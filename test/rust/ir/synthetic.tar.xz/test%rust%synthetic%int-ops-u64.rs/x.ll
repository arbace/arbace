; ModuleID = 'int_ops_u64.796c94a944354593-cgu.0'
source_filename = "int_ops_u64.796c94a944354593-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaqkWKWdl1xD_11int_ops_u64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !0
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !1
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !2
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !3
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !4
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !5
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !6
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !7
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !8
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !9
@alloc_b7f057a700061b96879a1cf049d1c13f = private unnamed_addr constant [4 x i8] c"@\00\00\00", align 4, !guid !10
@alloc_39a69332114d933fd0ed2d6178b5663f = private unnamed_addr constant [15 x i8] c"\C0\01 \C0\06 bits \C0\01\0A\00", align 1, !guid !11
@alloc_b97b237269009ab871a5d98c9589107d = private unnamed_addr constant [17 x i8] c"\C0\01 \C1 \00\80`\01 \C0\01 \C0\01\0A\00", align 1, !guid !12
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !13
@alloc_b14bb161abcc1e25b418bf7683984c8b = private unnamed_addr constant [35 x i8] c"test/rust/synthetic/int-ops-u64.rs\00", align 1, !guid !14
@alloc_8a23c0758fbf417fc818cbd8735ef655 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\10\00\00\00A\00\00\00" }>, align 8, !guid !15
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !16
@alloc_7f34e9163fb18bbebb42b639348843c3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00\17\00\00\00" }>, align 8, !guid !17
@alloc_16b4e0c063782b4883031e6e0c36e77b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\14\00\00\00$\00\00\00" }>, align 8, !guid !18
@alloc_ae52c2733f312a4a903aef7e6436cb13 = private unnamed_addr constant [2 x i8] c"11", align 1, !guid !19
@alloc_b5cf66decfc284fbd911f1a33c9cfc2b = private unnamed_addr constant [3 x i8] c"300", align 1, !guid !20
@alloc_dd0c98b643347ed36d6d6d8492534cf1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\00$\00\00\00" }>, align 8, !guid !21
@alloc_8f9d50c9386268ec077df5193767c256 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1A\00\00\004\00\00\00" }>, align 8, !guid !22
@alloc_8df7207579456be1b8cc8a77a25d63d9 = private unnamed_addr constant [8 x i8] c"\C3 \00\00(-\00\00", align 1, !guid !23
@alloc_db4a9b34cd4b0400e0309e7a877f6ab6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b14bb161abcc1e25b418bf7683984c8b, [16 x i8] c"\22\00\00\00\00\00\00\00\1B\00\00\00\14\00\00\00" }>, align 8, !guid !24
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !25
@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !26
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !27
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !28
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !29
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !30
@alloc_78b6a49e36fe808e0ef950c2feb9fafc = private unnamed_addr constant [71 x i8] c"to_digit: invalid radix -- radix must be in the range 2 to 36 inclusive", align 1, !guid !31
@alloc_29239fb67bbb61a9701dc91a228afdc5 = private unnamed_addr constant [25 x i8] c"core/src/char/methods.rs\00", align 1, !guid !32
@alloc_6b38166963fe6da8fd2b01f68be063f4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29239fb67bbb61a9701dc91a228afdc5, [16 x i8] c"\18\00\00\00\00\00\00\00\97\01\00\00\09\00\00\00" }>, align 8, !guid !33
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !34
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !35
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !36
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !37
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !38
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !39
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !40
@alloc_f1a045d8073201c1c83e5f2e698e256e = private unnamed_addr constant [20 x i8] c"core/src/fmt/mod.rs\00", align 1, !guid !41
@alloc_fa033a099f4a753e8c9d30a58dfdad40 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a045d8073201c1c83e5f2e698e256e, [16 x i8] c"\13\00\00\00\00\00\00\00q\03\00\00*\00\00\00" }>, align 8, !guid !42
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !43
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !44
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !45
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !46
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !47
@alloc_ae2de464f9b6df44eca1585c04dc7532 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00*\05\00\00\05\00\00\00" }>, align 8, !guid !48
@alloc_5aa1d1250638a5285856df0c8e3018a3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00K\07\00\00\01\00\00\00" }>, align 8, !guid !49
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !50
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !51
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !52
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !53
@anon.3163d8aaa3ec962f62b1dd64a9184856.0 = private unnamed_addr constant [512 x i8] c"\00\00\01\00\01\01\01\02\02\00\02\01\02\02\02\03\02\04\03\00\03\01\03\02\03\03\03\04\03\05\03\06\04\00\04\01\04\02\04\03\04\04\04\05\04\06\04\07\04\08\05\00\05\01\05\02\05\03\05\04\05\05\05\06\05\07\05\08\05\09\05\0A\06\00\06\01\06\02\06\03\06\04\06\05\06\06\06\07\06\08\06\09\06\0A\06\0B\06\0C\07\00\07\01\07\02\07\03\07\04\07\05\07\06\07\07\07\08\07\09\07\0A\07\0B\07\0C\07\0D\07\0E\08\00\08\01\08\02\08\03\08\04\08\05\08\06\08\07\08\08\08\09\08\0A\08\0B\08\0C\08\0D\08\0E\08\0F\08\10\09\00\09\01\09\02\09\03\09\04\09\05\09\06\09\07\09\08\09\09\09\0A\09\0B\09\0C\09\0D\09\0E\09\0F\09\10\09\11\09\12\0A\00\0A\01\0A\02\0A\03\0A\04\0A\05\0A\06\0A\07\0A\08\0A\09\0A\0A\0A\0B\0A\0C\0A\0D\0A\0E\0A\0F\0A\10\0A\11\0A\12\0A\13\0A\14\0B\00\0B\01\0B\02\0B\03\0B\04\0B\05\0B\06\0B\07\0B\08\0B\09\0B\0A\0B\0B\0B\0C\0B\0D\0B\0E\0B\0F\0B\10\0B\11\0B\12\0B\13\0B\14\0B\15\0B\16\0C\00\0C\01\0C\02\0C\03\0C\04\0C\05\0C\06\0C\07\0C\08\0C\09\0C\0A\0C\0B\0C\0C\0C\0D\0C\0E\0C\0F\0C\10\0C\11\0C\12\0C\13\0C\14\0C\15\0C\16\0C\17\0C\18\0D\00\0D\01\0D\02\0D\03\0D\04\0D\05\0D\06\0D\07\0D\08\0D\09\0D\0A\0D\0B\0D\0C\0D\0D\0D\0E\0D\0F\0D\10\0D\11\0D\12\0D\13\0D\14\0D\15\0D\16\0D\17\0D\18\0D\19\0D\1A\0E\00\0E\01\0E\02\0E\03\0E\04\0E\05\0E\06\0E\07\0E\08\0E\09\0E\0A\0E\0B\0E\0C\0E\0D\0E\0E\0E\0F\0E\10\0E\11\0E\12\0E\13\0E\14\0E\15\0E\16\0E\17\0E\18\0E\19\0E\1A\0E\1B\0E\1C\0F\00\0F\01\0F\02\0F\03\0F\04\0F\05\0F\06\0F\07\0F\08\0F\09\0F\0A\0F\0B\0F\0C\0F\0D\0F\0E\0F\0F\0F\10\0F\11\0F\12\0F\13\0F\14\0F\15\0F\16\0F\17\0F\18\0F\19\0F\1A\0F\1B\0F\1C\0F\1D\0F\1E", align 1, !guid !54
@alloc_f760a8b1c45ef3b69092b00440ac3bf6 = private unnamed_addr constant [29 x i8] c"core/src/num/imp/int_sqrt.rs\00", align 1, !guid !55
@alloc_dd07830ff498a5ad3af27fc9310868e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E5\00\00\00\12\00\00\00" }>, align 8, !guid !56
@alloc_73a63def61abd19c5b285b7e5bba6f74 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\E6\00\00\00\05\00\00\00" }>, align 8, !guid !57
@alloc_c9c619c258f652778f0098fbdacd3593 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F1\00\00\00\12\00\00\00" }>, align 8, !guid !58
@alloc_debe392282102e1a17f340d9b53f07df = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !59
@alloc_d1e64d3a180065bd6a022925cad00717 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\F3\00\00\00\05\00\00\00" }>, align 8, !guid !60
@alloc_9a4d1999757609695fb8537fcdec871b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FE\00\00\00\12\00\00\00" }>, align 8, !guid !61
@alloc_ffea377e021bf2f87b4ad4aac9bcd041 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\FF\00\00\00\12\00\00\00" }>, align 8, !guid !62
@alloc_3410a5a3f8bc9abd6709ddad50da91f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\00\01\00\00\12\00\00\00" }>, align 8, !guid !63
@alloc_cb646754bd05cd238e749888201337e6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00\01\01\00\00\05\00\00\00" }>, align 8, !guid !64
@alloc_c4e65bfc79cb636ae13d26c91b325bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f760a8b1c45ef3b69092b00440ac3bf6, [16 x i8] c"\1C\00\00\00\00\00\00\00)\00\00\00\05\00\00\00" }>, align 8, !guid !65
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !66
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !67
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !68
@alloc_c856595eac66a24654d670eae8c59bb6 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !69
@alloc_f4be92229193d4464753072989252627 = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_shl cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !70
@alloc_10473b11a7e05bbd7ed679b01f6c847b = private unnamed_addr constant [184 x i8] c"unsafe precondition(s) violated: u64::unchecked_shr cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !71
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !72
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !73
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !74
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !75
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !76
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !77
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !78
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !79
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !80
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !81
@alloc_f62df14955f7d78bca139b0a7668683d = private unnamed_addr constant [13 x i8] c"ParseIntError", align 1, !guid !82
@alloc_a5d866b1768ad3f826bccdb004a1a8ae = private unnamed_addr constant [4 x i8] c"kind", align 1, !guid !83
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !84
@alloc_59ba7b9f7211443cd55a366616eef46a = private unnamed_addr constant [5 x i8] c"Empty", align 1, !guid !85
@alloc_00315c78e51d29fe6b3102a4c1ecf6ef = private unnamed_addr constant [12 x i8] c"InvalidDigit", align 1, !guid !86
@alloc_bd3a3f3879e0d5f64554753e977f58d4 = private unnamed_addr constant [11 x i8] c"PosOverflow", align 1, !guid !87
@alloc_0964bb2a4870637395c77a018495bd5c = private unnamed_addr constant [11 x i8] c"NegOverflow", align 1, !guid !88
@alloc_6566120a3a17f930e960a0863fcbd591 = private unnamed_addr constant [4 x i8] c"Zero", align 1, !guid !89
@alloc_6c17bac0c71cba42380f8445f4dcbd16 = private unnamed_addr constant [14 x i8] c"NotAPowerOfTwo", align 1, !guid !90
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !91
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !92
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64 }>, align 8, !guid !93

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !99 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <str>::parse::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !100 {
start:
; call <u64 as core::str::traits::FromStr>::from_str
  call void @_RNvXsC_NtCsl10jNU3mE6R_4core3numyNtNtNtB7_3str6traits7FromStr8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECsaqkWKWdl1xD_11int_ops_u64(ptr %0) unnamed_addr #0 !guid !101 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1, ptr align 8 %default) unnamed_addr #0 personality ptr @rust_eh_personality !guid !102 {
start:
  %_10 = alloca [1 x i8], align 1
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_10, align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_10, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_4 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_4 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %t.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
  call void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %t.0, i64 %t.1) #21
  br label %bb15

bb2:                                              ; preds = %start
  store i8 0, ptr %_10, align 1
; call alloc::fmt::format::{closure#0}
  call void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %default) #21
  br label %bb14

bb14:                                             ; preds = %bb2
  br label %bb9

bb9:                                              ; preds = %bb15, %bb14
  %10 = load i8, ptr %_9, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb8, label %bb4

bb15:                                             ; preds = %bb3
  br label %bb9

bb4:                                              ; preds = %bb8, %bb9
  %12 = load i8, ptr %_10, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
  br label %bb4

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable

bb12:                                             ; No predecessors!
  unreachable

bb13:                                             ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !103 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CsaqkWKWdl1xD_11int_ops_u64() #21
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_binary::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !104 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsy_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_6Binary3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !105 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %x) #21
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !106 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !107 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %x) #21
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !108 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<usize>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<usize>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !109 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %x) #21
; call <core::ptr::non_null::NonNull<u32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !110 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsd_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impyNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_lower_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !111 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsC_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8LowerHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_upper_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !112 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !113 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u64>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionyEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<core::option::Option<u64>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionyEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u64, core::num::error::ParseIntError>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultyNtNtNtB7_3num5error13ParseIntErrorEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !114 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultyNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultyNtNtNtBa_3num5error13ParseIntErrorEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultyNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !115 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<(u64, bool)>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTybEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<(u64, bool)>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTybEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTybENtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !116 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %x) #21
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_octal::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !117 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<u64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsA_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Octal3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !118 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<u64>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionyEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !119 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultyNtNtNtBa_3num5error13ParseIntErrorEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !120 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !121 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<(u64, bool)>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullTybEE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !122 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !123 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !124 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !125 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !126 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<usize>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulljE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !127 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullmE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !128 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4castuECsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !129 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !130 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !131 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %_3) #21
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr %_2) #21
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<17, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !132 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !133 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !134 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<8, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !135 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !136 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !137 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaqkWKWdl1xD_11int_ops_u64(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !138 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u64>
; Function Attrs: nounwind nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyECsaqkWKWdl1xD_11int_ops_u64(i64 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !139 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 8 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i64
  %_0 = call i64 @llvm.fshl.i64(i64 %x, i64 %x, i64 %1)
  ret i64 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #23
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u64>
; Function Attrs: nounwind nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECsaqkWKWdl1xD_11int_ops_u64(i64 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !140 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 8 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i64
  %_0 = call i64 @llvm.fshr.i64(i64 %x, i64 %x, i64 %1)
  ret i64 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #23
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::is_val_statically_known::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownmECsaqkWKWdl1xD_11int_ops_u64(i32 %_arg) unnamed_addr #2 !guid !141 {
start:
  ret i1 false
}

; core::intrinsics::is_val_statically_known::<u64>
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core10intrinsics23is_val_statically_knownyECsaqkWKWdl1xD_11int_ops_u64(i64 %_arg) unnamed_addr #2 !guid !142 {
start:
  ret i1 false
}

; core::ptr::slice_from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) unnamed_addr #0 !guid !143 {
start:
; call core::ptr::metadata::from_raw_parts::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) unnamed_addr #0 !guid !144 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !145 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) #24
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) unnamed_addr #1 !guid !146 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) unnamed_addr #1 !guid !147 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaqkWKWdl1xD_11int_ops_u64(i32 %dummy) unnamed_addr #0 !guid !148 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !149
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 %dummy) unnamed_addr #0 !guid !150 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !149
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !151 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !149
  ret void
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 %dummy) unnamed_addr #0 !guid !152 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !149
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaqkWKWdl1xD_11int_ops_u64(ptr %f) unnamed_addr #3 personality ptr @rust_eh_personality !guid !153 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %f) #21
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsaqkWKWdl1xD_11int_ops_u64() #21
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsShhECsaqkWKWdl1xD_11int_ops_u64(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !154 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECsaqkWKWdl1xD_11int_ops_u64(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !155 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::slice::raw::from_raw_parts::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !156 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partshECsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) #21
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 1, i64 1, i64 %len, ptr align 8 %0) #25
  br label %bb5
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !157 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #21
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %v) #24
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #25
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) unnamed_addr #0 !guid !158 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #26
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaqkWKWdl1xD_11int_ops_u64() #21
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaqkWKWdl1xD_11int_ops_u64(i8 %_2) #21
  ret i32 %_0
}

; alloc::fmt::format::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvNtCs7CppTae75M1_5alloc3fmt6format0CsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #0 !guid !159 {
start:
  %_2.0 = load ptr, ptr %_1, align 8
  %0 = getelementptr inbounds i8, ptr %_1, i64 8
  %_2.1 = load ptr, ptr %0, align 8
; call alloc::fmt::format::format_inner
  call void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, ptr %_2.1)
  ret void
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !160 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsaqkWKWdl1xD_11int_ops_u64(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsaqkWKWdl1xD_11int_ops_u64(ptr %_1) unnamed_addr #0 !guid !161 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %0) #21
  ret i32 %_0
}

; int_ops_u64::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsaqkWKWdl1xD_11int_ops_u644main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !162 {
start:
  %0 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %args24 = alloca [16 x i8], align 8
  %_283 = alloca [16 x i8], align 8
  %args23 = alloca [16 x i8], align 8
  %_278 = alloca [24 x i8], align 8
  %_277 = alloca [24 x i8], align 8
  %_273 = alloca [24 x i8], align 8
  %_270 = alloca [8 x i8], align 8
  %_263 = alloca [16 x i8], align 8
  %_262 = alloca [16 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_258 = alloca [4 x i8], align 4
  %_256 = alloca [8 x i8], align 8
  %_249 = alloca [16 x i8], align 8
  %_248 = alloca [16 x i8], align 8
  %args21 = alloca [32 x i8], align 8
  %_246 = alloca [4 x i8], align 4
  %_244 = alloca [4 x i8], align 4
  %_237 = alloca [16 x i8], align 8
  %_236 = alloca [16 x i8], align 8
  %_235 = alloca [16 x i8], align 8
  %args20 = alloca [48 x i8], align 8
  %_233 = alloca [8 x i8], align 8
  %_231 = alloca [4 x i8], align 4
  %_227 = alloca [1 x i8], align 1
  %args19 = alloca [24 x i8], align 8
  %_220 = alloca [16 x i8], align 8
  %_219 = alloca [16 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_216 = alloca [16 x i8], align 8
  %_214 = alloca [1 x i8], align 1
  %_210 = alloca [16 x i8], align 8
  %_203 = alloca [16 x i8], align 8
  %_202 = alloca [16 x i8], align 8
  %args17 = alloca [32 x i8], align 8
  %_200 = alloca [8 x i8], align 8
  %_197 = alloca [8 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %_189 = alloca [16 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_187 = alloca [16 x i8], align 8
  %_184 = alloca [16 x i8], align 8
  %_177 = alloca [16 x i8], align 8
  %_176 = alloca [16 x i8], align 8
  %args15 = alloca [32 x i8], align 8
  %_173 = alloca [8 x i8], align 8
  %_170 = alloca [8 x i8], align 8
  %_163 = alloca [16 x i8], align 8
  %_162 = alloca [16 x i8], align 8
  %args14 = alloca [32 x i8], align 8
  %_159 = alloca [8 x i8], align 8
  %_156 = alloca [8 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %_148 = alloca [16 x i8], align 8
  %args13 = alloca [32 x i8], align 8
  %_146 = alloca [8 x i8], align 8
  %_144 = alloca [8 x i8], align 8
  %_137 = alloca [16 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %args12 = alloca [32 x i8], align 8
  %_133 = alloca [8 x i8], align 8
  %_130 = alloca [8 x i8], align 8
  %_123 = alloca [16 x i8], align 8
  %_122 = alloca [16 x i8], align 8
  %_121 = alloca [16 x i8], align 8
  %args11 = alloca [48 x i8], align 8
  %_115 = alloca [4 x i8], align 4
  %_113 = alloca [4 x i8], align 4
  %_111 = alloca [4 x i8], align 4
  %args10 = alloca [24 x i8], align 8
  %_104 = alloca [16 x i8], align 8
  %_103 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_100 = alloca [16 x i8], align 8
  %_98 = alloca [16 x i8], align 8
  %_91 = alloca [16 x i8], align 8
  %_90 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_88 = alloca [8 x i8], align 8
  %_86 = alloca [8 x i8], align 8
  %_79 = alloca [16 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_76 = alloca [8 x i8], align 8
  %_74 = alloca [8 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %_66 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_64 = alloca [8 x i8], align 8
  %_62 = alloca [8 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_50 = alloca [16 x i8], align 8
  %_43 = alloca [16 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_31 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_29 = alloca [16 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_15 = alloca [16 x i8], align 8
  %args1 = alloca [48 x i8], align 8
  %args = alloca [24 x i8], align 8
  %max = alloca [8 x i8], align 8
  %min = alloca [8 x i8], align 8
; call core::hint::black_box::<u64>
  %_4 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 0) #21
; call core::hint::black_box::<u64>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 -1) #21
  store i64 %_4, ptr %min, align 8
  store i64 %_5, ptr %max, align 8
; call core::hint::black_box::<u64>
  %one = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 1) #21
; call core::hint::black_box::<u64>
  %three = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 3) #21
  store ptr %min, ptr %args, align 8
  %1 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %max, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr @alloc_b7f057a700061b96879a1cf049d1c13f, ptr %2, align 8
  %_291 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_15, ptr align 8 %_291) #21
  %3 = getelementptr inbounds i8, ptr %args, i64 8
  %_292 = load ptr, ptr %3, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %_292) #21
  %4 = getelementptr inbounds i8, ptr %args, i64 16
  %_293 = load ptr, ptr %4, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_17, ptr align 4 %_293) #21
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_15, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_16, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_17, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 3>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_39a69332114d933fd0ed2d6178b5663f, ptr align 8 %args1) #21
  %_9.0 = extractvalue { ptr, ptr } %8, 0
  %_9.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_9.0, ptr %_9.1)
  store ptr %max, ptr %args2, align 8
  %9 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %max, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %max, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %min, ptr %11, align 8
  %_294 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_28, ptr align 8 %_294) #21
  %12 = getelementptr inbounds i8, ptr %args2, i64 8
  %_295 = load ptr, ptr %12, align 8
; call <core::fmt::rt::Argument>::new_binary::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument10new_binaryyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_29, ptr align 8 %_295) #21
  %13 = getelementptr inbounds i8, ptr %args2, i64 16
  %_296 = load ptr, ptr %13, align 8
; call <core::fmt::rt::Argument>::new_octal::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_octalyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_30, ptr align 8 %_296) #21
  %14 = getelementptr inbounds i8, ptr %args2, i64 24
  %_297 = load ptr, ptr %14, align 8
; call <core::fmt::rt::Argument>::new_upper_hex::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_upper_hexyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_31, ptr align 8 %_297) #21
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_28, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_29, i64 16, i1 false)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_30, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_31, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<17, 4>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj4_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b97b237269009ab871a5d98c9589107d, ptr align 8 %args3) #21
  %_21.0 = extractvalue { ptr, ptr } %19, 0
  %_21.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
  %20 = load i64, ptr %max, align 8
; call <u64>::checked_add
  %21 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %20, i64 %one) #21
  %22 = extractvalue { i64, i64 } %21, 0
  %23 = extractvalue { i64, i64 } %21, 1
  store i64 %22, ptr %_38, align 8
  %24 = getelementptr inbounds i8, ptr %_38, i64 8
  store i64 %23, ptr %24, align 8
  %25 = load i64, ptr %min, align 8
; call <u64>::checked_add
  %26 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %25, i64 %one) #21
  %27 = extractvalue { i64, i64 } %26, 0
  %28 = extractvalue { i64, i64 } %26, 1
  store i64 %27, ptr %_40, align 8
  %29 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %28, ptr %29, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_38) #21
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_43, ptr align 8 %_40) #21
  %30 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %_42, i64 16, i1 false)
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_43, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %32 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #21
  %_35.0 = extractvalue { ptr, ptr } %32, 0
  %_35.1 = extractvalue { ptr, ptr } %32, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_35.0, ptr %_35.1)
  %33 = load i64, ptr %max, align 8
  %_5.0.i = add i64 %33, %one
  %_5.1.i = icmp ult i64 %_5.0.i, %33
  %34 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %35 = insertvalue { i64, i1 } %34, i1 %_5.1.i, 1
  %36 = extractvalue { i64, i1 } %35, 0
  %37 = extractvalue { i64, i1 } %35, 1
  store i64 %36, ptr %_50, align 8
  %38 = getelementptr inbounds i8, ptr %_50, i64 8
  %39 = zext i1 %37 to i8
  store i8 %39, ptr %38, align 8
  %40 = load i64, ptr %min, align 8
  %_5.0.i53 = sub i64 %40, %one
  %_5.1.i54 = icmp ult i64 %40, %one
  %41 = insertvalue { i64, i1 } poison, i64 %_5.0.i53, 0
  %42 = insertvalue { i64, i1 } %41, i1 %_5.1.i54, 1
  %43 = extractvalue { i64, i1 } %42, 0
  %44 = extractvalue { i64, i1 } %42, 1
  store i64 %43, ptr %_52, align 8
  %45 = getelementptr inbounds i8, ptr %_52, i64 8
  %46 = zext i1 %44 to i8
  store i8 %46, ptr %45, align 8
; call <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_54, ptr align 8 %_50) #21
; call <core::fmt::rt::Argument>::new_debug::<(u64, bool)>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugTybEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_55, ptr align 8 %_52) #21
  %47 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %47, ptr align 8 %_54, i64 16, i1 false)
  %48 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %48, ptr align 8 %_55, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %49 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args5) #21
  %_47.0 = extractvalue { ptr, ptr } %49, 0
  %_47.1 = extractvalue { ptr, ptr } %49, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_47.0, ptr %_47.1)
  %50 = load i64, ptr %max, align 8
  %_0.i35 = add i64 %50, %one
  store i64 %_0.i35, ptr %_62, align 8
  %51 = load i64, ptr %min, align 8
  %_0.i41 = sub i64 %51, %one
  store i64 %_0.i41, ptr %_64, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_66, ptr align 8 %_62) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_67, ptr align 8 %_64) #21
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_66, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_67, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %54 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args6) #21
  %_59.0 = extractvalue { ptr, ptr } %54, 0
  %_59.1 = extractvalue { ptr, ptr } %54, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_59.0, ptr %_59.1)
  %55 = load i64, ptr %max, align 8
  %_0.i49 = call i64 @llvm.uadd.sat.i64(i64 %55, i64 %three)
  store i64 %_0.i49, ptr %_74, align 8
  %56 = load i64, ptr %min, align 8
  %_0.i50 = call i64 @llvm.usub.sat.i64(i64 %56, i64 %three)
  store i64 %_0.i50, ptr %_76, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_78, ptr align 8 %_74) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_79, ptr align 8 %_76) #21
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_78, i64 16, i1 false)
  %58 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %58, ptr align 8 %_79, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %59 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #21
  %_71.0 = extractvalue { ptr, ptr } %59, 0
  %_71.1 = extractvalue { ptr, ptr } %59, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_71.0, ptr %_71.1)
  %60 = load i64, ptr %max, align 8
  %_0.i37 = mul i64 %60, %three
  store i64 %_0.i37, ptr %_86, align 8
  %61 = load i64, ptr %max, align 8
  %62 = load i64, ptr %max, align 8
  %_0.i36 = mul i64 %61, %62
  store i64 %_0.i36, ptr %_88, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_90, ptr align 8 %_86) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_91, ptr align 8 %_88) #21
  %63 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %63, ptr align 8 %_90, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %64, ptr align 8 %_91, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %65 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args8) #21
  %_83.0 = extractvalue { ptr, ptr } %65, 0
  %_83.1 = extractvalue { ptr, ptr } %65, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_83.0, ptr %_83.1)
  %66 = load i64, ptr %max, align 8
; call <u64>::checked_mul
  %67 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %66, i64 %three) #21
  %68 = extractvalue { i64, i64 } %67, 0
  %69 = extractvalue { i64, i64 } %67, 1
  store i64 %68, ptr %_98, align 8
  %70 = getelementptr inbounds i8, ptr %_98, i64 8
  store i64 %69, ptr %70, align 8
; call core::hint::black_box::<u32>
  %_101 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 5) #21
; call <u64>::checked_pow
  %71 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %three, i32 %_101) #21
  %72 = extractvalue { i64, i64 } %71, 0
  %73 = extractvalue { i64, i64 } %71, 1
  store i64 %72, ptr %_100, align 8
  %74 = getelementptr inbounds i8, ptr %_100, i64 8
  store i64 %73, ptr %74, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_103, ptr align 8 %_98) #21
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_104, ptr align 8 %_100) #21
  %75 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %75, ptr align 8 %_103, i64 16, i1 false)
  %76 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %76, ptr align 8 %_104, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %77 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args9) #21
  %_95.0 = extractvalue { ptr, ptr } %77, 0
  %_95.1 = extractvalue { ptr, ptr } %77, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_95.0, ptr %_95.1)
  %78 = load i64, ptr %max, align 8
  %79 = call i64 @llvm.ctpop.i64(i64 %78)
  %_0.i = trunc i64 %79 to i32
  store i32 %_0.i, ptr %_111, align 4
  %80 = load i64, ptr %max, align 8
  %81 = call i64 @llvm.ctlz.i64(i64 %80, i1 false)
  %_0.i43 = trunc i64 %81 to i32
  store i32 %_0.i43, ptr %_113, align 4
; call core::hint::black_box::<i32>
  %_117 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsaqkWKWdl1xD_11int_ops_u64(i32 3) #21
  %_119 = icmp ult i32 %_117, 64
  br i1 %_119, label %bb56, label %panic

bb56:                                             ; preds = %start
  %82 = and i32 %_117, 63
  %83 = zext i32 %82 to i64
  %_116 = shl i64 %one, %83
  %84 = call i64 @llvm.cttz.i64(i64 %_116, i1 false)
  %_0.i52 = trunc i64 %84 to i32
  store i32 %_0.i52, ptr %_115, align 4
  store ptr %_111, ptr %args10, align 8
  %85 = getelementptr inbounds i8, ptr %args10, i64 8
  store ptr %_113, ptr %85, align 8
  %86 = getelementptr inbounds i8, ptr %args10, i64 16
  store ptr %_115, ptr %86, align 8
  %_310 = load ptr, ptr %args10, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_121, ptr align 4 %_310) #21
  %87 = getelementptr inbounds i8, ptr %args10, i64 8
  %_311 = load ptr, ptr %87, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_122, ptr align 4 %_311) #21
  %88 = getelementptr inbounds i8, ptr %args10, i64 16
  %_312 = load ptr, ptr %88, align 8
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_123, ptr align 4 %_312) #21
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_121, i64 16, i1 false)
  %90 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %90, ptr align 8 %_122, i64 16, i1 false)
  %91 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %91, ptr align 8 %_123, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %92 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args11) #21
  %_108.0 = extractvalue { ptr, ptr } %92, 0
  %_108.1 = extractvalue { ptr, ptr } %92, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_108.0, ptr %_108.1)
; call core::hint::black_box::<u32>
  %_131 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 5) #21
  %93 = load i64, ptr %max, align 8
; call core::intrinsics::rotate_left::<u64>
  %_0.i31 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyECsaqkWKWdl1xD_11int_ops_u64(i64 %93, i32 %_131) #27
  store i64 %_0.i31, ptr %_130, align 8
; call core::hint::black_box::<u32>
  %_134 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 7) #21
  %94 = load i64, ptr %min, align 8
; call core::intrinsics::rotate_right::<u64>
  %_0.i34 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightyECsaqkWKWdl1xD_11int_ops_u64(i64 %94, i32 %_134) #27
  store i64 %_0.i34, ptr %_133, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_136, ptr align 8 %_130) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_137, ptr align 8 %_133) #21
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_136, i64 16, i1 false)
  %96 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %96, ptr align 8 %_137, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %97 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args12) #21
  %_127.0 = extractvalue { ptr, ptr } %97, 0
  %_127.1 = extractvalue { ptr, ptr } %97, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_127.0, ptr %_127.1)
  %98 = load i64, ptr %max, align 8
  %_0.i30 = call i64 @llvm.bswap.i64(i64 %98)
  store i64 %_0.i30, ptr %_144, align 8
  %99 = load i64, ptr %max, align 8
  %_0.i33 = call i64 @llvm.bitreverse.i64(i64 %99)
  store i64 %_0.i33, ptr %_146, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_148, ptr align 8 %_144) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_146) #21
  %100 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %100, ptr align 8 %_148, i64 16, i1 false)
  %101 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %101, ptr align 8 %_149, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %102 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args13) #21
  %_141.0 = extractvalue { ptr, ptr } %102, 0
  %_141.1 = extractvalue { ptr, ptr } %102, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_141.0, ptr %_141.1)
; call core::hint::black_box::<u32>
  %_157 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 70) #21
  %103 = load i64, ptr %max, align 8
  %_3.i = and i32 %_157, 63
; call core::ub_checks::check_language_ub
  %_3.i44 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i44, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb56
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %_3.i, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb56, %bb2.i
  %104 = zext i32 %_3.i to i64
  %_0.i45 = shl i64 %103, %104
  store i64 %_0.i45, ptr %_156, align 8
; call core::hint::black_box::<u32>
  %_160 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 66) #21
  %105 = load i64, ptr %min, align 8
  %_3.i39 = and i32 %_160, 63
; call core::ub_checks::check_language_ub
  %_3.i46 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i46, label %bb2.i48, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit

bb2.i48:                                          ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit
; call <u64>::unchecked_shr::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %_3.i39, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit: ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb2.i48
  %106 = zext i32 %_3.i39 to i64
  %_0.i47 = lshr i64 %105, %106
  store i64 %_0.i47, ptr %_159, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_162, ptr align 8 %_156) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_163, ptr align 8 %_159) #21
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_162, i64 16, i1 false)
  %108 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %108, ptr align 8 %_163, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %109 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args14) #21
  %_153.0 = extractvalue { ptr, ptr } %109, 0
  %_153.1 = extractvalue { ptr, ptr } %109, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_153.0, ptr %_153.1)
  %_171 = icmp eq i64 %three, 0
  br i1 %_171, label %panic25, label %bb85

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_shl_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8 @alloc_8a23c0758fbf417fc818cbd8735ef655) #28
  unreachable

bb85:                                             ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit
  %110 = load i64, ptr %max, align 8
  %111 = udiv i64 %110, %three
  store i64 %111, ptr %_170, align 8
  %_174 = icmp eq i64 %three, 0
  br i1 %_174, label %panic26, label %bb86

panic25:                                          ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_7f34e9163fb18bbebb42b639348843c3) #28
  unreachable

bb86:                                             ; preds = %bb85
  %112 = load i64, ptr %max, align 8
  %113 = urem i64 %112, %three
  store i64 %113, ptr %_173, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_176, ptr align 8 %_170) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_177, ptr align 8 %_173) #21
  %114 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %114, ptr align 8 %_176, i64 16, i1 false)
  %115 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %115, ptr align 8 %_177, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %116 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args15) #21
  %_167.0 = extractvalue { ptr, ptr } %116, 0
  %_167.1 = extractvalue { ptr, ptr } %116, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_167.0, ptr %_167.1)
; call core::hint::black_box::<u64>
  %_185 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECsaqkWKWdl1xD_11int_ops_u64(i64 0) #21
  %117 = load i64, ptr %max, align 8
; call <u64>::checked_div
  %118 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_divCsaqkWKWdl1xD_11int_ops_u64(i64 %117, i64 %_185) #21
  %119 = extractvalue { i64, i64 } %118, 0
  %120 = extractvalue { i64, i64 } %118, 1
  store i64 %119, ptr %_184, align 8
  %121 = getelementptr inbounds i8, ptr %_184, i64 8
  store i64 %120, ptr %121, align 8
  %122 = load i64, ptr %max, align 8
; call <u64>::checked_rem
  %123 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_remCsaqkWKWdl1xD_11int_ops_u64(i64 %122, i64 %three) #21
  %124 = extractvalue { i64, i64 } %123, 0
  %125 = extractvalue { i64, i64 } %123, 1
  store i64 %124, ptr %_187, align 8
  %126 = getelementptr inbounds i8, ptr %_187, i64 8
  store i64 %125, ptr %126, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_189, ptr align 8 %_184) #21
; call <core::fmt::rt::Argument>::new_debug::<core::option::Option<u64>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionyEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_190, ptr align 8 %_187) #21
  %127 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %127, ptr align 8 %_189, i64 16, i1 false)
  %128 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %128, ptr align 8 %_190, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %129 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args16) #21
  %_181.0 = extractvalue { ptr, ptr } %129, 0
  %_181.1 = extractvalue { ptr, ptr } %129, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_181.0, ptr %_181.1)
; call core::hint::black_box::<u32>
  %_198 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 4) #21
; call <u64>::pow
  %130 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy3powCsaqkWKWdl1xD_11int_ops_u64(i64 %three, i32 %_198) #21
  store i64 %130, ptr %_197, align 8
  %131 = load i64, ptr %max, align 8
  %132 = load i64, ptr %min, align 8
; call <u64>::abs_diff
  %133 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %131, i64 %132) #21
  store i64 %133, ptr %_200, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_202, ptr align 8 %_197) #21
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_203, ptr align 8 %_200) #21
  %134 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %134, ptr align 8 %_202, i64 16, i1 false)
  %135 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %135, ptr align 8 %_203, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %136 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args17) #21
  %_194.0 = extractvalue { ptr, ptr } %136, 0
  %_194.1 = extractvalue { ptr, ptr } %136, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_194.0, ptr %_194.1)
; call core::hint::black_box::<u32>
  %_212 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECsaqkWKWdl1xD_11int_ops_u64(i32 7) #21
; call <u64>::from_str_radix
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_210, ptr @alloc_ae52c2733f312a4a903aef7e6436cb13, i64 2, i32 %_212) #21
; call <str>::parse::<u64>
  call void @_RINvMNtCsl10jNU3mE6R_4core3stre5parseyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_216, ptr @alloc_b5cf66decfc284fbd911f1a33c9cfc2b, i64 3) #21
; call <core::result::Result<u64, core::num::error::ParseIntError>>::is_ok
  %137 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyNtNtNtB4_3num5error13ParseIntErrorE5is_okCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_216) #21
  %138 = zext i1 %137 to i8
  store i8 %138, ptr %_214, align 1
; call <core::fmt::rt::Argument>::new_debug::<core::result::Result<u64, core::num::error::ParseIntError>>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultyNtNtNtB7_3num5error13ParseIntErrorEECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_219, ptr align 8 %_210) #21
; call <core::fmt::rt::Argument>::new_debug::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_220, ptr %_214) #21
  %139 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %139, ptr align 8 %_219, i64 16, i1 false)
  %140 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %140, ptr align 8 %_220, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %141 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args18) #21
  %_207.0 = extractvalue { ptr, ptr } %141, 0
  %_207.1 = extractvalue { ptr, ptr } %141, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_207.0, ptr %_207.1)
  %142 = load i64, ptr %max, align 8
  %_229 = uitofp i64 %142 to double
  %_228 = call i64 @llvm.fptoui.sat.i64.f64(double %_229)
  %143 = load i64, ptr %max, align 8
  %144 = icmp eq i64 %_228, %143
  %145 = zext i1 %144 to i8
  store i8 %145, ptr %_227, align 1
  %146 = load i64, ptr %max, align 8
  %147 = uitofp i64 %146 to float
  store float %147, ptr %_231, align 4
  %148 = load i64, ptr %min, align 8
  %149 = uitofp i64 %148 to double
  store double %149, ptr %_233, align 8
  store ptr %_227, ptr %args19, align 8
  %150 = getelementptr inbounds i8, ptr %args19, i64 8
  store ptr %_231, ptr %150, align 8
  %151 = getelementptr inbounds i8, ptr %args19, i64 16
  store ptr %_233, ptr %151, align 8
  %_327 = load ptr, ptr %args19, align 8
; call <core::fmt::rt::Argument>::new_display::<bool>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_235, ptr %_327) #21
  %152 = getelementptr inbounds i8, ptr %args19, i64 8
  %_328 = load ptr, ptr %152, align 8
; call <core::fmt::rt::Argument>::new_display::<f32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_236, ptr align 4 %_328) #21
  %153 = getelementptr inbounds i8, ptr %args19, i64 16
  %_329 = load ptr, ptr %153, align 8
; call <core::fmt::rt::Argument>::new_display::<f64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_237, ptr align 8 %_329) #21
  %154 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %154, ptr align 8 %_235, i64 16, i1 false)
  %155 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %155, ptr align 8 %_236, i64 16, i1 false)
  %156 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args20, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %156, ptr align 8 %_237, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %157 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args20) #21
  %_224.0 = extractvalue { ptr, ptr } %157, 0
  %_224.1 = extractvalue { ptr, ptr } %157, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_224.0, ptr %_224.1)
  %158 = load i64, ptr %max, align 8
  %_2.i = xor i64 %158, -1
  %159 = call i64 @llvm.ctlz.i64(i64 %_2.i, i1 false)
  %_0.i42 = trunc i64 %159 to i32
  store i32 %_0.i42, ptr %_244, align 4
  %160 = load i64, ptr %min, align 8
  %161 = call i64 @llvm.cttz.i64(i64 %160, i1 false)
  %_0.i51 = trunc i64 %161 to i32
  store i32 %_0.i51, ptr %_246, align 4
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_248, ptr align 4 %_244) #21
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_249, ptr align 4 %_246) #21
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_248, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_249, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %164 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args21) #21
  %_241.0 = extractvalue { ptr, ptr } %164, 0
  %_241.1 = extractvalue { ptr, ptr } %164, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_241.0, ptr %_241.1)
  %165 = load i64, ptr %max, align 8
; call <u64>::isqrt
  %166 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCsaqkWKWdl1xD_11int_ops_u64(i64 %165) #21
  store i64 %166, ptr %_256, align 8
  %167 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %three, i64 %three)
  %_260.0 = extractvalue { i64, i1 } %167, 0
  %_260.1 = extractvalue { i64, i1 } %167, 1
  br i1 %_260.1, label %panic27, label %bb125

panic26:                                          ; preds = %bb85
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_16b4e0c063782b4883031e6e0c36e77b) #28
  unreachable

bb125:                                            ; preds = %bb86
; call <u64>::ilog2
  %168 = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_260.0, ptr align 8 @alloc_8f9d50c9386268ec077df5193767c256) #21
  store i32 %168, ptr %_258, align 4
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_262, ptr align 8 %_256) #21
; call <core::fmt::rt::Argument>::new_display::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_263, ptr align 4 %_258) #21
  %169 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %169, ptr align 8 %_262, i64 16, i1 false)
  %170 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args22, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %170, ptr align 8 %_263, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %171 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args22) #21
  %_253.0 = extractvalue { ptr, ptr } %171, 0
  %_253.1 = extractvalue { ptr, ptr } %171, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_253.0, ptr %_253.1)
; call <u64 as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringyNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_273, ptr align 8 %max) #21
; invoke <alloc::string::String>::len
  %_271 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_273)
          to label %bb132 unwind label %cleanup

panic27:                                          ; preds = %bb86
; call core::panicking::panic_const::panic_const_mul_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8 @alloc_dd0c98b643347ed36d6d6d8492534cf1) #28
  unreachable

bb145:                                            ; preds = %bb144, %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_273) #24
          to label %bb146 unwind label %terminate

cleanup:                                          ; preds = %bb141, %bb134, %bb133, %bb132, %bb125
  %172 = landingpad { ptr, i32 }
          cleanup
  %173 = extractvalue { ptr, i32 } %172, 0
  %174 = extractvalue { ptr, i32 } %172, 1
  store ptr %173, ptr %0, align 8
  %175 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %174, ptr %175, align 8
  br label %bb145

bb132:                                            ; preds = %bb125
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_283, ptr align 8 %min)
          to label %bb133 unwind label %cleanup

bb133:                                            ; preds = %bb132
  %176 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %176, ptr align 8 %_283, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<8, 1>
  %177 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj8_Kj1_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_8df7207579456be1b8cc8a77a25d63d9, ptr align 8 %args23)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb133
  %_279.0 = extractvalue { ptr, ptr } %177, 0
  %_279.1 = extractvalue { ptr, ptr } %177, 1
; invoke alloc::fmt::format
  invoke void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_278, ptr %_279.0, ptr %_279.1)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_277, ptr align 8 %_278, i64 24, i1 false)
  br label %bb136

bb136:                                            ; preds = %bb135
; invoke <alloc::string::String>::len
  %_275 = invoke i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_277)
          to label %bb137 unwind label %cleanup28

bb144:                                            ; preds = %cleanup28
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_277) #24
          to label %bb145 unwind label %terminate

cleanup28:                                        ; preds = %bb140, %bb139, %bb138, %panic29, %bb136
  %178 = landingpad { ptr, i32 }
          cleanup
  %179 = extractvalue { ptr, i32 } %178, 0
  %180 = extractvalue { ptr, i32 } %178, 1
  store ptr %179, ptr %0, align 8
  %181 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %180, ptr %181, align 8
  br label %bb144

bb137:                                            ; preds = %bb136
  %_286.0 = add i64 %_271, %_275
  %_286.1 = icmp ult i64 %_286.0, %_271
  br i1 %_286.1, label %panic29, label %bb138

bb138:                                            ; preds = %bb137
  store i64 %_286.0, ptr %_270, align 8
; invoke <core::fmt::rt::Argument>::new_display::<usize>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayjECsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_288, ptr align 8 %_270)
          to label %bb139 unwind label %cleanup28

panic29:                                          ; preds = %bb137
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_db4a9b34cd4b0400e0309e7a877f6ab6) #23
          to label %unreachable unwind label %cleanup28

unreachable:                                      ; preds = %panic29
  unreachable

bb139:                                            ; preds = %bb138
  %182 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args24, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %182, ptr align 8 %_288, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %183 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args24)
          to label %bb140 unwind label %cleanup28

bb140:                                            ; preds = %bb139
  %_267.0 = extractvalue { ptr, ptr } %183, 0
  %_267.1 = extractvalue { ptr, ptr } %183, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_267.0, ptr %_267.1)
          to label %bb141 unwind label %cleanup28

bb141:                                            ; preds = %bb140
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_277)
          to label %bb142 unwind label %cleanup

bb142:                                            ; preds = %bb141
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_273)
  ret void

terminate:                                        ; preds = %bb145, %bb144
  %184 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb146:                                            ; preds = %bb145
  %185 = load ptr, ptr %0, align 8
  %186 = getelementptr inbounds i8, ptr %0, i64 8
  %187 = load i32, ptr %186, align 8
  %188 = insertvalue { ptr, i32 } poison, ptr %185, 0
  %189 = insertvalue { ptr, i32 } %188, i32 %187, 1
  resume { ptr, i32 } %189
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !163 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !164 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !165 {
start:
; call <alloc::vec::Vec<u8>>::len
  %_0 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  ret i64 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaqkWKWdl1xD_11int_ops_u64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !166 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[u8]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCsaqkWKWdl1xD_11int_ops_u64(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !167 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <core::result::Result<u64, core::num::error::ParseIntError>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyNtNtNtB4_3num5error13ParseIntErrorE5is_okCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !168 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_2 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb4:                                              ; No predecessors!
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !169 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %align, ptr align 8 %0) #25
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !170 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCsaqkWKWdl1xD_11int_ops_u64(i64 %align) unnamed_addr #0 !guid !171 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #21
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !172 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCsaqkWKWdl1xD_11int_ops_u64(i64 %_2) #21
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !173 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !174 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret i1 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !175 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %align) unnamed_addr #0 !guid !176 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #21
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #28
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !177 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret i1 %_0
}

; <char>::to_digit
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %self, i32 %radix) unnamed_addr #0 !guid !178 {
start:
  %value = alloca [4 x i8], align 4
  %_0 = alloca [8 x i8], align 4
  %_3 = icmp uge i32 %radix, 2
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_78b6a49e36fe808e0ef950c2feb9fafc, i64 71) #21
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 @alloc_6b38166963fe6da8fd2b01f68be063f4) #28
  unreachable

bb1:                                              ; preds = %start
  %_4 = icmp ule i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  %_8 = icmp ugt i32 %self, 57
  br i1 %_8, label %bb5, label %bb8

bb8:                                              ; preds = %bb5, %bb2
  %_0.i1 = sub i32 %self, 48
  store i32 %_0.i1, ptr %value, align 4
  br label %bb9

bb5:                                              ; preds = %bb2
  %_9 = icmp ugt i32 %radix, 10
  br i1 %_9, label %bb6, label %bb8

bb6:                                              ; preds = %bb5
  %_0.i = sub i32 %self, 65
  %_10 = and i32 %_0.i, -33
  %1 = add i32 %_10, 10
  store i32 %1, ptr %value, align 4
  br label %bb9

bb9:                                              ; preds = %bb6, %bb8
  %_17 = load i32, ptr %value, align 4
  %_16 = icmp ult i32 %_17, %radix
  br i1 %_16, label %bb10, label %bb11

bb11:                                             ; preds = %bb9
  store i32 0, ptr %_0, align 4
  br label %bb12

bb10:                                             ; preds = %bb9
  %_18 = load i32, ptr %value, align 4
  %2 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_18, ptr %2, align 4
  store i32 1, ptr %_0, align 4
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  %3 = load i32, ptr %_0, align 4
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = insertvalue { i32, i32 } poison, i32 %3, 0
  %7 = insertvalue { i32, i32 } %6, i32 %5, 1
  ret { i32, i32 } %7
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !179 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %_3) #21
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsaqkWKWdl1xD_11int_ops_u64(i64 %_2) #21
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !180 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_4, i64 %n) #21
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %_7) #21
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %alignment) unnamed_addr #0 !guid !181 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %align) unnamed_addr #0 !guid !182 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCsaqkWKWdl1xD_11int_ops_u64(i64 %align) #21
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !183 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %align, ptr align 8 %0) #25
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !184 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !185 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %_2) #21
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !186 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !187 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsaqkWKWdl1xD_11int_ops_u64(i64 %3, i64 %5, i1 zeroext %8) #21
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !188 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %2, i64 %4, i64 %6) #21
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsaqkWKWdl1xD_11int_ops_u64(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !189 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %_6, i64 0) #21
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsaqkWKWdl1xD_11int_ops_u64(i64 %11, i64 %13) #21
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsaqkWKWdl1xD_11int_ops_u64(i64 %15, i64 %17) #21
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCsaqkWKWdl1xD_11int_ops_u64(ptr %_12) #21
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECsaqkWKWdl1xD_11int_ops_u64(ptr %_11) #21
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCsaqkWKWdl1xD_11int_ops_u64(ptr %_10) #21
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #21
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %size) #21
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !190 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %3, i64 %5) #21
  br label %bb3
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !191 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !192 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 1) #21
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) unnamed_addr #0 !guid !193 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) #21
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCsaqkWKWdl1xD_11int_ops_u64(i32 %self) unnamed_addr #0 !guid !194 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsaqkWKWdl1xD_11int_ops_u64(i64 %addr) unnamed_addr #0 !guid !195 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <core::num::nonzero::NonZero<u64>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !196 {
start:
; call <core::num::nonzero::NonZero<u64>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getCsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<u64>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !197 {
start:
; call <core::num::nonzero::NonZero<u64>>::leading_zeros
  %_3 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE13leading_zerosCsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %pointer) unnamed_addr #0 !guid !198 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !199 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<u64>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionyEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !200 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<u64, core::num::error::ParseIntError>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultyNtNtNtB9_3num5error13ParseIntErrorEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !201 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !202 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr.0, ptr align 8 %0) #25
  br label %bb3
}

; <core::ptr::non_null::NonNull<(u64, bool)>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullTybEE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !203 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr %r) unnamed_addr #0 !guid !204 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !205 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %r) unnamed_addr #0 !guid !206 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !207 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, ptr align 8 %0) #25
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr) unnamed_addr #0 !guid !208 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr) #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #21
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<usize>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulljE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !209 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullmE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 4 %r) unnamed_addr #0 !guid !210 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE8from_refCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %r) unnamed_addr #0 !guid !211 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %val) unnamed_addr #0 !guid !212 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !213 {
start:
  ret i64 %self
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !214 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout) #21
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %_7) #21
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !215 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout) #21
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsaqkWKWdl1xD_11int_ops_u64(i64 %_8) #21
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout) #21
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsaqkWKWdl1xD_11int_ops_u64(i64 %_13) #21
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #25
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout) #21
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #21
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCsaqkWKWdl1xD_11int_ops_u64(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #21
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCsaqkWKWdl1xD_11int_ops_u64(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !216 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsaqkWKWdl1xD_11int_ops_u64(i64 %align) #21
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCsaqkWKWdl1xD_11int_ops_u64(i64 %_5) #21
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %_4) #21
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !217 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCsaqkWKWdl1xD_11int_ops_u64(i64 %_4) #21
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %len) unnamed_addr #0 !guid !218 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !219 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #21
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsaqkWKWdl1xD_11int_ops_u64(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #21
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(i64 %capacity) unnamed_addr #0 !guid !220 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(i64 %capacity, i64 1, i64 1) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !221 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %bits = ptrtoint ptr %_3 to i64
  %_5 = and i64 %bits, 1
  %_4 = icmp eq i64 %_5, 1
  br i1 %_4, label %bb1, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_10 = load ptr, ptr %self, align 8
  %_11 = lshr i64 %bits, 1
; call core::slice::raw::from_raw_parts::<u8>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partshECsaqkWKWdl1xD_11int_ops_u64(ptr %_10, i64 %_11, ptr align 8 @alloc_fa033a099f4a753e8c9d30a58dfdad40) #21
  %_7.0 = extractvalue { ptr, i64 } %1, 0
  %_7.1 = extractvalue { ptr, i64 } %1, 1
; call core::str::converts::from_utf8_unchecked
  %2 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %_7.0, i64 %_7.1) #21
  %_6.0 = extractvalue { ptr, i64 } %2, 0
  %_6.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_6.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %3, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb5
  %4 = load ptr, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { ptr, i64 } poison, ptr %4, 0
  %8 = insertvalue { ptr, i64 } %7, i64 %6, 1
  ret { ptr, i64 } %8
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !222 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsaqkWKWdl1xD_11int_ops_u64(ptr %s.0, i64 %s.1) #21
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) unnamed_addr #0 !guid !223 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %len) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #21
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !224 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #21
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsaqkWKWdl1xD_11int_ops_u64(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #21
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout) #21
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCsaqkWKWdl1xD_11int_ops_u64(ptr %alloc, i64 %12, i64 %14) #21
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsaqkWKWdl1xD_11int_ops_u64(ptr %alloc, i64 %19, i64 %21) #21
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsaqkWKWdl1xD_11int_ops_u64(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #21
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECsaqkWKWdl1xD_11int_ops_u64(ptr %ptr.0, i64 %ptr.1) #21
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr %_28) #21
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsaqkWKWdl1xD_11int_ops_u64(i64 %capacity) #21
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCsaqkWKWdl1xD_11int_ops_u64(i64 %_16) #21
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !225 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #23
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #21
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <u32>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %self, i32 %rhs) unnamed_addr #0 !guid !226 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %0 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %self, i32 %rhs)
  %_5.0.i = extractvalue { i32, i1 } %0, 0
  %_5.1.i = extractvalue { i32, i1 } %0, 1
  %_5.0 = extractvalue { i32, i1 } %0, 0
  %_5.1 = extractvalue { i32, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5.0, ptr %3, align 4
  store i32 1, ptr %_0, align 4
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i32 0, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i32, ptr %_0, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  %6 = load i32, ptr %5, align 4
  %7 = insertvalue { i32, i32 } poison, i32 %4, 0
  %8 = insertvalue { i32, i32 } %7, i32 %6, 1
  ret { i32, i32 } %8
}

; <u64>::strict_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy10strict_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp, ptr align 8 %0) unnamed_addr #0 !guid !227 {
start:
  %_3 = alloca [16 x i8], align 8
; call <u64>::checked_pow
  %1 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #21
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_4 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_4 to i1
  br i1 %7, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %a = load i64, ptr %8, align 8
  ret i64 %a

bb4:                                              ; preds = %start
; call core::num::imp::overflow_panic::pow
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8 %0) #23
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <u64>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !228 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_5.0 = add i64 %self, %rhs
  %_5.1 = icmp ult i64 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_div
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_divCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !229 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = udiv i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !230 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <u64>::checked_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %0) unnamed_addr #0 !guid !231 {
start:
  %_49 = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_30 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %_11 = alloca [8 x i8], align 4
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  %_6 = load i64, ptr %base, align 8
  %_5 = call i1 @llvm.is.constant.i64(i64 %_6)
  br i1 %_5, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_16 = load i32, ptr %exp, align 4
  %_15 = icmp eq i32 %_16, 0
  br i1 %_15, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %base, align 8
  %1 = call i64 @llvm.ctpop.i64(i64 %_8)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_10 = load i64, ptr %base, align 8
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_10, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #21
  %_12 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %k, i32 %_12) #21
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_11, align 4
  %5 = getelementptr inbounds i8, ptr %_11, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_11, align 4
  %7 = getelementptr inbounds i8, ptr %_11, i64 4
  %8 = load i32, ptr %7, align 4
  %_13 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_13 to i1
  br i1 %9, label %bb9, label %bb8

bb12:                                             ; preds = %bb10
  %_18 = load i32, ptr %exp, align 4
  %_17 = call i1 @llvm.is.constant.i32(i32 %_18)
  br i1 %_17, label %bb14, label %bb26

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb37

bb26:                                             ; preds = %bb36, %bb12
  %_39 = load i32, ptr %exp, align 4
  %_38 = and i32 %_39, 1
  %_37 = icmp eq i32 %_38, 1
  br i1 %_37, label %bb27, label %bb32

bb14:                                             ; preds = %bb24, %bb12
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp ugt i32 %_20, 1
  br i1 %_19, label %bb15, label %bb25

bb32:                                             ; preds = %bb30, %bb26
  %11 = load i32, ptr %exp, align 4
  %12 = udiv i32 %11, 2
  store i32 %12, ptr %exp, align 4
  %_50 = load i64, ptr %base, align 8
  %_51 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %13 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_50, i64 %_51) #21
  %14 = extractvalue { i64, i64 } %13, 0
  %15 = extractvalue { i64, i64 } %13, 1
  store i64 %14, ptr %_49, align 8
  %16 = getelementptr inbounds i8, ptr %_49, i64 8
  store i64 %15, ptr %16, align 8
  %_52 = load i64, ptr %_49, align 8
  %17 = getelementptr inbounds i8, ptr %_49, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = trunc nuw i64 %_52 to i1
  br i1 %19, label %bb36, label %bb35

bb27:                                             ; preds = %bb26
  %_41 = load i64, ptr %acc, align 8
  %_42 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %20 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_41, i64 %_42) #21
  %21 = extractvalue { i64, i64 } %20, 0
  %22 = extractvalue { i64, i64 } %20, 1
  store i64 %21, ptr %_40, align 8
  %23 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %22, ptr %23, align 8
  %_43 = load i64, ptr %_40, align 8
  %24 = getelementptr inbounds i8, ptr %_40, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = trunc nuw i64 %_43 to i1
  br i1 %26, label %bb30, label %bb29

bb30:                                             ; preds = %bb27
  %27 = getelementptr inbounds i8, ptr %_40, i64 8
  %x = load i64, ptr %27, align 8
  store i64 %x, ptr %acc, align 8
  %_46 = load i32, ptr %exp, align 4
  %_45 = icmp eq i32 %_46, 1
  br i1 %_45, label %bb31, label %bb32

bb29:                                             ; preds = %bb27
  store i64 0, ptr %_0, align 8
  br label %bb37

bb37:                                             ; preds = %bb9, %bb8, %bb11, %bb23, %bb18, %bb25, %bb31, %bb35, %bb29
  %28 = load i64, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { i64, i64 } poison, i64 %28, 0
  %32 = insertvalue { i64, i64 } %31, i64 %30, 1
  ret { i64, i64 } %32

bb31:                                             ; preds = %bb30
  %_47 = load i64, ptr %acc, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_47, ptr %33, align 8
  store i64 1, ptr %_0, align 8
  br label %bb37

bb36:                                             ; preds = %bb32
  %34 = getelementptr inbounds i8, ptr %_49, i64 8
  %x1 = load i64, ptr %34, align 8
  store i64 %x1, ptr %base, align 8
  br label %bb26

bb35:                                             ; preds = %bb32
  store i64 0, ptr %_0, align 8
  br label %bb37

bb25:                                             ; preds = %bb14
  %_35 = load i64, ptr %acc, align 8
  %_36 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %35 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_35, i64 %_36) #21
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_0, align 8
  %38 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %37, ptr %38, align 8
  br label %bb37

bb15:                                             ; preds = %bb14
  %_23 = load i32, ptr %exp, align 4
  %_22 = and i32 %_23, 1
  %_21 = icmp eq i32 %_22, 1
  br i1 %_21, label %bb16, label %bb20

bb20:                                             ; preds = %bb19, %bb15
  %39 = load i32, ptr %exp, align 4
  %40 = udiv i32 %39, 2
  store i32 %40, ptr %exp, align 4
  %_31 = load i64, ptr %base, align 8
  %_32 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %41 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_31, i64 %_32) #21
  %42 = extractvalue { i64, i64 } %41, 0
  %43 = extractvalue { i64, i64 } %41, 1
  store i64 %42, ptr %_30, align 8
  %44 = getelementptr inbounds i8, ptr %_30, i64 8
  store i64 %43, ptr %44, align 8
  %_33 = load i64, ptr %_30, align 8
  %45 = getelementptr inbounds i8, ptr %_30, i64 8
  %46 = load i64, ptr %45, align 8
  %47 = trunc nuw i64 %_33 to i1
  br i1 %47, label %bb24, label %bb23

bb16:                                             ; preds = %bb15
  %_25 = load i64, ptr %acc, align 8
  %_26 = load i64, ptr %base, align 8
; call <u64>::checked_mul
  %48 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_25, i64 %_26) #21
  %49 = extractvalue { i64, i64 } %48, 0
  %50 = extractvalue { i64, i64 } %48, 1
  store i64 %49, ptr %_24, align 8
  %51 = getelementptr inbounds i8, ptr %_24, i64 8
  store i64 %50, ptr %51, align 8
  %_27 = load i64, ptr %_24, align 8
  %52 = getelementptr inbounds i8, ptr %_24, i64 8
  %53 = load i64, ptr %52, align 8
  %54 = trunc nuw i64 %_27 to i1
  br i1 %54, label %bb19, label %bb18

bb19:                                             ; preds = %bb16
  %55 = getelementptr inbounds i8, ptr %_24, i64 8
  %x2 = load i64, ptr %55, align 8
  store i64 %x2, ptr %acc, align 8
  br label %bb20

bb18:                                             ; preds = %bb16
  store i64 0, ptr %_0, align 8
  br label %bb37

bb24:                                             ; preds = %bb20
  %56 = getelementptr inbounds i8, ptr %_30, i64 8
  %x3 = load i64, ptr %56, align 8
  store i64 %x3, ptr %base, align 8
  br label %bb14

bb23:                                             ; preds = %bb20
  store i64 0, ptr %_0, align 8
  br label %bb37

bb9:                                              ; preds = %bb4
  %57 = getelementptr inbounds i8, ptr %_11, i64 4
  %shift = load i32, ptr %57, align 4
; call <u64>::checked_shl
  %58 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_shlCsaqkWKWdl1xD_11int_ops_u64(i64 1, i32 %shift) #21
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_0, align 8
  %61 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %60, ptr %61, align 8
  br label %bb37

bb8:                                              ; preds = %bb4
  store i64 0, ptr %_0, align 8
  br label %bb37

bb7:                                              ; No predecessors!
  unreachable
}

; <u64>::checked_rem
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_remCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !232 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_5 = urem i64 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <u64>::checked_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_shlCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !233 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i32 %rhs, 64
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i64
  %_0.i = shl i64 %self, %0
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_0.i, ptr %1, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb3
  %2 = load i64, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = insertvalue { i64, i64 } poison, i64 %2, 0
  %6 = insertvalue { i64, i64 } %5, i64 %4, 1
  ret { i64, i64 } %6
}

; <u64>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_subCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !234 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <u64>::wrapping_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy12wrapping_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) unnamed_addr #0 !guid !235 {
start:
; call <u64>::overflowing_pow
  %0 = call { i64, i1 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy15overflowing_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #21
  %_3.0 = extractvalue { i64, i1 } %0, 0
  %_3.1 = extractvalue { i64, i1 } %0, 1
  ret i64 %_3.0
}

; <u64>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !236 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<u64>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newCsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<u64>>::ilog2
  %_5 = call i32 @_RNvMs11_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZeroyE5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %x) #21
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <u64>::unbounded_shl
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unbounded_shlCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %rhs) unnamed_addr #0 !guid !237 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp ult i32 %rhs, 64
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

bb2.i:                                            ; preds = %bb1
; call <u64>::unchecked_shl::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit: ; preds = %bb1, %bb2.i
  %0 = zext i32 %rhs to i64
  %_0.i = shl i64 %self, %0
  store i64 %_0.i, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl.exit, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <u64>::overflowing_pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i1 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy15overflowing_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %0) unnamed_addr #0 !guid !238 {
start:
  %_14 = alloca [8 x i8], align 4
  %tmp_overflow = alloca [1 x i8], align 1
  %overflow = alloca [1 x i8], align 1
  %acc = alloca [8 x i8], align 8
  %base = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %exp = alloca [4 x i8], align 4
  store i32 %0, ptr %exp, align 4
  store i64 %self, ptr %base, align 8
  store i64 1, ptr %acc, align 8
  store i8 0, ptr %overflow, align 1
  %_8 = load i64, ptr %base, align 8
  %_7 = call i1 @llvm.is.constant.i64(i64 %_8)
  br i1 %_7, label %bb2, label %bb10

bb10:                                             ; preds = %bb2, %start
  %_20 = load i32, ptr %exp, align 4
  %_19 = icmp eq i32 %_20, 0
  br i1 %_19, label %bb11, label %bb12

bb2:                                              ; preds = %start
  %_10 = load i64, ptr %base, align 8
  %1 = call i64 @llvm.ctpop.i64(i64 %_10)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb4, label %bb10

bb4:                                              ; preds = %bb2
  %_12 = load i64, ptr %base, align 8
; call <u64>::ilog2
  %k = call i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %_12, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #21
  %_15 = load i32, ptr %exp, align 4
; call <u32>::checked_mul
  %2 = call { i32, i32 } @_RNvMs6_NtCsl10jNU3mE6R_4core3numm11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i32 %k, i32 %_15) #21
  %3 = extractvalue { i32, i32 } %2, 0
  %4 = extractvalue { i32, i32 } %2, 1
  store i32 %3, ptr %_14, align 4
  %5 = getelementptr inbounds i8, ptr %_14, i64 4
  store i32 %4, ptr %5, align 4
  %6 = load i32, ptr %_14, align 4
  %7 = getelementptr inbounds i8, ptr %_14, i64 4
  %8 = load i32, ptr %7, align 4
  %_16 = zext i32 %6 to i64
  %9 = trunc nuw i64 %_16 to i1
  br i1 %9, label %bb7, label %bb8

bb12:                                             ; preds = %bb10
  %_22 = load i32, ptr %exp, align 4
  %_21 = call i1 @llvm.is.constant.i32(i32 %_22)
  br i1 %_21, label %bb14, label %bb23

bb11:                                             ; preds = %bb10
  store i128 1, ptr %_0, align 8
  br label %bb30

bb23:                                             ; preds = %bb27, %bb12
  %_51 = load i32, ptr %exp, align 4
  %_50 = and i32 %_51, 1
  %_49 = icmp eq i32 %_50, 1
  br i1 %_49, label %bb24, label %bb27

bb14:                                             ; preds = %bb18, %bb12
  %_24 = load i32, ptr %exp, align 4
  %_23 = icmp ugt i32 %_24, 1
  br i1 %_23, label %bb15, label %bb21

bb27:                                             ; preds = %bb24, %bb23
  %10 = load i32, ptr %exp, align 4
  %11 = udiv i32 %10, 2
  store i32 %11, ptr %exp, align 4
  %_66 = load i64, ptr %base, align 8
  %_67 = load i64, ptr %base, align 8
  %12 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_66, i64 %_67)
  %_5.0.i5 = extractvalue { i64, i1 } %12, 0
  %_5.1.i6 = extractvalue { i64, i1 } %12, 1
  %_65.0 = extractvalue { i64, i1 } %12, 0
  %_65.1 = extractvalue { i64, i1 } %12, 1
  store i64 %_65.0, ptr %base, align 8
  %13 = zext i1 %_65.1 to i8
  store i8 %13, ptr %tmp_overflow, align 1
  %14 = load i8, ptr %tmp_overflow, align 1
  %_68 = trunc nuw i8 %14 to i1
  %15 = load i8, ptr %overflow, align 1
  %16 = trunc nuw i8 %15 to i1
  %17 = or i1 %16, %_68
  %18 = zext i1 %17 to i8
  store i8 %18, ptr %overflow, align 1
  br label %bb23

bb24:                                             ; preds = %bb23
  %_55 = load i64, ptr %acc, align 8
  %_56 = load i64, ptr %base, align 8
  %19 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_55, i64 %_56)
  %_5.0.i7 = extractvalue { i64, i1 } %19, 0
  %_5.1.i8 = extractvalue { i64, i1 } %19, 1
  %_54.0 = extractvalue { i64, i1 } %19, 0
  %_54.1 = extractvalue { i64, i1 } %19, 1
  store i64 %_54.0, ptr %acc, align 8
  %20 = zext i1 %_54.1 to i8
  store i8 %20, ptr %tmp_overflow, align 1
  %21 = load i8, ptr %tmp_overflow, align 1
  %_57 = trunc nuw i8 %21 to i1
  %22 = load i8, ptr %overflow, align 1
  %23 = trunc nuw i8 %22 to i1
  %24 = or i1 %23, %_57
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %overflow, align 1
  %_59 = load i32, ptr %exp, align 4
  %_58 = icmp eq i32 %_59, 1
  br i1 %_58, label %bb26, label %bb27

bb26:                                             ; preds = %bb24
  %_60 = load i64, ptr %acc, align 8
  %26 = load i8, ptr %overflow, align 1
  %_61 = trunc nuw i8 %26 to i1
  store i64 %_60, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  %28 = zext i1 %_61 to i8
  store i8 %28, ptr %27, align 8
  br label %bb30

bb30:                                             ; preds = %bb8, %bb7, %bb11, %bb21, %bb26
  %29 = load i64, ptr %_0, align 8
  %30 = getelementptr inbounds i8, ptr %_0, i64 8
  %31 = load i8, ptr %30, align 8
  %32 = trunc nuw i8 %31 to i1
  %33 = insertvalue { i64, i1 } poison, i64 %29, 0
  %34 = insertvalue { i64, i1 } %33, i1 %32, 1
  ret { i64, i1 } %34

bb21:                                             ; preds = %bb14
  %_44 = load i64, ptr %acc, align 8
  %_45 = load i64, ptr %base, align 8
  %35 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_44, i64 %_45)
  %_5.0.i3 = extractvalue { i64, i1 } %35, 0
  %_5.1.i4 = extractvalue { i64, i1 } %35, 1
  %_43.0 = extractvalue { i64, i1 } %35, 0
  %_43.1 = extractvalue { i64, i1 } %35, 1
  store i64 %_43.0, ptr %acc, align 8
  %36 = zext i1 %_43.1 to i8
  store i8 %36, ptr %tmp_overflow, align 1
  %37 = load i8, ptr %tmp_overflow, align 1
  %_46 = trunc nuw i8 %37 to i1
  %38 = load i8, ptr %overflow, align 1
  %39 = trunc nuw i8 %38 to i1
  %40 = or i1 %39, %_46
  %41 = zext i1 %40 to i8
  store i8 %41, ptr %overflow, align 1
  %_47 = load i64, ptr %acc, align 8
  %42 = load i8, ptr %overflow, align 1
  %_48 = trunc nuw i8 %42 to i1
  store i64 %_47, ptr %_0, align 8
  %43 = getelementptr inbounds i8, ptr %_0, i64 8
  %44 = zext i1 %_48 to i8
  store i8 %44, ptr %43, align 8
  br label %bb30

bb15:                                             ; preds = %bb14
  %_27 = load i32, ptr %exp, align 4
  %_26 = and i32 %_27, 1
  %_25 = icmp eq i32 %_26, 1
  br i1 %_25, label %bb16, label %bb18

bb18:                                             ; preds = %bb16, %bb15
  %45 = load i32, ptr %exp, align 4
  %46 = udiv i32 %45, 2
  store i32 %46, ptr %exp, align 4
  %_38 = load i64, ptr %base, align 8
  %_39 = load i64, ptr %base, align 8
  %47 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_38, i64 %_39)
  %_5.0.i = extractvalue { i64, i1 } %47, 0
  %_5.1.i = extractvalue { i64, i1 } %47, 1
  %_37.0 = extractvalue { i64, i1 } %47, 0
  %_37.1 = extractvalue { i64, i1 } %47, 1
  store i64 %_37.0, ptr %base, align 8
  %48 = zext i1 %_37.1 to i8
  store i8 %48, ptr %tmp_overflow, align 1
  %49 = load i8, ptr %tmp_overflow, align 1
  %_40 = trunc nuw i8 %49 to i1
  %50 = load i8, ptr %overflow, align 1
  %51 = trunc nuw i8 %50 to i1
  %52 = or i1 %51, %_40
  %53 = zext i1 %52 to i8
  store i8 %53, ptr %overflow, align 1
  br label %bb14

bb16:                                             ; preds = %bb15
  %_31 = load i64, ptr %acc, align 8
  %_32 = load i64, ptr %base, align 8
  %54 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_31, i64 %_32)
  %_5.0.i1 = extractvalue { i64, i1 } %54, 0
  %_5.1.i2 = extractvalue { i64, i1 } %54, 1
  %_30.0 = extractvalue { i64, i1 } %54, 0
  %_30.1 = extractvalue { i64, i1 } %54, 1
  store i64 %_30.0, ptr %acc, align 8
  %55 = zext i1 %_30.1 to i8
  store i8 %55, ptr %tmp_overflow, align 1
  %56 = load i8, ptr %tmp_overflow, align 1
  %_33 = trunc nuw i8 %56 to i1
  %57 = load i8, ptr %overflow, align 1
  %58 = trunc nuw i8 %57 to i1
  %59 = or i1 %58, %_33
  %60 = zext i1 %59 to i8
  store i8 %60, ptr %overflow, align 1
  br label %bb18

bb7:                                              ; preds = %bb4
  %61 = getelementptr inbounds i8, ptr %_14, i64 4
  %shift = load i32, ptr %61, align 4
; call <u64>::unbounded_shl
  %_17 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unbounded_shlCsaqkWKWdl1xD_11int_ops_u64(i64 1, i32 %shift) #21
  %_18 = icmp uge i32 %shift, 64
  store i64 %_17, ptr %_0, align 8
  %62 = getelementptr inbounds i8, ptr %_0, i64 8
  %63 = zext i1 %_18 to i8
  store i8 %63, ptr %62, align 8
  br label %bb30

bb8:                                              ; preds = %bb4
  store i128 18446744073709551616, ptr %_0, align 8
  br label %bb30

bb31:                                             ; No predecessors!
  unreachable
}

; <u64>::pow
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy3powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) unnamed_addr #0 !guid !239 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <u64>::strict_pow
  %0 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy10strict_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #21
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb2:                                              ; No predecessors!
; call <u64>::wrapping_pow
  %1 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy12wrapping_powCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i32 %exp) #21
  store i64 %1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <u64>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !240 {
start:
  %_2 = alloca [8 x i8], align 4
; call <u64>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy13checked_ilog2CsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #23
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <u64>::isqrt
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy5isqrtCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !241 {
start:
; call core::num::imp::int_sqrt::u64
  %result = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsaqkWKWdl1xD_11int_ops_u64(i64 %self) #21
  %_3 = icmp ule i64 %result, 4294967295
; call core::ub_checks::check_language_ub
  %_2.i8 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i8, label %bb2.i9, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

bb2.i9:                                           ; preds = %start
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_3, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10: ; preds = %start, %bb2.i9
  %_5 = icmp uge i64 %self, 1
  br i1 %_5, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7, %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_3.i, label %bb2.i, label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

bb2.i:                                            ; preds = %bb4
; call <u64>::unchecked_mul::precondition_check
  call void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %result, i64 %result, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit

_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit: ; preds = %bb4, %bb2.i
  %_0.i = mul nuw i64 %result, %result
  %_8 = icmp ule i64 %_0.i, %self
; call core::ub_checks::check_language_ub
  %_2.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i2, label %bb2.i3, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

bb2.i3:                                           ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_8, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4: ; preds = %_RNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul.exit, %bb2.i3
  %_11 = icmp ule i64 %result, %self
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i, label %bb2.i1, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i1:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_11, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit4, %bb2.i1
  ret i64 %result

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit10
  %_6 = icmp uge i64 %result, 1
; call core::ub_checks::check_language_ub
  %_2.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i5, label %bb2.i6, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

bb2.i6:                                           ; preds = %bb3
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_6, ptr align 8 @alloc_ae2de464f9b6df44eca1585c04dc7532) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit7: ; preds = %bb3, %bb2.i6
  br label %bb4
}

; <u64>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %other) unnamed_addr #0 !guid !242 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsaqkWKWdl1xD_11int_ops_u64(i32 %_0.i) #21
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaqkWKWdl1xD_11int_ops_u64(ptr %self) unnamed_addr #0 !guid !243 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %rhs) unnamed_addr #0 !guid !244 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %self, i64 %other) unnamed_addr #0 !guid !245 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCsaqkWKWdl1xD_11int_ops_u64(i32 %_0.i) #21
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <u64>::from_str_radix
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !246 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %src.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %src.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <u64>::from_ascii_bytes_radix_impl
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy27from_ascii_bytes_radix_implCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %_3.0, i64 %_3.1, i32 %radix) #21
  ret void
}

; <u64>::from_ascii_bytes_radix_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy27from_ascii_bytes_radix_implCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 %radix) unnamed_addr #0 !guid !247 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_99 = alloca [16 x i8], align 8
  %_88 = alloca [8 x i8], align 4
  %mul1 = alloca [16 x i8], align 8
  %_74 = alloca [16 x i8], align 8
  %_63 = alloca [8 x i8], align 4
  %mul = alloca [16 x i8], align 8
  %_46 = alloca [8 x i8], align 4
  %_31 = alloca [8 x i8], align 4
  %result = alloca [8 x i8], align 8
  %rest = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %digits = alloca [16 x i8], align 8
  %_3 = icmp ugt i32 2, %radix
  br i1 %_3, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_4 = icmp ugt i32 %radix, 36
  br i1 %_4, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
; call core::num::from_ascii_bytes_radix_panic
  call void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32 %radix, ptr align 8 @alloc_5aa1d1250638a5285856df0c8e3018a3) #28
  unreachable

bb3:                                              ; preds = %bb1
; call <[u8]>::is_empty
  %_6 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSh8is_emptyCsaqkWKWdl1xD_11int_ops_u64(ptr %src.0, i64 %src.1) #21
  br i1 %_6, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %_14 = icmp eq i64 %src.1, 1
  br i1 %_14, label %bb8, label %bb7

bb5:                                              ; preds = %bb3
  %0 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %0, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb7:                                              ; preds = %bb8, %bb6
  %_16 = icmp uge i64 %src.1, 1
  br i1 %_16, label %bb10, label %bb9

bb8:                                              ; preds = %bb6
  %1 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %2 = load i8, ptr %1, align 1
  switch i8 %2, label %bb7 [
    i8 43, label %bb13
    i8 45, label %bb13
  ]

bb13:                                             ; preds = %bb8, %bb8
  %3 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %3, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb53:                                             ; preds = %bb5, %bb22, %bb52, %bb27, %bb39, %bb36, %bb34, %bb50, %bb47, %bb45, %bb13
  ret void

bb9:                                              ; preds = %bb11, %bb10, %bb7
  store i8 1, ptr %_12, align 8
  %4 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %src.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %src.1, ptr %5, align 8
  br label %bb15

bb10:                                             ; preds = %bb7
  %6 = getelementptr inbounds nuw i8, ptr %src.0, i64 0
  %7 = load i8, ptr %6, align 1
  switch i8 %7, label %bb9 [
    i8 43, label %bb12
    i8 45, label %bb11
  ]

bb12:                                             ; preds = %bb10
  %rest.0 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %rest.1 = sub i64 %src.1, 1
  store i8 1, ptr %_12, align 8
  %8 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %rest.0, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  store i64 %rest.1, ptr %9, align 8
  br label %bb15

bb11:                                             ; preds = %bb10
  %10 = getelementptr inbounds nuw i8, ptr %src.0, i64 1
  %11 = sub i64 %src.1, 1
  store ptr %10, ptr %rest, align 8
  %12 = getelementptr inbounds i8, ptr %rest, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb9

bb15:                                             ; preds = %bb9, %bb14, %bb12
  %13 = load i8, ptr %_12, align 8
  %is_positive = trunc nuw i8 %13 to i1
  %14 = getelementptr inbounds i8, ptr %_12, i64 8
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  store ptr %15, ptr %digits, align 8, !captures !248
  %18 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %17, ptr %18, align 8
  store i64 0, ptr %result, align 8
  %_24.0 = load ptr, ptr %digits, align 8
  %19 = getelementptr inbounds i8, ptr %digits, i64 8
  %_24.1 = load i64, ptr %19, align 8
  %_4.i = icmp ule i32 %radix, 16
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb15
  store i8 0, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit

bb1.i:                                            ; preds = %bb15
  %20 = icmp ule i64 %_24.1, 16
  %21 = zext i1 %20 to i8
  store i8 %21, ptr %_0.i, align 1
  br label %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit

_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit: ; preds = %bb2.i, %bb1.i
  %22 = load i8, ptr %_0.i, align 1
  %23 = trunc nuw i8 %22 to i1
  br i1 %23, label %bb17, label %bb29

bb14:                                             ; No predecessors!
  store i8 0, ptr %_12, align 8
  %24 = load ptr, ptr %rest, align 8
  %25 = getelementptr inbounds i8, ptr %rest, i64 8
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds i8, ptr %_12, i64 8
  store ptr %24, ptr %27, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i64 %26, ptr %28, align 8
  br label %bb15

bb29:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit
  br i1 %is_positive, label %bb30, label %bb41

bb17:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3num16can_not_overflowyECsaqkWKWdl1xD_11int_ops_u64.exit
  br i1 %is_positive, label %bb18, label %bb24

bb41:                                             ; preds = %bb51, %bb29
  %29 = load ptr, ptr %digits, align 8
  %30 = getelementptr inbounds i8, ptr %digits, i64 8
  %_80 = load i64, ptr %30, align 8
  %_81 = icmp uge i64 %_80, 1
  br i1 %_81, label %bb42, label %bb52

bb30:                                             ; preds = %bb40, %bb29
  %31 = load ptr, ptr %digits, align 8
  %32 = getelementptr inbounds i8, ptr %digits, i64 8
  %_55 = load i64, ptr %32, align 8
  %_56 = icmp uge i64 %_55, 1
  br i1 %_56, label %bb31, label %bb52

bb52:                                             ; preds = %bb18, %bb24, %bb30, %bb41
  %_105 = load i64, ptr %result, align 8
  %33 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_105, ptr %33, align 8
  store i8 0, ptr %_0, align 8
  br label %bb53

bb42:                                             ; preds = %bb41
  %34 = load ptr, ptr %digits, align 8
  %35 = getelementptr inbounds i8, ptr %digits, i64 8
  %36 = load i64, ptr %35, align 8
  %c = getelementptr inbounds nuw i8, ptr %34, i64 0
  %37 = load ptr, ptr %digits, align 8
  %38 = getelementptr inbounds i8, ptr %digits, i64 8
  %39 = load i64, ptr %38, align 8
  %rest.02 = getelementptr inbounds nuw i8, ptr %37, i64 1
  %rest.13 = sub i64 %39, 1
  %_85 = load i64, ptr %result, align 8
  %_86 = zext i32 %radix to i64
; call <u64>::checked_mul
  %40 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_85, i64 %_86) #21
  %41 = extractvalue { i64, i64 } %40, 0
  %42 = extractvalue { i64, i64 } %40, 1
  store i64 %41, ptr %mul1, align 8
  %43 = getelementptr inbounds i8, ptr %mul1, i64 8
  store i64 %42, ptr %43, align 8
  %_90 = load i8, ptr %c, align 1
  %_89 = zext i8 %_90 to i32
; call <char>::to_digit
  %44 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_89, i32 %radix) #21
  %45 = extractvalue { i32, i32 } %44, 0
  %46 = extractvalue { i32, i32 } %44, 1
  store i32 %45, ptr %_88, align 4
  %47 = getelementptr inbounds i8, ptr %_88, i64 4
  store i32 %46, ptr %47, align 4
  %48 = load i32, ptr %_88, align 4
  %49 = getelementptr inbounds i8, ptr %_88, i64 4
  %50 = load i32, ptr %49, align 4
  %_91 = zext i32 %48 to i64
  %51 = trunc nuw i64 %_91 to i1
  br i1 %51, label %bb46, label %bb45

bb46:                                             ; preds = %bb42
  %52 = getelementptr inbounds i8, ptr %_88, i64 4
  %value = load i32, ptr %52, align 4
  %x = zext i32 %value to i64
  %_95 = load i64, ptr %mul1, align 8
  %53 = getelementptr inbounds i8, ptr %mul1, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = trunc nuw i64 %_95 to i1
  br i1 %55, label %bb48, label %bb47

bb45:                                             ; preds = %bb42
  %56 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %56, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb48:                                             ; preds = %bb46
  %57 = getelementptr inbounds i8, ptr %mul1, i64 8
  %value4 = load i64, ptr %57, align 8
  store i64 %value4, ptr %result, align 8
  %_100 = load i64, ptr %result, align 8
; call <u64>::checked_sub
  %58 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_subCsaqkWKWdl1xD_11int_ops_u64(i64 %_100, i64 %x) #21
  %59 = extractvalue { i64, i64 } %58, 0
  %60 = extractvalue { i64, i64 } %58, 1
  store i64 %59, ptr %_99, align 8
  %61 = getelementptr inbounds i8, ptr %_99, i64 8
  store i64 %60, ptr %61, align 8
  %_101 = load i64, ptr %_99, align 8
  %62 = getelementptr inbounds i8, ptr %_99, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = trunc nuw i64 %_101 to i1
  br i1 %64, label %bb51, label %bb50

bb47:                                             ; preds = %bb46
  %65 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %65, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb51:                                             ; preds = %bb48
  %66 = getelementptr inbounds i8, ptr %_99, i64 8
  %value5 = load i64, ptr %66, align 8
  store i64 %value5, ptr %result, align 8
  store ptr %rest.02, ptr %digits, align 8, !captures !248
  %67 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.13, ptr %67, align 8
  br label %bb41

bb50:                                             ; preds = %bb48
  %68 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 3, ptr %68, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb31:                                             ; preds = %bb30
  %69 = load ptr, ptr %digits, align 8
  %70 = getelementptr inbounds i8, ptr %digits, i64 8
  %71 = load i64, ptr %70, align 8
  %c6 = getelementptr inbounds nuw i8, ptr %69, i64 0
  %72 = load ptr, ptr %digits, align 8
  %73 = getelementptr inbounds i8, ptr %digits, i64 8
  %74 = load i64, ptr %73, align 8
  %rest.07 = getelementptr inbounds nuw i8, ptr %72, i64 1
  %rest.18 = sub i64 %74, 1
  %_60 = load i64, ptr %result, align 8
  %_61 = zext i32 %radix to i64
; call <u64>::checked_mul
  %75 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %_60, i64 %_61) #21
  %76 = extractvalue { i64, i64 } %75, 0
  %77 = extractvalue { i64, i64 } %75, 1
  store i64 %76, ptr %mul, align 8
  %78 = getelementptr inbounds i8, ptr %mul, i64 8
  store i64 %77, ptr %78, align 8
  %_65 = load i8, ptr %c6, align 1
  %_64 = zext i8 %_65 to i32
; call <char>::to_digit
  %79 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_64, i32 %radix) #21
  %80 = extractvalue { i32, i32 } %79, 0
  %81 = extractvalue { i32, i32 } %79, 1
  store i32 %80, ptr %_63, align 4
  %82 = getelementptr inbounds i8, ptr %_63, i64 4
  store i32 %81, ptr %82, align 4
  %83 = load i32, ptr %_63, align 4
  %84 = getelementptr inbounds i8, ptr %_63, i64 4
  %85 = load i32, ptr %84, align 4
  %_66 = zext i32 %83 to i64
  %86 = trunc nuw i64 %_66 to i1
  br i1 %86, label %bb35, label %bb34

bb35:                                             ; preds = %bb31
  %87 = getelementptr inbounds i8, ptr %_63, i64 4
  %value9 = load i32, ptr %87, align 4
  %x10 = zext i32 %value9 to i64
  %_70 = load i64, ptr %mul, align 8
  %88 = getelementptr inbounds i8, ptr %mul, i64 8
  %89 = load i64, ptr %88, align 8
  %90 = trunc nuw i64 %_70 to i1
  br i1 %90, label %bb37, label %bb36

bb34:                                             ; preds = %bb31
  %91 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %91, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb37:                                             ; preds = %bb35
  %92 = getelementptr inbounds i8, ptr %mul, i64 8
  %value11 = load i64, ptr %92, align 8
  store i64 %value11, ptr %result, align 8
  %_75 = load i64, ptr %result, align 8
; call <u64>::checked_add
  %93 = call { i64, i64 } @_RNvMs7_NtCsl10jNU3mE6R_4core3numy11checked_addCsaqkWKWdl1xD_11int_ops_u64(i64 %_75, i64 %x10) #21
  %94 = extractvalue { i64, i64 } %93, 0
  %95 = extractvalue { i64, i64 } %93, 1
  store i64 %94, ptr %_74, align 8
  %96 = getelementptr inbounds i8, ptr %_74, i64 8
  store i64 %95, ptr %96, align 8
  %_76 = load i64, ptr %_74, align 8
  %97 = getelementptr inbounds i8, ptr %_74, i64 8
  %98 = load i64, ptr %97, align 8
  %99 = trunc nuw i64 %_76 to i1
  br i1 %99, label %bb40, label %bb39

bb36:                                             ; preds = %bb35
  %100 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %100, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb40:                                             ; preds = %bb37
  %101 = getelementptr inbounds i8, ptr %_74, i64 8
  %value12 = load i64, ptr %101, align 8
  store i64 %value12, ptr %result, align 8
  store ptr %rest.07, ptr %digits, align 8, !captures !248
  %102 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.18, ptr %102, align 8
  br label %bb30

bb39:                                             ; preds = %bb37
  %103 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 2, ptr %103, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb24:                                             ; preds = %bb28, %bb17
  %104 = load ptr, ptr %digits, align 8
  %105 = getelementptr inbounds i8, ptr %digits, i64 8
  %_40 = load i64, ptr %105, align 8
  %_41 = icmp uge i64 %_40, 1
  br i1 %_41, label %bb25, label %bb52

bb18:                                             ; preds = %bb23, %bb17
  %106 = load ptr, ptr %digits, align 8
  %107 = getelementptr inbounds i8, ptr %digits, i64 8
  %_25 = load i64, ptr %107, align 8
  %_26 = icmp uge i64 %_25, 1
  br i1 %_26, label %bb19, label %bb52

bb25:                                             ; preds = %bb24
  %108 = load ptr, ptr %digits, align 8
  %109 = getelementptr inbounds i8, ptr %digits, i64 8
  %110 = load i64, ptr %109, align 8
  %c13 = getelementptr inbounds nuw i8, ptr %108, i64 0
  %111 = load ptr, ptr %digits, align 8
  %112 = getelementptr inbounds i8, ptr %digits, i64 8
  %113 = load i64, ptr %112, align 8
  %rest.014 = getelementptr inbounds nuw i8, ptr %111, i64 1
  %rest.115 = sub i64 %113, 1
  %_44 = load i64, ptr %result, align 8
  %_45 = zext i32 %radix to i64
  %114 = mul i64 %_44, %_45
  store i64 %114, ptr %result, align 8
  %_48 = load i8, ptr %c13, align 1
  %_47 = zext i8 %_48 to i32
; call <char>::to_digit
  %115 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_47, i32 %radix) #21
  %116 = extractvalue { i32, i32 } %115, 0
  %117 = extractvalue { i32, i32 } %115, 1
  store i32 %116, ptr %_46, align 4
  %118 = getelementptr inbounds i8, ptr %_46, i64 4
  store i32 %117, ptr %118, align 4
  %119 = load i32, ptr %_46, align 4
  %120 = getelementptr inbounds i8, ptr %_46, i64 4
  %121 = load i32, ptr %120, align 4
  %_49 = zext i32 %119 to i64
  %122 = trunc nuw i64 %_49 to i1
  br i1 %122, label %bb28, label %bb27

bb28:                                             ; preds = %bb25
  %123 = getelementptr inbounds i8, ptr %_46, i64 4
  %x16 = load i32, ptr %123, align 4
  %_53 = load i64, ptr %result, align 8
  %_54 = zext i32 %x16 to i64
  %124 = sub i64 %_53, %_54
  store i64 %124, ptr %result, align 8
  store ptr %rest.014, ptr %digits, align 8, !captures !248
  %125 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.115, ptr %125, align 8
  br label %bb24

bb27:                                             ; preds = %bb25
  %126 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %126, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb19:                                             ; preds = %bb18
  %127 = load ptr, ptr %digits, align 8
  %128 = getelementptr inbounds i8, ptr %digits, i64 8
  %129 = load i64, ptr %128, align 8
  %c17 = getelementptr inbounds nuw i8, ptr %127, i64 0
  %130 = load ptr, ptr %digits, align 8
  %131 = getelementptr inbounds i8, ptr %digits, i64 8
  %132 = load i64, ptr %131, align 8
  %rest.018 = getelementptr inbounds nuw i8, ptr %130, i64 1
  %rest.119 = sub i64 %132, 1
  %_29 = load i64, ptr %result, align 8
  %_30 = zext i32 %radix to i64
  %133 = mul i64 %_29, %_30
  store i64 %133, ptr %result, align 8
  %_33 = load i8, ptr %c17, align 1
  %_32 = zext i8 %_33 to i32
; call <char>::to_digit
  %134 = call { i32, i32 } @_RNvMNtNtCsl10jNU3mE6R_4core4char7methodsc8to_digitCsaqkWKWdl1xD_11int_ops_u64(i32 %_32, i32 %radix) #21
  %135 = extractvalue { i32, i32 } %134, 0
  %136 = extractvalue { i32, i32 } %134, 1
  store i32 %135, ptr %_31, align 4
  %137 = getelementptr inbounds i8, ptr %_31, i64 4
  store i32 %136, ptr %137, align 4
  %138 = load i32, ptr %_31, align 4
  %139 = getelementptr inbounds i8, ptr %_31, i64 4
  %140 = load i32, ptr %139, align 4
  %_34 = zext i32 %138 to i64
  %141 = trunc nuw i64 %_34 to i1
  br i1 %141, label %bb23, label %bb22

bb23:                                             ; preds = %bb19
  %142 = getelementptr inbounds i8, ptr %_31, i64 4
  %x20 = load i32, ptr %142, align 4
  %_38 = load i64, ptr %result, align 8
  %_39 = zext i32 %x20 to i64
  %143 = add i64 %_38, %_39
  store i64 %143, ptr %result, align 8
  store ptr %rest.018, ptr %digits, align 8, !captures !248
  %144 = getelementptr inbounds i8, ptr %digits, i64 8
  store i64 %rest.119, ptr %144, align 8
  br label %bb18

bb22:                                             ; preds = %bb19
  %145 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 1, ptr %145, align 1
  store i8 1, ptr %_0, align 8
  br label %bb53

bb21:                                             ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !249 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCsaqkWKWdl1xD_11int_ops_u64(i64 %capacity) #21
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CsaqkWKWdl1xD_11int_ops_u64(i8 %0) unnamed_addr #0 !guid !250 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !251 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE3lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !252 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %0, align 8
  %_2 = icmp ule i64 %len, 9223372036854775807
  ret i64 %len
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !253 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #25
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #0 !guid !254 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  ret i64 %_0
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %len) unnamed_addr #0 !guid !255 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !256 {
start:
  ret i64 %self
}

; <core::num::nonzero::NonZero<u64>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3getCsaqkWKWdl1xD_11int_ops_u64(i64 %self) unnamed_addr #0 !guid !257 {
start:
  ret i64 %self
}

; <core::num::nonzero::NonZero<u64>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZeroyE3newCsaqkWKWdl1xD_11int_ops_u64(i64 %n) unnamed_addr #0 !guid !258 {
start:
  ret i64 %n
}

; alloc::fmt::format
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc3fmt6formatCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !259 {
start:
  %args = alloca [16 x i8], align 8
  store ptr %0, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %1, ptr %2, align 8
; call <core::fmt::Arguments>::as_str
  %3 = call { ptr, i64 } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments6as_strCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %args) #21
  %_2.0 = extractvalue { ptr, i64 } %3, 0
  %_2.1 = extractvalue { ptr, i64 } %3, 1
; call <core::option::Option<&str>>::map_or_else::<alloc::string::String, alloc::fmt::format::{closure#0}, <str as alloc::borrow::ToOwned>::to_owned>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionReE11map_or_elseNtNtCs7CppTae75M1_5alloc6string6StringNCNvNtB12_3fmt6format0NvYeNtNtB12_6borrow7ToOwned8to_ownedECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %_2.0, i64 %_2.1, ptr align 8 %args) #21
  ret void
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsaqkWKWdl1xD_11int_ops_u64(i64 %0, i64 %1) unnamed_addr #0 !guid !260 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #27
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #27
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !261 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #27
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsaqkWKWdl1xD_11int_ops_u64(i64 %0, i64 %1) unnamed_addr #0 !guid !262 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #27
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %layout) #21
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #27
  ret ptr %_0
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !263 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %elem_layout, i64 %cap) #21
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #21
  ret void
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #4 !guid !264 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align) unnamed_addr #0 !guid !265 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !266 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !267 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %3, ptr %5, i64 %7, i64 %9) #21
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %len) unnamed_addr #0 !guid !268 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #28
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !269 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align) #21
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr) #21
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !270 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; core::num::imp::int_sqrt::u16_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsaqkWKWdl1xD_11int_ops_u64(i16 %n) unnamed_addr #0 !guid !271 {
start:
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n1 = lshr i16 %n, 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_9 = zext i16 %n1 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s2 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s2, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb1, %bb2.i
  %lo = and i16 %n, 255
  %_16 = zext i8 %r to i16
  %_15 = shl i16 %_16, 4
  %_17 = lshr i16 %lo, 4
  %numerator = or i16 %_15, %_17
  %_19 = zext i8 %s2 to i16
  %denominator = shl i16 %_19, 1
  %_21 = icmp eq i16 %denominator, 0
  br i1 %_21, label %panic3, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_dd07830ff498a5ad3af27fc9310868e8) #28
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q = udiv i16 %numerator, %denominator
  %_24 = shl i8 %s2, 4
  %_23 = zext i8 %_24 to i16
  %3 = add i16 %_23, %q
  store i16 %3, ptr %s, align 2
  %_28 = load i16, ptr %s, align 2
  %_29 = load i16, ptr %s, align 2
  %4 = call { i16, i1 } @llvm.umul.with.overflow.i16(i16 %_28, i16 %_29)
  %_5.0.i = extractvalue { i16, i1 } %4, 0
  %_5.1.i = extractvalue { i16, i1 } %4, 1
  %_27.0 = extractvalue { i16, i1 } %4, 0
  %_27.1 = extractvalue { i16, i1 } %4, 1
  br i1 %_27.1, label %bb6, label %bb5

panic3:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_73a63def61abd19c5b285b7e5bba6f74) #28
  unreachable

bb5:                                              ; preds = %bb3
  %_30 = icmp ugt i16 %_27.0, %n
  br i1 %_30, label %bb6, label %bb7

bb6:                                              ; preds = %bb5, %bb3
  %5 = load i16, ptr %s, align 2
  %6 = sub i16 %5, 1
  store i16 %6, ptr %s, align 2
  br label %bb7

bb7:                                              ; preds = %bb6, %bb5
  %_0 = load i16, ptr %s, align 2
  ret i16 %_0
}

; core::num::imp::int_sqrt::u32_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsaqkWKWdl1xD_11int_ops_u64(i32 %n) unnamed_addr #0 !guid !272 {
start:
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n2 = lshr i32 %n, 24
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_9 = zext i32 %n2 to i64
  %_10 = icmp ult i64 %_9, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %s3 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %_9
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r4 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s3, 0
; call core::ub_checks::check_language_ub
  %_2.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i15, label %bb2.i16, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

bb2.i16:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17: ; preds = %bb1, %bb2.i16
  %_17 = lshr i32 %n, 16
  %n5 = trunc i32 %_17 to i16
  %lo = and i16 %n5, 255
  %_21 = zext i8 %r4 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s3 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic6, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_9, i64 256, ptr align 8 @alloc_c9c619c258f652778f0098fbdacd3593) #28
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic7, label %bb4

panic6:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit17
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #28
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s3, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic7:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #28
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_45, ptr align 8 @alloc_debe392282102e1a17f340d9b53f07df) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb8, %bb2.i
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %lo8 = and i32 %n, 65535
  %_52 = zext i16 %_48 to i32
  %_51 = shl i32 %_52, 8
  %_53 = lshr i32 %lo8, 8
  %numerator9 = or i32 %_51, %_53
  %_55 = zext i16 %_47 to i32
  %denominator10 = shl i32 %_55, 1
  %_57 = icmp eq i32 %denominator10, 0
  br i1 %_57, label %panic11, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q12 = udiv i32 %numerator9, %denominator10
  %_60 = shl i16 %_47, 8
  %_59 = zext i16 %_60 to i32
  %8 = add i32 %_59, %q12
  store i32 %8, ptr %s1, align 4
  %_64 = load i32, ptr %s1, align 4
  %_65 = load i32, ptr %s1, align 4
  %9 = call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_64, i32 %_65)
  %_5.0.i13 = extractvalue { i32, i1 } %9, 0
  %_5.1.i14 = extractvalue { i32, i1 } %9, 1
  %_63.0 = extractvalue { i32, i1 } %9, 0
  %_63.1 = extractvalue { i32, i1 } %9, 1
  br i1 %_63.1, label %bb13, label %bb12

panic11:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_d1e64d3a180065bd6a022925cad00717) #28
  unreachable

bb12:                                             ; preds = %bb10
  %_66 = icmp ugt i32 %_63.0, %n
  br i1 %_66, label %bb13, label %bb14

bb13:                                             ; preds = %bb12, %bb10
  %10 = load i32, ptr %s1, align 4
  %11 = sub i32 %10, 1
  store i32 %11, ptr %s1, align 4
  br label %bb14

bb14:                                             ; preds = %bb13, %bb12
  %_0 = load i32, ptr %s1, align 4
  ret i32 %_0
}

; core::num::imp::int_sqrt::u64_stages
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsaqkWKWdl1xD_11int_ops_u64(i64 %n) unnamed_addr #0 !guid !273 {
start:
  %s3 = alloca [8 x i8], align 8
  %r2 = alloca [4 x i8], align 4
  %s1 = alloca [4 x i8], align 4
  %r = alloca [2 x i8], align 2
  %s = alloca [2 x i8], align 2
  %_8 = alloca [512 x i8], align 1
  %n4 = lshr i64 %n, 56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_8, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_10 = icmp ult i64 %n4, 256
  br i1 %_10, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %s5 = load i8, ptr %0, align 1
  %1 = getelementptr inbounds nuw { i8, i8 }, ptr %_8, i64 %n4
  %2 = getelementptr inbounds i8, ptr %1, i64 1
  %r6 = load i8, ptr %2, align 1
  %_12 = icmp ne i8 %s5, 0
; call core::ub_checks::check_language_ub
  %_2.i31 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i31, label %bb2.i32, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

bb2.i32:                                          ; preds = %bb1
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_12, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33: ; preds = %bb1, %bb2.i32
  %_17 = lshr i64 %n, 48
  %n7 = trunc i64 %_17 to i16
  %lo = and i16 %n7, 255
  %_21 = zext i8 %r6 to i16
  %_20 = shl i16 %_21, 4
  %_22 = lshr i16 %lo, 4
  %numerator = or i16 %_20, %_22
  %_24 = zext i8 %s5 to i16
  %denominator = shl i16 %_24, 1
  %_26 = icmp eq i16 %denominator, 0
  br i1 %_26, label %panic8, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %n4, i64 256, ptr align 8 @alloc_9a4d1999757609695fb8537fcdec871b) #28
  unreachable

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
  %q = udiv i16 %numerator, %denominator
  %_28 = icmp eq i16 %denominator, 0
  br i1 %_28, label %panic9, label %bb4

panic8:                                           ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit33
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #28
  unreachable

bb4:                                              ; preds = %bb3
  %u = urem i16 %numerator, %denominator
  %_31 = shl i8 %s5, 4
  %_30 = zext i8 %_31 to i16
  %3 = add i16 %_30, %q
  store i16 %3, ptr %s, align 2
  %_36 = shl i16 %u, 4
  %_37 = and i16 %lo, 15
  %_35 = or i16 %_36, %_37
  %_38 = mul i16 %q, %q
  %_5.0.i = sub i16 %_35, %_38
  %_5.1.i = icmp ult i16 %_35, %_38
  %4 = insertvalue { i16, i1 } poison, i16 %_5.0.i, 0
  %5 = insertvalue { i16, i1 } %4, i1 %_5.1.i, 1
  %_34.0 = extractvalue { i16, i1 } %5, 0
  %_34.1 = extractvalue { i16, i1 } %5, 1
  store i16 %_34.0, ptr %r, align 2
  br i1 %_34.1, label %bb6, label %bb8

panic9:                                           ; preds = %bb3
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #28
  unreachable

bb8:                                              ; preds = %bb6, %bb4
  %_46 = load i16, ptr %s, align 2
  %_45 = icmp ne i16 %_46, 0
; call core::ub_checks::check_language_ub
  %_2.i28 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i28, label %bb2.i29, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

bb2.i29:                                          ; preds = %bb8
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_45, ptr align 8 @alloc_ffea377e021bf2f87b4ad4aac9bcd041) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30: ; preds = %bb8, %bb2.i29
  %_47 = load i16, ptr %s, align 2
  %_48 = load i16, ptr %r, align 2
  %_53 = lshr i64 %n, 32
  %n10 = trunc i64 %_53 to i32
  %lo11 = and i32 %n10, 65535
  %_57 = zext i16 %_48 to i32
  %_56 = shl i32 %_57, 8
  %_58 = lshr i32 %lo11, 8
  %numerator12 = or i32 %_56, %_58
  %_60 = zext i16 %_47 to i32
  %denominator13 = shl i32 %_60, 1
  %_62 = icmp eq i32 %denominator13, 0
  br i1 %_62, label %panic14, label %bb10

bb6:                                              ; preds = %bb4
  %_40 = load i16, ptr %r, align 2
  %_43 = load i16, ptr %s, align 2
  %_42 = mul i16 2, %_43
  %_41 = sub i16 %_42, 1
  %_0.i = add i16 %_40, %_41
  store i16 %_0.i, ptr %r, align 2
  %6 = load i16, ptr %s, align 2
  %7 = sub i16 %6, 1
  store i16 %7, ptr %s, align 2
  br label %bb8

bb10:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
  %q15 = udiv i32 %numerator12, %denominator13
  %_64 = icmp eq i32 %denominator13, 0
  br i1 %_64, label %panic16, label %bb11

panic14:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit30
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #28
  unreachable

bb11:                                             ; preds = %bb10
  %u17 = urem i32 %numerator12, %denominator13
  %_67 = shl i16 %_47, 8
  %_66 = zext i16 %_67 to i32
  %8 = add i32 %_66, %q15
  store i32 %8, ptr %s1, align 4
  %_72 = shl i32 %u17, 8
  %_73 = and i32 %lo11, 255
  %_71 = or i32 %_72, %_73
  %_74 = mul i32 %q15, %q15
  %_5.0.i24 = sub i32 %_71, %_74
  %_5.1.i25 = icmp ult i32 %_71, %_74
  %9 = insertvalue { i32, i1 } poison, i32 %_5.0.i24, 0
  %10 = insertvalue { i32, i1 } %9, i1 %_5.1.i25, 1
  %_70.0 = extractvalue { i32, i1 } %10, 0
  %_70.1 = extractvalue { i32, i1 } %10, 1
  store i32 %_70.0, ptr %r2, align 4
  br i1 %_70.1, label %bb13, label %bb15

panic16:                                          ; preds = %bb10
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #28
  unreachable

bb15:                                             ; preds = %bb13, %bb11
  %_82 = load i32, ptr %s1, align 4
  %_81 = icmp ne i32 %_82, 0
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsaqkWKWdl1xD_11int_ops_u64() #21
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb15
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %_81, ptr align 8 @alloc_3410a5a3f8bc9abd6709ddad50da91f7) #25
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb15, %bb2.i
  %_83 = load i32, ptr %s1, align 4
  %_84 = load i32, ptr %r2, align 4
  %lo18 = and i64 %n, 4294967295
  %_88 = zext i32 %_84 to i64
  %_87 = shl i64 %_88, 16
  %_89 = lshr i64 %lo18, 16
  %numerator19 = or i64 %_87, %_89
  %_91 = zext i32 %_83 to i64
  %denominator20 = shl i64 %_91, 1
  %_93 = icmp eq i64 %denominator20, 0
  br i1 %_93, label %panic21, label %bb17

bb13:                                             ; preds = %bb11
  %_76 = load i32, ptr %r2, align 4
  %_79 = load i32, ptr %s1, align 4
  %_78 = mul i32 2, %_79
  %_77 = sub i32 %_78, 1
  %_0.i23 = add i32 %_76, %_77
  store i32 %_0.i23, ptr %r2, align 4
  %11 = load i32, ptr %s1, align 4
  %12 = sub i32 %11, 1
  store i32 %12, ptr %s1, align 4
  br label %bb15

bb17:                                             ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %q22 = udiv i64 %numerator19, %denominator20
  %_96 = shl i32 %_83, 16
  %_95 = zext i32 %_96 to i64
  %13 = add i64 %_95, %q22
  store i64 %13, ptr %s3, align 8
  %_100 = load i64, ptr %s3, align 8
  %_101 = load i64, ptr %s3, align 8
  %14 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %_100, i64 %_101)
  %_5.0.i26 = extractvalue { i64, i1 } %14, 0
  %_5.1.i27 = extractvalue { i64, i1 } %14, 1
  %_99.0 = extractvalue { i64, i1 } %14, 0
  %_99.1 = extractvalue { i64, i1 } %14, 1
  br i1 %_99.1, label %bb20, label %bb19

panic21:                                          ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_cb646754bd05cd238e749888201337e6) #28
  unreachable

bb19:                                             ; preds = %bb17
  %_102 = icmp ugt i64 %_99.0, %n
  br i1 %_102, label %bb20, label %bb21

bb20:                                             ; preds = %bb19, %bb17
  %15 = load i64, ptr %s3, align 8
  %16 = sub i64 %15, 1
  store i64 %16, ptr %s3, align 8
  br label %bb21

bb21:                                             ; preds = %bb20, %bb19
  %_0 = load i64, ptr %s3, align 8
  ret i64 %_0
}

; core::num::imp::int_sqrt::u8
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsaqkWKWdl1xD_11int_ops_u64(i8 %n) unnamed_addr #0 !guid !274 {
start:
  %_2 = alloca [512 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_2, ptr align 1 @anon.3163d8aaa3ec962f62b1dd64a9184856.0, i64 512, i1 false)
  %_3 = zext i8 %n to i64
  %_4 = icmp ult i64 %_3, 256
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw { i8, i8 }, ptr %_2, i64 %_3
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_3, i64 256, ptr align 8 @alloc_c4e65bfc79cb636ae13d26c91b325bd6) #28
  unreachable
}

; core::num::imp::int_sqrt::u16
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsaqkWKWdl1xD_11int_ops_u64(i16 %0) unnamed_addr #0 !guid !275 {
start:
  %_0 = alloca [2 x i8], align 2
  %n = alloca [2 x i8], align 2
  store i16 %0, ptr %n, align 2
  %_3 = load i16, ptr %n, align 2
  %_2 = icmp ule i16 %_3, 255
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i16, ptr %n, align 2
  %1 = call i16 @llvm.ctlz.i16(i16 %_10, i1 false)
  %_0.i = zext i16 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i16, ptr %n, align 2
  %3 = and i32 %normalization_shift, 15
  %4 = trunc i32 %3 to i16
  %5 = shl i16 %2, %4
  store i16 %5, ptr %n, align 2
  %_12 = load i16, ptr %n, align 2
; call core::num::imp::int_sqrt::u16_stages
  %s = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u16_stagesCsaqkWKWdl1xD_11int_ops_u64(i16 %_12) #21
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 15
  %7 = trunc i32 %6 to i16
  %8 = lshr i16 %s, %7
  store i16 %8, ptr %_0, align 2
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i16, ptr %n, align 2
  %_6 = trunc i16 %_7 to i8
; call core::num::imp::int_sqrt::u8
  %_5 = call i8 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt2u8CsaqkWKWdl1xD_11int_ops_u64(i8 %_6) #21
  %9 = zext i8 %_5 to i16
  store i16 %9, ptr %_0, align 2
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i16, ptr %_0, align 2
  ret i16 %10
}

; core::num::imp::int_sqrt::u32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsaqkWKWdl1xD_11int_ops_u64(i32 %0) unnamed_addr #0 !guid !276 {
start:
  %_0 = alloca [4 x i8], align 4
  %n = alloca [4 x i8], align 4
  store i32 %0, ptr %n, align 4
  %_3 = load i32, ptr %n, align 4
  %_2 = icmp ule i32 %_3, 65535
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i32, ptr %n, align 4
  %_0.i = call i32 @llvm.ctlz.i32(i32 %_10, i1 false)
  %normalization_shift = and i32 %_0.i, -2
  %1 = load i32, ptr %n, align 4
  %2 = and i32 %normalization_shift, 31
  %3 = shl i32 %1, %2
  store i32 %3, ptr %n, align 4
  %_12 = load i32, ptr %n, align 4
; call core::num::imp::int_sqrt::u32_stages
  %s = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u32_stagesCsaqkWKWdl1xD_11int_ops_u64(i32 %_12) #21
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %4 = and i32 %denormalization_shift, 31
  %5 = lshr i32 %s, %4
  store i32 %5, ptr %_0, align 4
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i32, ptr %n, align 4
  %_6 = trunc i32 %_7 to i16
; call core::num::imp::int_sqrt::u16
  %_5 = call i16 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u16CsaqkWKWdl1xD_11int_ops_u64(i16 %_6) #21
  %6 = zext i16 %_5 to i32
  store i32 %6, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %7 = load i32, ptr %_0, align 4
  ret i32 %7
}

; core::num::imp::int_sqrt::u64
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u64CsaqkWKWdl1xD_11int_ops_u64(i64 %0) unnamed_addr #0 !guid !277 {
start:
  %_0 = alloca [8 x i8], align 8
  %n = alloca [8 x i8], align 8
  store i64 %0, ptr %n, align 8
  %_3 = load i64, ptr %n, align 8
  %_2 = icmp ule i64 %_3, 4294967295
  br i1 %_2, label %bb1, label %bb3

bb3:                                              ; preds = %start
  %_10 = load i64, ptr %n, align 8
  %1 = call i64 @llvm.ctlz.i64(i64 %_10, i1 false)
  %_0.i = trunc i64 %1 to i32
  %normalization_shift = and i32 %_0.i, -2
  %2 = load i64, ptr %n, align 8
  %3 = and i32 %normalization_shift, 63
  %4 = zext i32 %3 to i64
  %5 = shl i64 %2, %4
  store i64 %5, ptr %n, align 8
  %_12 = load i64, ptr %n, align 8
; call core::num::imp::int_sqrt::u64_stages
  %s = call i64 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt10u64_stagesCsaqkWKWdl1xD_11int_ops_u64(i64 %_12) #21
  %denormalization_shift = lshr i32 %normalization_shift, 1
  %6 = and i32 %denormalization_shift, 63
  %7 = zext i32 %6 to i64
  %8 = lshr i64 %s, %7
  store i64 %8, ptr %_0, align 8
  br label %bb6

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %n, align 8
  %_6 = trunc i64 %_7 to i32
; call core::num::imp::int_sqrt::u32
  %_5 = call i32 @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp8int_sqrt3u32CsaqkWKWdl1xD_11int_ops_u64(i32 %_6) #21
  %9 = zext i32 %_5 to i64
  store i64 %9, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb3
  %10 = load i64, ptr %_0, align 8
  ret i64 %10
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %align, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !278 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr) unnamed_addr #0 !guid !279 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !280 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !281 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <u64>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !282 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_c856595eac66a24654d670eae8c59bb6, i64 184)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <u64>::unchecked_shl::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shl18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !283 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_f4be92229193d4464753072989252627, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <u64>::unchecked_shr::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs7_NtCsl10jNU3mE6R_4core3numy13unchecked_shr18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i32 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !284 {
start:
  %_2 = icmp ult i32 %rhs, 64
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_10473b11a7e05bbd7ed679b01f6c847b, i64 184)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %1, 0
  %_4.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !285 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !286 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !287 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCsaqkWKWdl1xD_11int_ops_u64(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !288 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align) unnamed_addr #0 !guid !289 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCsaqkWKWdl1xD_11int_ops_u64(ptr %ptr, i64 %align) #21
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !290 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCsaqkWKWdl1xD_11int_ops_u64(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !291 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %count) #21
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCsaqkWKWdl1xD_11int_ops_u64(i64 %_0.i2, i64 %_0.i) #21
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #29
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #5 personality ptr @rust_eh_personality !guid !292 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCsaqkWKWdl1xD_11int_ops_u64(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCsaqkWKWdl1xD_11int_ops_u64(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !293 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <(u64, bool) as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1G_NtCsl10jNU3mE6R_4core3fmtTybENtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !294 {
start:
  %T = alloca [8 x i8], align 8
  %U = alloca [8 x i8], align 8
  %builder = alloca [24 x i8], align 8
; call <core::fmt::Formatter>::debug_tuple
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8 %builder, ptr align 8 %f, ptr inttoptr (i64 1 to ptr), i64 0)
  store ptr %self, ptr %U, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %0, ptr %T, align 8
; call <core::fmt::builders::DebugTuple>::field
  %_7 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %U, ptr align 8 @vtable.1)
; call <core::fmt::builders::DebugTuple>::field
  %_11 = call align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8 %builder, ptr %T, ptr align 8 @vtable.2)
; call <core::fmt::builders::DebugTuple>::finish
  %_0 = call zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8 %builder)
  ret i1 %_0
}

; <u64 as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1N_NtCs7CppTae75M1_5alloc6stringyNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !295 {
start:
  %buf = alloca [20 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %buf, i8 undef, i64 20, i1 false)
  %_5 = load i64, ptr %self, align 8
; call <u64>::_fmt
  %0 = call { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64 %_5, ptr %buf, i64 20)
  %_4.0 = extractvalue { ptr, i64 } %0, 0
  %_4.1 = extractvalue { ptr, i64 } %0, 1
; call <str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %_4.0, i64 %_4.1) #21
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !296 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #21
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !297 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !298 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsaqkWKWdl1xD_11int_ops_u64(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #1 !guid !299 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !300 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr %self) #21
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCsaqkWKWdl1xD_11int_ops_u64(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !301 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCsaqkWKWdl1xD_11int_ops_u64(i64 %self.0, i64 %self.1) #21
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !302 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, ptr align 8 %f) #21
  ret i1 %_0
}

; <&core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtNtB8_3num5error13ParseIntErrorNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !303 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::num::error::ParseIntError as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, ptr align 8 %f) #21
  ret i1 %_0
}

; <&bool as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRbNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !304 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <bool as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, ptr align 8 %f) #21
  ret i1 %_0
}

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !305 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_3, ptr align 8 %f) #21
  ret i1 %_0
}

; <str as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs26_NtCs7CppTae75M1_5alloc6stringeNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !306 {
start:
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !307 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #21
  ret void
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !308 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringeNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !309 {
start:
; call <str as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs26_NtCs7CppTae75M1_5alloc6stringeNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #21
  ret void
}

; <u64 as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringyNtB5_8ToString9to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !310 {
start:
; call <u64 as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs1N_NtCs7CppTae75M1_5alloc6stringyNtB6_12SpecToString14spec_to_stringCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #21
  ret void
}

; <u64 as core::str::traits::FromStr>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsC_NtCsl10jNU3mE6R_4core3numyNtNtNtB7_3str6traits7FromStr8from_strCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1) unnamed_addr #0 !guid !311 {
start:
; call <u64>::from_str_radix
  call void @_RNvMsD_NtCsl10jNU3mE6R_4core3numy14from_str_radixCsaqkWKWdl1xD_11int_ops_u64(ptr sret([16 x i8]) align 8 %_0, ptr %src.0, i64 %src.1, i32 10) #21
  ret void
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !312 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #21
  ret void
}

; <core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !313 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.1)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsaqkWKWdl1xD_11int_ops_u64() unnamed_addr #0 !guid !314 {
start:
  ret i8 0
}

; <u64 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !315 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsC_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8LowerHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u64 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXsd_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impyNtB9_7Display3fmt(ptr align 8 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u64 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr %pointer) unnamed_addr #0 !guid !316 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCsaqkWKWdl1xD_11int_ops_u64(ptr %pointer) #21
  ret ptr %_0
}

; <core::num::error::ParseIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsd_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_13ParseIntErrorNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !317 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %self, ptr %_7, align 8
; call <core::fmt::Formatter>::debug_struct_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8 %f, ptr @alloc_f62df14955f7d78bca139b0a7668683d, i64 13, ptr @alloc_a5d866b1768ad3f826bccdb004a1a8ae, i64 4, ptr %_7, ptr align 8 @vtable.3)
  ret i1 %_0
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !318 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCsaqkWKWdl1xD_11int_ops_u64(ptr %unique) unnamed_addr #0 !guid !319 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr %unique) #21
  ret ptr %_0
}

; <core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsi_NtNtCsl10jNU3mE6R_4core3num5errorNtB5_12IntErrorKindNtNtB9_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !320 {
start:
  %_3 = alloca [16 x i8], align 8
  %0 = load i8, ptr %self, align 1
  %_4 = zext i8 %0 to i64
  switch i64 %_4, label %bb1 [
    i64 0, label %bb7
    i64 1, label %bb6
    i64 2, label %bb5
    i64 3, label %bb4
    i64 4, label %bb3
    i64 5, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  store ptr @alloc_59ba7b9f7211443cd55a366616eef46a, ptr %_3, align 8, !captures !248
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb8

bb6:                                              ; preds = %start
  store ptr @alloc_00315c78e51d29fe6b3102a4c1ecf6ef, ptr %_3, align 8, !captures !248
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 12, ptr %2, align 8
  br label %bb8

bb5:                                              ; preds = %start
  store ptr @alloc_bd3a3f3879e0d5f64554753e977f58d4, ptr %_3, align 8, !captures !248
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %3, align 8
  br label %bb8

bb4:                                              ; preds = %start
  store ptr @alloc_0964bb2a4870637395c77a018495bd5c, ptr %_3, align 8, !captures !248
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 11, ptr %4, align 8
  br label %bb8

bb3:                                              ; preds = %start
  store ptr @alloc_6566120a3a17f930e960a0863fcbd591, ptr %_3, align 8, !captures !248
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %5, align 8
  br label %bb8

bb2:                                              ; preds = %start
  store ptr @alloc_6c17bac0c71cba42380f8445f4dcbd16, ptr %_3, align 8, !captures !248
  %6 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 14, ptr %6, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb3, %bb4, %bb5, %bb6, %bb7
  %7 = load ptr, ptr %_3, align 8
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %9 = load i64, ptr %8, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %7, i64 %9)
  ret i1 %_0
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) unnamed_addr #1 !guid !321 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCsaqkWKWdl1xD_11int_ops_u64(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCsaqkWKWdl1xD_11int_ops_u64(ptr %0) unnamed_addr #0 !guid !322 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %0) unnamed_addr #0 !guid !323 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u64, core::num::error::ParseIntError> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultyNtNtNtB7_3num5error13ParseIntErrorENtNtB7_3fmt5Debug3fmtCsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !324 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i8, ptr %self, align 8
  %1 = trunc nuw i8 %0 to i1
  %_3 = zext i1 %1 to i64
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store ptr %3, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.4)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %6, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.1)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %_1) unnamed_addr #0 !guid !325 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !326 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CsaqkWKWdl1xD_11int_ops_u64(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<str as alloc::borrow::ToOwned>::to_owned as core::ops::function::FnOnce<(&str,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYeNtNtCs7CppTae75M1_5alloc6borrow7ToOwned8to_ownedINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTReEE9call_onceCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %0, i64 %1) unnamed_addr #0 !guid !327 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load i64, ptr %4, align 8
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsaqkWKWdl1xD_11int_ops_u64(ptr sret([24 x i8]) align 8 %_0, ptr %3, i64 %5) #21
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; <u64 as core::fmt::Binary>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsy_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_6Binary3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs8_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impmNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impyNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsC_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8LowerHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::Octal>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsA_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Octal3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshl.i64(i64, i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshr.i64(i64, i64, i64) #9

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #7

; alloc::fmt::format::format_inner
; Function Attrs: nonlazybind uwtable
declare void @_RNvNvNtCs7CppTae75M1_5alloc3fmt6format12format_inner(ptr sret([24 x i8]) align 8, ptr, ptr) unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_shl_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_shl_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptoui.sat.i64.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; core::panicking::panic_const::panic_const_mul_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_mul_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #10

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #11

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i16, i1 } @llvm.umul.with.overflow.i16(i16, i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; core::num::imp::overflow_panic::pow
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp14overflow_panic3pow(ptr align 8) unnamed_addr #12

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #9

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i64(i64) #13

; Function Attrs: convergent nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.is.constant.i32(i32) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bitreverse.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #10

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #12

; core::num::from_ascii_bytes_radix_panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core3num28from_ascii_bytes_radix_panic(i32, ptr align 8) unnamed_addr #8

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #14

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #15

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #16

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #17

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #18

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #18

; <core::fmt::Formatter>::debug_tuple
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter11debug_tuple(ptr sret([24 x i8]) align 8, ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::field
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple5field(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugTuple>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs3_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_10DebugTuple6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #19

; <u64>::_fmt
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvMsf_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impy4__fmt(i64, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter26debug_struct_field1_finish(ptr align 8, ptr, i64, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #20 !guid !328 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsaqkWKWdl1xD_11int_ops_u64(ptr @_RNvCsaqkWKWdl1xD_11int_ops_u644main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #13 = { convergent nocallback nofree nosync nounwind willreturn memory(none) }
attributes #14 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #20 = { nonlazybind "target-cpu"="x86-64" }
attributes #21 = { inlinehint }
attributes #22 = { cold noreturn nounwind }
attributes #23 = { noreturn }
attributes #24 = { cold }
attributes #25 = { inlinehint nounwind }
attributes #26 = { noinline }
attributes #27 = { nounwind }
attributes #28 = { noinline noreturn }
attributes #29 = { noinline noreturn nounwind }

!llvm.module.flags = !{!94, !95, !96, !97}
!llvm.ident = !{!98}

!0 = !{i64 7938327338976879079}
!1 = !{i64 -109070386805518354}
!2 = !{i64 5524297308320710066}
!3 = !{i64 2246735844356491145}
!4 = !{i64 -271052646426727132}
!5 = !{i64 -1419700088927249345}
!6 = !{i64 4947035934306108841}
!7 = !{i64 1967848389496497450}
!8 = !{i64 4930596590132631515}
!9 = !{i64 -5671961470366415977}
!10 = !{i64 8755703796242553449}
!11 = !{i64 -7261305892346556305}
!12 = !{i64 5528178722780467347}
!13 = !{i64 798857786609991516}
!14 = !{i64 -4877988758469276444}
!15 = !{i64 2315585346768016276}
!16 = !{i64 1340099557426450802}
!17 = !{i64 6217070906369098870}
!18 = !{i64 6436552939374826905}
!19 = !{i64 9215324736617152384}
!20 = !{i64 888090495040403296}
!21 = !{i64 9198555632046922647}
!22 = !{i64 -6044176112104071840}
!23 = !{i64 -3681473385203712016}
!24 = !{i64 757788644300956645}
!25 = !{i64 -1523824978182727493}
!26 = !{i64 4317514277697668881}
!27 = !{i64 626655937958193683}
!28 = !{i64 -362132119376458647}
!29 = !{i64 -5283554405303541200}
!30 = !{i64 8542228282444442704}
!31 = !{i64 1296081147239773327}
!32 = !{i64 -8312605705889461906}
!33 = !{i64 8309120882261627751}
!34 = !{i64 -80228529520714525}
!35 = !{i64 2804330219051540150}
!36 = !{i64 -6758682519451409128}
!37 = !{i64 6614689773467282067}
!38 = !{i64 442031788282784778}
!39 = !{i64 -6586370286599506440}
!40 = !{i64 1744075833574203449}
!41 = !{i64 6265328426664965774}
!42 = !{i64 1157272896255167537}
!43 = !{i64 -4267485340632747674}
!44 = !{i64 -6789443114737007639}
!45 = !{i64 -5530931128925921390}
!46 = !{i64 -951397152438170539}
!47 = !{i64 -3150036093075419246}
!48 = !{i64 -5182390714351297736}
!49 = !{i64 5258143136158706627}
!50 = !{i64 5076215302340364156}
!51 = !{i64 -7797837914430344026}
!52 = !{i64 222629819854076568}
!53 = !{i64 6383420266755449063}
!54 = !{i64 -3955802835283734671}
!55 = !{i64 -3979211527972569883}
!56 = !{i64 8516412466986539181}
!57 = !{i64 -30625496072518029}
!58 = !{i64 -4665618356843850562}
!59 = !{i64 1018782987527740056}
!60 = !{i64 5973441873893200458}
!61 = !{i64 -636863307005789285}
!62 = !{i64 1559288740909412277}
!63 = !{i64 -6855163255179491489}
!64 = !{i64 8080009867882604140}
!65 = !{i64 -6032540243932600782}
!66 = !{i64 7641386475100528221}
!67 = !{i64 4752139574418998791}
!68 = !{i64 1783833921328926476}
!69 = !{i64 -3292621149234371449}
!70 = !{i64 8157536733645029574}
!71 = !{i64 -2552955181169439579}
!72 = !{i64 9092249036767239461}
!73 = !{i64 -1862980922168359821}
!74 = !{i64 -1058873960738823006}
!75 = !{i64 446528662538533320}
!76 = !{i64 -7671382668664545280}
!77 = !{i64 2295552988240259401}
!78 = !{i64 -6871408488924829530}
!79 = !{i64 -2235870228323838579}
!80 = !{i64 -3317795933806447176}
!81 = !{i64 5515343984767116602}
!82 = !{i64 7976718107228562692}
!83 = !{i64 6332281186964487049}
!84 = !{i64 5276547322382775096}
!85 = !{i64 5578442532098480133}
!86 = !{i64 3025787509247669247}
!87 = !{i64 6487687840719552694}
!88 = !{i64 -4136242965791850227}
!89 = !{i64 6838174585052404177}
!90 = !{i64 -7959834973872451342}
!91 = !{i64 663905389432559625}
!92 = !{i64 7456263123078546678}
!93 = !{i64 8392059085853937974}
!94 = !{i32 8, !"PIC Level", i32 2}
!95 = !{i32 7, !"PIE Level", i32 2}
!96 = !{i32 2, !"RtLibUseGOT", i32 1}
!97 = !{i32 7, !"uwtable", i32 2}
!98 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!99 = !{i64 -6350719809822921302}
!100 = !{i64 4598604432072176377}
!101 = !{i64 3844424672209099440}
!102 = !{i64 6746030293298378209}
!103 = !{i64 -40090442275042475}
!104 = !{i64 -3163035758188836344}
!105 = !{i64 8436620925122215103}
!106 = !{i64 -9207250945187463467}
!107 = !{i64 -7970528797176059054}
!108 = !{i64 3707073223740859259}
!109 = !{i64 -53896399863891363}
!110 = !{i64 7093706694727694467}
!111 = !{i64 4155246040506498275}
!112 = !{i64 1319503229847619699}
!113 = !{i64 695347774772586088}
!114 = !{i64 -8617339630766678476}
!115 = !{i64 6338318562965072180}
!116 = !{i64 -4825313884789255364}
!117 = !{i64 9218849494273665989}
!118 = !{i64 -3810777442543115777}
!119 = !{i64 -4262925026214832570}
!120 = !{i64 -1627377697008618755}
!121 = !{i64 1861857640655292274}
!122 = !{i64 -2922591977059710389}
!123 = !{i64 7511625827164674474}
!124 = !{i64 -2608727000935219874}
!125 = !{i64 42186360075275663}
!126 = !{i64 -1124839821726628810}
!127 = !{i64 7976818497324575145}
!128 = !{i64 -6091010505496475839}
!129 = !{i64 -1614549966000700235}
!130 = !{i64 2401334445587855503}
!131 = !{i64 2369482161656604196}
!132 = !{i64 5790166327339483146}
!133 = !{i64 -624206037079103781}
!134 = !{i64 111872114013139112}
!135 = !{i64 -8039629580606335041}
!136 = !{i64 -5171023141198713979}
!137 = !{i64 -3963448332835941428}
!138 = !{i64 6246524645047417096}
!139 = !{i64 4350988615656036239}
!140 = !{i64 -6061915748425719849}
!141 = !{i64 -5905933150245821560}
!142 = !{i64 -3523670511775376906}
!143 = !{i64 3792554740636990856}
!144 = !{i64 -1777899974264241074}
!145 = !{i64 5626453863526824725}
!146 = !{i64 4651395426815426823}
!147 = !{i64 9163988470097482543}
!148 = !{i64 -3415355657281130952}
!149 = !{i64 1318421816192758}
!150 = !{i64 -7372870578464189338}
!151 = !{i64 -8862244240714331605}
!152 = !{i64 -9065040132769964150}
!153 = !{i64 4065062684607214532}
!154 = !{i64 316608270089133767}
!155 = !{i64 -4906846794084809111}
!156 = !{i64 -2499393080194238783}
!157 = !{i64 -2453818025794349473}
!158 = !{i64 -3916065205790971371}
!159 = !{i64 -5593393964078787404}
!160 = !{i64 2820467709869103777}
!161 = !{i64 -3337375598024144164}
!162 = !{i64 -6072384481081895979}
!163 = !{i64 -904213774230372846}
!164 = !{i64 -3819006441798575423}
!165 = !{i64 -7976856525470099590}
!166 = !{i64 3938936552322764790}
!167 = !{i64 5784358415283395242}
!168 = !{i64 9050391400537049710}
!169 = !{i64 1176718162706297901}
!170 = !{i64 -8717791699218421743}
!171 = !{i64 3223004046794454688}
!172 = !{i64 7532444191162389596}
!173 = !{i64 8233673783046959087}
!174 = !{i64 9138402150979337073}
!175 = !{i64 -8245059269415379029}
!176 = !{i64 5888477222608763348}
!177 = !{i64 -8154040520278106413}
!178 = !{i64 7533107914709645929}
!179 = !{i64 -4397651060086935519}
!180 = !{i64 3944613826687201892}
!181 = !{i64 3033720013553781730}
!182 = !{i64 9181289285005510115}
!183 = !{i64 -2516591411859319167}
!184 = !{i64 6705170978821925516}
!185 = !{i64 6538909164765615712}
!186 = !{i64 -4345664529390579720}
!187 = !{i64 -1633227817060299688}
!188 = !{i64 -2571980898543774483}
!189 = !{i64 -3108260469831875508}
!190 = !{i64 6662915525973710707}
!191 = !{i64 -3557370128383784781}
!192 = !{i64 628188102975309372}
!193 = !{i64 -8095622546596976425}
!194 = !{i64 1337966168107413200}
!195 = !{i64 -1363070441522020673}
!196 = !{i64 4846436873892184382}
!197 = !{i64 2515683562128846338}
!198 = !{i64 8218073533274545389}
!199 = !{i64 5623537759640579363}
!200 = !{i64 1406947283778291750}
!201 = !{i64 720260308985200625}
!202 = !{i64 5781405749118267868}
!203 = !{i64 -269248032162978403}
!204 = !{i64 -3350798943300075920}
!205 = !{i64 -4778322950972124677}
!206 = !{i64 -6855571009827672949}
!207 = !{i64 -5922228499221643424}
!208 = !{i64 361063970380850146}
!209 = !{i64 -2316390431737325018}
!210 = !{i64 2001982696344733867}
!211 = !{i64 5148583652124832886}
!212 = !{i64 -413551022245900942}
!213 = !{i64 -5228764445810587903}
!214 = !{i64 5598652176235337189}
!215 = !{i64 -2932284724560433419}
!216 = !{i64 -4708595355468721561}
!217 = !{i64 -7264675113099629355}
!218 = !{i64 7552883798601296924}
!219 = !{i64 1263414000987683013}
!220 = !{i64 2590996121912709322}
!221 = !{i64 2728289856830196920}
!222 = !{i64 7279590991024219152}
!223 = !{i64 1430814720129927817}
!224 = !{i64 -8298385756738422110}
!225 = !{i64 -6562501830756283154}
!226 = !{i64 8892391336116780560}
!227 = !{i64 -3866327579059496776}
!228 = !{i64 -184302977520553460}
!229 = !{i64 1346407431516218718}
!230 = !{i64 3524171481337899677}
!231 = !{i64 6584544868637230167}
!232 = !{i64 -7329576845016027113}
!233 = !{i64 -3354308861726144285}
!234 = !{i64 8833813407064249582}
!235 = !{i64 8810249560178221974}
!236 = !{i64 8447309241766734749}
!237 = !{i64 5647368559608178870}
!238 = !{i64 -4738980014978525536}
!239 = !{i64 -5058041819172935420}
!240 = !{i64 5587975771484298313}
!241 = !{i64 6707042033982496572}
!242 = !{i64 -6925668523040432656}
!243 = !{i64 -466326505033984838}
!244 = !{i64 8254032864921389810}
!245 = !{i64 -4439883515804700344}
!246 = !{i64 -4142831142022185768}
!247 = !{i64 367009040887567627}
!248 = !{!"address", !"read_provenance"}
!249 = !{i64 -7750170169438176012}
!250 = !{i64 -1561071384183156027}
!251 = !{i64 -2529914820990798968}
!252 = !{i64 -4195963069822752863}
!253 = !{i64 -5208662540699454679}
!254 = !{i64 -8717178794633523553}
!255 = !{i64 3818549656696581138}
!256 = !{i64 -7591776228908526841}
!257 = !{i64 4828420101989349356}
!258 = !{i64 7581851013127974944}
!259 = !{i64 9022555215535491106}
!260 = !{i64 -757979026959033904}
!261 = !{i64 5949725353974006584}
!262 = !{i64 -719673426596097862}
!263 = !{i64 -243086732511287858}
!264 = !{i64 8373382471319891027}
!265 = !{i64 887586428047543126}
!266 = !{i64 -7662377760537027417}
!267 = !{i64 -6106143873890159787}
!268 = !{i64 7044814406672171610}
!269 = !{i64 -1763238666644041436}
!270 = !{i64 5487361353474060126}
!271 = !{i64 -1398325481744745642}
!272 = !{i64 1789253852056413623}
!273 = !{i64 -4392294270250856224}
!274 = !{i64 4953353209417393232}
!275 = !{i64 5164152049230694844}
!276 = !{i64 2841976868082735308}
!277 = !{i64 -3501058256543413933}
!278 = !{i64 -2680498261641511433}
!279 = !{i64 8521899060245139423}
!280 = !{i64 -2286175622002410824}
!281 = !{i64 1637974947924006769}
!282 = !{i64 5358980377409072148}
!283 = !{i64 7945436370753363634}
!284 = !{i64 -8975763721634503969}
!285 = !{i64 4471042118902851324}
!286 = !{i64 -3456332943716809878}
!287 = !{i64 -7939726870870579729}
!288 = !{i64 4681439759542066467}
!289 = !{i64 -5095558764385123404}
!290 = !{i64 -3031649311062085522}
!291 = !{i64 8193098927635585432}
!292 = !{i64 3719540220659171612}
!293 = !{i64 1849668918799912488}
!294 = !{i64 -558701064432408242}
!295 = !{i64 6276392682066897435}
!296 = !{i64 -94960204928028562}
!297 = !{i64 105306664376949484}
!298 = !{i64 4307739763472359341}
!299 = !{i64 6873138380453914866}
!300 = !{i64 -4716766129536807756}
!301 = !{i64 4628056024129131784}
!302 = !{i64 8675281945561449826}
!303 = !{i64 9189638898058079224}
!304 = !{i64 1175947219159088360}
!305 = !{i64 568509004574244735}
!306 = !{i64 -3711776805372135909}
!307 = !{i64 -5963571134110560314}
!308 = !{i64 2432203382448743984}
!309 = !{i64 2898506403154190660}
!310 = !{i64 8147787680137622774}
!311 = !{i64 -6473584967267895069}
!312 = !{i64 6257490210186134315}
!313 = !{i64 2249711040122262746}
!314 = !{i64 -4298085847484392885}
!315 = !{i64 1130289959401245969}
!316 = !{i64 -653600711429701308}
!317 = !{i64 -8170538480505551888}
!318 = !{i64 5966082782125074017}
!319 = !{i64 -6818943895805622957}
!320 = !{i64 -276745317899406443}
!321 = !{i64 2133125491075777861}
!322 = !{i64 -5684737044029998339}
!323 = !{i64 4820658818275775916}
!324 = !{i64 -1346890464324994791}
!325 = !{i64 -4842438223868083872}
!326 = !{i64 4339694693084854807}
!327 = !{i64 397858292899287867}
!328 = !{i64 -2624081020897602054}
