; ModuleID = 'exit_code.8035a3e2a0a8eb2d-cgu.0'
source_filename = "exit_code.8035a3e2a0a8eb2d-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsb0si8eCUKzp_9exit_code, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csb0si8eCUKzp_9exit_code, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csb0si8eCUKzp_9exit_code }>, align 8, !guid !0
@alloc_40f3a3d4abbeda48638410ab1f0b1ae7 = private unnamed_addr constant [22 x i8] c"no newline before exit", align 1, !guid !1
@alloc_9b561109c7712415cef0dc637481dd37 = private unnamed_addr constant [23 x i8] c"drop (not run by exit)\0A", align 1, !guid !2

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsb0si8eCUKzp_9exit_code(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 !guid !8 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::ptr::drop_glue::<exit_code::Late>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsb0si8eCUKzp_9exit_code4LateEBD_(ptr %_1) unnamed_addr #0 !guid !9 {
start:
; call <exit_code::Late as core::ops::drop::Drop>::drop
  call void @_RNvXCsb0si8eCUKzp_9exit_codeNtB2_4LateNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr %_1)
  ret void
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsb0si8eCUKzp_9exit_code(i32 %dummy) unnamed_addr #1 !guid !10 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !11
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsb0si8eCUKzp_9exit_code(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !12 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsb0si8eCUKzp_9exit_code(ptr %f) #7
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #7
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csb0si8eCUKzp_9exit_code(ptr align 8 %_1) unnamed_addr #1 !guid !13 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsb0si8eCUKzp_9exit_code(ptr %_4) #8
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsb0si8eCUKzp_9exit_code() #7
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csb0si8eCUKzp_9exit_code(i8 %_2) #7
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsb0si8eCUKzp_9exit_code(ptr %_1) unnamed_addr #1 !guid !14 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsb0si8eCUKzp_9exit_code(ptr %0) #7
  ret i32 %_0
}

; exit_code::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsb0si8eCUKzp_9exit_code4main() unnamed_addr #0 personality ptr @rust_eh_personality !guid !15 {
start:
  %0 = alloca [16 x i8], align 8
  %_1 = alloca [0 x i8], align 1
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsb0si8eCUKzp_9exit_code(ptr @alloc_40f3a3d4abbeda48638410ab1f0b1ae7, i64 22)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<exit_code::Late>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsb0si8eCUKzp_9exit_code4LateEBD_(ptr %_1) #9
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb3, %bb2, %bb1, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb1:                                              ; preds = %start
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_3.0, ptr %_3.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; invoke core::hint::black_box::<i32>
  %code = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECsb0si8eCUKzp_9exit_code(i32 37)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
; invoke std::process::exit
  invoke void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32 %code) #10
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %bb3
  unreachable

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #11
  unreachable

bb5:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsb0si8eCUKzp_9exit_code(ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !16 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsb0si8eCUKzp_9exit_code(ptr %s.0, i64 %s.1) unnamed_addr #1 !guid !17 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsb0si8eCUKzp_9exit_code(ptr %s.0, i64 %s.1) #7
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csb0si8eCUKzp_9exit_code(ptr %self) unnamed_addr #1 !guid !18 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csb0si8eCUKzp_9exit_code(i8 %0) unnamed_addr #1 !guid !19 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csb0si8eCUKzp_9exit_code(ptr %self) #7
  ret i32 %_0
}

; <exit_code::Late as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXCsb0si8eCUKzp_9exit_codeNtB2_4LateNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr %self) unnamed_addr #0 !guid !20 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsb0si8eCUKzp_9exit_code(ptr @alloc_9b561109c7712415cef0dc637481dd37, i64 23) #7
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_3.0, ptr %_3.1)
  ret void
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsb0si8eCUKzp_9exit_code() unnamed_addr #1 !guid !21 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsb0si8eCUKzp_9exit_code(ptr %_1) unnamed_addr #1 !guid !22 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsb0si8eCUKzp_9exit_code(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality !guid !23 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csb0si8eCUKzp_9exit_code(ptr align 8 %_1) #7
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #3

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #1

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #0

; std::process::exit
; Function Attrs: noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32) unnamed_addr #4

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #5

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #6 !guid !24 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsb0si8eCUKzp_9exit_code(ptr @_RNvCsb0si8eCUKzp_9exit_code4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nonlazybind "target-cpu"="x86-64" }
attributes #7 = { inlinehint }
attributes #8 = { noinline }
attributes #9 = { cold }
attributes #10 = { noreturn }
attributes #11 = { cold noreturn nounwind }

!llvm.module.flags = !{!3, !4, !5, !6}
!llvm.ident = !{!7}

!0 = !{i64 9082334548049727103}
!1 = !{i64 -760985524593948987}
!2 = !{i64 -2742937413147219267}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"PIE Level", i32 2}
!5 = !{i32 2, !"RtLibUseGOT", i32 1}
!6 = !{i32 7, !"uwtable", i32 2}
!7 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!8 = !{i64 -3863050477470570048}
!9 = !{i64 6148813445907763288}
!10 = !{i64 4278484523170846389}
!11 = !{i64 2015632447449362}
!12 = !{i64 -7614239920758466211}
!13 = !{i64 -4555630490747484321}
!14 = !{i64 -3497780050417964362}
!15 = !{i64 -4612399941052420968}
!16 = !{i64 2877906106939216713}
!17 = !{i64 -4520925798267206315}
!18 = !{i64 6078598085222318098}
!19 = !{i64 7494110017168733288}
!20 = !{i64 2871747631015262639}
!21 = !{i64 366725555110722903}
!22 = !{i64 7116049006672057379}
!23 = !{i64 8678641705977090301}
!24 = !{i64 -2624081020897602054}
