; ModuleID = 'intrinsics.167242395d19bcd7-cgu.0'
source_filename = "intrinsics.167242395d19bcd7-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@alloc_67f63f1edba9c857548f5126ab7ce3c2 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/merge.rs\00", align 1, !guid !4
@alloc_fdb60fb5b6a688ef522fd0615d36880a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00v\00\00\00%\00\00\00" }>, align 8, !guid !5
@alloc_da4db734c057a1035818039c5f2cff53 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00w\00\00\00&\00\00\00" }>, align 8, !guid !6
@alloc_dbe0429b9a60c3340cdd89d89688dc8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00x\00\00\00\1B\00\00\00" }>, align 8, !guid !7
@alloc_766632cf75d088c2aec994d85ef6a106 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\7F\00\00\00!\00\00\00" }>, align 8, !guid !8
@alloc_529aa4c4fd2d7c0d041fb141fa6954c5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\80\00\00\00\22\00\00\00" }>, align 8, !guid !9
@alloc_22aeb683d111f116ce81304814e59560 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00_\00\00\00\1E\00\00\00" }>, align 8, !guid !10
@alloc_5fdc9e59b7004febe916aa193690e482 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00`\00\00\00\1F\00\00\00" }>, align 8, !guid !11
@alloc_90003bfdf1f7042f7a6739b0adf34bd6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00b\00\00\00\1C\00\00\00" }>, align 8, !guid !12
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !13
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs1VtPVuSYnoF_10intrinsics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs1VtPVuSYnoF_10intrinsics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs1VtPVuSYnoF_10intrinsics }>, align 8, !guid !14
@alloc_5dc527583710389322b338be96f11800 = private unnamed_addr constant [27 x i8] c"core/src/intrinsics/mod.rs\00", align 1, !guid !15
@alloc_fad0ec960aaef86e92b189df8cfad615 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\A7\08\00\00)\00\00\00" }>, align 8, !guid !16
@alloc_52eb278fa84a54678ec49f4c446bc778 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\BD\08\00\00)\00\00\00" }>, align 8, !guid !17
@alloc_4267f6d2b1c6fe0d6aaa5e106110e530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5dc527583710389322b338be96f11800, [16 x i8] c"\1A\00\00\00\00\00\00\00\C6\0A\00\00\0E\00\00\00" }>, align 8, !guid !18
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !19
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !20
@alloc_16babad1faddf07a74f2f1bf3db5920d = private unnamed_addr constant [17 x i8] c"core/src/hint.rs\00", align 1, !guid !21
@alloc_4abf659b91fe7b31ded00e9133a8280f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16babad1faddf07a74f2f1bf3db5920d, [16 x i8] c"\10\00\00\00\00\00\00\00o\03\00\00Q\00\00\00" }>, align 8, !guid !22
@alloc_cb304c8bbb6b9195bc454f414df930e7 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/shared/mod.rs\00", align 1, !guid !23
@alloc_b1a59a7585543a4a25115f0cbf40f484 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00-\00\00\00" }>, align 8, !guid !24
@alloc_4e95ed00d8479deaf9b8943b85759bde = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00\22\00\00\00A\00\00\00" }>, align 8, !guid !25
@alloc_0aa54d60960e578bf5dc3db64f9182b2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00/\00\00\00" }>, align 8, !guid !26
@alloc_34d92db687bf3e85a75e319cac8072d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00(\00\00\00I\00\00\00" }>, align 8, !guid !27
@alloc_3a54043bf62a6816be5c3584bd0aab69 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00.\00\00\00" }>, align 8, !guid !28
@alloc_435a452c7ddb8b633a1045ff18a4d695 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cb304c8bbb6b9195bc454f414df930e7, [16 x i8] c"!\00\00\00\00\00\00\00$\00\00\00H\00\00\00" }>, align 8, !guid !29
@alloc_302a40d1b3e97481190cef1fa0a61594 = private unnamed_addr constant [34 x i8] c"core/src/slice/sort/stable/mod.rs\00", align 1, !guid !30
@alloc_63f80f9ffc23059c68b68d596767dcd4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00p\00\00\00\1A\00\00\00" }>, align 8, !guid !31
@alloc_5d8412d29d22d9db01454032d8b4fb6b = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/shared/pivot.rs\00", align 1, !guid !32
@alloc_99632a891b912b3f72527a56e4385e22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\00\22\00\00\00" }>, align 8, !guid !33
@alloc_09b6e462f7991c3c89272eedf987595a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00C\00\00\001\00\00\00" }>, align 8, !guid !34
@alloc_ff6d2fff2e86935f8ee7efadcbb4f63c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\00\22\00\00\00" }>, align 8, !guid !35
@alloc_a1fbc84c38974b09c08d1ec7662e37f7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00D\00\00\001\00\00\00" }>, align 8, !guid !36
@alloc_7346065d37ade22e9dac3d1740436530 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\00\22\00\00\00" }>, align 8, !guid !37
@alloc_8d141bec50a4ecf1e0d49d05dd5d5a28 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00E\00\00\001\00\00\00" }>, align 8, !guid !38
@alloc_ce80262f7993cac42401bc51ff6be40f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00\1F\00\00\00\18\00\00\00" }>, align 8, !guid !39
@alloc_8fdae93ef9d304733cddf77b9bee7ee5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00 \00\00\00\18\00\00\00" }>, align 8, !guid !40
@alloc_f0b38f15064fc95bc0114a55e7ca2131 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00%\00\00\006\00\00\00" }>, align 8, !guid !41
@alloc_1824be00902e801da9c2923e0e00ce0b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00#\00\00\00-\00\00\00" }>, align 8, !guid !42
@alloc_ab4c6a2d756e35f752701a51dadd262d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5d8412d29d22d9db01454032d8b4fb6b, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\09\00\00\00" }>, align 8, !guid !43
@alloc_f23d27f71cf62f918f1bed533c70d704 = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/shared/smallsort.rs\00", align 1, !guid !44
@alloc_dec6cf59bf3c4f4ee712ccf93b06ede2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\E0\02\00\00\13\00\00\00" }>, align 8, !guid !45
@alloc_d37f5665651ea8a963ab5b8e3fc8edc3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1C\02\00\00\1D\00\00\00" }>, align 8, !guid !46
@alloc_fdc854ce3bacec098be26750747cb188 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00&\02\00\00*\00\00\00" }>, align 8, !guid !47
@alloc_9deddb0feaaab459a2c7bc3556806f0a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\005\02\00\00\19\00\00\00" }>, align 8, !guid !48
@alloc_d25d1aaad97ebd3cd2f74cf98d99708b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00l\02\00\00#\00\00\00" }>, align 8, !guid !49
@alloc_7559890e91a3e111de81bd762d3bd47b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\00#\00\00\00" }>, align 8, !guid !50
@alloc_9b8e086b7f9a13f6b87be36922fe3508 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00m\02\00\004\00\00\00" }>, align 8, !guid !51
@alloc_4d667cad9e6bd5c37f0224e029fdac09 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00n\02\00\00\18\00\00\00" }>, align 8, !guid !52
@alloc_b1a74bf155318ff7697ff97ab6eab62f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00o\02\00\00\18\00\00\00" }>, align 8, !guid !53
@alloc_5b26eaacf3418840255607328a9ebf80 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00p\02\00\00\18\00\00\00" }>, align 8, !guid !54
@alloc_363ed81fe39abdd8a5079e48018053d0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00q\02\00\00\18\00\00\00" }>, align 8, !guid !55
@alloc_417b4ff3eddaf23cb9f5daaf8042e173 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\88\02\00\00*\00\00\00" }>, align 8, !guid !56
@alloc_5aef466167aa735606252f9c0ea6593f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\89\02\00\00*\00\00\00" }>, align 8, !guid !57
@alloc_030cd358d2f5c80597f9fd26abd3c2a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\8A\02\00\00+\00\00\00" }>, align 8, !guid !58
@alloc_7a8e4a95c146a6c2f88953bb46a5cc11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\00\1D\00\00\00" }>, align 8, !guid !59
@alloc_6b013669700cca0a3c4ffe02b2be411a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\9A\02\00\002\00\00\00" }>, align 8, !guid !60
@alloc_0ab1672cf9b06a39e5138e5643964c99 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\A0\02\00\00\1D\00\00\00" }>, align 8, !guid !61
@alloc_309c25bb111f12fc56d067e96fc10c4d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00$\03\00\00\1D\00\00\00" }>, align 8, !guid !62
@alloc_448a388e6d58225948aba50cc1a6d287 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00'\03\00\00 \00\00\00" }>, align 8, !guid !63
@alloc_0f305da993ffb5dd0c56a60daa72ac11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00(\03\00\00!\00\00\00" }>, align 8, !guid !64
@alloc_5c83ade1182dd85b92ed28e4ff47ff65 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00)\03\00\00\1F\00\00\00" }>, align 8, !guid !65
@alloc_93577c96033441b3a93f04582b1dcd3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\008\03\00\00\19\00\00\00" }>, align 8, !guid !66
@alloc_73f0e688413d58d51ee7d8bf7ee8fce8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\009\03\00\00\1B\00\00\00" }>, align 8, !guid !67
@alloc_f03f13dd652dcc6c8ef2b56857ba12fd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00O\02\00\00\1C\00\00\00" }>, align 8, !guid !68
@alloc_db2dccc6f36daf34898e5d24ec4427c7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00P\02\00\00\1F\00\00\00" }>, align 8, !guid !69
@alloc_0977e4bfeef367cc9b1ee8484f31ed3e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00W\02\00\00\19\00\00\00" }>, align 8, !guid !70
@alloc_9a8ea5ce0558e5156f6c03bd8315475b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00-\00\00\00" }>, align 8, !guid !71
@alloc_9f2322a70f1cdf56e7a06ccd06d355bd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\04\01\00\00J\00\00\00" }>, align 8, !guid !72
@alloc_c1f1e1e090df8fced69504921b66da98 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00!\00\00\00" }>, align 8, !guid !73
@alloc_1d52a18521d4b096220396e4abdd5c93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\FF\00\00\00>\00\00\00" }>, align 8, !guid !74
@alloc_5597fc2d1a2380cd4ab5ac1a539e8a22 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F3\00\00\00=\00\00\00" }>, align 8, !guid !75
@alloc_e13dc99a925a6bd4a73408f1fbbddb5f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F5\00\00\00\18\00\00\00" }>, align 8, !guid !76
@alloc_2288ef688a5190ec529d3a4c5860298d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F6\00\00\00\1E\00\00\00" }>, align 8, !guid !77
@alloc_4a7db440c2c67d9cd260b0d40e6000e8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\F7\00\00\00\1E\00\00\00" }>, align 8, !guid !78
@alloc_dea82b1a5cc143169db7b7d27413b6f6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\1F\01\00\00\0D\00\00\00" }>, align 8, !guid !79
@alloc_581886408b98ee2e542da40823dc7fbc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0C\01\00\00\1E\00\00\00" }>, align 8, !guid !80
@alloc_4f39daafd3dae09b4a4c732def155bd3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\0D\01\00\00$\00\00\00" }>, align 8, !guid !81
@alloc_bf1a118daf399e69d630cbc17cad5ced = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00.\00\00\00" }>, align 8, !guid !82
@alloc_40ef727ccfc43dc7481d04a8f29418d4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\11\01\00\00:\00\00\00" }>, align 8, !guid !83
@alloc_400da1c41164a324a087a19b9508009c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\12\01\00\00&\00\00\00" }>, align 8, !guid !84
@alloc_aaec00fa598af579a3c30bdcf4b2d93d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BD\02\00\00\1F\00\00\00" }>, align 8, !guid !85
@alloc_8746fce18c06124837c134543b80e6a7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BE\02\00\00\1D\00\00\00" }>, align 8, !guid !86
@alloc_bb2fc3b74a4bb7a8908f20b7bbc281bc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f23d27f71cf62f918f1bed533c70d704, [16 x i8] c"'\00\00\00\00\00\00\00\BF\02\00\00\13\00\00\00" }>, align 8, !guid !87
@alloc_b64624e679dbd4ce1203b98702274009 = private unnamed_addr constant [36 x i8] c"core/src/slice/sort/stable/drift.rs\00", align 1, !guid !88
@alloc_ea3823fa310c0ac95d0d5924e997a992 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\FF\00\00\00\19\00\00\00" }>, align 8, !guid !89
@alloc_0b170457ff613254af1d0cbd2a159dca = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\F2\00\00\00\12\00\00\00" }>, align 8, !guid !90
@alloc_c54bc7e12f54e1b6a5d6ee337e066d20 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\CE\00\00\00$\00\00\00" }>, align 8, !guid !91
@alloc_4b0ce783e358f6d901ee99bada134993 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\D1\00\00\00$\00\00\00" }>, align 8, !guid !92
@alloc_5b26bc7b45e7e23728885c9a7d45b9d3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\0D\01\00\00#\00\00\00" }>, align 8, !guid !93
@alloc_418d50aea1f432fc229dc42e85bc0c4e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00@\00\00\00\22\00\00\00" }>, align 8, !guid !94
@alloc_e6fc37ca432e3141da706e397b9bb790 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00W\00\00\004\00\00\00" }>, align 8, !guid !95
@alloc_93fee4c110c8615e3a44cfd0974e3956 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00g\00\00\00\13\00\00\00" }>, align 8, !guid !96
@alloc_ad9b3ef1565e0278a16153d428d3f2bf = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00h\00\00\00\1D\00\00\00" }>, align 8, !guid !97
@alloc_1a50229706ade81408c400fb610c9b55 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00Z\00\00\00\22\00\00\00" }>, align 8, !guid !98
@alloc_289e523c22daf4b02f0ced64176f9f7d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00]\00\00\00%\00\00\00" }>, align 8, !guid !99
@alloc_0f1d702ef74aa7166083d4a51933e745 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00)\00\00\00\1C\00\00\00" }>, align 8, !guid !100
@alloc_c1de2663403b8d62e29c8e4804352bb5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00*\00\00\00\1C\00\00\00" }>, align 8, !guid !101
@alloc_1b2260870073aafe108a5ee9a05f9377 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\005\00\00\00A\00\00\00" }>, align 8, !guid !102
@alloc_31616bb5bbed1ce5b2e84544eb586cfa = private unnamed_addr constant [40 x i8] c"core/src/slice/sort/stable/quicksort.rs\00", align 1, !guid !103
@alloc_8dae72bdaad9bf2cafde7b2cd598f477 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00r\00\00\00\1C\00\00\00" }>, align 8, !guid !104
@alloc_6b7a24d3e2ffd1fcade669520d81ebba = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\82\00\00\00)\00\00\00" }>, align 8, !guid !105
@alloc_77a953284c34024a97a172b82a9b5128 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\8B\00\00\00#\00\00\00" }>, align 8, !guid !106
@alloc_99697bcb2ea96e2031a95f1524bc6f42 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AE\00\00\00\1E\00\00\00" }>, align 8, !guid !107
@alloc_27f0c46980e62edb2ad618f3979fb7d8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\AF\00\00\00\18\00\00\00" }>, align 8, !guid !108
@alloc_4b681e459e5d8eeddb2bdf3b83cf18ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\009\00\00\00" }>, align 8, !guid !109
@alloc_1c4a9aaa93e622ac2e6c018a51cab7ab = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00-\00\00\00#\00\00\00" }>, align 8, !guid !110
@alloc_2b7dc74fc6b7aa0b08aab5733d36da25 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00<\00\00\00;\00\00\00" }>, align 8, !guid !111
@alloc_06823d4b39e256f98f8c7a33a4ce85ea = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00M\00\00\00\1F\00\00\00" }>, align 8, !guid !112
@alloc_d82d96a4fa703c840ac11f4b07c0ef3c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00G\00\00\00\17\00\00\00" }>, align 8, !guid !113
@alloc_e86c6ef68ba94e4a4bc451173d753cca = private unnamed_addr constant [22 x i8] c"core/src/slice/mod.rs\00", align 1, !guid !114
@alloc_ab5ed840fe8613ddcabc97b74e0b565e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F1\03\00\00\1C\00\00\00" }>, align 8, !guid !115
@alloc_f7fcaa33fdba299ee035b5518e72c889 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F2\03\00\00\1C\00\00\00" }>, align 8, !guid !116
@alloc_1466797b2db3a3ca9645efa4732978a2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00 \00\00\00" }>, align 8, !guid !117
@alloc_853b9dc5190658ffe6dc67504ed95441 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\F6\03\00\00+\00\00\00" }>, align 8, !guid !118
@alloc_e90bd9a80b7f188aa76a1bfb741a5999 = private unnamed_addr constant [34 x i8] c"core/src/array/iter/iter_inner.rs\00", align 1, !guid !119
@alloc_ac893681874450253b62899ecf8cf06a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\00 \00\00\00" }>, align 8, !guid !120
@alloc_b0b7c7361940ea6a8360c2bdef76bb12 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\DB\00\00\003\00\00\00" }>, align 8, !guid !121
@alloc_d4f9eee8b3859a4cb2c5427791046c70 = private unnamed_addr constant [13 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !122
@alloc_fbc6c40d9625a19c7c9c699604923a9e = private unnamed_addr constant [29 x i8] c"test/rust/eval/intrinsics.rs\00", align 1, !guid !123
@alloc_1183d6a86a10d89031fe84e0039f2937 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fbc6c40d9625a19c7c9c699604923a9e, [16 x i8] c"\1C\00\00\00\00\00\00\00\08\00\00\00e\00\00\00" }>, align 8, !guid !124
@alloc_b1b3cecaa6a7183967abcfd14f99ae78 = private unnamed_addr constant [7 x i8] c"\C0\01 \C0\01\0A\00", align 1, !guid !125
@alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e = private unnamed_addr constant [10 x i8] c"\C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !126
@alloc_65f62cd96ffd83ca67dd1fc1291b6651 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fbc6c40d9625a19c7c9c699604923a9e, [16 x i8] c"\1C\00\00\00\00\00\00\00\0F\00\00\00\11\00\00\00" }>, align 8, !guid !127
@alloc_61247b90e1706a3f65e71312b599d3d1 = private unnamed_addr constant [4 x i8] c"\C0\01\0A\00", align 1, !guid !128
@alloc_6a96e47ef75dbf6fc4eb5423ba7bb768 = private unnamed_addr constant [16 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01\0A\00", align 1, !guid !129
@alloc_49a1e817e911805af64bbc7efb390101 = private unnamed_addr constant [1 x i8] c"\0A", align 1, !guid !130
@alloc_249b00765606cfa85122173b22b0fb80 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fbc6c40d9625a19c7c9c699604923a9e, [16 x i8] c"\1C\00\00\00\00\00\00\00\1E\00\00\00 \00\00\00" }>, align 8, !guid !131
@alloc_848f03bdfff992cf43c902ffa62c80db = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_fbc6c40d9625a19c7c9c699604923a9e, [16 x i8] c"\1C\00\00\00\00\00\00\00\1E\00\00\00'\00\00\00" }>, align 8, !guid !132
@alloc_fddf786d72bd1b53926e64dc15c567f6 = private unnamed_addr constant [14 x i8] c"\C0\01 \C0\01 \C0\01 \C0\02; \00", align 1, !guid !133
@alloc_5685a6c13b96afe5e3bc9310a5bb8655 = private unnamed_addr constant [20 x i8] c"\C0\01 \C0\01 \C0\01 \C0\01 \C0\01 \C0\02; \00", align 1, !guid !134
@alloc_d1084648e479974e70c9329824bf76f9 = private unnamed_addr constant [9 x i8] c"mid > len", align 1, !guid !135
@alloc_36e015fa750e45dca62b9d94b6d857e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00J\03\00\00\22\00\00\00" }>, align 8, !guid !136
@alloc_a6541cbd0ddc1cb3d23757a1b3f12432 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\9D\08\00\00 \00\00\00" }>, align 8, !guid !137
@alloc_c0be9056d9e7c9d32564b353e6cdd76b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DD\03\00\00\15\00\00\00" }>, align 8, !guid !138
@alloc_73d74aabd1e8eaefe4cbe59407c3c85c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\003\00\00\00" }>, align 8, !guid !139
@alloc_11a111513757e9d53adfd2e1c4df0866 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e86c6ef68ba94e4a4bc451173d753cca, [16 x i8] c"\15\00\00\00\00\00\00\00\DE\03\00\00\15\00\00\00" }>, align 8, !guid !140
@alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b = private unnamed_addr constant [28 x i8] c"core/src/ops/index_range.rs\00", align 1, !guid !141
@alloc_de9a5d9a80d554992107c1ea3afec081 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8c0d3d3dfca6f109d2c25fa63c9dd69b, [16 x i8] c"\1B\00\00\00\00\00\00\00?\00\00\00%\00\00\00" }>, align 8, !guid !142
@alloc_ec595fc0e82ef92fc59bd74f68296eae = private unnamed_addr constant [73 x i8] c"assertion failed: 0 < pointee_size && pointee_size <= isize::MAX as usize", align 1, !guid !143
@alloc_f5abd596fd0c54395cb86286cae95a93 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A0\00\00\00\13\00\00\00" }>, align 8, !guid !144
@alloc_2491cc18f41182435b2301519a149a1c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_302a40d1b3e97481190cef1fa0a61594, [16 x i8] c"!\00\00\00\00\00\00\00\A3\00\00\00\12\00\00\00" }>, align 8, !guid !145
@alloc_a96f4d0356403e36c78136287f0c1b2f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\DE\00\00\001\00\00\00" }>, align 8, !guid !146
@alloc_a56b047bd0b34a39f54c81b6689d3e24 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E3\00\00\00 \00\00\00" }>, align 8, !guid !147
@alloc_35909116da33a5c42c9fe1f80ecea2ce = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\E7\00\00\00#\00\00\00" }>, align 8, !guid !148
@alloc_9738d6b9b3097219ddae8e296f0517dc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_31616bb5bbed1ce5b2e84544eb586cfa, [16 x i8] c"'\00\00\00\00\00\00\00\CB\00\00\00X\00\00\00" }>, align 8, !guid !149
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !150
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !151
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !152
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !153
@alloc_30024c4bc45de36c011698e5487cd374 = private unnamed_addr constant [20 x i8] c"core/src/num/mod.rs\00", align 1, !guid !154
@alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_30024c4bc45de36c011698e5487cd374, [16 x i8] c"\13\00\00\00\00\00\00\00\AC\05\00\00\05\00\00\00" }>, align 8, !guid !155
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !156
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !157
@alloc_1cbb975cc83b9471f5f1e14e3976c3b1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\EA\0C\00\00#\00\00\00" }>, align 8, !guid !158
@alloc_027cef065c3c71aa2f31a680ec9e0201 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\E9\0C\00\00\0D\00\00\00" }>, align 8, !guid !159
@alloc_ab1ae74de3e4549d53c3a5a25a7b5349 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00.\00\00\00" }>, align 8, !guid !160
@alloc_bde50f121dd28b1208f603a6cb579e2e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\FE\05\00\00<\00\00\00" }>, align 8, !guid !161
@alloc_1c4da29079507117c08f6c94a17cb56e = private unnamed_addr constant [22 x i8] c"core/src/ub_checks.rs\00", align 1, !guid !162
@alloc_61dde53e4938ab5b281c865c498eaeb6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_1c4da29079507117c08f6c94a17cb56e, [16 x i8] c"\15\00\00\00\00\00\00\00\94\00\00\006\00\00\00" }>, align 8, !guid !163
@alloc_945f2c369c171e278c4be97205a79e9b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !164
@alloc_8b70662a33190959512d6213db47913f = private unnamed_addr constant [22 x i8] c"Platform not supported", align 1, !guid !165
@alloc_32204aadf0ef6d74ed8e4766f91eb6a4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_b64624e679dbd4ce1203b98702274009, [16 x i8] c"#\00\00\00\00\00\00\00\9E\00\00\00\09\00\00\00" }>, align 8, !guid !166
@alloc_6b0b11c9e93314b588b613b55005cf18 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: slice::split_at_mut_unchecked requires the index to be within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !167
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !168
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !169
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !170
@alloc_3e1ebac14318b612ab4efabc52799932 = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_add cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !171
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !172
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !173
@alloc_2875d9f120b8cc0de1c30c014c7b6715 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::swap_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !174
@alloc_21be34ed5a7b8b5ac8a692be276474da = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00\EB\05\00\00\09\00\00\00" }>, align 8, !guid !175
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !176
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !177
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !178
@alloc_5c1a2f972552229672fc942406cfc298 = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts_mut requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !179
@alloc_97d92cbf2a68a6ac45a1b13da79836e4 = private unnamed_addr constant [214 x i8] c"unsafe precondition(s) violated: slice::get_unchecked requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !180
@alloc_5a8fdd84b3281310cbf6b74bb6bf0065 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the index is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !181
@alloc_18d73aa062d524e9620b9e3b55bd9eb1 = private unnamed_addr constant [218 x i8] c"unsafe precondition(s) violated: slice::get_unchecked_mut requires that the range is within the slice\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !182
@alloc_c7037efb906203803aa3ca07167c9120 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e90bd9a80b7f188aa76a1bfb741a5999, [16 x i8] c"!\00\00\00\00\00\00\00\13\00\00\00\17\00\00\00" }>, align 8, !guid !183
@alloc_a9c61c9f249d39e49475c00b6de04ee0 = private unnamed_addr constant [4 x i8] c"Less", align 1, !guid !184
@alloc_cd17b9cbc635e79a5454e667c96efc06 = private unnamed_addr constant [5 x i8] c"Equal", align 1, !guid !185
@alloc_a2975b4a9399ac4e26287fc3f00ae96d = private unnamed_addr constant [7 x i8] c"Greater", align 1, !guid !186
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !187
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !188
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCs1VtPVuSYnoF_10intrinsics }>, align 8, !guid !189
@alloc_4a07d64a21980758f07ef2afc3d73d2d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_67f63f1edba9c857548f5126ab7ce3c2, [16 x i8] c"#\00\00\00\00\00\00\00\92\00\00\00 \00\00\00" }>, align 8, !guid !190

; <[i32]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, ptr align 4 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !196 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<i32>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #21
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable
}

; <bool>::then_some::<&i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRlECs1VtPVuSYnoF_10intrinsics(i1 zeroext %self, ptr align 4 %t) unnamed_addr #0 !guid !197 {
start:
  %_4 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  store i8 0, ptr %_4, align 1
  store i8 1, ptr %_4, align 1
  br i1 %self, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_4, align 1
  store ptr %t, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load i8, ptr %_4, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb3
  %2 = load ptr, ptr %_0, align 8
  ret ptr %2

bb5:                                              ; preds = %bb3
  br label %bb4
}

; <[core::mem::maybe_uninit::MaybeUninit<f64>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdE13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !198 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitdEE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<f64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !199 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitdEE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[core::mem::maybe_uninit::MaybeUninit<f32>]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfE13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !200 {
start:
; call <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitfEE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  ret ptr %_3
}

; <[core::mem::maybe_uninit::MaybeUninit<f32>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !201 {
start:
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitfEE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <[i32]>::get_unchecked::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %index, ptr align 8 %0) unnamed_addr #0 !guid !202 {
start:
; call <usize as core::slice::index::SliceIndex<[i32]>>::get_unchecked
  %_3 = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %index, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  ret ptr %_3
}

; <[i32]>::get_unchecked_mut::<core::ops::range::Range<usize>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSl17get_unchecked_mutINtNtNtB5_3ops5range5RangejEECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %index.0, i64 %index.1, ptr align 8 %0) unnamed_addr #0 !guid !203 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::get_unchecked_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %index.0, i64 %index.1, ptr %self.0, i64 %self.1, ptr align 8 %0) #23
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_3.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_3.1, 1
  ret { ptr, i64 } %3
}

; <core::option::Option<usize>>::map::<f64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, double } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapdNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdEE4next0ECs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1, ptr align 8 %f.0, i64 %f.1) unnamed_addr #0 !guid !204 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next::{closure#0}
  %_5 = call double @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitdEE4next0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %f.0, i64 %f.1, i64 %x) #23
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store double %_5, ptr %7, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i64, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  %12 = load double, ptr %11, align 8
  %13 = insertvalue { i64, double } poison, i64 %10, 0
  %14 = insertvalue { i64, double } %13, double %12, 1
  ret { i64, double } %14

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<usize>>::map::<f32, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, float } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapfNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfEE4next0ECs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1, ptr align 4 %f.0, i64 %f.1) unnamed_addr #0 !guid !205 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %6, align 8
  store i8 0, ptr %_8, align 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next::{closure#0}
  %_5 = call float @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitfEE4next0Cs1VtPVuSYnoF_10intrinsics(ptr align 4 %f.0, i64 %f.1, i64 %x) #23
  %7 = getelementptr inbounds i8, ptr %_0, i64 4
  store float %_5, ptr %7, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_8, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %10 = load i32, ptr %_0, align 4
  %11 = getelementptr inbounds i8, ptr %_0, i64 4
  %12 = load float, ptr %11, align 4
  %13 = insertvalue { i32, float } poison, i32 %10, 0
  %14 = insertvalue { i32, float } %13, float %12, 1
  ret { i32, float } %14

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !206 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i8>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %x) #23
; call <core::ptr::non_null::NonNull<i8>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !207 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %x) #23
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !208 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %x) #23
; call <core::ptr::non_null::NonNull<f64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !209 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<f32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 4 %x) #23
; call <core::ptr::non_null::NonNull<f32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !210 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 16 %x) #23
; call <core::ptr::non_null::NonNull<i128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !211 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<u128>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16 %x) #23
; call <core::ptr::non_null::NonNull<u128>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 2 %x) unnamed_addr #0 !guid !212 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i16>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 2 %x) #23
; call <core::ptr::non_null::NonNull<i16>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !213 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i64>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %x) #23
; call <core::ptr::non_null::NonNull<i64>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 16 %x) unnamed_addr #0 !guid !214 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u128>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionoEE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 16 %x) #23
; call <core::ptr::non_null::NonNull<core::option::Option<u128>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionoEE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionoENtNtB7_3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !215 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %x) #23
; call <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !216 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %x) #23
; call <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #23
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !217 {
start:
; call core::mem::align_of_val_raw::<[i32]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) #23
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #23
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !218 {
start:
; call core::mem::size_of_val_raw::<[i32]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) #23
; call <core::mem::alignment::Alignment>::of_val_raw::<[i32]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) #23
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #23
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::slice::sort::stable::merge::MergeState<i32>>::merge_down::<<i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE10merge_downNvYlNtNtBb_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr %left_end, ptr %right_end, ptr %0, ptr %is_less) unnamed_addr #1 !guid !219 {
start:
  %_0.i6 = alloca [8 x i8], align 8
  %_0.i4 = alloca [8 x i8], align 8
  %_0.i2 = alloca [8 x i8], align 8
  %src = alloca [8 x i8], align 8
  %out = alloca [8 x i8], align 8
  store ptr %0, ptr %out, align 8
  br label %bb1

bb1:                                              ; preds = %bb12, %start
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i32, ptr %_7, i64 -1
  store ptr %2, ptr %_0.i6, align 8
  %3 = load ptr, ptr %_0.i6, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %4, align 8
  %5 = getelementptr inbounds i32, ptr %_9, i64 -1
  store ptr %5, ptr %_0.i4, align 8
  %6 = load ptr, ptr %_0.i4, align 8
  %_11 = load ptr, ptr %out, align 8
  %7 = getelementptr inbounds i32, ptr %_11, i64 -1
  store ptr %7, ptr %_0.i2, align 8
  %8 = load ptr, ptr %_0.i2, align 8
  store ptr %8, ptr %out, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %consume_left = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %6, ptr align 4 %3) #23
  br i1 %consume_left, label %bb6, label %bb7

bb7:                                              ; preds = %bb1
  store ptr %6, ptr %src, align 8
  br label %bb8

bb6:                                              ; preds = %bb1
  store ptr %3, ptr %src, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_19 = load ptr, ptr %src, align 8
  %_20 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_19, ptr %_20, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb8, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_20, ptr align 4 %_19, i64 4, i1 false)
  %_23 = xor i1 %consume_left, true
  %_22 = zext i1 %_23 to i64
  %_0.i1 = getelementptr inbounds nuw i32, ptr %3, i64 %_22
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %_0.i1, ptr %9, align 8
  %_25 = zext i1 %consume_left to i64
  %_0.i = getelementptr inbounds nuw i32, ptr %6, i64 %_25
  %10 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 16
  %_28 = load ptr, ptr %11, align 8
  %_26 = icmp eq ptr %_28, %left_end
  br i1 %_26, label %bb13, label %bb12

bb12:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %_31 = load ptr, ptr %12, align 8
  %_29 = icmp eq ptr %_31, %right_end
  br i1 %_29, label %bb13, label %bb1

bb13:                                             ; preds = %bb12, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
  ret void
}

; <core::slice::sort::stable::merge::MergeState<i32>>::merge_up::<<i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE8merge_upNvYlNtNtBb_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr %0, ptr %right_end, ptr %is_less) unnamed_addr #1 !guid !220 {
start:
  %src = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  store ptr %0, ptr %right, align 8
  %out = getelementptr inbounds i8, ptr %self, i64 16
  br label %bb1

bb1:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit, %start
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %1, align 8
  %_7 = icmp ne ptr %_8, %_9
  br i1 %_7, label %bb2, label %bb12

bb12:                                             ; preds = %bb2, %bb1
  ret void

bb2:                                              ; preds = %bb1
  %_11 = load ptr, ptr %right, align 8
  %_10 = icmp ne ptr %_11, %right_end
  br i1 %_10, label %bb3, label %bb12

bb3:                                              ; preds = %bb2
  %_15 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %self, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_13 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_15, ptr align 4 %_31) #23
  %consume_left = xor i1 %_13, true
  br i1 %consume_left, label %bb5, label %bb6

bb6:                                              ; preds = %bb3
  %2 = load ptr, ptr %right, align 8
  store ptr %2, ptr %src, align 8
  br label %bb7

bb5:                                              ; preds = %bb3
  %_18 = load ptr, ptr %self, align 8
  store ptr %_18, ptr %src, align 8
  br label %bb7

bb7:                                              ; preds = %bb5, %bb6
  %_20 = load ptr, ptr %src, align 8
  %_21 = load ptr, ptr %out, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb7
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_20, ptr %_21, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb7, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_21, ptr align 4 %_20, i64 4, i1 false)
  %_23 = load ptr, ptr %self, align 8
  %_24 = zext i1 %consume_left to i64
  %_0.i1 = getelementptr inbounds nuw i32, ptr %_23, i64 %_24
  store ptr %_0.i1, ptr %self, align 8
  %_26 = load ptr, ptr %right, align 8
  %_28 = xor i1 %consume_left, true
  %_27 = zext i1 %_28 to i64
  %_0.i2 = getelementptr inbounds nuw i32, ptr %_26, i64 %_27
  store ptr %_0.i2, ptr %right, align 8
  %_30 = load ptr, ptr %out, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_30, i64 1
  store ptr %_0.i, ptr %out, align 8
  br label %bb1
}

; <core::ptr::unique::Unique<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !221 {
start:
; call <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %self.1) #23
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !222 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECs1VtPVuSYnoF_10intrinsics(ptr %self) #23
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<u128>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionoEE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !223 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !224 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtBa_3cmp8OrderingE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !225 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[i32]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSlE4casthECs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !226 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<i8>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullaE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !227 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !228 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulldE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !229 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<f32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullfE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !230 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castlECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !231 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullnE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !232 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i16>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullsE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !233 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i64>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullxE4castuECs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !234 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !235 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<i32>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nulllECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !236 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<i32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castlECs1VtPVuSYnoF_10intrinsics(ptr %_3) #23
; call <core::ptr::unique::Unique<i32>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCs1VtPVuSYnoF_10intrinsics(ptr %_2) #23
  ret ptr %_0
}

; <core::fmt::Arguments>::new::<16, 5>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECs1VtPVuSYnoF_10intrinsics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !237 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<20, 6>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj6_ECs1VtPVuSYnoF_10intrinsics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !238 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<10, 3>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs1VtPVuSYnoF_10intrinsics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !239 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !240 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<14, 4>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !241 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr %entries.0, ptr %entries.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !242 {
start:
  %entry = alloca [8 x i8], align 8
  %_5 = alloca [8 x i8], align 8
  %iter = alloca [16 x i8], align 8
; call <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr %entries.0, ptr %entries.1) #23
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
  store ptr %_3.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store ptr %_3.1, ptr %1, align 8
  br label %bb2

bb2:                                              ; preds = %bb7, %start
; call <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
  %2 = call align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8 %iter) #23
  store ptr %2, ptr %_5, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %_5, align 8
  %4 = ptrtoint ptr %3 to i64
  %5 = icmp eq i64 %4, 0
  %_7 = select i1 %5, i64 0, i64 1
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb5, label %bb6

bb5:                                              ; preds = %bb3
  %7 = load ptr, ptr %_5, align 8
  store ptr %7, ptr %entry, align 8, !captures !243
; call <core::fmt::builders::DebugList>::entry
  %_9 = call align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8 %self, ptr %entry, ptr align 8 @vtable.0)
  br label %bb7

bb6:                                              ; preds = %bb3
  ret ptr %self

bb7:                                              ; preds = %bb5
  br label %bb2

bb4:                                              ; No predecessors!
  unreachable

bb9:                                              ; No predecessors!
  unreachable

bb10:                                             ; No predecessors!
  unreachable

bb11:                                             ; No predecessors!
  unreachable
}

; alloc::slice::stable_sort::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortlNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !244 {
start:
  %_0.i1 = alloca [1 x i8], align 1
  %_0.i = alloca [1 x i8], align 1
  %is_less = alloca [0 x i8], align 1
  %_6.i = icmp ult i64 %v.1, 2
  br i1 %_6.i, label %bb1.i3, label %bb2.i2

bb2.i2:                                           ; preds = %start
  store i8 0, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

bb1.i3:                                           ; preds = %start
  store i8 1, ptr %_0.i1, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4: ; preds = %bb2.i2, %bb1.i3
  %0 = load i8, ptr %_0.i1, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics.exit, label %bb3.i

bb3.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4
  %_8.i = icmp ule i64 %v.1, 20
  br i1 %_8.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb3.i
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

bb1.i:                                            ; preds = %bb3.i
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit: ; preds = %bb2.i, %bb1.i
  %2 = load i8, ptr %_0.i, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::stable::driftsort_main::<i32, <i32 as core::cmp::PartialOrd>::lt, alloc::vec::Vec<i32>>
  call void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr %is_less) #25
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics.exit

bb5.i:                                            ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit
; call core::slice::sort::shared::smallsort::insertion_sort_shift_left::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 1, ptr %is_less)
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics6likely.exit4, %bb6.i, %bb5.i
  br label %bb1

bb1:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable4sortlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics.exit
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::new_cap::<i32>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECs1VtPVuSYnoF_10intrinsics(i64 %cap) unnamed_addr #1 !guid !245 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %cap) #23
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs1VtPVuSYnoF_10intrinsics(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !246 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.1, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::intrinsics::rotate_left::<u8>
; Function Attrs: nounwind nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs1VtPVuSYnoF_10intrinsics(i8 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !247 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 1 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i8
  %_0 = call i8 @llvm.fshl.i8(i8 %x, i8 %x, i8 %1)
  ret i8 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #26
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_left::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftmECs1VtPVuSYnoF_10intrinsics(i32 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !248 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 4 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %_0 = call i32 @llvm.fshl.i32(i32 %x, i32 %x, i32 %_3)
  ret i32 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_fad0ec960aaef86e92b189df8cfad615) #26
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u32>
; Function Attrs: nounwind nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightmECs1VtPVuSYnoF_10intrinsics(i32 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !249 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 4 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %_0 = call i32 @llvm.fshr.i32(i32 %x, i32 %x, i32 %_3)
  ret i32 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #26
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u128>
; Function Attrs: nounwind nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECs1VtPVuSYnoF_10intrinsics(i128 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !250 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 16 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = zext i32 %_3 to i128
  %_0 = call i128 @llvm.fshr.i128(i128 %x, i128 %x, i128 %1)
  ret i128 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #26
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::rotate_right::<u16>
; Function Attrs: nounwind nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righttECs1VtPVuSYnoF_10intrinsics(i16 %x, i32 %shift) unnamed_addr #2 personality ptr @rust_eh_personality !guid !251 {
start:
  br label %bb1

terminate:                                        ; preds = %panic
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_5 = trunc i64 2 to i32
  %_4 = mul i32 %_5, 8
  %_7 = icmp eq i32 %_4, 0
  br i1 %_7, label %panic, label %bb2

bb2:                                              ; preds = %bb1
  %_3 = urem i32 %shift, %_4
  %1 = trunc i32 %_3 to i16
  %_0 = call i16 @llvm.fshr.i16(i16 %x, i16 %x, i16 %1)
  ret i16 %_0

panic:                                            ; preds = %bb1
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_52eb278fa84a54678ec49f4c446bc778) #26
          to label %unreachable unwind label %terminate

unreachable:                                      ; preds = %panic
  unreachable
}

; core::intrinsics::select_unpredictable::<core::mem::maybe_uninit::MaybeUninit<*const i32>>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableINtNtNtB4_3mem12maybe_uninit11MaybeUninitPlEECs1VtPVuSYnoF_10intrinsics(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #3 !guid !252 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::select_unpredictable::<*mut *const i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core10intrinsics20select_unpredictableOPlECs1VtPVuSYnoF_10intrinsics(i1 zeroext %b, ptr %true_val, ptr %false_val) unnamed_addr #3 !guid !253 {
start:
  %_0 = alloca [8 x i8], align 8
  br i1 %b, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store ptr %false_val, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store ptr %true_val, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; core::intrinsics::typed_swap_nonoverlapping::<i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core10intrinsics25typed_swap_nonoverlappinglECs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y) unnamed_addr #3 personality ptr @rust_eh_personality !guid !254 {
start:
; invoke core::ptr::swap_nonoverlapping::<i32>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappinglECs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 1, ptr align 8 @alloc_4267f6d2b1c6fe0d6aaa5e106110e530)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; core::mem::needs_drop::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropdECs1VtPVuSYnoF_10intrinsics() unnamed_addr #0 !guid !255 {
start:
  ret i1 false
}

; core::mem::needs_drop::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropfECs1VtPVuSYnoF_10intrinsics() unnamed_addr #0 !guid !256 {
start:
  ret i1 false
}

; core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %src) unnamed_addr #0 !guid !257 {
start:
  ret ptr %src
}

; core::mem::size_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !258 {
start:
  %_0 = mul nuw nsw i64 %val.1, 4
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !259 {
start:
  %0 = mul nuw nsw i64 %val.1, 4
  ret i64 4
}

; core::mem::swap::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4swaplECs1VtPVuSYnoF_10intrinsics(ptr align 4 %x, ptr align 4 %y) unnamed_addr #0 !guid !260 {
start:
  %0 = load i32, ptr %x, align 4
  %1 = load i32, ptr %y, align 4
  store i32 %1, ptr %x, align 4
  store i32 %0, ptr %y, align 4
  ret void
}

; core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %t) unnamed_addr #0 !guid !261 {
start:
  %0 = alloca [24 x i8], align 8
  %_2.i = alloca [24 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %_2 = alloca [24 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %t, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDroplEE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_2, ptr align 8 %_2.i, i64 24, i1 false)
  ret void
}

; core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %t) unnamed_addr #0 !guid !262 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const i32>>>::new
  %_2.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPlEE3newCs1VtPVuSYnoF_10intrinsics(ptr %t)
  ret void
}

; core::ptr::swap_nonoverlapping::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlappinglECs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %count, ptr align 8 %0) unnamed_addr #0 !guid !263 {
start:
  %_10 = alloca [24 x i8], align 8
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::swap_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 4, i64 4, i64 %count, ptr align 8 %0) #24
  br label %bb4

bb4:                                              ; preds = %bb1
  store ptr %x, ptr %_10, align 8
  %1 = getelementptr inbounds i8, ptr %_10, i64 8
  store ptr %y, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_10, i64 16
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_10, align 8
  %4 = getelementptr inbounds i8, ptr %_10, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_10, i64 16
  %7 = load i64, ptr %6, align 8
; call core::ptr::swap_nonoverlapping::runtime::<i32>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimelECs1VtPVuSYnoF_10intrinsics(ptr %3, ptr %5, i64 %7) #23
  ret void
}

; core::ptr::slice_from_raw_parts::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partslECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) unnamed_addr #0 !guid !264 {
start:
; call core::ptr::metadata::from_raw_parts::<[i32], i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSllECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitlEECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) unnamed_addr #0 !guid !265 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<i32>], core::mem::maybe_uninit::MaybeUninit<i32>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEBX_ECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) unnamed_addr #0 !guid !266 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<alloc::vec::Vec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !267 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[i32]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !268 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #21
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb2:                                              ; preds = %bb4
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !269 {
start:
; call <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<f64, 10>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterdKja_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !270 {
start:
; call <core::array::iter::IntoIter<f64, 10> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterdKja_ENtNtNtB9_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  ret void
}

; core::ptr::drop_glue::<core::array::iter::IntoIter<f32, 5>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterfKj5_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !271 {
start:
; call <core::array::iter::IntoIter<f32, 5> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterfKj5_ENtNtNtB9_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitdEja_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !272 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEja_ENtNtNtBb_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  ret void
}

; core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitfEj5_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !273 {
start:
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEj5_ENtNtNtBb_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !274 {
start:
; call <core::slice::sort::shared::smallsort::CopyOnDrop<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDroplENtNtNtBd_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !275 {
start:
; call <core::slice::sort::stable::merge::MergeState<i32> as core::ops::drop::Drop>::drop
  call void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStatelENtNtNtBc_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #1 !guid !276 {
start:
; call <core::hint::select_unpredictable::DropOnPanic<*const i32> as core::ops::drop::Drop>::drop
  call void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPlENtNtNtB6_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<i8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs1VtPVuSYnoF_10intrinsics(i8 %dummy) unnamed_addr #0 !guid !277 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<f64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %dummy) unnamed_addr #0 !guid !279 {
start:
  %_0 = alloca [8 x i8], align 8
  store double %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load double, ptr %_0, align 8
  ret double %0
}

; core::hint::black_box::<f32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float %dummy) unnamed_addr #0 !guid !280 {
start:
  %_0 = alloca [4 x i8], align 4
  store float %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load float, ptr %_0, align 4
  ret float %0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 %dummy) unnamed_addr #0 !guid !281 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs1VtPVuSYnoF_10intrinsics(i32 %dummy) unnamed_addr #0 !guid !282 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 %dummy) unnamed_addr #0 !guid !283 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<i128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs1VtPVuSYnoF_10intrinsics(i128 %dummy) unnamed_addr #0 !guid !284 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 %dummy) unnamed_addr #0 !guid !285 {
start:
  %_0 = alloca [16 x i8], align 16
  store i128 %dummy, ptr %_0, align 16
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i128, ptr %_0, align 16
  ret i128 %0
}

; core::hint::black_box::<u16>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs1VtPVuSYnoF_10intrinsics(i16 %dummy) unnamed_addr #0 !guid !286 {
start:
  %_0 = alloca [2 x i8], align 2
  store i16 %dummy, ptr %_0, align 2
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i16, ptr %_0, align 2
  ret i16 %0
}

; core::hint::black_box::<i64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs1VtPVuSYnoF_10intrinsics(i64 %dummy) unnamed_addr #0 !guid !287 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 %dummy) unnamed_addr #0 !guid !288 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !278
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1VtPVuSYnoF_10intrinsics(ptr %f) unnamed_addr #4 personality ptr @rust_eh_personality !guid !289 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs1VtPVuSYnoF_10intrinsics(ptr %f) #23
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #23
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts::<[i32], i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata14from_raw_partsSllECs1VtPVuSYnoF_10intrinsics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !290 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[core::mem::maybe_uninit::MaybeUninit<i32>], core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEBX_ECs1VtPVuSYnoF_10intrinsics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !291 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[i32], i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSllECs1VtPVuSYnoF_10intrinsics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !292 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f64>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitdEECs1VtPVuSYnoF_10intrinsics(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !293 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f32>]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitfEECs1VtPVuSYnoF_10intrinsics(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !294 {
start:
  ret i64 %ptr.1
}

; core::ptr::metadata::metadata::<[i32]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECs1VtPVuSYnoF_10intrinsics(ptr %ptr.0, i64 %ptr.1) unnamed_addr #0 !guid !295 {
start:
  ret i64 %ptr.1
}

; core::slice::raw::from_raw_parts::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !296 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts::<i32>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr20slice_from_raw_partslECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !297 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutINtNtNtB4_3mem12maybe_uninit11MaybeUninitlEECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::slice::raw::from_raw_parts_mut::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len, ptr align 8 %0) unnamed_addr #0 !guid !298 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %len) #23
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_8.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_8.1, 1
  ret { ptr, i64 } %3

bb2:                                              ; preds = %start
; call core::slice::raw::from_raw_parts_mut::precondition_check
  call void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 4, i64 4, i64 %len, ptr align 8 %0) #24
  br label %bb5
}

; core::slice::sort::stable::driftsort_main::<i32, <i32 as core::cmp::PartialOrd>::lt, alloc::vec::Vec<i32>>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable14driftsort_mainlNvYlNtNtB8_3cmp10PartialOrd2ltINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr %is_less) unnamed_addr #4 personality ptr @rust_eh_personality !guid !299 {
start:
  %0 = alloca [16 x i8], align 8
  %_30 = alloca [1 x i8], align 1
  %_23 = alloca [24 x i8], align 8
  %scratch = alloca [16 x i8], align 8
  %heap_buf = alloca [24 x i8], align 8
  %stack_buf = alloca [4096 x i8], align 4
  store i8 0, ptr %_30, align 1
  %_5 = icmp eq i64 4, 0
  br i1 %_5, label %panic, label %bb2

bb2:                                              ; preds = %start
  %max_full_alloc = udiv i64 8000000, 4
  %_11 = udiv i64 %v.1, 2
  %_10 = sub i64 %v.1, %_11
; call core::cmp::min::<usize>
  %_13 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %v.1, i64 %max_full_alloc) #23
; call core::cmp::max::<usize>
  %_9 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_10, i64 %_13) #23
; call core::cmp::max::<usize>
  %alloc_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64 %_9, i64 48) #23
; call <core::slice::sort::stable::AlignedStorage<i32, 4096>>::new
  call void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E3newCs1VtPVuSYnoF_10intrinsics(ptr sret([4096 x i8]) align 4 %stack_buf)
; call <core::slice::sort::stable::AlignedStorage<i32, 4096>>::as_uninit_slice_mut
  %1 = call { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E19as_uninit_slice_mutCs1VtPVuSYnoF_10intrinsics(ptr align 4 %stack_buf)
  %stack_scratch.0 = extractvalue { ptr, i64 } %1, 0
  %stack_scratch.1 = extractvalue { ptr, i64 } %1, 1
  %_19 = icmp uge i64 %stack_scratch.1, %alloc_len
  br i1 %_19, label %bb9, label %bb10

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_63f80f9ffc23059c68b68d596767dcd4) #27
  unreachable

bb10:                                             ; preds = %bb2
; invoke <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::with_capacity
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE13with_capacityCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_23, i64 %alloc_len)
          to label %bb11 unwind label %cleanup

bb9:                                              ; preds = %bb2
  store ptr %stack_scratch.0, ptr %scratch, align 8
  %2 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %stack_scratch.1, ptr %2, align 8
  br label %bb13

bb20:                                             ; preds = %cleanup
  %3 = load i8, ptr %_30, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb19, label %bb17

cleanup:                                          ; preds = %bb14, %bb11, %bb10
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb20

bb11:                                             ; preds = %bb10
  store i8 1, ptr %_30, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %heap_buf, ptr align 8 %_23, i64 24, i1 false)
; invoke <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::as_uninit_slice_mut
  %9 = invoke { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE19as_uninit_slice_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %heap_buf)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  %_22.0 = extractvalue { ptr, i64 } %9, 0
  %_22.1 = extractvalue { ptr, i64 } %9, 1
  store ptr %_22.0, ptr %scratch, align 8
  %10 = getelementptr inbounds i8, ptr %scratch, i64 8
  store i64 %_22.1, ptr %10, align 8
  br label %bb13

bb13:                                             ; preds = %bb9, %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
  %_26 = mul i64 32, 2
  %eager_sort = icmp ule i64 %v.1, %_26
  %_29.0 = load ptr, ptr %scratch, align 8
  %11 = getelementptr inbounds i8, ptr %scratch, i64 8
  %_29.1 = load i64, ptr %11, align 8
; invoke core::slice::sort::stable::drift::sort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %_29.0, i64 %_29.1, i1 zeroext %eager_sort, ptr %is_less)
          to label %bb15 unwind label %cleanup

bb15:                                             ; preds = %bb14
  %12 = load i8, ptr %_30, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb18, label %bb16

bb16:                                             ; preds = %bb18, %bb15
  store i8 0, ptr %_30, align 1
  ret void

bb18:                                             ; preds = %bb15
; call core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %heap_buf)
  br label %bb16

bb17:                                             ; preds = %bb19, %bb20
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb19:                                             ; preds = %bb20
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %heap_buf) #21
          to label %bb17 unwind label %terminate

terminate:                                        ; preds = %bb19
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable
}

; core::slice::sort::shared::pivot::median3_rec::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %0, ptr %1, ptr %2, i64 %n, ptr %is_less) unnamed_addr #1 !guid !300 {
start:
  %_0.i = alloca [8 x i8], align 8
  %c = alloca [8 x i8], align 8
  %b = alloca [8 x i8], align 8
  %a = alloca [8 x i8], align 8
  store ptr %0, ptr %a, align 8
  store ptr %1, ptr %b, align 8
  store ptr %2, ptr %c, align 8
  %_7 = mul i64 %n, 8
  %_6 = icmp uge i64 %_7, 64
  br i1 %_6, label %bb1, label %bb12

bb12:                                             ; preds = %bb1, %start
  %_34 = load ptr, ptr %a, align 8
  %_35 = load ptr, ptr %b, align 8
  %_36 = load ptr, ptr %c, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %x.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_34, ptr align 4 %_35) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %y.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_34, ptr align 4 %_36) #23
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb12
  store ptr %_34, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb3.i:                                            ; preds = %bb12
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %z.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_35, ptr align 4 %_36) #23
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_35, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_36, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %3 = load ptr, ptr %_0.i, align 8
  ret ptr %3

bb1:                                              ; preds = %start
  %n8 = udiv i64 %n, 8
  %_11 = load ptr, ptr %a, align 8
  %_13 = load ptr, ptr %a, align 8
  %_14 = mul i64 %n8, 4
  %_0.i6 = getelementptr inbounds nuw i32, ptr %_13, i64 %_14
  %_16 = load ptr, ptr %a, align 8
  %_17 = mul i64 %n8, 7
  %_0.i5 = getelementptr inbounds nuw i32, ptr %_16, i64 %_17
; call core::slice::sort::shared::pivot::median3_rec::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_10 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_11, ptr %_0.i6, ptr %_0.i5, i64 %n8, ptr %is_less)
  store ptr %_10, ptr %a, align 8
  %_19 = load ptr, ptr %b, align 8
  %_21 = load ptr, ptr %b, align 8
  %_22 = mul i64 %n8, 4
  %_0.i4 = getelementptr inbounds nuw i32, ptr %_21, i64 %_22
  %_24 = load ptr, ptr %b, align 8
  %_25 = mul i64 %n8, 7
  %_0.i3 = getelementptr inbounds nuw i32, ptr %_24, i64 %_25
; call core::slice::sort::shared::pivot::median3_rec::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_18 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_19, ptr %_0.i4, ptr %_0.i3, i64 %n8, ptr %is_less)
  store ptr %_18, ptr %b, align 8
  %_27 = load ptr, ptr %c, align 8
  %_29 = load ptr, ptr %c, align 8
  %_30 = mul i64 %n8, 4
  %_0.i2 = getelementptr inbounds nuw i32, ptr %_29, i64 %_30
  %_32 = load ptr, ptr %c, align 8
  %_33 = mul i64 %n8, 7
  %_0.i1 = getelementptr inbounds nuw i32, ptr %_32, i64 %_33
; call core::slice::sort::shared::pivot::median3_rec::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_26 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_27, ptr %_0.i2, ptr %_0.i1, i64 %n8, ptr %is_less)
  store ptr %_26, ptr %c, align 8
  br label %bb12
}

; core::slice::sort::shared::pivot::choose_pivot::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr %is_less) unnamed_addr #0 !guid !301 {
start:
  %_0.i = alloca [8 x i8], align 8
  %index = alloca [8 x i8], align 8
  %_4 = icmp ult i64 %v.1, 8
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %len_div_8 = udiv i64 %v.1, 8
  %_11 = mul i64 %len_div_8, 4
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_11
  %_13 = mul i64 %len_div_8, 7
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_13
  %_14 = icmp ult i64 %v.1, 64
  br i1 %_14, label %bb7, label %bb9

bb1:                                              ; preds = %start
  call void @llvm.trap()
  unreachable

bb9:                                              ; preds = %bb2
; call core::slice::sort::shared::pivot::median3_rec::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_19 = call ptr @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot11median3_reclNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v.0, ptr %_0.i2, ptr %_0.i1, i64 %len_div_8, ptr %is_less)
; call <*const i32>::offset_from_unsigned
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %_19, ptr %v.0, ptr align 8 @alloc_f0b38f15064fc95bc0114a55e7ca2131) #23
  store i64 %0, ptr %index, align 8
  br label %bb11

bb7:                                              ; preds = %bb2
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %x.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %v.0, ptr align 4 %_0.i2) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %y.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %v.0, ptr align 4 %_0.i1) #23
  %_9.i = icmp eq i1 %x.i, %y.i
  br i1 %_9.i, label %bb3.i, label %bb7.i

bb7.i:                                            ; preds = %bb7
  store ptr %v.0, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb3.i:                                            ; preds = %bb7
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %z.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i2, ptr align 4 %_0.i1) #23
  %_12.i = xor i1 %z.i, %x.i
  br i1 %_12.i, label %bb5.i, label %bb6.i

bb6.i:                                            ; preds = %bb3.i
  store ptr %_0.i2, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb5.i:                                            ; preds = %bb3.i
  store ptr %_0.i1, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb7.i, %bb6.i, %bb5.i
  %1 = load ptr, ptr %_0.i, align 8
; call <*const i32>::offset_from_unsigned
  %2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %1, ptr %v.0, ptr align 8 @alloc_1824be00902e801da9c2923e0e00ce0b) #23
  store i64 %2, ptr %index, align 8
  br label %bb11

bb11:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot7median3lNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit, %bb9
  %_22 = load i64, ptr %index, align 8
  %_21 = icmp ult i64 %_22, %v.1
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb11
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i1 zeroext %_21, ptr align 8 @alloc_ab4c6a2d756e35f752701a51dadd262d) #24
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb11, %bb2.i
  %_0 = load i64, ptr %index, align 8
  ret i64 %_0
}

; core::slice::sort::shared::smallsort::insert_tail::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %begin, ptr %tail, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !302 {
start:
  %_0.i3 = alloca [8 x i8], align 8
  %_0.i = alloca [8 x i8], align 8
  %0 = alloca [16 x i8], align 8
  %gap_guard = alloca [24 x i8], align 8
  %tmp = alloca [4 x i8], align 4
  %sift = alloca [8 x i8], align 8
  %1 = getelementptr inbounds i32, ptr %tail, i64 -1
  store ptr %1, ptr %_0.i3, align 8
  %2 = load ptr, ptr %_0.i3, align 8
  store ptr %2, ptr %sift, align 8
  %_8 = load ptr, ptr %sift, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_5 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %tail, ptr align 4 %_8) #23
  br i1 %_5, label %bb3, label %bb14

bb14:                                             ; preds = %bb13, %start
  ret void

bb3:                                              ; preds = %start
  %_0.i.i = load i32, ptr %tail, align 4
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32 %_0.i.i)
  store i32 %_2.i, ptr %tmp, align 4
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
  %_0.i7 = call align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCs1VtPVuSYnoF_10intrinsics(ptr align 4 %tmp)
  store ptr %_0.i7, ptr %gap_guard, align 8
  %3 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %tail, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %gap_guard, i64 16
  store i64 1, ptr %4, align 8
  br label %bb7

bb7:                                              ; preds = %bb12, %bb3
  %_17 = load ptr, ptr %sift, align 8
  %5 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  %_18 = load ptr, ptr %5, align 8
; invoke core::ub_checks::check_language_ub
  %_4.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb7
  br i1 %_4.i1, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_17, ptr %_18, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_18, ptr align 4 %_17, i64 4, i1 false)
  br label %bb8

bb15:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %gap_guard) #21
          to label %bb16 unwind label %terminate

cleanup:                                          ; preds = %bb10, %bb7, %bb11
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb15

bb8:                                              ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
  %_19 = load ptr, ptr %sift, align 8
  %10 = getelementptr inbounds i8, ptr %gap_guard, i64 8
  store ptr %_19, ptr %10, align 8
  %_21 = load ptr, ptr %sift, align 8
  %_20 = icmp eq ptr %_21, %begin
  br i1 %_20, label %bb13, label %bb9

bb9:                                              ; preds = %bb8
  %_23 = load ptr, ptr %sift, align 8
  %11 = getelementptr inbounds i32, ptr %_23, i64 -1
  store ptr %11, ptr %_0.i, align 8
  %12 = load ptr, ptr %_0.i, align 8
  br label %bb10

bb13:                                             ; preds = %bb12, %bb8
; call core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %gap_guard)
  br label %bb14

bb10:                                             ; preds = %bb9
  store ptr %12, ptr %sift, align 8
; invoke <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
  %_0.i56 = invoke align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCs1VtPVuSYnoF_10intrinsics(ptr align 4 %tmp)
          to label %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCs1VtPVuSYnoF_10intrinsics.exit unwind label %cleanup

_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb10
  br label %bb11

bb11:                                             ; preds = %_RNvXs0_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB5_12ManuallyDroplENtNtNtB9_3ops5deref5Deref5derefCs1VtPVuSYnoF_10intrinsics.exit
  %_28 = load ptr, ptr %sift, align 8
; invoke <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_24 = invoke zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i56, ptr align 4 %_28)
          to label %bb12 unwind label %cleanup

bb12:                                             ; preds = %bb11
  br i1 %_24, label %bb7, label %bb13

terminate:                                        ; preds = %bb15
  %13 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb16:                                             ; preds = %bb15
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18
}

; core::slice::sort::shared::smallsort::sort4_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v_base, ptr %dst, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !303 {
start:
  %0 = alloca [16 x i8], align 8
  %_21.i155 = alloca [1 x i8], align 1
  %_20.i156 = alloca [1 x i8], align 1
  %guard.i157 = alloca [8 x i8], align 8
  %false_val2.i158 = alloca [8 x i8], align 8
  %true_val1.i159 = alloca [8 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_21.i131 = alloca [1 x i8], align 1
  %_20.i132 = alloca [1 x i8], align 1
  %guard.i133 = alloca [8 x i8], align 8
  %false_val2.i134 = alloca [8 x i8], align 8
  %true_val1.i135 = alloca [8 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %_21.i107 = alloca [1 x i8], align 1
  %_20.i108 = alloca [1 x i8], align 1
  %guard.i109 = alloca [8 x i8], align 8
  %false_val2.i110 = alloca [8 x i8], align 8
  %true_val1.i111 = alloca [8 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_21.i83 = alloca [1 x i8], align 1
  %_20.i84 = alloca [1 x i8], align 1
  %guard.i85 = alloca [8 x i8], align 8
  %false_val2.i86 = alloca [8 x i8], align 8
  %true_val1.i87 = alloca [8 x i8], align 8
  %4 = alloca [16 x i8], align 8
  %_21.i59 = alloca [1 x i8], align 1
  %_20.i60 = alloca [1 x i8], align 1
  %guard.i61 = alloca [8 x i8], align 8
  %false_val2.i62 = alloca [8 x i8], align 8
  %true_val1.i63 = alloca [8 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %_21.i35 = alloca [1 x i8], align 1
  %_20.i36 = alloca [1 x i8], align 1
  %guard.i37 = alloca [8 x i8], align 8
  %false_val2.i38 = alloca [8 x i8], align 8
  %true_val1.i39 = alloca [8 x i8], align 8
  %6 = alloca [16 x i8], align 8
  %_21.i11 = alloca [1 x i8], align 1
  %_20.i12 = alloca [1 x i8], align 1
  %guard.i13 = alloca [8 x i8], align 8
  %false_val2.i14 = alloca [8 x i8], align 8
  %true_val1.i15 = alloca [8 x i8], align 8
  %7 = alloca [16 x i8], align 8
  %_21.i = alloca [1 x i8], align 1
  %_20.i = alloca [1 x i8], align 1
  %guard.i = alloca [8 x i8], align 8
  %false_val2.i = alloca [8 x i8], align 8
  %true_val1.i = alloca [8 x i8], align 8
  %_0.i188 = getelementptr inbounds nuw i32, ptr %v_base, i64 1
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %c1 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i188, ptr align 4 %v_base) #23
  %_0.i187 = getelementptr inbounds nuw i32, ptr %v_base, i64 3
  %_0.i186 = getelementptr inbounds nuw i32, ptr %v_base, i64 2
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %c2 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i187, ptr align 4 %_0.i186) #23
  %_16 = zext i1 %c1 to i64
  %_0.i185 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_16
  %_19 = xor i1 %c1, true
  %_18 = zext i1 %_19 to i64
  %_0.i184 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_18
  %_22 = zext i1 %c2 to i64
  %_21 = add i64 2, %_22
  %_0.i183 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_21
  %_26 = xor i1 %c2, true
  %_25 = zext i1 %_26 to i64
  %_24 = add i64 2, %_25
  %_0.i182 = getelementptr inbounds nuw i32, ptr %v_base, i64 %_24
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %c3 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i183, ptr align 4 %_0.i185) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %c4 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i182, ptr align 4 %_0.i184) #23
  store i8 0, ptr %_21.i155, align 1
  store i8 0, ptr %_20.i156, align 1
  store i8 1, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i212 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i183)
  store ptr %_2.i.i212, ptr %true_val1.i159, align 8
  store i8 0, ptr %_21.i155, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i185)
  store ptr %_2.i.i, ptr %false_val2.i158, align 8
  %guard3.i163 = select i1 %c3, ptr %true_val1.i159, ptr %false_val2.i158, !unpredictable !304
  %drop.i164 = select i1 %c3, ptr %false_val2.i158, ptr %true_val1.i159, !unpredictable !304
  store i8 1, ptr %_20.i156, align 1
  store ptr %guard3.i163, ptr %guard.i157, align 8
  br label %bb7.i171

cleanup.i165:                                     ; preds = %bb8.i173, %bb7.i171
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  %12 = load i8, ptr %_20.i156, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb12.i169, label %bb15.i166

bb7.i171:                                         ; preds = %start
  store i8 0, ptr %_20.i156, align 1
  %_16.i172 = load ptr, ptr %guard.i157, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i172)
          to label %bb8.i173 unwind label %cleanup.i165

bb8.i173:                                         ; preds = %bb7.i171
  %_18.i174 = load ptr, ptr %true_val1.i159, align 8
  %_19.i175 = load ptr, ptr %false_val2.i158, align 8
  %_17.i176 = select i1 %c3, ptr %_18.i174, ptr %_19.i175, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i189190 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i176) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit unwind label %cleanup.i165

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb8.i173
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit178

bb15.i166:                                        ; preds = %bb12.i169, %cleanup.i165
  %14 = load i8, ptr %_21.i155, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb14.i168, label %bb11.i167

bb12.i169:                                        ; preds = %cleanup.i165
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i157) #21
          to label %bb15.i166 unwind label %terminate.i170

terminate.i170:                                   ; preds = %bb12.i169
  %16 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i167:                                        ; preds = %bb14.i168, %bb15.i166
  %17 = load ptr, ptr %0, align 8
  %18 = getelementptr inbounds i8, ptr %0, i64 8
  %19 = load i32, ptr %18, align 8
  %20 = insertvalue { ptr, i32 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i32 } %20, i32 %19, 1
  resume { ptr, i32 } %21

bb14.i168:                                        ; preds = %bb15.i166
  br label %bb11.i167

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit178: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit
  store i8 0, ptr %_20.i156, align 1
  store i8 0, ptr %_21.i131, align 1
  store i8 0, ptr %_20.i132, align 1
  store i8 1, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i214 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i184)
  store ptr %_2.i.i214, ptr %true_val1.i135, align 8
  store i8 0, ptr %_21.i131, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i213 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i182)
  store ptr %_2.i.i213, ptr %false_val2.i134, align 8
  %guard3.i139 = select i1 %c4, ptr %true_val1.i135, ptr %false_val2.i134, !unpredictable !304
  %drop.i140 = select i1 %c4, ptr %false_val2.i134, ptr %true_val1.i135, !unpredictable !304
  store i8 1, ptr %_20.i132, align 1
  store ptr %guard3.i139, ptr %guard.i133, align 8
  br label %bb7.i147

cleanup.i141:                                     ; preds = %bb8.i149, %bb7.i147
  %22 = landingpad { ptr, i32 }
          cleanup
  %23 = extractvalue { ptr, i32 } %22, 0
  %24 = extractvalue { ptr, i32 } %22, 1
  store ptr %23, ptr %1, align 8
  %25 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %24, ptr %25, align 8
  %26 = load i8, ptr %_20.i132, align 1
  %27 = trunc nuw i8 %26 to i1
  br i1 %27, label %bb12.i145, label %bb15.i142

bb7.i147:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit178
  store i8 0, ptr %_20.i132, align 1
  %_16.i148 = load ptr, ptr %guard.i133, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i148)
          to label %bb8.i149 unwind label %cleanup.i141

bb8.i149:                                         ; preds = %bb7.i147
  %_18.i150 = load ptr, ptr %true_val1.i135, align 8
  %_19.i151 = load ptr, ptr %false_val2.i134, align 8
  %_17.i152 = select i1 %c4, ptr %_18.i150, ptr %_19.i151, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i191192 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i152) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit193 unwind label %cleanup.i141

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit193: ; preds = %bb8.i149
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit154

bb15.i142:                                        ; preds = %bb12.i145, %cleanup.i141
  %28 = load i8, ptr %_21.i131, align 1
  %29 = trunc nuw i8 %28 to i1
  br i1 %29, label %bb14.i144, label %bb11.i143

bb12.i145:                                        ; preds = %cleanup.i141
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i133) #21
          to label %bb15.i142 unwind label %terminate.i146

terminate.i146:                                   ; preds = %bb12.i145
  %30 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i143:                                        ; preds = %bb14.i144, %bb15.i142
  %31 = load ptr, ptr %1, align 8
  %32 = getelementptr inbounds i8, ptr %1, i64 8
  %33 = load i32, ptr %32, align 8
  %34 = insertvalue { ptr, i32 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i32 } %34, i32 %33, 1
  resume { ptr, i32 } %35

bb14.i144:                                        ; preds = %bb15.i142
  br label %bb11.i143

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit154: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit193
  store i8 0, ptr %_20.i132, align 1
  store i8 0, ptr %_21.i107, align 1
  store i8 0, ptr %_20.i108, align 1
  store i8 1, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i216 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i183)
  store ptr %_2.i.i216, ptr %true_val1.i111, align 8
  store i8 0, ptr %_21.i107, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i215 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i184)
  store ptr %_2.i.i215, ptr %false_val2.i110, align 8
  %guard3.i115 = select i1 %c4, ptr %true_val1.i111, ptr %false_val2.i110, !unpredictable !304
  %drop.i116 = select i1 %c4, ptr %false_val2.i110, ptr %true_val1.i111, !unpredictable !304
  store i8 1, ptr %_20.i108, align 1
  store ptr %guard3.i115, ptr %guard.i109, align 8
  br label %bb7.i123

cleanup.i117:                                     ; preds = %bb8.i125, %bb7.i123
  %36 = landingpad { ptr, i32 }
          cleanup
  %37 = extractvalue { ptr, i32 } %36, 0
  %38 = extractvalue { ptr, i32 } %36, 1
  store ptr %37, ptr %2, align 8
  %39 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %38, ptr %39, align 8
  %40 = load i8, ptr %_20.i108, align 1
  %41 = trunc nuw i8 %40 to i1
  br i1 %41, label %bb12.i121, label %bb15.i118

bb7.i123:                                         ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit154
  store i8 0, ptr %_20.i108, align 1
  %_16.i124 = load ptr, ptr %guard.i109, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i124)
          to label %bb8.i125 unwind label %cleanup.i117

bb8.i125:                                         ; preds = %bb7.i123
  %_18.i126 = load ptr, ptr %true_val1.i111, align 8
  %_19.i127 = load ptr, ptr %false_val2.i110, align 8
  %_17.i128 = select i1 %c4, ptr %_18.i126, ptr %_19.i127, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i194195 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i128) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit196 unwind label %cleanup.i117

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit196: ; preds = %bb8.i125
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit130

bb15.i118:                                        ; preds = %bb12.i121, %cleanup.i117
  %42 = load i8, ptr %_21.i107, align 1
  %43 = trunc nuw i8 %42 to i1
  br i1 %43, label %bb14.i120, label %bb11.i119

bb12.i121:                                        ; preds = %cleanup.i117
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i109) #21
          to label %bb15.i118 unwind label %terminate.i122

terminate.i122:                                   ; preds = %bb12.i121
  %44 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i119:                                        ; preds = %bb14.i120, %bb15.i118
  %45 = load ptr, ptr %2, align 8
  %46 = getelementptr inbounds i8, ptr %2, i64 8
  %47 = load i32, ptr %46, align 8
  %48 = insertvalue { ptr, i32 } poison, ptr %45, 0
  %49 = insertvalue { ptr, i32 } %48, i32 %47, 1
  resume { ptr, i32 } %49

bb14.i120:                                        ; preds = %bb15.i118
  br label %bb11.i119

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit130: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit196
  store i8 0, ptr %_20.i108, align 1
  store i8 0, ptr %_21.i83, align 1
  store i8 0, ptr %_20.i84, align 1
  store i8 1, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i218 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i185)
  store ptr %_2.i.i218, ptr %true_val1.i87, align 8
  store i8 0, ptr %_21.i83, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i217 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i194195)
  store ptr %_2.i.i217, ptr %false_val2.i86, align 8
  %guard3.i91 = select i1 %c3, ptr %true_val1.i87, ptr %false_val2.i86, !unpredictable !304
  %drop.i92 = select i1 %c3, ptr %false_val2.i86, ptr %true_val1.i87, !unpredictable !304
  store i8 1, ptr %_20.i84, align 1
  store ptr %guard3.i91, ptr %guard.i85, align 8
  br label %bb7.i99

cleanup.i93:                                      ; preds = %bb8.i101, %bb7.i99
  %50 = landingpad { ptr, i32 }
          cleanup
  %51 = extractvalue { ptr, i32 } %50, 0
  %52 = extractvalue { ptr, i32 } %50, 1
  store ptr %51, ptr %3, align 8
  %53 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %52, ptr %53, align 8
  %54 = load i8, ptr %_20.i84, align 1
  %55 = trunc nuw i8 %54 to i1
  br i1 %55, label %bb12.i97, label %bb15.i94

bb7.i99:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit130
  store i8 0, ptr %_20.i84, align 1
  %_16.i100 = load ptr, ptr %guard.i85, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i100)
          to label %bb8.i101 unwind label %cleanup.i93

bb8.i101:                                         ; preds = %bb7.i99
  %_18.i102 = load ptr, ptr %true_val1.i87, align 8
  %_19.i103 = load ptr, ptr %false_val2.i86, align 8
  %_17.i104 = select i1 %c3, ptr %_18.i102, ptr %_19.i103, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i197198 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i104) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit199 unwind label %cleanup.i93

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit199: ; preds = %bb8.i101
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit106

bb15.i94:                                         ; preds = %bb12.i97, %cleanup.i93
  %56 = load i8, ptr %_21.i83, align 1
  %57 = trunc nuw i8 %56 to i1
  br i1 %57, label %bb14.i96, label %bb11.i95

bb12.i97:                                         ; preds = %cleanup.i93
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i85) #21
          to label %bb15.i94 unwind label %terminate.i98

terminate.i98:                                    ; preds = %bb12.i97
  %58 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i95:                                         ; preds = %bb14.i96, %bb15.i94
  %59 = load ptr, ptr %3, align 8
  %60 = getelementptr inbounds i8, ptr %3, i64 8
  %61 = load i32, ptr %60, align 8
  %62 = insertvalue { ptr, i32 } poison, ptr %59, 0
  %63 = insertvalue { ptr, i32 } %62, i32 %61, 1
  resume { ptr, i32 } %63

bb14.i96:                                         ; preds = %bb15.i94
  br label %bb11.i95

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit106: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit199
  store i8 0, ptr %_20.i84, align 1
  store i8 0, ptr %_21.i59, align 1
  store i8 0, ptr %_20.i60, align 1
  store i8 1, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i220 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i184)
  store ptr %_2.i.i220, ptr %true_val1.i63, align 8
  store i8 0, ptr %_21.i59, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i219 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i183)
  store ptr %_2.i.i219, ptr %false_val2.i62, align 8
  %guard3.i67 = select i1 %c3, ptr %true_val1.i63, ptr %false_val2.i62, !unpredictable !304
  %drop.i68 = select i1 %c3, ptr %false_val2.i62, ptr %true_val1.i63, !unpredictable !304
  store i8 1, ptr %_20.i60, align 1
  store ptr %guard3.i67, ptr %guard.i61, align 8
  br label %bb7.i75

cleanup.i69:                                      ; preds = %bb8.i77, %bb7.i75
  %64 = landingpad { ptr, i32 }
          cleanup
  %65 = extractvalue { ptr, i32 } %64, 0
  %66 = extractvalue { ptr, i32 } %64, 1
  store ptr %65, ptr %4, align 8
  %67 = getelementptr inbounds i8, ptr %4, i64 8
  store i32 %66, ptr %67, align 8
  %68 = load i8, ptr %_20.i60, align 1
  %69 = trunc nuw i8 %68 to i1
  br i1 %69, label %bb12.i73, label %bb15.i70

bb7.i75:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit106
  store i8 0, ptr %_20.i60, align 1
  %_16.i76 = load ptr, ptr %guard.i61, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i76)
          to label %bb8.i77 unwind label %cleanup.i69

bb8.i77:                                          ; preds = %bb7.i75
  %_18.i78 = load ptr, ptr %true_val1.i63, align 8
  %_19.i79 = load ptr, ptr %false_val2.i62, align 8
  %_17.i80 = select i1 %c3, ptr %_18.i78, ptr %_19.i79, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i200201 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i80) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit202 unwind label %cleanup.i69

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit202: ; preds = %bb8.i77
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit82

bb15.i70:                                         ; preds = %bb12.i73, %cleanup.i69
  %70 = load i8, ptr %_21.i59, align 1
  %71 = trunc nuw i8 %70 to i1
  br i1 %71, label %bb14.i72, label %bb11.i71

bb12.i73:                                         ; preds = %cleanup.i69
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i61) #21
          to label %bb15.i70 unwind label %terminate.i74

terminate.i74:                                    ; preds = %bb12.i73
  %72 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i71:                                         ; preds = %bb14.i72, %bb15.i70
  %73 = load ptr, ptr %4, align 8
  %74 = getelementptr inbounds i8, ptr %4, i64 8
  %75 = load i32, ptr %74, align 8
  %76 = insertvalue { ptr, i32 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i32 } %76, i32 %75, 1
  resume { ptr, i32 } %77

bb14.i72:                                         ; preds = %bb15.i70
  br label %bb11.i71

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit82: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit202
  store i8 0, ptr %_20.i60, align 1
  store i8 0, ptr %_21.i35, align 1
  store i8 0, ptr %_20.i36, align 1
  store i8 1, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i222 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i182)
  store ptr %_2.i.i222, ptr %true_val1.i39, align 8
  store i8 0, ptr %_21.i35, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i221 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i200201)
  store ptr %_2.i.i221, ptr %false_val2.i38, align 8
  %guard3.i43 = select i1 %c4, ptr %true_val1.i39, ptr %false_val2.i38, !unpredictable !304
  %drop.i44 = select i1 %c4, ptr %false_val2.i38, ptr %true_val1.i39, !unpredictable !304
  store i8 1, ptr %_20.i36, align 1
  store ptr %guard3.i43, ptr %guard.i37, align 8
  br label %bb7.i51

cleanup.i45:                                      ; preds = %bb8.i53, %bb7.i51
  %78 = landingpad { ptr, i32 }
          cleanup
  %79 = extractvalue { ptr, i32 } %78, 0
  %80 = extractvalue { ptr, i32 } %78, 1
  store ptr %79, ptr %5, align 8
  %81 = getelementptr inbounds i8, ptr %5, i64 8
  store i32 %80, ptr %81, align 8
  %82 = load i8, ptr %_20.i36, align 1
  %83 = trunc nuw i8 %82 to i1
  br i1 %83, label %bb12.i49, label %bb15.i46

bb7.i51:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit82
  store i8 0, ptr %_20.i36, align 1
  %_16.i52 = load ptr, ptr %guard.i37, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i52)
          to label %bb8.i53 unwind label %cleanup.i45

bb8.i53:                                          ; preds = %bb7.i51
  %_18.i54 = load ptr, ptr %true_val1.i39, align 8
  %_19.i55 = load ptr, ptr %false_val2.i38, align 8
  %_17.i56 = select i1 %c4, ptr %_18.i54, ptr %_19.i55, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i203204 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i56) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit205 unwind label %cleanup.i45

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit205: ; preds = %bb8.i53
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit58

bb15.i46:                                         ; preds = %bb12.i49, %cleanup.i45
  %84 = load i8, ptr %_21.i35, align 1
  %85 = trunc nuw i8 %84 to i1
  br i1 %85, label %bb14.i48, label %bb11.i47

bb12.i49:                                         ; preds = %cleanup.i45
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i37) #21
          to label %bb15.i46 unwind label %terminate.i50

terminate.i50:                                    ; preds = %bb12.i49
  %86 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i47:                                         ; preds = %bb14.i48, %bb15.i46
  %87 = load ptr, ptr %5, align 8
  %88 = getelementptr inbounds i8, ptr %5, i64 8
  %89 = load i32, ptr %88, align 8
  %90 = insertvalue { ptr, i32 } poison, ptr %87, 0
  %91 = insertvalue { ptr, i32 } %90, i32 %89, 1
  resume { ptr, i32 } %91

bb14.i48:                                         ; preds = %bb15.i46
  br label %bb11.i47

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit58: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit205
  store i8 0, ptr %_20.i36, align 1
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %c5 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_0.i203204, ptr align 4 %_0.i197198) #23
  store i8 0, ptr %_21.i11, align 1
  store i8 0, ptr %_20.i12, align 1
  store i8 1, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i224 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i203204)
  store ptr %_2.i.i224, ptr %true_val1.i15, align 8
  store i8 0, ptr %_21.i11, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i223 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i197198)
  store ptr %_2.i.i223, ptr %false_val2.i14, align 8
  %guard3.i19 = select i1 %c5, ptr %true_val1.i15, ptr %false_val2.i14, !unpredictable !304
  %drop.i20 = select i1 %c5, ptr %false_val2.i14, ptr %true_val1.i15, !unpredictable !304
  store i8 1, ptr %_20.i12, align 1
  store ptr %guard3.i19, ptr %guard.i13, align 8
  br label %bb7.i27

cleanup.i21:                                      ; preds = %bb8.i29, %bb7.i27
  %92 = landingpad { ptr, i32 }
          cleanup
  %93 = extractvalue { ptr, i32 } %92, 0
  %94 = extractvalue { ptr, i32 } %92, 1
  store ptr %93, ptr %6, align 8
  %95 = getelementptr inbounds i8, ptr %6, i64 8
  store i32 %94, ptr %95, align 8
  %96 = load i8, ptr %_20.i12, align 1
  %97 = trunc nuw i8 %96 to i1
  br i1 %97, label %bb12.i25, label %bb15.i22

bb7.i27:                                          ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit58
  store i8 0, ptr %_20.i12, align 1
  %_16.i28 = load ptr, ptr %guard.i13, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i28)
          to label %bb8.i29 unwind label %cleanup.i21

bb8.i29:                                          ; preds = %bb7.i27
  %_18.i30 = load ptr, ptr %true_val1.i15, align 8
  %_19.i31 = load ptr, ptr %false_val2.i14, align 8
  %_17.i32 = select i1 %c5, ptr %_18.i30, ptr %_19.i31, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i206207 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i32) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit208 unwind label %cleanup.i21

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit208: ; preds = %bb8.i29
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit34

bb15.i22:                                         ; preds = %bb12.i25, %cleanup.i21
  %98 = load i8, ptr %_21.i11, align 1
  %99 = trunc nuw i8 %98 to i1
  br i1 %99, label %bb14.i24, label %bb11.i23

bb12.i25:                                         ; preds = %cleanup.i21
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i13) #21
          to label %bb15.i22 unwind label %terminate.i26

terminate.i26:                                    ; preds = %bb12.i25
  %100 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i23:                                         ; preds = %bb14.i24, %bb15.i22
  %101 = load ptr, ptr %6, align 8
  %102 = getelementptr inbounds i8, ptr %6, i64 8
  %103 = load i32, ptr %102, align 8
  %104 = insertvalue { ptr, i32 } poison, ptr %101, 0
  %105 = insertvalue { ptr, i32 } %104, i32 %103, 1
  resume { ptr, i32 } %105

bb14.i24:                                         ; preds = %bb15.i22
  br label %bb11.i23

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit34: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit208
  store i8 0, ptr %_20.i12, align 1
  store i8 0, ptr %_21.i, align 1
  store i8 0, ptr %_20.i, align 1
  store i8 1, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i226 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i197198)
  store ptr %_2.i.i226, ptr %true_val1.i, align 8
  store i8 0, ptr %_21.i, align 1
; call <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
  %_2.i.i225 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %_0.i203204)
  store ptr %_2.i.i225, ptr %false_val2.i, align 8
  %guard3.i = select i1 %c5, ptr %true_val1.i, ptr %false_val2.i, !unpredictable !304
  %drop.i = select i1 %c5, ptr %false_val2.i, ptr %true_val1.i, !unpredictable !304
  store i8 1, ptr %_20.i, align 1
  store ptr %guard3.i, ptr %guard.i, align 8
  br label %bb7.i

cleanup.i:                                        ; preds = %bb8.i, %bb7.i
  %106 = landingpad { ptr, i32 }
          cleanup
  %107 = extractvalue { ptr, i32 } %106, 0
  %108 = extractvalue { ptr, i32 } %106, 1
  store ptr %107, ptr %7, align 8
  %109 = getelementptr inbounds i8, ptr %7, i64 8
  store i32 %108, ptr %109, align 8
  %110 = load i8, ptr %_20.i, align 1
  %111 = trunc nuw i8 %110 to i1
  br i1 %111, label %bb12.i, label %bb15.i

bb7.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit34
  store i8 0, ptr %_20.i, align 1
  %_16.i = load ptr, ptr %guard.i, align 8
; invoke core::mem::forget::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr %_16.i)
          to label %bb8.i unwind label %cleanup.i

bb8.i:                                            ; preds = %bb7.i
  %_18.i = load ptr, ptr %true_val1.i, align 8
  %_19.i = load ptr, ptr %false_val2.i, align 8
  %_17.i = select i1 %c5, ptr %_18.i, ptr %_19.i, !unpredictable !304
; invoke core::mem::transmute_neo::<core::mem::maybe_uninit::MaybeUninit<*const i32>, *const i32>
  %_0.i209210 = invoke ptr @_RINvNtCsl10jNU3mE6R_4core3mem13transmute_neoINtNtB2_12maybe_uninit11MaybeUninitPlEB1f_ECs1VtPVuSYnoF_10intrinsics(ptr %_17.i) #23
          to label %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit211 unwind label %cleanup.i

_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit211: ; preds = %bb8.i
  br label %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit

bb15.i:                                           ; preds = %bb12.i, %cleanup.i
  %112 = load i8, ptr %_21.i, align 1
  %113 = trunc nuw i8 %112 to i1
  br i1 %113, label %bb14.i, label %bb11.i

bb12.i:                                           ; preds = %cleanup.i
; invoke core::ptr::drop_glue::<core::hint::select_unpredictable::DropOnPanic<*const i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNvNtB4_4hint20select_unpredictable11DropOnPanicPlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %guard.i) #21
          to label %bb15.i unwind label %terminate.i

terminate.i:                                      ; preds = %bb12.i
  %114 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb11.i:                                           ; preds = %bb14.i, %bb15.i
  %115 = load ptr, ptr %7, align 8
  %116 = getelementptr inbounds i8, ptr %7, i64 8
  %117 = load i32, ptr %116, align 8
  %118 = insertvalue { ptr, i32 } poison, ptr %115, 0
  %119 = insertvalue { ptr, i32 } %118, i32 %117, 1
  resume { ptr, i32 } %119

bb14.i:                                           ; preds = %bb15.i
  br label %bb11.i

_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %_RNvMs1_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitINtB5_11MaybeUninitPlE11assume_initCs1VtPVuSYnoF_10intrinsics.exit211
  store i8 0, ptr %_20.i, align 1
; call core::ub_checks::check_language_ub
  %_4.i7 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i7, label %bb2.i8, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit9

bb2.i8:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i189190, ptr %dst, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit9

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit9: ; preds = %_RINvNtCsl10jNU3mE6R_4core4hint20select_unpredictablePlECs1VtPVuSYnoF_10intrinsics.exit, %bb2.i8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %dst, ptr align 4 %_0.i189190, i64 4, i1 false)
  %_0.i181 = getelementptr inbounds nuw i32, ptr %dst, i64 1
; call core::ub_checks::check_language_ub
  %_4.i4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i4, label %bb2.i5, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit6

bb2.i5:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit9
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i206207, ptr %_0.i181, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit6

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit6: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit9, %bb2.i5
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i181, ptr align 4 %_0.i206207, i64 4, i1 false)
  %_0.i180 = getelementptr inbounds nuw i32, ptr %dst, i64 2
; call core::ub_checks::check_language_ub
  %_4.i1 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i1, label %bb2.i2, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit3

bb2.i2:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit6
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i209210, ptr %_0.i180, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit3

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit3: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit6, %bb2.i2
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i180, ptr align 4 %_0.i209210, i64 4, i1 false)
  %_0.i179 = getelementptr inbounds nuw i32, ptr %dst, i64 3
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit3
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i191192, ptr %_0.i179, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit3, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i179, ptr align 4 %_0.i191192, i64 4, i1 false)
  ret void
}

; core::slice::sort::shared::smallsort::sort8_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v_base, ptr %dst, ptr %scratch_base, ptr %is_less) unnamed_addr #1 !guid !305 {
start:
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v_base, ptr %scratch_base, ptr %is_less)
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v_base, i64 4
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch_base, i64 4
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_0.i1, ptr %_0.i, ptr %is_less)
; call core::slice::raw::from_raw_parts::<i32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECs1VtPVuSYnoF_10intrinsics(ptr %scratch_base, i64 8, ptr align 8 @alloc_0ab1672cf9b06a39e5138e5643964c99) #23
  %_12.0 = extractvalue { ptr, i64 } %0, 0
  %_12.1 = extractvalue { ptr, i64 } %0, 1
; call core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_12.0, i64 %_12.1, ptr %dst, ptr %is_less)
  ret void
}

; core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr %dst, ptr %is_less) unnamed_addr #1 !guid !306 {
start:
  %_0.i30 = alloca [8 x i8], align 8
  %src.i3 = alloca [8 x i8], align 8
  %dst.i4 = alloca [8 x i8], align 8
  %right_src.i5 = alloca [8 x i8], align 8
  %left_src.i6 = alloca [8 x i8], align 8
  %src.i = alloca [8 x i8], align 8
  %dst.i = alloca [8 x i8], align 8
  %right_src.i = alloca [8 x i8], align 8
  %left_src.i = alloca [8 x i8], align 8
  %last_src = alloca [8 x i8], align 8
  %_35 = alloca [24 x i8], align 8
  %_28 = alloca [24 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %dst_rev = alloca [8 x i8], align 8
  %right_rev = alloca [8 x i8], align 8
  %left_rev = alloca [8 x i8], align 8
  %dst1 = alloca [8 x i8], align 8
  %right = alloca [8 x i8], align 8
  %left = alloca [8 x i8], align 8
  %len_div_2 = udiv i64 %v.1, 2
  %_8 = icmp ne i64 %len_div_2, 0
  store ptr %v.0, ptr %left, align 8
  %_0.i48 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  store ptr %_0.i48, ptr %right, align 8
  store ptr %dst, ptr %dst1, align 8
  %_13 = sub i64 %len_div_2, 1
  %_0.i47 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_13
  store ptr %_0.i47, ptr %left_rev, align 8
  %_15 = sub i64 %v.1, 1
  %_0.i46 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_15
  store ptr %_0.i46, ptr %right_rev, align 8
  %_17 = load ptr, ptr %dst1, align 8
  %_18 = sub i64 %v.1, 1
  %_0.i29 = getelementptr inbounds nuw i32, ptr %_17, i64 %_18
  store ptr %_0.i29, ptr %dst_rev, align 8
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %0 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %len_div_2) #23
  %_19.0 = extractvalue { i64, i64 } %0, 0
  %_19.1 = extractvalue { i64, i64 } %0, 1
  store i64 %_19.0, ptr %iter, align 8
  %1 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_19.1, ptr %1, align 8
  br label %bb8

bb8:                                              ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit, %start
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %2 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #23
  %_22.0 = extractvalue { i64, i64 } %2, 0
  %_22.1 = extractvalue { i64, i64 } %2, 1
  %3 = trunc nuw i64 %_22.0 to i1
  br i1 %3, label %bb11, label %bb12

bb11:                                             ; preds = %bb8
  %_29 = load ptr, ptr %left, align 8
  %_30 = load ptr, ptr %right, align 8
  %_31 = load ptr, ptr %dst1, align 8
  store ptr %_29, ptr %left_src.i6, align 8
  store ptr %_30, ptr %right_src.i5, align 8
  store ptr %_31, ptr %dst.i4, align 8
  %_8.i7 = load ptr, ptr %right_src.i5, align 8
  %_9.i8 = load ptr, ptr %left_src.i6, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_6.i9 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_8.i7, ptr align 4 %_9.i8) #23
  %is_l.i10 = xor i1 %_6.i9, true
  br i1 %is_l.i10, label %bb2.i28, label %bb3.i11

bb3.i11:                                          ; preds = %bb11
  %4 = load ptr, ptr %right_src.i5, align 8
  store ptr %4, ptr %src.i3, align 8
  br label %bb4.i12

bb2.i28:                                          ; preds = %bb11
  %5 = load ptr, ptr %left_src.i6, align 8
  store ptr %5, ptr %src.i3, align 8
  br label %bb4.i12

bb4.i12:                                          ; preds = %bb2.i28, %bb3.i11
  %_12.i13 = load ptr, ptr %src.i3, align 8
  %_13.i14 = load ptr, ptr %dst.i4, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i15 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i.i15, label %bb2.i.i27, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb2.i.i27:                                        ; preds = %bb4.i12
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_12.i13, ptr %_13.i14, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb4.i12, %bb2.i.i27
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_13.i14, ptr align 4 %_12.i13, i64 4, i1 false)
  %_15.i16 = load ptr, ptr %right_src.i5, align 8
  %_16.i18 = zext i1 %_6.i9 to i64
  %_0.i43 = getelementptr inbounds nuw i32, ptr %_15.i16, i64 %_16.i18
  store ptr %_0.i43, ptr %right_src.i5, align 8
  %_19.i20 = load ptr, ptr %left_src.i6, align 8
  %_20.i = zext i1 %is_l.i10 to i64
  %_0.i42 = getelementptr inbounds nuw i32, ptr %_19.i20, i64 %_20.i
  store ptr %_0.i42, ptr %left_src.i6, align 8
  %_22.i22 = load ptr, ptr %dst.i4, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_22.i22, i64 1
  store ptr %_0.i, ptr %dst.i4, align 8
  %_23.i24 = load ptr, ptr %left_src.i6, align 8
  %_24.i25 = load ptr, ptr %right_src.i5, align 8
  %_25.i26 = load ptr, ptr %dst.i4, align 8
  store ptr %_23.i24, ptr %_28, align 8
  %6 = getelementptr inbounds i8, ptr %_28, i64 8
  store ptr %_24.i25, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %_28, i64 16
  store ptr %_25.i26, ptr %7, align 8
  %_25 = load ptr, ptr %_28, align 8
  %8 = getelementptr inbounds i8, ptr %_28, i64 8
  %_26 = load ptr, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_28, i64 16
  %_27 = load ptr, ptr %9, align 8
  store ptr %_25, ptr %left, align 8
  store ptr %_26, ptr %right, align 8
  store ptr %_27, ptr %dst1, align 8
  %_36 = load ptr, ptr %left_rev, align 8
  %_37 = load ptr, ptr %right_rev, align 8
  %_38 = load ptr, ptr %dst_rev, align 8
  store ptr %_36, ptr %left_src.i, align 8
  store ptr %_37, ptr %right_src.i, align 8
  store ptr %_38, ptr %dst.i, align 8
  %_8.i = load ptr, ptr %right_src.i, align 8
  %_9.i = load ptr, ptr %left_src.i, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_6.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_8.i, ptr align 4 %_9.i) #23
  %is_l.i = xor i1 %_6.i, true
  br i1 %is_l.i, label %bb2.i2, label %bb3.i

bb3.i:                                            ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit
  %10 = load ptr, ptr %left_src.i, align 8
  store ptr %10, ptr %src.i, align 8
  br label %bb4.i

bb2.i2:                                           ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort8merge_uplNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit
  %11 = load ptr, ptr %right_src.i, align 8
  store ptr %11, ptr %src.i, align 8
  br label %bb4.i

bb4.i:                                            ; preds = %bb2.i2, %bb3.i
  %_12.i = load ptr, ptr %src.i, align 8
  %_13.i = load ptr, ptr %dst.i, align 8
; call core::ub_checks::check_language_ub
  %_4.i.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i.i, label %bb2.i.i, label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb2.i.i:                                          ; preds = %bb4.i
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_12.i, ptr %_13.i, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort10merge_downlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb4.i, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_13.i, ptr align 4 %_12.i, i64 4, i1 false)
  %_15.i = load ptr, ptr %right_src.i, align 8
  %_16.i = zext i1 %is_l.i to i64
  %_0.i52 = sub i64 0, %_16.i
  %_0.i38 = getelementptr i32, ptr %_15.i, i64 %_0.i52
  store ptr %_0.i38, ptr %right_src.i, align 8
  %_18.i = load ptr, ptr %left_src.i, align 8
  %_19.i = zext i1 %_6.i to i64
  %_0.i51 = sub i64 0, %_19.i
  %_0.i39 = getelementptr i32, ptr %_18.i, i64 %_0.i51
  store ptr %_0.i39, ptr %left_src.i, align 8
  %_22.i = load ptr, ptr %dst.i, align 8
  %12 = getelementptr inbounds i32, ptr %_22.i, i64 -1
  store ptr %12, ptr %_0.i30, align 8
  %13 = load ptr, ptr %_0.i30, align 8
  store ptr %13, ptr %dst.i, align 8
  %_23.i = load ptr, ptr %left_src.i, align 8
  %_24.i = load ptr, ptr %right_src.i, align 8
  %_25.i = load ptr, ptr %dst.i, align 8
  store ptr %_23.i, ptr %_35, align 8
  %14 = getelementptr inbounds i8, ptr %_35, i64 8
  store ptr %_24.i, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %_35, i64 16
  store ptr %_25.i, ptr %15, align 8
  %_32 = load ptr, ptr %_35, align 8
  %16 = getelementptr inbounds i8, ptr %_35, i64 8
  %_33 = load ptr, ptr %16, align 8
  %17 = getelementptr inbounds i8, ptr %_35, i64 16
  %_34 = load ptr, ptr %17, align 8
  store ptr %_32, ptr %left_rev, align 8
  store ptr %_33, ptr %right_rev, align 8
  store ptr %_34, ptr %dst_rev, align 8
  br label %bb8

bb12:                                             ; preds = %bb8
  %_40 = load ptr, ptr %left_rev, align 8
  %_0.i40 = getelementptr i32, ptr %_40, i64 1
  %_42 = load ptr, ptr %right_rev, align 8
  %_0.i41 = getelementptr i32, ptr %_42, i64 1
; call <usize>::is_multiple_of
  %_43 = call zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCs1VtPVuSYnoF_10intrinsics(i64 %v.1, i64 2) #23
  br i1 %_43, label %bb25, label %bb18

bb18:                                             ; preds = %bb12
  %_45 = load ptr, ptr %left, align 8
  %left_nonempty = icmp ult ptr %_45, %_0.i40
  br i1 %left_nonempty, label %bb19, label %bb20

bb25:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit, %bb12
  %_58 = load ptr, ptr %left, align 8
  %_57 = icmp ne ptr %_58, %_0.i40
  br i1 %_57, label %bb27, label %bb26

bb20:                                             ; preds = %bb18
  %18 = load ptr, ptr %right, align 8
  store ptr %18, ptr %last_src, align 8
  br label %bb21

bb19:                                             ; preds = %bb18
  %19 = load ptr, ptr %left, align 8
  store ptr %19, ptr %last_src, align 8
  br label %bb21

bb21:                                             ; preds = %bb19, %bb20
  %_48 = load ptr, ptr %last_src, align 8
  %_49 = load ptr, ptr %dst1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_48, ptr %_49, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb21, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_49, ptr align 4 %_48, i64 4, i1 false)
  %_51 = load ptr, ptr %left, align 8
  %_52 = zext i1 %left_nonempty to i64
  %_0.i45 = getelementptr inbounds nuw i32, ptr %_51, i64 %_52
  store ptr %_0.i45, ptr %left, align 8
  %_54 = load ptr, ptr %right, align 8
  %_56 = xor i1 %left_nonempty, true
  %_55 = zext i1 %_56 to i64
  %_0.i44 = getelementptr inbounds nuw i32, ptr %_54, i64 %_55
  store ptr %_0.i44, ptr %right, align 8
  br label %bb25

bb26:                                             ; preds = %bb25
  %_60 = load ptr, ptr %right, align 8
  %_59 = icmp ne ptr %_60, %_0.i41
  br i1 %_59, label %bb27, label %bb28

bb27:                                             ; preds = %bb26, %bb25
; call core::slice::sort::shared::smallsort::panic_on_ord_violation
  call void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() #27
  unreachable

bb28:                                             ; preds = %bb26
  ret void

bb10:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::shared::smallsort::insertion_sort_shift_left::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %offset, ptr %is_less) unnamed_addr #1 !guid !307 {
start:
  %tail = alloca [8 x i8], align 8
  %_6 = icmp eq i64 %offset, 0
  br i1 %_6, label %bb2, label %bb1

bb1:                                              ; preds = %start
  %_7 = icmp ugt i64 %offset, %v.1
  br i1 %_7, label %bb2, label %bb3

bb2:                                              ; preds = %bb1, %start
  call void @llvm.trap()
  unreachable

bb3:                                              ; preds = %bb1
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %v.1
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %offset
  store ptr %_0.i1, ptr %tail, align 8
  br label %bb6

bb6:                                              ; preds = %bb7, %bb3
  %_13 = load ptr, ptr %tail, align 8
  %_12 = icmp ne ptr %_13, %_0.i2
  br i1 %_12, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  ret void

bb7:                                              ; preds = %bb6
  %_15 = load ptr, ptr %tail, align 8
; call core::slice::sort::shared::smallsort::insert_tail::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v.0, ptr %_15, ptr %is_less)
  %_17 = load ptr, ptr %tail, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_17, i64 1
  store ptr %_0.i, ptr %tail, align 8
  br label %bb6
}

; core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !308 {
start:
  %0 = alloca [16 x i8], align 8
  %_74 = alloca [1 x i8], align 1
  %_73 = alloca [24 x i8], align 8
  %drop_guard = alloca [24 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %iter1 = alloca [16 x i8], align 8
  %desired_len = alloca [8 x i8], align 8
  %_42 = alloca [16 x i8], align 8
  %iter = alloca [32 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_39 = alloca [32 x i8], align 8
  %presorted_len = alloca [8 x i8], align 8
  store i8 0, ptr %_74, align 1
  %_6 = icmp ult i64 %v.1, 2
  br i1 %_6, label %bb50, label %bb1

bb1:                                              ; preds = %start
  %_10 = add i64 %v.1, 16
  %_7 = icmp ult i64 %scratch.1, %_10
  br i1 %_7, label %bb2, label %bb3

bb50:                                             ; preds = %bb49, %start
  ret void

bb3:                                              ; preds = %bb1
  %len_div_2 = udiv i64 %v.1, 2
  br label %bb7

bb2:                                              ; preds = %bb1
  call void @llvm.trap()
  unreachable

bb7:                                              ; preds = %bb3
  %_18 = icmp uge i64 %v.1, 16
  br i1 %_18, label %bb8, label %bb15

bb15:                                             ; preds = %bb7
  %_26 = icmp uge i64 %v.1, 8
  br i1 %_26, label %bb16, label %bb21

bb8:                                              ; preds = %bb7
  %_0.i16 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %v.1
; call core::slice::sort::shared::smallsort::sort8_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v.0, ptr %scratch.0, ptr %_0.i16, ptr %is_less)
  %_0.i15 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i14 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
  %_25 = add i64 %v.1, 8
  %_0.i13 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_25
; call core::slice::sort::shared::smallsort::sort8_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort8_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_0.i15, ptr %_0.i14, ptr %_0.i13, ptr %is_less)
  store i64 8, ptr %presorted_len, align 8
  br label %bb26

bb21:                                             ; preds = %bb15
; call core::ub_checks::check_language_ub
  %_4.i6 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i6, label %bb2.i7, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit8

bb2.i7:                                           ; preds = %bb21
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %v.0, ptr %scratch.0, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit8

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit8: ; preds = %bb21, %bb2.i7
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %scratch.0, ptr align 4 %v.0, i64 4, i1 false)
  %_0.i20 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i19 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i4, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit5

bb2.i4:                                           ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit8
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i20, ptr %_0.i19, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit5

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit5: ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit8, %bb2.i4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i19, ptr align 4 %_0.i20, i64 4, i1 false)
  store i64 1, ptr %presorted_len, align 8
  br label %bb26

bb16:                                             ; preds = %bb15
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %v.0, ptr %scratch.0, ptr %is_less)
  %_0.i18 = getelementptr inbounds nuw i32, ptr %v.0, i64 %len_div_2
  %_0.i17 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %len_div_2
; call core::slice::sort::shared::smallsort::sort4_stable::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort12sort4_stablelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_0.i18, ptr %_0.i17, ptr %is_less)
  store i64 4, ptr %presorted_len, align 8
  br label %bb26

bb26:                                             ; preds = %bb8, %bb16, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit5
  %1 = getelementptr inbounds nuw i64, ptr %_40, i64 0
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds nuw i64, ptr %_40, i64 1
  store i64 %len_div_2, ptr %2, align 8
; call <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
  call void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8 %_39, ptr align 8 %_40) #23
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_39, i64 32, i1 false)
  br label %bb28

bb28:                                             ; preds = %bb40, %bb26
; invoke <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
  %3 = invoke { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8 %iter)
          to label %bb29 unwind label %cleanup

bb51:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter) #21
          to label %bb52 unwind label %terminate

cleanup:                                          ; preds = %bb43, %bb45, %bb39, %bb37, %bb28
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb51

bb29:                                             ; preds = %bb28
  %8 = extractvalue { i64, i64 } %3, 0
  %9 = extractvalue { i64, i64 } %3, 1
  store i64 %8, ptr %_42, align 8
  %10 = getelementptr inbounds i8, ptr %_42, i64 8
  store i64 %9, ptr %10, align 8
  %_44 = load i64, ptr %_42, align 8
  %11 = getelementptr inbounds i8, ptr %_42, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = trunc nuw i64 %_44 to i1
  br i1 %13, label %bb31, label %bb32

bb31:                                             ; preds = %bb29
  %14 = getelementptr inbounds i8, ptr %_42, i64 8
  %offset = load i64, ptr %14, align 8
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %offset
  br label %bb33

bb32:                                             ; preds = %bb29
; call core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8 %iter)
  store i8 1, ptr %_74, align 1
  store ptr %scratch.0, ptr %drop_guard, align 8
  %15 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  store ptr %v.0, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  store i64 %v.1, ptr %16, align 8
  %_69 = load ptr, ptr %drop_guard, align 8
  %17 = getelementptr inbounds i8, ptr %drop_guard, i64 16
  %_70 = load i64, ptr %17, align 8
; invoke core::slice::raw::from_raw_parts::<i32>
  %18 = invoke { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_partslECs1VtPVuSYnoF_10intrinsics(ptr %_69, i64 %_70, ptr align 8 @alloc_dea82b1a5cc143169db7b7d27413b6f6)
          to label %bb47 unwind label %cleanup2

bb54:                                             ; preds = %cleanup2
  %19 = load i8, ptr %_74, align 1
  %20 = trunc nuw i8 %19 to i1
  br i1 %20, label %bb53, label %bb52

cleanup2:                                         ; preds = %bb48, %bb47, %bb32
  %21 = landingpad { ptr, i32 }
          cleanup
  %22 = extractvalue { ptr, i32 } %21, 0
  %23 = extractvalue { ptr, i32 } %21, 1
  store ptr %22, ptr %0, align 8
  %24 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %23, ptr %24, align 8
  br label %bb54

bb47:                                             ; preds = %bb32
  %_68.0 = extractvalue { ptr, i64 } %18, 0
  %_68.1 = extractvalue { ptr, i64 } %18, 1
  %25 = getelementptr inbounds i8, ptr %drop_guard, i64 8
  %_71 = load ptr, ptr %25, align 8
; invoke core::slice::sort::shared::smallsort::bidirectional_merge::<i32, <i32 as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort19bidirectional_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_68.0, i64 %_68.1, ptr %_71, ptr %is_less)
          to label %bb48 unwind label %cleanup2

bb48:                                             ; preds = %bb47
  store i8 0, ptr %_74, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_73, ptr align 8 %drop_guard, i64 24, i1 false)
; invoke core::mem::forget::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem6forgetINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_73)
          to label %bb49 unwind label %cleanup2

bb49:                                             ; preds = %bb48
  store i8 0, ptr %_74, align 1
  br label %bb50

bb52:                                             ; preds = %bb51, %bb53, %bb54
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr inbounds i8, ptr %0, i64 8
  %28 = load i32, ptr %27, align 8
  %29 = insertvalue { ptr, i32 } poison, ptr %26, 0
  %30 = insertvalue { ptr, i32 } %29, i32 %28, 1
  resume { ptr, i32 } %30

bb53:                                             ; preds = %bb54
; invoke core::ptr::drop_glue::<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6shared9smallsort10CopyOnDroplEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %drop_guard) #21
          to label %bb52 unwind label %terminate

terminate:                                        ; preds = %bb51, %bb53
  %31 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb33:                                             ; preds = %bb31
  %_0.i11 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %offset
  br label %bb34

bb34:                                             ; preds = %bb33
  %_49 = icmp eq i64 %offset, 0
  br i1 %_49, label %bb35, label %bb36

bb36:                                             ; preds = %bb34
  %32 = sub i64 %v.1, %len_div_2
  store i64 %32, ptr %desired_len, align 8
  br label %bb37

bb35:                                             ; preds = %bb34
  store i64 %len_div_2, ptr %desired_len, align 8
  br label %bb37

bb37:                                             ; preds = %bb35, %bb36
  %_52 = load i64, ptr %presorted_len, align 8
  %_53 = load i64, ptr %desired_len, align 8
; invoke <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %33 = invoke { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 %_52, i64 %_53)
          to label %bb38 unwind label %cleanup

bb38:                                             ; preds = %bb37
  %_50.0 = extractvalue { i64, i64 } %33, 0
  %_50.1 = extractvalue { i64, i64 } %33, 1
  store i64 %_50.0, ptr %iter1, align 8
  %34 = getelementptr inbounds i8, ptr %iter1, i64 8
  store i64 %_50.1, ptr %34, align 8
  br label %bb39

bb39:                                             ; preds = %bb55, %bb38
; invoke <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %35 = invoke { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter1)
          to label %bb40 unwind label %cleanup

bb40:                                             ; preds = %bb39
  %36 = extractvalue { i64, i64 } %35, 0
  %37 = extractvalue { i64, i64 } %35, 1
  store i64 %36, ptr %_55, align 8
  %38 = getelementptr inbounds i8, ptr %_55, i64 8
  store i64 %37, ptr %38, align 8
  %_57 = load i64, ptr %_55, align 8
  %39 = getelementptr inbounds i8, ptr %_55, i64 8
  %40 = load i64, ptr %39, align 8
  %41 = trunc nuw i64 %_57 to i1
  br i1 %41, label %bb41, label %bb28

bb41:                                             ; preds = %bb40
  %42 = getelementptr inbounds i8, ptr %_55, i64 8
  %i = load i64, ptr %42, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %_0.i12, i64 %i
  br label %bb42

bb42:                                             ; preds = %bb41
  %_0.i9 = getelementptr inbounds nuw i32, ptr %_0.i11, i64 %i
  br label %bb43

bb43:                                             ; preds = %bb42
; invoke core::ub_checks::check_language_ub
  %_4.i3 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
          to label %_4.i.noexc unwind label %cleanup

_4.i.noexc:                                       ; preds = %bb43
  br i1 %_4.i3, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %_4.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i10, ptr %_0.i9, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %_4.i.noexc, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i9, ptr align 4 %_0.i10, i64 4, i1 false)
  br label %bb44

bb44:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
  %_0.i = getelementptr inbounds nuw i32, ptr %_0.i11, i64 %i
  br label %bb45

bb45:                                             ; preds = %bb44
; invoke core::slice::sort::shared::smallsort::insert_tail::<i32, <i32 as core::cmp::PartialOrd>::lt>
  invoke void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort11insert_taillNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr %_0.i11, ptr %_0.i, ptr %is_less)
          to label %bb55 unwind label %cleanup

bb55:                                             ; preds = %bb45
  br label %bb39

bb30:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::drift::create_run::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %min_good_run_len, i1 zeroext %eager_sort, ptr %is_less) unnamed_addr #1 !guid !309 {
start:
  %run_len.i = alloca [8 x i8], align 8
  %_0.i = alloca [16 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_8 = icmp uge i64 %v.1, %min_good_run_len
  br i1 %_8, label %bb1, label %bb7

bb7:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNvYlNtNtB8_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit, %start
  br i1 %eager_sort, label %bb8, label %bb13

bb1:                                              ; preds = %start
  %_4.i = icmp ult i64 %v.1, 2
  br i1 %_4.i, label %bb1.i, label %bb2.i

bb2.i:                                            ; preds = %bb1
  store i64 2, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_8.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 1, ptr align 8 @alloc_b1a59a7585543a4a25115f0cbf40f484) #23
; call <[i32]>::get_unchecked::<usize>
  %_9.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 0, ptr align 8 @alloc_4e95ed00d8479deaf9b8943b85759bde) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %strictly_descending.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_8.i, ptr align 4 %_9.i) #23
  br i1 %strictly_descending.i, label %bb6.i, label %bb12.i

bb1.i:                                            ; preds = %bb1
  store i64 %v.1, ptr %_0.i, align 8
  %0 = getelementptr inbounds i8, ptr %_0.i, i64 8
  store i8 0, ptr %0, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNvYlNtNtB8_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb12.i:                                           ; preds = %bb17.i, %bb2.i
  %_20.i = load i64, ptr %run_len.i, align 8
  %_19.i = icmp ult i64 %_20.i, %v.1
  br i1 %_19.i, label %bb13.i, label %bb18.i

bb6.i:                                            ; preds = %bb11.i, %bb2.i
  %_11.i = load i64, ptr %run_len.i, align 8
  %_10.i = icmp ult i64 %_11.i, %v.1
  br i1 %_10.i, label %bb7.i, label %bb18.i

bb18.i:                                           ; preds = %bb7.i, %bb13.i, %bb6.i, %bb12.i
  %_28.i = load i64, ptr %run_len.i, align 8
  store i64 %_28.i, ptr %_0.i, align 8
  %1 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %2 = zext i1 %strictly_descending.i to i8
  store i8 %2, ptr %1, align 8
  br label %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNvYlNtNtB8_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb13.i:                                           ; preds = %bb12.i
  %_24.i = load i64, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_23.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %_24.i, ptr align 8 @alloc_0aa54d60960e578bf5dc3db64f9182b2) #23
  %_27.i = load i64, ptr %run_len.i, align 8
  %_26.i = sub i64 %_27.i, 1
; call <[i32]>::get_unchecked::<usize>
  %_25.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %_26.i, ptr align 8 @alloc_34d92db687bf3e85a75e319cac8072d0) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_21.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_23.i, ptr align 4 %_25.i) #23
  br i1 %_21.i, label %bb18.i, label %bb17.i

bb17.i:                                           ; preds = %bb13.i
  %3 = load i64, ptr %run_len.i, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %run_len.i, align 8
  br label %bb12.i

bb7.i:                                            ; preds = %bb6.i
  %_15.i = load i64, ptr %run_len.i, align 8
; call <[i32]>::get_unchecked::<usize>
  %_14.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %_15.i, ptr align 8 @alloc_3a54043bf62a6816be5c3584bd0aab69) #23
  %_18.i = load i64, ptr %run_len.i, align 8
  %_17.i = sub i64 %_18.i, 1
; call <[i32]>::get_unchecked::<usize>
  %_16.i = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSl13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %_17.i, ptr align 8 @alloc_435a452c7ddb8b633a1045ff18a4d695) #23
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_12.i = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_14.i, ptr align 4 %_16.i) #23
  br i1 %_12.i, label %bb11.i, label %bb18.i

bb11.i:                                           ; preds = %bb7.i
  %5 = load i64, ptr %run_len.i, align 8
  %6 = add i64 %5, 1
  store i64 %6, ptr %run_len.i, align 8
  br label %bb6.i

_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNvYlNtNtB8_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb1.i, %bb18.i
  %7 = load i64, ptr %_0.i, align 8
  %8 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %9 = load i8, ptr %8, align 8
  %10 = trunc nuw i8 %9 to i1
  %11 = insertvalue { i64, i1 } poison, i64 %7, 0
  %12 = insertvalue { i64, i1 } %11, i1 %10, 1
  %_11.0 = extractvalue { i64, i1 } %12, 0
  %_11.1 = extractvalue { i64, i1 } %12, 1
  %_13 = icmp ule i64 %_11.0, %v.1
  %_14 = icmp uge i64 %_11.0, %min_good_run_len
  br i1 %_14, label %bb3, label %bb7

bb3:                                              ; preds = %_RINvNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared17find_existing_runlNvYlNtNtB8_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit
  br i1 %_11.1, label %bb4, label %bb6

bb13:                                             ; preds = %bb7
; call core::cmp::min::<usize>
  %_24 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %min_good_run_len, i64 %v.1) #23
  %_2.i3 = shl i64 %_24, 1
  store i64 %_2.i3, ptr %_0, align 8
  br label %bb15

bb8:                                              ; preds = %bb7
; call core::cmp::min::<usize>
  %eager_run_len = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 32, i64 %v.1) #23
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %13 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %eager_run_len, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_ea3823fa310c0ac95d0d5924e997a992) #23
  %_0.0.i4 = extractvalue { ptr, i64 } %13, 0
  %_0.1.i5 = extractvalue { ptr, i64 } %13, 1
  %_21.0 = extractvalue { ptr, i64 } %13, 0
  %_21.1 = extractvalue { ptr, i64 } %13, 1
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_21.0, i64 %_21.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 0, ptr align 4 null, ptr %is_less) #25
  %_3.i1 = shl i64 %eager_run_len, 1
  %_2.i2 = or i64 %_3.i1, 1
  store i64 %_2.i2, ptr %_0, align 8
  br label %bb15

bb15:                                             ; preds = %bb6, %bb8, %bb13
  %14 = load i64, ptr %_0, align 8
  ret i64 %14

bb6:                                              ; preds = %bb4, %bb3
  %_3.i = shl i64 %_11.0, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0, align 8
  br label %bb15

bb4:                                              ; preds = %bb3
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %15 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %_11.0, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_0b170457ff613254af1d0cbd2a159dca) #23
  %_0.0.i = extractvalue { ptr, i64 } %15, 0
  %_0.1.i = extractvalue { ptr, i64 } %15, 1
  %_16.0 = extractvalue { ptr, i64 } %15, 0
  %_16.1 = extractvalue { ptr, i64 } %15, 1
; call <[i32]>::reverse
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl7reverseCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_16.0, i64 %_16.1) #23
  br label %bb6
}

; core::slice::sort::stable::drift::stable_quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less) unnamed_addr #1 !guid !310 {
start:
  %_6 = or i64 %v.1, 1
; call <usize>::ilog2
  %_5 = call i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %_6, ptr align 8 @alloc_5b26bc7b45e7e23728885c9a7d45b9d3) #23
  %limit = mul i32 2, %_5
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %limit, ptr align 4 null, ptr %is_less) #25
  ret void
}

; core::slice::sort::stable::drift::sort::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i1 zeroext %eager_sort, ptr %is_less) unnamed_addr #1 !guid !311 {
start:
  %_0.i = alloca [8 x i8], align 8
  %desired_depth = alloca [1 x i8], align 1
  %next_run = alloca [8 x i8], align 8
  %prev_run = alloca [8 x i8], align 8
  %scan_idx = alloca [8 x i8], align 8
  %desired_depth_storage = alloca [66 x i8], align 1
  %run_storage = alloca [528 x i8], align 8
  %stack_len = alloca [8 x i8], align 8
  %min_good_run_len = alloca [8 x i8], align 8
  %_7 = icmp ult i64 %v.1, 2
  br i1 %_7, label %bb39, label %bb1

bb1:                                              ; preds = %start
; call <u64>::div_ceil
  %_0.i26 = call i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCs1VtPVuSYnoF_10intrinsics(i64 4611686018427387904, i64 %v.1, ptr align 8 @alloc_945f2c369c171e278c4be97205a79e9b) #23
  %_10 = icmp ule i64 %v.1, 4096
  br i1 %_10, label %bb3, label %bb5

bb39:                                             ; preds = %bb38, %bb34, %start
  ret void

bb5:                                              ; preds = %bb1
; call core::slice::sort::stable::drift::sqrt_approx
  %0 = call i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64 %v.1)
  store i64 %0, ptr %min_good_run_len, align 8
  br label %bb6

bb3:                                              ; preds = %bb1
  %_13 = udiv i64 %v.1, 2
  %_12 = sub i64 %v.1, %_13
; call core::cmp::min::<usize>
  %1 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %_12, i64 64) #23
  store i64 %1, ptr %min_good_run_len, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb5
  store i64 0, ptr %stack_len, align 8
  store i64 0, ptr %scan_idx, align 8
  store i64 1, ptr %prev_run, align 8
  br label %bb13

bb13:                                             ; preds = %bb35, %bb6
  %_29 = load i64, ptr %scan_idx, align 8
  %_28 = icmp ult i64 %_29, %v.1
  br i1 %_28, label %bb14, label %bb20

bb20:                                             ; preds = %bb13
  store i64 1, ptr %next_run, align 8
  store i8 0, ptr %desired_depth, align 1
  br label %bb22

bb14:                                             ; preds = %bb13
  %_33 = load i64, ptr %scan_idx, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %2 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %_33, ptr align 4 %v.0, i64 %v.1, ptr align 8 @alloc_418d50aea1f432fc229dc42e85bc0c4e) #23
  %_0.0.i29 = extractvalue { ptr, i64 } %2, 0
  %_0.1.i30 = extractvalue { ptr, i64 } %2, 1
  %_31.0 = extractvalue { ptr, i64 } %2, 0
  %_31.1 = extractvalue { ptr, i64 } %2, 1
  %_34 = load i64, ptr %min_good_run_len, align 8
; call core::slice::sort::stable::drift::create_run::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_30 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift10create_runlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_31.0, i64 %_31.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %_34, i1 zeroext %eager_sort, ptr %is_less)
  store i64 %_30, ptr %next_run, align 8
  %_37 = load i64, ptr %scan_idx, align 8
  %_39 = load i64, ptr %prev_run, align 8
  %_0.i13 = lshr i64 %_39, 1
  %_36 = sub i64 %_37, %_0.i13
  %_40 = load i64, ptr %scan_idx, align 8
  %_42 = load i64, ptr %scan_idx, align 8
  %_44 = load i64, ptr %next_run, align 8
  %_0.i12 = lshr i64 %_44, 1
  %_41 = add i64 %_42, %_0.i12
  %x.i = add i64 %_36, %_40
  %y.i = add i64 %_40, %_41
  %_13.i = mul i64 %_0.i26, %x.i
  %_14.i = mul i64 %_0.i26, %y.i
  %_12.i = xor i64 %_13.i, %_14.i
  %3 = call i64 @llvm.ctlz.i64(i64 %_12.i, i1 false)
  %_0.i.i = trunc i64 %3 to i32
  %_0.i24 = trunc i32 %_0.i.i to i8
  store i8 %_0.i24, ptr %desired_depth, align 1
  br label %bb22

bb22:                                             ; preds = %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit, %bb14, %bb20
  %_47 = load i64, ptr %stack_len, align 8
  %_46 = icmp ugt i64 %_47, 1
  br i1 %_46, label %bb23, label %bb31

bb31:                                             ; preds = %bb23, %bb22
  %_69 = load i64, ptr %prev_run, align 8
  %_71 = load i64, ptr %stack_len, align 8
  %_0.i2 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_71
  store i64 %_69, ptr %_0.i2, align 8
  %_72 = load i8, ptr %desired_depth, align 1
  %_74 = load i64, ptr %stack_len, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_74
  store i8 %_72, ptr %_0.i3, align 1
  %4 = load i64, ptr %stack_len, align 8
  %5 = add i64 %4, 1
  store i64 %5, ptr %stack_len, align 8
  %_76 = load i64, ptr %scan_idx, align 8
  %_75 = icmp uge i64 %_76, %v.1
  br i1 %_75, label %bb34, label %bb35

bb23:                                             ; preds = %bb22
  %_52 = load i64, ptr %stack_len, align 8
  %_51 = sub i64 %_52, 1
  %_0.i4 = getelementptr inbounds nuw i8, ptr %desired_depth_storage, i64 %_51
  %_49 = load i8, ptr %_0.i4, align 1
  %_53 = load i8, ptr %desired_depth, align 1
  %_48 = icmp uge i8 %_49, %_53
  br i1 %_48, label %bb25, label %bb31

bb25:                                             ; preds = %bb23
  %_57 = load i64, ptr %stack_len, align 8
  %_56 = sub i64 %_57, 1
  %_0.i1 = getelementptr inbounds nuw i64, ptr %run_storage, i64 %_56
  %left = load i64, ptr %_0.i1, align 8
  %_0.i10 = lshr i64 %left, 1
  %_61 = load i64, ptr %prev_run, align 8
  %_0.i9 = lshr i64 %_61, 1
  %merged_len = add i64 %_0.i10, %_0.i9
  %_63 = load i64, ptr %scan_idx, align 8
  %merge_start_idx = sub i64 %_63, %merged_len
  %_66 = load i64, ptr %scan_idx, align 8
; call <[i32]>::get_unchecked_mut::<core::ops::range::Range<usize>>
  %6 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSl17get_unchecked_mutINtNtNtB5_3ops5range5RangejEECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, i64 %merge_start_idx, i64 %_66, ptr align 8 @alloc_289e523c22daf4b02f0ced64176f9f7d) #23
  %merge_slice.0 = extractvalue { ptr, i64 } %6, 0
  %merge_slice.1 = extractvalue { ptr, i64 } %6, 1
  %_68 = load i64, ptr %prev_run, align 8
  %can_fit_in_scratch.i = icmp ule i64 %merge_slice.1, %scratch.1
  br i1 %can_fit_in_scratch.i, label %bb1.i, label %bb5.i

bb5.i:                                            ; preds = %bb3.i, %bb1.i, %bb25
  %_2.i20 = and i64 %left, 1
  %_0.i21 = icmp eq i64 %_2.i20, 1
  br i1 %_0.i21, label %bb10.i, label %bb7.i

bb1.i:                                            ; preds = %bb25
  %_2.i16 = and i64 %left, 1
  %_0.i17 = icmp eq i64 %_2.i16, 1
  br i1 %_0.i17, label %bb5.i, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_2.i14 = and i64 %_68, 1
  %_0.i15 = icmp eq i64 %_2.i14, 1
  br i1 %_0.i15, label %bb5.i, label %bb18.i

bb18.i:                                           ; preds = %bb3.i
  %_2.i5 = shl i64 %merge_slice.1, 1
  store i64 %_2.i5, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

bb7.i:                                            ; preds = %bb5.i
  %_0.i8 = lshr i64 %left, 1
; call <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %7 = call { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %_0.i8, ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_c54bc7e12f54e1b6a5d6ee337e066d20) #23
  %_0.0.i = extractvalue { ptr, i64 } %7, 0
  %_0.1.i = extractvalue { ptr, i64 } %7, 1
  %_15.0.i = extractvalue { ptr, i64 } %7, 0
  %_15.1.i = extractvalue { ptr, i64 } %7, 1
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_15.0.i, i64 %_15.1.i, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb10.i

bb10.i:                                           ; preds = %bb7.i, %bb5.i
  %_2.i18 = and i64 %_68, 1
  %_0.i19 = icmp eq i64 %_2.i18, 1
  br i1 %_0.i19, label %bb15.i, label %bb12.i

bb12.i:                                           ; preds = %bb10.i
  %_0.i7 = lshr i64 %left, 1
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %8 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %_0.i7, ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 8 @alloc_4b0ce783e358f6d901ee99bada134993) #23
  %_0.0.i27 = extractvalue { ptr, i64 } %8, 0
  %_0.1.i28 = extractvalue { ptr, i64 } %8, 1
  %_20.0.i = extractvalue { ptr, i64 } %8, 0
  %_20.1.i = extractvalue { ptr, i64 } %8, 1
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_20.0.i, i64 %_20.1.i, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb15.i

bb15.i:                                           ; preds = %bb12.i, %bb10.i
  %_0.i6 = lshr i64 %left, 1
; call core::slice::sort::stable::merge::merge::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %merge_slice.0, i64 %merge_slice.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %_0.i6, ptr %is_less)
  %_3.i = shl i64 %merge_slice.1, 1
  %_2.i = or i64 %_3.i, 1
  store i64 %_2.i, ptr %_0.i, align 8
  br label %_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift13logical_mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb18.i, %bb15.i
  %9 = load i64, ptr %_0.i, align 8
  store i64 %9, ptr %prev_run, align 8
  %10 = load i64, ptr %stack_len, align 8
  %11 = sub i64 %10, 1
  store i64 %11, ptr %stack_len, align 8
  br label %bb22

bb35:                                             ; preds = %bb31
  %_78 = load i64, ptr %next_run, align 8
  %_0.i11 = lshr i64 %_78, 1
  %12 = load i64, ptr %scan_idx, align 8
  %13 = add i64 %12, %_0.i11
  store i64 %13, ptr %scan_idx, align 8
  %_79 = load i64, ptr %next_run, align 8
  store i64 %_79, ptr %prev_run, align 8
  br label %bb13

bb34:                                             ; preds = %bb31
  %_81 = load i64, ptr %prev_run, align 8
  %_2.i22 = and i64 %_81, 1
  %_0.i23 = icmp eq i64 %_2.i22, 1
  br i1 %_0.i23, label %bb39, label %bb38

bb38:                                             ; preds = %bb34
; call core::slice::sort::stable::drift::stable_quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift16stable_quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb39
}

; core::slice::sort::stable::merge::merge::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5merge5mergelNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %mid, ptr %is_less) unnamed_addr #1 personality ptr @rust_eh_personality !guid !312 {
start:
  %0 = alloca [16 x i8], align 8
  %merge_state = alloca [24 x i8], align 8
  %save_len = alloca [8 x i8], align 8
  %save_base = alloca [8 x i8], align 8
  %_7 = icmp eq i64 %mid, 0
  br i1 %_7, label %bb21, label %bb1

bb1:                                              ; preds = %start
  %_8 = icmp uge i64 %mid, %v.1
  br i1 %_8, label %bb21, label %bb2

bb21:                                             ; preds = %bb20, %bb2, %bb1, %start
  ret void

bb2:                                              ; preds = %bb1
  %_13 = sub i64 %v.1, %mid
; call core::cmp::min::<usize>
  %_12 = call i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64 %mid, i64 %_13) #23
  %_9 = icmp ult i64 %scratch.1, %_12
  br i1 %_9, label %bb21, label %bb4

bb4:                                              ; preds = %bb2
  %_0.i2 = getelementptr inbounds nuw i32, ptr %v.0, i64 %mid
  %_0.i1 = getelementptr inbounds nuw i32, ptr %v.0, i64 %v.1
  %right_len = sub i64 %v.1, %mid
  %left_is_shorter = icmp ule i64 %mid, %right_len
  br i1 %left_is_shorter, label %bb10, label %bb11

bb11:                                             ; preds = %bb4
  store ptr %_0.i2, ptr %save_base, align 8
  br label %bb12

bb10:                                             ; preds = %bb4
  store ptr %v.0, ptr %save_base, align 8
  br label %bb12

bb12:                                             ; preds = %bb10, %bb11
  br i1 %left_is_shorter, label %bb13, label %bb14

bb14:                                             ; preds = %bb12
  store i64 %right_len, ptr %save_len, align 8
  br label %bb15

bb13:                                             ; preds = %bb12
  store i64 %mid, ptr %save_len, align 8
  br label %bb15

bb15:                                             ; preds = %bb13, %bb14
  %_25 = load ptr, ptr %save_base, align 8
  %_26 = load i64, ptr %save_len, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb15
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_25, ptr %scratch.0, i64 4, i64 4, i64 %_26, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb15, %bb2.i
  %1 = mul nuw nsw i64 %_26, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %scratch.0, ptr align 4 %_25, i64 %1, i1 false)
  %_29 = load i64, ptr %save_len, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_29
  %_30 = load ptr, ptr %save_base, align 8
  store ptr %scratch.0, ptr %merge_state, align 8
  %2 = getelementptr inbounds i8, ptr %merge_state, i64 8
  store ptr %_0.i, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %merge_state, i64 16
  store ptr %_30, ptr %3, align 8
  br i1 %left_is_shorter, label %bb18, label %bb19

bb19:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
; invoke <core::slice::sort::stable::merge::MergeState<i32>>::merge_down::<<i32 as core::cmp::PartialOrd>::lt>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE10merge_downNvYlNtNtBb_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 8 %merge_state, ptr %v.0, ptr %scratch.0, ptr %_0.i1, ptr %is_less)
          to label %bb25 unwind label %cleanup

bb18:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit
; invoke <core::slice::sort::stable::merge::MergeState<i32>>::merge_up::<<i32 as core::cmp::PartialOrd>::lt>
  invoke void @_RINvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB3_10MergeStatelE8merge_upNvYlNtNtBb_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 8 %merge_state, ptr %_0.i2, ptr %_0.i1, ptr %is_less)
          to label %bb24 unwind label %cleanup

bb22:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %merge_state) #21
          to label %bb23 unwind label %terminate

cleanup:                                          ; preds = %bb18, %bb19
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb22

bb25:                                             ; preds = %bb19
  br label %bb20

bb20:                                             ; preds = %bb24, %bb25
; call core::ptr::drop_glue::<core::slice::sort::stable::merge::MergeState<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtNtB4_5slice4sort6stable5merge10MergeStatelEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %merge_state)
  br label %bb21

bb24:                                             ; preds = %bb18
  br label %bb20

terminate:                                        ; preds = %bb22
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb23:                                             ; preds = %bb22
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; core::slice::sort::stable::quicksort::stable_partition::<i32, core::slice::sort::stable::quicksort::quicksort<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvB2_9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltE0ECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr align 8 %is_less) unnamed_addr #1 !guid !313 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<i32, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr null) #23
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
  %_30 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %is_less, ptr align 4 %_90, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
  %_36 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %is_less, ptr align 4 %_91, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
  %_42 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %is_less, ptr align 4 %_92, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
  %_48 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %is_less, ptr align 4 %_93, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
  %_58 = call zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %is_less, ptr align 4 %_94, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECs1VtPVuSYnoF_10intrinsics()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %scratch.0, ptr %v.0, i64 4, i64 4, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %v.0, ptr align 4 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #23
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i12, ptr %_68, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_68, ptr align 4 %_0.i12, i64 4, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #23
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i9, ptr %_0.i8, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i8, ptr align 4 %_0.i9, i64 4, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::stable_partition::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %v.0, i64 %v.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext %pivot_goes_left, ptr %is_less) unnamed_addr #1 !guid !314 {
start:
  %_0.i14 = alloca [1 x i8], align 1
  %_78 = alloca [16 x i8], align 8
  %iter = alloca [16 x i8], align 8
  %loop_end_pos = alloca [8 x i8], align 8
  %pivot_in_scratch = alloca [8 x i8], align 8
  %state = alloca [32 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_10 = icmp ult i64 %scratch.1, %v.1
  br i1 %_10, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = icmp uge i64 %pivot_pos, %v.1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_9, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %_9, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_9, align 1
  %3 = trunc nuw i8 %2 to i1
  br i1 %3, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %bb3
  store i8 0, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %bb3
  store i8 1, ptr %_0.i14, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %4 = load i8, ptr %_0.i14, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb5, label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_0.i12 = getelementptr inbounds nuw i32, ptr %v.0, i64 %pivot_pos
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
  call void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %state, ptr %v.0, ptr %scratch.0, i64 %v.1)
; call core::ptr::metadata::from_raw_parts_mut::<i32, ()>
  %_0.i = call ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr null) #23
  store ptr %_0.i, ptr %pivot_in_scratch, align 8
  store i64 %pivot_pos, ptr %loop_end_pos, align 8
  br label %bb13

bb5:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  call void @llvm.trap()
  unreachable

bb13:                                             ; preds = %bb31, %bb6
  br label %bb14

bb14:                                             ; preds = %bb13
  %_24 = load i64, ptr %loop_end_pos, align 8
  %_0.i13 = call i64 @llvm.usub.sat.i64(i64 %_24, i64 3)
  %_0.i11 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_0.i13
  br label %bb16

bb16:                                             ; preds = %bb17, %bb14
  %6 = getelementptr inbounds i8, ptr %state, i64 8
  %_27 = load ptr, ptr %6, align 8
  %_26 = icmp ult ptr %_27, %_0.i11
  br i1 %_26, label %bb17, label %bb25

bb25:                                             ; preds = %bb16
  %_53 = load i64, ptr %loop_end_pos, align 8
  %_0.i10 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_53
  br label %bb26

bb17:                                             ; preds = %bb16
  %7 = getelementptr inbounds i8, ptr %state, i64 8
  %_90 = load ptr, ptr %7, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_30 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_90, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_28 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_30)
  %8 = getelementptr inbounds i8, ptr %state, i64 8
  %_91 = load ptr, ptr %8, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_36 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_91, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_34 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_36)
  %9 = getelementptr inbounds i8, ptr %state, i64 8
  %_92 = load ptr, ptr %9, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_42 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_92, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_40 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_42)
  %10 = getelementptr inbounds i8, ptr %state, i64 8
  %_93 = load ptr, ptr %10, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_48 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_93, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_46 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_48)
  br label %bb16

bb26:                                             ; preds = %bb27, %bb25
  %11 = getelementptr inbounds i8, ptr %state, i64 8
  %_55 = load ptr, ptr %11, align 8
  %_54 = icmp ult ptr %_55, %_0.i10
  br i1 %_54, label %bb27, label %bb29

bb29:                                             ; preds = %bb26
  %_63 = load i64, ptr %loop_end_pos, align 8
  %_62 = icmp eq i64 %_63, %v.1
  br i1 %_62, label %bb30, label %bb31

bb27:                                             ; preds = %bb26
  %12 = getelementptr inbounds i8, ptr %state, i64 8
  %_94 = load ptr, ptr %12, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_58 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %_94, ptr align 4 %_0.i12) #23
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_56 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %_58)
  br label %bb26

bb31:                                             ; preds = %bb29
; call <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
  %_64 = call ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %state, i1 zeroext %pivot_goes_left)
  store ptr %_64, ptr %pivot_in_scratch, align 8
  store i64 %v.1, ptr %loop_end_pos, align 8
  br label %bb13

bb30:                                             ; preds = %bb29
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_66 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECs1VtPVuSYnoF_10intrinsics()
  br i1 %_66, label %bb34, label %bb35

bb35:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7, %bb30
  %13 = getelementptr inbounds i8, ptr %state, i64 16
  %_72 = load i64, ptr %13, align 8
; call core::ub_checks::check_language_ub
  %_4.i2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i2, label %bb2.i3, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4

bb2.i3:                                           ; preds = %bb35
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %scratch.0, ptr %v.0, i64 4, i64 4, i64 %_72, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4: ; preds = %bb35, %bb2.i3
  %14 = mul nuw nsw i64 %_72, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %v.0, ptr align 4 %scratch.0, i64 %14, i1 false)
  %15 = getelementptr inbounds i8, ptr %state, i64 16
  %_76 = load i64, ptr %15, align 8
  %_75 = sub i64 %v.1, %_76
; call <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
  %16 = call { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64 0, i64 %_75) #23
  %_73.0 = extractvalue { i64, i64 } %16, 0
  %_73.1 = extractvalue { i64, i64 } %16, 1
  store i64 %_73.0, ptr %iter, align 8
  %17 = getelementptr inbounds i8, ptr %iter, i64 8
  store i64 %_73.1, ptr %17, align 8
  br label %bb39

bb34:                                             ; preds = %bb30
  %_68 = load ptr, ptr %pivot_in_scratch, align 8
; call core::ub_checks::check_language_ub
  %_4.i5 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i5, label %bb2.i6, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7

bb2.i6:                                           ; preds = %bb34
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i12, ptr %_68, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit7: ; preds = %bb34, %bb2.i6
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_68, ptr align 4 %_0.i12, i64 4, i1 false)
  br label %bb35

bb39:                                             ; preds = %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit, %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit4
; call <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
  %18 = call { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8 %iter) #23
  %19 = extractvalue { i64, i64 } %18, 0
  %20 = extractvalue { i64, i64 } %18, 1
  store i64 %19, ptr %_78, align 8
  %21 = getelementptr inbounds i8, ptr %_78, i64 8
  store i64 %20, ptr %21, align 8
  %_80 = load i64, ptr %_78, align 8
  %22 = getelementptr inbounds i8, ptr %_78, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = trunc nuw i64 %_80 to i1
  br i1 %24, label %bb42, label %bb43

bb42:                                             ; preds = %bb39
  %25 = getelementptr inbounds i8, ptr %_78, i64 8
  %i = load i64, ptr %25, align 8
  %_86 = sub i64 %v.1, 1
  %_85 = sub i64 %_86, %i
  %_0.i9 = getelementptr inbounds nuw i32, ptr %scratch.0, i64 %_85
  %26 = getelementptr inbounds i8, ptr %state, i64 16
  %_89 = load i64, ptr %26, align 8
  %_88 = add i64 %_89, %i
  %_0.i8 = getelementptr inbounds nuw i32, ptr %v.0, i64 %_88
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb42
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_0.i9, ptr %_0.i8, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb42, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i8, ptr align 4 %_0.i9, i64 4, i1 false)
  br label %bb39

bb43:                                             ; preds = %bb39
  %27 = getelementptr inbounds i8, ptr %state, i64 16
  %_0 = load i64, ptr %27, align 8
  ret i64 %_0

bb41:                                             ; No predecessors!
  unreachable
}

; core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECs1VtPVuSYnoF_10intrinsics() unnamed_addr #1 !guid !315 {
start:
; call <i32 as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
  %_1 = call zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortlNtB5_8IsFreeze9is_freezeCs1VtPVuSYnoF_10intrinsics()
  %_0 = xor i1 %_1, true
  ret i1 %_0
}

; core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %0, i64 %1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %2, ptr align 4 %3, ptr %is_less) unnamed_addr #4 !guid !316 {
start:
  %_55 = alloca [32 x i8], align 8
  %_48 = alloca [8 x i8], align 8
  %left_partition_len = alloca [8 x i8], align 8
  %perform_equal_partition = alloca [1 x i8], align 1
  %pivot_copy = alloca [4 x i8], align 4
  %left_ancestor_pivot = alloca [8 x i8], align 8
  %limit = alloca [4 x i8], align 4
  %v = alloca [16 x i8], align 8
  store ptr %0, ptr %v, align 8
  %4 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %1, ptr %4, align 8
  store i32 %2, ptr %limit, align 4
  store ptr %3, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb1:                                              ; preds = %bb21, %bb24, %start
  %_7.0 = load ptr, ptr %v, align 8
  %5 = getelementptr inbounds i8, ptr %v, i64 8
  %_7.1 = load i64, ptr %5, align 8
  %_8 = icmp ule i64 %_7.1, 32
  br i1 %_8, label %bb3, label %bb4

bb4:                                              ; preds = %bb1
  %_13 = load i32, ptr %limit, align 4
  %_12 = icmp eq i32 %_13, 0
  br i1 %_12, label %bb5, label %bb6

bb3:                                              ; preds = %bb1
  %_11.0 = load ptr, ptr %v, align 8
  %6 = getelementptr inbounds i8, ptr %v, i64 8
  %_11.1 = load i64, ptr %6, align 8
; call core::slice::sort::shared::smallsort::small_sort_general_with_scratch::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_11.0, i64 %_11.1, ptr align 4 %scratch.0, i64 %scratch.1, ptr %is_less)
  br label %bb27

bb6:                                              ; preds = %bb4
  %7 = load i32, ptr %limit, align 4
  %8 = sub i32 %7, 1
  store i32 %8, ptr %limit, align 4
  %_17.0 = load ptr, ptr %v, align 8
  %9 = getelementptr inbounds i8, ptr %v, i64 8
  %_17.1 = load i64, ptr %9, align 8
; call core::slice::sort::shared::pivot::choose_pivot::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %pivot_pos = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared5pivot12choose_pivotlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_17.0, i64 %_17.1, ptr %is_less) #23
  %_21.0 = load ptr, ptr %v, align 8
  %10 = getelementptr inbounds i8, ptr %v, i64 8
  %_21.1 = load i64, ptr %10, align 8
  %_23 = icmp ult i64 %pivot_pos, %_21.1
  br i1 %_23, label %bb8, label %panic

bb5:                                              ; preds = %bb4
  %_15.0 = load ptr, ptr %v, align 8
  %11 = getelementptr inbounds i8, ptr %v, i64 8
  %_15.1 = load i64, ptr %11, align 8
; call core::slice::sort::stable::drift::sort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift4sortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_15.0, i64 %_15.1, ptr align 4 %scratch.0, i64 %scratch.1, i1 zeroext true, ptr %is_less)
  br label %bb27

bb8:                                              ; preds = %bb6
  %12 = load ptr, ptr %v, align 8
  %13 = getelementptr inbounds i8, ptr %v, i64 8
  %14 = load i64, ptr %13, align 8
  %_20 = getelementptr inbounds nuw i32, ptr %12, i64 %pivot_pos
  %_0.i = load i32, ptr %_20, align 4
  store i32 %_0.i, ptr %pivot_copy, align 4
; call core::slice::sort::stable::quicksort::has_direct_interior_mutability::<i32>
  %_26 = call zeroext i1 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort30has_direct_interior_mutabilitylECs1VtPVuSYnoF_10intrinsics()
  %_25 = xor i1 %_26, true
; call <bool>::then_some::<&i32>
  %pivot_ref = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core4boolb9then_someRlECs1VtPVuSYnoF_10intrinsics(i1 zeroext %_25, ptr align 4 %pivot_copy) #23
  store i8 0, ptr %perform_equal_partition, align 1
  %15 = load ptr, ptr %left_ancestor_pivot, align 8
  %16 = ptrtoint ptr %15 to i64
  %17 = icmp eq i64 %16, 0
  %_31 = select i1 %17, i64 0, i64 1
  %18 = trunc nuw i64 %_31 to i1
  br i1 %18, label %bb14, label %bb17

panic:                                            ; preds = %bb6
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_21.1, ptr align 8 @alloc_4b681e459e5d8eeddb2bdf3b83cf18ab) #27
  unreachable

bb14:                                             ; preds = %bb8
  %la_pivot = load ptr, ptr %left_ancestor_pivot, align 8
  %_36.0 = load ptr, ptr %v, align 8
  %19 = getelementptr inbounds i8, ptr %v, i64 8
  %_36.1 = load i64, ptr %19, align 8
  %_38 = icmp ult i64 %pivot_pos, %_36.1
  br i1 %_38, label %bb15, label %panic1

bb17:                                             ; preds = %bb15, %bb8
  store i64 0, ptr %left_partition_len, align 8
  %20 = load i8, ptr %perform_equal_partition, align 1
  %_40 = trunc nuw i8 %20 to i1
  br i1 %_40, label %bb20, label %bb18

bb15:                                             ; preds = %bb14
  %21 = load ptr, ptr %v, align 8
  %22 = getelementptr inbounds i8, ptr %v, i64 8
  %23 = load i64, ptr %22, align 8
  %_35 = getelementptr inbounds nuw i32, ptr %21, i64 %pivot_pos
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_33 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %is_less, ptr align 4 %la_pivot, ptr align 4 %_35) #23
  %24 = xor i1 %_33, true
  %25 = zext i1 %24 to i8
  store i8 %25, ptr %perform_equal_partition, align 1
  br label %bb17

panic1:                                           ; preds = %bb14
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %pivot_pos, i64 %_36.1, ptr align 8 @alloc_2b7dc74fc6b7aa0b08aab5733d36da25) #27
  unreachable

bb18:                                             ; preds = %bb17
  %_42.0 = load ptr, ptr %v, align 8
  %26 = getelementptr inbounds i8, ptr %v, i64 8
  %_42.1 = load i64, ptr %26, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<i32, <i32 as core::cmp::PartialOrd>::lt>
  %_41 = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_42.0, i64 %_42.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext false, ptr %is_less)
  store i64 %_41, ptr %left_partition_len, align 8
  %_43 = load i64, ptr %left_partition_len, align 8
  %27 = icmp eq i64 %_43, 0
  %28 = zext i1 %27 to i8
  store i8 %28, ptr %perform_equal_partition, align 1
  br label %bb20

bb20:                                             ; preds = %bb18, %bb17
  %29 = load i8, ptr %perform_equal_partition, align 1
  %_44 = trunc nuw i8 %29 to i1
  br i1 %_44, label %bb21, label %bb24

bb24:                                             ; preds = %bb20
  %_56.0 = load ptr, ptr %v, align 8
  %30 = getelementptr inbounds i8, ptr %v, i64 8
  %_56.1 = load i64, ptr %30, align 8
  %_57 = load i64, ptr %left_partition_len, align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_55, ptr align 4 %_56.0, i64 %_56.1, i64 %_57, ptr align 8 @alloc_06823d4b39e256f98f8c7a33a4ce85ea) #23
  %left.0 = load ptr, ptr %_55, align 8
  %31 = getelementptr inbounds i8, ptr %_55, i64 8
  %left.1 = load i64, ptr %31, align 8
  %32 = getelementptr inbounds i8, ptr %_55, i64 16
  %right.0 = load ptr, ptr %32, align 8
  %33 = getelementptr inbounds i8, ptr %32, i64 8
  %right.1 = load i64, ptr %33, align 8
  %_59 = load i32, ptr %limit, align 4
; call core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %right.0, i64 %right.1, ptr align 4 %scratch.0, i64 %scratch.1, i32 %_59, ptr align 4 %pivot_ref, ptr %is_less) #25
  store ptr %left.0, ptr %v, align 8
  %34 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %left.1, ptr %34, align 8
  br label %bb1

bb21:                                             ; preds = %bb20
  %_46.0 = load ptr, ptr %v, align 8
  %35 = getelementptr inbounds i8, ptr %v, i64 8
  %_46.1 = load i64, ptr %35, align 8
  store ptr %is_less, ptr %_48, align 8
; call core::slice::sort::stable::quicksort::stable_partition::<i32, core::slice::sort::stable::quicksort::quicksort<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}>
  %mid_eq = call i64 @_RINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort16stable_partitionlNCINvB2_9quicksortlNvYlNtNtBa_3cmp10PartialOrd2ltE0ECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_46.0, i64 %_46.1, ptr align 4 %scratch.0, i64 %scratch.1, i64 %pivot_pos, i1 zeroext true, ptr align 8 %_48)
  %_50.0 = load ptr, ptr %v, align 8
  %36 = getelementptr inbounds i8, ptr %v, i64 8
  %_50.1 = load i64, ptr %36, align 8
; call <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %37 = call { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %mid_eq, ptr align 4 %_50.0, i64 %_50.1, ptr align 8 @alloc_d82d96a4fa703c840ac11f4b07c0ef3c) #23
  %_0.0.i = extractvalue { ptr, i64 } %37, 0
  %_0.1.i = extractvalue { ptr, i64 } %37, 1
  %_49.0 = extractvalue { ptr, i64 } %37, 0
  %_49.1 = extractvalue { ptr, i64 } %37, 1
  store ptr %_49.0, ptr %v, align 8
  %38 = getelementptr inbounds i8, ptr %v, i64 8
  store i64 %_49.1, ptr %38, align 8
  store ptr null, ptr %left_ancestor_pivot, align 8
  br label %bb1

bb28:                                             ; No predecessors!
  unreachable

bb27:                                             ; preds = %bb3, %bb5
  ret void
}

; <[_]>::reverse::revswap::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswaplECs1VtPVuSYnoF_10intrinsics(ptr align 4 %a.0, i64 %a.1, ptr align 4 %b.0, i64 %b.1, i64 %n) unnamed_addr #0 !guid !317 {
start:
  %i = alloca [8 x i8], align 8
  %_7 = alloca [32 x i8], align 8
  %_5 = alloca [32 x i8], align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_5, ptr align 4 %a.0, i64 %a.1, i64 %n, ptr align 8 @alloc_ab5ed840fe8613ddcabc97b74e0b565e) #23
  %a.01 = load ptr, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  %a.12 = load i64, ptr %0, align 8
; call <[i32]>::split_at_mut
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_7, ptr align 4 %b.0, i64 %b.1, i64 %n, ptr align 8 @alloc_f7fcaa33fdba299ee035b5518e72c889) #23
  %b.03 = load ptr, ptr %_7, align 8
  %1 = getelementptr inbounds i8, ptr %_7, i64 8
  %b.14 = load i64, ptr %1, align 8
  store i64 0, ptr %i, align 8
  br label %bb3

bb3:                                              ; preds = %bb6, %start
  %_10 = load i64, ptr %i, align 8
  %_9 = icmp ult i64 %_10, %n
  br i1 %_9, label %bb4, label %bb8

bb8:                                              ; preds = %bb3
  ret void

bb4:                                              ; preds = %bb3
  %_13 = load i64, ptr %i, align 8
  %_16 = icmp ult i64 %_13, %a.12
  br i1 %_16, label %bb5, label %panic

bb5:                                              ; preds = %bb4
  %_12 = getelementptr inbounds nuw i32, ptr %a.01, i64 %_13
  %_19 = sub i64 %n, 1
  %_20 = load i64, ptr %i, align 8
  %_18 = sub i64 %_19, %_20
  %_23 = icmp ult i64 %_18, %b.14
  br i1 %_23, label %bb6, label %panic5

panic:                                            ; preds = %bb4
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_13, i64 %a.12, ptr align 8 @alloc_1466797b2db3a3ca9645efa4732978a2) #27
  unreachable

bb6:                                              ; preds = %bb5
  %_17 = getelementptr inbounds nuw i32, ptr %b.03, i64 %_18
; call core::mem::swap::<i32>
  call void @_RINvNtCsl10jNU3mE6R_4core3mem4swaplECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_12, ptr align 4 %_17) #23
  %2 = load i64, ptr %i, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %i, align 8
  br label %bb3

panic5:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %_18, i64 %b.14, ptr align 8 @alloc_853b9dc5190658ffe6dc67504ed95441) #27
  unreachable
}

; core::ptr::swap_nonoverlapping::runtime::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping7runtimelECs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %count) unnamed_addr #0 !guid !318 {
start:
  %_7 = alloca [8 x i8], align 8
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %x, i64 %count) #23
  %slice.0 = extractvalue { ptr, i64 } %0, 0
  %slice.1 = extractvalue { ptr, i64 } %0, 1
; call core::mem::size_of_val_raw::<[i32]>
  %bytes = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <core::num::nonzero::NonZero<usize>>::new
  %1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %bytes) #23
  store i64 %1, ptr %_7, align 8
  %2 = load i64, ptr %_7, align 8
  %3 = icmp eq i64 %2, 0
  %_8 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_8 to i1
  br i1 %4, label %bb4, label %bb7

bb4:                                              ; preds = %start
  %bytes1 = load i64, ptr %_7, align 8
; call core::ptr::swap_nonoverlapping_bytes
  call void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %bytes1) #23
  br label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb8:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) unnamed_addr #0 !guid !319 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1VtPVuSYnoF_10intrinsics(ptr %_4) #25
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs1VtPVuSYnoF_10intrinsics() #23
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs1VtPVuSYnoF_10intrinsics(i8 %_2) #23
  ret i32 %_0
}

; core::slice::sort::stable::quicksort::quicksort::<i32, <i32 as core::cmp::PartialOrd>::lt>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCINvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksort9quicksortlNvYlNtNtBc_3cmp10PartialOrd2ltE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1, ptr align 4 %a, ptr align 4 %b) unnamed_addr #0 !guid !320 {
start:
  %_6 = load ptr, ptr %_1, align 8
; call <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
  %_4 = call zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %_6, ptr align 4 %b, ptr align 4 %a) #23
  %_0 = xor i1 %_4, true
  ret i1 %_0
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitdEE4next0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !321 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f64>]>::get_unchecked::<usize>
  %_3 = call align 8 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdE13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #23
  %_0.i.i.i = load double, ptr %_3, align 8
  ret double %_0.i.i.i
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNCNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB7_15PolymorphicIterSINtNtNtBd_3mem12maybe_uninit11MaybeUninitfEE4next0Cs1VtPVuSYnoF_10intrinsics(ptr align 4 %_1.0, i64 %_1.1, i64 %idx) unnamed_addr #0 !guid !322 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f32>]>::get_unchecked::<usize>
  %_3 = call align 4 ptr @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfE13get_uncheckedjECs1VtPVuSYnoF_10intrinsics(ptr align 4 %_1.0, i64 %_1.1, i64 %idx, ptr align 8 @alloc_ac893681874450253b62899ecf8cf06a) #23
  %_0.i.i.i = load float, ptr %_3, align 4
  ret float %_0.i.i.i
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCs1VtPVuSYnoF_10intrinsics(ptr %_1) unnamed_addr #0 !guid !323 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs1VtPVuSYnoF_10intrinsics(ptr %0) #23
  ret i32 %_0
}

; intrinsics::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCs1VtPVuSYnoF_10intrinsics4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !324 {
start:
  %0 = alloca [80 x i8], align 8
  %1 = alloca [16 x i8], align 8
  %_367 = alloca [16 x i8], align 8
  %_366 = alloca [16 x i8], align 8
  %args26 = alloca [32 x i8], align 8
  %_363 = alloca [32 x i8], align 16
  %_360 = alloca [32 x i8], align 16
  %_353 = alloca [16 x i8], align 8
  %_352 = alloca [16 x i8], align 8
  %_351 = alloca [16 x i8], align 8
  %_350 = alloca [16 x i8], align 8
  %_349 = alloca [16 x i8], align 8
  %args25 = alloca [80 x i8], align 8
  %_347 = alloca [32 x i8], align 16
  %_345 = alloca [1 x i8], align 1
  %_340 = alloca [16 x i8], align 16
  %_338 = alloca [16 x i8], align 16
  %_332 = alloca [16 x i8], align 16
  %_326 = alloca [16 x i8], align 16
  %args24 = alloca [40 x i8], align 8
  %_317 = alloca [16 x i8], align 8
  %_316 = alloca [16 x i8], align 8
  %_315 = alloca [16 x i8], align 8
  %_314 = alloca [16 x i8], align 8
  %args23 = alloca [64 x i8], align 8
  %_310 = alloca [4 x i8], align 4
  %_306 = alloca [8 x i8], align 8
  %_302 = alloca [4 x i8], align 4
  %_298 = alloca [8 x i8], align 8
  %args22 = alloca [32 x i8], align 8
  %_289 = alloca [16 x i8], align 8
  %_288 = alloca [16 x i8], align 8
  %_287 = alloca [16 x i8], align 8
  %_286 = alloca [16 x i8], align 8
  %args21 = alloca [64 x i8], align 8
  %_283 = alloca [8 x i8], align 8
  %_280 = alloca [4 x i8], align 4
  %_277 = alloca [2 x i8], align 2
  %_274 = alloca [1 x i8], align 1
  %args20 = alloca [32 x i8], align 8
  %_266 = alloca [8 x i8], align 4
  %iter19 = alloca [40 x i8], align 8
  %_264 = alloca [20 x i8], align 4
  %_263 = alloca [40 x i8], align 8
  %_258 = alloca [16 x i8], align 8
  %_257 = alloca [16 x i8], align 8
  %_256 = alloca [16 x i8], align 8
  %_255 = alloca [16 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %_253 = alloca [16 x i8], align 8
  %args18 = alloca [96 x i8], align 8
  %_250 = alloca [16 x i8], align 16
  %_247 = alloca [16 x i8], align 16
  %_244 = alloca [8 x i8], align 8
  %_241 = alloca [4 x i8], align 4
  %_238 = alloca [1 x i8], align 1
  %_235 = alloca [1 x i8], align 1
  %args17 = alloca [48 x i8], align 8
  %_227 = alloca [16 x i8], align 8
  %iter = alloca [96 x i8], align 8
  %_225 = alloca [96 x i8], align 8
  %fs = alloca [80 x i8], align 8
  %_221 = alloca [16 x i8], align 8
  %_220 = alloca [16 x i8], align 8
  %_219 = alloca [16 x i8], align 8
  %_218 = alloca [16 x i8], align 8
  %_217 = alloca [16 x i8], align 8
  %args16 = alloca [80 x i8], align 8
  %_214 = alloca [4 x i8], align 4
  %_208 = alloca [4 x i8], align 4
  %_205 = alloca [4 x i8], align 4
  %_202 = alloca [4 x i8], align 4
  %_199 = alloca [4 x i8], align 4
  %args15 = alloca [40 x i8], align 8
  %_192 = alloca [16 x i8], align 8
  %_191 = alloca [16 x i8], align 8
  %_190 = alloca [16 x i8], align 8
  %args14 = alloca [48 x i8], align 8
  %_187 = alloca [2 x i8], align 2
  %_184 = alloca [16 x i8], align 16
  %_181 = alloca [4 x i8], align 4
  %args13 = alloca [24 x i8], align 8
  %_174 = alloca [16 x i8], align 8
  %_173 = alloca [16 x i8], align 8
  %_172 = alloca [16 x i8], align 8
  %_171 = alloca [16 x i8], align 8
  %args12 = alloca [64 x i8], align 8
  %_168 = alloca [16 x i8], align 16
  %_165 = alloca [8 x i8], align 8
  %_162 = alloca [2 x i8], align 2
  %_159 = alloca [1 x i8], align 1
  %args11 = alloca [32 x i8], align 8
  %_152 = alloca [16 x i8], align 8
  %args10 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_139 = alloca [16 x i8], align 8
  %_138 = alloca [16 x i8], align 8
  %_137 = alloca [16 x i8], align 8
  %args9 = alloca [48 x i8], align 8
  %_135 = alloca [8 x i8], align 8
  %_133 = alloca [8 x i8], align 8
  %_131 = alloca [1 x i8], align 1
  %_129 = alloca [4 x i8], align 4
  %_127 = alloca [4 x i8], align 4
  %_125 = alloca [1 x i8], align 1
  %_123 = alloca [8 x i8], align 8
  %_121 = alloca [8 x i8], align 8
  %_119 = alloca [1 x i8], align 1
  %args8 = alloca [24 x i8], align 8
  %_112 = alloca [16 x i8], align 8
  %_111 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_107 = alloca [4 x i8], align 4
  %_103 = alloca [4 x i8], align 4
  %_96 = alloca [16 x i8], align 8
  %_95 = alloca [16 x i8], align 8
  %_94 = alloca [16 x i8], align 8
  %_93 = alloca [16 x i8], align 8
  %args6 = alloca [64 x i8], align 8
  %_89 = alloca [16 x i8], align 16
  %_85 = alloca [1 x i8], align 1
  %_81 = alloca [2 x i8], align 2
  %_77 = alloca [8 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_70 = alloca [16 x i8], align 8
  %_69 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_65 = alloca [16 x i8], align 16
  %_61 = alloca [16 x i8], align 16
  %_54 = alloca [16 x i8], align 8
  %_53 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %args3 = alloca [64 x i8], align 8
  %_47 = alloca [4 x i8], align 4
  %_41 = alloca [8 x i8], align 8
  %_37 = alloca [1 x i8], align 1
  %_33 = alloca [1 x i8], align 1
  %args2 = alloca [32 x i8], align 8
  %_26 = alloca [16 x i8], align 8
  %_25 = alloca [16 x i8], align 8
  %_24 = alloca [16 x i8], align 8
  %_23 = alloca [16 x i8], align 8
  %args1 = alloca [64 x i8], align 8
  %_19 = alloca [8 x i8], align 8
  %_13 = alloca [8 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %_5 = alloca [1 x i8], align 1
  %args = alloca [32 x i8], align 8
; call core::hint::black_box::<u8>
  %_6 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 -6) #23
; call core::hint::black_box::<u8>
  %_7 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 10) #23
  %_0.i44 = call i8 @llvm.uadd.sat.i8(i8 %_6, i8 %_7)
  store i8 %_0.i44, ptr %_5, align 1
; call core::hint::black_box::<u8>
  %_10 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 5) #23
; call core::hint::black_box::<u8>
  %_11 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 10) #23
  %_0.i45 = call i8 @llvm.usub.sat.i8(i8 %_10, i8 %_11)
  store i8 %_0.i45, ptr %_9, align 1
; call core::hint::black_box::<u64>
  %_14 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 -2) #23
; call core::hint::black_box::<u64>
  %_17 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 7) #23
  %_0.i56 = call i64 @llvm.uadd.sat.i64(i64 %_14, i64 %_17)
  store i64 %_0.i56, ptr %_13, align 8
; call core::hint::black_box::<u64>
  %_20 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 3) #23
; call core::hint::black_box::<u64>
  %_21 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 9) #23
  %_0.i57 = call i64 @llvm.usub.sat.i64(i64 %_20, i64 %_21)
  store i64 %_0.i57, ptr %_19, align 8
  store ptr %_5, ptr %args, align 8
  %2 = getelementptr inbounds i8, ptr %args, i64 8
  store ptr %_9, ptr %2, align 8
  %3 = getelementptr inbounds i8, ptr %args, i64 16
  store ptr %_13, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %args, i64 24
  store ptr %_19, ptr %4, align 8
  %_370 = load ptr, ptr %args, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_23, ptr %_370) #23
  %5 = getelementptr inbounds i8, ptr %args, i64 8
  %_371 = load ptr, ptr %5, align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_24, ptr %_371) #23
  %6 = getelementptr inbounds i8, ptr %args, i64 16
  %_372 = load ptr, ptr %6, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_25, ptr align 8 %_372) #23
  %7 = getelementptr inbounds i8, ptr %args, i64 24
  %_373 = load ptr, ptr %7, align 8
; call <core::fmt::rt::Argument>::new_display::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_26, ptr align 8 %_373) #23
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_23, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_24, i64 16, i1 false)
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_25, i64 16, i1 false)
  %11 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 8 %_26, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %12 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args1) #23
  %_2.0 = extractvalue { ptr, ptr } %12, 0
  %_2.1 = extractvalue { ptr, ptr } %12, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call core::hint::black_box::<i8>
  %_34 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs1VtPVuSYnoF_10intrinsics(i8 120) #23
; call core::hint::black_box::<i8>
  %_35 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs1VtPVuSYnoF_10intrinsics(i8 10) #23
  %_0.i = call i8 @llvm.sadd.sat.i8(i8 %_34, i8 %_35)
  store i8 %_0.i, ptr %_33, align 1
; call core::hint::black_box::<i8>
  %_38 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs1VtPVuSYnoF_10intrinsics(i8 -120) #23
; call core::hint::black_box::<i8>
  %_39 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxaECs1VtPVuSYnoF_10intrinsics(i8 10) #23
  %_0.i36 = call i8 @llvm.ssub.sat.i8(i8 %_38, i8 %_39)
  store i8 %_0.i36, ptr %_37, align 1
  %13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 -9223372036854775808, i64 2)
  %_44.0 = extractvalue { i64, i1 } %13, 0
  %_44.1 = extractvalue { i64, i1 } %13, 1
  br i1 %_44.1, label %panic, label %bb26

bb26:                                             ; preds = %start
; call core::hint::black_box::<i64>
  %_42 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs1VtPVuSYnoF_10intrinsics(i64 %_44.0) #23
; call core::hint::black_box::<i64>
  %_45 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs1VtPVuSYnoF_10intrinsics(i64 7) #23
  %_0.i38 = call i64 @llvm.ssub.sat.i64(i64 %_42, i64 %_45)
  store i64 %_0.i38, ptr %_41, align 8
; call core::hint::black_box::<i32>
  %_48 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs1VtPVuSYnoF_10intrinsics(i32 -5) #23
; call core::hint::black_box::<i32>
  %_49 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs1VtPVuSYnoF_10intrinsics(i32 -7) #23
  %_0.i37 = call i32 @llvm.sadd.sat.i32(i32 %_48, i32 %_49)
  store i32 %_0.i37, ptr %_47, align 4
  store ptr %_33, ptr %args2, align 8
  %14 = getelementptr inbounds i8, ptr %args2, i64 8
  store ptr %_37, ptr %14, align 8
  %15 = getelementptr inbounds i8, ptr %args2, i64 16
  store ptr %_41, ptr %15, align 8
  %16 = getelementptr inbounds i8, ptr %args2, i64 24
  store ptr %_47, ptr %16, align 8
  %_374 = load ptr, ptr %args2, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_51, ptr %_374) #23
  %17 = getelementptr inbounds i8, ptr %args2, i64 8
  %_375 = load ptr, ptr %17, align 8
; call <core::fmt::rt::Argument>::new_display::<i8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_52, ptr %_375) #23
  %18 = getelementptr inbounds i8, ptr %args2, i64 16
  %_376 = load ptr, ptr %18, align 8
; call <core::fmt::rt::Argument>::new_display::<i64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_53, ptr align 8 %_376) #23
  %19 = getelementptr inbounds i8, ptr %args2, i64 24
  %_377 = load ptr, ptr %19, align 8
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_54, ptr align 4 %_377) #23
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_51, i64 16, i1 false)
  %21 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %21, ptr align 8 %_52, i64 16, i1 false)
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_53, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_54, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %24 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args3) #23
  %_30.0 = extractvalue { ptr, ptr } %24, 0
  %_30.1 = extractvalue { ptr, ptr } %24, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_30.0, ptr %_30.1)
; call core::hint::black_box::<i128>
  %_62 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs1VtPVuSYnoF_10intrinsics(i128 170141183460469231731687303715884105727) #23
; call core::hint::black_box::<i128>
  %_63 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs1VtPVuSYnoF_10intrinsics(i128 1) #23
  %_0.i40 = call i128 @llvm.sadd.sat.i128(i128 %_62, i128 %_63)
  store i128 %_0.i40, ptr %_61, align 16
; call core::hint::black_box::<u128>
  %_66 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 1) #23
; call core::hint::black_box::<u128>
  %_67 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 2) #23
  %_0.i63 = call i128 @llvm.usub.sat.i128(i128 %_66, i128 %_67)
  store i128 %_0.i63, ptr %_65, align 16
; call <core::fmt::rt::Argument>::new_display::<i128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_69, ptr align 16 %_61) #23
; call <core::fmt::rt::Argument>::new_display::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_70, ptr align 16 %_65) #23
  %25 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %25, ptr align 8 %_69, i64 16, i1 false)
  %26 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %26, ptr align 8 %_70, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %27 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args4) #23
  %_58.0 = extractvalue { ptr, ptr } %27, 0
  %_58.1 = extractvalue { ptr, ptr } %27, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_58.0, ptr %_58.1)
; call core::hint::black_box::<u64>
  %_78 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 1311768467463790320) #23
; call core::hint::black_box::<u32>
  %_79 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 12) #23
; call core::intrinsics::rotate_left::<u64>
  %_0.i54 = call i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64 %_78, i32 %_79) #28
  store i64 %_0.i54, ptr %_77, align 8
; call core::hint::black_box::<u16>
  %_82 = call i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs1VtPVuSYnoF_10intrinsics(i16 -32767) #23
; call core::hint::black_box::<u32>
  %_83 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 3) #23
; call core::intrinsics::rotate_right::<u16>
  %_0.i48 = call i16 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_righttECs1VtPVuSYnoF_10intrinsics(i16 %_82, i32 %_83) #28
  store i16 %_0.i48, ptr %_81, align 2
; call core::hint::black_box::<u8>
  %_86 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 -16) #23
; call core::hint::black_box::<u32>
  %_87 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 9) #23
; call core::intrinsics::rotate_left::<u8>
  %_0.i41 = call i8 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_lefthECs1VtPVuSYnoF_10intrinsics(i8 %_86, i32 %_87) #28
  store i8 %_0.i41, ptr %_85, align 1
; call core::hint::black_box::<u128>
  %_90 = call i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 1) #23
; call core::hint::black_box::<u32>
  %_91 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 1) #23
; call core::intrinsics::rotate_right::<u128>
  %_0.i61 = call i128 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightoECs1VtPVuSYnoF_10intrinsics(i128 %_90, i32 %_91) #28
  store i128 %_0.i61, ptr %_89, align 16
  store ptr %_77, ptr %args5, align 8
  %28 = getelementptr inbounds i8, ptr %args5, i64 8
  store ptr %_81, ptr %28, align 8
  %29 = getelementptr inbounds i8, ptr %args5, i64 16
  store ptr %_85, ptr %29, align 8
  %30 = getelementptr inbounds i8, ptr %args5, i64 24
  store ptr %_89, ptr %30, align 8
  %_380 = load ptr, ptr %args5, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u64>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8 %_93, ptr align 8 %_380) #23
  %31 = getelementptr inbounds i8, ptr %args5, i64 8
  %_381 = load ptr, ptr %31, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u16>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hextEB7_(ptr sret([16 x i8]) align 8 %_94, ptr align 2 %_381) #23
  %32 = getelementptr inbounds i8, ptr %args5, i64 16
  %_382 = load ptr, ptr %32, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexhEB7_(ptr sret([16 x i8]) align 8 %_95, ptr %_382) #23
  %33 = getelementptr inbounds i8, ptr %args5, i64 24
  %_383 = load ptr, ptr %33, align 8
; call <core::fmt::rt::Argument>::new_lower_hex::<u128>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_96, ptr align 16 %_383) #23
  %34 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %34, ptr align 8 %_93, i64 16, i1 false)
  %35 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_94, i64 16, i1 false)
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_95, i64 16, i1 false)
  %37 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %37, ptr align 8 %_96, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<13, 4>
  %38 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args6) #23
  %_74.0 = extractvalue { ptr, ptr } %38, 0
  %_74.1 = extractvalue { ptr, ptr } %38, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_74.0, ptr %_74.1)
; call core::hint::black_box::<u32>
  %_104 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 -559038737) #23
; call core::hint::black_box::<u32>
  %_105 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 0) #23
; call core::intrinsics::rotate_left::<u32>
  %_0.i51 = call i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftmECs1VtPVuSYnoF_10intrinsics(i32 %_104, i32 %_105) #28
  store i32 %_0.i51, ptr %_103, align 4
; call core::hint::black_box::<u32>
  %_108 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 -559038737) #23
; call core::hint::black_box::<u32>
  %_109 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 32) #23
; call core::intrinsics::rotate_right::<u32>
  %_0.i52 = call i32 @_RINvNtCsl10jNU3mE6R_4core10intrinsics12rotate_rightmECs1VtPVuSYnoF_10intrinsics(i32 %_108, i32 %_109) #28
  store i32 %_0.i52, ptr %_107, align 4
; call <core::fmt::rt::Argument>::new_lower_hex::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_111, ptr align 4 %_103) #23
; call <core::fmt::rt::Argument>::new_lower_hex::<u32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_112, ptr align 4 %_107) #23
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_111, i64 16, i1 false)
  %40 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %40, ptr align 8 %_112, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<7, 2>
  %41 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args7) #23
  %_100.0 = extractvalue { ptr, ptr } %41, 0
  %_100.1 = extractvalue { ptr, ptr } %41, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_100.0, ptr %_100.1)
; call core::hint::black_box::<i64>
  %42 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs1VtPVuSYnoF_10intrinsics(i64 3) #23
  store i64 %42, ptr %_121, align 8
; call core::hint::black_box::<i64>
  %43 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxxECs1VtPVuSYnoF_10intrinsics(i64 -4) #23
  store i64 %43, ptr %_123, align 8
; call <i64 as core::cmp::Ord>::cmp
  %44 = call i8 @_RNvXs1f_NtNtCsl10jNU3mE6R_4core3cmp5implsxNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_121, ptr align 8 %_123) #23
  store i8 %44, ptr %_119, align 1
; call core::hint::black_box::<u32>
  %45 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 3) #23
  store i32 %45, ptr %_127, align 4
; call core::hint::black_box::<u32>
  %46 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 3) #23
  store i32 %46, ptr %_129, align 4
; call <u32 as core::cmp::Ord>::cmp
  %47 = call i8 @_RNvXs11_NtNtCsl10jNU3mE6R_4core3cmp5implsmNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_127, ptr align 4 %_129) #23
  store i8 %47, ptr %_125, align 1
; call core::hint::black_box::<u64>
  %48 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 1) #23
  store i64 %48, ptr %_133, align 8
; call core::hint::black_box::<u64>
  %49 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 -1) #23
  store i64 %49, ptr %_135, align 8
; call <u64 as core::cmp::Ord>::cmp
  %50 = call i8 @_RNvXs13_NtNtCsl10jNU3mE6R_4core3cmp5implsyNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_133, ptr align 8 %_135) #23
  store i8 %50, ptr %_131, align 1
  store ptr %_119, ptr %args8, align 8
  %51 = getelementptr inbounds i8, ptr %args8, i64 8
  store ptr %_125, ptr %51, align 8
  %52 = getelementptr inbounds i8, ptr %args8, i64 16
  store ptr %_131, ptr %52, align 8
  %_386 = load ptr, ptr %args8, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_137, ptr %_386) #23
  %53 = getelementptr inbounds i8, ptr %args8, i64 8
  %_387 = load ptr, ptr %53, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_138, ptr %_387) #23
  %54 = getelementptr inbounds i8, ptr %args8, i64 16
  %_388 = load ptr, ptr %54, align 8
; call <core::fmt::rt::Argument>::new_debug::<core::cmp::Ordering>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugNtNtB7_3cmp8OrderingECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_139, ptr %_388) #23
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_137, i64 16, i1 false)
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_138, i64 16, i1 false)
  %57 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %57, ptr align 8 %_139, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 3>
  %58 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args9) #23
  %_116.0 = extractvalue { ptr, ptr } %58, 0
  %_116.1 = extractvalue { ptr, ptr } %58, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_116.0, ptr %_116.1)
; call alloc::boxed::box_new_uninit
  %_1.i = call align 4 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs1VtPVuSYnoF_10intrinsics(i64 4, i64 24) #23
  %_425 = ptrtoint ptr %_1.i to i64
  %_427 = and i64 %_425, 3
  %_428 = icmp eq i64 %_427, 0
  br i1 %_428, label %bb228, label %panic27

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_1183d6a86a10d89031fe84e0039f2937) #27
  unreachable

bb228:                                            ; preds = %bb26
  %_430 = ptrtoint ptr %_1.i to i64
  %_432 = icmp eq i64 %_430, 0
  %_433 = and i1 %_432, true
  %_434 = xor i1 %_433, true
  br i1 %_434, label %bb229, label %panic28

panic27:                                          ; preds = %bb26
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 4, i64 %_425, ptr align 8 @alloc_65f62cd96ffd83ca67dd1fc1291b6651) #29
  unreachable

bb229:                                            ; preds = %bb228
  %59 = getelementptr inbounds nuw i32, ptr %_1.i, i64 0
  store i32 5, ptr %59, align 4
  %60 = getelementptr inbounds nuw i32, ptr %_1.i, i64 1
  store i32 -3, ptr %60, align 4
  %61 = getelementptr inbounds nuw i32, ptr %_1.i, i64 2
  store i32 9, ptr %61, align 4
  %62 = getelementptr inbounds nuw i32, ptr %_1.i, i64 3
  store i32 0, ptr %62, align 4
  %63 = getelementptr inbounds nuw i32, ptr %_1.i, i64 4
  store i32 -3, ptr %63, align 4
  %64 = getelementptr inbounds nuw i32, ptr %_1.i, i64 5
  store i32 12, ptr %64, align 4
; call <[i32]>::into_vec::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSl8into_vecNtNtB5_5alloc6GlobalECs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %v, ptr align 4 %_1.i, i64 6) #23
; invoke <alloc::vec::Vec<i32> as core::ops::deref::DerefMut>::deref_mut
  %65 = invoke { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %v)
          to label %bb93 unwind label %cleanup

panic28:                                          ; preds = %bb228
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_65f62cd96ffd83ca67dd1fc1291b6651) #29
  unreachable

bb226:                                            ; preds = %bb225, %bb224, %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %v) #21
          to label %bb227 unwind label %terminate

cleanup:                                          ; preds = %bb221, %bb220, %bb219, %bb218, %bb217, %bb216, %bb215, %bb214, %bb213, %bb212, %bb211, %bb210, %bb209, %bb208, %bb207, %bb206, %bb205, %panic34, %panic33, %panic32, %panic31, %bb198, %bb197, %bb196, %bb195, %bb194, %bb193, %bb192, %bb191, %bb190, %bb189, %bb188, %bb187, %bb186, %bb185, %bb184, %bb183, %bb182, %bb181, %bb180, %bb179, %bb178, %bb177, %bb167, %bb162, %bb161, %bb160, %bb146, %bb140, %bb139, %bb138, %bb137, %bb136, %bb135, %bb134, %bb133, %bb131, %bb129, %bb126, %bb124, %bb122, %bb121, %bb120, %bb119, %bb118, %bb117, %bb115, %bb113, %bb111, %bb110, %bb109, %bb108, %bb107, %bb106, %bb105, %bb103, %bb101, %bb99, %bb97, %bb96, %bb95, %bb94, %bb93, %bb229
  %66 = landingpad { ptr, i32 }
          cleanup
  %67 = extractvalue { ptr, i32 } %66, 0
  %68 = extractvalue { ptr, i32 } %66, 1
  store ptr %67, ptr %1, align 8
  %69 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %68, ptr %69, align 8
  br label %bb226

bb93:                                             ; preds = %bb229
  %_145.0 = extractvalue { ptr, i64 } %65, 0
  %_145.1 = extractvalue { ptr, i64 } %65, 1
; invoke <[i32]>::sort
  invoke void @_RNvMNtCs7CppTae75M1_5alloc5sliceSl4sortCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_145.0, i64 %_145.1)
          to label %bb94 unwind label %cleanup

bb94:                                             ; preds = %bb93
; invoke <core::fmt::rt::Argument>::new_debug::<alloc::vec::Vec<i32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_152, ptr align 8 %v)
          to label %bb95 unwind label %cleanup

bb95:                                             ; preds = %bb94
  %70 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %70, ptr align 8 %_152, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<4, 1>
  %71 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_61247b90e1706a3f65e71312b599d3d1, ptr align 8 %args10)
          to label %bb96 unwind label %cleanup

bb96:                                             ; preds = %bb95
  %_148.0 = extractvalue { ptr, ptr } %71, 0
  %_148.1 = extractvalue { ptr, ptr } %71, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_148.0, ptr %_148.1)
          to label %bb97 unwind label %cleanup

bb97:                                             ; preds = %bb96
; invoke core::hint::black_box::<u8>
  %_160 = invoke i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 1)
          to label %bb98 unwind label %cleanup

bb98:                                             ; preds = %bb97
  %_0.i42 = call i8 @llvm.bitreverse.i8(i8 %_160)
  br label %bb99

bb99:                                             ; preds = %bb98
  store i8 %_0.i42, ptr %_159, align 1
; invoke core::hint::black_box::<u16>
  %_163 = invoke i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs1VtPVuSYnoF_10intrinsics(i16 4660)
          to label %bb100 unwind label %cleanup

bb100:                                            ; preds = %bb99
  %_0.i47 = call i16 @llvm.bitreverse.i16(i16 %_163)
  br label %bb101

bb101:                                            ; preds = %bb100
  store i16 %_0.i47, ptr %_162, align 2
; invoke core::hint::black_box::<u64>
  %_166 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECs1VtPVuSYnoF_10intrinsics(i64 1)
          to label %bb102 unwind label %cleanup

bb102:                                            ; preds = %bb101
  %_0.i55 = call i64 @llvm.bitreverse.i64(i64 %_166)
  br label %bb103

bb103:                                            ; preds = %bb102
  store i64 %_0.i55, ptr %_165, align 8
; invoke core::hint::black_box::<u128>
  %_169 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 3)
          to label %bb104 unwind label %cleanup

bb104:                                            ; preds = %bb103
  %_0.i60 = call i128 @llvm.bitreverse.i128(i128 %_169)
  br label %bb105

bb105:                                            ; preds = %bb104
  store i128 %_0.i60, ptr %_168, align 16
  store ptr %_159, ptr %args11, align 8
  %72 = getelementptr inbounds i8, ptr %args11, i64 8
  store ptr %_162, ptr %72, align 8
  %73 = getelementptr inbounds i8, ptr %args11, i64 16
  store ptr %_165, ptr %73, align 8
  %74 = getelementptr inbounds i8, ptr %args11, i64 24
  store ptr %_168, ptr %74, align 8
  %_390 = load ptr, ptr %args11, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexhEB7_(ptr sret([16 x i8]) align 8 %_171, ptr %_390)
          to label %bb106 unwind label %cleanup

bb106:                                            ; preds = %bb105
  %75 = getelementptr inbounds i8, ptr %args11, i64 8
  %_391 = load ptr, ptr %75, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hextEB7_(ptr sret([16 x i8]) align 8 %_172, ptr align 2 %_391)
          to label %bb107 unwind label %cleanup

bb107:                                            ; preds = %bb106
  %76 = getelementptr inbounds i8, ptr %args11, i64 16
  %_392 = load ptr, ptr %76, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8 %_173, ptr align 8 %_392)
          to label %bb108 unwind label %cleanup

bb108:                                            ; preds = %bb107
  %77 = getelementptr inbounds i8, ptr %args11, i64 24
  %_393 = load ptr, ptr %77, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_174, ptr align 16 %_393)
          to label %bb109 unwind label %cleanup

bb109:                                            ; preds = %bb108
  %78 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %78, ptr align 8 %_171, i64 16, i1 false)
  %79 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %79, ptr align 8 %_172, i64 16, i1 false)
  %80 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %80, ptr align 8 %_173, i64 16, i1 false)
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args12, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_174, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 4>
  %82 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args12)
          to label %bb110 unwind label %cleanup

bb110:                                            ; preds = %bb109
  %_156.0 = extractvalue { ptr, ptr } %82, 0
  %_156.1 = extractvalue { ptr, ptr } %82, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_156.0, ptr %_156.1)
          to label %bb111 unwind label %cleanup

bb111:                                            ; preds = %bb110
; invoke core::hint::black_box::<u32>
  %_182 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 16909060)
          to label %bb112 unwind label %cleanup

bb112:                                            ; preds = %bb111
  %_0.i50 = call i32 @llvm.bswap.i32(i32 %_182)
  br label %bb113

bb113:                                            ; preds = %bb112
  store i32 %_0.i50, ptr %_181, align 4
; invoke core::hint::black_box::<u128>
  %_185 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 1339673755198158349044581307228491536)
          to label %bb114 unwind label %cleanup

bb114:                                            ; preds = %bb113
  %_0.i59 = call i128 @llvm.bswap.i128(i128 %_185)
  br label %bb115

bb115:                                            ; preds = %bb114
  store i128 %_0.i59, ptr %_184, align 16
; invoke core::hint::black_box::<u16>
  %_188 = invoke i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs1VtPVuSYnoF_10intrinsics(i16 -21555)
          to label %bb116 unwind label %cleanup

bb116:                                            ; preds = %bb115
  %_0.i46 = call i16 @llvm.bswap.i16(i16 %_188)
  br label %bb117

bb117:                                            ; preds = %bb116
  store i16 %_0.i46, ptr %_187, align 2
  store ptr %_181, ptr %args13, align 8
  %83 = getelementptr inbounds i8, ptr %args13, i64 8
  store ptr %_184, ptr %83, align 8
  %84 = getelementptr inbounds i8, ptr %args13, i64 16
  store ptr %_187, ptr %84, align 8
  %_394 = load ptr, ptr %args13, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8 %_190, ptr align 4 %_394)
          to label %bb118 unwind label %cleanup

bb118:                                            ; preds = %bb117
  %85 = getelementptr inbounds i8, ptr %args13, i64 8
  %_395 = load ptr, ptr %85, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8 %_191, ptr align 16 %_395)
          to label %bb119 unwind label %cleanup

bb119:                                            ; preds = %bb118
  %86 = getelementptr inbounds i8, ptr %args13, i64 16
  %_396 = load ptr, ptr %86, align 8
; invoke <core::fmt::rt::Argument>::new_lower_hex::<u16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hextEB7_(ptr sret([16 x i8]) align 8 %_192, ptr align 2 %_396)
          to label %bb120 unwind label %cleanup

bb120:                                            ; preds = %bb119
  %87 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %87, ptr align 8 %_190, i64 16, i1 false)
  %88 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %88, ptr align 8 %_191, i64 16, i1 false)
  %89 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args14, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %89, ptr align 8 %_192, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 3>
  %90 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj3_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_704e87b7a5fdee7fd1dff6d5c83f0b3e, ptr align 8 %args14)
          to label %bb121 unwind label %cleanup

bb121:                                            ; preds = %bb120
  %_178.0 = extractvalue { ptr, ptr } %90, 0
  %_178.1 = extractvalue { ptr, ptr } %90, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_178.0, ptr %_178.1)
          to label %bb122 unwind label %cleanup

bb122:                                            ; preds = %bb121
; invoke core::hint::black_box::<u8>
  %_200 = invoke i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECs1VtPVuSYnoF_10intrinsics(i8 1)
          to label %bb123 unwind label %cleanup

bb123:                                            ; preds = %bb122
  %91 = call i8 @llvm.ctlz.i8(i8 %_200, i1 false)
  %_0.i43 = zext i8 %91 to i32
  br label %bb124

bb124:                                            ; preds = %bb123
  store i32 %_0.i43, ptr %_199, align 4
; invoke core::hint::black_box::<u16>
  %_203 = invoke i16 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxtECs1VtPVuSYnoF_10intrinsics(i16 16)
          to label %bb125 unwind label %cleanup

bb125:                                            ; preds = %bb124
  %92 = call i16 @llvm.cttz.i16(i16 %_203, i1 false)
  %_0.i49 = zext i16 %92 to i32
  br label %bb126

bb126:                                            ; preds = %bb125
  store i32 %_0.i49, ptr %_202, align 4
; invoke core::hint::black_box::<u32>
  %_206 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECs1VtPVuSYnoF_10intrinsics(i32 0)
          to label %bb127 unwind label %cleanup

bb127:                                            ; preds = %bb126
  %_0.i53 = call i32 @llvm.ctlz.i32(i32 %_206, i1 false)
  br label %bb128

bb128:                                            ; preds = %bb127
  store i32 %_0.i53, ptr %_205, align 4
  br label %bb129

bb129:                                            ; preds = %bb128
; invoke core::hint::black_box::<u128>
  %_209 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 1267650600228229401496703205376)
          to label %bb130 unwind label %cleanup

bb130:                                            ; preds = %bb129
  %93 = call i128 @llvm.ctlz.i128(i128 %_209, i1 false)
  %_0.i62 = trunc i128 %93 to i32
  br label %bb131

bb131:                                            ; preds = %bb130
  store i32 %_0.i62, ptr %_208, align 4
; invoke core::hint::black_box::<u128>
  %_215 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 -1)
          to label %bb132 unwind label %cleanup

bb132:                                            ; preds = %bb131
  %94 = call i128 @llvm.ctpop.i128(i128 %_215)
  %_0.i58 = trunc i128 %94 to i32
  br label %bb133

bb133:                                            ; preds = %bb132
  store i32 %_0.i58, ptr %_214, align 4
  store ptr %_199, ptr %args15, align 8
  %95 = getelementptr inbounds i8, ptr %args15, i64 8
  store ptr %_202, ptr %95, align 8
  %96 = getelementptr inbounds i8, ptr %args15, i64 16
  store ptr %_205, ptr %96, align 8
  %97 = getelementptr inbounds i8, ptr %args15, i64 24
  store ptr %_208, ptr %97, align 8
  %98 = getelementptr inbounds i8, ptr %args15, i64 32
  store ptr %_214, ptr %98, align 8
  %_397 = load ptr, ptr %args15, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_217, ptr align 4 %_397)
          to label %bb134 unwind label %cleanup

bb134:                                            ; preds = %bb133
  %99 = getelementptr inbounds i8, ptr %args15, i64 8
  %_398 = load ptr, ptr %99, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_218, ptr align 4 %_398)
          to label %bb135 unwind label %cleanup

bb135:                                            ; preds = %bb134
  %100 = getelementptr inbounds i8, ptr %args15, i64 16
  %_399 = load ptr, ptr %100, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_219, ptr align 4 %_399)
          to label %bb136 unwind label %cleanup

bb136:                                            ; preds = %bb135
  %101 = getelementptr inbounds i8, ptr %args15, i64 24
  %_400 = load ptr, ptr %101, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_220, ptr align 4 %_400)
          to label %bb137 unwind label %cleanup

bb137:                                            ; preds = %bb136
  %102 = getelementptr inbounds i8, ptr %args15, i64 32
  %_401 = load ptr, ptr %102, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_221, ptr align 4 %_401)
          to label %bb138 unwind label %cleanup

bb138:                                            ; preds = %bb137
  %103 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %103, ptr align 8 %_217, i64 16, i1 false)
  %104 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %104, ptr align 8 %_218, i64 16, i1 false)
  %105 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %105, ptr align 8 %_219, i64 16, i1 false)
  %106 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %106, ptr align 8 %_220, i64 16, i1 false)
  %107 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args16, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %107, ptr align 8 %_221, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<16, 5>
  %108 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args16)
          to label %bb139 unwind label %cleanup

bb139:                                            ; preds = %bb138
  %_196.0 = extractvalue { ptr, ptr } %108, 0
  %_196.1 = extractvalue { ptr, ptr } %108, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_196.0, ptr %_196.1)
          to label %bb140 unwind label %cleanup

bb140:                                            ; preds = %bb139
  %109 = getelementptr inbounds nuw double, ptr %fs, i64 0
  store double +qnan, ptr %109, align 8
  %110 = getelementptr inbounds nuw double, ptr %fs, i64 1
  store double -1.500000e+00, ptr %110, align 8
  %111 = getelementptr inbounds nuw double, ptr %fs, i64 2
  store double -5.000000e-01, ptr %111, align 8
  %112 = getelementptr inbounds nuw double, ptr %fs, i64 3
  store double 0.000000e+00, ptr %112, align 8
  %113 = getelementptr inbounds nuw double, ptr %fs, i64 4
  store double 1.000000e+03, ptr %113, align 8
  %114 = getelementptr inbounds nuw double, ptr %fs, i64 5
  store double 3.007000e+02, ptr %114, align 8
  %115 = getelementptr inbounds nuw double, ptr %fs, i64 6
  store double -3.002000e+02, ptr %115, align 8
  %116 = getelementptr inbounds nuw double, ptr %fs, i64 7
  store double 1.000000e+30, ptr %116, align 8
  %117 = getelementptr inbounds nuw double, ptr %fs, i64 8
  store double -1.000000e+30, ptr %117, align 8
  %118 = getelementptr inbounds nuw double, ptr %fs, i64 9
  store double +inf, ptr %118, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %fs, i64 80, i1 false)
; invoke <[f64; 10] as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAdja_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %_225, ptr align 8 %0)
          to label %bb141 unwind label %cleanup

bb141:                                            ; preds = %bb140
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter, ptr align 8 %_225, i64 96, i1 false)
  br label %bb142

bb142:                                            ; preds = %bb230, %bb141
; invoke <core::array::iter::IntoIter<f64, 10> as core::iter::traits::iterator::Iterator>::next
  %119 = invoke { i64, double } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterdKja_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter)
          to label %bb143 unwind label %cleanup29

bb225:                                            ; preds = %cleanup29
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<f64, 10>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterdKja_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter) #21
          to label %bb226 unwind label %terminate

cleanup29:                                        ; preds = %bb159, %bb158, %bb157, %bb156, %bb155, %bb154, %bb153, %bb152, %bb151, %bb150, %bb149, %bb148, %bb147, %bb145, %bb142
  %120 = landingpad { ptr, i32 }
          cleanup
  %121 = extractvalue { ptr, i32 } %120, 0
  %122 = extractvalue { ptr, i32 } %120, 1
  store ptr %121, ptr %1, align 8
  %123 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %122, ptr %123, align 8
  br label %bb225

bb143:                                            ; preds = %bb142
  %124 = extractvalue { i64, double } %119, 0
  %125 = extractvalue { i64, double } %119, 1
  store i64 %124, ptr %_227, align 8
  %126 = getelementptr inbounds i8, ptr %_227, i64 8
  store double %125, ptr %126, align 8
  %_229 = load i64, ptr %_227, align 8
  %127 = getelementptr inbounds i8, ptr %_227, i64 8
  %128 = load double, ptr %127, align 8
  %129 = trunc nuw i64 %_229 to i1
  br i1 %129, label %bb145, label %bb146

bb145:                                            ; preds = %bb143
  %130 = getelementptr inbounds i8, ptr %_227, i64 8
  %f35 = load double, ptr %130, align 8
; invoke core::hint::black_box::<f64>
  %_236 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb147 unwind label %cleanup29

bb146:                                            ; preds = %bb143
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<f64, 10>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterdKja_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter)
          to label %bb160 unwind label %cleanup

bb160:                                            ; preds = %bb146
; invoke <core::fmt::Arguments>::from_str
  %131 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1)
          to label %bb161 unwind label %cleanup

bb161:                                            ; preds = %bb160
  %_262.0 = extractvalue { ptr, ptr } %131, 0
  %_262.1 = extractvalue { ptr, ptr } %131, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_262.0, ptr %_262.1)
          to label %bb162 unwind label %cleanup

bb162:                                            ; preds = %bb161
  %132 = getelementptr inbounds nuw float, ptr %_264, i64 0
  store float +qnan, ptr %132, align 4
  %133 = getelementptr inbounds nuw float, ptr %_264, i64 1
  store float -1.290000e+02, ptr %133, align 4
  %134 = getelementptr inbounds nuw float, ptr %_264, i64 2
  store float 2.555000e+02, ptr %134, align 4
  %135 = getelementptr inbounds nuw float, ptr %_264, i64 3
  store float 4.000000e+09, ptr %135, align 4
  %136 = getelementptr inbounds nuw float, ptr %_264, i64 4
  store float -3.000000e+38, ptr %136, align 4
; invoke <[f32; 5] as core::iter::traits::collect::IntoIterator>::into_iter
  invoke void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAfj5_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %_263, ptr align 4 %_264)
          to label %bb163 unwind label %cleanup

bb163:                                            ; preds = %bb162
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %iter19, ptr align 8 %_263, i64 40, i1 false)
  br label %bb164

bb164:                                            ; preds = %bb231, %bb163
; invoke <core::array::iter::IntoIter<f32, 5> as core::iter::traits::iterator::Iterator>::next
  %137 = invoke { i32, float } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterfKj5_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter19)
          to label %bb165 unwind label %cleanup30

bb224:                                            ; preds = %cleanup30
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<f32, 5>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterfKj5_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter19) #21
          to label %bb226 unwind label %terminate

cleanup30:                                        ; preds = %bb176, %bb175, %bb174, %bb173, %bb172, %bb171, %bb170, %bb169, %bb168, %bb166, %bb164
  %138 = landingpad { ptr, i32 }
          cleanup
  %139 = extractvalue { ptr, i32 } %138, 0
  %140 = extractvalue { ptr, i32 } %138, 1
  store ptr %139, ptr %1, align 8
  %141 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %140, ptr %141, align 8
  br label %bb224

bb165:                                            ; preds = %bb164
  %142 = extractvalue { i32, float } %137, 0
  %143 = extractvalue { i32, float } %137, 1
  store i32 %142, ptr %_266, align 4
  %144 = getelementptr inbounds i8, ptr %_266, i64 4
  store float %143, ptr %144, align 4
  %145 = load i32, ptr %_266, align 4
  %146 = getelementptr inbounds i8, ptr %_266, i64 4
  %147 = load float, ptr %146, align 4
  %_268 = zext i32 %145 to i64
  %148 = trunc nuw i64 %_268 to i1
  br i1 %148, label %bb166, label %bb167

bb166:                                            ; preds = %bb165
  %149 = getelementptr inbounds i8, ptr %_266, i64 4
  %f = load float, ptr %149, align 4
; invoke core::hint::black_box::<f32>
  %_275 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float %f)
          to label %bb168 unwind label %cleanup30

bb167:                                            ; preds = %bb165
; invoke core::ptr::drop_glue::<core::array::iter::IntoIter<f32, 5>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterfKj5_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %iter19)
          to label %bb177 unwind label %cleanup

bb177:                                            ; preds = %bb167
; invoke <core::fmt::Arguments>::from_str
  %150 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_49a1e817e911805af64bbc7efb390101, i64 1)
          to label %bb178 unwind label %cleanup

bb178:                                            ; preds = %bb177
  %_293.0 = extractvalue { ptr, ptr } %150, 0
  %_293.1 = extractvalue { ptr, ptr } %150, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_293.0, ptr %_293.1)
          to label %bb179 unwind label %cleanup

bb179:                                            ; preds = %bb178
; invoke core::hint::black_box::<f64>
  %_299 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double 2.000000e+00)
          to label %bb180 unwind label %cleanup

bb180:                                            ; preds = %bb179
; invoke core::hint::black_box::<i32>
  %_300 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs1VtPVuSYnoF_10intrinsics(i32 10)
          to label %bb181 unwind label %cleanup

bb181:                                            ; preds = %bb180
; invoke <f64>::powi
  %151 = invoke double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powiCs1VtPVuSYnoF_10intrinsics(double %_299, i32 %_300)
          to label %bb182 unwind label %cleanup

bb182:                                            ; preds = %bb181
  store double %151, ptr %_298, align 8
; invoke core::hint::black_box::<f32>
  %_303 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float 1.500000e+00)
          to label %bb183 unwind label %cleanup

bb183:                                            ; preds = %bb182
; invoke core::hint::black_box::<i32>
  %_304 = invoke i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECs1VtPVuSYnoF_10intrinsics(i32 -2)
          to label %bb184 unwind label %cleanup

bb184:                                            ; preds = %bb183
; invoke <f32>::powi
  %152 = invoke float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powiCs1VtPVuSYnoF_10intrinsics(float %_303, i32 %_304)
          to label %bb185 unwind label %cleanup

bb185:                                            ; preds = %bb184
  store float %152, ptr %_302, align 4
; invoke core::hint::black_box::<f64>
  %_307 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double 3.000000e+00)
          to label %bb186 unwind label %cleanup

bb186:                                            ; preds = %bb185
; invoke core::hint::black_box::<f64>
  %_308 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double +qnan)
          to label %bb187 unwind label %cleanup

bb187:                                            ; preds = %bb186
; invoke <f64>::min
  %153 = invoke double @_RNvMNtCsl10jNU3mE6R_4core3f64d3minCs1VtPVuSYnoF_10intrinsics(double %_307, double %_308)
          to label %bb188 unwind label %cleanup

bb188:                                            ; preds = %bb187
  store double %153, ptr %_306, align 8
; invoke core::hint::black_box::<f32>
  %_311 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float +qnan)
          to label %bb189 unwind label %cleanup

bb189:                                            ; preds = %bb188
; invoke core::hint::black_box::<f32>
  %_312 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float -1.000000e+00)
          to label %bb190 unwind label %cleanup

bb190:                                            ; preds = %bb189
; invoke <f32>::max
  %154 = invoke float @_RNvMNtCsl10jNU3mE6R_4core3f32f3maxCs1VtPVuSYnoF_10intrinsics(float %_311, float %_312)
          to label %bb191 unwind label %cleanup

bb191:                                            ; preds = %bb190
  store float %154, ptr %_310, align 4
  store ptr %_298, ptr %args22, align 8
  %155 = getelementptr inbounds i8, ptr %args22, i64 8
  store ptr %_302, ptr %155, align 8
  %156 = getelementptr inbounds i8, ptr %args22, i64 16
  store ptr %_306, ptr %156, align 8
  %157 = getelementptr inbounds i8, ptr %args22, i64 24
  store ptr %_310, ptr %157, align 8
  %_412 = load ptr, ptr %args22, align 8
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_314, ptr align 8 %_412)
          to label %bb192 unwind label %cleanup

bb192:                                            ; preds = %bb191
  %158 = getelementptr inbounds i8, ptr %args22, i64 8
  %_413 = load ptr, ptr %158, align 8
; invoke <core::fmt::rt::Argument>::new_display::<f32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_315, ptr align 4 %_413)
          to label %bb193 unwind label %cleanup

bb193:                                            ; preds = %bb192
  %159 = getelementptr inbounds i8, ptr %args22, i64 16
  %_414 = load ptr, ptr %159, align 8
; invoke <core::fmt::rt::Argument>::new_display::<f64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaydECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_316, ptr align 8 %_414)
          to label %bb194 unwind label %cleanup

bb194:                                            ; preds = %bb193
  %160 = getelementptr inbounds i8, ptr %args22, i64 24
  %_415 = load ptr, ptr %160, align 8
; invoke <core::fmt::rt::Argument>::new_display::<f32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayfECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_317, ptr align 4 %_415)
          to label %bb195 unwind label %cleanup

bb195:                                            ; preds = %bb194
  %161 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %161, ptr align 8 %_314, i64 16, i1 false)
  %162 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %162, ptr align 8 %_315, i64 16, i1 false)
  %163 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %163, ptr align 8 %_316, i64 16, i1 false)
  %164 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args23, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %164, ptr align 8 %_317, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 4>
  %165 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_d4f9eee8b3859a4cb2c5427791046c70, ptr align 8 %args23)
          to label %bb196 unwind label %cleanup

bb196:                                            ; preds = %bb195
  %_295.0 = extractvalue { ptr, ptr } %165, 0
  %_295.1 = extractvalue { ptr, ptr } %165, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_295.0, ptr %_295.1)
          to label %bb197 unwind label %cleanup

bb197:                                            ; preds = %bb196
; invoke core::hint::black_box::<i128>
  %a = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs1VtPVuSYnoF_10intrinsics(i128 170141183460469231731687303715884105727)
          to label %bb198 unwind label %cleanup

bb198:                                            ; preds = %bb197
; invoke core::hint::black_box::<i128>
  %b = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxnECs1VtPVuSYnoF_10intrinsics(i128 -12345678901234567890123456789)
          to label %bb199 unwind label %cleanup

bb199:                                            ; preds = %bb198
  %_327 = icmp eq i128 %b, 0
  br i1 %_327, label %panic31, label %bb200

bb200:                                            ; preds = %bb199
  %_328 = icmp eq i128 %b, -1
  %_329 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_330 = and i1 %_328, %_329
  br i1 %_330, label %panic32, label %bb201

panic31:                                          ; preds = %bb199
; invoke core::panicking::panic_const::panic_const_div_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_249b00765606cfa85122173b22b0fb80) #26
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %panic34, %panic33, %panic32, %panic31
  unreachable

bb201:                                            ; preds = %bb200
  %166 = sdiv i128 %a, %b
  store i128 %166, ptr %_326, align 16
  %_333 = icmp eq i128 %b, 0
  br i1 %_333, label %panic33, label %bb202

panic32:                                          ; preds = %bb200
; invoke core::panicking::panic_const::panic_const_div_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8 @alloc_249b00765606cfa85122173b22b0fb80) #26
          to label %unreachable unwind label %cleanup

bb202:                                            ; preds = %bb201
  %_334 = icmp eq i128 %b, -1
  %_335 = icmp eq i128 %a, -170141183460469231731687303715884105728
  %_336 = and i1 %_334, %_335
  br i1 %_336, label %panic34, label %bb203

panic33:                                          ; preds = %bb201
; invoke core::panicking::panic_const::panic_const_rem_by_zero
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_848f03bdfff992cf43c902ffa62c80db) #26
          to label %unreachable unwind label %cleanup

bb203:                                            ; preds = %bb202
  %167 = srem i128 %a, %b
  store i128 %167, ptr %_332, align 16
  %_0.i39 = mul i128 %a, %b
  br label %bb204

panic34:                                          ; preds = %bb202
; invoke core::panicking::panic_const::panic_const_rem_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8 @alloc_848f03bdfff992cf43c902ffa62c80db) #26
          to label %unreachable unwind label %cleanup

bb204:                                            ; preds = %bb203
  store i128 %_0.i39, ptr %_338, align 16
  br label %bb205

bb205:                                            ; preds = %bb204
  %168 = lshr i128 %a, 77
  store i128 %168, ptr %_340, align 16
; invoke <i128>::checked_mul
  invoke void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_347, i128 %b, i128 %b)
          to label %bb206 unwind label %cleanup

bb206:                                            ; preds = %bb205
; invoke <core::option::Option<i128>>::is_none
  %169 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCs1VtPVuSYnoF_10intrinsics(ptr align 16 %_347)
          to label %bb207 unwind label %cleanup

bb207:                                            ; preds = %bb206
  %170 = zext i1 %169 to i8
  store i8 %170, ptr %_345, align 1
  store ptr %_326, ptr %args24, align 8
  %171 = getelementptr inbounds i8, ptr %args24, i64 8
  store ptr %_332, ptr %171, align 8
  %172 = getelementptr inbounds i8, ptr %args24, i64 16
  store ptr %_338, ptr %172, align 8
  %173 = getelementptr inbounds i8, ptr %args24, i64 24
  store ptr %_340, ptr %173, align 8
  %174 = getelementptr inbounds i8, ptr %args24, i64 32
  store ptr %_345, ptr %174, align 8
  %_416 = load ptr, ptr %args24, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_349, ptr align 16 %_416)
          to label %bb208 unwind label %cleanup

bb208:                                            ; preds = %bb207
  %175 = getelementptr inbounds i8, ptr %args24, i64 8
  %_417 = load ptr, ptr %175, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_350, ptr align 16 %_417)
          to label %bb209 unwind label %cleanup

bb209:                                            ; preds = %bb208
  %176 = getelementptr inbounds i8, ptr %args24, i64 16
  %_418 = load ptr, ptr %176, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_351, ptr align 16 %_418)
          to label %bb210 unwind label %cleanup

bb210:                                            ; preds = %bb209
  %177 = getelementptr inbounds i8, ptr %args24, i64 24
  %_419 = load ptr, ptr %177, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_352, ptr align 16 %_419)
          to label %bb211 unwind label %cleanup

bb211:                                            ; preds = %bb210
  %178 = getelementptr inbounds i8, ptr %args24, i64 32
  %_420 = load ptr, ptr %178, align 8
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_353, ptr %_420)
          to label %bb212 unwind label %cleanup

bb212:                                            ; preds = %bb211
  %179 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %179, ptr align 8 %_349, i64 16, i1 false)
  %180 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %180, ptr align 8 %_350, i64 16, i1 false)
  %181 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %181, ptr align 8 %_351, i64 16, i1 false)
  %182 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %182, ptr align 8 %_352, i64 16, i1 false)
  %183 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args25, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %183, ptr align 8 %_353, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<16, 5>
  %184 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj10_Kj5_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_6a96e47ef75dbf6fc4eb5423ba7bb768, ptr align 8 %args25)
          to label %bb213 unwind label %cleanup

bb213:                                            ; preds = %bb212
  %_323.0 = extractvalue { ptr, ptr } %184, 0
  %_323.1 = extractvalue { ptr, ptr } %184, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_323.0, ptr %_323.1)
          to label %bb214 unwind label %cleanup

bb214:                                            ; preds = %bb213
; invoke core::hint::black_box::<u128>
  %_361 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 -1)
          to label %bb215 unwind label %cleanup

bb215:                                            ; preds = %bb214
; invoke <u128>::checked_add
  invoke void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_360, i128 %_361, i128 1)
          to label %bb216 unwind label %cleanup

bb216:                                            ; preds = %bb215
; invoke core::hint::black_box::<u128>
  %_364 = invoke i128 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxoECs1VtPVuSYnoF_10intrinsics(i128 7)
          to label %bb217 unwind label %cleanup

bb217:                                            ; preds = %bb216
; invoke <u128>::checked_mul
  invoke void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_363, i128 %_364, i128 9)
          to label %bb218 unwind label %cleanup

bb218:                                            ; preds = %bb217
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_366, ptr align 16 %_360)
          to label %bb219 unwind label %cleanup

bb219:                                            ; preds = %bb218
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<u128>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionoEECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_367, ptr align 16 %_363)
          to label %bb220 unwind label %cleanup

bb220:                                            ; preds = %bb219
  %185 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %185, ptr align 8 %_366, i64 16, i1 false)
  %186 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args26, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %186, ptr align 8 %_367, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<7, 2>
  %187 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr @alloc_b1b3cecaa6a7183967abcfd14f99ae78, ptr align 8 %args26)
          to label %bb221 unwind label %cleanup

bb221:                                            ; preds = %bb220
  %_357.0 = extractvalue { ptr, ptr } %187, 0
  %_357.1 = extractvalue { ptr, ptr } %187, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_357.0, ptr %_357.1)
          to label %bb222 unwind label %cleanup

bb222:                                            ; preds = %bb221
; call core::ptr::drop_glue::<alloc::vec::Vec<i32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VeclEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %v)
  ret void

bb168:                                            ; preds = %bb166
  %188 = call i8 @llvm.fptoui.sat.i8.f32(float %_275)
  store i8 %188, ptr %_274, align 1
; invoke core::hint::black_box::<f32>
  %_278 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float %f)
          to label %bb169 unwind label %cleanup30

bb169:                                            ; preds = %bb168
  %189 = call i16 @llvm.fptosi.sat.i16.f32(float %_278)
  store i16 %189, ptr %_277, align 2
; invoke core::hint::black_box::<f32>
  %_281 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float %f)
          to label %bb170 unwind label %cleanup30

bb170:                                            ; preds = %bb169
  %190 = call i32 @llvm.fptoui.sat.i32.f32(float %_281)
  store i32 %190, ptr %_280, align 4
; invoke core::hint::black_box::<f32>
  %_284 = invoke float @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxfECs1VtPVuSYnoF_10intrinsics(float %f)
          to label %bb171 unwind label %cleanup30

bb171:                                            ; preds = %bb170
  %191 = call i64 @llvm.fptosi.sat.i64.f32(float %_284)
  store i64 %191, ptr %_283, align 8
  store ptr %_274, ptr %args20, align 8
  %192 = getelementptr inbounds i8, ptr %args20, i64 8
  store ptr %_277, ptr %192, align 8
  %193 = getelementptr inbounds i8, ptr %args20, i64 16
  store ptr %_280, ptr %193, align 8
  %194 = getelementptr inbounds i8, ptr %args20, i64 24
  store ptr %_283, ptr %194, align 8
  %_408 = load ptr, ptr %args20, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_286, ptr %_408)
          to label %bb172 unwind label %cleanup30

bb172:                                            ; preds = %bb171
  %195 = getelementptr inbounds i8, ptr %args20, i64 8
  %_409 = load ptr, ptr %195, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i16>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaysECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_287, ptr align 2 %_409)
          to label %bb173 unwind label %cleanup30

bb173:                                            ; preds = %bb172
  %196 = getelementptr inbounds i8, ptr %args20, i64 16
  %_410 = load ptr, ptr %196, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8 %_288, ptr align 4 %_410)
          to label %bb174 unwind label %cleanup30

bb174:                                            ; preds = %bb173
  %197 = getelementptr inbounds i8, ptr %args20, i64 24
  %_411 = load ptr, ptr %197, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayxECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_289, ptr align 8 %_411)
          to label %bb175 unwind label %cleanup30

bb175:                                            ; preds = %bb174
  %198 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %198, ptr align 8 %_286, i64 16, i1 false)
  %199 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %199, ptr align 8 %_287, i64 16, i1 false)
  %200 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %200, ptr align 8 %_288, i64 16, i1 false)
  %201 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args21, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %201, ptr align 8 %_289, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<14, 4>
  %202 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj4_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_fddf786d72bd1b53926e64dc15c567f6, ptr align 8 %args21)
          to label %bb176 unwind label %cleanup30

bb176:                                            ; preds = %bb175
  %_271.0 = extractvalue { ptr, ptr } %202, 0
  %_271.1 = extractvalue { ptr, ptr } %202, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_271.0, ptr %_271.1)
          to label %bb231 unwind label %cleanup30

bb231:                                            ; preds = %bb176
  br label %bb164

terminate:                                        ; preds = %bb226, %bb225, %bb224
  %203 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #22
  unreachable

bb147:                                            ; preds = %bb145
  %204 = call i8 @llvm.fptoui.sat.i8.f64(double %_236)
  store i8 %204, ptr %_235, align 1
; invoke core::hint::black_box::<f64>
  %_239 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb148 unwind label %cleanup29

bb148:                                            ; preds = %bb147
  %205 = call i8 @llvm.fptosi.sat.i8.f64(double %_239)
  store i8 %205, ptr %_238, align 1
; invoke core::hint::black_box::<f64>
  %_242 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb149 unwind label %cleanup29

bb149:                                            ; preds = %bb148
  %206 = call i32 @llvm.fptosi.sat.i32.f64(double %_242)
  store i32 %206, ptr %_241, align 4
; invoke core::hint::black_box::<f64>
  %_245 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb150 unwind label %cleanup29

bb150:                                            ; preds = %bb149
  %207 = call i64 @llvm.fptoui.sat.i64.f64(double %_245)
  store i64 %207, ptr %_244, align 8
; invoke core::hint::black_box::<f64>
  %_248 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb151 unwind label %cleanup29

bb151:                                            ; preds = %bb150
  %208 = call i128 @llvm.fptosi.sat.i128.f64(double %_248)
  store i128 %208, ptr %_247, align 16
; invoke core::hint::black_box::<f64>
  %_251 = invoke double @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxdECs1VtPVuSYnoF_10intrinsics(double %f35)
          to label %bb152 unwind label %cleanup29

bb152:                                            ; preds = %bb151
  %209 = call i128 @llvm.fptoui.sat.i128.f64(double %_251)
  store i128 %209, ptr %_250, align 16
  store ptr %_235, ptr %args17, align 8
  %210 = getelementptr inbounds i8, ptr %args17, i64 8
  store ptr %_238, ptr %210, align 8
  %211 = getelementptr inbounds i8, ptr %args17, i64 16
  store ptr %_241, ptr %211, align 8
  %212 = getelementptr inbounds i8, ptr %args17, i64 24
  store ptr %_244, ptr %212, align 8
  %213 = getelementptr inbounds i8, ptr %args17, i64 32
  store ptr %_247, ptr %213, align 8
  %214 = getelementptr inbounds i8, ptr %args17, i64 40
  store ptr %_250, ptr %214, align 8
  %_402 = load ptr, ptr %args17, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_253, ptr %_402)
          to label %bb153 unwind label %cleanup29

bb153:                                            ; preds = %bb152
  %215 = getelementptr inbounds i8, ptr %args17, i64 8
  %_403 = load ptr, ptr %215, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayaECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_254, ptr %_403)
          to label %bb154 unwind label %cleanup29

bb154:                                            ; preds = %bb153
  %216 = getelementptr inbounds i8, ptr %args17, i64 16
  %_404 = load ptr, ptr %216, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i32>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_255, ptr align 4 %_404)
          to label %bb155 unwind label %cleanup29

bb155:                                            ; preds = %bb154
  %217 = getelementptr inbounds i8, ptr %args17, i64 24
  %_405 = load ptr, ptr %217, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u64>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8 %_256, ptr align 8 %_405)
          to label %bb156 unwind label %cleanup29

bb156:                                            ; preds = %bb155
  %218 = getelementptr inbounds i8, ptr %args17, i64 32
  %_406 = load ptr, ptr %218, align 8
; invoke <core::fmt::rt::Argument>::new_display::<i128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaynECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_257, ptr align 16 %_406)
          to label %bb157 unwind label %cleanup29

bb157:                                            ; preds = %bb156
  %219 = getelementptr inbounds i8, ptr %args17, i64 40
  %_407 = load ptr, ptr %219, align 8
; invoke <core::fmt::rt::Argument>::new_display::<u128>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayoECs1VtPVuSYnoF_10intrinsics(ptr sret([16 x i8]) align 8 %_258, ptr align 16 %_407)
          to label %bb158 unwind label %cleanup29

bb158:                                            ; preds = %bb157
  %220 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %220, ptr align 8 %_253, i64 16, i1 false)
  %221 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %221, ptr align 8 %_254, i64 16, i1 false)
  %222 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %222, ptr align 8 %_255, i64 16, i1 false)
  %223 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %223, ptr align 8 %_256, i64 16, i1 false)
  %224 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %224, ptr align 8 %_257, i64 16, i1 false)
  %225 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args18, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %225, ptr align 8 %_258, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<20, 6>
  %226 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj14_Kj6_ECs1VtPVuSYnoF_10intrinsics(ptr @alloc_5685a6c13b96afe5e3bc9310a5bb8655, ptr align 8 %args18)
          to label %bb159 unwind label %cleanup29

bb159:                                            ; preds = %bb158
  %_232.0 = extractvalue { ptr, ptr } %226, 0
  %_232.1 = extractvalue { ptr, ptr } %226, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_232.0, ptr %_232.1)
          to label %bb230 unwind label %cleanup29

bb230:                                            ; preds = %bb159
  br label %bb142

bb144:                                            ; No predecessors!
  unreachable

bb227:                                            ; preds = %bb226
  %227 = load ptr, ptr %1, align 8
  %228 = getelementptr inbounds i8, ptr %1, i64 8
  %229 = load i32, ptr %228, align 8
  %230 = insertvalue { ptr, i32 } poison, ptr %227, 0
  %231 = insertvalue { ptr, i32 } %230, i32 %229, 1
  resume { ptr, i32 } %231
}

; <alloc::vec::Vec<i32>>::with_capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeclE13with_capacityCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !325 {
start:
; call <alloc::vec::Vec<i32>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclE16with_capacity_inCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #23
  ret void
}

; <[i32]>::sort
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSl4sortCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !326 {
start:
; call alloc::slice::stable_sort::<i32, <i32 as core::cmp::PartialOrd>::lt>
  call void @_RINvNtCs7CppTae75M1_5alloc5slice11stable_sortlNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) #23
  ret void
}

; <f32>::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsddYV2PBJW9h_3std3f32f4powiCs1VtPVuSYnoF_10intrinsics(float %self, i32 %n) unnamed_addr #0 !guid !327 {
start:
; call core::f32::math::powi
  %_0 = call float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4powiCs1VtPVuSYnoF_10intrinsics(float %self, i32 %n) #23
  ret float %_0
}

; <f64>::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsddYV2PBJW9h_3std3f64d4powiCs1VtPVuSYnoF_10intrinsics(double %self, i32 %n) unnamed_addr #0 !guid !328 {
start:
; call core::f64::math::powi
  %_0 = call double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4powiCs1VtPVuSYnoF_10intrinsics(double %self, i32 %n) #23
  ret double %_0
}

; <f32>::max
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvMNtCsl10jNU3mE6R_4core3f32f3maxCs1VtPVuSYnoF_10intrinsics(float %self, float %other) unnamed_addr #0 !guid !329 {
start:
  %_0 = call nsz float @llvm.maximumnum.f32(float %self, float %other)
  ret float %_0
}

; <f32>::is_nan
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs1VtPVuSYnoF_10intrinsics(float %self) unnamed_addr #0 !guid !330 {
start:
  %_0 = fcmp une float %self, %self
  ret i1 %_0
}

; <f64>::min
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvMNtCsl10jNU3mE6R_4core3f64d3minCs1VtPVuSYnoF_10intrinsics(double %self, double %other) unnamed_addr #0 !guid !331 {
start:
  %_0 = call nsz double @llvm.minimumnum.f64(double %self, double %other)
  ret double %_0
}

; <f64>::is_nan
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCs1VtPVuSYnoF_10intrinsics(double %self) unnamed_addr #0 !guid !332 {
start:
  %_0 = fcmp une double %self, %self
  ret i1 %_0
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !333 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <[core::mem::maybe_uninit::MaybeUninit<f64>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitdE8is_emptyCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !334 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[core::mem::maybe_uninit::MaybeUninit<f32>]>::is_empty
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitfE8is_emptyCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !335 {
start:
  %_0 = icmp eq i64 %self.1, 0
  ret i1 %_0
}

; <[i32]>::split_at_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl12split_at_mutCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %pair, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #0 !guid !336 {
start:
  %_3 = alloca [32 x i8], align 8
; call <[i32]>::split_at_mut_checked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl20split_at_mut_checkedCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_3, ptr align 4 %self.0, i64 %self.1, i64 %mid) #23
  %1 = load ptr, ptr %_3, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb4, label %bb3

bb4:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %pair, ptr align 8 %_3, i64 32, i1 false)
  ret void

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %5 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_d1084648e479974e70c9329824bf76f9, i64 9) #23
  %_6.0 = extractvalue { ptr, ptr } %5, 0
  %_6.1 = extractvalue { ptr, ptr } %5, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_6.0, ptr %_6.1, ptr align 8 %0) #27
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <[i32]>::as_mut_ptr_range
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl16as_mut_ptr_rangeCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !337 {
start:
  %_0.i = getelementptr inbounds nuw i32, ptr %self.0, i64 %self.1
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_0.i, 1
  ret { ptr, ptr } %1
}

; <[i32]>::split_at_mut_checked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl20split_at_mut_checkedCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_0, ptr align 4 %self.0, i64 %self.1, i64 %mid) unnamed_addr #0 !guid !338 {
start:
  %_6 = alloca [32 x i8], align 8
  %_3 = icmp ule i64 %mid, %self.1
  br i1 %_3, label %bb1, label %bb3

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb1:                                              ; preds = %start
; call <[i32]>::split_at_mut_unchecked
  call void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl22split_at_mut_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_6, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 @alloc_a6541cbd0ddc1cb3d23757a1b3f12432) #23
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 32, i1 false)
  br label %bb4

bb4:                                              ; preds = %bb1, %bb3
  ret void
}

; <[i32]>::split_at_mut_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl22split_at_mut_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_0, ptr align 4 %self.0, i64 %self.1, i64 %mid, ptr align 8 %0) unnamed_addr #0 !guid !339 {
start:
  br label %bb2

bb2:                                              ; preds = %start
; call <[_]>::split_at_mut_unchecked::precondition_check
  call void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %mid, i64 %self.1, ptr align 8 %0) #24
  br label %bb3

bb3:                                              ; preds = %bb2
; call core::slice::raw::from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %mid, ptr align 8 %0) #23
  %_8.0 = extractvalue { ptr, i64 } %1, 0
  %_8.1 = extractvalue { ptr, i64 } %1, 1
  %_0.i = getelementptr inbounds nuw i32, ptr %self.0, i64 %mid
  %_11 = sub nuw i64 %self.1, %mid
; call core::slice::raw::from_raw_parts_mut::<i32>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %_0.i, i64 %_11, ptr align 8 %0) #23
  %_9.0 = extractvalue { ptr, i64 } %2, 0
  %_9.1 = extractvalue { ptr, i64 } %2, 1
  store ptr %_8.0, ptr %_0, align 8
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_8.1, ptr %3, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 16
  store ptr %_9.0, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  store i64 %_9.1, ptr %5, align 8
  ret void
}

; <[i32]>::reverse
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core5sliceSl7reverseCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) unnamed_addr #0 !guid !340 {
start:
  %_0.i = alloca [8 x i8], align 8
  %_11 = alloca [32 x i8], align 8
  %half_len = udiv i64 %self.1, 2
; call <[i32]>::as_mut_ptr_range
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl16as_mut_ptr_rangeCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1) #23
  %_8.0 = extractvalue { ptr, ptr } %0, 0
  %_8.1 = extractvalue { ptr, ptr } %0, 1
; call core::slice::raw::from_raw_parts_mut::<i32>
  %1 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %_8.0, i64 %half_len, ptr align 8 @alloc_c0be9056d9e7c9d32564b353e6cdd76b) #23
  %_12.0 = extractvalue { ptr, i64 } %1, 0
  %_12.1 = extractvalue { ptr, i64 } %1, 1
  %_3.i = sub nsw i64 0, %half_len
  %2 = getelementptr inbounds i32, ptr %_8.1, i64 %_3.i
  store ptr %2, ptr %_0.i, align 8
  %3 = load ptr, ptr %_0.i, align 8
; call core::slice::raw::from_raw_parts_mut::<i32>
  %4 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %3, i64 %half_len, ptr align 8 @alloc_11a111513757e9d53adfd2e1c4df0866) #23
  %_13.0 = extractvalue { ptr, i64 } %4, 0
  %_13.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_12.0, ptr %_11, align 8
  %5 = getelementptr inbounds i8, ptr %_11, i64 8
  store i64 %_12.1, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_11, i64 16
  store ptr %_13.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %_13.1, ptr %7, align 8
  %front_half.0 = load ptr, ptr %_11, align 8
  %8 = getelementptr inbounds i8, ptr %_11, i64 8
  %front_half.1 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_11, i64 16
  %back_half.0 = load ptr, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  %back_half.1 = load i64, ptr %10, align 8
; call <[_]>::reverse::revswap::<i32>
  call void @_RINvNvMNtCsl10jNU3mE6R_4core5sliceSp7reverse7revswaplECs1VtPVuSYnoF_10intrinsics(ptr align 4 %front_half.0, i64 %front_half.1, ptr align 4 %back_half.0, i64 %back_half.1, i64 %half_len) #23
  ret void
}

; <core::option::Option<i128>>::is_none
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_noneCs1VtPVuSYnoF_10intrinsics(ptr align 16 %self) unnamed_addr #0 !guid !341 {
start:
; call <core::option::Option<i128>>::is_some
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCs1VtPVuSYnoF_10intrinsics(ptr align 16 %self) #23
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::option::Option<i128>>::is_some
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionnE7is_someCs1VtPVuSYnoF_10intrinsics(ptr align 16 %self) unnamed_addr #0 !guid !342 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_2 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCs1VtPVuSYnoF_10intrinsics(ptr align 4 %x.0, i64 %x.1) unnamed_addr #1 !guid !343 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !344 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !345 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitdEja_EE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !346 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 96, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitdEja_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !347 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitfEj5_EE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !348 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 40, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitfEj5_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !349 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::slice::sort::shared::smallsort::CopyOnDrop<i32>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtNtB6_5slice4sort6shared9smallsort10CopyOnDroplEE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 !guid !350 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::hint::select_unpredictable::DropOnPanic<*const i32>>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNvNtB6_4hint20select_unpredictable11DropOnPanicPlEE3newCs1VtPVuSYnoF_10intrinsics(ptr %x) unnamed_addr #1 !guid !351 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<*const i32>>::new
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingPlE3newCs1VtPVuSYnoF_10intrinsics(ptr %x) unnamed_addr #1 !guid !352 {
start:
  ret ptr %x
}

; <core::mem::maybe_dangling::MaybeDangling<i32>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 4 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE6as_refCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self) unnamed_addr #1 !guid !353 {
start:
  ret ptr %self
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !354 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %align, ptr align 8 %0) #24
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs1VtPVuSYnoF_10intrinsics(i64 %self) unnamed_addr #0 !guid !355 {
start:
  ret i64 %self
}

; <core::ops::index_range::IndexRange>::next_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !356 {
start:
  %value = load i64, ptr %self, align 8
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

bb2.i:                                            ; preds = %start
; call <usize>::unchecked_add::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %value, i64 1, ptr align 8 @alloc_de9a5d9a80d554992107c1ea3afec081) #24
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add.exit: ; preds = %start, %bb2.i
  %_0.i = add nuw i64 %value, 1
  store i64 %_0.i, ptr %self, align 8
  ret i64 %value
}

; <core::ops::index_range::IndexRange>::end
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !357 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !358 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_2 = load i64, ptr %0, align 8
  %_3 = load i64, ptr %self, align 8
  %_0 = sub nuw i64 %_2, %_3
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::start
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !359 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::ops::index_range::IndexRange>::zero_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs1VtPVuSYnoF_10intrinsics(i64 %end) unnamed_addr #0 !guid !360 {
start:
  %0 = insertvalue { i64, i64 } { i64 0, i64 poison }, i64 %end, 1
  ret { i64, i64 } %0
}

; <*mut i32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !361 {
start:
; call <*const i32>::offset_from_unsigned
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %origin, ptr align 8 %0) #23
  ret i64 %_0
}

; <*const i32>::offset_from_unsigned
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %origin, ptr align 8 %0) unnamed_addr #0 !guid !362 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %_8 = icmp ult i64 0, 4
  br i1 %_8, label %bb5, label %bb7

bb2:                                              ; preds = %start
; call <*const _>::offset_from_unsigned::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %origin, ptr align 8 %0) #24
  br label %bb3

bb7:                                              ; preds = %bb5, %bb3
; call core::panicking::panic
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr @alloc_ec595fc0e82ef92fc59bd74f68296eae, i64 73, ptr align 8 %0) #27
  unreachable

bb5:                                              ; preds = %bb3
  %_9 = icmp ule i64 4, 9223372036854775807
  br i1 %_9, label %bb6, label %bb7

bb6:                                              ; preds = %bb5
  %1 = ptrtoint ptr %self to i64
  %2 = ptrtoint ptr %origin to i64
  %3 = sub nuw i64 %1, %2
  %_0 = udiv exact i64 %3, 4
  ret i64 %_0
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !363 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCs1VtPVuSYnoF_10intrinsics(i64 %_3) #23
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #23
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !364 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %alignment, ptr align 8 %0) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !365 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !366 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <core::array::iter::IntoIter<f64, 10>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterdKja_E10unsize_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !367 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitdEja_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 10, 1
  ret { ptr, i64 } %1
}

; <core::array::iter::IntoIter<f32, 5>>::unsize_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterfKj5_E10unsize_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !368 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitfEj5_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self)
  %0 = insertvalue { ptr, i64 } poison, ptr %_0.i, 0
  %1 = insertvalue { ptr, i64 } %0, i64 5, 1
  ret { ptr, i64 } %1
}

; <core::slice::sort::stable::AlignedStorage<i32, 4096>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E19as_uninit_slice_mutCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self) unnamed_addr #1 !guid !369 {
start:
  %_4 = icmp eq i64 4, 0
  br i1 %_4, label %panic, label %bb2

bb2:                                              ; preds = %start
  %len = udiv i64 4096, 4
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %len, ptr align 8 @alloc_2491cc18f41182435b2301519a149a1c) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_f5abd596fd0c54395cb86286cae95a93) #27
  unreachable
}

; <core::slice::sort::stable::AlignedStorage<i32, 4096>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtCsl10jNU3mE6R_4core5slice4sort6stableINtB2_14AlignedStoragelKj1000_E3newCs1VtPVuSYnoF_10intrinsics(ptr sret([4096 x i8]) align 4 %_0) unnamed_addr #1 !guid !370 {
start:
  %_1 = alloca [4096 x i8], align 1
  call void @llvm.memset.p0.i64(ptr align 1 %_1, i8 undef, i64 4096, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0, ptr align 1 %_1, i64 4096, i1 false)
  ret void
}

; <core::slice::sort::stable::quicksort::PartitionState<i32>>::partition_one
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE13partition_oneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, i1 zeroext %towards_left) unnamed_addr #1 !guid !371 {
start:
  %_0.i1 = alloca [8 x i8], align 8
  %dst_base = alloca [8 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 24
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i32, ptr %_4, i64 -1
  store ptr %1, ptr %_0.i1, align 8
  %2 = load ptr, ptr %_0.i1, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 24
  store ptr %2, ptr %3, align 8
  br i1 %towards_left, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 24
  %5 = load ptr, ptr %4, align 8
  store ptr %5, ptr %dst_base, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %6 = load ptr, ptr %self, align 8
  store ptr %6, ptr %dst_base, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %_6 = load ptr, ptr %dst_base, align 8
  %7 = getelementptr inbounds i8, ptr %self, i64 16
  %_7 = load i64, ptr %7, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_6, i64 %_7
  %8 = getelementptr inbounds i8, ptr %self, i64 8
  %_9 = load ptr, ptr %8, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %bb4
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_9, ptr %_0.i, i64 4, i64 4, i64 1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %bb4, %bb2.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_0.i, ptr align 4 %_9, i64 4, i1 false)
  %_10 = zext i1 %towards_left to i64
  %9 = getelementptr inbounds i8, ptr %self, i64 16
  %10 = getelementptr inbounds i8, ptr %self, i64 16
  %11 = load i64, ptr %10, align 8
  %12 = add i64 %11, %_10
  store i64 %12, ptr %9, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_12 = load ptr, ptr %13, align 8
  %_0.i3 = getelementptr inbounds nuw i32, ptr %_12, i64 1
  %14 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_0.i3, ptr %14, align 8
  ret ptr %_0.i
}

; <core::slice::sort::stable::quicksort::PartitionState<i32>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortINtB2_14PartitionStatelE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 8 %_0, ptr %scan, ptr %scratch, i64 %len) unnamed_addr #1 !guid !372 {
start:
  %_0.i = getelementptr inbounds nuw i32, ptr %scratch, i64 %len
  store ptr %scratch, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %scan, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 24
  store ptr %_0.i, ptr %2, align 8
  ret void
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !373 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs1VtPVuSYnoF_10intrinsics(i64 %3, i64 %5, i1 zeroext %8) #23
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !374 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs1VtPVuSYnoF_10intrinsics(ptr %2, i64 %4, i64 %6) #23
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !375 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #23
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs1VtPVuSYnoF_10intrinsics(i64 %11, i64 %13) #23
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs1VtPVuSYnoF_10intrinsics(i64 %15, i64 %17) #23
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #23
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #23
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #23
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #23
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #23
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !376 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %3, i64 %5) #23
  br label %bb3
}

; <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !377 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<i32>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_caplECs1VtPVuSYnoF_10intrinsics(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #23
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<i32>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !378 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<i32>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrlECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<i32>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !379 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8 %self, i64 4) #23
  ret i64 %_0
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs1VtPVuSYnoF_10intrinsics(i32 %self) unnamed_addr #0 !guid !380 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs1VtPVuSYnoF_10intrinsics(i32 %self) #23
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCs1VtPVuSYnoF_10intrinsics(i32 %self) unnamed_addr #0 !guid !381 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::unique::Unique<[i32]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCs1VtPVuSYnoF_10intrinsics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !382 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::unique::Unique<i32>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquelE15as_non_null_ptrCs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !383 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<u128>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionoEE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 16 %r) unnamed_addr #0 !guid !384 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::vec::Vec<i32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtCs7CppTae75M1_5alloc3vec3VeclEE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %r) unnamed_addr #0 !guid !385 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::cmp::Ordering>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtB9_3cmp8OrderingE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %r) unnamed_addr #0 !guid !386 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i8>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %r) unnamed_addr #0 !guid !387 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCs1VtPVuSYnoF_10intrinsics(ptr %r) unnamed_addr #0 !guid !388 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulldE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %r) unnamed_addr #0 !guid !389 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<f32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullfE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 4 %r) unnamed_addr #0 !guid !390 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullnE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 16 %r) unnamed_addr #0 !guid !391 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i16>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullsE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 2 %r) unnamed_addr #0 !guid !392 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<i64>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullxE8from_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %r) unnamed_addr #0 !guid !393 {
start:
  ret ptr %r
}

; <core::num::nonzero::NonZero<usize>>::leading_zeros
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCs1VtPVuSYnoF_10intrinsics(i64 %self) unnamed_addr #0 !guid !394 {
start:
; call <core::num::nonzero::NonZero<usize>>::get
  %_2 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %self) #23
  %0 = call i64 @llvm.ctlz.i64(i64 %_2, i1 true)
  %_0 = trunc i64 %0 to i32
  ret i32 %_0
}

; <core::num::nonzero::NonZero<usize>>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %self) unnamed_addr #0 !guid !395 {
start:
; call <core::num::nonzero::NonZero<usize>>::leading_zeros
  %_3 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE13leading_zerosCs1VtPVuSYnoF_10intrinsics(i64 %self) #23
  %_0 = sub i32 63, %_3
  ret i32 %_0
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %val) unnamed_addr #0 !guid !396 {
start:
  ret i64 %val
}

; <i128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCsl10jNU3mE6R_4core3numn11checked_mulCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !397 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.smul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEja_E13new_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 8 %data) unnamed_addr #0 !guid !398 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %data, i64 80, i1 false)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEj5_E13new_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %_0, i64 %alive.0, i64 %alive.1, ptr align 4 %data) unnamed_addr #0 !guid !399 {
start:
  store i64 %alive.0, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %alive.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 4 %data, i64 20, i1 false)
  ret void
}

; <alloc::raw_vec::RawVec<i32>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE16with_capacity_inCs1VtPVuSYnoF_10intrinsics(i64 %capacity) unnamed_addr #0 !guid !400 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64 %capacity, i64 4, i64 4) #23
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !401 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCs1VtPVuSYnoF_10intrinsics(ptr %s.0, i64 %s.1) #23
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <alloc::boxed::Box<[i32]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlE23into_raw_with_allocatorCs1VtPVuSYnoF_10intrinsics(ptr align 4 %b.0, i64 %b.1) unnamed_addr #0 !guid !402 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE3newCs1VtPVuSYnoF_10intrinsics(ptr align 4 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[i32]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSlEE6as_refCs1VtPVuSYnoF_10intrinsics(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <u64>::div_ceil
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs7_NtCsl10jNU3mE6R_4core3numy8div_ceilCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #0 !guid !403 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  %_6 = icmp eq i64 %rhs, 0
  br i1 %_6, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #27
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_7 = icmp ugt i64 %r, 0
  br i1 %_7, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #27
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <u128>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_addCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !404 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_5.0 = add i128 %self, %rhs
  %_5.1 = icmp ult i128 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i128 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_6, ptr %2, align 16
  store i128 1, ptr %_0, align 16
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  ret void
}

; <u128>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs8_NtCsl10jNU3mE6R_4core3numo11checked_mulCs1VtPVuSYnoF_10intrinsics(ptr sret([32 x i8]) align 16 %_0, i128 %self, i128 %rhs) unnamed_addr #0 !guid !405 {
start:
  %_0.i = alloca [1 x i8], align 1
  %0 = alloca [32 x i8], align 16
  %1 = call { i128, i1 } @llvm.umul.with.overflow.i128(i128 %self, i128 %rhs)
  %_5.0.i = extractvalue { i128, i1 } %1, 0
  %_5.1.i = extractvalue { i128, i1 } %1, 1
  store i128 %_5.0.i, ptr %0, align 16
  %2 = getelementptr inbounds i8, ptr %0, i64 16
  %3 = zext i1 %_5.1.i to i8
  store i8 %3, ptr %2, align 16
  %_5.0 = load i128, ptr %0, align 16
  %4 = getelementptr inbounds i8, ptr %0, i64 16
  %5 = load i8, ptr %4, align 16
  %_5.1 = trunc nuw i8 %5 to i1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %6 = load i8, ptr %_0.i, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %8 = getelementptr inbounds i8, ptr %_0, i64 16
  store i128 %_5.0, ptr %8, align 16
  store i128 1, ptr %_0, align 16
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i128 0, ptr %_0, align 16
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, double } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEE4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !406 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0) #23
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<f64, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next::{closure#0}>
  %1 = call { i64, double } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapdNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdEE4next0ECs1VtPVuSYnoF_10intrinsics(i64 %_2.0, i64 %_2.1, ptr align 8 %_5.0, i64 %self.1) #23
  %_0.0 = extractvalue { i64, double } %1, 0
  %_0.1 = extractvalue { i64, double } %1, 1
  %2 = insertvalue { i64, double } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, double } %2, double %_0.1, 1
  ret { i64, double } %3
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, float } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEE4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1) unnamed_addr #0 !guid !407 {
start:
; call <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
  %0 = call { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0) #23
  %_2.0 = extractvalue { i64, i64 } %0, 0
  %_2.1 = extractvalue { i64, i64 } %0, 1
  %_5.0 = getelementptr inbounds i8, ptr %self.0, i64 16
; call <core::option::Option<usize>>::map::<f32, <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next::{closure#0}>
  %1 = call { i32, float } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionjE3mapfNCNvMs8_NtNtNtB5_5array4iter10iter_innerINtBX_15PolymorphicIterSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfEE4next0ECs1VtPVuSYnoF_10intrinsics(i64 %_2.0, i64 %_2.1, ptr align 4 %_5.0, i64 %self.1) #23
  %_0.0 = extractvalue { i32, float } %1, 0
  %_0.1 = extractvalue { i32, float } %1, 1
  %2 = insertvalue { i32, float } poison, i32 %_0.0, 0
  %3 = insertvalue { i32, float } %2, float %_0.1, 1
  ret { i32, float } %3
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs1VtPVuSYnoF_10intrinsics(ptr %self) unnamed_addr #0 !guid !408 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %rhs) unnamed_addr #0 !guid !409 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::checked_sub
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %rhs) unnamed_addr #0 !guid !410 {
start:
  %_0 = alloca [16 x i8], align 8
  %_3 = icmp ult i64 %self, %rhs
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = sub nuw i64 %self, %rhs
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_4, ptr %0, align 8
  store i64 1, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <usize>::checked_ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %self) unnamed_addr #0 !guid !411 {
start:
  %_2 = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 4
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %self) #23
  store i64 %0, ptr %_2, align 8
  %1 = load i64, ptr %_2, align 8
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %x = load i64, ptr %_2, align 8
; call <core::num::nonzero::NonZero<usize>>::ilog2
  %_5 = call i32 @_RNvMs1f_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB6_7NonZerojE5ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %x) #23
  %4 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %4, align 4
  store i32 1, ptr %_0, align 4
  br label %bb6

bb3:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3
  %5 = load i32, ptr %_0, align 4
  %6 = getelementptr inbounds i8, ptr %_0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = insertvalue { i32, i32 } poison, i32 %5, 0
  %9 = insertvalue { i32, i32 } %8, i32 %7, 1
  ret { i32, i32 } %9

bb2:                                              ; No predecessors!
  unreachable
}

; <usize>::is_multiple_of
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj14is_multiple_ofCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %rhs) unnamed_addr #0 !guid !412 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = icmp eq i64 %rhs, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %self, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %_0, align 1
  br label %bb4

bb1:                                              ; preds = %start
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb3

bb4:                                              ; preds = %bb3, %bb2
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  ret i1 %4

bb3:                                              ; preds = %bb1
  %_3 = urem i64 %self, %rhs
  %5 = icmp eq i64 %_3, 0
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 @alloc_9f4cf96e0cfa121f5a07edf0a5a77ed7) #27
  unreachable
}

; <usize>::ilog2
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj5ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %self, ptr align 8 %0) unnamed_addr #0 !guid !413 {
start:
  %_2 = alloca [8 x i8], align 4
; call <usize>::checked_ilog2
  %1 = call { i32, i32 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj13checked_ilog2Cs1VtPVuSYnoF_10intrinsics(i64 %self) #23
  %2 = extractvalue { i32, i32 } %1, 0
  %3 = extractvalue { i32, i32 } %1, 1
  store i32 %2, ptr %_2, align 4
  %4 = getelementptr inbounds i8, ptr %_2, i64 4
  store i32 %3, ptr %4, align 4
  %5 = load i32, ptr %_2, align 4
  %6 = getelementptr inbounds i8, ptr %_2, i64 4
  %7 = load i32, ptr %6, align 4
  %_3 = zext i32 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %_2, i64 4
  %log = load i32, ptr %9, align 4
  ret i32 %log

bb3:                                              ; preds = %start
; call core::num::imp::int_log10::panic_for_nonpositive_argument
  call void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8 %0) #26
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %other) unnamed_addr #0 !guid !414 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCs1VtPVuSYnoF_10intrinsics(i32 %_0.i) #23
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<i32>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclE16with_capacity_inCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !415 {
start:
; call <alloc::raw_vec::RawVec<i32>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE16with_capacity_inCs1VtPVuSYnoF_10intrinsics(i64 %capacity) #23
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Cs1VtPVuSYnoF_10intrinsics(i8 %0) unnamed_addr #0 !guid !416 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Cs1VtPVuSYnoF_10intrinsics(ptr %self) #23
  ret i32 %_0
}

; <alloc::vec::Vec<i32>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !417 {
start:
; call <alloc::raw_vec::RawVec<i32>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  ret ptr %_0
}

; <alloc::vec::Vec<i32>>::as_mut_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE12as_mut_sliceCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !418 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<i32>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE17from_raw_parts_inCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !419 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<i32>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE17from_raw_parts_inCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %capacity) #23
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<i32>>::spare_capacity_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE18spare_capacity_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !420 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_4 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %0, align 8
  %_0.i = getelementptr inbounds nuw i32, ptr %_4, i64 %_5
; call <alloc::raw_vec::RawVec<i32>>::capacity
  %_7 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE8capacityCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load i64, ptr %1, align 8
  %_6 = sub i64 %_7, %_9
; call core::slice::raw::from_raw_parts_mut::<core::mem::maybe_uninit::MaybeUninit<i32>>
  %2 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mutINtNtNtB6_3mem12maybe_uninit11MaybeUninitlEECs1VtPVuSYnoF_10intrinsics(ptr %_0.i, i64 %_6, ptr align 8 @alloc_027cef065c3c71aa2f31a680ec9e0201) #23
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <alloc::vec::Vec<i32>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6as_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !421 {
start:
; call <alloc::raw_vec::RawVec<i32>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclE3ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  ret ptr %_2
}

; <alloc::vec::Vec<i32>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8as_sliceCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !422 {
start:
; call <alloc::vec::Vec<i32>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE6as_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitdEja_EE4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %slot) unnamed_addr #0 !guid !423 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitdEja_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitdEja_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_3)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitfEj5_EE4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %slot) unnamed_addr #0 !guid !424 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::as_mut
  %_3 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitfEj5_EE6as_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %slot)
; call core::ptr::drop_glue::<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtNtB4_5array4iter10iter_inner15PolymorphicIterAINtNtNtB4_3mem12maybe_uninit11MaybeUninitfEj5_EECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_3)
  ret void
}

; <*mut i32>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %len) unnamed_addr #0 !guid !425 {
start:
; call core::ptr::slice_from_raw_parts_mut::<i32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutlECs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %len) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1) unnamed_addr #0 !guid !426 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !427 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #28
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1) unnamed_addr #0 !guid !428 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCs1VtPVuSYnoF_10intrinsics(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !429 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs1VtPVuSYnoF_10intrinsics(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #23
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #26
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #23
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::maximum_number_nsz_f32
; Function Attrs: nounwind nonlazybind uwtable
define internal float @_RNvNtCsl10jNU3mE6R_4core10intrinsics22maximum_number_nsz_f32Cs1VtPVuSYnoF_10intrinsics(float %x, float %y) unnamed_addr #2 personality ptr @rust_eh_personality !guid !430 {
start:
  %_0 = alloca [4 x i8], align 4
; invoke <f32>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f32f6is_nanCs1VtPVuSYnoF_10intrinsics(float %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp oge float %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store float %y, ptr %_0, align 4
  br label %bb5

bb4:                                              ; preds = %bb2
  store float %x, ptr %_0, align 4
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load float, ptr %_0, align 4
  ret float %1
}

; core::intrinsics::minimum_number_nsz_f64
; Function Attrs: nounwind nonlazybind uwtable
define internal double @_RNvNtCsl10jNU3mE6R_4core10intrinsics22minimum_number_nsz_f64Cs1VtPVuSYnoF_10intrinsics(double %x, double %y) unnamed_addr #2 personality ptr @rust_eh_personality !guid !431 {
start:
  %_0 = alloca [8 x i8], align 8
; invoke <f64>::is_nan
  %_3 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core3f64d6is_nanCs1VtPVuSYnoF_10intrinsics(double %x)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %0 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb3, label %bb2

bb2:                                              ; preds = %bb1
  %_4 = fcmp ole double %y, %x
  br i1 %_4, label %bb3, label %bb4

bb3:                                              ; preds = %bb2, %bb1
  store double %y, ptr %_0, align 8
  br label %bb5

bb4:                                              ; preds = %bb2
  store double %x, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %1 = load double, ptr %_0, align 8
  ret double %1
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCs1VtPVuSYnoF_10intrinsics() unnamed_addr #5 !guid !432 {
start:
  ret void
}

; core::ptr::swap_nonoverlapping_bytes
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytesCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %bytes) unnamed_addr #0 !guid !433 {
start:
  %_15 = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #23
  %chunks = udiv i64 %bytes1, 8
  %tail = urem i64 %bytes1, 8
; call <core::num::nonzero::NonZero<usize>>::new
  %0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %chunks) #23
  store i64 %0, ptr %_9, align 8
  %1 = load i64, ptr %_9, align 8
  %2 = icmp eq i64 %1, 0
  %_10 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_10 to i1
  br i1 %3, label %bb5, label %bb8

bb5:                                              ; preds = %start
  %chunks2 = load i64, ptr %_9, align 8
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
  call void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr %x, ptr %y, i64 %chunks2)
  br label %bb8

bb8:                                              ; preds = %bb5, %start
; call <core::num::nonzero::NonZero<usize>>::new
  %4 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64 %tail) #23
  store i64 %4, ptr %_15, align 8
  %5 = load i64, ptr %_15, align 8
  %6 = icmp eq i64 %5, 0
  %_16 = select i1 %6, i64 0, i64 1
  %7 = trunc nuw i64 %_16 to i1
  br i1 %7, label %bb10, label %bb13

bb10:                                             ; preds = %bb8
  %tail3 = load i64, ptr %_15, align 8
  %delta = mul i64 %chunks, 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %delta
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %delta
; call core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCs1VtPVuSYnoF_10intrinsics(ptr %_0.i4, ptr %_0.i, i64 %tail3) #23
  br label %bb13

bb13:                                             ; preds = %bb10, %bb8
  ret void

bb14:                                             ; No predecessors!
  unreachable
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %align) unnamed_addr #0 !guid !434 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %align) #23
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() unnamed_addr #0 !guid !435 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs1VtPVuSYnoF_10intrinsics(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !436 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs1VtPVuSYnoF_10intrinsics(ptr %3, ptr %5, i64 %7, i64 %9) #23
  ret i1 %_0
}

; core::ub_checks::is_valid_allocation_size
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %len) unnamed_addr #0 !guid !437 {
start:
  %max_len = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %size, 0
  br i1 %_4, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_6 = icmp eq i64 %size, 0
  br i1 %_6, label %panic, label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %max_len, align 8
  br label %bb4

bb3:                                              ; preds = %bb2
  %0 = udiv i64 9223372036854775807, %size
  store i64 %0, ptr %max_len, align 8
  br label %bb4

panic:                                            ; preds = %bb2
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 @alloc_61dde53e4938ab5b281c865c498eaeb6) #27
  unreachable

bb4:                                              ; preds = %bb1, %bb3
  %_7 = load i64, ptr %max_len, align 8
  %_0 = icmp ule i64 %len, %_7
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !438 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %align) #23
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr %ptr) #23
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::f32::math::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal float @_RNvNtNtCsl10jNU3mE6R_4core3f324math4powiCs1VtPVuSYnoF_10intrinsics(float %x, i32 %n) unnamed_addr #0 !guid !439 {
start:
  %_0 = call float @llvm.powi.f32.i32(float %x, i32 %n)
  ret float %_0
}

; core::f64::math::powi
; Function Attrs: inlinehint nonlazybind uwtable
define internal double @_RNvNtNtCsl10jNU3mE6R_4core3f644math4powiCs1VtPVuSYnoF_10intrinsics(double %x, i32 %n) unnamed_addr #0 !guid !440 {
start:
  %_0 = call double @llvm.powi.f64.i32(double %x, i32 %n)
  ret double %_0
}

; <[_]>::split_at_mut_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtCsl10jNU3mE6R_4core5sliceSp22split_at_mut_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %mid, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !441 {
start:
  %_3 = icmp ule i64 %mid, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_6b0b11c9e93314b588b613b55005cf18, i64 221)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %align, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !442 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <*const _>::offset_from_unsigned::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %this, ptr %origin, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !443 {
start:
; invoke <*const _>::offset_from_unsigned::runtime_ptr_ge
  %_3 = invoke zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr %this, ptr %origin)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_de4e626d456b04760e72bc785ed7e52a, i64 201)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !444 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <usize>::unchecked_add::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_add18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !445 {
start:
  %_5.0.i = add i64 %lhs, %rhs
  %_5.1.i = icmp ult i64 %_5.0.i, %lhs
  %1 = insertvalue { i64, i1 } poison, i64 %_5.0.i, 0
  %2 = insertvalue { i64, i1 } %1, i1 %_5.1.i, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %3 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %2, 0
  %_4.1 = extractvalue { i64, i1 } %2, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %4 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_3e1ebac14318b612ab4efabc52799932, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %4, 0
  %_6.1 = extractvalue { ptr, ptr } %4, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !446 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !447 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs1VtPVuSYnoF_10intrinsics(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ptr::swap_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19swap_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !448 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %size, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %count, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_11 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %x, i64 %align, i1 zeroext %_11)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_14 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_12 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %y, i64 %align, i1 zeroext %_14)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_12, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_2875d9f120b8cc0de1c30c014c7b6715, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_18.0 = extractvalue { ptr, ptr } %10, 0
  %_18.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_18.0, ptr %_18.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_short
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes25swap_nonoverlapping_shortCs1VtPVuSYnoF_10intrinsics(ptr %x, ptr %y, i64 %bytes) unnamed_addr #0 !guid !449 {
start:
  %i = alloca [8 x i8], align 8
; call <core::num::nonzero::NonZero<usize>>::get
  %bytes1 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64 %bytes) #23
  store i64 0, ptr %i, align 8
  %_7 = and i64 %bytes1, 4
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb2, label %bb8

bb8:                                              ; preds = %bb2, %start
  %_18 = and i64 %bytes1, 2
  %_17 = icmp ne i64 %_18, 0
  br i1 %_17, label %bb9, label %bb15

bb2:                                              ; preds = %start
  %_12 = load i64, ptr %i, align 8
  %_0.i6 = getelementptr inbounds nuw i8, ptr %x, i64 %_12
  %_16 = load i64, ptr %i, align 8
  %_0.i5 = getelementptr inbounds nuw i8, ptr %y, i64 %_16
; call core::ptr::swap_chunk::<4>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr %_0.i6, ptr %_0.i5) #23
  %0 = load i64, ptr %i, align 8
  %1 = or i64 %0, 4
  store i64 %1, ptr %i, align 8
  br label %bb8

bb15:                                             ; preds = %bb9, %bb8
  %_29 = and i64 %bytes1, 1
  %_28 = icmp ne i64 %_29, 0
  br i1 %_28, label %bb16, label %bb22

bb9:                                              ; preds = %bb8
  %_23 = load i64, ptr %i, align 8
  %_0.i4 = getelementptr inbounds nuw i8, ptr %x, i64 %_23
  %_27 = load i64, ptr %i, align 8
  %_0.i3 = getelementptr inbounds nuw i8, ptr %y, i64 %_27
; call core::ptr::swap_chunk::<2>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr %_0.i4, ptr %_0.i3) #23
  %2 = load i64, ptr %i, align 8
  %3 = or i64 %2, 2
  store i64 %3, ptr %i, align 8
  br label %bb15

bb22:                                             ; preds = %bb16, %bb15
  ret void

bb16:                                             ; preds = %bb15
  %_34 = load i64, ptr %i, align 8
  %_0.i2 = getelementptr inbounds nuw i8, ptr %x, i64 %_34
  %_38 = load i64, ptr %i, align 8
  %_0.i = getelementptr inbounds nuw i8, ptr %y, i64 %_38
; call core::ptr::swap_chunk::<1>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr %_0.i2, ptr %_0.i) #23
  %4 = load i64, ptr %i, align 8
  %5 = or i64 %4, 1
  store i64 %5, ptr %i, align 8
  br label %bb22
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !450 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCs1VtPVuSYnoF_10intrinsics(ptr %ptr, i64 %align) unnamed_addr #0 !guid !451 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr %ptr, i64 %align) #23
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCs1VtPVuSYnoF_10intrinsics() unnamed_addr #0 !guid !452 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCs1VtPVuSYnoF_10intrinsics(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !453 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %count) #23
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCs1VtPVuSYnoF_10intrinsics(i64 %_0.i2, i64 %_0.i) #23
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #29
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; core::slice::raw::from_raw_parts::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw14from_raw_parts18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !454 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_a28e8c8fd5088943a8b5d44af697ff83, i64 279)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; core::slice::raw::from_raw_parts_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtNtCsl10jNU3mE6R_4core5slice3raw18from_raw_parts_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %size, i64 %align, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !455 {
start:
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_5 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCs1VtPVuSYnoF_10intrinsics(ptr %data, i64 %align, i1 zeroext false)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb5, %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb1:                                              ; preds = %start
  br i1 %_5, label %bb2, label %bb5

bb5:                                              ; preds = %bb3, %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_5c1a2f972552229672fc942406cfc298, i64 283)
          to label %bb6 unwind label %terminate

bb2:                                              ; preds = %bb1
; invoke core::ub_checks::is_valid_allocation_size
  %_7 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks24is_valid_allocation_sizeCs1VtPVuSYnoF_10intrinsics(i64 %size, i64 %len)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  br i1 %_7, label %bb4, label %bb5

bb4:                                              ; preds = %bb3
  ret void

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %2, 0
  %_9.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_9.0, ptr %_9.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %this, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !456 {
start:
  %_3 = icmp ult i64 %this, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_97d92cbf2a68a6ac45a1b13da79836e4, i64 214)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !457 {
start:
  %_3 = icmp ule i64 %end, %len
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_5a8fdd84b3281310cbf6b74bb6bf0065, i64 218)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %start1, i64 %end, i64 %len, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !458 {
start:
  %_4 = icmp uge i64 %end, %start1
  br i1 %_4, label %bb1, label %bb3

bb3:                                              ; preds = %bb1, %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCs1VtPVuSYnoF_10intrinsics(ptr @alloc_18d73aa062d524e9620b9e3b55bd9eb1, i64 218)
          to label %bb4 unwind label %terminate

bb1:                                              ; preds = %start
  %_5 = icmp ule i64 %end, %len
  br i1 %_5, label %bb2, label %bb3

bb2:                                              ; preds = %bb1
  ret void

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

bb4:                                              ; preds = %bb3
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_7.0, ptr %_7.1, i1 zeroext false, ptr align 8 %0) #29
  unreachable
}

; <core::slice::iter::Iter<i32> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_5slice4iter4IterlENtB2_12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr %self.0, ptr %self.1) unnamed_addr #0 !guid !459 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  ret { ptr, ptr } %1
}

; <[core::mem::maybe_uninit::MaybeUninit<f64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitdENtB2_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !460 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f64>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitdE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs1VtPVuSYnoF_10intrinsics(ptr align 8 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #23
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<f64>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitdE8is_emptyCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_3.0, i64 %_3.1) #23
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitdE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitdE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitdE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit: ; preds = %start, %bb2.i
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<f32>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitfENtB2_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !461 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f32>]>::get_unchecked_mut::<core::ops::index_range::IndexRange>
  %0 = call { ptr, i64 } @_RINvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB5_3mem12maybe_uninit11MaybeUninitfE17get_unchecked_mutNtNtNtB5_3ops11index_range10IndexRangeECs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, i64 %alive.0, i64 %alive.1, ptr align 8 @alloc_c7037efb906203803aa3ca07167c9120) #23
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<f32>]>::is_empty
  %_2.i = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core5sliceSINtNtNtB4_3mem12maybe_uninit11MaybeUninitfE8is_emptyCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_3.0, i64 %_3.1) #23
  br i1 %_2.i, label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitfE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit, label %bb2.i

bb2.i:                                            ; preds = %start
  br label %_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitfE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit

_RNvMs2_NtNtCsl10jNU3mE6R_4core3mem12maybe_uninitSINtB5_11MaybeUninitfE16assume_init_dropCs1VtPVuSYnoF_10intrinsics.exit: ; preds = %start, %bb2.i
  ret void
}

; <core::hint::select_unpredictable::DropOnPanic<*const i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNvNtCsl10jNU3mE6R_4core4hint20select_unpredictableINtB2_11DropOnPanicPlENtNtNtB6_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !462 {
start:
  %_2 = load ptr, ptr %self, align 8
  ret void
}

; <[f64; 10] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAdja_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !463 {
start:
  %0 = alloca [96 x i8], align 8
  %_2.i = alloca [96 x i8], align 8
  %1 = alloca [96 x i8], align 8
  %2 = alloca [80 x i8], align 8
  %_5 = alloca [96 x i8], align 8
  %inner = alloca [96 x i8], align 8
  %data = alloca [80 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %self, i64 80, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs1VtPVuSYnoF_10intrinsics(i64 10) #23
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %data, i64 80, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEja_E13new_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 8 %2) #23
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 96, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 96, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitdEja_EE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([96 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 96, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 96, i1 false)
  ret void
}

; <[f32; 5] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAfj5_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %_0, ptr align 4 %self) unnamed_addr #0 !guid !464 {
start:
  %0 = alloca [40 x i8], align 8
  %_2.i = alloca [40 x i8], align 8
  %1 = alloca [40 x i8], align 8
  %2 = alloca [20 x i8], align 4
  %_5 = alloca [40 x i8], align 8
  %inner = alloca [40 x i8], align 8
  %data = alloca [20 x i8], align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %data, ptr align 4 %self, i64 20, i1 false)
; call <core::ops::index_range::IndexRange>::zero_to
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange7zero_toCs1VtPVuSYnoF_10intrinsics(i64 5) #23
  %_4.0 = extractvalue { i64, i64 } %3, 0
  %_4.1 = extractvalue { i64, i64 } %3, 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %data, i64 20, i1 false)
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>::new_unchecked
  call void @_RNvMs2_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEj5_E13new_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %inner, i64 %_4.0, i64 %_4.1, ptr align 4 %2) #23
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %inner, i64 40, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 40, i1 false)
; call <core::mem::maybe_dangling::MaybeDangling<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtNtB6_5array4iter10iter_inner15PolymorphicIterAINtNtB4_12maybe_uninit11MaybeUninitfEj5_EE3newCs1VtPVuSYnoF_10intrinsics(ptr sret([40 x i8]) align 8 %_2.i, ptr align 8 %0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_5, ptr align 8 %_2.i, i64 40, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 40, i1 false)
  ret void
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitdEE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !465 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitdEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw double, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f64>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitdEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %_0.i1, ptr align 8 %0) #24
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitfEE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !466 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f32>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitfEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw float, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f32>]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitfEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %_0.i1, ptr align 8 %0) #24
  br label %bb4
}

; <usize as core::slice::index::SliceIndex<[i32]>>::get_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSlE13get_uncheckedCs1VtPVuSYnoF_10intrinsics(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !467 {
start:
; call core::ub_checks::check_language_ub
  %_3 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_3, label %bb2, label %bb4

bb4:                                              ; preds = %bb2, %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
  %_6 = icmp ult i64 %self, %_0.i
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

bb2:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i1 = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <usize as core::slice::index::SliceIndex<[_]>>::get_unchecked::precondition_check
  call void @_RNvNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB7_10SliceIndexSpE13get_unchecked18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %self, i64 %_0.i1, ptr align 8 %0) #24
  br label %bb4
}

; <i32 as core::slice::sort::stable::quicksort::IsFreeze>::is_freeze
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs0_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable9quicksortlNtB5_8IsFreeze9is_freezeCs1VtPVuSYnoF_10intrinsics() unnamed_addr #1 !guid !468 {
start:
  ret i1 true
}

; <u32 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs11_NtNtCsl10jNU3mE6R_4core3cmp5implsmNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self, ptr align 4 %other) unnamed_addr #0 !guid !469 {
start:
  %_3 = load i32, ptr %self, align 4
  %_4 = load i32, ptr %other, align 4
  %_0 = call i8 @llvm.ucmp.i8.i32(i32 %_3, i32 %_4)
  ret i8 %_0
}

; <u64 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs13_NtNtCsl10jNU3mE6R_4core3cmp5implsyNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !470 {
start:
  %_3 = load i64, ptr %self, align 8
  %_4 = load i64, ptr %other, align 8
  %_0 = call i8 @llvm.ucmp.i8.i64(i64 %_3, i64 %_4)
  ret i8 %_0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !471 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #23
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !472 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCs1VtPVuSYnoF_10intrinsics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !473 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitdEE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !474 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f64>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitdEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %_5, i64 %_0.i, ptr align 8 %2) #24
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %ptr.i = getelementptr inbounds nuw double, ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtB9_3ops11index_range10IndexRangeINtB5_10SliceIndexSINtNtNtB9_3mem12maybe_uninit11MaybeUninitfEE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %0, i64 %1, ptr %slice.0, i64 %slice.1, ptr align 8 %2) unnamed_addr #0 !guid !475 {
start:
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ops::index_range::IndexRange>::end
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3endCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
; call core::ptr::metadata::metadata::<[core::mem::maybe_uninit::MaybeUninit<f32>]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSINtNtNtB6_3mem12maybe_uninit11MaybeUninitfEECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <core::ops::index_range::IndexRange as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs1_NtNtCsl10jNU3mE6R_4core5slice5indexNtNtNtBb_3ops11index_range10IndexRangeINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %_5, i64 %_0.i, ptr align 8 %2) #24
  br label %bb4

bb4:                                              ; preds = %bb1
; call <core::ops::index_range::IndexRange>::start
  %_8 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange5startCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
; call <core::ops::index_range::IndexRange>::len
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange3lenCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %ptr.i = getelementptr inbounds nuw float, ptr %slice.0, i64 %_8
  %4 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %5 = insertvalue { ptr, i64 } %4, i64 %_10, 1
  %_0.0 = extractvalue { ptr, i64 } %5, 0
  %_0.1 = extractvalue { ptr, i64 } %5, 1
  %6 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %_0.1, 1
  ret { ptr, i64 } %7
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEja_ENtNtNtBb_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !476 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<f64>; 10] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitdEja_NtB4_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterAINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEj5_ENtNtNtBb_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !477 {
start:
  %_2 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ops::index_range::IndexRange as core::clone::Clone>::clone
  %0 = call { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_3.0 = extractvalue { i64, i64 } %0, 0
  %_3.1 = extractvalue { i64, i64 } %0, 1
; call <[core::mem::maybe_uninit::MaybeUninit<f32>; 5] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitfEj5_NtB4_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_2, i64 %_3.0, i64 %_3.1)
  ret void
}

; <i64 as core::cmp::Ord>::cmp
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXs1f_NtNtCsl10jNU3mE6R_4core3cmp5implsxNtB8_3Ord3cmpCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !478 {
start:
  %_3 = load i64, ptr %self, align 8
  %_4 = load i64, ptr %other, align 8
  %_0 = call i8 @llvm.scmp.i8.i64(i64 %_3, i64 %_4)
  ret i8 %_0
}

; <&u128 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRoNtB6_5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !479 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u128 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 16 %_3, ptr align 8 %f) #23
  ret i1 %_0
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::get_unchecked_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE17get_unchecked_mutCs1VtPVuSYnoF_10intrinsics(i64 %self.0, i64 %self.1, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !480 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call core::ptr::metadata::metadata::<[i32]>
  %_0.i = call i64 @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata8metadataSlECs1VtPVuSYnoF_10intrinsics(ptr %slice.0, i64 %slice.1) #23
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[_]>>::get_unchecked_mut::precondition_check
  call void @_RNvNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtBb_3ops5range5RangejEINtB7_10SliceIndexSpE17get_unchecked_mut18precondition_checkCs1VtPVuSYnoF_10intrinsics(i64 %self.0, i64 %self.1, i64 %_0.i, ptr align 8 %0) #24
  br label %bb3

bb3:                                              ; preds = %bb1
  %new_len = sub nuw i64 %self.1, %self.0
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self.0
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_0.0 = extractvalue { ptr, i64 } %2, 0
  %_0.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_0.1, 1
  ret { ptr, i64 } %4
}

; <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %self.0, i64 %self.1, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !481 {
start:
  %_3 = alloca [16 x i8], align 8
; call <usize>::checked_sub
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_subCs1VtPVuSYnoF_10intrinsics(i64 %self.1, i64 %self.0) #23
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_6 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_6 to i1
  br i1 %7, label %bb2, label %bb5

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %new_len = load i64, ptr %8, align 8
  %_8 = icmp ule i64 %self.1, %slice.1
  br i1 %_8, label %bb3, label %bb5

bb5:                                              ; preds = %bb2, %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self.0, i64 %self.1, i64 %slice.1, ptr align 8 %0) #27
  unreachable

bb3:                                              ; preds = %bb2
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self.0
  %9 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %new_len, 1
  %_12.0 = extractvalue { ptr, i64 } %10, 0
  %_12.1 = extractvalue { ptr, i64 } %10, 1
  %11 = insertvalue { ptr, i64 } poison, ptr %_12.0, 0
  %12 = insertvalue { ptr, i64 } %11, i64 %_12.1, 1
  ret { ptr, i64 } %12

bb6:                                              ; No predecessors!
  unreachable
}

; <core::cmp::Ordering as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs3_NtCsl10jNU3mE6R_4core3cmpNtB5_8OrderingNtNtB7_3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !482 {
start:
  %_3 = alloca [16 x i8], align 8
  %_4 = load i8, ptr %self, align 1
  switch i8 %_4, label %bb1 [
    i8 -1, label %bb4
    i8 0, label %bb3
    i8 1, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb4:                                              ; preds = %start
  store ptr @alloc_a9c61c9f249d39e49475c00b6de04ee0, ptr %_3, align 8, !captures !243
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %0, align 8
  br label %bb5

bb3:                                              ; preds = %start
  store ptr @alloc_cd17b9cbc635e79a5454e667c96efc06, ptr %_3, align 8, !captures !243
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 5, ptr %1, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr @alloc_a2975b4a9399ac4e26287fc3f00ae96d, ptr %_3, align 8, !captures !243
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 7, ptr %2, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3, %bb4
  %3 = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %3, i64 %5)
  ret i1 %_0
}

; <core::array::iter::IntoIter<f64, 10> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, double } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterdKja_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !483 {
start:
; call <core::array::iter::IntoIter<f64, 10>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterdKja_E10unsize_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>]>>::next
  %1 = call { i64, double } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitdEE4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_2.0, i64 %_2.1) #23
  %_0.0 = extractvalue { i64, double } %1, 0
  %_0.1 = extractvalue { i64, double } %1, 1
  %2 = insertvalue { i64, double } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, double } %2, double %_0.1, 1
  ret { i64, double } %3
}

; <core::array::iter::IntoIter<f32, 5> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, float } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterfKj5_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !484 {
start:
; call <core::array::iter::IntoIter<f32, 5>>::unsize_mut
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5array4iterINtB2_8IntoIterfKj5_E10unsize_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call <core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>]>>::next
  %1 = call { i32, float } @_RNvMs8_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerINtB5_15PolymorphicIterSINtNtNtBb_3mem12maybe_uninit11MaybeUninitfEE4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %_2.0, i64 %_2.1) #23
  %_0.0 = extractvalue { i32, float } %1, 0
  %_0.1 = extractvalue { i32, float } %1, 1
  %2 = insertvalue { i32, float } poison, i32 %_0.0, 0
  %3 = insertvalue { i32, float } %2, float %_0.1, 1
  ret { i32, float } %3
}

; <core::ops::range::RangeTo<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range7RangeTojEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !485 {
start:
; call <core::ops::range::Range<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
  %1 = call { ptr, i64 } @_RNvXs2_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range5RangejEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 0, i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) #23
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ops::index_range::IndexRange as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB5_10IndexRangeNtNtB9_5clone5Clone5cloneCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !486 {
start:
  %_2 = load i64, ptr %self, align 8
  %_5 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %_5, align 8
  %0 = insertvalue { i64, i64 } poison, i64 %_2, 0
  %1 = insertvalue { i64, i64 } %0, i64 %_4, 1
  ret { i64, i64 } %1
}

; <core::array::iter::IntoIter<f64, 10> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterdKja_ENtNtNtB9_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !487 {
start:
; call core::mem::needs_drop::<f64>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropdECs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f64>; 10]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitdEja_EE4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  br label %bb3
}

; <core::array::iter::IntoIter<f32, 5> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs5_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterfKj5_ENtNtNtB9_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !488 {
start:
; call core::mem::needs_drop::<f32>
  %_2 = call zeroext i1 @_RINvNtCsl10jNU3mE6R_4core3mem10needs_dropfECs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call <core::mem::manually_drop::ManuallyDrop<core::array::iter::iter_inner::PolymorphicIter<[core::mem::maybe_uninit::MaybeUninit<f32>; 5]>>>::drop
  call void @_RNvMs_NtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB4_12ManuallyDropINtNtNtNtB8_5array4iter10iter_inner15PolymorphicIterAINtNtB6_12maybe_uninit11MaybeUninitfEj5_EE4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  br label %bb3
}

; <core::ops::range::RangeFrom<usize> as core::slice::index::SliceIndex<[i32]>>::index_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs5_NtNtCsl10jNU3mE6R_4core5slice5indexINtNtNtB9_3ops5range9RangeFromjEINtB5_10SliceIndexSlE9index_mutCs1VtPVuSYnoF_10intrinsics(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !489 {
start:
  %_3 = icmp ugt i64 %self, %slice.1
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %new_len = sub nuw i64 %slice.1, %self
  %ptr.i = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.i, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %new_len, 1
  %_17.0 = extractvalue { ptr, i64 } %2, 0
  %_17.1 = extractvalue { ptr, i64 } %2, 1
  %3 = insertvalue { ptr, i64 } poison, ptr %_17.0, 0
  %4 = insertvalue { ptr, i64 } %3, i64 %_17.1, 1
  ret { ptr, i64 } %4

bb1:                                              ; preds = %start
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64 %self, i64 %slice.1, i64 %slice.1, ptr align 8 %0) #27
  unreachable
}

; <core::slice::sort::shared::smallsort::CopyOnDrop<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs5_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsortINtB5_10CopyOnDroplENtNtNtBd_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !490 {
start:
  %_3 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_5 = load i64, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_3, ptr %_4, i64 4, i64 4, i64 %_5, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %_5, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_4, ptr align 4 %_3, i64 %2, i1 false)
  ret void
}

; <alloc::vec::Vec<i32> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !491 {
start:
; call <alloc::vec::Vec<i32>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE8as_sliceCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<[i32]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSlENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !492 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[i32]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSlE6as_ptrCs1VtPVuSYnoF_10intrinsics(ptr %ptr.0, i64 %ptr.1) #23
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[i32]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSlECs1VtPVuSYnoF_10intrinsics(ptr %_5.0, i64 %_5.1) #23
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCs1VtPVuSYnoF_10intrinsics(ptr align 8 %layout) #23
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[i32]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSlE4casthECs1VtPVuSYnoF_10intrinsics(ptr %ptr.0, i64 %ptr.1) #23
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #23
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCs1VtPVuSYnoF_10intrinsics(ptr %_10, ptr %_11, i64 %6, i64 %8) #23
  br label %bb7
}

; <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::with_capacity
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE13with_capacityCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #1 !guid !493 {
start:
; call <alloc::vec::Vec<i32>>::with_capacity
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VeclE13with_capacityCs1VtPVuSYnoF_10intrinsics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) #23
  ret void
}

; <alloc::vec::Vec<i32> as core::slice::sort::stable::BufGuard<i32>>::as_uninit_slice_mut
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc5sliceINtNtB7_3vec3VeclEINtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable8BufGuardlE19as_uninit_slice_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !494 {
start:
; call <alloc::vec::Vec<i32>>::spare_capacity_mut
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE18spare_capacity_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<i32> as core::ops::deref::DerefMut>::deref_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs9_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref8DerefMut9deref_mutCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #0 !guid !495 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE12as_mut_sliceCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::option::Option<u128> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionoENtNtB7_3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !496 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i128, ptr %self, align 16
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %2 = load i128, ptr %1, align 16
  %_3 = trunc i128 %0 to i64
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 16
  store ptr %4, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.2)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCs1VtPVuSYnoF_10intrinsics() unnamed_addr #0 !guid !497 {
start:
  ret i8 0
}

; <u128 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsY_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 16 %self, ptr align 8 %f) unnamed_addr #0 !guid !498 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u128 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u128 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u128 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::ops::index_range::IndexRange as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs_NtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB4_10IndexRangeNtNtNtNtB8_4iter6traits8iterator8Iterator4nextCs1VtPVuSYnoF_10intrinsics(ptr align 8 %0) unnamed_addr #0 !guid !499 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
; call <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
  %_3 = call i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8 %self)
  %_2 = icmp ugt i64 %_3, 0
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  %1 = load ptr, ptr %self, align 8
; call <core::ops::index_range::IndexRange>::next_unchecked
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ops11index_rangeNtB2_10IndexRange14next_uncheckedCs1VtPVuSYnoF_10intrinsics(ptr align 8 %1) #23
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %2, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %3 = load i64, ptr %_0, align 8
  %4 = getelementptr inbounds i8, ptr %_0, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { i64, i64 } poison, i64 %3, 0
  %7 = insertvalue { i64, i64 } %6, i64 %5, 1
  ret { i64, i64 } %7
}

; <[core::mem::maybe_uninit::MaybeUninit<f64>; 10] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitdEja_NtB4_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !500 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f64>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitdENtB2_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, i64 10, i64 %alive.0, i64 %alive.1)
  ret void
}

; <[core::mem::maybe_uninit::MaybeUninit<f32>; 5] as core::array::iter::iter_inner::PartialDrop>::partial_drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerAINtNtNtBa_3mem12maybe_uninit11MaybeUninitfEj5_NtB4_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self, i64 %alive.0, i64 %alive.1) unnamed_addr #1 !guid !501 {
start:
; call <[core::mem::maybe_uninit::MaybeUninit<f32>] as core::array::iter::iter_inner::PartialDrop>::partial_drop
  call void @_RNvXNtNtNtCsl10jNU3mE6R_4core5array4iter10iter_innerSINtNtNtB8_3mem12maybe_uninit11MaybeUninitfENtB2_11PartialDrop12partial_dropCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self, i64 5, i64 %alive.0, i64 %alive.1)
  ret void
}

; <core::slice::sort::stable::merge::MergeState<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs_NtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5mergeINtB4_10MergeStatelENtNtNtBc_3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !502 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
  %_5 = load ptr, ptr %self, align 8
; call <*mut i32>::offset_from_unsigned
  %len = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl20offset_from_unsignedCs1VtPVuSYnoF_10intrinsics(ptr %_3, ptr %_5, ptr align 8 @alloc_4a07d64a21980758f07ef2afc3d73d2d) #23
  %_8 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %_9 = load ptr, ptr %1, align 8
; call core::ub_checks::check_language_ub
  %_4.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCs1VtPVuSYnoF_10intrinsics() #23
  br i1 %_4.i, label %bb2.i, label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

bb2.i:                                            ; preds = %start
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCs1VtPVuSYnoF_10intrinsics(ptr %_8, ptr %_9, i64 4, i64 4, i64 %len, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #24
  br label %_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit

_RINvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlappinglECs1VtPVuSYnoF_10intrinsics.exit: ; preds = %start, %bb2.i
  %2 = mul nuw nsw i64 %len, 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %_9, ptr align 4 %_8, i64 %2, i1 false)
  ret void
}

; <alloc::vec::Vec<i32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) unnamed_addr #1 !guid !503 {
start:
; call <alloc::vec::Vec<i32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VeclE10as_mut_ptrCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut i32>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOl10cast_sliceCs1VtPVuSYnoF_10intrinsics(ptr %_3, i64 %_4) #23
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<i32> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !504 {
start:
; call <alloc::vec::Vec<i32> as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VeclENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCs1VtPVuSYnoF_10intrinsics(ptr align 8 %self) #23
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <[i32] as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <[i32] as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCsl10jNU3mE6R_4core3fmtSlNtB5_5Debug3fmtCs1VtPVuSYnoF_10intrinsics(ptr align 4 %self.0, i64 %self.1, ptr align 8 %f) unnamed_addr #1 !guid !505 {
start:
  %_5 = alloca [16 x i8], align 8
; call <core::fmt::Formatter>::debug_list
  call void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8 %_5, ptr align 8 %f)
; call <[i32]>::iter
  %0 = call { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4 %self.0, i64 %self.1) #23
  %_6.0 = extractvalue { ptr, ptr } %0, 0
  %_6.1 = extractvalue { ptr, ptr } %0, 1
; call <core::fmt::builders::DebugList>::entries::<&i32, core::slice::iter::Iter<i32>>
  %_3 = call align 8 ptr @_RINvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB6_9DebugList7entriesRlINtNtNtBa_5slice4iter4IterlEECs1VtPVuSYnoF_10intrinsics(ptr align 8 %_5, ptr %_6.0, ptr %_6.1)
; call <core::fmt::builders::DebugList>::finish
  %_0 = call zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8 %_3)
  ret i1 %_0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs1VtPVuSYnoF_10intrinsics(ptr %_1) unnamed_addr #0 !guid !506 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCs1VtPVuSYnoF_10intrinsics(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !507 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Cs1VtPVuSYnoF_10intrinsics(ptr align 8 %_1) #23
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<i32 as core::cmp::PartialOrd>::lt as core::ops::function::FnMut<(&i32, &i32)>>::call_mut
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvYNvYlNtNtCsl10jNU3mE6R_4core3cmp10PartialOrd2ltINtNtNtBa_3ops8function5FnMutTRlB1g_EE8call_mutCs1VtPVuSYnoF_10intrinsics(ptr %_1, ptr align 4 %0, ptr align 4 %1) unnamed_addr #0 !guid !508 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %2 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %1, ptr %2, align 8
  %3 = load ptr, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  %5 = load ptr, ptr %4, align 8
  %_3.i = load i32, ptr %3, align 4
  %_4.i = load i32, ptr %5, align 4
  %_0.i = icmp slt i32 %_3.i, %_4.i
  ret i1 %_0.i
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #2

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; <i8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impaNtB8_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <f64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs7_NtNtCsl10jNU3mE6R_4core3fmt5floatdNtB7_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <f32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs3_NtNtCsl10jNU3mE6R_4core3fmt5floatfNtB7_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs_NtNtCsl10jNU3mE6R_4core3fmt3numnNtB6_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <core::ptr::non_null::NonNull<u128>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulloE8from_refB9_(ptr align 16) unnamed_addr #0

; <core::ptr::non_null::NonNull<u128>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulloE4castuEBa_(ptr) unnamed_addr #0

; <u128 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtCsl10jNU3mE6R_4core3fmt3numoNtB4_7Display3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <i16 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs4_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impsNtB9_7Display3fmt(ptr align 2, ptr align 8) unnamed_addr #1

; <i64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impxNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <core::slice::iter::Iter<i32> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare align 4 ptr @_RNvXs2J_NtNtCsl10jNU3mE6R_4core5slice4iterINtB6_4IterlENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #0

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::builders::DebugList>::entry
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList5entry(ptr align 8, ptr, ptr align 8) unnamed_addr #1

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshr.i32(i32, i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshr.i128(i128, i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshr.i16(i16, i16, i16) #9

; core::ptr::metadata::from_raw_parts_mut::<i32, ()>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutluECsddYV2PBJW9h_3std(ptr) unnamed_addr #0

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #8

; core::cmp::min::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3minjEB4_(i64, i64) unnamed_addr #0

; core::cmp::max::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core3cmp3maxjEB4_(i64, i64) unnamed_addr #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #10

; <core::ops::range::Range<usize> as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits7collectINtNtNtB8_3ops5range5RangejENtB2_12IntoIterator9into_iterB8_(i64, i64) unnamed_addr #0

; <core::ops::range::Range<usize> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs4_NtNtCsl10jNU3mE6R_4core4iter5rangeINtNtNtB9_3ops5range5RangejENtNtNtB7_6traits8iterator8Iterator4nextB9_(ptr align 8) unnamed_addr #0

; core::slice::sort::shared::smallsort::panic_on_ord_violation
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6shared9smallsort22panic_on_ord_violation() unnamed_addr #8

; <[usize; 2] as core::iter::traits::collect::IntoIterator>::into_iter
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvXs0_NtNtCsl10jNU3mE6R_4core5array4iterAjj2_NtNtNtNtB9_4iter6traits7collect12IntoIterator9into_iterCshGsV4pNJ6ra_6object(ptr sret([32 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::array::iter::IntoIter<usize, 2> as core::iter::traits::iterator::Iterator>::next
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, i64 } @_RNvXs3_NtNtCsl10jNU3mE6R_4core5array4iterINtB5_8IntoIterjKj2_ENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #0

; core::ptr::drop_glue::<core::array::iter::IntoIter<usize, 2>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtNtB4_5array4iter8IntoIterjKj2_EECshGsV4pNJ6ra_6object(ptr align 8) unnamed_addr #1

; core::slice::sort::stable::drift::sqrt_approx
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtNtNtNtCsl10jNU3mE6R_4core5slice4sort6stable5drift11sqrt_approx(i64) unnamed_addr #1

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #11

; <core::num::nonzero::NonZero<usize>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3newB9_(i64) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayyEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #9

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #8

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<7, 2>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj7_Kj2_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexyECs2d0hS33vDhg_5gimli(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u16>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hextEB7_(ptr sret([16 x i8]) align 8, ptr align 2) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u128>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexoEB7_(ptr sret([16 x i8]) align 8, ptr align 16) unnamed_addr #0

; <core::fmt::rt::Argument>::new_lower_hex::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument13new_lower_hexmEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #6

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #6

; <core::fmt::Arguments>::new::<4, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj4_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::rt::Argument>::new_display::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaymEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; core::panicking::panic_const::panic_const_div_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_div_overflow(ptr align 8) unnamed_addr #8

; core::panicking::panic_const::panic_const_rem_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_rem_overflow(ptr align 8) unnamed_addr #8

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f32(float) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fptosi.sat.i16.f32(float) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptoui.sat.i32.f32(float) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptosi.sat.i64.f32(float) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptoui.sat.i8.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fptosi.sat.i8.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fptosi.sat.i32.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fptoui.sat.i64.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptosi.sat.i128.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fptoui.sat.i128.f64(double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximumnum.f32(float, float) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.minimumnum.f64(double, double) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.sadd.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ssub.sat.i8(i8, i8) #9

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #8

; <core::mem::maybe_dangling::MaybeDangling<i32>>::new
; Function Attrs: nonlazybind uwtable
declare i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32) unnamed_addr #1

; core::panicking::panic
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking5panic(ptr, i64, ptr align 8) unnamed_addr #8

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #12

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityB7_(ptr align 8, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.sadd.sat.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ssub.sat.i64(i64, i64) #9

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
declare i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getB9_(i64) unnamed_addr #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.sadd.sat.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.smul.with.overflow.i128(i128, i128) #9

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inB7_(i64, i64, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.bitreverse.i8(i8) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctlz.i8(i8, i1 immarg) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.uadd.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.usub.sat.i8(i8, i8) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bitreverse.i16(i16) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.cttz.i16(i16, i1 immarg) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #13

; core::intrinsics::rotate_left::<u64>
; Function Attrs: nounwind nonlazybind uwtable
declare i64 @_RINvNtCsl10jNU3mE6R_4core10intrinsics11rotate_leftyEB4_(i64, i32) unnamed_addr #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bitreverse.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.usub.sat.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bswap.i128(i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.bitreverse.i128(i128) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.usub.sat.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i128, i1 } @llvm.umul.with.overflow.i128(i128, i128) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #9

; core::num::imp::int_log10::panic_for_nonpositive_argument
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtNtNtCsl10jNU3mE6R_4core3num3imp9int_log1030panic_for_nonpositive_argument(ptr align 8) unnamed_addr #14

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #2

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #15

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #16

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #17

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #18

; core::ptr::swap_nonoverlapping_bytes::swap_nonoverlapping_chunks::<8>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNvNtCsl10jNU3mE6R_4core3ptr25swap_nonoverlapping_bytes26swap_nonoverlapping_chunksKj8_ECshGsV4pNJ6ra_6object(ptr, ptr, i64) unnamed_addr #1

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullB6_(ptr) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.powi.f32.i32(float, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.powi.f64.i32(double, i32) #9

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #19

; <*const _>::offset_from_unsigned::runtime_ptr_ge
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp20offset_from_unsigned14runtime_ptr_ge(ptr, ptr) unnamed_addr #1

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; core::ptr::swap_chunk::<4>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj4_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; core::ptr::swap_chunk::<2>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj2_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; core::ptr::swap_chunk::<1>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr10swap_chunkKj1_ECshGsV4pNJ6ra_6object(ptr, ptr) unnamed_addr #0

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toB6_(ptr, i64) unnamed_addr #0

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #19

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.ucmp.i8.i32(i32, i32) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.ucmp.i8.i64(i64, i64) #9

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare range(i8 -1, 2) i8 @llvm.scmp.i8.i64(i64, i64) #9

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core5slice5index16slice_index_fail(i64, i64, i64, ptr align 8) unnamed_addr #8

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <u128 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsM_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8UpperHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <u128 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsK_NtNtCsl10jNU3mE6R_4core3fmt3numoNtB7_8LowerHex3fmt(ptr align 16, ptr align 8) unnamed_addr #1

; <&mut core::ops::index_range::IndexRange as core::iter::traits::exact_size::ExactSizeIterator>::len
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvXNtNtNtCsl10jNU3mE6R_4core4iter6traits10exact_sizeQNtNtNtB8_3ops11index_range10IndexRangeNtB2_17ExactSizeIterator3lenB8_(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_list
; Function Attrs: nonlazybind uwtable
declare void @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter10debug_list(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #1

; <[i32]>::iter
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core5sliceSl4iterCsddYV2PBJW9h_3std(ptr align 4, i64) unnamed_addr #0

; <core::fmt::builders::DebugList>::finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMs6_NtNtCsl10jNU3mE6R_4core3fmt8buildersNtB5_9DebugList6finish(ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #20 !guid !509 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECs1VtPVuSYnoF_10intrinsics(ptr @_RNvCs1VtPVuSYnoF_10intrinsics4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #11 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #13 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #14 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { nonlazybind "target-cpu"="x86-64" }
attributes #21 = { cold }
attributes #22 = { cold noreturn nounwind }
attributes #23 = { inlinehint }
attributes #24 = { inlinehint nounwind }
attributes #25 = { noinline }
attributes #26 = { noreturn }
attributes #27 = { noinline noreturn }
attributes #28 = { nounwind }
attributes #29 = { noinline noreturn nounwind }

!llvm.module.flags = !{!191, !192, !193, !194}
!llvm.ident = !{!195}

!0 = !{i64 5012009826999754764}
!1 = !{i64 859931767084508942}
!2 = !{i64 -1493298376364532576}
!3 = !{i64 7977971464320610758}
!4 = !{i64 -558658983099320227}
!5 = !{i64 -4558332988889097920}
!6 = !{i64 -2342624737986402107}
!7 = !{i64 -846529502477233803}
!8 = !{i64 -1662441078099063405}
!9 = !{i64 -7514931899525342179}
!10 = !{i64 -9107731042933738806}
!11 = !{i64 7770000143703394327}
!12 = !{i64 3227408200207844823}
!13 = !{i64 3920913176760694219}
!14 = !{i64 1731163695030823118}
!15 = !{i64 -6313606514940900119}
!16 = !{i64 1627116699959665906}
!17 = !{i64 2254965233131522854}
!18 = !{i64 -957404972220627957}
!19 = !{i64 -8489754138700453995}
!20 = !{i64 820808751580086804}
!21 = !{i64 5246520789196130455}
!22 = !{i64 -8203131933765999794}
!23 = !{i64 -3228945894592286598}
!24 = !{i64 8829866764502838292}
!25 = !{i64 -6218429175517256050}
!26 = !{i64 7747386920500713491}
!27 = !{i64 5269785954908669621}
!28 = !{i64 3172143636628678298}
!29 = !{i64 -2990079216619765531}
!30 = !{i64 -6301696961026790470}
!31 = !{i64 2455106305516310946}
!32 = !{i64 7636101292588195884}
!33 = !{i64 4894737188061631008}
!34 = !{i64 -5361101849471920004}
!35 = !{i64 9095994143553950680}
!36 = !{i64 255481120335003476}
!37 = !{i64 -8342150686870266016}
!38 = !{i64 6960259972573412833}
!39 = !{i64 -2664314086999544644}
!40 = !{i64 2836763285533005075}
!41 = !{i64 6420558049522527229}
!42 = !{i64 -4385050309468905900}
!43 = !{i64 8944610176455066578}
!44 = !{i64 -7311862010936797359}
!45 = !{i64 5786872961599815775}
!46 = !{i64 -2421404647175109445}
!47 = !{i64 8096382786028492422}
!48 = !{i64 1311710456971064234}
!49 = !{i64 6324413686670515937}
!50 = !{i64 -8932498165430416840}
!51 = !{i64 -6458075513063479806}
!52 = !{i64 255043712993954242}
!53 = !{i64 8633122901425672484}
!54 = !{i64 2215910307408682287}
!55 = !{i64 -1861562670225174782}
!56 = !{i64 1774768811942512737}
!57 = !{i64 8072693672349622200}
!58 = !{i64 -3057583153728657487}
!59 = !{i64 -3249266294239469050}
!60 = !{i64 -6323583076327240216}
!61 = !{i64 -6723518822097334138}
!62 = !{i64 -1316806990741536492}
!63 = !{i64 5518829944733687161}
!64 = !{i64 2528993791865816127}
!65 = !{i64 8936967561890998494}
!66 = !{i64 8809858523098588476}
!67 = !{i64 2669247293983739617}
!68 = !{i64 2065553673427083905}
!69 = !{i64 -3251317050933252660}
!70 = !{i64 6614769068827472919}
!71 = !{i64 -3199886664500295409}
!72 = !{i64 -8378102819311433097}
!73 = !{i64 -2324141329769942771}
!74 = !{i64 -1127030707558583514}
!75 = !{i64 9219552007566209272}
!76 = !{i64 1094403739830055365}
!77 = !{i64 5455773204780505865}
!78 = !{i64 6481606209120281691}
!79 = !{i64 838864447638184161}
!80 = !{i64 1555837465568432490}
!81 = !{i64 -3997600965550494850}
!82 = !{i64 -8844054800050483494}
!83 = !{i64 -9086588370956439395}
!84 = !{i64 -7167575496315378513}
!85 = !{i64 -2836831063483532676}
!86 = !{i64 9129689984770205813}
!87 = !{i64 5039416695937296969}
!88 = !{i64 5664265460829984083}
!89 = !{i64 -3920652517187676440}
!90 = !{i64 -1634345256061548825}
!91 = !{i64 8772734413032583553}
!92 = !{i64 -1076546646720334917}
!93 = !{i64 -8498009882267882835}
!94 = !{i64 6584033496080340135}
!95 = !{i64 -5910670816601358185}
!96 = !{i64 6186233393152015905}
!97 = !{i64 -6603755824540049852}
!98 = !{i64 -6966210236880368140}
!99 = !{i64 1316740898801939269}
!100 = !{i64 -1416684049165969743}
!101 = !{i64 -6336409711279911425}
!102 = !{i64 -1666173519776368529}
!103 = !{i64 1676174066934773688}
!104 = !{i64 -5001155834458976781}
!105 = !{i64 6435189127620935553}
!106 = !{i64 2424941686481107159}
!107 = !{i64 1391307642236365117}
!108 = !{i64 -7747551185770447997}
!109 = !{i64 -8049434056363087120}
!110 = !{i64 2350945452228579760}
!111 = !{i64 2251102052032019623}
!112 = !{i64 -6981754514617602819}
!113 = !{i64 6393103840121972526}
!114 = !{i64 6116109133072420365}
!115 = !{i64 -9140111806213034617}
!116 = !{i64 8066691038648424675}
!117 = !{i64 7415563400739925846}
!118 = !{i64 6509446697909093698}
!119 = !{i64 -5923609321155386839}
!120 = !{i64 3496554622996856580}
!121 = !{i64 278549251482249020}
!122 = !{i64 7251518982385136405}
!123 = !{i64 -4202968232600896536}
!124 = !{i64 -5023653909276942613}
!125 = !{i64 8109974407722673825}
!126 = !{i64 -3613456328448895934}
!127 = !{i64 1826068447412549943}
!128 = !{i64 -1816933101835137103}
!129 = !{i64 2944974678289463283}
!130 = !{i64 -2108463937509228155}
!131 = !{i64 2644425006731365167}
!132 = !{i64 -1926208629995607706}
!133 = !{i64 -3356670834838661877}
!134 = !{i64 -8515461399668346392}
!135 = !{i64 4790073540972632304}
!136 = !{i64 -2936632318221977887}
!137 = !{i64 2985871059242957489}
!138 = !{i64 293451691395416121}
!139 = !{i64 7027221470690262187}
!140 = !{i64 -8922548592248831784}
!141 = !{i64 -544809582528124497}
!142 = !{i64 -1181270652497392464}
!143 = !{i64 -3939498218700180716}
!144 = !{i64 -3885838299040574649}
!145 = !{i64 -7259401896597824851}
!146 = !{i64 -5591808197666155062}
!147 = !{i64 -3620968857960013105}
!148 = !{i64 5619208144822997390}
!149 = !{i64 -5185475759671889437}
!150 = !{i64 -5640304748386331833}
!151 = !{i64 7460633174897113846}
!152 = !{i64 -3856933252642800400}
!153 = !{i64 -4355841678084914084}
!154 = !{i64 1468843266197407265}
!155 = !{i64 -4549645854015720638}
!156 = !{i64 -8455179464546714297}
!157 = !{i64 1783478615072336958}
!158 = !{i64 -7524149584410960035}
!159 = !{i64 4427155208708554357}
!160 = !{i64 5739225673397796947}
!161 = !{i64 -6894235802882735597}
!162 = !{i64 -5264386122318587835}
!163 = !{i64 -6896068070615383455}
!164 = !{i64 808904218014161335}
!165 = !{i64 -162805009132398016}
!166 = !{i64 1415628443334511868}
!167 = !{i64 5075963305070329091}
!168 = !{i64 3987341476848857358}
!169 = !{i64 1230319404472115182}
!170 = !{i64 4710025728869275738}
!171 = !{i64 -2532702223148228200}
!172 = !{i64 -4394540123254906515}
!173 = !{i64 -6289913326813426685}
!174 = !{i64 3356468467315999840}
!175 = !{i64 -7157953304763032298}
!176 = !{i64 -5069486045650391912}
!177 = !{i64 -3788207361947093230}
!178 = !{i64 -3225776007466991302}
!179 = !{i64 161482085639622383}
!180 = !{i64 4807461332735074665}
!181 = !{i64 5521714044994081832}
!182 = !{i64 6917851419444908919}
!183 = !{i64 4886089725356571552}
!184 = !{i64 4007017047238911115}
!185 = !{i64 5530303173414705768}
!186 = !{i64 -5013032940440748410}
!187 = !{i64 3044376946262651527}
!188 = !{i64 -113403392822258305}
!189 = !{i64 4638474125972007181}
!190 = !{i64 -8710017253982268223}
!191 = !{i32 8, !"PIC Level", i32 2}
!192 = !{i32 7, !"PIE Level", i32 2}
!193 = !{i32 2, !"RtLibUseGOT", i32 1}
!194 = !{i32 7, !"uwtable", i32 2}
!195 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!196 = !{i64 -1570031906573291671}
!197 = !{i64 -7137418803948217433}
!198 = !{i64 150520389911133327}
!199 = !{i64 -548429824181197235}
!200 = !{i64 8978920911402943846}
!201 = !{i64 4801508007305839619}
!202 = !{i64 2543220794919325449}
!203 = !{i64 -6513382411548892260}
!204 = !{i64 -1840088386842938099}
!205 = !{i64 1733306387946096680}
!206 = !{i64 -5606370883408946798}
!207 = !{i64 7640367412521984987}
!208 = !{i64 9045182968014938928}
!209 = !{i64 8251636824897719359}
!210 = !{i64 -2506404807361057306}
!211 = !{i64 4890024459223337287}
!212 = !{i64 3431297684657718142}
!213 = !{i64 -3248508455943946476}
!214 = !{i64 -2925290717176122481}
!215 = !{i64 5770050166730189191}
!216 = !{i64 -7616613011666501298}
!217 = !{i64 6661769055013933012}
!218 = !{i64 -8636687766140146680}
!219 = !{i64 6375668271011245981}
!220 = !{i64 -2566011965284469848}
!221 = !{i64 -1682376172326332725}
!222 = !{i64 4198658464906832355}
!223 = !{i64 3970454294106490489}
!224 = !{i64 5543620976986215832}
!225 = !{i64 4729413033291095011}
!226 = !{i64 1120589196710826191}
!227 = !{i64 4308850147935718996}
!228 = !{i64 3484996021038112078}
!229 = !{i64 -2430519219213179416}
!230 = !{i64 2715661591021467245}
!231 = !{i64 -8571143369964205621}
!232 = !{i64 -5422308215046963520}
!233 = !{i64 -3379055876309323090}
!234 = !{i64 2837557592976205748}
!235 = !{i64 -8040774479335211355}
!236 = !{i64 2721438439813342709}
!237 = !{i64 1172875117895140625}
!238 = !{i64 -240359161182285970}
!239 = !{i64 8444306163917056399}
!240 = !{i64 1397426295504335823}
!241 = !{i64 -1063997034892750929}
!242 = !{i64 3713207951400655090}
!243 = !{!"address", !"read_provenance"}
!244 = !{i64 -8412077637648994996}
!245 = !{i64 1713502145143602669}
!246 = !{i64 1803445987707231123}
!247 = !{i64 6564843102094570542}
!248 = !{i64 -8353321237852635082}
!249 = !{i64 4441096489478380728}
!250 = !{i64 4650837836973781143}
!251 = !{i64 3985236823715557774}
!252 = !{i64 1290522935157851040}
!253 = !{i64 8995598244278203798}
!254 = !{i64 -2202258155926112373}
!255 = !{i64 1118819575329138797}
!256 = !{i64 -2335139109467150508}
!257 = !{i64 -5792976956413633102}
!258 = !{i64 -7611803597273067312}
!259 = !{i64 -1764508262961807130}
!260 = !{i64 -1964163953718405048}
!261 = !{i64 -8053998874152235829}
!262 = !{i64 3691249532704810586}
!263 = !{i64 6933726545100921185}
!264 = !{i64 5519320009352599838}
!265 = !{i64 6345653482014013777}
!266 = !{i64 -9158958890012611407}
!267 = !{i64 -1673582558680877803}
!268 = !{i64 8883132109628606407}
!269 = !{i64 4747718874908629067}
!270 = !{i64 6922829745707279789}
!271 = !{i64 -2736648386056802278}
!272 = !{i64 1924051537976976105}
!273 = !{i64 -8189538882979429527}
!274 = !{i64 -1633245617836690044}
!275 = !{i64 9214715438966127202}
!276 = !{i64 822473619815619502}
!277 = !{i64 -6091644224634048968}
!278 = !{i64 1323129100350270}
!279 = !{i64 -4493370618905944311}
!280 = !{i64 1445637646399524976}
!281 = !{i64 5811213525221117083}
!282 = !{i64 4951787171383673532}
!283 = !{i64 3529269604517622033}
!284 = !{i64 1448722208353177035}
!285 = !{i64 -2136096331831290087}
!286 = !{i64 -3059880594652403689}
!287 = !{i64 6493238536462595403}
!288 = !{i64 8029855726709480346}
!289 = !{i64 2838388761246185286}
!290 = !{i64 6799713349986581494}
!291 = !{i64 419884933966253370}
!292 = !{i64 6157146327448299061}
!293 = !{i64 5784957859185936598}
!294 = !{i64 3129265321664552887}
!295 = !{i64 -2986169483620609081}
!296 = !{i64 1369314008014469836}
!297 = !{i64 -1266184905783853378}
!298 = !{i64 3467533106288140291}
!299 = !{i64 -5770121695530803036}
!300 = !{i64 -2674764737256309613}
!301 = !{i64 -8236145633449047770}
!302 = !{i64 -973872404273653936}
!303 = !{i64 7238558936677286888}
!304 = !{}
!305 = !{i64 -7023091248692888120}
!306 = !{i64 -2531283859637514864}
!307 = !{i64 6091191395495918188}
!308 = !{i64 -179875847021105404}
!309 = !{i64 1455098328924371536}
!310 = !{i64 772212209544494760}
!311 = !{i64 -8930296895304792756}
!312 = !{i64 -7903599640162921076}
!313 = !{i64 -1133084177828190719}
!314 = !{i64 -4555838034176562426}
!315 = !{i64 8921720546380135435}
!316 = !{i64 3884796027706948003}
!317 = !{i64 8947300769869511194}
!318 = !{i64 -6685050176304576594}
!319 = !{i64 -1887574188492611858}
!320 = !{i64 1860203667341184862}
!321 = !{i64 6448903842870311300}
!322 = !{i64 4273051541664015817}
!323 = !{i64 -6859501505529021442}
!324 = !{i64 2228071430792233637}
!325 = !{i64 -2210008274260800854}
!326 = !{i64 -1282399083373049224}
!327 = !{i64 4879927262172217345}
!328 = !{i64 7548799086141245241}
!329 = !{i64 -2650343876789346852}
!330 = !{i64 2828143040501454437}
!331 = !{i64 5141516619828539411}
!332 = !{i64 -455467600916474367}
!333 = !{i64 -8918590997959822634}
!334 = !{i64 -4904151862790063822}
!335 = !{i64 -8278154663216398619}
!336 = !{i64 5385671355908161052}
!337 = !{i64 -975867243988703956}
!338 = !{i64 -7603392899240571067}
!339 = !{i64 -7996539765509500974}
!340 = !{i64 3230606492346596201}
!341 = !{i64 5588018687106798020}
!342 = !{i64 -8029792346447214487}
!343 = !{i64 1437243793022808134}
!344 = !{i64 -2289072558708680833}
!345 = !{i64 7770205609726544500}
!346 = !{i64 -3217760126315213205}
!347 = !{i64 -8196974514695491296}
!348 = !{i64 -7655326984159772428}
!349 = !{i64 1949054697762754930}
!350 = !{i64 -7815479023660245991}
!351 = !{i64 -231921796209729020}
!352 = !{i64 -4461196498246316317}
!353 = !{i64 5577633881872387751}
!354 = !{i64 8262640285554516249}
!355 = !{i64 -2949764703124250877}
!356 = !{i64 2340139552636968193}
!357 = !{i64 2943723579203535067}
!358 = !{i64 -5147712460889170159}
!359 = !{i64 -3946793915924787852}
!360 = !{i64 5813951371130568623}
!361 = !{i64 3001384513294557681}
!362 = !{i64 -3544332010434450059}
!363 = !{i64 7193990271482187149}
!364 = !{i64 -4331898326118517965}
!365 = !{i64 -4826827339651949968}
!366 = !{i64 4889590320915811548}
!367 = !{i64 -4814292078583478867}
!368 = !{i64 5979045177376570027}
!369 = !{i64 -7248032210704185986}
!370 = !{i64 -9075744585012846823}
!371 = !{i64 6264175616852112493}
!372 = !{i64 7523828141609960219}
!373 = !{i64 1346783384337962768}
!374 = !{i64 8818699151483781456}
!375 = !{i64 -3436430868913962017}
!376 = !{i64 4660522338715319616}
!377 = !{i64 4726118653950741936}
!378 = !{i64 -4754922798793825178}
!379 = !{i64 -1021001876457136175}
!380 = !{i64 -7401572254237808178}
!381 = !{i64 -7921120856036938096}
!382 = !{i64 -270815425454307178}
!383 = !{i64 -1756745560801949134}
!384 = !{i64 -5525384999616878353}
!385 = !{i64 7567075352123435230}
!386 = !{i64 853465861991013495}
!387 = !{i64 -4949181013668095190}
!388 = !{i64 431533332570289233}
!389 = !{i64 1206712473789052016}
!390 = !{i64 8894790240870817911}
!391 = !{i64 -1987825235881630151}
!392 = !{i64 -4980522154421327105}
!393 = !{i64 7629932565032658270}
!394 = !{i64 -3478759665906138087}
!395 = !{i64 -7764989679103851071}
!396 = !{i64 -230191782218626427}
!397 = !{i64 -8590047831744037908}
!398 = !{i64 -8869746785559782121}
!399 = !{i64 -8846681255766285839}
!400 = !{i64 6887682334349139751}
!401 = !{i64 -8831095150046581125}
!402 = !{i64 -1018011519307529553}
!403 = !{i64 -9009456034626688229}
!404 = !{i64 8418129047172111628}
!405 = !{i64 8648357893758307649}
!406 = !{i64 7588017879833985101}
!407 = !{i64 -5389701333999367419}
!408 = !{i64 -5660501682885218571}
!409 = !{i64 8125795892107370867}
!410 = !{i64 5294183154218646122}
!411 = !{i64 -3514209259557579491}
!412 = !{i64 2942015586919137197}
!413 = !{i64 -2994484789639035453}
!414 = !{i64 3549731234475393895}
!415 = !{i64 -4418098867396644361}
!416 = !{i64 -7993959659669583404}
!417 = !{i64 -7384109547207484095}
!418 = !{i64 6218589345651951541}
!419 = !{i64 2770603294531503104}
!420 = !{i64 7673722869275214201}
!421 = !{i64 -7935922529525049084}
!422 = !{i64 2742740345579728290}
!423 = !{i64 -8678531163172662601}
!424 = !{i64 783152223878285821}
!425 = !{i64 -4890172639401893336}
!426 = !{i64 4048027390332729318}
!427 = !{i64 7126729709894229338}
!428 = !{i64 -4181188586742329733}
!429 = !{i64 2833262569634644939}
!430 = !{i64 -928023099955455404}
!431 = !{i64 126302764950501994}
!432 = !{i64 5631383983347155165}
!433 = !{i64 -7683439194097077307}
!434 = !{i64 994195373952965550}
!435 = !{i64 6534725155875779896}
!436 = !{i64 -4616098150496766607}
!437 = !{i64 -3327380770864514931}
!438 = !{i64 7980638714980638279}
!439 = !{i64 -1899931427992092030}
!440 = !{i64 1722296854801885465}
!441 = !{i64 4311719845930224081}
!442 = !{i64 -3177300122288124228}
!443 = !{i64 3269093224125019262}
!444 = !{i64 -1077928047292508167}
!445 = !{i64 861198878434414239}
!446 = !{i64 8062465523289614334}
!447 = !{i64 3077797532745321381}
!448 = !{i64 6182041727713576017}
!449 = !{i64 -1218058394385163267}
!450 = !{i64 3309435655617196965}
!451 = !{i64 5783735962445009728}
!452 = !{i64 -1089142657202914620}
!453 = !{i64 6004849689332389574}
!454 = !{i64 -7152851824667145343}
!455 = !{i64 -800809040555317199}
!456 = !{i64 7519876477219573273}
!457 = !{i64 1432367447649312791}
!458 = !{i64 -3723883393898942761}
!459 = !{i64 -2139618628215353125}
!460 = !{i64 1541928680566394519}
!461 = !{i64 6535502366125318510}
!462 = !{i64 -4830300452352343087}
!463 = !{i64 7909279710589797290}
!464 = !{i64 375873775389823181}
!465 = !{i64 -4322560870714004368}
!466 = !{i64 -3508001570568619633}
!467 = !{i64 2411127353683190230}
!468 = !{i64 -2844748015748115581}
!469 = !{i64 8396751554899594302}
!470 = !{i64 -3508564593237287620}
!471 = !{i64 6496803476751462345}
!472 = !{i64 2791498010530908803}
!473 = !{i64 592294665945732413}
!474 = !{i64 -136142993301618289}
!475 = !{i64 -2000625919881304703}
!476 = !{i64 -4289663870056818646}
!477 = !{i64 6560242446820738421}
!478 = !{i64 6088693301328888018}
!479 = !{i64 7667434283843692777}
!480 = !{i64 9197266948984612606}
!481 = !{i64 2972521796463933233}
!482 = !{i64 6871146030517691168}
!483 = !{i64 2205388083932477230}
!484 = !{i64 4682088799267301564}
!485 = !{i64 -1309953040574250282}
!486 = !{i64 2134280516140519142}
!487 = !{i64 8489283372398839169}
!488 = !{i64 7211766767742025917}
!489 = !{i64 -289559334297295817}
!490 = !{i64 7732416066418622818}
!491 = !{i64 6997926070084987981}
!492 = !{i64 -7019947327909857637}
!493 = !{i64 -5611893142432097492}
!494 = !{i64 -1139961358325208909}
!495 = !{i64 5481448636660248156}
!496 = !{i64 5670152409363650381}
!497 = !{i64 7181864858485889367}
!498 = !{i64 -5980363803752038216}
!499 = !{i64 -5496670144081979835}
!500 = !{i64 4369875416799435956}
!501 = !{i64 2011278027674901366}
!502 = !{i64 5597547750257422647}
!503 = !{i64 -3075810535824517386}
!504 = !{i64 -9181012866680813211}
!505 = !{i64 3267763556827036243}
!506 = !{i64 7529273670847353283}
!507 = !{i64 -6295463253203442573}
!508 = !{i64 476300499689948165}
!509 = !{i64 -2624081020897602054}
