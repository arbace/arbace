; ModuleID = 'unwind.de6fece333d206cb-cgu.0'
source_filename = "unwind.de6fece333d206cb-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%Noisy = type { { ptr, i64 } }
%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@anon.8a767884830b53d754c778cf6ba696d7.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -8815622259637286671 to ptr), ptr inttoptr (i64 8786967495329273992 to ptr) }>, align 8, !guid !4
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsj61JMRYXuTT_6unwind, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csj61JMRYXuTT_6unwind, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csj61JMRYXuTT_6unwind }>, align 8, !guid !5
@alloc_ab7766fee1e1b94f8c00ce7ffec41c7e = private unnamed_addr constant [1 x i8] c"b", align 1, !guid !6
@alloc_0280725f3eb987d13d947714e41d5ae1 = private unnamed_addr constant [7 x i8] c"inner 7", align 1, !guid !7
@alloc_e3cf71e1def3cd24299f28383abd4ed3 = private unnamed_addr constant [25 x i8] c"test/rust/eval/unwind.rs\00", align 1, !guid !8
@alloc_6d0551713e79347e9595c2ef6cb10d53 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\22\00\00\00C\00\00\00" }>, align 8, !guid !9
@alloc_02b558d5b27198b9b90fbafced75e0cf = private unnamed_addr constant [11 x i8] c"\06hook: \C0\01\0A\00", align 1, !guid !10
@alloc_3827bbb606bbdb0f0c926011c14ccc34 = private unnamed_addr constant [1 x i8] c"a", align 1, !guid !11
@alloc_8aacd928cc9cd06d971ebb753399589c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\1D\00\00\00\12\00\00\00" }>, align 8, !guid !12
@alloc_c985f9648a4752df94836fcbae4dfeb9 = private unnamed_addr constant [18 x i8] c"\0Dinner caught \C0\01\0A\00", align 1, !guid !13
@alloc_18f2f0d3d4f38df552db2352111ec81f = private unnamed_addr constant [1 x i8] c"c", align 1, !guid !14
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @_RNvXNtCsl10jNU3mE6R_4core3anymNtB2_3Any7type_idCsj61JMRYXuTT_6unwind }>, align 8, !guid !15
@alloc_e1e82be9de827f623ba9c6d5bef55b18 = private unnamed_addr constant [13 x i8] c"nothing there", align 1, !guid !16
@alloc_7a883dc29779389d1427c2ddfbcbb9ad = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00(\00\00\00S\00\00\00" }>, align 8, !guid !17
@alloc_79c0faa1113895cec8a77a1ad0fa7359 = private unnamed_addr constant [15 x i8] c"\0Coverflow of \C0\00", align 1, !guid !18
@alloc_fab7d5ddde7e96f6eda9131f29e4478a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00-\00\00\002\00\00\00" }>, align 8, !guid !19
@alloc_125c1a986a46d7dd60e9e2dd8e919f72 = private unnamed_addr constant [3 x i8] c"odd", align 1, !guid !20
@alloc_fbf52d5fed6793d3e790c9ce6627a01c = private unnamed_addr constant [4 x i8] c"even", align 1, !guid !21
@alloc_0970c60599a798604a3541cff42e1e58 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\0E\00\00\00\0A\00\00\00" }>, align 8, !guid !22
@alloc_f7c3db4719e24bc3032931eae45c9dac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\0E\00\00\00\05\00\00\00" }>, align 8, !guid !23
@alloc_753040b032de2b44c70b10e6e33f5434 = private unnamed_addr constant [14 x i8] c"bottom reached", align 1, !guid !24
@alloc_be58da8534b8ede79c3a9683d69e5ca7 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\0D\00\00\00\11\00\00\00" }>, align 8, !guid !25
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCsj61JMRYXuTT_6unwind4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_, ptr @_RNCNvCsj61JMRYXuTT_6unwind4main0B3_, ptr @_RNCNvCsj61JMRYXuTT_6unwind4main0B3_ }>, align 8, !guid !26
@alloc_31a4754d1d7ab2dbef2d2f2030dca95f = private unnamed_addr constant [13 x i8] c"\08caught: \C0\01\0A\00", align 1, !guid !27
@alloc_4708833df625061546a6b3f99554ca2c = private unnamed_addr constant [2 x i8] c"v1", align 1, !guid !28
@alloc_8f96945e3024e6985f2e60d09c120143 = private unnamed_addr constant [2 x i8] c"v2", align 1, !guid !29
@alloc_83c2d8dfe927c8d1ff9bad87f0f15c1c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00\19\00\00\00\0D\00\00\00" }>, align 8, !guid !30
@alloc_c763cf0b07e9674e5b5a834b413ba04f = private unnamed_addr constant [12 x i8] c"\07index: \C0\01\0A\00", align 1, !guid !31
@alloc_7ad1c81a7c2155091a8327f883d7946b = private unnamed_addr constant [14 x i8] c"\09resumed: \C0\01\0A\00", align 1, !guid !32
@alloc_20e1345a6ca51fe6622b10715f7afc58 = private unnamed_addr constant [13 x i8] c"\08expect: \C0\01\0A\00", align 1, !guid !33
@alloc_4047f048e81a836efb536f863c5bda29 = private unnamed_addr constant [4 x i8] c"last", align 1, !guid !34
@alloc_a0768cdb3da30baaab7f5655e171e172 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_e3cf71e1def3cd24299f28383abd4ed3, [16 x i8] c"\18\00\00\00\00\00\00\00-\00\00\00 \00\00\00" }>, align 8, !guid !35
@alloc_1e83afe964be28b7af38cd986c24bed2 = private unnamed_addr constant [17 x i8] c"\0Cunreachable \C0\01\0A\00", align 1, !guid !36
@alloc_04af5354bae90239a24027527d4c463d = private unnamed_addr constant [30 x i8] c"core/src/mem/manually_drop.rs\00", align 1, !guid !37
@alloc_622d398601f4d17fcdc4667dab4c4cb4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\CB\00\00\000\00\00\00" }>, align 8, !guid !38
@alloc_d9607be26b1182115ab3c853f5787a76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\E4\00\00\00\12\00\00\00" }>, align 8, !guid !39
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !40
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !41
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !42
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !43
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !44
@alloc_a4b5e9c02a3b46b6492ce6eaa610346d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\A7\04\00\00\09\00\00\00" }>, align 8, !guid !45
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !46
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !47
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !48
@alloc_88523646262c2465cd77855ffd6da4ff = private unnamed_addr constant [10 x i8] c"\05drop \C0\01\0A\00", align 1, !guid !49
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !50
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !51
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCsj61JMRYXuTT_6unwind }>, align 8, !guid !52

; <[unwind::Noisy]>::into_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsj61JMRYXuTT_6unwind5Noisy8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0, i64 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !58 {
start:
  %2 = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %3, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %_10.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_10.1 = load i64, ptr %4, align 8
  store i8 0, ptr %_9, align 1
  %_7.0 = load ptr, ptr %self, align 8
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_7.1 = load i64, ptr %5, align 8
; invoke <alloc::boxed::Box<[unwind::Noisy]>>::into_raw_with_allocator
  %6 = invoke { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsj61JMRYXuTT_6unwind5NoisyE23into_raw_with_allocatorBK_(ptr align 8 %_7.0, i64 %_7.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_6.0 = extractvalue { ptr, i64 } %6, 0
  %_6.1 = extractvalue { ptr, i64 } %6, 1
; invoke <alloc::vec::Vec<unwind::Noisy>>::from_raw_parts_in
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsj61JMRYXuTT_6unwind5NoisyE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %_6.0, i64 %_10.1, i64 %_10.1)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret void

bb3:                                              ; preds = %bb4, %bb5
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<[unwind::Noisy]>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEEB1d_(ptr align 8 %self) #19
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; <core::option::Option<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::and_then::<alloc::string::String, unwind::main::{closure#6}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE8and_thenNtNtBN_6string6StringNCNvCsj61JMRYXuTT_6unwind4mains4_0EB2t_(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr %1) unnamed_addr #0 !guid !59 {
start:
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %x.1 = load ptr, ptr %9, align 8
  store i8 0, ptr %_7, align 1
; call unwind::main::{closure#6}
  call void @_RNCNvCsj61JMRYXuTT_6unwind4mains4_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %x.0, ptr align 8 %x.1) #21
  br label %bb6

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %10 = load i8, ptr %_7, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::and_then::<u32, unwind::main::{closure#7}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE8and_thenmNCNvCsj61JMRYXuTT_6unwind4mains5_0EB29_(ptr %0, ptr %1) unnamed_addr #0 !guid !60 {
start:
  %_7 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %x.1 = load ptr, ptr %9, align 8
  store i8 0, ptr %_7, align 1
; call unwind::main::{closure#7}
  %10 = call { i32, i32 } @_RNCNvCsj61JMRYXuTT_6unwind4mains5_0B3_(ptr %x.0, ptr align 8 %x.1) #21
  %11 = extractvalue { i32, i32 } %10, 0
  %12 = extractvalue { i32, i32 } %10, 1
  store i32 %11, ptr %_0, align 4
  %13 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %12, ptr %13, align 4
  br label %bb6

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %14 = load i8, ptr %_7, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %16 = load i32, ptr %_0, align 4
  %17 = getelementptr inbounds i8, ptr %_0, i64 4
  %18 = load i32, ptr %17, align 4
  %19 = insertvalue { i32, i32 } poison, i32 %16, 0
  %20 = insertvalue { i32, i32 } %19, i32 %18, 1
  ret { i32, i32 } %20

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<alloc::string::String>>::or_else::<unwind::main::{closure#0}::{closure#1}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE7or_elseNCNCNvCsj61JMRYXuTT_6unwind4main0s_0EB1z_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 personality ptr @rust_eh_personality !guid !61 {
start:
  %0 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %x = alloca [24 x i8], align 8
  store i8 0, ptr %_7, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_7, align 1
  store i8 1, ptr %_6, align 1
  %1 = load i64, ptr %self, align 8
  %2 = icmp eq i64 %1, -1
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  store i8 0, ptr %_7, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb8

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; invoke unwind::main::{closure#0}::{closure#1}
  invoke void @_RNCNCNvCsj61JMRYXuTT_6unwind4main0s_0B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %f)
          to label %bb12 unwind label %cleanup

bb11:                                             ; preds = %cleanup
  %4 = load i8, ptr %_7, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb10, label %bb6

cleanup:                                          ; preds = %bb2
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb11

bb12:                                             ; preds = %bb2
  br label %bb8

bb8:                                              ; preds = %bb3, %bb12
  %10 = load i8, ptr %_6, align 1
  %11 = trunc nuw i8 %10 to i1
  br i1 %11, label %bb7, label %bb4

bb4:                                              ; preds = %bb7, %bb8
  %12 = load i8, ptr %_7, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb9, label %bb5

bb7:                                              ; preds = %bb8
  br label %bb4

bb5:                                              ; preds = %bb9, %bb4
  ret void

bb9:                                              ; preds = %bb4
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %self)
  br label %bb5

bb6:                                              ; preds = %bb10, %bb11
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb10:                                             ; preds = %bb11
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %self) #19
          to label %bb6 unwind label %terminate

terminate:                                        ; preds = %bb10
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !62 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
  call void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&&str>>::map::<alloc::string::String, unwind::main::{closure#0}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCsj61JMRYXuTT_6unwind4main00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !63 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call unwind::main::{closure#0}::{closure#0}
  call void @_RNCNCNvCsj61JMRYXuTT_6unwind4main00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u8>>::unwrap_or_else::<unwind::main::{closure#5}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE14unwrap_or_elseNCNvCsj61JMRYXuTT_6unwind4mains3_0EB14_(i1 zeroext %0, i8 %1, ptr %f, ptr align 8 %2) unnamed_addr #0 !guid !64 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [1 x i8], align 1
  %self = alloca [2 x i8], align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %self, align 1
  %4 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %4, align 1
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %5 = load i8, ptr %self, align 1
  %6 = trunc nuw i8 %5 to i1
  %7 = getelementptr inbounds i8, ptr %self, i64 1
  %8 = load i8, ptr %7, align 1
  %_3 = zext i1 %6 to i64
  %9 = trunc nuw i64 %_3 to i1
  br i1 %9, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %10 = getelementptr inbounds i8, ptr %self, i64 1
  %x = load i8, ptr %10, align 1
  store i8 %x, ptr %_0, align 1
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
; call unwind::main::{closure#5}
  %11 = call i8 @_RNCNvCsj61JMRYXuTT_6unwind4mains3_0B3_(ptr %f) #21
  store i8 %11, ptr %_0, align 1
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %12 = load i8, ptr %_6, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %14 = load i8, ptr %_0, align 1
  ret i8 %14

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !65 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsj61JMRYXuTT_6unwind(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsj61JMRYXuTT_6unwind(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsj61JMRYXuTT_6unwind, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !66 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsj61JMRYXuTT_6unwind(ptr %x) #21
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsj61JMRYXuTT_6unwind(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<alloc::string::String>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<alloc::string::String>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEE8from_refCsj61JMRYXuTT_6unwind(ptr align 8 %x) #21
; call <core::ptr::non_null::NonNull<core::option::Option<alloc::string::String>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEE4castuECsj61JMRYXuTT_6unwind(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCsj61JMRYXuTT_6unwind, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::option::Option<u32>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionmEECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::option::Option<u32>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionmEE8from_refCsj61JMRYXuTT_6unwind(ptr align 4 %x) #21
; call <core::ptr::non_null::NonNull<core::option::Option<u32>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionmEE4castuECsj61JMRYXuTT_6unwind(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsj61JMRYXuTT_6unwind(ptr %x) #21
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsj61JMRYXuTT_6unwind(ptr %_4) #21
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsj61JMRYXuTT_6unwind, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<[unwind::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEB18_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !70 {
start:
; call core::mem::align_of_val_raw::<[unwind::Noisy]>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEBM_(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsj61JMRYXuTT_6unwind(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #21
  ret i64 %_0
}

; <core::alloc::layout::Layout>::for_value_raw::<[unwind::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsj61JMRYXuTT_6unwind5NoisyEB17_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !71 {
start:
; call core::mem::size_of_val_raw::<[unwind::Noisy]>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEBL_(ptr %val.0, i64 %val.1) #21
; call <core::mem::alignment::Alignment>::of_val_raw::<[unwind::Noisy]>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEB18_(ptr %val.0, i64 %val.1) #21
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsj61JMRYXuTT_6unwind(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #21
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<[unwind::Noisy]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsj61JMRYXuTT_6unwind5NoisyE4casthEBU_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !72 {
start:
; call <core::ptr::non_null::NonNull<[unwind::Noisy]>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsj61JMRYXuTT_6unwind5NoisyE4casthEBX_(ptr %self.0, i64 %self.1) #21
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsj61JMRYXuTT_6unwind5NoisyEB10_(ptr %self) unnamed_addr #0 !guid !73 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<unwind::Noisy>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsj61JMRYXuTT_6unwind5NoisyEB13_(ptr %self) #21
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::option::Option<alloc::string::String>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEE4castuECsj61JMRYXuTT_6unwind(ptr %self) unnamed_addr #0 !guid !74 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::option::Option<u32>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6option6OptionmEE4castuECsj61JMRYXuTT_6unwind(ptr %self) unnamed_addr #0 !guid !75 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECsj61JMRYXuTT_6unwind(ptr %self) unnamed_addr #0 !guid !76 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[unwind::Noisy]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullSNtCsj61JMRYXuTT_6unwind5NoisyE4casthEBX_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !77 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECsj61JMRYXuTT_6unwind(ptr %self) unnamed_addr #0 !guid !78 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castNtCsj61JMRYXuTT_6unwind5NoisyEB13_(ptr %self) unnamed_addr #0 !guid !79 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsj61JMRYXuTT_6unwind5NoisyEBY_(ptr align 8 %self) unnamed_addr #0 !guid !80 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<unwind::Noisy>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsj61JMRYXuTT_6unwind5NoisyEB13_(ptr align 8 %self) #21
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullNtCsj61JMRYXuTT_6unwind5NoisyEB13_(ptr align 8 %self) unnamed_addr #0 !guid !81 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<unwind::Noisy>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castNtCsj61JMRYXuTT_6unwind5NoisyEB10_(ptr %_3) #21
; call <core::ptr::unique::Unique<unwind::Noisy>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsj61JMRYXuTT_6unwind5NoisyE15as_non_null_ptrBS_(ptr %_2) #21
  ret ptr %_0
}

; <dyn core::any::Any>::downcast_ref::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refmECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !82 {
start:
  %_0 = alloca [8 x i8], align 8
; call <dyn core::any::Any>::is::<u32>
  %_2 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2ismECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) #21
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <dyn core::any::Any>::downcast_unchecked_ref::<u32>
  %_3 = call align 4 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refmECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) #21
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <dyn core::any::Any>::downcast_unchecked_ref::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refmECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !83 {
start:
  ret ptr %self.0
}

; <dyn core::any::Any>::is::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2ismECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !84 {
start:
  %concrete = alloca [16 x i8], align 8
  %t = alloca [16 x i8], align 8
; call <core::any::TypeId>::of::<u32>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofmECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %t)
  %0 = getelementptr inbounds i8, ptr %self.1, i64 24
  %1 = load ptr, ptr %0, align 8, !invariant.load !85, !nonnull !85
  call void %1(ptr sret([16 x i8]) align 8 %concrete, ptr %self.0) #21
; call <core::any::TypeId as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCsj61JMRYXuTT_6unwind(ptr align 8 %t, ptr align 8 %concrete) #21
  ret i1 %_0
}

; <core::fmt::Arguments>::new::<12, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsj61JMRYXuTT_6unwind(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !86 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsj61JMRYXuTT_6unwind(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !87 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECsj61JMRYXuTT_6unwind(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !88 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refmECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !89 {
start:
; call <dyn core::any::Any>::downcast_ref::<u32>
  %_0 = call align 4 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refmECsj61JMRYXuTT_6unwind(ptr %self.0, ptr align 8 %self.1) #21
  ret ptr %_0
}

; <core::any::TypeId>::of::<u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofmECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !90 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.8a767884830b53d754c778cf6ba696d7.0, i64 16, i1 false)
  ret void
}

; alloc::raw_vec::new_cap::<unwind::Noisy>
; Function Attrs: nonlazybind uwtable
define internal i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsj61JMRYXuTT_6unwind5NoisyEBG_(i64 %cap) unnamed_addr #1 !guid !91 {
start:
  %_0 = alloca [8 x i8], align 8
  br label %bb2

bb2:                                              ; preds = %start
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsj61JMRYXuTT_6unwind(i64 %cap) #21
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1

bb1:                                              ; No predecessors!
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsj61JMRYXuTT_6unwind(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !92 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; std::panic::catch_unwind::<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>, ()>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB1L_() unnamed_addr #1 !guid !93 {
start:
; call std::panicking::catch_unwind::<(), core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>
  %0 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EEB1Q_()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::panic::catch_unwind::<unwind::main::{closure#3}::{closure#0}, ()>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEBM_() unnamed_addr #1 !guid !94 {
start:
; call std::panicking::catch_unwind::<(), unwind::main::{closure#3}::{closure#0}>
  %0 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNCNvCsj61JMRYXuTT_6unwind4mains1_00EBR_()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::panic::catch_unwind::<unwind::main::{closure#3}, ()>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBK_() unnamed_addr #1 !guid !95 {
start:
; call std::panicking::catch_unwind::<(), unwind::main::{closure#3}>
  %0 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCsj61JMRYXuTT_6unwind4mains1_0EBP_()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::panic::catch_unwind::<unwind::main::{closure#4}, i32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !96 {
start:
; call std::panicking::catch_unwind::<i32, unwind::main::{closure#4}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCsj61JMRYXuTT_6unwind4mains2_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<unwind::main::{closure#1}, u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains_0mEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !97 {
start:
; call std::panicking::catch_unwind::<u32, unwind::main::{closure#1}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsj61JMRYXuTT_6unwind4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panicking::catch_unwind::<i32, unwind::main::{closure#4}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCsj61JMRYXuTT_6unwind4mains2_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !98 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#4}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains2_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u32, unwind::main::{closure#1}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCsj61JMRYXuTT_6unwind4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !99 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#1}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains_0mEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains_0mEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<(), core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EEB1Q_() unnamed_addr #1 !guid !100 {
start:
  %slot.i1 = alloca [0 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE3newB1T_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB1Z_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB20_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %0 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %0, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %1 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %1, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %2, align 8
  %3 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_0.1.i.i, 1
  %5 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %6, 0
  %_0.1.i = extractvalue { ptr, ptr } %6, 1
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load ptr, ptr %9, align 8
  %11 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %12 = insertvalue { ptr, ptr } %11, ptr %10, 1
  ret { ptr, ptr } %12
}

; std::panicking::catch_unwind::<(), unwind::main::{closure#3}::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNCNvCsj61JMRYXuTT_6unwind4mains1_00EBR_() unnamed_addr #1 !guid !101 {
start:
  %slot.i1 = alloca [0 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}::{closure#0}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E3newB1a_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEB10_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEB11_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %0 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %0, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %1 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %1, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %2, align 8
  %3 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_0.1.i.i, 1
  %5 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %6, 0
  %_0.1.i = extractvalue { ptr, ptr } %6, 1
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load ptr, ptr %9, align 8
  %11 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %12 = insertvalue { ptr, ptr } %11, ptr %10, 1
  ret { ptr, ptr } %12
}

; std::panicking::catch_unwind::<(), unwind::main::{closure#3}>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCsj61JMRYXuTT_6unwind4mains1_0EBP_() unnamed_addr #1 !guid !102 {
start:
  %slot.i1 = alloca [0 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains1_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %0 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %0, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %1 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %1, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %2, align 8
  %3 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_0.1.i.i, 1
  %5 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %6, 0
  %_0.1.i = extractvalue { ptr, ptr } %6, 1
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load ptr, ptr %9, align 8
  %11 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %12 = insertvalue { ptr, ptr } %11, ptr %10, 1
  ret { ptr, ptr } %12
}

; core::mem::size_of_val_raw::<[unwind::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEBL_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !103 {
start:
  %_0 = mul nuw nsw i64 %val.1, 16
  ret i64 %_0
}

; core::mem::align_of_val_raw::<[unwind::Noisy]>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawSNtCsj61JMRYXuTT_6unwind5NoisyEBM_(ptr %val.0, i64 %val.1) unnamed_addr #0 !guid !104 {
start:
  %0 = mul nuw nsw i64 %val.1, 16
  ret i64 8
}

; core::mem::drop::<alloc::vec::Vec<unwind::Noisy>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc3vec3VecNtCsj61JMRYXuTT_6unwind5NoisyEEB15_(ptr align 8 %_x) unnamed_addr #0 !guid !105 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<unwind::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsj61JMRYXuTT_6unwind5NoisyEEB1a_(ptr align 8 %_x)
  ret void
}

; core::ptr::slice_from_raw_parts_mut::<unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsj61JMRYXuTT_6unwind5NoisyEBT_(ptr %data, i64 %len) unnamed_addr #0 !guid !106 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[unwind::Noisy], unwind::Noisy>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsj61JMRYXuTT_6unwind5NoisyBX_EBZ_(ptr %data, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %_1) unnamed_addr #1 !guid !107 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %_1) unnamed_addr #1 !guid !108 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %_1) unnamed_addr #1 !guid !109 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %2 = load ptr, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = icmp eq i64 %_2, 0
  br i1 %5, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<unwind::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsj61JMRYXuTT_6unwind5NoisyEEB1a_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !110 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<unwind::Noisy> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<unwind::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsj61JMRYXuTT_6unwind5NoisyEEB1h_(ptr align 8 %_1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<unwind::Noisy>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsj61JMRYXuTT_6unwind5NoisyEEB1h_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<[unwind::Noisy]>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEEB1d_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !111 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load i64, ptr %1, align 8
; invoke core::ptr::drop_glue::<[unwind::Noisy]>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsj61JMRYXuTT_6unwind5NoisyEBE_(ptr align 8 %_6.0, i64 %_6.1)
          to label %bb3 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<[unwind::Noisy]> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #19
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb4

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<[unwind::Noisy]> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #21
  ret void

terminate:                                        ; preds = %bb4
  %6 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb2:                                              ; preds = %bb4
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  %9 = load i32, ptr %8, align 8
  %10 = insertvalue { ptr, i32 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i32 } %10, i32 %9, 1
  resume { ptr, i32 } %11
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<unwind::Noisy>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecNtCsj61JMRYXuTT_6unwind5NoisyEEB1h_(ptr align 8 %_1) unnamed_addr #1 !guid !112 {
start:
; call <alloc::raw_vec::RawVec<unwind::Noisy> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<unwind::Noisy>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_1) unnamed_addr #1 !guid !113 {
start:
; call <unwind::Noisy as core::ops::drop::Drop>::drop
  call void @_RNvXCsj61JMRYXuTT_6unwindNtB2_5NoisyNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<[unwind::Noisy]>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsj61JMRYXuTT_6unwind5NoisyEBE_(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !114 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [8 x i8], align 8
  store i64 0, ptr %_3, align 8
  br label %bb6

bb6:                                              ; preds = %bb5, %start
  %1 = load i64, ptr %_3, align 8
  %_7 = icmp eq i64 %1, %_1.1
  br i1 %_7, label %bb1, label %bb5

bb5:                                              ; preds = %bb6
  %2 = load i64, ptr %_3, align 8
  %_6 = getelementptr inbounds nuw %Noisy, ptr %_1.0, i64 %2
  %3 = load i64, ptr %_3, align 8
  %4 = add i64 %3, 1
  store i64 %4, ptr %_3, align 8
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_6)
          to label %bb6 unwind label %cleanup

bb1:                                              ; preds = %bb6
  ret void

bb4:                                              ; preds = %bb3, %cleanup
  %5 = load i64, ptr %_3, align 8
  %_5 = icmp eq i64 %5, %_1.1
  br i1 %_5, label %bb2, label %bb3

cleanup:                                          ; preds = %bb5
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb4

bb3:                                              ; preds = %bb4
  %10 = load i64, ptr %_3, align 8
  %_4 = getelementptr inbounds nuw %Noisy, ptr %_1.0, i64 %10
  %11 = load i64, ptr %_3, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %_3, align 8
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_4) #19
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb4
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

terminate:                                        ; preds = %bb3
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECsj61JMRYXuTT_6unwind(i8 %dummy) unnamed_addr #0 !guid !115 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !116
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsj61JMRYXuTT_6unwind(ptr %f) unnamed_addr #2 personality ptr @rust_eh_personality !guid !117 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsj61JMRYXuTT_6unwind(ptr %f) #21
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #21
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[unwind::Noisy], unwind::Noisy>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSNtCsj61JMRYXuTT_6unwind5NoisyBX_EBZ_(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !118 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; std::panicking::catch_unwind::do_call::<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB1Z_(ptr %data) unnamed_addr #0 !guid !119 {
start:
; call <core::mem::manually_drop::ManuallyDrop<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE4takeB1R_(ptr %data) #21
; call <core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}> as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvXsl_NtNtCsl10jNU3mE6R_4core5panic11unwind_safeINtB5_16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EINtNtNtB9_3ops8function6FnOnceuE9call_onceB1d_() #21
; call <core::mem::maybe_dangling::MaybeDangling<()>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std()
  ret void
}

; std::panicking::catch_unwind::do_call::<unwind::main::{closure#3}::{closure#0}, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEB10_(ptr %data) unnamed_addr #0 !guid !120 {
start:
; call <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#3}::{closure#0}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E4takeB18_(ptr %data) #21
; call unwind::main::{closure#3}::{closure#0}
  call void @_RNCNCNvCsj61JMRYXuTT_6unwind4mains1_00B5_() #21
; call <core::mem::maybe_dangling::MaybeDangling<()>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std()
  ret void
}

; std::panicking::catch_unwind::do_call::<unwind::main::{closure#3}, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBY_(ptr %data) unnamed_addr #0 !guid !121 {
start:
; call <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#3}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains1_0E4takeB16_(ptr %data) #21
; call unwind::main::{closure#3}
  call void @_RNCNvCsj61JMRYXuTT_6unwind4mains1_0B3_() #21
; call <core::mem::maybe_dangling::MaybeDangling<()>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std()
  ret void
}

; std::panicking::catch_unwind::do_call::<unwind::main::{closure#4}, i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBY_(ptr %data) unnamed_addr #0 !guid !122 {
start:
; call <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#4}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains2_0E4takeB16_(ptr %data) #21
; call unwind::main::{closure#4}
  %_5 = call i32 @_RNCNvCsj61JMRYXuTT_6unwind4mains2_0B3_() #21
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<unwind::main::{closure#1}, u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCsj61JMRYXuTT_6unwind4mains_0mEBY_(ptr %data) unnamed_addr #0 !guid !123 {
start:
; call <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#1}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains_0E4takeB16_(ptr %data) #21
; call unwind::main::{closure#1}
  %_5 = call i32 @_RNCNvCsj61JMRYXuTT_6unwind4mains_0B3_() #21
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCsj61JMRYXuTT_6unwind(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>, ()>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB20_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !124 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<unwind::main::{closure#3}::{closure#0}, ()>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEB11_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !125 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<unwind::main::{closure#3}, ()>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBZ_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !126 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<unwind::main::{closure#4}, i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBZ_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !127 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<unwind::main::{closure#1}, u32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCsj61JMRYXuTT_6unwind4mains_0mEBZ_(ptr %data, ptr %payload) unnamed_addr #3 personality ptr @rust_eh_personality !guid !128 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #22
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsj61JMRYXuTT_6unwind.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csj61JMRYXuTT_6unwind(ptr align 8 %_1) unnamed_addr #0 !guid !129 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsj61JMRYXuTT_6unwind(ptr %_4) #23
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsj61JMRYXuTT_6unwind() #21
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csj61JMRYXuTT_6unwind(i8 %_2) #21
  ret i32 %_0
}

; unwind::main::{closure#0}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCsj61JMRYXuTT_6unwind4main00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) unnamed_addr #0 !guid !130 {
start:
; call <&str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) #21
  ret void
}

; unwind::main::{closure#0}::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCsj61JMRYXuTT_6unwind4main0s_0B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_1) unnamed_addr #0 !guid !131 {
start:
; call <std::panic::PanicHookInfo>::payload
  %0 = call { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCsj61JMRYXuTT_6unwind(ptr align 8 %_1) #21
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
  %_2 = call align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr %_3.0, ptr align 8 %_3.1) #21
; call <core::option::Option<&alloc::string::String>>::cloned
  call void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2)
  ret void
}

; unwind::main::{closure#3}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCsj61JMRYXuTT_6unwind4mains1_00B5_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !132 {
start:
  %0 = alloca [16 x i8], align 8
  %_b = alloca [16 x i8], align 8
  store ptr @alloc_ab7766fee1e1b94f8c00ce7ffec41c7e, ptr %_b, align 8
  %1 = getelementptr inbounds i8, ptr %_b, i64 8
  store i64 1, ptr %1, align 8
; invoke <core::fmt::Arguments>::from_str_nonconst
  %2 = invoke { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCsj61JMRYXuTT_6unwind(ptr @alloc_0280725f3eb987d13d947714e41d5ae1, i64 7)
          to label %bb1 unwind label %cleanup

bb2:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_b) #19
          to label %bb3 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %3 = landingpad { ptr, i32 }
          cleanup
  %4 = extractvalue { ptr, i32 } %3, 0
  %5 = extractvalue { ptr, i32 } %3, 1
  store ptr %4, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %5, ptr %6, align 8
  br label %bb2

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; invoke core::panicking::panic_fmt
  invoke void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_4.0, ptr %_4.1, ptr align 8 @alloc_6d0551713e79347e9595c2ef6cb10d53) #24
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %bb1
  unreachable

terminate:                                        ; preds = %bb2
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb3:                                              ; preds = %bb2
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; unwind::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsj61JMRYXuTT_6unwind4main0B3_(ptr %_1, ptr align 8 %info) unnamed_addr #0 personality ptr @rust_eh_personality !guid !133 {
start:
  %0 = alloca [16 x i8], align 8
  %_14 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_5 = alloca [24 x i8], align 8
  %_4 = alloca [24 x i8], align 8
  %msg = alloca [24 x i8], align 8
; call <std::panic::PanicHookInfo>::payload
  %1 = call { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCsj61JMRYXuTT_6unwind(ptr align 8 %info) #21
  %_7.0 = extractvalue { ptr, ptr } %1, 0
  %_7.1 = extractvalue { ptr, ptr } %1, 1
; call <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
  %_6 = call align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECsddYV2PBJW9h_3std(ptr %_7.0, ptr align 8 %_7.1) #21
; call <core::option::Option<&&str>>::map::<alloc::string::String, unwind::main::{closure#0}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCsj61JMRYXuTT_6unwind4main00EB1y_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %_6) #21
; call <core::option::Option<alloc::string::String>>::or_else::<unwind::main::{closure#0}::{closure#1}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE7or_elseNCNCNvCsj61JMRYXuTT_6unwind4main0s_0EB1z_(ptr sret([24 x i8]) align 8 %_4, ptr align 8 %_5, ptr align 8 %info) #21
; call <core::option::Option<alloc::string::String>>::unwrap_or_default
  call void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %msg, ptr align 8 %_4) #21
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_14, ptr align 8 %msg)
          to label %bb6 unwind label %cleanup

bb10:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %msg) #19
          to label %bb11 unwind label %terminate

cleanup:                                          ; preds = %bb7, %bb6, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb10

bb6:                                              ; preds = %start
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_14, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %7 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_02b558d5b27198b9b90fbafced75e0cf, ptr align 8 %args)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  %_10.0 = extractvalue { ptr, ptr } %7, 0
  %_10.1 = extractvalue { ptr, ptr } %7, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_10.0, ptr %_10.1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %msg)
  ret void

terminate:                                        ; preds = %bb10
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb11:                                             ; preds = %bb10
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; unwind::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsj61JMRYXuTT_6unwind4mains0_0B3_(ptr %_1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !134 {
start:
  %0 = alloca [16 x i8], align 8
  %w = alloca [24 x i8], align 8
  %_a = alloca [16 x i8], align 8
  store ptr @alloc_3827bbb606bbdb0f0c926011c14ccc34, ptr %_a, align 8
  %1 = getelementptr inbounds i8, ptr %_a, i64 8
  store i64 1, ptr %1, align 8
; invoke <alloc::vec::Vec<u8>>::new
  invoke void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8 %w)
          to label %bb1 unwind label %cleanup

bb6:                                              ; preds = %bb5, %cleanup
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_a) #19
          to label %bb7 unwind label %terminate

cleanup:                                          ; preds = %bb2, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb6

bb1:                                              ; preds = %start
; invoke <alloc::vec::Vec<u8> as core::ops::index::Index<usize>>::index
  %_4 = invoke ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VechEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCsj61JMRYXuTT_6unwind(ptr align 8 %w, i64 3, ptr align 8 @alloc_8aacd928cc9cd06d971ebb753399589c)
          to label %bb2 unwind label %cleanup1

bb5:                                              ; preds = %cleanup1
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8 %w) #19
          to label %bb6 unwind label %terminate

cleanup1:                                         ; preds = %bb1
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb5

bb2:                                              ; preds = %bb1
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8 %w)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
; call core::ptr::drop_glue::<unwind::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_a)
  ret void

terminate:                                        ; preds = %bb6, %bb5
  %10 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb7:                                              ; preds = %bb6
  %11 = load ptr, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  %13 = load i32, ptr %12, align 8
  %14 = insertvalue { ptr, i32 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i32 } %14, i32 %13, 1
  resume { ptr, i32 } %15
}

; unwind::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsj61JMRYXuTT_6unwind4mains1_0B3_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !135 {
start:
  %_4.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_c = alloca [16 x i8], align 8
  %_10 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %inner = alloca [16 x i8], align 8
; call std::panic::catch_unwind::<unwind::main::{closure#3}::{closure#0}, ()>
  %1 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCsj61JMRYXuTT_6unwind4mains1_00uEBM_()
  %2 = extractvalue { ptr, ptr } %1, 0
  %3 = extractvalue { ptr, ptr } %1, 1
  store ptr %2, ptr %inner, align 8
  %4 = getelementptr inbounds i8, ptr %inner, i64 8
  store ptr %3, ptr %4, align 8
; invoke <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %5 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %inner)
          to label %bb2 unwind label %cleanup

bb8:                                              ; preds = %bb7, %cleanup
; invoke core::ptr::drop_glue::<core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %inner) #19
          to label %bb9 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb3, %bb2, %start
  %6 = landingpad { ptr, i32 }
          cleanup
  %7 = extractvalue { ptr, i32 } %6, 0
  %8 = extractvalue { ptr, i32 } %6, 1
  store ptr %7, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %8, ptr %9, align 8
  br label %bb8

bb2:                                              ; preds = %start
  %10 = zext i1 %5 to i8
  store i8 %10, ptr %_7, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_10, ptr %_7)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
  %11 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 8 %_10, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<18, 1>
  %12 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj12_Kj1_EB8_(ptr @alloc_c985f9648a4752df94836fcbae4dfeb9, ptr align 8 %args)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %12, 0
  %_4.1 = extractvalue { ptr, ptr } %12, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  store ptr @alloc_18f2f0d3d4f38df552db2352111ec81f, ptr %_c, align 8
  %13 = getelementptr inbounds i8, ptr %_c, i64 8
  store i64 1, ptr %13, align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; invoke alloc::boxed::box_new_uninit
  %_3.i2 = invoke ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsj61JMRYXuTT_6unwind(i64 4, i64 4) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxmE3newCsj61JMRYXuTT_6unwind.exit unwind label %cleanup1

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxmE3newCsj61JMRYXuTT_6unwind.exit: ; preds = %bb5
  store i8 0, ptr %_4.i, align 1
  store i32 42, ptr %_3.i2, align 4
  br label %bb6

bb7:                                              ; preds = %cleanup1
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_c) #19
          to label %bb8 unwind label %terminate

cleanup1:                                         ; preds = %bb5, %bb6
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb7

bb6:                                              ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxmE3newCsj61JMRYXuTT_6unwind.exit
; invoke std::panic::resume_unwind
  invoke void @_RNvNtCsddYV2PBJW9h_3std5panic13resume_unwind(ptr %_3.i2, ptr align 8 @vtable.1) #24
          to label %unreachable unwind label %cleanup1

unreachable:                                      ; preds = %bb6
  unreachable

terminate:                                        ; preds = %bb8, %bb7
  %18 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb9:                                              ; preds = %bb8
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr inbounds i8, ptr %0, i64 8
  %21 = load i32, ptr %20, align 8
  %22 = insertvalue { ptr, i32 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i32 } %22, i32 %21, 1
  resume { ptr, i32 } %23
}

; unwind::main::{closure#4}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCsj61JMRYXuTT_6unwind4mains2_0B3_() unnamed_addr #0 !guid !136 {
start:
; call <core::option::Option<i32>>::expect
  %_0 = call i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE6expectCsj61JMRYXuTT_6unwind(i32 0, i32 undef, ptr @alloc_e1e82be9de827f623ba9c6d5bef55b18, i64 13, ptr align 8 @alloc_7a883dc29779389d1427c2ddfbcbb9ad) #21
  ret i32 %_0
}

; unwind::main::{closure#5}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNvCsj61JMRYXuTT_6unwind4mains3_0B3_(ptr %_1) unnamed_addr #0 !guid !137 {
start:
  %_6 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
; call <core::fmt::rt::Argument>::new_display::<u8>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_6, ptr %_1) #21
  %0 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_6, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<15, 1>
  %1 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECsj61JMRYXuTT_6unwind(ptr @alloc_79c0faa1113895cec8a77a1ad0fa7359, ptr align 8 %args) #21
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_3.0, ptr %_3.1, ptr align 8 @alloc_fab7d5ddde7e96f6eda9131f29e4478a) #25
  unreachable
}

; unwind::main::{closure#6}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCsj61JMRYXuTT_6unwind4mains4_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !138 {
start:
  %2 = alloca [16 x i8], align 8
  %e = alloca [16 x i8], align 8
  store ptr %0, ptr %e, align 8
  %3 = getelementptr inbounds i8, ptr %e, i64 8
  store ptr %1, ptr %3, align 8
  %_5.0 = load ptr, ptr %e, align 8
  %4 = getelementptr inbounds i8, ptr %e, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
  %_3 = invoke align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e) #19
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

bb1:                                              ; preds = %start
; invoke <core::option::Option<&alloc::string::String>>::cloned
  invoke void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_3)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e)
  ret void

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb5:                                              ; preds = %bb4
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; unwind::main::{closure#7}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RNCNvCsj61JMRYXuTT_6unwind4mains5_0B3_(ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !139 {
start:
  %2 = alloca [16 x i8], align 8
  %e = alloca [16 x i8], align 8
  store ptr %0, ptr %e, align 8
  %3 = getelementptr inbounds i8, ptr %e, i64 8
  store ptr %1, ptr %3, align 8
  %_5.0 = load ptr, ptr %e, align 8
  %4 = getelementptr inbounds i8, ptr %e, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<u32>
  %_3 = invoke align 4 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refmECsj61JMRYXuTT_6unwind(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e) #19
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

bb1:                                              ; preds = %start
; invoke <core::option::Option<&u32>>::copied
  %9 = invoke { i32, i32 } @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRmE6copiedCsj61JMRYXuTT_6unwind(ptr align 4 %_3)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  %_0.0 = extractvalue { i32, i32 } %9, 0
  %_0.1 = extractvalue { i32, i32 } %9, 1
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e)
  %10 = insertvalue { i32, i32 } poison, i32 %_0.0, 0
  %11 = insertvalue { i32, i32 } %10, i32 %_0.1, 1
  ret { i32, i32 } %11

terminate:                                        ; preds = %bb4
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb5:                                              ; preds = %bb4
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %2, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17
}

; unwind::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCsj61JMRYXuTT_6unwind4mains_0B3_() unnamed_addr #0 !guid !140 {
start:
; call unwind::deep
  %_0 = call i32 @_RNvCsj61JMRYXuTT_6unwind4deep(i32 3)
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCsj61JMRYXuTT_6unwind(ptr %_1) unnamed_addr #0 !guid !141 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsj61JMRYXuTT_6unwind(ptr %0) #21
  ret i32 %_0
}

; <unwind::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNSNvYNCNvCsj61JMRYXuTT_6unwind4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !142 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <unwind::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
  call void @_RNvYNCNvCsj61JMRYXuTT_6unwind4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %1) #21
  ret void
}

; unwind::deep
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCsj61JMRYXuTT_6unwind4deep(i32 %n) unnamed_addr #1 personality ptr @rust_eh_personality !guid !143 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  %_g = alloca [16 x i8], align 8
  %_5 = urem i32 %n, 2
  %_4 = icmp eq i32 %_5, 0
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store ptr @alloc_125c1a986a46d7dd60e9e2dd8e919f72, ptr %_3, align 8, !captures !144
  %1 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 3, ptr %1, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store ptr @alloc_fbf52d5fed6793d3e790c9ce6627a01c, ptr %_3, align 8, !captures !144
  %2 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 4, ptr %2, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %5 = load i64, ptr %4, align 8
  store ptr %3, ptr %_g, align 8
  %6 = getelementptr inbounds i8, ptr %_g, i64 8
  store i64 %5, ptr %6, align 8
  %_7 = icmp eq i32 %n, 0
  br i1 %_7, label %bb5, label %bb7

bb7:                                              ; preds = %bb4
  %_12.0 = sub i32 %n, 1
  %_12.1 = icmp ult i32 %n, 1
  br i1 %_12.1, label %panic, label %bb8

bb5:                                              ; preds = %bb4
; invoke <core::fmt::Arguments>::from_str
  %7 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr @alloc_753040b032de2b44c70b10e6e33f5434, i64 14)
          to label %bb6 unwind label %cleanup

bb8:                                              ; preds = %bb7
; invoke unwind::deep
  %_10 = invoke i32 @_RNvCsj61JMRYXuTT_6unwind4deep(i32 %_12.0)
          to label %bb9 unwind label %cleanup

panic:                                            ; preds = %bb7
; invoke core::panicking::panic_const::panic_const_sub_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_0970c60599a798604a3541cff42e1e58) #24
          to label %unreachable unwind label %cleanup

bb12:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_g) #19
          to label %bb13 unwind label %terminate

cleanup:                                          ; preds = %bb6, %bb5, %panic1, %bb8, %panic
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb12

unreachable:                                      ; preds = %bb6, %panic1, %panic
  unreachable

bb9:                                              ; preds = %bb8
  %_13.0 = add i32 %_10, 1
  %_13.1 = icmp ult i32 %_13.0, %_10
  br i1 %_13.1, label %panic1, label %bb10

bb10:                                             ; preds = %bb9
; call core::ptr::drop_glue::<unwind::Noisy>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_g)
  ret i32 %_13.0

panic1:                                           ; preds = %bb9
; invoke core::panicking::panic_const::panic_const_add_overflow
  invoke void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_f7c3db4719e24bc3032931eae45c9dac) #24
          to label %unreachable unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_9.0 = extractvalue { ptr, ptr } %7, 0
  %_9.1 = extractvalue { ptr, ptr } %7, 1
; invoke core::panicking::panic_fmt
  invoke void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_9.0, ptr %_9.1, ptr align 8 @alloc_be58da8534b8ede79c3a9683d69e5ca7) #24
          to label %unreachable unwind label %cleanup

terminate:                                        ; preds = %bb12
  %12 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb13:                                             ; preds = %bb12
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17
}

; unwind::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsj61JMRYXuTT_6unwind4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !145 {
start:
  %_4.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_74 = alloca [1 x i8], align 1
  %_66 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %m = alloca [1 x i8], align 1
  %n = alloca [1 x i8], align 1
  %_last = alloca [16 x i8], align 8
  %_54 = alloca [16 x i8], align 8
  %_51 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_48 = alloca [1 x i8], align 1
  %r3 = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_37 = alloca [8 x i8], align 4
  %_31 = alloca [24 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %args1 = alloca [16 x i8], align 8
  %_24 = alloca [24 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %r = alloca [16 x i8], align 8
  store i8 0, ptr %_74, align 1
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsj61JMRYXuTT_6unwind(i64 1, i64 0) #21
  store i8 0, ptr %_4.i, align 1
; call std::panicking::set_hook
  call void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr %_3.i, ptr align 8 @vtable.2)
; call std::panic::catch_unwind::<unwind::main::{closure#1}, u32>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains_0mEBK_(ptr sret([16 x i8]) align 8 %r)
; invoke <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %1 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %r)
          to label %bb4 unwind label %cleanup

bb43:                                             ; preds = %bb45, %bb46, %cleanup
; invoke core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %r) #19
          to label %bb44 unwind label %terminate

cleanup:                                          ; preds = %bb7, %_3.i.noexc, %bb6, %bb5, %bb4, %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb43

bb4:                                              ; preds = %start
  %6 = zext i1 %1 to i8
  store i8 %6, ptr %_9, align 1
; invoke <core::fmt::rt::Argument>::new_debug::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugbECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_12, ptr %_9)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_12, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %8 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsj61JMRYXuTT_6unwind(ptr @alloc_31a4754d1d7ab2dbef2d2f2030dca95f, ptr align 8 %args)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_6.0 = extractvalue { ptr, ptr } %8, 0
  %_6.1 = extractvalue { ptr, ptr } %8, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_6.0, ptr %_6.1)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
; invoke alloc::boxed::box_new_uninit
  %_1.i14 = invoke align 8 ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsj61JMRYXuTT_6unwind(i64 8, i64 32) #21
          to label %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsj61JMRYXuTT_6unwind5Noisyj2_E10new_uninitBH_.exit unwind label %cleanup

_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsj61JMRYXuTT_6unwind5Noisyj2_E10new_uninitBH_.exit: ; preds = %bb7
  br label %bb8

bb8:                                              ; preds = %_RNvMNtCs7CppTae75M1_5alloc5boxedINtB2_3BoxANtCsj61JMRYXuTT_6unwind5Noisyj2_E10new_uninitBH_.exit
  %_77 = ptrtoint ptr %_1.i14 to i64
  %_79 = and i64 %_77, 7
  %_80 = icmp eq i64 %_79, 0
  br i1 %_80, label %bb47, label %panic

bb47:                                             ; preds = %bb8
  %_82 = ptrtoint ptr %_1.i14 to i64
  %_84 = icmp eq i64 %_82, 0
  %_85 = and i1 %_84, true
  %_86 = xor i1 %_85, true
  br i1 %_86, label %bb48, label %panic6

panic:                                            ; preds = %bb8
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_77, ptr align 8 @alloc_83c2d8dfe927c8d1ff9bad87f0f15c1c) #26
  unreachable

bb48:                                             ; preds = %bb47
  %9 = getelementptr inbounds nuw %Noisy, ptr %_1.i14, i64 0
  store ptr @alloc_4708833df625061546a6b3f99554ca2c, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 2, ptr %10, align 8
  %11 = getelementptr inbounds nuw %Noisy, ptr %_1.i14, i64 1
  store ptr @alloc_8f96945e3024e6985f2e60d09c120143, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 8
  store i64 2, ptr %12, align 8
  br label %_3.i.noexc

_3.i.noexc:                                       ; preds = %bb48
; invoke <[unwind::Noisy]>::into_vec::<alloc::alloc::Global>
  invoke void @_RINvMNtCs7CppTae75M1_5alloc5sliceSNtCsj61JMRYXuTT_6unwind5Noisy8into_vecNtNtB5_5alloc6GlobalEBy_(ptr sret([24 x i8]) align 8 %v, ptr align 8 %_1.i14, i64 2) #21
          to label %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsj61JMRYXuTT_6unwind5NoisyKj2_EB13_.exit unwind label %cleanup

_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsj61JMRYXuTT_6unwind5NoisyKj2_EB13_.exit: ; preds = %_3.i.noexc
  br label %bb9

panic6:                                           ; preds = %bb47
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_83c2d8dfe927c8d1ff9bad87f0f15c1c) #26
  unreachable

bb9:                                              ; preds = %_RINvNtCs7CppTae75M1_5alloc5boxed31box_assume_init_into_vec_unsafeNtCsj61JMRYXuTT_6unwind5NoisyKj2_EB13_.exit
  store i8 1, ptr %_74, align 1
; invoke std::panic::catch_unwind::<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>, ()>
  %13 = invoke { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindINtNtNtCsl10jNU3mE6R_4core5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EuEB1L_()
          to label %bb10 unwind label %cleanup7

bb46:                                             ; preds = %bb42, %bb41, %cleanup7
  %14 = load i8, ptr %_74, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb45, label %bb43

cleanup7:                                         ; preds = %bb37, %bb23, %bb22, %bb21, %bb20, %bb19, %bb18, %bb17, %bb16, %bb15, %bb11, %bb10, %bb9
  %16 = landingpad { ptr, i32 }
          cleanup
  %17 = extractvalue { ptr, i32 } %16, 0
  %18 = extractvalue { ptr, i32 } %16, 1
  store ptr %17, ptr %0, align 8
  %19 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %18, ptr %19, align 8
  br label %bb46

bb10:                                             ; preds = %bb9
  %r.0 = extractvalue { ptr, ptr } %13, 0
  %r.1 = extractvalue { ptr, ptr } %13, 1
; invoke <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::err
  %20 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE3errCsj61JMRYXuTT_6unwind(ptr %r.0, ptr %r.1)
          to label %bb11 unwind label %cleanup7

bb11:                                             ; preds = %bb10
  %_25.0 = extractvalue { ptr, ptr } %20, 0
  %_25.1 = extractvalue { ptr, ptr } %20, 1
; invoke <core::option::Option<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::and_then::<alloc::string::String, unwind::main::{closure#6}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE8and_thenNtNtBN_6string6StringNCNvCsj61JMRYXuTT_6unwind4mains4_0EB2t_(ptr sret([24 x i8]) align 8 %_24, ptr %_25.0, ptr %_25.1)
          to label %bb12 unwind label %cleanup7

bb12:                                             ; preds = %bb11
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<alloc::string::String>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_27, ptr align 8 %_24)
          to label %bb13 unwind label %cleanup8

bb42:                                             ; preds = %cleanup8
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_24) #19
          to label %bb46 unwind label %terminate

cleanup8:                                         ; preds = %bb14, %bb13, %bb12
  %21 = landingpad { ptr, i32 }
          cleanup
  %22 = extractvalue { ptr, i32 } %21, 0
  %23 = extractvalue { ptr, i32 } %21, 1
  store ptr %22, ptr %0, align 8
  %24 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %23, ptr %24, align 8
  br label %bb42

bb13:                                             ; preds = %bb12
  %25 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %25, ptr align 8 %_27, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<12, 1>
  %26 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjc_Kj1_ECsj61JMRYXuTT_6unwind(ptr @alloc_c763cf0b07e9674e5b5a834b413ba04f, ptr align 8 %args1)
          to label %bb14 unwind label %cleanup8

bb14:                                             ; preds = %bb13
  %_21.0 = extractvalue { ptr, ptr } %26, 0
  %_21.1 = extractvalue { ptr, ptr } %26, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_21.0, ptr %_21.1)
          to label %bb15 unwind label %cleanup8

bb15:                                             ; preds = %bb14
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_24)
          to label %bb16 unwind label %cleanup7

bb16:                                             ; preds = %bb15
  store i8 0, ptr %_74, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_31, ptr align 8 %v, i64 24, i1 false)
; invoke core::mem::drop::<alloc::vec::Vec<unwind::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3mem4dropINtNtCs7CppTae75M1_5alloc3vec3VecNtCsj61JMRYXuTT_6unwind5NoisyEEB15_(ptr align 8 %_31)
          to label %bb17 unwind label %cleanup7

bb17:                                             ; preds = %bb16
; invoke std::panic::catch_unwind::<unwind::main::{closure#3}, ()>
  %27 = invoke { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains1_0uEBK_()
          to label %bb18 unwind label %cleanup7

bb18:                                             ; preds = %bb17
  %r.09 = extractvalue { ptr, ptr } %27, 0
  %r.110 = extractvalue { ptr, ptr } %27, 1
; invoke <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::err
  %28 = invoke { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE3errCsj61JMRYXuTT_6unwind(ptr %r.09, ptr %r.110)
          to label %bb19 unwind label %cleanup7

bb19:                                             ; preds = %bb18
  %_38.0 = extractvalue { ptr, ptr } %28, 0
  %_38.1 = extractvalue { ptr, ptr } %28, 1
; invoke <core::option::Option<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::and_then::<u32, unwind::main::{closure#7}>
  %29 = invoke { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE8and_thenmNCNvCsj61JMRYXuTT_6unwind4mains5_0EB29_(ptr %_38.0, ptr %_38.1)
          to label %bb20 unwind label %cleanup7

bb20:                                             ; preds = %bb19
  %30 = extractvalue { i32, i32 } %29, 0
  %31 = extractvalue { i32, i32 } %29, 1
  store i32 %30, ptr %_37, align 4
  %32 = getelementptr inbounds i8, ptr %_37, i64 4
  store i32 %31, ptr %32, align 4
; invoke <core::fmt::rt::Argument>::new_debug::<core::option::Option<u32>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6option6OptionmEECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_40, ptr align 4 %_37)
          to label %bb21 unwind label %cleanup7

bb21:                                             ; preds = %bb20
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_40, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<14, 1>
  %34 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr @alloc_7ad1c81a7c2155091a8327f883d7946b, ptr align 8 %args2)
          to label %bb22 unwind label %cleanup7

bb22:                                             ; preds = %bb21
  %_34.0 = extractvalue { ptr, ptr } %34, 0
  %_34.1 = extractvalue { ptr, ptr } %34, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_34.0, ptr %_34.1)
          to label %bb23 unwind label %cleanup7

bb23:                                             ; preds = %bb22
; invoke std::panic::catch_unwind::<unwind::main::{closure#4}, i32>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCsj61JMRYXuTT_6unwind4mains2_0lEBK_(ptr sret([16 x i8]) align 8 %r3)
          to label %bb24 unwind label %cleanup7

bb24:                                             ; preds = %bb23
; invoke <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %35 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %r3)
          to label %bb25 unwind label %cleanup11

bb41:                                             ; preds = %bb40, %cleanup11
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %r3) #19
          to label %bb46 unwind label %terminate

cleanup11:                                        ; preds = %bb36, %bb29, %bb28, %bb27, %bb26, %bb25, %bb24
  %36 = landingpad { ptr, i32 }
          cleanup
  %37 = extractvalue { ptr, i32 } %36, 0
  %38 = extractvalue { ptr, i32 } %36, 1
  store ptr %37, ptr %0, align 8
  %39 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %38, ptr %39, align 8
  br label %bb41

bb25:                                             ; preds = %bb24
  %40 = zext i1 %35 to i8
  store i8 %40, ptr %_48, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_51, ptr %_48)
          to label %bb26 unwind label %cleanup11

bb26:                                             ; preds = %bb25
  %41 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %41, ptr align 8 %_51, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %42 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECsj61JMRYXuTT_6unwind(ptr @alloc_20e1345a6ca51fe6622b10715f7afc58, ptr align 8 %args4)
          to label %bb27 unwind label %cleanup11

bb27:                                             ; preds = %bb26
  %_45.0 = extractvalue { ptr, ptr } %42, 0
  %_45.1 = extractvalue { ptr, ptr } %42, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_45.0, ptr %_45.1)
          to label %bb28 unwind label %cleanup11

bb28:                                             ; preds = %bb27
; invoke std::panicking::take_hook
  %43 = invoke { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook()
          to label %bb29 unwind label %cleanup11

bb29:                                             ; preds = %bb28
  %44 = extractvalue { ptr, ptr } %43, 0
  %45 = extractvalue { ptr, ptr } %43, 1
  store ptr %44, ptr %_54, align 8
  %46 = getelementptr inbounds i8, ptr %_54, i64 8
  store ptr %45, ptr %46, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8 %_54)
          to label %bb30 unwind label %cleanup11

bb30:                                             ; preds = %bb29
  store ptr @alloc_4047f048e81a836efb536f863c5bda29, ptr %_last, align 8
  %47 = getelementptr inbounds i8, ptr %_last, i64 8
  store i64 4, ptr %47, align 8
; invoke core::hint::black_box::<u8>
  %48 = invoke i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECsj61JMRYXuTT_6unwind(i8 -56)
          to label %bb31 unwind label %cleanup12

bb40:                                             ; preds = %cleanup12
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_last) #19
          to label %bb41 unwind label %terminate

cleanup12:                                        ; preds = %bb35, %bb34, %bb33, %bb32, %bb31, %bb30
  %49 = landingpad { ptr, i32 }
          cleanup
  %50 = extractvalue { ptr, i32 } %49, 0
  %51 = extractvalue { ptr, i32 } %49, 1
  store ptr %50, ptr %0, align 8
  %52 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %51, ptr %52, align 8
  br label %bb40

bb31:                                             ; preds = %bb30
  store i8 %48, ptr %n, align 1
  %53 = load i8, ptr %n, align 1
; invoke <u8>::checked_add
  %54 = invoke { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCsj61JMRYXuTT_6unwind(i8 %53, i8 100)
          to label %bb32 unwind label %cleanup12

bb32:                                             ; preds = %bb31
  %_58.0 = extractvalue { i1, i8 } %54, 0
  %_58.1 = extractvalue { i1, i8 } %54, 1
; invoke <core::option::Option<u8>>::unwrap_or_else::<unwind::main::{closure#5}>
  %55 = invoke i8 @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE14unwrap_or_elseNCNvCsj61JMRYXuTT_6unwind4mains3_0EB14_(i1 zeroext %_58.0, i8 %_58.1, ptr %n, ptr align 8 @alloc_a0768cdb3da30baaab7f5655e171e172)
          to label %bb33 unwind label %cleanup12

bb33:                                             ; preds = %bb32
  store i8 %55, ptr %m, align 1
; invoke <core::fmt::rt::Argument>::new_display::<u8>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8 %_66, ptr %m)
          to label %bb34 unwind label %cleanup12

bb34:                                             ; preds = %bb33
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_66, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<17, 1>
  %57 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj1_ECs2d0hS33vDhg_5gimli(ptr @alloc_1e83afe964be28b7af38cd986c24bed2, ptr align 8 %args5)
          to label %bb35 unwind label %cleanup12

bb35:                                             ; preds = %bb34
  %_62.0 = extractvalue { ptr, ptr } %57, 0
  %_62.1 = extractvalue { ptr, ptr } %57, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_62.0, ptr %_62.1)
          to label %bb36 unwind label %cleanup12

bb36:                                             ; preds = %bb35
; invoke core::ptr::drop_glue::<unwind::Noisy>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtCsj61JMRYXuTT_6unwind5NoisyEBD_(ptr align 8 %_last)
          to label %bb37 unwind label %cleanup11

bb37:                                             ; preds = %bb36
; invoke core::ptr::drop_glue::<core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %r3)
          to label %bb38 unwind label %cleanup7

bb38:                                             ; preds = %bb37
  store i8 0, ptr %_74, align 1
; call core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %r)
  ret void

terminate:                                        ; preds = %bb43, %bb45, %bb42, %bb41, %bb40
  %58 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #20
  unreachable

bb45:                                             ; preds = %bb46
; invoke core::ptr::drop_glue::<alloc::vec::Vec<unwind::Noisy>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecNtCsj61JMRYXuTT_6unwind5NoisyEEB1a_(ptr align 8 %v) #19
          to label %bb43 unwind label %terminate

bb44:                                             ; preds = %bb43
  %59 = load ptr, ptr %0, align 8
  %60 = getelementptr inbounds i8, ptr %0, i64 8
  %61 = load i32, ptr %60, align 8
  %62 = insertvalue { ptr, i32 } poison, ptr %59, 0
  %63 = insertvalue { ptr, i32 } %62, i32 %61, 1
  resume { ptr, i32 } %63
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !146 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !147 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8 %_1) #21
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !148 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #21
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsj61JMRYXuTT_6unwind(ptr %_2.0, i64 %_2.1) #21
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <std::panic::PanicHookInfo>::payload
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !149 {
start:
  %_0.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0.1 = load ptr, ptr %0, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsj61JMRYXuTT_6unwind(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !150 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<alloc::string::String>>::unwrap_or_default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !151 {
start:
  %x = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb4

bb2:                                              ; preds = %start
; call <alloc::string::String as core::default::Default>::default
  call void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0) #21
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32>>::expect
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE6expectCsj61JMRYXuTT_6unwind(i32 %0, i32 %1, ptr %msg.0, i64 %msg.1, ptr align 8 %2) unnamed_addr #0 !guid !152 {
start:
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %3 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %3, align 4
  %4 = load i32, ptr %self, align 4
  %5 = getelementptr inbounds i8, ptr %self, i64 4
  %6 = load i32, ptr %5, align 4
  %_3 = zext i32 %4 to i64
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %self, i64 4
  %val = load i32, ptr %8, align 4
  ret i32 %val

bb2:                                              ; preds = %start
; call core::option::expect_failed
  call void @_RNvNtCsl10jNU3mE6R_4core6option13expect_failed(ptr %msg.0, i64 %msg.1, ptr align 8 %2) #25
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !153 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !154 {
start:
; call <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !155 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !156 {
start:
; call <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::err
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE3errCsj61JMRYXuTT_6unwind(ptr %0, ptr %1) unnamed_addr #0 !guid !157 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_2 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_2 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %x.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %x.1 = load ptr, ptr %9, align 8
  store ptr %x.0, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %x.1, ptr %10, align 8
  br label %bb6

bb3:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %11 = load ptr, ptr %self, align 8
  %12 = getelementptr inbounds i8, ptr %self, i64 8
  %13 = load ptr, ptr %12, align 8
  %14 = ptrtoint ptr %11 to i64
  %15 = icmp eq i64 %14, 0
  %_4 = select i1 %15, i64 0, i64 1
  %16 = trunc nuw i64 %_4 to i1
  br i1 %16, label %bb4, label %bb5

bb4:                                              ; preds = %bb5, %bb6
  %17 = load ptr, ptr %_0, align 8
  %18 = getelementptr inbounds i8, ptr %_0, i64 8
  %19 = load ptr, ptr %18, align 8
  %20 = insertvalue { ptr, ptr } poison, ptr %17, 0
  %21 = insertvalue { ptr, ptr } %20, ptr %19, 1
  ret { ptr, ptr } %21

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECsj61JMRYXuTT_6unwind(ptr align 8 %self)
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !158 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load ptr, ptr %1, align 8
  %3 = ptrtoint ptr %0 to i64
  %4 = icmp eq i64 %3, 0
  %_2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2 to i1
  br i1 %5, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !159 {
start:
; call <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::mem::manually_drop::ManuallyDrop<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE4takeB1R_(ptr %slot) unnamed_addr #0 !guid !160 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE6as_refB1T_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#3}::{closure#0}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E4takeB18_(ptr %slot) unnamed_addr #0 !guid !161 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}::{closure#0}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E6as_refB1a_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#3}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains1_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !162 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains1_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#4}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains2_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !163 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#4}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains2_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<unwind::main::{closure#1}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCsj61JMRYXuTT_6unwind4mains_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !164 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#1}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE3newB1G_(ptr align 8 %x.0, i64 %x.1) unnamed_addr #1 !guid !165 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %x.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE6as_mutB1G_(ptr align 8 %self) unnamed_addr #1 !guid !166 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE6as_refB1G_(ptr align 8 %self) unnamed_addr #1 !guid !167 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE3newB1T_() unnamed_addr #1 !guid !168 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtNtB6_5panic11unwind_safe16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EE6as_refB1T_(ptr %self) unnamed_addr #1 !guid !169 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E3newB1a_() unnamed_addr #1 !guid !170 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}::{closure#0}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCsj61JMRYXuTT_6unwind4mains1_00E6as_refB1a_(ptr %self) unnamed_addr #1 !guid !171 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains1_0E3newB18_() unnamed_addr #1 !guid !172 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#3}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains1_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !173 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#4}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains2_0E3newB18_() unnamed_addr #1 !guid !174 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#4}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains2_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !175 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#1}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains_0E3newB18_() unnamed_addr #1 !guid !176 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<unwind::main::{closure#1}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCsj61JMRYXuTT_6unwind4mains_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !177 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCsj61JMRYXuTT_6unwind(i32 %x) unnamed_addr #1 !guid !178 {
start:
  ret i32 %x
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCsj61JMRYXuTT_6unwind(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !179 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsj61JMRYXuTT_6unwind() #21
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsj61JMRYXuTT_6unwind(i64 %align, ptr align 8 %0) #27
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsj61JMRYXuTT_6unwind(i64 %self) unnamed_addr #0 !guid !180 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !181 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCsj61JMRYXuTT_6unwind(i64 %_3) #21
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #21
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCsj61JMRYXuTT_6unwind(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !182 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsj61JMRYXuTT_6unwind(i64 %size, i64 %alignment, ptr align 8 %0) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !183 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !184 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsj61JMRYXuTT_6unwind(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !185 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsj61JMRYXuTT_6unwind(i64 %3, i64 %5, i1 zeroext %8) #21
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsj61JMRYXuTT_6unwind(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !186 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsj61JMRYXuTT_6unwind(ptr %2, i64 %4, i64 %6) #21
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCsj61JMRYXuTT_6unwind(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !187 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #21
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsj61JMRYXuTT_6unwind(i64 %11, i64 %13) #21
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsj61JMRYXuTT_6unwind(i64 %15, i64 %17) #21
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #21
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #21
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #21
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #21
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #21
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCsj61JMRYXuTT_6unwind(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !188 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsj61JMRYXuTT_6unwind(ptr %ptr, i64 %3, i64 %5) #21
  br label %bb3
}

; <alloc::raw_vec::RawVec<unwind::Noisy>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !189 {
start:
  %_8 = alloca [1 x i8], align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call alloc::raw_vec::new_cap::<unwind::Noisy>
  %capacity2 = call i64 @_RINvNtCs7CppTae75M1_5alloc7raw_vec7new_capNtCsj61JMRYXuTT_6unwind5NoisyEBG_(i64 %capacity)
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_8, align 1
; call <alloc::raw_vec::RawVecInner>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr %ptr, i64 %capacity2) #21
  %_6.0 = extractvalue { i64, ptr } %0, 0
  %_6.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  %1 = insertvalue { i64, ptr } poison, i64 %_6.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_6.1, 1
  ret { i64, ptr } %2

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<unwind::Noisy>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyE3ptrBO_(ptr align 8 %self) unnamed_addr #0 !guid !190 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<unwind::Noisy>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrNtCsj61JMRYXuTT_6unwind5NoisyEBY_(ptr align 8 %self) #21
  ret ptr %_0
}

; <core::option::Option<&alloc::string::String>>::cloned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !191 {
start:
; call <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #21
  ret void
}

; <core::option::Option<&u32>>::copied
; Function Attrs: nonlazybind uwtable
define internal { i32, i32 } @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRmE6copiedCsj61JMRYXuTT_6unwind(ptr align 4 %0) unnamed_addr #1 !guid !192 {
start:
  %_0 = alloca [8 x i8], align 4
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %_4 = load ptr, ptr %self, align 8
  %v = load i32, ptr %_4, align 4
  %5 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %v, ptr %5, align 4
  store i32 1, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i32, ptr %_0, align 4
  %7 = getelementptr inbounds i8, ptr %_0, i64 4
  %8 = load i32, ptr %7, align 4
  %9 = insertvalue { i32, i32 } poison, i32 %6, 0
  %10 = insertvalue { i32, i32 } %9, i32 %8, 1
  ret { i32, i32 } %10

bb1:                                              ; No predecessors!
  unreachable
}

; <core::ptr::unique::Unique<unwind::Noisy>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtCsj61JMRYXuTT_6unwind5NoisyE15as_non_null_ptrBS_(ptr %self) unnamed_addr #0 !guid !193 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<[unwind::Noisy]>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsj61JMRYXuTT_6unwind5NoisyE6as_ptrBT_(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !194 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::ptr::non_null::NonNull<core::option::Option<alloc::string::String>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEE8from_refCsj61JMRYXuTT_6unwind(ptr align 8 %r) unnamed_addr #0 !guid !195 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::option::Option<u32>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6option6OptionmEE8from_refCsj61JMRYXuTT_6unwind(ptr align 4 %r) unnamed_addr #0 !guid !196 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCsj61JMRYXuTT_6unwind(ptr align 8 %r) unnamed_addr #0 !guid !197 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCsj61JMRYXuTT_6unwind(ptr %r) unnamed_addr #0 !guid !198 {
start:
  ret ptr %r
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCsj61JMRYXuTT_6unwind(i64 %val) unnamed_addr #0 !guid !199 {
start:
  ret i64 %val
}

; <core::fmt::Arguments>::from_str_nonconst
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs2_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments17from_str_nonconstCsj61JMRYXuTT_6unwind(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !200 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr %s.0, i64 %s.1) #21
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !201 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCsj61JMRYXuTT_6unwind(ptr %s.0, i64 %s.1) #21
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <u8>::checked_add
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RNvMs4_NtCsl10jNU3mE6R_4core3numh11checked_addCsj61JMRYXuTT_6unwind(i8 %self, i8 %rhs) unnamed_addr #0 !guid !202 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [2 x i8], align 1
  %_5.0 = add i8 %self, %rhs
  %_5.1 = icmp ult i8 %_5.0, %self
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %0 = load i8, ptr %_0.i, align 1
  %1 = trunc nuw i8 %0 to i1
  br i1 %1, label %bb2, label %bb3

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %_6 = add nuw i8 %self, %rhs
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %_6, ptr %2, align 1
  store i8 1, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %3 = load i8, ptr %_0, align 1
  %4 = trunc nuw i8 %3 to i1
  %5 = getelementptr inbounds i8, ptr %_0, i64 1
  %6 = load i8, ptr %5, align 1
  %7 = insertvalue { i1, i8 } poison, i1 %4, 0
  %8 = insertvalue { i1, i8 } %7, i8 %6, 1
  ret { i1, i8 } %8
}

; <alloc::boxed::Box<[unwind::Noisy]>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsj61JMRYXuTT_6unwind5NoisyE23into_raw_with_allocatorBK_(ptr align 8 %b.0, i64 %b.1) unnamed_addr #0 !guid !203 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::new
  %0 = call { ptr, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE3newB1G_(ptr align 8 %b.0, i64 %b.1)
  %_2.0.i = extractvalue { ptr, i64 } %0, 0
  %_2.1.i = extractvalue { ptr, i64 } %0, 1
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store i64 %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE6as_mutB1G_(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load i64, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<[unwind::Noisy]>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxSNtCsj61JMRYXuTT_6unwind5NoisyEE6as_refB1G_(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, i64 } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, i64 } %5, i64 %_11.1, 1
  ret { ptr, i64 } %6
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csj61JMRYXuTT_6unwind(ptr %self) unnamed_addr #0 !guid !204 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32Csj61JMRYXuTT_6unwind(i8 %0) unnamed_addr #0 !guid !205 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32Csj61JMRYXuTT_6unwind(ptr %self) #21
  ret i32 %_0
}

; <alloc::vec::Vec<unwind::Noisy>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsj61JMRYXuTT_6unwind5NoisyE10as_mut_ptrBG_(ptr align 8 %self) unnamed_addr #0 !guid !206 {
start:
; call <alloc::raw_vec::RawVec<unwind::Noisy>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyE3ptrBO_(ptr align 8 %self) #21
  ret ptr %_0
}

; <alloc::vec::Vec<unwind::Noisy>>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsj61JMRYXuTT_6unwind5NoisyE17from_raw_parts_inBG_(ptr sret([24 x i8]) align 8 %_0, ptr %ptr, i64 %length, i64 %capacity) unnamed_addr #0 personality ptr @rust_eh_personality !guid !207 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsj61JMRYXuTT_6unwind(i64 %length, i64 %capacity, ptr align 8 @alloc_a4b5e9c02a3b46b6492ce6eaa610346d) #27
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_9, align 1
; call <alloc::raw_vec::RawVec<unwind::Noisy>>::from_raw_parts_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyE17from_raw_parts_inBO_(ptr %ptr, i64 %capacity) #21
  %_7.0 = extractvalue { i64, ptr } %0, 0
  %_7.1 = extractvalue { i64, ptr } %0, 1
  br label %bb3

bb3:                                              ; preds = %bb2
  store i64 %_7.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_7.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 %length, ptr %2, align 8
  ret void

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; <*mut unwind::Noisy>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsj61JMRYXuTT_6unwind5Noisy10cast_sliceBG_(ptr %self, i64 %len) unnamed_addr #0 !guid !208 {
start:
; call core::ptr::slice_from_raw_parts_mut::<unwind::Noisy>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutNtCsj61JMRYXuTT_6unwind5NoisyEBT_(ptr %self, i64 %len) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCsj61JMRYXuTT_6unwind(i64 %0, i64 %1) unnamed_addr #0 !guid !209 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCsj61JMRYXuTT_6unwind(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !210 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #28
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCsj61JMRYXuTT_6unwind(i64 %0, i64 %1) unnamed_addr #0 !guid !211 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #28
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #28
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCsj61JMRYXuTT_6unwind(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !212 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsj61JMRYXuTT_6unwind(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #21
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #24
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #21
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::type_id_eq
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCsj61JMRYXuTT_6unwind(ptr align 8 %a, ptr align 8 %b) unnamed_addr #4 !guid !213 {
start:
  %_3 = load i128, ptr %a, align 8
  %_4 = load i128, ptr %b, align 8
  %_0 = icmp eq i128 %_3, %_4
  ret i1 %_0
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCsj61JMRYXuTT_6unwind() unnamed_addr #5 !guid !214 {
start:
  ret void
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCsj61JMRYXuTT_6unwind() unnamed_addr #0 !guid !215 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsj61JMRYXuTT_6unwind() #21
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCsj61JMRYXuTT_6unwind(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !216 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCsj61JMRYXuTT_6unwind(i64 %align, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !217 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCsj61JMRYXuTT_6unwind(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !218 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCsj61JMRYXuTT_6unwind(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !219 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCsj61JMRYXuTT_6unwind(ptr @alloc_82a99021b1306c9239507412b95c0e74, i64 205)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #20
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #26
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCsj61JMRYXuTT_6unwind() unnamed_addr #0 !guid !220 {
start:
  ret i1 true
}

; <unwind::Noisy as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXCsj61JMRYXuTT_6unwindNtB2_5NoisyNtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4drop(ptr align 8 %self) unnamed_addr #1 !guid !221 {
start:
  %_7 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
; call <core::fmt::rt::Argument>::new_display::<&str>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8 %_7, ptr align 8 %self) #21
  %0 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_7, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 1>
  %1 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_88523646262c2465cd77855ffd6da4ff, ptr align 8 %args) #21
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_3.0, ptr %_3.1)
  ret void
}

; <u32 as core::any::Any>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtCsl10jNU3mE6R_4core3anymNtB2_3Any7type_idCsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %self) unnamed_addr #1 !guid !222 {
start:
; call <core::any::TypeId>::of::<u32>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofmECsj61JMRYXuTT_6unwind(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <usize as core::slice::index::SliceIndex<[u8]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexShE5indexCsj61JMRYXuTT_6unwind(i64 %self, ptr %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !223 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i8, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #25
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsj61JMRYXuTT_6unwind(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !224 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCsj61JMRYXuTT_6unwind(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #21
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCsj61JMRYXuTT_6unwind(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !225 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCsj61JMRYXuTT_6unwind(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<unwind::Noisy> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBO_(ptr align 8 %self) unnamed_addr #1 !guid !226 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCsj61JMRYXuTT_6unwind(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !227 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCsj61JMRYXuTT_6unwind(ptr align 8 %_3, ptr align 8 %f) #21
  ret i1 %_0
}

; <&str as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !228 {
start:
  %s.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %s.1 = load i64, ptr %0, align 8
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #21
  ret void
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !229 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #21
  ret void
}

; <core::any::TypeId as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCsj61JMRYXuTT_6unwind(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !230 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %self, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %other, i64 16, i1 false)
; call core::intrinsics::type_id_eq
  %_0 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCsj61JMRYXuTT_6unwind(ptr align 8 %_3, ptr align 8 %_4) #28
  ret i1 %_0
}

; <alloc::boxed::Box<[unwind::Noisy]> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxSNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #0 !guid !231 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load i64, ptr %0, align 8
; call <core::ptr::unique::Unique<[unwind::Noisy]>>::as_ptr
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueSNtCsj61JMRYXuTT_6unwind5NoisyE6as_ptrBT_(ptr %ptr.0, i64 %ptr.1) #21
  %_5.0 = extractvalue { ptr, i64 } %1, 0
  %_5.1 = extractvalue { ptr, i64 } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<[unwind::Noisy]>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawSNtCsj61JMRYXuTT_6unwind5NoisyEB17_(ptr %_5.0, i64 %_5.1) #21
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCsj61JMRYXuTT_6unwind(ptr align 8 %layout) #21
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<[unwind::Noisy]>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueSNtCsj61JMRYXuTT_6unwind5NoisyE4casthEBU_(ptr %ptr.0, i64 %ptr.1) #21
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #21
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCsj61JMRYXuTT_6unwind(ptr %_10, ptr %_11, i64 %6, i64 %8) #21
  br label %bb7
}

; <&str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !232 {
start:
; call <&str as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #21
  ret void
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !233 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #21
  ret void
}

; <core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCsj61JMRYXuTT_6unwind(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !234 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.3)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCsj61JMRYXuTT_6unwind() unnamed_addr #0 !guid !235 {
start:
  ret i8 0
}

; <alloc::vec::Vec<u8> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VechEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCsj61JMRYXuTT_6unwind(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !236 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefB7_(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[u8]>>::index
  %_0.i = call ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexShE5indexCsj61JMRYXuTT_6unwind(i64 %index, ptr %_3.0, i64 %_3.1, ptr align 8 %0) #21
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <bool as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsf_NtCsl10jNU3mE6R_4core3fmtbNtB5_5Debug3fmtCsj61JMRYXuTT_6unwind(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !237 {
start:
; call <bool as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr %self, ptr align 8 %f)
  ret i1 %_0
}

; <core::panic::unwind_safe::AssertUnwindSafe<unwind::main::{closure#2}> as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsl_NtNtCsl10jNU3mE6R_4core5panic11unwind_safeINtB5_16AssertUnwindSafeNCNvCsj61JMRYXuTT_6unwind4mains0_0EINtNtNtB9_3ops8function6FnOnceuE9call_onceB1d_() unnamed_addr #0 !guid !238 {
start:
  %_2 = alloca [0 x i8], align 1
; call <unwind::main::{closure#2} as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYNCNvCsj61JMRYXuTT_6unwind4mains0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceB6_() #21
  ret void
}

; <alloc::vec::Vec<unwind::Noisy> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecNtCsj61JMRYXuTT_6unwind5NoisyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropBH_(ptr align 8 %self) unnamed_addr #1 !guid !239 {
start:
; call <alloc::vec::Vec<unwind::Noisy>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecNtCsj61JMRYXuTT_6unwind5NoisyE10as_mut_ptrBG_(ptr align 8 %self) #21
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut unwind::Noisy>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrONtCsj61JMRYXuTT_6unwind5Noisy10cast_sliceBG_(ptr %_3, i64 %_4) #21
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
; call core::ptr::drop_glue::<[unwind::Noisy]>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueSNtCsj61JMRYXuTT_6unwind5NoisyEBE_(ptr align 8 %_2.0, i64 %_2.1)
  ret void
}

; <alloc::string::String as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !240 {
start:
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0) #21
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCsj61JMRYXuTT_6unwind(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !241 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCsj61JMRYXuTT_6unwind(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !242 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCsj61JMRYXuTT_6unwind(ptr align 8 %self) unnamed_addr #0 !guid !243 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCsj61JMRYXuTT_6unwind(ptr align 8 %self) #21
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsj61JMRYXuTT_6unwind(ptr %_1) unnamed_addr #0 !guid !244 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCsj61JMRYXuTT_6unwind(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !245 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0Csj61JMRYXuTT_6unwind(ptr align 8 %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <unwind::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNCNvCsj61JMRYXuTT_6unwind4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !246 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call unwind::main::{closure#0}
  call void @_RNCNvCsj61JMRYXuTT_6unwind4main0B3_(ptr %_1, ptr align 8 %1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <unwind::main::{closure#2} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNCNvCsj61JMRYXuTT_6unwind4mains0_0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceB6_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !247 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [0 x i8], align 1
; call unwind::main::{closure#2}
  call void @_RNCNvCsj61JMRYXuTT_6unwind4mains0_0B3_(ptr %_1) #21
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCsj61JMRYXuTT_6unwind(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !248 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <alloc::string::String as core::clone::Clone>::clone
  call void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %1)
  ret void
}

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8) unnamed_addr #1

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <core::option::Option<u32> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionmENtNtB7_3fmt5Debug3fmtCsddYV2PBJW9h_3std(ptr align 4, ptr align 8) unnamed_addr #0

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nonlazybind
define internal zeroext i1 @__rust_try(ptr %0, ptr %1, ptr %2) unnamed_addr #8 personality ptr @rust_eh_personality !guid !249 {
entry-block:
  invoke void %0(ptr %1)
          to label %then unwind label %catch

then:                                             ; preds = %entry-block
  ret i1 false

catch:                                            ; preds = %entry-block
  %3 = landingpad { ptr, i32 }
          catch ptr null
  %4 = extractvalue { ptr, i32 } %3, 0
  call void %2(ptr %1, ptr %4)
  ret i1 true
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; std::panicking::catch_unwind::cleanup
; Function Attrs: cold minsize nonlazybind optsize uwtable
declare { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr) unnamed_addr #9

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #6

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #10

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<11, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8) unnamed_addr #0

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEEBG_(ptr align 8) unnamed_addr #1

; <core::fmt::Arguments>::new::<18, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj12_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; std::panic::resume_unwind
; Function Attrs: noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std5panic13resume_unwind(ptr, ptr align 8) unnamed_addr #11

; <core::fmt::rt::Argument>::new_display::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayhEB7_(ptr sret([16 x i8]) align 8, ptr) unnamed_addr #0

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #10

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #10

; std::panicking::set_hook
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr, ptr align 8) unnamed_addr #1

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #6

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #6

; <core::fmt::Arguments>::new::<14, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKje_Kj1_ECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; std::panicking::take_hook
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook() unnamed_addr #1

; core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8) unnamed_addr #1

; <core::fmt::Arguments>::new::<17, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKj11_Kj1_ECs2d0hS33vDhg_5gimli(ptr, ptr align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #0

; core::option::expect_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6option13expect_failed(ptr, i64, ptr align 8) unnamed_addr #10

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<i32>>::new
; Function Attrs: nonlazybind uwtable
declare i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<()>>::new
; Function Attrs: nonlazybind uwtable
declare void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std() unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::from_raw_parts_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner17from_raw_parts_inB7_(ptr, i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #12

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #4

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #13

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #14

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #15

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #16

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #17

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <core::fmt::rt::Argument>::new_display::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayReEB7_(ptr sret([16 x i8]) align 8, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<10, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #18

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <alloc::vec::Vec<u8> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefB7_(ptr align 8) unnamed_addr #0

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <alloc::string::String as core::clone::Clone>::clone
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #8 !guid !250 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECsj61JMRYXuTT_6unwind(ptr @_RNvCsj61JMRYXuTT_6unwind4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nonlazybind "target-cpu"="x86-64" }
attributes #9 = { cold minsize nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #13 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { cold }
attributes #20 = { cold noreturn nounwind }
attributes #21 = { inlinehint }
attributes #22 = { cold noinline noreturn nounwind }
attributes #23 = { noinline }
attributes #24 = { noreturn }
attributes #25 = { noinline noreturn }
attributes #26 = { noinline noreturn nounwind }
attributes #27 = { inlinehint nounwind }
attributes #28 = { nounwind }

!llvm.module.flags = !{!53, !54, !55, !56}
!llvm.ident = !{!57}

!0 = !{i64 -46997948313791345}
!1 = !{i64 25788200098060345}
!2 = !{i64 9097894202144483822}
!3 = !{i64 -1937342340018060412}
!4 = !{i64 2803351903542963515}
!5 = !{i64 2237243252279070084}
!6 = !{i64 7513801262837041031}
!7 = !{i64 -9040853548866323263}
!8 = !{i64 3073539128067302049}
!9 = !{i64 8882065627796805609}
!10 = !{i64 5715730670869923177}
!11 = !{i64 -3097255471922782039}
!12 = !{i64 6476593438218903146}
!13 = !{i64 750501877259457115}
!14 = !{i64 -8410994454635278510}
!15 = !{i64 6044602955791338646}
!16 = !{i64 5477337275393488174}
!17 = !{i64 8855430625693264075}
!18 = !{i64 6237042688929350005}
!19 = !{i64 8286948434782919971}
!20 = !{i64 8159189490201776228}
!21 = !{i64 -5573732233918587288}
!22 = !{i64 -1953853819310495170}
!23 = !{i64 9022769322471430628}
!24 = !{i64 -6460411210198171804}
!25 = !{i64 -906006658164277552}
!26 = !{i64 -3304747871054666095}
!27 = !{i64 3938263861695563202}
!28 = !{i64 -8552201389972001759}
!29 = !{i64 3415514776676653820}
!30 = !{i64 -8320957451860364439}
!31 = !{i64 3573783935262181909}
!32 = !{i64 -1573582506693127581}
!33 = !{i64 -742586658062999790}
!34 = !{i64 -3150317274950825336}
!35 = !{i64 5097855652968470885}
!36 = !{i64 4693911346259883079}
!37 = !{i64 6438493609263354986}
!38 = !{i64 8040868217744969391}
!39 = !{i64 -5578600404413430813}
!40 = !{i64 9007145453274206376}
!41 = !{i64 1058910653964066435}
!42 = !{i64 -966402249997496400}
!43 = !{i64 5242366891305432469}
!44 = !{i64 5800475840393375104}
!45 = !{i64 6606951270893114267}
!46 = !{i64 -1517006067546666936}
!47 = !{i64 -2897438167078804421}
!48 = !{i64 8589057288068047256}
!49 = !{i64 -3777628700482277481}
!50 = !{i64 -2628405084503888027}
!51 = !{i64 1086313243142492600}
!52 = !{i64 -2650361182996604791}
!53 = !{i32 8, !"PIC Level", i32 2}
!54 = !{i32 7, !"PIE Level", i32 2}
!55 = !{i32 2, !"RtLibUseGOT", i32 1}
!56 = !{i32 7, !"uwtable", i32 2}
!57 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!58 = !{i64 7023548702319222261}
!59 = !{i64 -531881656306039393}
!60 = !{i64 4785105574571031474}
!61 = !{i64 -2392942903570284614}
!62 = !{i64 -4921999264155663288}
!63 = !{i64 -3296601575049424246}
!64 = !{i64 -7685350173286587147}
!65 = !{i64 -8458522585817192738}
!66 = !{i64 -6821046558852552387}
!67 = !{i64 -2324523553096144469}
!68 = !{i64 -2181024838697994936}
!69 = !{i64 -8275796664565091977}
!70 = !{i64 6068379703341016911}
!71 = !{i64 -518738937041840240}
!72 = !{i64 -3462251056832541505}
!73 = !{i64 -2033411732582076474}
!74 = !{i64 -1039089779564713687}
!75 = !{i64 3494786566929536553}
!76 = !{i64 -5341378800644088221}
!77 = !{i64 -4726744417322693753}
!78 = !{i64 4960126619592054564}
!79 = !{i64 -2439748376665454502}
!80 = !{i64 57467566325803549}
!81 = !{i64 -6545004805685653433}
!82 = !{i64 -3576601558060869464}
!83 = !{i64 -1275680866396143892}
!84 = !{i64 -6224664640947478484}
!85 = !{}
!86 = !{i64 4187878799989392275}
!87 = !{i64 -882433292433895509}
!88 = !{i64 5117644983642315563}
!89 = !{i64 2295028533068594908}
!90 = !{i64 8297098863772719673}
!91 = !{i64 5637730794429991715}
!92 = !{i64 11615993984435929}
!93 = !{i64 4965580966647725375}
!94 = !{i64 7883934866794680411}
!95 = !{i64 -493997454764294544}
!96 = !{i64 1068947975801049199}
!97 = !{i64 -1013107326609711099}
!98 = !{i64 -4549788686705438145}
!99 = !{i64 6452895775283513052}
!100 = !{i64 7318036032847176982}
!101 = !{i64 -3834828242125021224}
!102 = !{i64 -5595489235376956080}
!103 = !{i64 8632733234357566709}
!104 = !{i64 -171878807594824003}
!105 = !{i64 1071994956028566125}
!106 = !{i64 5537395914001285910}
!107 = !{i64 3013870773541151949}
!108 = !{i64 4460689490964229601}
!109 = !{i64 1906199493168831737}
!110 = !{i64 8897791604366554957}
!111 = !{i64 6912472538816894139}
!112 = !{i64 -2013958386842646913}
!113 = !{i64 964386977547016645}
!114 = !{i64 -5775077004378984915}
!115 = !{i64 -2029530961329380500}
!116 = !{i64 7272552159893046}
!117 = !{i64 2595431406214894466}
!118 = !{i64 -2051078527316764863}
!119 = !{i64 5717360595067241253}
!120 = !{i64 3169983078121563004}
!121 = !{i64 -3356572237261674117}
!122 = !{i64 -1778535198784739726}
!123 = !{i64 2885546803949749605}
!124 = !{i64 -939347771391540111}
!125 = !{i64 -2711000338865583535}
!126 = !{i64 -4614375422743623090}
!127 = !{i64 -8767980489127399917}
!128 = !{i64 4065674698670099945}
!129 = !{i64 6091087561605134293}
!130 = !{i64 -3347084429214993037}
!131 = !{i64 8031937318387492587}
!132 = !{i64 2225085444472503253}
!133 = !{i64 6156871347376519777}
!134 = !{i64 -2981900149610824906}
!135 = !{i64 4250406016120512617}
!136 = !{i64 -6002625856935831694}
!137 = !{i64 -5573752844520059538}
!138 = !{i64 4262121075296452980}
!139 = !{i64 -2969243860849169377}
!140 = !{i64 2080074959201274588}
!141 = !{i64 -1010221574337769992}
!142 = !{i64 -5037077667718887832}
!143 = !{i64 -1653880629708179304}
!144 = !{!"address", !"read_provenance"}
!145 = !{i64 3572344929449874007}
!146 = !{i64 1679570524464819461}
!147 = !{i64 1972899464632930629}
!148 = !{i64 1195258934373199157}
!149 = !{i64 -6544011068013524680}
!150 = !{i64 -4929638444971229519}
!151 = !{i64 7655115883257683502}
!152 = !{i64 1198116908226035232}
!153 = !{i64 9217348938474593215}
!154 = !{i64 -5180519459133059938}
!155 = !{i64 5905033416250492674}
!156 = !{i64 3577065868728385588}
!157 = !{i64 4609561583050964194}
!158 = !{i64 -5898563382191083856}
!159 = !{i64 5685473636548659871}
!160 = !{i64 -1983506358410569769}
!161 = !{i64 -7378091768690927498}
!162 = !{i64 1897438907734765248}
!163 = !{i64 -8680409505359379649}
!164 = !{i64 7196130926803854910}
!165 = !{i64 -4109755186550774506}
!166 = !{i64 -6962893036044812739}
!167 = !{i64 -3615558887818013180}
!168 = !{i64 169835604785446194}
!169 = !{i64 -8477643349101799590}
!170 = !{i64 4362669388234661833}
!171 = !{i64 -8927464062389080014}
!172 = !{i64 -8758297214577667608}
!173 = !{i64 4597458451775448928}
!174 = !{i64 -507505213710526852}
!175 = !{i64 -2375777125383894724}
!176 = !{i64 -5457838972365119729}
!177 = !{i64 -4887338828625697092}
!178 = !{i64 -6039982225966711707}
!179 = !{i64 -5579205219611553027}
!180 = !{i64 -7263153827905218860}
!181 = !{i64 7903886593814662449}
!182 = !{i64 9019521140501357229}
!183 = !{i64 3230371950830112160}
!184 = !{i64 67544252025066805}
!185 = !{i64 -7236469522679317378}
!186 = !{i64 -4967506726653512898}
!187 = !{i64 2309124602159114378}
!188 = !{i64 1389080820400396864}
!189 = !{i64 8359173768618879323}
!190 = !{i64 4284175005976489874}
!191 = !{i64 -4530544011851097058}
!192 = !{i64 580027383581805373}
!193 = !{i64 4483702997740033697}
!194 = !{i64 -1404412160599368745}
!195 = !{i64 3025973972477838150}
!196 = !{i64 3204957754455324564}
!197 = !{i64 -3555350369073939805}
!198 = !{i64 -2745318183748636811}
!199 = !{i64 -4111823575633121463}
!200 = !{i64 1673051659469401160}
!201 = !{i64 -3036649844380987997}
!202 = !{i64 4392112868510214690}
!203 = !{i64 -1420609587330846714}
!204 = !{i64 3535161258375386116}
!205 = !{i64 -8315292463441952805}
!206 = !{i64 -8244286634172289296}
!207 = !{i64 1382035183592853144}
!208 = !{i64 -4575921144177855514}
!209 = !{i64 -8878844463946632887}
!210 = !{i64 4940666474604113535}
!211 = !{i64 7166043214258924584}
!212 = !{i64 3318661738481319789}
!213 = !{i64 -8866953841867248691}
!214 = !{i64 -724166438064429401}
!215 = !{i64 -7767806222439068091}
!216 = !{i64 8812146767796777852}
!217 = !{i64 -372385085587535475}
!218 = !{i64 -3934748311880270058}
!219 = !{i64 -8685453576482836310}
!220 = !{i64 -730432179678809565}
!221 = !{i64 3967480922327723482}
!222 = !{i64 -5861609853910821451}
!223 = !{i64 -1226309751627289687}
!224 = !{i64 -2943637024259081680}
!225 = !{i64 -892966620789907228}
!226 = !{i64 -2099978545410729009}
!227 = !{i64 -217909079383780795}
!228 = !{i64 6703074244643795057}
!229 = !{i64 -5193483442656551560}
!230 = !{i64 -9167326877320100973}
!231 = !{i64 4725715884761456558}
!232 = !{i64 5885079298074879546}
!233 = !{i64 -7709281265378594548}
!234 = !{i64 4573416091382488010}
!235 = !{i64 4889224201700585908}
!236 = !{i64 -2918979142801786628}
!237 = !{i64 -8581689077457298745}
!238 = !{i64 7252006362433926055}
!239 = !{i64 -3110969696375146213}
!240 = !{i64 7044029389274114963}
!241 = !{i64 7880329999077289534}
!242 = !{i64 2961951442178952414}
!243 = !{i64 -5234167759827731165}
!244 = !{i64 2227755928174156227}
!245 = !{i64 5442134326757287376}
!246 = !{i64 5979876915698526641}
!247 = !{i64 3394146764950021160}
!248 = !{i64 -5758914929317213520}
!249 = !{i64 -4243069127258217452}
!250 = !{i64 -2624081020897602054}
