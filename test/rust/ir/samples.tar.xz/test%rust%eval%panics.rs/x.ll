; ModuleID = 'panics.aafd8ccfe9a8bfaa-cgu.0'
source_filename = "panics.aafd8ccfe9a8bfaa-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@anon.fc6ebcf9488fce9791a3e964855a907f.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -2724188134956199339 to ptr), ptr inttoptr (i64 -7993673810352186047 to ptr) }>, align 8, !guid !4
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseGb2pkncjeE_6panics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics }>, align 8, !guid !5
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs_NvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB4_7PayloadyENtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics, ptr @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload8take_boxCseGb2pkncjeE_6panics, ptr @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload3getCseGb2pkncjeE_6panics, ptr @_RNvYINtNvNtCsddYV2PBJW9h_3std9panicking11begin_panic7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload6as_strCseGb2pkncjeE_6panics }>, align 8, !guid !6
@alloc_6c342f467cee9eb46aaa013cf1ccd49c = private unnamed_addr constant [5 x i8] c"inner", align 1, !guid !7
@alloc_93aca317a13a136ecbfa0dc0ccaaa44a = private unnamed_addr constant [25 x i8] c"test/rust/eval/panics.rs\00", align 1, !guid !8
@alloc_1378573dc70dc7b629a9d6b1d49c46c0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\14\00\00\00C\00\00\00" }>, align 8, !guid !9
@alloc_bc2728ce27cec9f60e0626ade65acb4b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\11\00\00\00K\00\00\00" }>, align 8, !guid !10
@alloc_0aeb6e895488c55d15573141e7b7a3c2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\13\00\00\00E\00\00\00" }>, align 8, !guid !11
@alloc_02b558d5b27198b9b90fbafced75e0cf = private unnamed_addr constant [11 x i8] c"\06hook: \C0\01\0A\00", align 1, !guid !12
@alloc_26337d6526588881851e4b9aa79dd1e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\0E\00\00\00;\00\00\00" }>, align 8, !guid !13
@alloc_12d2d02b2e0c041f3e841225de325fca = private unnamed_addr constant [10 x i8] c"\07custom \C0\00", align 1, !guid !14
@alloc_e2740e3908ad36560b71cc9f5b200537 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\10\00\00\00-\00\00\00" }>, align 8, !guid !15
@alloc_ed9180a32b8d1532dfca976b688cc762 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\12\00\00\003\00\00\00" }>, align 8, !guid !16
@alloc_3aadfb4415466f9ec9f9a3c5fbb426c4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00[\00\00\00" }>, align 8, !guid !17
@alloc_d43dd53cfe4b9b827fd912a6e62abe23 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00V\00\00\00" }>, align 8, !guid !18
@alloc_6a689db22d1294a68a0bad4756950543 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00E\00\00\00" }>, align 8, !guid !19
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_, ptr @_RNCNvCseGb2pkncjeE_6panics4main0B3_, ptr @_RNCNvCseGb2pkncjeE_6panics4main0B3_ }>, align 8, !guid !20
@alloc_448fb98007976f236e6e677ba877f9b6 = private unnamed_addr constant [11 x i8] c"\06deep: \C0\01\0A\00", align 1, !guid !21
@alloc_3c431bcb3e5b1a19bfdfd590efb9375c = private unnamed_addr constant [15 x i8] c"\0Aoverflow: \C0\01\0A\00", align 1, !guid !22
@alloc_3d7fb2aa6ae966f1e7013d6c153d46dc = private unnamed_addr constant [13 x i8] c"\08custom: \C0\01\0A\00", align 1, !guid !23
@alloc_b3985d69dd852d2586fba6caf63ad04a = private unnamed_addr constant [10 x i8] c"\05any: \C0\01\0A\00", align 1, !guid !24
@alloc_6c16facbf882c3c5f712b5f99d829949 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\14\00\00\00`\00\00\00" }>, align 8, !guid !25
@alloc_71d9bbd0f6c53403bb664fdb9799afa5 = private unnamed_addr constant [13 x i8] c"\08nested: \C0\01\0A\00", align 1, !guid !26
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !27
@vtable.3 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std, [16 x i8] c"\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtBM_3fmt5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !28
@alloc_04af5354bae90239a24027527d4c463d = private unnamed_addr constant [30 x i8] c"core/src/mem/manually_drop.rs\00", align 1, !guid !29
@alloc_622d398601f4d17fcdc4667dab4c4cb4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\CB\00\00\000\00\00\00" }>, align 8, !guid !30
@alloc_d9607be26b1182115ab3c853f5787a76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\E4\00\00\00\12\00\00\00" }>, align 8, !guid !31
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !32
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !33
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !34
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !35
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !36
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !37
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !38
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !39
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !40
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXNtCsl10jNU3mE6R_4core3anyyNtB2_3Any7type_idCseGb2pkncjeE_6panics }>, align 8, !guid !41
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !42
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !43
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !44
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_ }>, align 8, !guid !45
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !46
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_ }>, align 8, !guid !47
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !48
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !49
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std }>, align 8, !guid !50
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRuNtB6_5Debug3fmtCshGsV4pNJ6ra_6object }>, align 8, !guid !51
@vtable.b = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionyENtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !52

; <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !58 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
  call void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#0}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4main00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !59 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#0}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4main00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#7}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4mains5_00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !60 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#7}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4mains5_00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u8>>::map::<i32, panics::main::{closure#6}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE3maplNCNvCseGb2pkncjeE_6panics4mains4_0EBT_(i1 zeroext %0, i8 %1) unnamed_addr #0 !guid !61 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %self = alloca [2 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %self, align 1
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %3, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %4 = load i8, ptr %self, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %self, i64 1
  %7 = load i8, ptr %6, align 1
  %_3 = zext i1 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %self, i64 1
  %x = load i8, ptr %9, align 1
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#6}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains4_0B3_(i8 %x) #24
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %11 = load i8, ptr %_8, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %13 = load i32, ptr %_0, align 4
  %14 = getelementptr inbounds i8, ptr %_0, i64 4
  %15 = load i32, ptr %14, align 4
  %16 = insertvalue { i32, i32 } poison, i32 %13, 0
  %17 = insertvalue { i32, i32 } %16, i32 %15, 1
  ret { i32, i32 } %17

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<alloc::boxed::Box<alloc::string::String>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<alloc::string::String, panics::main::{closure#8}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxNtNtBN_6string6StringEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapB1h_NCNCNvCseGb2pkncjeE_6panics4mains6_00EB2z_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !62 {
start:
  %_9 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %e.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store ptr %e.1, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load ptr, ptr %7, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#8}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4mains6_00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %t) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_9, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<alloc::boxed::Box<u64>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<u64, panics::main::{closure#9}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxyEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapyNCNCNvCseGb2pkncjeE_6panics4mains7_00EB2c_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !63 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store ptr %e.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %e.1, ptr %5, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load ptr, ptr %6, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#9}::{closure#0}
  %_5 = call i64 @_RNCNCNvCseGb2pkncjeE_6panics4mains7_00B5_(ptr align 8 %t) #24
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %7, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_9, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#7}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains5_0EB2Q_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !64 {
start:
  %_9 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#7}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains5_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr %e.0, ptr align 8 %e.1) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i8, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %t, ptr %6, align 8
  store i64 -2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#8}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains6_0EB2Q_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !65 {
start:
  %_9 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#8}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains6_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr %e.0, ptr align 8 %e.1) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i32, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %t, ptr %6, align 8
  store i64 -2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<u64>, panics::main::{closure#9}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionyENCNvCseGb2pkncjeE_6panics4mains7_0EB2w_(ptr %0, ptr %1) unnamed_addr #0 !guid !66 {
start:
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#9}
  %10 = call { i64, i64 } @_RNCNvCseGb2pkncjeE_6panics4mains7_0B3_(ptr %e.0, ptr align 8 %e.1) #24
  %_6.0 = extractvalue { i64, i64 } %10, 0
  %_6.1 = extractvalue { i64, i64 } %10, 1
  store i64 %_6.0, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %11, align 8
  br label %bb7

bb3:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %12 = load i8, ptr %_9, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %14 = load i64, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  %16 = load i64, ptr %15, align 8
  %17 = insertvalue { i64, i64 } poison, i64 %14, 0
  %18 = insertvalue { i64, i64 } %17, i64 %16, 1
  ret { i64, i64 } %18

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !67 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECseGb2pkncjeE_6panics(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !68 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseGb2pkncjeE_6panics(ptr %x) #24
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseGb2pkncjeE_6panics(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !69 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !70 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<(), core::option::Option<u64>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultuINtNtB7_6option6OptionyEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !71 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultuINtNtB9_6option6OptionyEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #24
; call <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultuINtNtBa_6option6OptionyEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #24
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtB7_6option6OptionyEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !72 {
start:
; call core::mem::align_of_val_raw::<alloc::string::String>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #24
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !73 {
start:
; call core::mem::align_of_val_raw::<u64>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #24
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofmECseGb2pkncjeE_6panics() unnamed_addr #0 !guid !74 {
start:
  ret i64 4
}

; <core::alloc::layout::Layout>::for_value_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !75 {
start:
; call core::mem::size_of_val_raw::<alloc::string::String>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::mem::alignment::Alignment>::of_val_raw::<alloc::string::String>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !76 {
start:
; call core::mem::size_of_val_raw::<u64>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::mem::alignment::Alignment>::of_val_raw::<u64>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #24
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<alloc::string::String>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !77 {
start:
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castmECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !78 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castmECseGb2pkncjeE_6panics(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u64>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueyE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !79 {
start:
; call <core::ptr::non_null::NonNull<u64>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4casthECseGb2pkncjeE_6panics(ptr %self) #24
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !80 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !81 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultuINtNtBa_6option6OptionyEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !82 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !83 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !84 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !85 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castmECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !86 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u64>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !87 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrmECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !88 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u32>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullmECseGb2pkncjeE_6panics(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullmECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !89 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castmECseGb2pkncjeE_6panics(ptr %_3) #24
; call <core::ptr::unique::Unique<u32>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquemE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %_2) #24
  ret ptr %_0
}

; <dyn core::any::Any>::is::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !90 {
start:
  %concrete = alloca [16 x i8], align 8
  %t = alloca [16 x i8], align 8
; call <core::any::TypeId>::of::<u64>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %t)
  %0 = getelementptr inbounds i8, ptr %self.1, i64 24
  %1 = load ptr, ptr %0, align 8, !invariant.load !91, !nonnull !91
  call void %1(ptr sret([16 x i8]) align 8 %concrete, ptr %self.0) #24
; call <core::any::TypeId as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %t, ptr align 8 %concrete) #24
  ret i1 %_0
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !92 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !93 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <dyn core::any::Any + core::marker::Send>::is::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !94 {
start:
; call <dyn core::any::Any>::is::<alloc::string::String>
  %_0 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr %self.0, ptr align 8 %self.1) #24
  ret i1 %_0
}

; <dyn core::any::Any + core::marker::Send>::is::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !95 {
start:
; call <dyn core::any::Any>::is::<u64>
  %_0 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #24
  ret i1 %_0
}

; <core::any::TypeId>::of::<u64>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !96 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.fc6ebcf9488fce9791a3e964855a907f.0, i64 16, i1 false)
  ret void
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !97 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
  %5 = invoke { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; invoke <alloc::boxed::Box<alloc::string::String>>::from_raw_in
  %_0 = invoke align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringE11from_raw_inCseGb2pkncjeE_6panics(ptr %_4.0)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret ptr %_0

bb3:                                              ; preds = %bb4, %bb5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %2, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %self) #25
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedyECseGb2pkncjeE_6panics(ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !98 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
  %5 = invoke { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; invoke <alloc::boxed::Box<u64>>::from_raw_in
  %_0 = invoke align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyE11from_raw_inCseGb2pkncjeE_6panics(ptr %_4.0)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret ptr %_0

bb3:                                              ; preds = %bb4, %bb5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %2, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %self) #25
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !99 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %_8.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::is::<alloc::string::String>
  %_2 = invoke zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %_8.0, ptr align 8 %_8.1)
          to label %bb1 unwind label %cleanup

bb8:                                              ; preds = %cleanup
  %5 = load i8, ptr %_7, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb7, label %bb6

cleanup:                                          ; preds = %bb2, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_6.0 = load ptr, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %_6.1 = load ptr, ptr %11, align 8
  store ptr %_6.0, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_6.1, ptr %12, align 8
  br label %bb5

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %13, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<alloc::string::String>
  %_4 = invoke align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb3 unwind label %cleanup

bb5:                                              ; preds = %bb3, %bb4
  ret void

bb3:                                              ; preds = %bb2
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_4, ptr %14, align 8
  store ptr null, ptr %_0, align 8
  br label %bb5

bb6:                                              ; preds = %bb7, %bb8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb7:                                              ; preds = %bb8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %self) #25
          to label %bb6 unwind label %terminate

terminate:                                        ; preds = %bb7
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !100 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %_8.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::is::<u64>
  %_2 = invoke zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isyECseGb2pkncjeE_6panics(ptr %_8.0, ptr align 8 %_8.1)
          to label %bb1 unwind label %cleanup

bb8:                                              ; preds = %cleanup
  %5 = load i8, ptr %_7, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb7, label %bb6

cleanup:                                          ; preds = %bb2, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_6.0 = load ptr, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %_6.1 = load ptr, ptr %11, align 8
  store ptr %_6.0, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_6.1, ptr %12, align 8
  br label %bb5

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %13, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<u64>
  %_4 = invoke align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedyECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb3 unwind label %cleanup

bb5:                                              ; preds = %bb3, %bb4
  ret void

bb3:                                              ; preds = %bb2
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_4, ptr %14, align 8
  store ptr null, ptr %_0, align 8
  br label %bb5

bb6:                                              ; preds = %bb7, %bb8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb7:                                              ; preds = %bb8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %self) #25
          to label %bb6 unwind label %terminate

terminate:                                        ; preds = %bb7
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseGb2pkncjeE_6panics(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !101 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; std::panic::catch_unwind::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCseGb2pkncjeE_6panics4mains3_00hEBM_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !102 {
start:
; call std::panicking::catch_unwind::<u8, panics::main::{closure#5}::{closure#0}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNCNvCseGb2pkncjeE_6panics4mains3_00EBR_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#2}, u8>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains0_0hEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !103 {
start:
; call std::panicking::catch_unwind::<u8, panics::main::{closure#2}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNvCseGb2pkncjeE_6panics4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#3}, i32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains1_0lEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !104 {
start:
; call std::panicking::catch_unwind::<i32, panics::main::{closure#3}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCseGb2pkncjeE_6panics4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#4}, ()>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains2_0uEBK_() unnamed_addr #1 !guid !105 {
start:
; call std::panicking::catch_unwind::<(), panics::main::{closure#4}>
  %0 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCseGb2pkncjeE_6panics4mains2_0EBP_()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::panic::catch_unwind::<panics::main::{closure#5}, bool>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains3_0bEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !106 {
start:
; call std::panicking::catch_unwind::<bool, panics::main::{closure#5}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindbNCNvCseGb2pkncjeE_6panics4mains3_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#1}, u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains_0mEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !107 {
start:
; call std::panicking::catch_unwind::<u32, panics::main::{closure#1}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCseGb2pkncjeE_6panics4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::panic_any::<u64>
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic9panic_anyyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) unnamed_addr #2 !guid !108 {
start:
; call std::panicking::begin_panic::<u64>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) #27
  unreachable
}

; std::panicking::begin_panic::<u64>
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !109 {
start:
  %_4 = alloca [1 x i8], align 1
  store i8 0, ptr %_4, align 1
  store i8 1, ptr %_4, align 1
; call <core::panic::location::Location>::caller
  %loc = call align 8 ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core5panic8locationNtB5_8Location6callerCseGb2pkncjeE_6panics(ptr align 8 %0) #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_4, align 1
; call std::sys::backtrace::__rust_end_short_backtrace::<std::panicking::begin_panic<u64>::{closure#0}, !>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace26___rust_end_short_backtraceNCINvNtB6_9panicking11begin_panicyE0zECseGb2pkncjeE_6panics(ptr align 8 %loc, i64 %msg) #27
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::panicking::catch_unwind::<bool, panics::main::{closure#5}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindbNCNvCseGb2pkncjeE_6panics4mains3_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !110 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains3_0bEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains3_0bEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %0 = load i8, ptr %data, align 8
  %_11 = trunc nuw i8 %0 to i1
  store i8 %0, ptr %slot.i1, align 1
  %1 = load i8, ptr %slot.i1, align 1
  %_0.i.i = trunc nuw i8 %1 to i1
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = zext i1 %_0.i.i to i8
  store i8 %3, ptr %2, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %4 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %4, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %5 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %5, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %6 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %6, align 8
  %7 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %8 = insertvalue { ptr, ptr } %7, ptr %_0.1.i.i, 1
  %9 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %10 = insertvalue { ptr, ptr } %9, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %10, 0
  %_0.1.i = extractvalue { ptr, ptr } %10, 1
  %_8.0 = extractvalue { ptr, ptr } %10, 0
  %_8.1 = extractvalue { ptr, ptr } %10, 1
  store ptr %_8.0, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %11, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u8, panics::main::{closure#5}::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNCNvCseGb2pkncjeE_6panics4mains3_00EBR_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !111 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E3newB1a_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB10_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB11_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i8, ptr %data, align 8
  store i8 %_11, ptr %slot.i1, align 1
  %_0.i.i = load i8, ptr %slot.i1, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u8, panics::main::{closure#2}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNvCseGb2pkncjeE_6panics4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !112 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains0_0hEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains0_0hEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i8, ptr %data, align 8
  store i8 %_11, ptr %slot.i1, align 1
  %_0.i.i = load i8, ptr %slot.i1, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<i32, panics::main::{closure#3}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCseGb2pkncjeE_6panics4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !113 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains1_0lEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains1_0lEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u32, panics::main::{closure#1}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCseGb2pkncjeE_6panics4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !114 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains_0mEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains_0mEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<(), panics::main::{closure#4}>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCseGb2pkncjeE_6panics4mains2_0EBP_() unnamed_addr #1 !guid !115 {
start:
  %slot.i1 = alloca [0 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains2_0uEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains2_0uEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %0 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %0, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %1 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %1, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %2, align 8
  %3 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_0.1.i.i, 1
  %5 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %6, 0
  %_0.1.i = extractvalue { ptr, ptr } %6, 1
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load ptr, ptr %9, align 8
  %11 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %12 = insertvalue { ptr, ptr } %11, ptr %10, 1
  ret { ptr, ptr } %12
}

; core::mem::size_of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !116 {
start:
  ret i64 24
}

; core::mem::size_of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !117 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !118 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !119 {
start:
  ret i64 8
}

; core::mem::replace::<core::option::Option<u64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionyEECseGb2pkncjeE_6panics(ptr align 8 %dest, i64 %src.0, i64 %src.1) unnamed_addr #0 !guid !120 {
start:
  %result.0 = load i64, ptr %dest, align 8
  %0 = getelementptr inbounds i8, ptr %dest, i64 8
  %result.1 = load i64, ptr %0, align 8
  store i64 %src.0, ptr %dest, align 8
  %1 = getelementptr inbounds i8, ptr %dest, i64 8
  store i64 %src.1, ptr %1, align 8
  %2 = insertvalue { i64, i64 } poison, i64 %result.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %result.1, 1
  ret { i64, i64 } %3
}

; core::ptr::slice_from_raw_parts_mut::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutmECseGb2pkncjeE_6panics(ptr %data, i64 %len) unnamed_addr #0 !guid !121 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u32], u32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSmmECseGb2pkncjeE_6panics(ptr %data, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtB11_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !122 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_1)
  br label %bb1

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %3)
  br label %bb1

bb1:                                              ; preds = %bb3, %bb2
  ret void
}

; core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !123 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -2
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !124 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !125 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -2
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !126 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !127 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<u32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !128 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u32> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) #25
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<u64>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxyEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !129 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #24
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #25
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb2:                                              ; preds = %bb4
  %2 = load ptr, ptr %0, align 8
  %3 = getelementptr inbounds i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !130 {
start:
; call <alloc::raw_vec::RawVec<u32> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECseGb2pkncjeE_6panics(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !131 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 %dummy) unnamed_addr #0 !guid !133 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECseGb2pkncjeE_6panics(i64 %dummy) unnamed_addr #0 !guid !134 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseGb2pkncjeE_6panics(i32 %dummy) unnamed_addr #0 !guid !135 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseGb2pkncjeE_6panics(i32 %dummy) unnamed_addr #0 !guid !136 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECseGb2pkncjeE_6panics(i64 %dummy) unnamed_addr #0 !guid !137 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !132
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_end_short_backtrace::<std::panicking::begin_panic<u64>::{closure#0}, !>
; Function Attrs: noinline noreturn nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace26___rust_end_short_backtraceNCINvNtB6_9panicking11begin_panicyE0zECseGb2pkncjeE_6panics(ptr align 8 %f.0, i64 %f.1) unnamed_addr #4 personality ptr @rust_eh_personality !guid !138 {
start:
; call std::panicking::begin_panic::<u64>::{closure#0}
  call void @_RNCINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyE0CseGb2pkncjeE_6panics(ptr align 8 %f.0, i64 %f.1) #28
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #24
  br label %bb2

bb2:                                              ; preds = %start
  call void @llvm.trap()
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseGb2pkncjeE_6panics(ptr %f) unnamed_addr #5 personality ptr @rust_eh_personality !guid !139 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %f) #24
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() #24
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[u32], u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSmmECseGb2pkncjeE_6panics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !140 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB10_(ptr %data) unnamed_addr #0 !guid !141 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}::{closure#0}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCseGb2pkncjeE_6panics4mains3_00E4takeB18_(ptr %data) #24
; call panics::main::{closure#5}::{closure#0}
  %_5 = call i8 @_RNCNCNvCseGb2pkncjeE_6panics4mains3_00B5_() #24
; call <core::mem::maybe_dangling::MaybeDangling<u8>>::new
  %_2.i = call i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newB6_(i8 %_5)
  store i8 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#2}, u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains0_0hEBY_(ptr %data) unnamed_addr #0 !guid !142 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#2}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains0_0E4takeB16_(ptr %data) #24
; call panics::main::{closure#2}
  %_5 = call i8 @_RNCNvCseGb2pkncjeE_6panics4mains0_0B3_() #24
; call <core::mem::maybe_dangling::MaybeDangling<u8>>::new
  %_2.i = call i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newB6_(i8 %_5)
  store i8 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#3}, i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains1_0lEBY_(ptr %data) unnamed_addr #0 !guid !143 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#3}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains1_0E4takeB16_(ptr %data) #24
; call panics::main::{closure#3}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains1_0B3_() #24
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#4}, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains2_0uEBY_(ptr %data) unnamed_addr #0 !guid !144 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#4}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains2_0E4takeB16_(ptr %data) #24
; call panics::main::{closure#4}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains2_0B3_() #24
; call <core::mem::maybe_dangling::MaybeDangling<()>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std()
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#5}, bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains3_0bEBY_(ptr %data) unnamed_addr #0 !guid !145 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains3_0E4takeB16_(ptr %data) #24
; call panics::main::{closure#5}
  %_5 = call zeroext i1 @_RNCNvCseGb2pkncjeE_6panics4mains3_0B3_() #24
; call <core::mem::maybe_dangling::MaybeDangling<bool>>::new
  %_2.i = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingbE3newCseGb2pkncjeE_6panics(i1 zeroext %_5)
  %0 = zext i1 %_2.i to i8
  store i8 %0, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#1}, u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains_0mEBY_(ptr %data) unnamed_addr #0 !guid !146 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#1}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains_0E4takeB16_(ptr %data) #24
; call panics::main::{closure#1}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains_0B3_() #24
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCseGb2pkncjeE_6panics(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB11_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !147 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#2}, u8>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains0_0hEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !148 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#3}, i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains1_0lEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !149 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#4}, ()>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains2_0uEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !150 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#5}, bool>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains3_0bEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !151 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#1}, u32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains_0mEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !152 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #29
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #0 !guid !153 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseGb2pkncjeE_6panics(ptr %_4) #30
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseGb2pkncjeE_6panics() #24
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseGb2pkncjeE_6panics(i8 %_2) #24
  ret i32 %_0
}

; std::panicking::begin_panic::<u64>::{closure#0}
; Function Attrs: inlinehint minsize noreturn nonlazybind optsize uwtable
define internal void @_RNCINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyE0CseGb2pkncjeE_6panics(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #7 personality ptr @rust_eh_personality !guid !154 {
start:
  %_4 = alloca [16 x i8], align 8
  store i64 1, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_1.1, ptr %0, align 8
; call std::panicking::panic_with_hook
  call void @_RNvNtCsddYV2PBJW9h_3std9panicking15panic_with_hook(ptr %_4, ptr align 8 @vtable.1, ptr align 8 %_1.0, i1 zeroext true, i1 zeroext false) #31
  unreachable

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; panics::main::{closure#0}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4main00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) unnamed_addr #0 !guid !155 {
start:
; call <&str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) #24
  ret void
}

; panics::main::{closure#5}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNCNvCseGb2pkncjeE_6panics4mains3_00B5_() unnamed_addr #0 !guid !156 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_6c342f467cee9eb46aaa013cf1ccd49c, i64 5) #24
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_3.0, ptr %_3.1, ptr align 8 @alloc_1378573dc70dc7b629a9d6b1d49c46c0) #27
  unreachable
}

; panics::main::{closure#7}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4mains5_00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) unnamed_addr #0 !guid !157 {
start:
; call <&str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) #24
  ret void
}

; panics::main::{closure#8}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4mains6_00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !158 {
start:
  %s = alloca [8 x i8], align 8
  store ptr %0, ptr %s, align 8
  %_5 = load ptr, ptr %s, align 8
  %_7 = ptrtoint ptr %_5 to i64
  %_9 = and i64 %_7, 7
  %_10 = icmp eq i64 %_9, 0
  br i1 %_10, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_12 = ptrtoint ptr %_5 to i64
  %_14 = icmp eq i64 %_12, 0
  %_15 = and i1 %_14, true
  %_16 = xor i1 %_15, true
  br i1 %_16, label %bb3, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_7, ptr align 8 @alloc_bc2728ce27cec9f60e0626ade65acb4b) #32
  unreachable

bb3:                                              ; preds = %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
; call <alloc::boxed::Box<alloc::string::String> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %s) #24
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_bc2728ce27cec9f60e0626ade65acb4b) #32
  unreachable
}

; panics::main::{closure#9}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNCNvCseGb2pkncjeE_6panics4mains7_00B5_(ptr align 8 %0) unnamed_addr #0 !guid !159 {
start:
  %v = alloca [8 x i8], align 8
  store ptr %0, ptr %v, align 8
  %_3 = load ptr, ptr %v, align 8
  %_5 = ptrtoint ptr %_3 to i64
  %_7 = and i64 %_5, 7
  %_8 = icmp eq i64 %_7, 0
  br i1 %_8, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_10 = ptrtoint ptr %_3 to i64
  %_12 = icmp eq i64 %_10, 0
  %_13 = and i1 %_12, true
  %_14 = xor i1 %_13, true
  br i1 %_14, label %bb3, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_5, ptr align 8 @alloc_0aeb6e895488c55d15573141e7b7a3c2) #32
  unreachable

bb3:                                              ; preds = %bb2
  %_0 = load i64, ptr %_3, align 8
; call core::ptr::drop_glue::<alloc::boxed::Box<u64>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxyEECseGb2pkncjeE_6panics(ptr align 8 %v)
  ret i64 %_0

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_0aeb6e895488c55d15573141e7b7a3c2) #32
  unreachable
}

; panics::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4main0B3_(ptr %_1, ptr align 8 %i) unnamed_addr #0 personality ptr @rust_eh_personality !guid !160 {
start:
  %0 = alloca [16 x i8], align 8
  %_20 = alloca [1 x i8], align 1
  %_16 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %_9 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  store i8 0, ptr %_20, align 1
; call <std::panic::PanicHookInfo>::payload
  %1 = call { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %i) #24
  %_11.0 = extractvalue { ptr, ptr } %1, 0
  %_11.1 = extractvalue { ptr, ptr } %1, 1
; call <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
  %_10 = call align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECsddYV2PBJW9h_3std(ptr %_11.0, ptr align 8 %_11.1) #24
  store i8 1, ptr %_20, align 1
; call <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#0}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4main00EB1y_(ptr sret([24 x i8]) align 8 %_9, ptr align 8 %_10) #24
; invoke <std::panic::PanicHookInfo>::payload
  %2 = invoke { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %i)
          to label %bb4 unwind label %cleanup

bb16:                                             ; preds = %cleanup
  %3 = load i8, ptr %_20, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb15, label %bb14

cleanup:                                          ; preds = %bb6, %bb5, %bb4, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb16

bb4:                                              ; preds = %start
  %_14.0 = extractvalue { ptr, ptr } %2, 0
  %_14.1 = extractvalue { ptr, ptr } %2, 1
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
  %_13 = invoke align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr %_14.0, ptr align 8 %_14.1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke <core::option::Option<&alloc::string::String>>::cloned
  invoke void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_12, ptr align 8 %_13)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  store i8 0, ptr %_20, align 1
; invoke <core::option::Option<alloc::string::String>>::or
  invoke void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE2orCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_8, ptr align 8 %_9, ptr align 8 %_12)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_20, align 1
; call <core::option::Option<alloc::string::String>>::unwrap_or_default
  call void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_7, ptr align 8 %_8) #24
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %_7)
          to label %bb9 unwind label %cleanup1

bb13:                                             ; preds = %cleanup1
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_7) #25
          to label %bb14 unwind label %terminate

cleanup1:                                         ; preds = %bb10, %bb9, %bb7
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb13

bb9:                                              ; preds = %bb7
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_16, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %14 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_02b558d5b27198b9b90fbafced75e0cf, ptr align 8 %args)
          to label %bb10 unwind label %cleanup1

bb10:                                             ; preds = %bb9
  %_4.0 = extractvalue { ptr, ptr } %14, 0
  %_4.1 = extractvalue { ptr, ptr } %14, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
          to label %bb11 unwind label %cleanup1

bb11:                                             ; preds = %bb10
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8 %_7)
  ret void

terminate:                                        ; preds = %bb15, %bb13
  %15 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb14:                                             ; preds = %bb15, %bb16, %bb13
  %16 = load ptr, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  %18 = load i32, ptr %17, align 8
  %19 = insertvalue { ptr, i32 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i32 } %19, i32 %18, 1
  resume { ptr, i32 } %20

bb15:                                             ; preds = %bb16
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %_9) #25
          to label %bb14 unwind label %terminate
}

; panics::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNvCseGb2pkncjeE_6panics4mains0_0B3_() unnamed_addr #0 !guid !161 {
start:
; call core::hint::black_box::<u8>
  %x = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 -6) #24
; call core::hint::black_box::<u8>
  %_3 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 10) #24
  %_4.0 = add i8 %x, %_3
  %_4.1 = icmp ult i8 %_4.0, %x
  br i1 %_4.1, label %panic, label %bb3

bb3:                                              ; preds = %start
  ret i8 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_26337d6526588881851e4b9aa79dd1e0) #27
  unreachable
}

; panics::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains1_0B3_() unnamed_addr #0 !guid !162 {
start:
  %_8 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_6 = alloca [4 x i8], align 4
; call core::hint::black_box::<i32>
  %0 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseGb2pkncjeE_6panics(i32 42) #24
  store i32 %0, ptr %_6, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8 %_8, ptr align 4 %_6) #24
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_12d2d02b2e0c041f3e841225de325fca, ptr align 8 %args) #24
  %_3.0 = extractvalue { ptr, ptr } %2, 0
  %_3.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_3.0, ptr %_3.1, ptr align 8 @alloc_e2740e3908ad36560b71cc9f5b200537) #27
  unreachable
}

; panics::main::{closure#4}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains2_0B3_() unnamed_addr #0 !guid !163 {
start:
; call core::hint::black_box::<u64>
  %_3 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECseGb2pkncjeE_6panics(i64 7) #24
; call std::panic::panic_any::<u64>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic9panic_anyyECseGb2pkncjeE_6panics(i64 %_3, ptr align 8 @alloc_ed9180a32b8d1532dfca976b688cc762) #28
  unreachable
}

; panics::main::{closure#5}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCseGb2pkncjeE_6panics4mains3_0B3_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !164 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
; call std::panic::catch_unwind::<panics::main::{closure#5}::{closure#0}, u8>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCseGb2pkncjeE_6panics4mains3_00hEBM_(ptr sret([16 x i8]) align 8 %_3)
; invoke <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %_0 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %_3)
          to label %bb2 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_3) #25
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb4

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_3)
  ret i1 %_0

terminate:                                        ; preds = %bb4
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb5:                                              ; preds = %bb4
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; panics::main::{closure#6}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains4_0B3_(i8 %x) unnamed_addr #0 !guid !165 {
start:
  %_0 = zext i8 %x to i32
  ret i32 %_0
}

; panics::main::{closure#7}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains5_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !166 {
start:
  %2 = alloca [16 x i8], align 8
  %e = alloca [16 x i8], align 8
  store ptr %0, ptr %e, align 8
  %3 = getelementptr inbounds i8, ptr %e, i64 8
  store ptr %1, ptr %3, align 8
  %_5.0 = load ptr, ptr %e, align 8
  %4 = getelementptr inbounds i8, ptr %e, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
  %_3 = invoke align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECsddYV2PBJW9h_3std(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e) #25
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

bb1:                                              ; preds = %start
; invoke <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#7}::{closure#0}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4mains5_00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_3)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e)
  ret void

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb5:                                              ; preds = %bb4
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; panics::main::{closure#8}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains6_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %e.0, ptr align 8 %e.1) unnamed_addr #0 !guid !167 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
; call <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<alloc::string::String>
  call void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_4, ptr %e.0, ptr align 8 %e.1) #24
; call <core::result::Result<alloc::boxed::Box<alloc::string::String>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<alloc::string::String, panics::main::{closure#8}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxNtNtBN_6string6StringEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapB1h_NCNCNvCseGb2pkncjeE_6panics4mains6_00EB2z_(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %_4) #24
; call <core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
  call void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtBL_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_3) #24
  ret void
}

; panics::main::{closure#9}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvCseGb2pkncjeE_6panics4mains7_0B3_(ptr %e.0, ptr align 8 %e.1) unnamed_addr #0 !guid !168 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
; call <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<u64>
  call void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_4, ptr %e.0, ptr align 8 %e.1) #24
; call <core::result::Result<alloc::boxed::Box<u64>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<u64, panics::main::{closure#9}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxyEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapyNCNCNvCseGb2pkncjeE_6panics4mains7_00EB2c_(ptr sret([16 x i8]) align 8 %_3, ptr align 8 %_4) #24
; call <core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
  %0 = call { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr align 8 %_3) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; panics::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains_0B3_() unnamed_addr #0 !guid !169 {
start:
; call core::hint::black_box::<u32>
  %_2 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseGb2pkncjeE_6panics(i32 5) #24
; call panics::deep
  %_0 = call i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %_2)
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseGb2pkncjeE_6panics(ptr %_1) unnamed_addr #0 !guid !170 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %0) #24
  ret i32 %_0
}

; <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNSNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !171 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
  call void @_RNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %1) #24
  ret void
}

; panics::deep
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %n) unnamed_addr #1 personality ptr @rust_eh_personality !guid !172 {
start:
  %0 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  %_2 = icmp eq i32 %n, 0
  br i1 %_2, label %bb1, label %bb5

bb5:                                              ; preds = %start
  %_9.0 = sub i32 %n, 1
  %_9.1 = icmp ult i32 %n, 1
  br i1 %_9.1, label %panic, label %bb6

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u32>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecmE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %v) #24
; invoke core::hint::black_box::<usize>
  %_6 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECseGb2pkncjeE_6panics(i64 7)
          to label %bb3 unwind label %cleanup

bb6:                                              ; preds = %bb5
; call panics::deep
  %_7 = call i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %_9.0)
  %_10.0 = add i32 %_7, 1
  %_10.1 = icmp ult i32 %_10.0, %_7
  br i1 %_10.1, label %panic1, label %bb8

panic:                                            ; preds = %bb5
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_3aadfb4415466f9ec9f9a3c5fbb426c4) #27
  unreachable

bb8:                                              ; preds = %bb6
  store i32 %_10.0, ptr %_0, align 4
  br label %bb9

panic1:                                           ; preds = %bb6
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d43dd53cfe4b9b827fd912a6e62abe23) #27
  unreachable

bb9:                                              ; preds = %bb4, %bb8
  %1 = load i32, ptr %_0, align 4
  ret i32 %1

bb10:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %v) #25
          to label %bb11 unwind label %terminate

cleanup:                                          ; preds = %bb3, %bb1
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb10

bb3:                                              ; preds = %bb1
; invoke <alloc::vec::Vec<u32> as core::ops::index::Index<usize>>::index
  %_4 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCseGb2pkncjeE_6panics(ptr align 8 %v, i64 %_6, ptr align 8 @alloc_6a689db22d1294a68a0bad4756950543)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  %6 = load i32, ptr %_4, align 4
  store i32 %6, ptr %_0, align 4
; call core::ptr::drop_glue::<alloc::vec::Vec<u32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %v)
  br label %bb9

terminate:                                        ; preds = %bb10
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb11:                                             ; preds = %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; panics::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCseGb2pkncjeE_6panics4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !173 {
start:
  %0 = alloca [16 x i8], align 8
  %e.i = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %1 = alloca [16 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_46 = alloca [16 x i8], align 8
  %n = alloca [1 x i8], align 1
  %_42 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_32 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_30 = alloca [24 x i8], align 8
  %r3 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_20 = alloca [24 x i8], align 8
  %r1 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %r = alloca [16 x i8], align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 1, i64 0) #24
  store i8 0, ptr %_4.i, align 1
; call std::panicking::set_hook
  call void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr %_3.i, ptr align 8 @vtable.2)
; call std::panic::catch_unwind::<panics::main::{closure#1}, u32>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains_0mEBK_(ptr sret([16 x i8]) align 8 %r)
; invoke <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %4 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %r)
          to label %bb4 unwind label %cleanup

bb37:                                             ; preds = %bb36, %bb35, %cleanup.body
; invoke core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %r) #25
          to label %bb38 unwind label %terminate

cleanup:                                          ; preds = %bb34, %bb33, %bb32, %bb31, %bb30, %bb29, %bb28, %bb27, %bb26, %bb24, %bb23, %bb22, %bb21, %bb20, %bb19, %bb18, %bb14, %bb13, %bb12, %bb8, %bb7, %bb6, %bb5, %bb4, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  br label %cleanup.body

cleanup.body:                                     ; preds = %bb5.i, %cleanup
  %eh.lpad-body = phi { ptr, i32 } [ %5, %cleanup ], [ %48, %bb5.i ]
  %6 = extractvalue { ptr, i32 } %eh.lpad-body, 0
  %7 = extractvalue { ptr, i32 } %eh.lpad-body, 1
  store ptr %6, ptr %3, align 8
  %8 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb37

bb4:                                              ; preds = %start
  %9 = zext i1 %4 to i8
  store i8 %9, ptr %_9, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_12, ptr %_9)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_12, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %11 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr @alloc_448fb98007976f236e6e677ba877f9b6, ptr align 8 %args)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_6.0 = extractvalue { ptr, ptr } %11, 0
  %_6.1 = extractvalue { ptr, ptr } %11, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_6.0, ptr %_6.1)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
; invoke std::panic::catch_unwind::<panics::main::{closure#2}, u8>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains0_0hEBK_(ptr sret([16 x i8]) align 8 %r1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %r1, i64 16, i1 false)
; invoke <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#7}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains5_0EB2Q_(ptr sret([24 x i8]) align 8 %_20, ptr align 8 %2)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_22, ptr align 8 %_20)
          to label %bb10 unwind label %cleanup7

bb36:                                             ; preds = %cleanup7
; invoke core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_20) #25
          to label %bb37 unwind label %terminate

cleanup7:                                         ; preds = %bb11, %bb10, %bb9
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %3, align 8
  %15 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb36

bb10:                                             ; preds = %bb9
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_22, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<15, 1>
  %17 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_3c431bcb3e5b1a19bfdfd590efb9375c, ptr align 8 %args2)
          to label %bb11 unwind label %cleanup7

bb11:                                             ; preds = %bb10
  %_17.0 = extractvalue { ptr, ptr } %17, 0
  %_17.1 = extractvalue { ptr, ptr } %17, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_17.0, ptr %_17.1)
          to label %bb12 unwind label %cleanup7

bb12:                                             ; preds = %bb11
; invoke core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_20)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb12
; invoke std::panic::catch_unwind::<panics::main::{closure#3}, i32>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains1_0lEBK_(ptr sret([16 x i8]) align 8 %r3)
          to label %bb14 unwind label %cleanup

bb14:                                             ; preds = %bb13
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %r3, i64 16, i1 false)
; invoke <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#8}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains6_0EB2Q_(ptr sret([24 x i8]) align 8 %_30, ptr align 8 %1)
          to label %bb15 unwind label %cleanup

bb15:                                             ; preds = %bb14
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_32, ptr align 8 %_30)
          to label %bb16 unwind label %cleanup8

bb35:                                             ; preds = %cleanup8
; invoke core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_30) #25
          to label %bb37 unwind label %terminate

cleanup8:                                         ; preds = %bb17, %bb16, %bb15
  %18 = landingpad { ptr, i32 }
          cleanup
  %19 = extractvalue { ptr, i32 } %18, 0
  %20 = extractvalue { ptr, i32 } %18, 1
  store ptr %19, ptr %3, align 8
  %21 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %20, ptr %21, align 8
  br label %bb35

bb16:                                             ; preds = %bb15
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_32, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %23 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_3d7fb2aa6ae966f1e7013d6c153d46dc, ptr align 8 %args4)
          to label %bb17 unwind label %cleanup8

bb17:                                             ; preds = %bb16
  %_27.0 = extractvalue { ptr, ptr } %23, 0
  %_27.1 = extractvalue { ptr, ptr } %23, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_27.0, ptr %_27.1)
          to label %bb18 unwind label %cleanup8

bb18:                                             ; preds = %bb17
; invoke core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_30)
          to label %bb19 unwind label %cleanup

bb19:                                             ; preds = %bb18
; invoke std::panic::catch_unwind::<panics::main::{closure#4}, ()>
  %24 = invoke { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains2_0uEBK_()
          to label %bb20 unwind label %cleanup

bb20:                                             ; preds = %bb19
  %r.0 = extractvalue { ptr, ptr } %24, 0
  %r.1 = extractvalue { ptr, ptr } %24, 1
; invoke <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<u64>, panics::main::{closure#9}>
  %25 = invoke { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionyENCNvCseGb2pkncjeE_6panics4mains7_0EB2w_(ptr %r.0, ptr %r.1)
          to label %bb21 unwind label %cleanup

bb21:                                             ; preds = %bb20
  %26 = extractvalue { i64, i64 } %25, 0
  %27 = extractvalue { i64, i64 } %25, 1
  store i64 %26, ptr %_40, align 8
  %28 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %27, ptr %28, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<(), core::option::Option<u64>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultuINtNtB7_6option6OptionyEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_40)
          to label %bb22 unwind label %cleanup

bb22:                                             ; preds = %bb21
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_42, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 1>
  %30 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr @alloc_b3985d69dd852d2586fba6caf63ad04a, ptr align 8 %args5)
          to label %bb23 unwind label %cleanup

bb23:                                             ; preds = %bb22
  %_37.0 = extractvalue { ptr, ptr } %30, 0
  %_37.1 = extractvalue { ptr, ptr } %30, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_37.0, ptr %_37.1)
          to label %bb24 unwind label %cleanup

bb24:                                             ; preds = %bb23
; invoke std::panic::catch_unwind::<panics::main::{closure#5}, bool>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains3_0bEBK_(ptr sret([16 x i8]) align 8 %_46)
          to label %bb25 unwind label %cleanup

bb25:                                             ; preds = %bb24
  %31 = load ptr, ptr %_46, align 8
  %32 = ptrtoint ptr %31 to i64
  %33 = icmp eq i64 %32, 0
  %_2.i = select i1 %33, i64 0, i64 1
  %34 = trunc nuw i64 %_2.i to i1
  br i1 %34, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit

bb2.i:                                            ; preds = %bb25
  %35 = load ptr, ptr %_46, align 8
  %36 = getelementptr inbounds i8, ptr %_46, i64 8
  %37 = load ptr, ptr %36, align 8
  store ptr %35, ptr %e.i, align 8
  %38 = getelementptr inbounds i8, ptr %e.i, i64 8
  store ptr %37, ptr %38, align 8
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.3, ptr align 8 @alloc_6c16facbf882c3c5f712b5f99d829949) #31
          to label %unreachable.i unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb2.i
  %39 = landingpad { ptr, i32 }
          cleanup
  %40 = extractvalue { ptr, i32 } %39, 0
  %41 = extractvalue { ptr, i32 } %39, 1
  store ptr %40, ptr %0, align 8
  %42 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %41, ptr %42, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %e.i) #25
          to label %bb5.i unwind label %terminate.i

unreachable.i:                                    ; preds = %bb2.i
  unreachable

terminate.i:                                      ; preds = %cleanup.i
  %43 = landingpad { ptr, i32 }
          cleanup
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb5.i:                                            ; preds = %cleanup.i
  %44 = load ptr, ptr %0, align 8
  %45 = getelementptr inbounds i8, ptr %0, i64 8
  %46 = load i32, ptr %45, align 8
  %47 = insertvalue { ptr, i32 } poison, ptr %44, 0
  %48 = insertvalue { ptr, i32 } %47, i32 %46, 1
  br label %cleanup.body

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit: ; preds = %bb25
  %49 = getelementptr inbounds i8, ptr %_46, i64 8
  %50 = load i8, ptr %49, align 8
  %t.i = trunc nuw i8 %50 to i1
  br label %bb26

bb26:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit
  %51 = zext i1 %t.i to i8
  store i8 %51, ptr %n, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_52, ptr %n)
          to label %bb27 unwind label %cleanup

bb27:                                             ; preds = %bb26
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_52, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %53 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_71d9bbd0f6c53403bb664fdb9799afa5, ptr align 8 %args6)
          to label %bb28 unwind label %cleanup

bb28:                                             ; preds = %bb27
  %_48.0 = extractvalue { ptr, ptr } %53, 0
  %_48.1 = extractvalue { ptr, ptr } %53, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_48.0, ptr %_48.1)
          to label %bb29 unwind label %cleanup

bb29:                                             ; preds = %bb28
; invoke std::panicking::take_hook
  %54 = invoke { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook()
          to label %bb30 unwind label %cleanup

bb30:                                             ; preds = %bb29
  %55 = extractvalue { ptr, ptr } %54, 0
  %56 = extractvalue { ptr, ptr } %54, 1
  store ptr %55, ptr %_55, align 8
  %57 = getelementptr inbounds i8, ptr %_55, i64 8
  store ptr %56, ptr %57, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8 %_55)
          to label %bb31 unwind label %cleanup

bb31:                                             ; preds = %bb30
; invoke core::hint::black_box::<core::option::Option<u8>>
  %58 = invoke { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECseGb2pkncjeE_6panics(i1 zeroext false, i8 undef)
          to label %bb32 unwind label %cleanup

bb32:                                             ; preds = %bb31
  %v.0 = extractvalue { i1, i8 } %58, 0
  %v.1 = extractvalue { i1, i8 } %58, 1
; invoke <core::option::Option<u8>>::map::<i32, panics::main::{closure#6}>
  %59 = invoke { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE3maplNCNvCseGb2pkncjeE_6panics4mains4_0EBT_(i1 zeroext %v.0, i8 %v.1)
          to label %bb33 unwind label %cleanup

bb33:                                             ; preds = %bb32
  %_60.0 = extractvalue { i32, i32 } %59, 0
  %_60.1 = extractvalue { i32, i32 } %59, 1
; invoke <core::option::Option<i32>>::unwrap_or
  %_59 = invoke i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE9unwrap_orCsddYV2PBJW9h_3std(i32 %_60.0, i32 %_60.1, i32 3)
          to label %bb34 unwind label %cleanup

bb34:                                             ; preds = %bb33
; invoke std::process::exit
  invoke void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32 %_59) #31
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %bb34
  unreachable

terminate:                                        ; preds = %bb37, %bb36, %bb35
  %60 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb38:                                             ; preds = %bb37
  %61 = load ptr, ptr %3, align 8
  %62 = getelementptr inbounds i8, ptr %3, i64 8
  %63 = load i32, ptr %62, align 8
  %64 = insertvalue { ptr, i32 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i32 } %64, i32 %63, 1
  resume { ptr, i32 } %65
}

; <alloc::vec::Vec<u32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecmE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !174 {
start:
; call <alloc::raw_vec::RawVec<u32>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecmE3newCseGb2pkncjeE_6panics()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !175 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !176 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8 %_1) #24
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !177 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8 %self) #24
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr %_2.0, i64 %_2.1) #24
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::raw_vec::RawVec<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecmE3newCseGb2pkncjeE_6panics() unnamed_addr #1 !guid !178 {
start:
; call <alloc::raw_vec::RawVec<u32>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE6new_inCseGb2pkncjeE_6panics() #24
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <std::panic::PanicHookInfo>::payload
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !179 {
start:
  %_0.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0.1 = load ptr, ptr %0, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !180 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<alloc::string::String>>::unwrap_or_default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !181 {
start:
  %x = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb4

bb2:                                              ; preds = %start
; call <alloc::string::String as core::default::Default>::default
  call void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) #24
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<alloc::string::String>>::or
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE2orCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, ptr align 8 %optb) unnamed_addr #0 personality ptr @rust_eh_personality !guid !182 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [1 x i8], align 1
  %x = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_6, align 1
  store i8 1, ptr %_5, align 1
  %1 = load i64, ptr %self, align 8
  %2 = icmp eq i64 %1, -1
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb9

bb2:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %optb, i64 24, i1 false)
  br label %bb9

bb9:                                              ; preds = %bb3, %bb2
  %4 = load i8, ptr %_5, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb8, label %bb4

bb4:                                              ; preds = %bb8, %bb9
  %6 = load i8, ptr %_6, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %optb)
          to label %bb4 unwind label %cleanup

bb6:                                              ; preds = %cleanup
  %8 = load i8, ptr %_6, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb11, label %bb7

cleanup:                                          ; preds = %bb8
  %10 = landingpad { ptr, i32 }
          cleanup
  %11 = extractvalue { ptr, i32 } %10, 0
  %12 = extractvalue { ptr, i32 } %10, 1
  store ptr %11, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %12, ptr %13, align 8
  br label %bb6

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %self)
  br label %bb5

bb7:                                              ; preds = %bb11, %bb6
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb11:                                             ; preds = %bb6
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8 %self) #25
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb11
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u64>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionyE4takeCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !183 {
start:
; call core::mem::replace::<core::option::Option<u64>>
  %0 = call { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionyEECseGb2pkncjeE_6panics(ptr align 8 %self, i64 0, i64 undef) #24
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtBL_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !184 {
start:
  %x = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %self, align 8
  %4 = icmp eq i64 %3, -1
  %_4 = select i1 %4, i64 1, i64 0
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtB11_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %self)
  br label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !185 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !186 {
start:
; call <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !187 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !188 {
start:
; call <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !189 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %x, ptr %5, align 8
  store i64 1, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %6 = load ptr, ptr %self, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %self)
  br label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %10 = load i64, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = insertvalue { i64, i64 } poison, i64 %10, 0
  %14 = insertvalue { i64, i64 } %13, i64 %12, 1
  ret { i64, i64 } %14

bb1:                                              ; No predecessors!
  unreachable
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}::{closure#0}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCseGb2pkncjeE_6panics4mains3_00E4takeB18_(ptr %slot) unnamed_addr #0 !guid !190 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E6as_refB1a_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#2}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains0_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !191 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#3}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains1_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !192 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#4}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains2_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !193 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains3_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !194 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#1}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !195 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_refCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !196 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E3newB1a_() unnamed_addr #1 !guid !197 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E6as_refB1a_(ptr %self) unnamed_addr #1 !guid !198 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E3newB18_() unnamed_addr #1 !guid !199 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !200 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E3newB18_() unnamed_addr #1 !guid !201 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !202 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E3newB18_() unnamed_addr #1 !guid !203 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !204 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E3newB18_() unnamed_addr #1 !guid !205 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !206 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E3newB18_() unnamed_addr #1 !guid !207 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !208 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<bool>>::new
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingbE3newCseGb2pkncjeE_6panics(i1 zeroext %x) unnamed_addr #1 !guid !209 {
start:
  ret i1 %x
}

; <core::mem::maybe_dangling::MaybeDangling<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCseGb2pkncjeE_6panics(i32 %x) unnamed_addr #1 !guid !210 {
start:
  ret i32 %x
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !211 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) #33
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %self) unnamed_addr #0 !guid !212 {
start:
  ret i64 %self
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !213 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %_3) #24
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64 %_2) #24
  ret ptr %_0
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !214 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) #33
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !215 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !216 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !217 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCseGb2pkncjeE_6panics(i64 %3, i64 %5, i1 zeroext %8) #24
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !218 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCseGb2pkncjeE_6panics(ptr %2, i64 %4, i64 %6) #24
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCseGb2pkncjeE_6panics(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !219 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %_6, i64 0) #24
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCseGb2pkncjeE_6panics(i64 %11, i64 %13) #24
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCseGb2pkncjeE_6panics(i64 %15, i64 %17) #24
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr %_12) #24
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr %_11) #24
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr %_10) #24
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #24
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr %ptr, i64 %size) #24
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCseGb2pkncjeE_6panics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !220 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCseGb2pkncjeE_6panics(ptr %ptr, i64 %3, i64 %5) #24
  br label %bb3
}

; <alloc::raw_vec::RawVec<u32>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !221 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u32>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrmECseGb2pkncjeE_6panics(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u32>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE6new_inCseGb2pkncjeE_6panics() unnamed_addr #0 personality ptr @rust_eh_personality !guid !222 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<u32>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofmECseGb2pkncjeE_6panics() #24
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64 %_4) #24
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&alloc::string::String>>::cloned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !223 {
start:
; call <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #24
  ret void
}

; <core::ptr::unique::Unique<alloc::string::String>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !224 {
start:
; call <core::ptr::non_null::NonNull<alloc::string::String>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<alloc::string::String>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE6as_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !225 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u32>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquemE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !226 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u64>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !227 {
start:
; call <core::ptr::non_null::NonNull<u64>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #24
  ret ptr %_2
}

; <core::ptr::unique::Unique<u64>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE6as_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !228 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !229 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !230 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultuINtNtB9_6option6OptionyEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !231 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !232 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) #33
  br label %bb3
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !233 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseGb2pkncjeE_6panics(ptr %r) unnamed_addr #0 !guid !234 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u64>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !235 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #24
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) #33
  br label %bb3
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !236 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseGb2pkncjeE_6panics(ptr %s.0, i64 %s.1) #24
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::panic::location::Location>::caller
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core5panic8locationNtB5_8Location6callerCseGb2pkncjeE_6panics(ptr align 8 %_0) unnamed_addr #0 !guid !237 {
start:
  ret ptr %_0
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %b.0, ptr align 8 %b.1) unnamed_addr #0 !guid !238 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr %b.0, ptr align 8 %b.1)
  %_2.0.i = extractvalue { ptr, ptr } %0, 0
  %_2.1.i = extractvalue { ptr, ptr } %0, 1
  %1 = extractvalue { ptr, ptr } %0, 0
  %2 = extractvalue { ptr, ptr } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store ptr %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_mutCsddYV2PBJW9h_3std(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load ptr, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_refCseGb2pkncjeE_6panics(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, ptr } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_11.1, 1
  ret { ptr, ptr } %6
}

; <alloc::boxed::Box<alloc::string::String>>::from_raw_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringE11from_raw_inCseGb2pkncjeE_6panics(ptr %raw) unnamed_addr #0 personality ptr @rust_eh_personality !guid !239 {
start:
; call <core::ptr::unique::Unique<alloc::string::String>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %raw) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_3

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<u64>>::from_raw_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyE11from_raw_inCseGb2pkncjeE_6panics(ptr %raw) unnamed_addr #0 personality ptr @rust_eh_personality !guid !240 {
start:
; call <core::ptr::unique::Unique<u64>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %raw) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_3

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !241 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseGb2pkncjeE_6panics(i8 %0) unnamed_addr #0 !guid !242 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseGb2pkncjeE_6panics(ptr %self) #24
  ret i32 %_0
}

; <alloc::vec::Vec<u32>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !243 {
start:
; call <alloc::raw_vec::RawVec<u32>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  ret ptr %_0
}

; <alloc::vec::Vec<u32>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !244 {
start:
; call <alloc::raw_vec::RawVec<u32>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  ret ptr %_2
}

; <alloc::vec::Vec<u32>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !245 {
start:
; call <alloc::vec::Vec<u32>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <*mut u32>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOm10cast_sliceCseGb2pkncjeE_6panics(ptr %self, i64 %len) unnamed_addr #0 !guid !246 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutmECseGb2pkncjeE_6panics(ptr %self, i64 %len) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCseGb2pkncjeE_6panics(i64 %0, i64 %1) unnamed_addr #0 !guid !247 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #34
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #34
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCseGb2pkncjeE_6panics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !248 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #34
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCseGb2pkncjeE_6panics(i64 %0, i64 %1) unnamed_addr #0 !guid !249 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #34
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #34
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !250 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCseGb2pkncjeE_6panics(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #24
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #31
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr %ptr.0, i64 %ptr.1) #24
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; core::intrinsics::type_id_eq
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCseGb2pkncjeE_6panics(ptr align 8 %a, ptr align 8 %b) unnamed_addr #8 !guid !251 {
start:
  %_3 = load i128, ptr %a, align 8
  %_4 = load i128, ptr %b, align 8
  %_0 = icmp eq i128 %_3, %_4
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !252 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseGb2pkncjeE_6panics() #24
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !253 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !254 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #32
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !255 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #32
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !256 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #26
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #32
  unreachable
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !257 {
start:
  ret i1 true
}

; <u64 as core::any::Any>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtCsl10jNU3mE6R_4core3anyyNtB2_3Any7type_idCseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !258 {
start:
; call <core::any::TypeId>::of::<u64>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::get
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload3getCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !259 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %a = getelementptr inbounds i8, ptr %self, i64 8
  %3 = insertvalue { ptr, ptr } poison, ptr %a, 0
  %4 = insertvalue { ptr, ptr } %3, ptr @vtable.4, 1
  ret { ptr, ptr } %4

bb2:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #31
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::take_box
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload8take_boxCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !260 {
start:
  %_4.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_11 = alloca [1 x i8], align 1
  %_3 = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  store i8 0, ptr %_11, align 1
; call <core::option::Option<u64>>::take
  %1 = call { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionyE4takeCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %a = load i64, ptr %8, align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 8, i64 8) #24
  store i8 0, ptr %_4.i, align 1
  store i64 %a, ptr %_3.i, align 8
  store i8 1, ptr %_11, align 1
  store ptr %_3.i, ptr %data, align 8
  %9 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr @vtable.4, ptr %9, align 8
  store i8 0, ptr %_11, align 1
  %_10.0 = load ptr, ptr %data, align 8
  %10 = getelementptr inbounds i8, ptr %data, i64 8
  %_10.1 = load ptr, ptr %10, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw
  %11 = invoke { ptr, ptr } @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E8into_rawCsddYV2PBJW9h_3std(ptr %_10.0, ptr align 8 %_10.1)
          to label %bb6 unwind label %cleanup

bb3:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #31
  unreachable

bb7:                                              ; preds = %cleanup
  %12 = load i8, ptr %_11, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb9, label %bb8

cleanup:                                          ; preds = %bb4
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  %_0.0 = extractvalue { ptr, ptr } %11, 0
  %_0.1 = extractvalue { ptr, ptr } %11, 1
  store i8 0, ptr %_11, align 1
  %18 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %19 = insertvalue { ptr, ptr } %18, ptr %_0.1, 1
  ret { ptr, ptr } %19

bb8:                                              ; preds = %bb9, %bb7
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr inbounds i8, ptr %0, i64 8
  %22 = load i32, ptr %21, align 8
  %23 = insertvalue { ptr, i32 } poison, ptr %20, 0
  %24 = insertvalue { ptr, i32 } %23, i32 %22, 1
  resume { ptr, i32 } %24

bb9:                                              ; preds = %bb7
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8 %data) #25
          to label %bb8 unwind label %terminate

terminate:                                        ; preds = %bb9
  %25 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #26
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <usize as core::slice::index::SliceIndex<[u32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSmE5indexCseGb2pkncjeE_6panics(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !261 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #27
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !262 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #24
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !263 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !264 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <&core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !265 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionyENtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !266 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<u64> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !267 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #24
  ret i1 %_0
}

; <&str as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !268 {
start:
  %s.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %s.1 = load i64, ptr %0, align 8
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #24
  ret void
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !269 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #24
  ret void
}

; <core::any::TypeId as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !270 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %self, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %other, i64 16, i1 false)
; call core::intrinsics::type_id_eq
  %_0 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %_4) #34
  ret i1 %_0
}

; <alloc::vec::Vec<u32> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !271 {
start:
; call <alloc::vec::Vec<u32>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<alloc::string::String> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !272 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<alloc::string::String>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE6as_ptrCseGb2pkncjeE_6panics(ptr %ptr) #24
; call <core::alloc::layout::Layout>::for_value_raw::<alloc::string::String>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %_5) #24
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<alloc::string::String>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %ptr) #24
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #24
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %4, i64 %6) #24
  br label %bb7
}

; <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !273 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<u64>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE6as_ptrCseGb2pkncjeE_6panics(ptr %ptr) #24
; call <core::alloc::layout::Layout>::for_value_raw::<u64>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawyECseGb2pkncjeE_6panics(ptr %_5) #24
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #24
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<u64>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueyE4casthECseGb2pkncjeE_6panics(ptr %ptr) #24
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr %_12) #24
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %4, i64 %6) #24
  br label %bb7
}

; <&str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !274 {
start:
; call <&str as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #24
  ret void
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !275 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #24
  ret void
}

; <core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !276 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.5)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !277 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.6)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !278 {
start:
  ret i8 0
}

; <std::panicking::begin_panic::Payload<u64> as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs_NvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB4_7PayloadyENtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !279 {
start:
  %_4 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %a = getelementptr inbounds i8, ptr %self, i64 8
; call std::panicking::payload_as_str
  %3 = call { ptr, i64 } @_RNvNtCsddYV2PBJW9h_3std9panicking14payload_as_str(ptr %a, ptr align 8 @vtable.4)
  %_6.0 = extractvalue { ptr, i64 } %3, 0
  %_6.1 = extractvalue { ptr, i64 } %3, 1
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %_6.0, i64 %_6.1)
  ret i1 %_0

bb2:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #31
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::vec::Vec<u32> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !280 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<u32> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[u32]>>::index
  %_0.i = call align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSmE5indexCseGb2pkncjeE_6panics(i64 %index, ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %0) #24
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtBM_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !281 {
start:
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
; call <dyn core::any::Any + core::marker::Send as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs0_NtCsl10jNU3mE6R_4core3anyDNtB5_3AnyNtNtB7_6marker4SendEL_NtNtB7_3fmt5Debug3fmt(ptr %_4.0, ptr align 8 %_4.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::vec::Vec<u32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !282 {
start:
; call <alloc::vec::Vec<u32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u32>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOm10cast_sliceCseGb2pkncjeE_6panics(ptr %_3, i64 %_4) #24
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::string::String as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !283 {
start:
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) #24
  ret void
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !284 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !285 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<u8, core::option::Option<alloc::string::String>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !286 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -2
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.8)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.7)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, core::option::Option<alloc::string::String>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !287 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -2
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.8)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.9)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), core::option::Option<u64>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtB7_6option6OptionyEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !288 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = icmp eq i64 %0, 2
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.b)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.a)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !289 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) #24
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %_1) unnamed_addr #0 !guid !290 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::as_str
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYINtNvNtCsddYV2PBJW9h_3std9panicking11begin_panic7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !291 {
start:
  ret { ptr, i64 } { ptr null, i64 undef }
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !292 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics(ptr align 8 %_1) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !293 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call panics::main::{closure#0}
  call void @_RNCNvCseGb2pkncjeE_6panics4main0B3_(ptr %_1, ptr align 8 %1) #24
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !294 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <alloc::string::String as core::clone::Clone>::clone
  call void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %1)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #9

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <dyn core::any::Any>::is::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #8

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #10

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nonlazybind
define internal zeroext i1 @__rust_try(ptr %0, ptr %1, ptr %2) unnamed_addr #11 personality ptr @rust_eh_personality !guid !295 {
entry-block:
  invoke void %0(ptr %1)
          to label %then unwind label %catch

then:                                             ; preds = %entry-block
  ret i1 false

catch:                                            ; preds = %entry-block
  %3 = landingpad { ptr, i32 }
          catch ptr null
  %4 = extractvalue { ptr, i32 } %3, 0
  call void %2(ptr %1, ptr %4)
  ret i1 true
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringEBF_(ptr align 8) unnamed_addr #1

; core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECs3ZOqIoMh3eg_9addr2line(ptr align 8) unnamed_addr #1

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECsddYV2PBJW9h_3std() unnamed_addr #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #12

; std::panicking::catch_unwind::cleanup
; Function Attrs: cold minsize nonlazybind optsize uwtable
declare { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr) unnamed_addr #13

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #10

; std::panicking::panic_with_hook
; Function Attrs: minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking15panic_with_hook(ptr, ptr align 8, ptr align 8, i1 zeroext, i1 zeroext) unnamed_addr #14

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #15

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #10

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #10

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
declare align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; <core::fmt::Arguments>::new::<11, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #15

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylEB7_(ptr sret([16 x i8]) align 8, ptr align 4) unnamed_addr #0

; <core::fmt::Arguments>::new::<10, 1>
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_EB8_(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #15

; std::panicking::set_hook
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr, ptr align 8) unnamed_addr #1

; std::panicking::take_hook
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook() unnamed_addr #1

; core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
declare void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EEB1O_(ptr align 8) unnamed_addr #1

; <core::option::Option<i32>>::unwrap_or
; Function Attrs: inlinehint nonlazybind uwtable
declare i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE9unwrap_orCsddYV2PBJW9h_3std(i32, i32, i32) unnamed_addr #0

; std::process::exit
; Function Attrs: noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32) unnamed_addr #16

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newB4_(ptr sret([24 x i8]) align 8) unnamed_addr #0

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceB6_(ptr align 8) unnamed_addr #0

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #15

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<u8>>::new
; Function Attrs: nonlazybind uwtable
declare i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newB6_(i8) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<i32>>::new
; Function Attrs: nonlazybind uwtable
declare i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCsddYV2PBJW9h_3std(i32) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<()>>::new
; Function Attrs: nonlazybind uwtable
declare void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCsddYV2PBJW9h_3std() unnamed_addr #1

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCs7CppTae75M1_5alloc(i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCs7CppTae75M1_5alloc(ptr align 8) unnamed_addr #0

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
declare { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inB7_(i64) unnamed_addr #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #17

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #8

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #18

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #19

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #20

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCs7CppTae75M1_5alloc(ptr, i64) unnamed_addr #0

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #21

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #22

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullB6_(ptr) unnamed_addr #0

; std::process::abort
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process5abort() unnamed_addr #23

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw
; Function Attrs: inlinehint nonlazybind uwtable
declare { ptr, ptr } @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E8into_rawCsddYV2PBJW9h_3std(ptr, ptr align 8) unnamed_addr #0

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #3

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
declare void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateB7_(ptr align 8, i64, i64) unnamed_addr #1

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_mut
; Function Attrs: nonlazybind uwtable
declare align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_mutCsddYV2PBJW9h_3std(ptr align 8) unnamed_addr #1

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedB7_(ptr sret([24 x i8]) align 8, ptr, i64) unnamed_addr #1

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
declare ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCs7CppTae75M1_5alloc(ptr) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; std::panicking::payload_as_str
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvNtCsddYV2PBJW9h_3std9panicking14payload_as_str(ptr, ptr align 8) unnamed_addr #1

; <dyn core::any::Any + core::marker::Send as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs0_NtCsl10jNU3mE6R_4core3anyDNtB5_3AnyNtNtB7_6marker4SendEL_NtNtB7_3fmt5Debug3fmt(ptr, ptr align 8, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtB8_(ptr align 8, ptr align 8) unnamed_addr #1

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCsddYV2PBJW9h_3std(ptr align 8, ptr align 8) unnamed_addr #1

; <&() as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRuNtB6_5Debug3fmtCshGsV4pNJ6ra_6object(ptr align 8, ptr align 8) unnamed_addr #1

; <alloc::string::String as core::clone::Clone>::clone
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #11 !guid !296 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseGb2pkncjeE_6panics(ptr @_RNvCseGb2pkncjeE_6panics4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { inlinehint minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #10 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { nonlazybind "target-cpu"="x86-64" }
attributes #12 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #13 = { cold minsize nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #14 = { minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #18 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #20 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #21 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #22 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #23 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #24 = { inlinehint }
attributes #25 = { cold }
attributes #26 = { cold noreturn nounwind }
attributes #27 = { noinline noreturn }
attributes #28 = { inlinehint noreturn }
attributes #29 = { cold noinline noreturn nounwind }
attributes #30 = { noinline }
attributes #31 = { noreturn }
attributes #32 = { noinline noreturn nounwind }
attributes #33 = { inlinehint nounwind }
attributes #34 = { nounwind }

!llvm.module.flags = !{!53, !54, !55, !56}
!llvm.ident = !{!57}

!0 = !{i64 -2493779167280624301}
!1 = !{i64 1208957907717419987}
!2 = !{i64 6423594196526314803}
!3 = !{i64 -5356250704026679138}
!4 = !{i64 2961479790530443818}
!5 = !{i64 788081539932565442}
!6 = !{i64 980210168389032609}
!7 = !{i64 -4882986603634069232}
!8 = !{i64 -3005372252893661383}
!9 = !{i64 4609579291053422603}
!10 = !{i64 3596965049277782570}
!11 = !{i64 2777624885515822651}
!12 = !{i64 7844761308724398288}
!13 = !{i64 4842289176554857169}
!14 = !{i64 2921346418304255893}
!15 = !{i64 -6103199286651190864}
!16 = !{i64 8563473757190057284}
!17 = !{i64 -8432432487554342137}
!18 = !{i64 2134700603267569285}
!19 = !{i64 -5396612712977725596}
!20 = !{i64 -4412256379462227110}
!21 = !{i64 -8857369527434967825}
!22 = !{i64 2404126197610985173}
!23 = !{i64 576422902352836766}
!24 = !{i64 -5638321319456089788}
!25 = !{i64 -3207152940169518150}
!26 = !{i64 -3029844248624312979}
!27 = !{i64 5049289066004386945}
!28 = !{i64 -6729519479804392288}
!29 = !{i64 -3167056848200926882}
!30 = !{i64 5207604533642723614}
!31 = !{i64 7044128501033304411}
!32 = !{i64 -8311165338614920329}
!33 = !{i64 -3066455594930163733}
!34 = !{i64 692931618294192451}
!35 = !{i64 -4507677279253300057}
!36 = !{i64 -620909799470651325}
!37 = !{i64 -7334063765312658700}
!38 = !{i64 7423254117282367028}
!39 = !{i64 6082881058793857041}
!40 = !{i64 -6288849203889583699}
!41 = !{i64 2000539387579406578}
!42 = !{i64 5529955749004293916}
!43 = !{i64 -7235210469069962263}
!44 = !{i64 6205583340840306213}
!45 = !{i64 -2079516508712941149}
!46 = !{i64 -4505891931221296063}
!47 = !{i64 8316537712808156689}
!48 = !{i64 6229991252516240826}
!49 = !{i64 6365320554810069131}
!50 = !{i64 -3521331006013510087}
!51 = !{i64 -1859781851218846456}
!52 = !{i64 -5032279224836018063}
!53 = !{i32 8, !"PIC Level", i32 2}
!54 = !{i32 7, !"PIE Level", i32 2}
!55 = !{i32 2, !"RtLibUseGOT", i32 1}
!56 = !{i32 7, !"uwtable", i32 2}
!57 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!58 = !{i64 2224638660137371447}
!59 = !{i64 5572620180629208040}
!60 = !{i64 1761714520277447330}
!61 = !{i64 5082061661087059114}
!62 = !{i64 -7655186839982109514}
!63 = !{i64 -9106327572736421219}
!64 = !{i64 8151770952107371830}
!65 = !{i64 4768298313051841941}
!66 = !{i64 -3738136729010150234}
!67 = !{i64 -2271441780443507501}
!68 = !{i64 -8199720594301612576}
!69 = !{i64 5269422196824196945}
!70 = !{i64 2217149738215784870}
!71 = !{i64 -5089356076365160607}
!72 = !{i64 -2253009204424128743}
!73 = !{i64 7670066073845004524}
!74 = !{i64 1222595694332470589}
!75 = !{i64 -4517012105260341799}
!76 = !{i64 -5464867015772116039}
!77 = !{i64 8843668367424603988}
!78 = !{i64 5728652024390193952}
!79 = !{i64 6478178445923673875}
!80 = !{i64 -6965744514756882586}
!81 = !{i64 -240621713624905051}
!82 = !{i64 509958630160434231}
!83 = !{i64 -4671858223165155422}
!84 = !{i64 -3713016501546592714}
!85 = !{i64 8776718972062272940}
!86 = !{i64 -4271769106560985845}
!87 = !{i64 1518304822886422269}
!88 = !{i64 2753412520765024960}
!89 = !{i64 5567448280889261194}
!90 = !{i64 -1703480618747896273}
!91 = !{}
!92 = !{i64 2333457655006828776}
!93 = !{i64 -643543568240074914}
!94 = !{i64 964608857734655080}
!95 = !{i64 -7920072275997662697}
!96 = !{i64 -4502938848911743220}
!97 = !{i64 -4010632222680605773}
!98 = !{i64 -963249951976168518}
!99 = !{i64 -8898058485598662946}
!100 = !{i64 -3268198669108626072}
!101 = !{i64 -4168046695701380807}
!102 = !{i64 -1988875521052614158}
!103 = !{i64 6821883899664113911}
!104 = !{i64 -6340184225945331994}
!105 = !{i64 1884650308998682136}
!106 = !{i64 4872637052914887925}
!107 = !{i64 435776538438485507}
!108 = !{i64 -8742019005803139187}
!109 = !{i64 1861970751934901077}
!110 = !{i64 -9026259935053962123}
!111 = !{i64 8164834616937106795}
!112 = !{i64 7926579248395741712}
!113 = !{i64 6545894656939472073}
!114 = !{i64 743855562828071151}
!115 = !{i64 7364987241347797797}
!116 = !{i64 3839739536483625434}
!117 = !{i64 7515942850166780773}
!118 = !{i64 -4413564777274010623}
!119 = !{i64 -9050075766900800808}
!120 = !{i64 -6042599337697936455}
!121 = !{i64 8441887133718696451}
!122 = !{i64 -6947769281004349913}
!123 = !{i64 1201345324733147127}
!124 = !{i64 -3688934762240791304}
!125 = !{i64 2277677993735861559}
!126 = !{i64 -6899602933721491208}
!127 = !{i64 -5466047578387750788}
!128 = !{i64 -6113563221550404169}
!129 = !{i64 -8989670239334155675}
!130 = !{i64 8792996344165845051}
!131 = !{i64 -2094620338651728568}
!132 = !{i64 1317781866065505}
!133 = !{i64 1324640065634921032}
!134 = !{i64 2229003545096304870}
!135 = !{i64 8708684069729819007}
!136 = !{i64 -4198634043639438075}
!137 = !{i64 3095575010650310376}
!138 = !{i64 -1261684364470924473}
!139 = !{i64 6973572072610238553}
!140 = !{i64 -4841057003702188408}
!141 = !{i64 -1974721998501145488}
!142 = !{i64 8188860582606171816}
!143 = !{i64 -5340046494180801143}
!144 = !{i64 -7554190426403637527}
!145 = !{i64 1456672556856389515}
!146 = !{i64 -6580344693357898314}
!147 = !{i64 3393877022876683785}
!148 = !{i64 -5991142457723329359}
!149 = !{i64 -8646164163127108748}
!150 = !{i64 -8497724877416256879}
!151 = !{i64 -6461360197485787082}
!152 = !{i64 -1039477695765711823}
!153 = !{i64 -3775161995293036592}
!154 = !{i64 3852851918349606188}
!155 = !{i64 -8392302851088250997}
!156 = !{i64 9184264244582243271}
!157 = !{i64 6361520969593812328}
!158 = !{i64 3038159018935187642}
!159 = !{i64 -4814645250736481124}
!160 = !{i64 8279767425853236006}
!161 = !{i64 8307965153042777408}
!162 = !{i64 -8265326322211251955}
!163 = !{i64 -6662938725145932966}
!164 = !{i64 -1822882181969888468}
!165 = !{i64 6074608682868900752}
!166 = !{i64 6227801940582305673}
!167 = !{i64 628969445224093317}
!168 = !{i64 2364622320996087613}
!169 = !{i64 -3293680003808909474}
!170 = !{i64 4617230870894404527}
!171 = !{i64 1740152363458035523}
!172 = !{i64 3993938978275726687}
!173 = !{i64 3132548509616971867}
!174 = !{i64 2606789744909526248}
!175 = !{i64 9178870146941793156}
!176 = !{i64 -3233061136429432758}
!177 = !{i64 3816323076261870142}
!178 = !{i64 -8845893073191810204}
!179 = !{i64 4582613916685560512}
!180 = !{i64 -6909857445594467514}
!181 = !{i64 6761627602321924331}
!182 = !{i64 -560269023889225501}
!183 = !{i64 -5485060114546218156}
!184 = !{i64 8270054427073737945}
!185 = !{i64 911314053452120926}
!186 = !{i64 1877182796108078077}
!187 = !{i64 6827170824707073715}
!188 = !{i64 6798526975859915153}
!189 = !{i64 -4540083857836917887}
!190 = !{i64 969984789867905705}
!191 = !{i64 8797688039007324089}
!192 = !{i64 4274311021221847017}
!193 = !{i64 -5439544120652538416}
!194 = !{i64 8377821728774780319}
!195 = !{i64 -250936119651597897}
!196 = !{i64 4631064969503936645}
!197 = !{i64 -6008462575974975462}
!198 = !{i64 -4221087853340720554}
!199 = !{i64 -625836193462287077}
!200 = !{i64 -8036760724735186814}
!201 = !{i64 -8069288519486989822}
!202 = !{i64 3589080336701170611}
!203 = !{i64 -2946255707023913763}
!204 = !{i64 603105798031861374}
!205 = !{i64 -2223916365818429278}
!206 = !{i64 -4872203053891441844}
!207 = !{i64 4185460534806626813}
!208 = !{i64 -3291126169198111119}
!209 = !{i64 2193513613803235693}
!210 = !{i64 755202331056813600}
!211 = !{i64 -5680232268847202953}
!212 = !{i64 -4718962668758820594}
!213 = !{i64 920996281870241555}
!214 = !{i64 102107858229253846}
!215 = !{i64 685047982707958140}
!216 = !{i64 -6097260604204814695}
!217 = !{i64 -7266521994395967762}
!218 = !{i64 5860098013496398209}
!219 = !{i64 -4438439204017971540}
!220 = !{i64 -4927944946904730497}
!221 = !{i64 -5293868592314058038}
!222 = !{i64 -2912674053402297990}
!223 = !{i64 4014400766819656997}
!224 = !{i64 698599596574328199}
!225 = !{i64 7036615888491847442}
!226 = !{i64 -6125528727597757192}
!227 = !{i64 -2037082091709337744}
!228 = !{i64 -8184553874587970345}
!229 = !{i64 3208406895400334301}
!230 = !{i64 -3752815637547068961}
!231 = !{i64 -1678522487719655038}
!232 = !{i64 -2997601288515956933}
!233 = !{i64 -8767397769133757208}
!234 = !{i64 -6363770451128396554}
!235 = !{i64 6700672834360432345}
!236 = !{i64 -4908851018894768552}
!237 = !{i64 4045862026971283700}
!238 = !{i64 1609589038781720879}
!239 = !{i64 3924040898618060945}
!240 = !{i64 -2476005197520479835}
!241 = !{i64 -1432665658785561984}
!242 = !{i64 8406323178692658310}
!243 = !{i64 4628431546686540976}
!244 = !{i64 3243116870724392383}
!245 = !{i64 512311490497756534}
!246 = !{i64 -2321076285018683494}
!247 = !{i64 673827160012687507}
!248 = !{i64 -6942687888014493335}
!249 = !{i64 1558557703929287480}
!250 = !{i64 -423893097844925362}
!251 = !{i64 1005312155265887362}
!252 = !{i64 -6389441196477388746}
!253 = !{i64 -4095352174548544079}
!254 = !{i64 3544267021258248557}
!255 = !{i64 3358492981697008189}
!256 = !{i64 5694257936774963863}
!257 = !{i64 2042777209422420261}
!258 = !{i64 5222149809899979354}
!259 = !{i64 6799861780628996667}
!260 = !{i64 -3451065699460907515}
!261 = !{i64 2268880559303429003}
!262 = !{i64 -4841745674710379277}
!263 = !{i64 2991605329457611134}
!264 = !{i64 -4498303764927497984}
!265 = !{i64 261905937459196452}
!266 = !{i64 -8149635205762438515}
!267 = !{i64 -4524934818297980858}
!268 = !{i64 -9195609212210476416}
!269 = !{i64 3789147084788905778}
!270 = !{i64 2110423025234355149}
!271 = !{i64 -5550870448663165119}
!272 = !{i64 2903431599885024645}
!273 = !{i64 -8026992919822840769}
!274 = !{i64 1512433693979055150}
!275 = !{i64 320121458441754668}
!276 = !{i64 -4005680100744842706}
!277 = !{i64 5495701163451503543}
!278 = !{i64 -3106731790953631421}
!279 = !{i64 -9221333948592381906}
!280 = !{i64 -4577917346625759239}
!281 = !{i64 5879453042235638201}
!282 = !{i64 -8114425130346640587}
!283 = !{i64 3573241012791516032}
!284 = !{i64 7497835115393955788}
!285 = !{i64 7077070301986270280}
!286 = !{i64 -6532429833960452330}
!287 = !{i64 -8944011964961764801}
!288 = !{i64 -6445883103901644176}
!289 = !{i64 1669988726900488455}
!290 = !{i64 7014981557723664926}
!291 = !{i64 6244821123098168303}
!292 = !{i64 5659697653897027325}
!293 = !{i64 502869261312355886}
!294 = !{i64 -7163031122851228909}
!295 = !{i64 -3126838782374109055}
!296 = !{i64 -2624081020897602054}
