; ModuleID = 'panics.aafd8ccfe9a8bfaa-cgu.0'
source_filename = "panics.aafd8ccfe9a8bfaa-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@alloc_f1a659b4341130ad3c74926dbea56691 = private unnamed_addr constant [26 x i8] c"core/src/mem/alignment.rs\00", align 1, !guid !0
@alloc_acba356d0d418ecf2dce0d26c62c4b8f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\A1\00\00\00\12\00\00\00" }>, align 8, !guid !1
@alloc_11ddb215bb7a9a9d0f0a40e162a47158 = private unnamed_addr constant [25 x i8] c"core/src/alloc/layout.rs\00", align 1, !guid !2
@alloc_36bf30472af6160b1c846dd09f0e2d85 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_11ddb215bb7a9a9d0f0a40e162a47158, [16 x i8] c"\18\00\00\00\00\00\00\00\07\01\00\00\12\00\00\00" }>, align 8, !guid !3
@anon.fc6ebcf9488fce9791a3e964855a907f.0 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -4483657762704989261 to ptr), ptr inttoptr (i64 4961802129399286908 to ptr) }>, align 8, !guid !4
@anon.fc6ebcf9488fce9791a3e964855a907f.1 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -5046843186896832932 to ptr), ptr inttoptr (i64 2648505749699871217 to ptr) }>, align 8, !guid !5
@anon.fc6ebcf9488fce9791a3e964855a907f.2 = private unnamed_addr constant <{ ptr, ptr }> <{ ptr inttoptr (i64 -2724188134956199339 to ptr), ptr inttoptr (i64 -7993673810352186047 to ptr) }>, align 8, !guid !6
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseGb2pkncjeE_6panics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics, ptr @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics }>, align 8, !guid !7
@alloc_92d63ba27fbb6c5e4e2cfc3879de4745 = private unnamed_addr constant [20 x i8] c"core/src/ptr/mod.rs\00", align 1, !guid !8
@alloc_a4b6077411685917cd51431566be9305 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_92d63ba27fbb6c5e4e2cfc3879de4745, [16 x i8] c"\13\00\00\00\00\00\00\00)\02\00\00\05\00\00\00" }>, align 8, !guid !9
@alloc_d5d54240cab534dcfdfc9e1f15f834f2 = private unnamed_addr constant [19 x i8] c"alloc/src/slice.rs\00", align 1, !guid !10
@alloc_50f7a04d493c3c635bb162890af45f79 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_d5d54240cab534dcfdfc9e1f15f834f2, [16 x i8] c"\12\00\00\00\00\00\00\00\C6\01\00\00$\00\00\00" }>, align 8, !guid !11
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs_NvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB4_7PayloadyENtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics, ptr @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload8take_boxCseGb2pkncjeE_6panics, ptr @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload3getCseGb2pkncjeE_6panics, ptr @_RNvYINtNvNtCsddYV2PBJW9h_3std9panicking11begin_panic7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload6as_strCseGb2pkncjeE_6panics }>, align 8, !guid !12
@alloc_6c342f467cee9eb46aaa013cf1ccd49c = private unnamed_addr constant [5 x i8] c"inner", align 1, !guid !13
@alloc_93aca317a13a136ecbfa0dc0ccaaa44a = private unnamed_addr constant [25 x i8] c"test/rust/eval/panics.rs\00", align 1, !guid !14
@alloc_1378573dc70dc7b629a9d6b1d49c46c0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\14\00\00\00C\00\00\00" }>, align 8, !guid !15
@alloc_bc2728ce27cec9f60e0626ade65acb4b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\11\00\00\00K\00\00\00" }>, align 8, !guid !16
@alloc_0aeb6e895488c55d15573141e7b7a3c2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\13\00\00\00E\00\00\00" }>, align 8, !guid !17
@alloc_02b558d5b27198b9b90fbafced75e0cf = private unnamed_addr constant [11 x i8] c"\06hook: \C0\01\0A\00", align 1, !guid !18
@alloc_26337d6526588881851e4b9aa79dd1e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\0E\00\00\00;\00\00\00" }>, align 8, !guid !19
@alloc_12d2d02b2e0c041f3e841225de325fca = private unnamed_addr constant [10 x i8] c"\07custom \C0\00", align 1, !guid !20
@alloc_e2740e3908ad36560b71cc9f5b200537 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\10\00\00\00-\00\00\00" }>, align 8, !guid !21
@alloc_ed9180a32b8d1532dfca976b688cc762 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\12\00\00\003\00\00\00" }>, align 8, !guid !22
@alloc_16d8701a704195662253a9809cf298d1 = private unnamed_addr constant [25 x i8] c"alloc/src/raw_vec/mod.rs\00", align 1, !guid !23
@alloc_84e24ad25dfa3f90d9808e22947b437c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\85\03\00\00G\00\00\00" }>, align 8, !guid !24
@alloc_3aadfb4415466f9ec9f9a3c5fbb426c4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00[\00\00\00" }>, align 8, !guid !25
@alloc_d43dd53cfe4b9b827fd912a6e62abe23 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00V\00\00\00" }>, align 8, !guid !26
@alloc_6a689db22d1294a68a0bad4756950543 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\07\00\00\00E\00\00\00" }>, align 8, !guid !27
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNSNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_, ptr @_RNCNvCseGb2pkncjeE_6panics4main0B3_, ptr @_RNCNvCseGb2pkncjeE_6panics4main0B3_ }>, align 8, !guid !28
@alloc_448fb98007976f236e6e677ba877f9b6 = private unnamed_addr constant [11 x i8] c"\06deep: \C0\01\0A\00", align 1, !guid !29
@alloc_3c431bcb3e5b1a19bfdfd590efb9375c = private unnamed_addr constant [15 x i8] c"\0Aoverflow: \C0\01\0A\00", align 1, !guid !30
@alloc_3d7fb2aa6ae966f1e7013d6c153d46dc = private unnamed_addr constant [13 x i8] c"\08custom: \C0\01\0A\00", align 1, !guid !31
@alloc_b3985d69dd852d2586fba6caf63ad04a = private unnamed_addr constant [10 x i8] c"\05any: \C0\01\0A\00", align 1, !guid !32
@alloc_6c16facbf882c3c5f712b5f99d829949 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_93aca317a13a136ecbfa0dc0ccaaa44a, [16 x i8] c"\18\00\00\00\00\00\00\00\14\00\00\00`\00\00\00" }>, align 8, !guid !33
@alloc_71d9bbd0f6c53403bb664fdb9799afa5 = private unnamed_addr constant [13 x i8] c"\08nested: \C0\01\0A\00", align 1, !guid !34
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1, !guid !35
@vtable.3 = private unnamed_addr constant <{ ptr, [16 x i8], ptr }> <{ ptr @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics, [16 x i8] c"\10\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtBM_3fmt5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !36
@alloc_04af5354bae90239a24027527d4c463d = private unnamed_addr constant [30 x i8] c"core/src/mem/manually_drop.rs\00", align 1, !guid !37
@alloc_622d398601f4d17fcdc4667dab4c4cb4 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\CB\00\00\000\00\00\00" }>, align 8, !guid !38
@alloc_d9607be26b1182115ab3c853f5787a76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_04af5354bae90239a24027527d4c463d, [16 x i8] c"\1D\00\00\00\00\00\00\00\E4\00\00\00\12\00\00\00" }>, align 8, !guid !39
@alloc_988c380202cc7b7a37ca3d8d5930c44f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_f1a659b4341130ad3c74926dbea56691, [16 x i8] c"\19\00\00\00\00\00\00\00\AD\00\00\00\1B\00\00\00" }>, align 8, !guid !40
@alloc_fad0cd83b7d1858a846a172eb260e593 = private unnamed_addr constant [42 x i8] c"is_aligned_to: align is not a power-of-two", align 1, !guid !41
@alloc_3a97cab01964e354cab63e4d72a95bbc = private unnamed_addr constant [26 x i8] c"core/src/ptr/const_ptr.rs\00", align 1, !guid !42
@alloc_7abc4ceda2d1d9be88f00c5dc522bc84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3a97cab01964e354cab63e4d72a95bbc, [16 x i8] c"\19\00\00\00\00\00\00\00M\05\00\00\0D\00\00\00" }>, align 8, !guid !43
@alloc_a873ca09b70b7db2f8c9b3291f9566b2 = private unnamed_addr constant [19 x i8] c"alloc/src/alloc.rs\00", align 1, !guid !44
@alloc_d48fd52eabdd3dce4034ac7ef36523bb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a873ca09b70b7db2f8c9b3291f9566b2, [16 x i8] c"\12\00\00\00\00\00\00\00/\01\00\00\1B\00\00\00" }>, align 8, !guid !45
@alloc_3d5b7f261101b120d30419294a27cc6f = private unnamed_addr constant [23 x i8] c"core/src/ptr/unique.rs\00", align 1, !guid !46
@alloc_8e8e5d43991787ef9fba0c8fe53b59fb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3d5b7f261101b120d30419294a27cc6f, [16 x i8] c"\16\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8, !guid !47
@alloc_8fcef52db7fa1bf8c0a5f459915f0181 = private unnamed_addr constant [25 x i8] c"core/src/ptr/non_null.rs\00", align 1, !guid !48
@alloc_e469ef44bf39c45bcb672a4bc963b9cb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00\1A\01\00\00\1B\00\00\00" }>, align 8, !guid !49
@alloc_85bcb8feb56634093aba2b8644936af9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\7F\02\00\005\00\00\00" }>, align 8, !guid !50
@alloc_17de00c3327446355700bd7db4b78ded = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\80\02\00\00\1E\00\00\00" }>, align 8, !guid !51
@alloc_b9419d44288097f84422e162822ba96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\81\02\00\00 \00\00\00" }>, align 8, !guid !52
@alloc_af3623564924928dd3d563c9d84a8a0e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_8fcef52db7fa1bf8c0a5f459915f0181, [16 x i8] c"\18\00\00\00\00\00\00\00s\05\00\00\12\00\00\00" }>, align 8, !guid !53
@alloc_33dfd402c6ecbe2e6a32e76edf5f31a5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\D8\01\00\00L\00\00\00" }>, align 8, !guid !54
@alloc_099d793709fa470a3d5e7c79c938e035 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\C9\01\00\003\00\00\00" }>, align 8, !guid !55
@alloc_51424262946dd0794fad6132df857999 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_16d8701a704195662253a9809cf298d1, [16 x i8] c"\18\00\00\00\00\00\00\00\B7\01\00\00\15\00\00\00" }>, align 8, !guid !56
@alloc_cfd148d182d4e1a7090a06e7be349887 = private unnamed_addr constant [19 x i8] c"alloc/src/boxed.rs\00", align 1, !guid !57
@alloc_eec7f4dd0816627e138b9d35c0a02643 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cfd148d182d4e1a7090a06e7be349887, [16 x i8] c"\12\00\00\00\00\00\00\00\8E\06\00\00\1E\00\00\00" }>, align 8, !guid !58
@alloc_20335d280cf863e989181802c79159f5 = private unnamed_addr constant [21 x i8] c"alloc/src/vec/mod.rs\00", align 1, !guid !59
@alloc_0a847bcc9fc8270cda6b588be330f96e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_20335d280cf863e989181802c79159f5, [16 x i8] c"\14\00\00\00\00\00\00\00\AA\08\00\00\09\00\00\00" }>, align 8, !guid !60
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !61
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !62
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !63
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !64
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !65
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !66
@alloc_bd3468a7b96187f70c1ce98a3e7a63bf = private unnamed_addr constant [283 x i8] c"unsafe precondition(s) violated: ptr::copy_nonoverlapping requires that both pointer arguments are aligned and non-null and the specified memory ranges do not overlap\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !67
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !68
@alloc_763310d78c99c2c1ad3f8a9821e942f3 = private unnamed_addr constant [61 x i8] c"is_nonoverlapping: `size_of::<T>() * count` overflows a usize", align 1, !guid !69
@vtable.4 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXNtCsl10jNU3mE6R_4core3anyyNtB2_3Any7type_idCseGb2pkncjeE_6panics }>, align 8, !guid !70
@alloc_37d2e53432a03a1f90b3e7253015eaf9 = private unnamed_addr constant [4 x i8] c"None", align 1, !guid !71
@alloc_9535bf4c204f3eb9b19ec2c83e446e52 = private unnamed_addr constant [4 x i8] c"Some", align 1, !guid !72
@vtable.5 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !73
@vtable.6 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !74
@alloc_ae6dc619079e3c3b08144a35532ecff7 = private unnamed_addr constant [2 x i8] c"()", align 1, !guid !75
@alloc_c73d17da7498663a071b898ac2218935 = private unnamed_addr constant [2 x i8] c"Ok", align 1, !guid !76
@vtable.7 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !77
@alloc_bf301217d548e4f1fd13189dd935c554 = private unnamed_addr constant [3 x i8] c"Err", align 1, !guid !78
@vtable.8 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !79
@vtable.9 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !80
@vtable.a = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRuNtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !81
@vtable.b = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionyENtB6_5Debug3fmtCseGb2pkncjeE_6panics }>, align 8, !guid !82

; <[u8]>::to_vec_in::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !88 {
start:
; call <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
  call void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECseGb2pkncjeE_6panics(ptr %0) unnamed_addr #0 !guid !89 {
start:
  %_6 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_6, align 1
  store i8 1, ptr %_6, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  store ptr null, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_6, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %7 = load ptr, ptr %_0, align 8
  ret ptr %7

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !90 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
  call void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#0}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4main00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !91 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#0}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4main00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#7}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4mains5_00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !92 {
start:
  %_8 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %x = load ptr, ptr %self, align 8
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#7}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4mains5_00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %x) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %5 = load i8, ptr %_8, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u8>>::map::<i32, panics::main::{closure#6}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE3maplNCNvCseGb2pkncjeE_6panics4mains4_0EBT_(i1 zeroext %0, i8 %1) unnamed_addr #0 !guid !93 {
start:
  %_8 = alloca [1 x i8], align 1
  %_0 = alloca [8 x i8], align 4
  %self = alloca [2 x i8], align 1
  %2 = zext i1 %0 to i8
  store i8 %2, ptr %self, align 1
  %3 = getelementptr inbounds i8, ptr %self, i64 1
  store i8 %1, ptr %3, align 1
  store i8 0, ptr %_8, align 1
  store i8 1, ptr %_8, align 1
  %4 = load i8, ptr %self, align 1
  %5 = trunc nuw i8 %4 to i1
  %6 = getelementptr inbounds i8, ptr %self, i64 1
  %7 = load i8, ptr %6, align 1
  %_3 = zext i1 %5 to i64
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %9 = getelementptr inbounds i8, ptr %self, i64 1
  %x = load i8, ptr %9, align 1
  store i8 0, ptr %_8, align 1
; call panics::main::{closure#6}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains4_0B3_(i8 %x) #25
  %10 = getelementptr inbounds i8, ptr %_0, i64 4
  store i32 %_5, ptr %10, align 4
  store i32 1, ptr %_0, align 4
  br label %bb7

bb2:                                              ; preds = %start
  store i32 0, ptr %_0, align 4
  br label %bb7

bb7:                                              ; preds = %bb3, %bb2
  %11 = load i8, ptr %_8, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %13 = load i32, ptr %_0, align 4
  %14 = getelementptr inbounds i8, ptr %_0, i64 4
  %15 = load i32, ptr %14, align 4
  %16 = insertvalue { i32, i32 } poison, i32 %13, 0
  %17 = insertvalue { i32, i32 } %16, i32 %15, 1
  ret { i32, i32 } %17

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<alloc::boxed::Box<alloc::string::String>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<alloc::string::String, panics::main::{closure#8}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxNtNtBN_6string6StringEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapB1h_NCNCNvCseGb2pkncjeE_6panics4mains6_00EB2z_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !94 {
start:
  %_9 = alloca [1 x i8], align 1
  %_5 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %e.0, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %5, i64 8
  store ptr %e.1, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load ptr, ptr %7, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#8}::{closure#0}
  call void @_RNCNCNvCseGb2pkncjeE_6panics4mains6_00B5_(ptr sret([24 x i8]) align 8 %_5, ptr align 8 %t) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_9, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<alloc::boxed::Box<u64>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<u64, panics::main::{closure#9}::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxyEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapyNCNCNvCseGb2pkncjeE_6panics4mains7_00EB2c_(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !95 {
start:
  %_9 = alloca [1 x i8], align 1
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store ptr %e.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %e.1, ptr %5, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load ptr, ptr %6, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#9}::{closure#0}
  %_5 = call i64 @_RNCNCNvCseGb2pkncjeE_6panics4mains7_00B5_(ptr align 8 %t) #25
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5, ptr %7, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_9, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, i64 %0, i64 %1) unnamed_addr #0 !guid !96 {
start:
  %_9 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load i64, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = icmp eq i64 %3, 0
  %_3 = select i1 %6, i64 1, i64 0
  %7 = trunc nuw i64 %_3 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i8 0, ptr %_9, align 1
; call alloc::raw_vec::layout_array::{closure#0}
  %8 = call { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CseGb2pkncjeE_6panics() #25
  %_6.0 = extractvalue { i64, i64 } %8, 0
  %_6.1 = extractvalue { i64, i64 } %8, 1
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.0, ptr %9, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 8
  store i64 %_6.1, ptr %10, align 8
  store i64 1, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %t.0 = load i64, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %t.1 = load i64, ptr %11, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %t.0, ptr %12, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store i64 %t.1, ptr %13, align 8
  store i64 0, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %14 = load i8, ptr %_9, align 1
  %15 = trunc nuw i8 %14 to i1
  br i1 %15, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#7}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains5_0EB2Q_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !97 {
start:
  %_9 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#7}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains5_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr %e.0, ptr align 8 %e.1) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i8, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %t, ptr %6, align 8
  store i64 -2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#8}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains6_0EB2Q_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !98 {
start:
  %_9 = alloca [1 x i8], align 1
  %_6 = alloca [24 x i8], align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %4, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#8}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains6_0B3_(ptr sret([24 x i8]) align 8 %_6, ptr %e.0, ptr align 8 %e.1) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_6, i64 24, i1 false)
  br label %bb7

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %t = load i32, ptr %5, align 8
  %6 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %t, ptr %6, align 8
  store i64 -2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_9, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  ret void

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<u64>, panics::main::{closure#9}>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionyENCNvCseGb2pkncjeE_6panics4mains7_0EB2w_(ptr %0, ptr %1) unnamed_addr #0 !guid !99 {
start:
  %_9 = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %2, align 8
  store i8 0, ptr %_9, align 1
  store i8 1, ptr %_9, align 1
  %3 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = ptrtoint ptr %3 to i64
  %7 = icmp eq i64 %6, 0
  %_3 = select i1 %7, i64 0, i64 1
  %8 = trunc nuw i64 %_3 to i1
  br i1 %8, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %e.0 = load ptr, ptr %self, align 8
  %9 = getelementptr inbounds i8, ptr %self, i64 8
  %e.1 = load ptr, ptr %9, align 8
  store i8 0, ptr %_9, align 1
; call panics::main::{closure#9}
  %10 = call { i64, i64 } @_RNCNvCseGb2pkncjeE_6panics4mains7_0B3_(ptr %e.0, ptr align 8 %e.1) #25
  %_6.0 = extractvalue { i64, i64 } %10, 0
  %_6.1 = extractvalue { i64, i64 } %10, 1
  store i64 %_6.0, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_6.1, ptr %11, align 8
  br label %bb7

bb3:                                              ; preds = %start
  store i64 2, ptr %_0, align 8
  br label %bb7

bb7:                                              ; preds = %bb2, %bb3
  %12 = load i8, ptr %_9, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb6, label %bb5

bb5:                                              ; preds = %bb6, %bb7
  %14 = load i64, ptr %_0, align 8
  %15 = getelementptr inbounds i8, ptr %_0, i64 8
  %16 = load i64, ptr %15, align 8
  %17 = insertvalue { i64, i64 } poison, i64 %14, 0
  %18 = insertvalue { i64, i64 } %17, i64 %16, 1
  ret { i64, i64 } %18

bb6:                                              ; preds = %bb7
  br label %bb5

bb1:                                              ; No predecessors!
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !100 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %x) unnamed_addr #0 !guid !101 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<bool>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseGb2pkncjeE_6panics(ptr %x) #25
; call <core::ptr::non_null::NonNull<bool>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_display::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 4 %x) unnamed_addr #0 !guid !102 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<i32>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCseGb2pkncjeE_6panics(ptr align 4 %x) #25
; call <core::ptr::non_null::NonNull<i32>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !103 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !104 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::rt::Argument>::new_debug::<core::result::Result<(), core::option::Option<u64>>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultuINtNtB7_6option6OptionyEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 !guid !105 {
start:
  %_2 = alloca [16 x i8], align 8
; call <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::from_ref
  %_4 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultuINtNtB9_6option6OptionyEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %x) #25
; call <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::cast::<()>
  %_3 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultuINtNtBa_6option6OptionyEEE4castuECseGb2pkncjeE_6panics(ptr %_4) #25
  store ptr %_3, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtB7_6option6OptionyEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDG0_INtNtNtB7_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB7_6marker4SyncNtB2D_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !106 {
start:
; call core::mem::align_of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2h_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<dyn core::any::Any + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_3any3AnyNtNtB7_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !107 {
start:
; call core::mem::align_of_val_raw::<dyn core::any::Any + core::marker::Send>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !108 {
start:
; call core::mem::align_of_val_raw::<alloc::string::String>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !109 {
start:
; call core::mem::align_of_val_raw::<u64>
  %align = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::mem::alignment::Alignment>::new_unchecked
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_acba356d0d418ecf2dce0d26c62c4b8f) #25
  ret i64 %_0
}

; <core::mem::alignment::Alignment>::of::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECseGb2pkncjeE_6panics() unnamed_addr #0 !guid !110 {
start:
  ret i64 1
}

; <core::mem::alignment::Alignment>::of::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofmECseGb2pkncjeE_6panics() unnamed_addr #0 !guid !111 {
start:
  ret i64 4
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDG0_INtNtNtB7_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB7_6marker4SyncNtB2C_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !112 {
start:
; call core::mem::size_of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2g_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDG0_INtNtNtB7_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB7_6marker4SyncNtB2D_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<dyn core::any::Any + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_3any3AnyNtNtB7_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !113 {
start:
; call core::mem::size_of_val_raw::<dyn core::any::Any + core::marker::Send>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<dyn core::any::Any + core::marker::Send>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawDNtNtB7_3any3AnyNtNtB7_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !114 {
start:
; call core::mem::size_of_val_raw::<alloc::string::String>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<alloc::string::String>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::for_value_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !115 {
start:
; call core::mem::size_of_val_raw::<u64>
  %_5 = call i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::mem::alignment::Alignment>::of_val_raw::<u64>
  %_6 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment10of_val_rawyECseGb2pkncjeE_6panics(ptr %val) #25
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked
  %0 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %_5, i64 %_6, ptr align 8 @alloc_36bf30472af6160b1c846dd09f0e2d85) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::ptr::unique::Unique<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDG0_INtNtNtBa_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBa_6marker4SyncNtB2p_4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !116 {
start:
; call <core::ptr::non_null::NonNull<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDG0_INtNtNtBa_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBa_6marker4SyncNtB2s_4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<dyn core::any::Any + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_3any3AnyNtNtBa_6marker4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !117 {
start:
; call <core::ptr::non_null::NonNull<dyn core::any::Any + core::marker::Send>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_3any3AnyNtNtBa_6marker4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<alloc::string::String>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !118 {
start:
; call <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !119 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECseGb2pkncjeE_6panics(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u8>>::cast::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castmECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !120 {
start:
; call <core::ptr::non_null::NonNull<u8>>::cast::<u32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castmECseGb2pkncjeE_6panics(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u64>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueyE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !121 {
start:
; call <core::ptr::non_null::NonNull<u64>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4casthECseGb2pkncjeE_6panics(ptr %self) #25
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDG0_INtNtNtBa_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBa_6marker4SyncNtB2s_4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !122 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<dyn core::any::Any + core::marker::Send>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullDNtNtBa_3any3AnyNtNtBa_6marker4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !123 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResulthINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !124 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultlINtNtBa_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !125 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullINtNtBa_6result6ResultuINtNtBa_6option6OptionyEEE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !126 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !127 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !128 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !129 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  ret ptr %_3.0
}

; <core::ptr::non_null::NonNull<bool>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullbE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !130 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !131 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u8>>::cast::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullhE4castmECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !132 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<i32>>::cast::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNulllE4castuECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !133 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<u64>>::cast::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullyE4casthECseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !134 {
start:
  ret ptr %self
}

; <alloc::raw_vec::RawVecInner>::ptr::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !135 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u8>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::ptr::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrmECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !136 {
start:
; call <alloc::raw_vec::RawVecInner>::non_null::<u32>
  %_2 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullmECseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::raw_vec::RawVecInner>::non_null::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullhECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !137 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u8>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4casthECseGb2pkncjeE_6panics(ptr %_3) #25
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %_2) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::non_null::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner8non_nullmECseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !138 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_3 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<u8>>::cast::<u32>
  %_2 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniquehE4castmECseGb2pkncjeE_6panics(ptr %_3) #25
; call <core::ptr::unique::Unique<u32>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquemE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %_2) #25
  ret ptr %_0
}

; <dyn core::any::Any>::downcast_ref::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !139 {
start:
  %_0 = alloca [8 x i8], align 8
; call <dyn core::any::Any>::is::<alloc::string::String>
  %_2 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <dyn core::any::Any>::downcast_unchecked_ref::<alloc::string::String>
  %_3 = call align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <dyn core::any::Any>::downcast_ref::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !140 {
start:
  %_0 = alloca [8 x i8], align 8
; call <dyn core::any::Any>::is::<&str>
  %_2 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <dyn core::any::Any>::downcast_unchecked_ref::<&str>
  %_3 = call align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <dyn core::any::Any>::downcast_unchecked_ref::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !141 {
start:
  ret ptr %self.0
}

; <dyn core::any::Any>::downcast_unchecked_ref::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_22downcast_unchecked_refReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !142 {
start:
  ret ptr %self.0
}

; <dyn core::any::Any>::is::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !143 {
start:
  %concrete = alloca [16 x i8], align 8
  %t = alloca [16 x i8], align 8
; call <core::any::TypeId>::of::<alloc::string::String>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %t)
  %0 = getelementptr inbounds i8, ptr %self.1, i64 24
  %1 = load ptr, ptr %0, align 8, !invariant.load !144, !nonnull !144
  call void %1(ptr sret([16 x i8]) align 8 %concrete, ptr %self.0) #25
; call <core::any::TypeId as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %t, ptr align 8 %concrete) #25
  ret i1 %_0
}

; <dyn core::any::Any>::is::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !145 {
start:
  %concrete = alloca [16 x i8], align 8
  %t = alloca [16 x i8], align 8
; call <core::any::TypeId>::of::<&str>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofReECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %t)
  %0 = getelementptr inbounds i8, ptr %self.1, i64 24
  %1 = load ptr, ptr %0, align 8, !invariant.load !144, !nonnull !144
  call void %1(ptr sret([16 x i8]) align 8 %concrete, ptr %self.0) #25
; call <core::any::TypeId as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %t, ptr align 8 %concrete) #25
  ret i1 %_0
}

; <dyn core::any::Any>::is::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !146 {
start:
  %concrete = alloca [16 x i8], align 8
  %t = alloca [16 x i8], align 8
; call <core::any::TypeId>::of::<u64>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %t)
  %0 = getelementptr inbounds i8, ptr %self.1, i64 24
  %1 = load ptr, ptr %0, align 8, !invariant.load !144, !nonnull !144
  call void %1(ptr sret([16 x i8]) align 8 %concrete, ptr %self.0) #25
; call <core::any::TypeId as core::cmp::PartialEq>::eq
  %_0 = call zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %t, ptr align 8 %concrete) #25
  ret i1 %_0
}

; <core::fmt::Arguments>::new::<10, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !147 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<11, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !148 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<13, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !149 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<15, 1>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECseGb2pkncjeE_6panics(ptr %template, ptr align 8 %args) unnamed_addr #0 !guid !150 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !151 {
start:
; call <dyn core::any::Any>::downcast_ref::<alloc::string::String>
  %_0 = call align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_0
}

; <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !152 {
start:
; call <dyn core::any::Any>::downcast_ref::<&str>
  %_0 = call align 8 ptr @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_12downcast_refReECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret ptr %_0
}

; <dyn core::any::Any + core::marker::Send>::is::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !153 {
start:
; call <dyn core::any::Any>::is::<alloc::string::String>
  %_0 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret i1 %_0
}

; <dyn core::any::Any + core::marker::Send>::is::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !154 {
start:
; call <dyn core::any::Any>::is::<u64>
  %_0 = call zeroext i1 @_RINvMs2_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyEL_2isyECseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) #25
  ret i1 %_0
}

; <core::any::TypeId>::of::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !155 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.fc6ebcf9488fce9791a3e964855a907f.0, i64 16, i1 false)
  ret void
}

; <core::any::TypeId>::of::<&str>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofReECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !156 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.fc6ebcf9488fce9791a3e964855a907f.1, i64 16, i1 false)
  ret void
}

; <core::any::TypeId>::of::<u64>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !157 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 @anon.fc6ebcf9488fce9791a3e964855a907f.2, i64 16, i1 false)
  ret void
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !158 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
  %5 = invoke { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; invoke <alloc::boxed::Box<alloc::string::String>>::from_raw_in
  %_0 = invoke align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringE11from_raw_inCseGb2pkncjeE_6panics(ptr %_4.0)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret ptr %_0

bb3:                                              ; preds = %bb4, %bb5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %2, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %self) #26
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedyECseGb2pkncjeE_6panics(ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !159 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
  %5 = invoke { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb5:                                              ; preds = %cleanup
  %6 = load i8, ptr %_7, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb4, label %bb3

cleanup:                                          ; preds = %bb1, %start
  %8 = landingpad { ptr, i32 }
          cleanup
  %9 = extractvalue { ptr, i32 } %8, 0
  %10 = extractvalue { ptr, i32 } %8, 1
  store ptr %9, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %10, ptr %11, align 8
  br label %bb5

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { ptr, ptr } %5, 0
  %_4.1 = extractvalue { ptr, ptr } %5, 1
; invoke <alloc::boxed::Box<u64>>::from_raw_in
  %_0 = invoke align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyE11from_raw_inCseGb2pkncjeE_6panics(ptr %_4.0)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
  ret ptr %_0

bb3:                                              ; preds = %bb4, %bb5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %2, i64 8
  %14 = load i32, ptr %13, align 8
  %15 = insertvalue { ptr, i32 } poison, ptr %12, 0
  %16 = insertvalue { ptr, i32 } %15, i32 %14, 1
  resume { ptr, i32 } %16

bb4:                                              ; preds = %bb5
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %self) #26
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb4
  %17 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !160 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %_8.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::is::<alloc::string::String>
  %_2 = invoke zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %_8.0, ptr align 8 %_8.1)
          to label %bb1 unwind label %cleanup

bb8:                                              ; preds = %cleanup
  %5 = load i8, ptr %_7, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb7, label %bb6

cleanup:                                          ; preds = %bb2, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_6.0 = load ptr, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %_6.1 = load ptr, ptr %11, align 8
  store ptr %_6.0, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_6.1, ptr %12, align 8
  br label %bb5

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %13, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<alloc::string::String>
  %_4 = invoke align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb3 unwind label %cleanup

bb5:                                              ; preds = %bb3, %bb4
  ret void

bb3:                                              ; preds = %bb2
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_4, ptr %14, align 8
  store ptr null, ptr %_0, align 8
  br label %bb5

bb6:                                              ; preds = %bb7, %bb8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb7:                                              ; preds = %bb8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %self) #26
          to label %bb6 unwind label %terminate

terminate:                                        ; preds = %bb7
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !161 {
start:
  %2 = alloca [16 x i8], align 8
  %_7 = alloca [1 x i8], align 1
  %self = alloca [16 x i8], align 8
  store ptr %0, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %1, ptr %3, align 8
  store i8 0, ptr %_7, align 1
  store i8 1, ptr %_7, align 1
  %_8.0 = load ptr, ptr %self, align 8
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %_8.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::is::<u64>
  %_2 = invoke zeroext i1 @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_2isyECseGb2pkncjeE_6panics(ptr %_8.0, ptr align 8 %_8.1)
          to label %bb1 unwind label %cleanup

bb8:                                              ; preds = %cleanup
  %5 = load i8, ptr %_7, align 1
  %6 = trunc nuw i8 %5 to i1
  br i1 %6, label %bb7, label %bb6

cleanup:                                          ; preds = %bb2, %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_6.0 = load ptr, ptr %self, align 8
  %11 = getelementptr inbounds i8, ptr %self, i64 8
  %_6.1 = load ptr, ptr %11, align 8
  store ptr %_6.0, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_6.1, ptr %12, align 8
  br label %bb5

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_7, align 1
  %_5.0 = load ptr, ptr %self, align 8
  %13 = getelementptr inbounds i8, ptr %self, i64 8
  %_5.1 = load ptr, ptr %13, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast_unchecked::<u64>
  %_4 = invoke align 8 ptr @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E18downcast_uncheckedyECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb3 unwind label %cleanup

bb5:                                              ; preds = %bb3, %bb4
  ret void

bb3:                                              ; preds = %bb2
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_4, ptr %14, align 8
  store ptr null, ptr %_0, align 8
  br label %bb5

bb6:                                              ; preds = %bb7, %bb8
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds i8, ptr %2, i64 8
  %17 = load i32, ptr %16, align 8
  %18 = insertvalue { ptr, i32 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i32 } %18, i32 %17, 1
  resume { ptr, i32 } %19

bb7:                                              ; preds = %bb8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %self) #26
          to label %bb6 unwind label %terminate

terminate:                                        ; preds = %bb7
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseGb2pkncjeE_6panics(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 !guid !162 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; std::panic::catch_unwind::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCseGb2pkncjeE_6panics4mains3_00hEBM_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !163 {
start:
; call std::panicking::catch_unwind::<u8, panics::main::{closure#5}::{closure#0}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNCNvCseGb2pkncjeE_6panics4mains3_00EBR_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#2}, u8>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains0_0hEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !164 {
start:
; call std::panicking::catch_unwind::<u8, panics::main::{closure#2}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNvCseGb2pkncjeE_6panics4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#3}, i32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains1_0lEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !165 {
start:
; call std::panicking::catch_unwind::<i32, panics::main::{closure#3}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCseGb2pkncjeE_6panics4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#4}, ()>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains2_0uEBK_() unnamed_addr #1 !guid !166 {
start:
; call std::panicking::catch_unwind::<(), panics::main::{closure#4}>
  %0 = call { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCseGb2pkncjeE_6panics4mains2_0EBP_()
  %_0.0 = extractvalue { ptr, ptr } %0, 0
  %_0.1 = extractvalue { ptr, ptr } %0, 1
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; std::panic::catch_unwind::<panics::main::{closure#5}, bool>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains3_0bEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !167 {
start:
; call std::panicking::catch_unwind::<bool, panics::main::{closure#5}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindbNCNvCseGb2pkncjeE_6panics4mains3_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::catch_unwind::<panics::main::{closure#1}, u32>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains_0mEBK_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !168 {
start:
; call std::panicking::catch_unwind::<u32, panics::main::{closure#1}>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCseGb2pkncjeE_6panics4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; std::panic::panic_any::<u64>
; Function Attrs: inlinehint noreturn nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std5panic9panic_anyyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) unnamed_addr #2 !guid !169 {
start:
; call std::panicking::begin_panic::<u64>
  call void @_RINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) #28
  unreachable
}

; std::panicking::begin_panic::<u64>
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyECseGb2pkncjeE_6panics(i64 %msg, ptr align 8 %0) unnamed_addr #3 personality ptr @rust_eh_personality !guid !170 {
start:
  %_4 = alloca [1 x i8], align 1
  store i8 0, ptr %_4, align 1
  store i8 1, ptr %_4, align 1
; call <core::panic::location::Location>::caller
  %loc = call align 8 ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core5panic8locationNtB5_8Location6callerCseGb2pkncjeE_6panics(ptr align 8 %0) #25
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_4, align 1
; call std::sys::backtrace::__rust_end_short_backtrace::<std::panicking::begin_panic<u64>::{closure#0}, !>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace26___rust_end_short_backtraceNCINvNtB6_9panicking11begin_panicyE0zECseGb2pkncjeE_6panics(ptr align 8 %loc, i64 %msg) #28
  unreachable

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::panicking::catch_unwind::<bool, panics::main::{closure#5}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindbNCNvCseGb2pkncjeE_6panics4mains3_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !171 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains3_0bEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains3_0bEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %0 = load i8, ptr %data, align 8
  %_11 = trunc nuw i8 %0 to i1
  store i8 %0, ptr %slot.i1, align 1
  %1 = load i8, ptr %slot.i1, align 1
  %_0.i.i = trunc nuw i8 %1 to i1
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = zext i1 %_0.i.i to i8
  store i8 %3, ptr %2, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %4 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %4, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %5 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %5, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %6 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %6, align 8
  %7 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %8 = insertvalue { ptr, ptr } %7, ptr %_0.1.i.i, 1
  %9 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %10 = insertvalue { ptr, ptr } %9, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %10, 0
  %_0.1.i = extractvalue { ptr, ptr } %10, 1
  %_8.0 = extractvalue { ptr, ptr } %10, 0
  %_8.1 = extractvalue { ptr, ptr } %10, 1
  store ptr %_8.0, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %11, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u8, panics::main::{closure#5}::{closure#0}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNCNvCseGb2pkncjeE_6panics4mains3_00EBR_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !172 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E3newB1a_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB10_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB11_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i8, ptr %data, align 8
  store i8 %_11, ptr %slot.i1, align 1
  %_0.i.i = load i8, ptr %slot.i1, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u8, panics::main::{closure#2}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindhNCNvCseGb2pkncjeE_6panics4mains0_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !173 {
start:
  %slot.i1 = alloca [1 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains0_0hEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains0_0hEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i8, ptr %data, align 8
  store i8 %_11, ptr %slot.i1, align 1
  %_0.i.i = load i8, ptr %slot.i1, align 1
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i8 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<i32, panics::main::{closure#3}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindlNCNvCseGb2pkncjeE_6panics4mains1_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !174 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains1_0lEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains1_0lEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<u32, panics::main::{closure#1}>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwindmNCNvCseGb2pkncjeE_6panics4mains_0EBP_(ptr sret([16 x i8]) align 8 %_0) unnamed_addr #1 !guid !175 {
start:
  %slot.i1 = alloca [4 x i8], align 4
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains_0mEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains_0mEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  %_11 = load i32, ptr %data, align 8
  store i32 %_11, ptr %slot.i1, align 4
  %_0.i.i = load i32, ptr %slot.i1, align 4
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i32 %_0.i.i, ptr %0, align 8
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %1 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %1, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %2, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %3 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %3, align 8
  %4 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %5 = insertvalue { ptr, ptr } %4, ptr %_0.1.i.i, 1
  %6 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %7 = insertvalue { ptr, ptr } %6, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %7, 0
  %_0.1.i = extractvalue { ptr, ptr } %7, 1
  %_8.0 = extractvalue { ptr, ptr } %7, 0
  %_8.1 = extractvalue { ptr, ptr } %7, 1
  store ptr %_8.0, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %8, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  ret void
}

; std::panicking::catch_unwind::<(), panics::main::{closure#4}>
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std9panicking12catch_unwinduNCNvCseGb2pkncjeE_6panics4mains2_0EBP_() unnamed_addr #1 !guid !176 {
start:
  %slot.i1 = alloca [0 x i8], align 1
  %slot.i = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E3newB18_()
  %_4 = call i1 @__rust_try(ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains2_0uEBY_, ptr %data, ptr @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains2_0uEBZ_)
  br i1 %_4, label %bb3, label %bb5

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb3:                                              ; preds = %start
  %_9.0 = load ptr, ptr %data, align 8
  %0 = getelementptr inbounds i8, ptr %data, i64 8
  %_9.1 = load ptr, ptr %0, align 8
  store ptr %_9.0, ptr %slot.i, align 8
  %1 = getelementptr inbounds i8, ptr %slot.i, i64 8
  store ptr %_9.1, ptr %1, align 8
  %_0.0.i.i = load ptr, ptr %slot.i, align 8
  %2 = getelementptr inbounds i8, ptr %slot.i, i64 8
  %_0.1.i.i = load ptr, ptr %2, align 8
  %3 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %4 = insertvalue { ptr, ptr } %3, ptr %_0.1.i.i, 1
  %5 = insertvalue { ptr, ptr } poison, ptr %_0.0.i.i, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_0.1.i.i, 1
  %_0.0.i = extractvalue { ptr, ptr } %6, 0
  %_0.1.i = extractvalue { ptr, ptr } %6, 1
  %_8.0 = extractvalue { ptr, ptr } %6, 0
  %_8.1 = extractvalue { ptr, ptr } %6, 1
  store ptr %_8.0, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_8.1, ptr %7, align 8
  br label %bb7

bb7:                                              ; preds = %bb3, %bb5
  %8 = load ptr, ptr %_0, align 8
  %9 = getelementptr inbounds i8, ptr %_0, i64 8
  %10 = load ptr, ptr %9, align 8
  %11 = insertvalue { ptr, ptr } poison, ptr %8, 0
  %12 = insertvalue { ptr, ptr } %11, ptr %10, 1
  ret { ptr, ptr } %12
}

; core::mem::size_of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2g_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !177 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !144
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !144
  ret i64 %_0
}

; core::mem::size_of_val_raw::<dyn core::any::Any + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !178 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %_0 = load i64, ptr %0, align 8, !invariant.load !144
  %1 = getelementptr inbounds i8, ptr %val.1, i64 16
  %2 = load i64, ptr %1, align 8, !invariant.load !144
  ret i64 %_0
}

; core::mem::size_of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !179 {
start:
  ret i64 24
}

; core::mem::size_of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem15size_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !180 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2h_4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !181 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !144
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !144
  ret i64 %_0
}

; core::mem::align_of_val_raw::<dyn core::any::Any + core::marker::Send>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %val.0, ptr align 8 %val.1) unnamed_addr #0 !guid !182 {
start:
  %0 = getelementptr inbounds i8, ptr %val.1, i64 8
  %1 = load i64, ptr %0, align 8, !invariant.load !144
  %2 = getelementptr inbounds i8, ptr %val.1, i64 16
  %_0 = load i64, ptr %2, align 8, !invariant.load !144
  ret i64 %_0
}

; core::mem::align_of_val_raw::<alloc::string::String>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !183 {
start:
  ret i64 8
}

; core::mem::align_of_val_raw::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core3mem16align_of_val_rawyECseGb2pkncjeE_6panics(ptr %val) unnamed_addr #0 !guid !184 {
start:
  ret i64 8
}

; core::mem::replace::<core::option::Option<u64>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionyEECseGb2pkncjeE_6panics(ptr align 8 %dest, i64 %src.0, i64 %src.1) unnamed_addr #0 !guid !185 {
start:
  %result.0 = load i64, ptr %dest, align 8
  %0 = getelementptr inbounds i8, ptr %dest, i64 8
  %result.1 = load i64, ptr %0, align 8
  store i64 %src.0, ptr %dest, align 8
  %1 = getelementptr inbounds i8, ptr %dest, i64 8
  store i64 %src.1, ptr %1, align 8
  %2 = insertvalue { i64, i64 } poison, i64 %result.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %result.1, 1
  ret { i64, i64 } %3
}

; core::ptr::slice_from_raw_parts_mut::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECseGb2pkncjeE_6panics(ptr %data, i64 %len) unnamed_addr #0 !guid !186 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECseGb2pkncjeE_6panics(ptr %data, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::slice_from_raw_parts_mut::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutmECseGb2pkncjeE_6panics(ptr %data, i64 %len) unnamed_addr #0 !guid !187 {
start:
; call core::ptr::metadata::from_raw_parts_mut::<[u32], u32>
  %0 = call { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSmmECseGb2pkncjeE_6panics(ptr %data, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; core::ptr::drop_glue::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB29_4SendEL_ECseGb2pkncjeE_6panics(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !188 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !144
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #25
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<dyn core::any::Any + core::marker::Send>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %_1.0, ptr align 8 %_1.1) unnamed_addr #1 !guid !189 {
start:
  %0 = getelementptr inbounds i8, ptr %_1.1, i64 0
  %1 = load ptr, ptr %0, align 8, !invariant.load !144
  %2 = icmp ne ptr %1, null
  br i1 %2, label %is_not_null, label %bb1

is_not_null:                                      ; preds = %start
  call void %1(ptr %_1.0) #25
  br label %bb1

bb1:                                              ; preds = %is_not_null, %start
  ret void
}

; core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !190 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtB11_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !191 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %3)
  br label %bb1

bb1:                                              ; preds = %bb3, %bb2
  ret void
}

; core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !192 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -2
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !193 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !194 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -2
  %_2 = select i1 %1, i64 0, i64 1
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !195 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !196 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !197 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECseGb2pkncjeE_6panics(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::vec::Vec<u32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !198 {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<u32> as core::ops::drop::Drop>::drop
  invoke void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !199 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !144
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDG0_INtNtNtCsl10jNU3mE6R_4core3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBS_6marker4SyncNtB2v_4SendEL_ENtNtBQ_4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #25
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDG0_INtNtNtCsl10jNU3mE6R_4core3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBS_6marker4SyncNtB2v_4SendEL_ENtNtBQ_4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !200 {
start:
  %0 = alloca [16 x i8], align 8
  %_6.0 = load ptr, ptr %_1, align 8
  %1 = getelementptr inbounds i8, ptr %_1, i64 8
  %_6.1 = load ptr, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_6.1, i64 0
  %3 = load ptr, ptr %2, align 8, !invariant.load !144
  %4 = icmp ne ptr %3, null
  br i1 %4, label %is_not_null, label %bb3

is_not_null:                                      ; preds = %start
  invoke void %3(ptr %_6.0)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %is_not_null, %start
; call <alloc::boxed::Box<dyn core::any::Any + core::marker::Send> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #25
  ret void

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

cleanup:                                          ; preds = %is_not_null
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; preds = %bb4
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr inbounds i8, ptr %0, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; core::ptr::drop_glue::<alloc::boxed::Box<u64>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxyEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !201 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
  br label %bb3

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #25
  ret void

bb4:                                              ; No predecessors!
; invoke <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1) #26
          to label %bb2 unwind label %terminate

terminate:                                        ; preds = %bb4
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; preds = %bb4
  %2 = load ptr, ptr %0, align 8
  %3 = getelementptr inbounds i8, ptr %0, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u8>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVechEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !202 {
start:
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<u32>>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc7raw_vec6RawVecmEECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !203 {
start:
; call <alloc::raw_vec::RawVec<u32> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::string::String>
; Function Attrs: nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #1 !guid !204 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECseGb2pkncjeE_6panics(ptr align 8 %_1)
  ret void
}

; core::hint::black_box::<core::option::Option<u8>>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECseGb2pkncjeE_6panics(i1 zeroext %dummy.0, i8 %dummy.1) unnamed_addr #0 !guid !205 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = zext i1 %dummy.0 to i8
  store i8 %0, ptr %_0, align 1
  %1 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 %dummy.1, ptr %1, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %2 = load i8, ptr %_0, align 1
  %3 = trunc nuw i8 %2 to i1
  %4 = getelementptr inbounds i8, ptr %_0, i64 1
  %5 = load i8, ptr %4, align 1
  %6 = insertvalue { i1, i8 } poison, i1 %3, 0
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1
  ret { i1, i8 } %7
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 %dummy) unnamed_addr #0 !guid !207 {
start:
  %_0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %_0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %0 = load i8, ptr %_0, align 1
  ret i8 %0
}

; core::hint::black_box::<usize>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECseGb2pkncjeE_6panics(i64 %dummy) unnamed_addr #0 !guid !208 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; core::hint::black_box::<i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseGb2pkncjeE_6panics(i32 %dummy) unnamed_addr #0 !guid !209 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseGb2pkncjeE_6panics(i32 %dummy) unnamed_addr #0 !guid !210 {
start:
  %_0 = alloca [4 x i8], align 4
  store i32 %dummy, ptr %_0, align 4
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; core::hint::black_box::<()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECseGb2pkncjeE_6panics() unnamed_addr #0 !guid !211 {
start:
  %_0 = alloca [0 x i8], align 1
  call void asm sideeffect "", "~{memory}"(), !srcloc !206
  ret void
}

; core::hint::black_box::<u64>
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECseGb2pkncjeE_6panics(i64 %dummy) unnamed_addr #0 !guid !212 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %dummy, ptr %_0, align 8
  call void asm sideeffect "", "r,~{memory}"(ptr %_0), !srcloc !206
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; std::sys::backtrace::__rust_end_short_backtrace::<std::panicking::begin_panic<u64>::{closure#0}, !>
; Function Attrs: noinline noreturn nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace26___rust_end_short_backtraceNCINvNtB6_9panicking11begin_panicyE0zECseGb2pkncjeE_6panics(ptr align 8 %f.0, i64 %f.1) unnamed_addr #4 personality ptr @rust_eh_personality !guid !213 {
start:
; call std::panicking::begin_panic::<u64>::{closure#0}
  call void @_RNCINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyE0CseGb2pkncjeE_6panics(ptr align 8 %f.0, i64 %f.1) #29
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECseGb2pkncjeE_6panics() #25
  br label %bb2

bb2:                                              ; preds = %start
  call void @llvm.trap()
  unreachable

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define internal void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseGb2pkncjeE_6panics(ptr %f) unnamed_addr #5 personality ptr @rust_eh_personality !guid !214 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %f) #25
; call core::hint::black_box::<()>
  call void @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxuECseGb2pkncjeE_6panics() #25
  br label %bb2

bb2:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; core::ptr::metadata::from_raw_parts_mut::<[u8], u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutShhECseGb2pkncjeE_6panics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !215 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; core::ptr::metadata::from_raw_parts_mut::<[u32], u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RINvNtNtCsl10jNU3mE6R_4core3ptr8metadata18from_raw_parts_mutSmmECseGb2pkncjeE_6panics(ptr %data_pointer, i64 %metadata) unnamed_addr #0 !guid !216 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %data_pointer, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %metadata, 1
  ret { ptr, i64 } %1
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB10_(ptr %data) unnamed_addr #0 !guid !217 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}::{closure#0}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCseGb2pkncjeE_6panics4mains3_00E4takeB18_(ptr %data) #25
; call panics::main::{closure#5}::{closure#0}
  %_5 = call i8 @_RNCNCNvCseGb2pkncjeE_6panics4mains3_00B5_() #25
; call <core::mem::maybe_dangling::MaybeDangling<u8>>::new
  %_2.i = call i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newCseGb2pkncjeE_6panics(i8 %_5)
  store i8 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#2}, u8>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains0_0hEBY_(ptr %data) unnamed_addr #0 !guid !218 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#2}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains0_0E4takeB16_(ptr %data) #25
; call panics::main::{closure#2}
  %_5 = call i8 @_RNCNvCseGb2pkncjeE_6panics4mains0_0B3_() #25
; call <core::mem::maybe_dangling::MaybeDangling<u8>>::new
  %_2.i = call i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newCseGb2pkncjeE_6panics(i8 %_5)
  store i8 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#3}, i32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains1_0lEBY_(ptr %data) unnamed_addr #0 !guid !219 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#3}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains1_0E4takeB16_(ptr %data) #25
; call panics::main::{closure#3}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains1_0B3_() #25
; call <core::mem::maybe_dangling::MaybeDangling<i32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCseGb2pkncjeE_6panics(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#4}, ()>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains2_0uEBY_(ptr %data) unnamed_addr #0 !guid !220 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#4}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains2_0E4takeB16_(ptr %data) #25
; call panics::main::{closure#4}
  call void @_RNCNvCseGb2pkncjeE_6panics4mains2_0B3_() #25
; call <core::mem::maybe_dangling::MaybeDangling<()>>::new
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCseGb2pkncjeE_6panics()
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#5}, bool>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains3_0bEBY_(ptr %data) unnamed_addr #0 !guid !221 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains3_0E4takeB16_(ptr %data) #25
; call panics::main::{closure#5}
  %_5 = call zeroext i1 @_RNCNvCseGb2pkncjeE_6panics4mains3_0B3_() #25
; call <core::mem::maybe_dangling::MaybeDangling<bool>>::new
  %_2.i = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingbE3newCseGb2pkncjeE_6panics(i1 zeroext %_5)
  %0 = zext i1 %_2.i to i8
  store i8 %0, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_call::<panics::main::{closure#1}, u32>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7do_callNCNvCseGb2pkncjeE_6panics4mains_0mEBY_(ptr %data) unnamed_addr #0 !guid !222 {
start:
; call <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#1}>>::take
  call void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains_0E4takeB16_(ptr %data) #25
; call panics::main::{closure#1}
  %_5 = call i32 @_RNCNvCseGb2pkncjeE_6panics4mains_0B3_() #25
; call <core::mem::maybe_dangling::MaybeDangling<u32>>::new
  %_2.i = call i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCseGb2pkncjeE_6panics(i32 %_5)
  store i32 %_2.i, ptr %data, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#5}::{closure#0}, u8>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNCNvCseGb2pkncjeE_6panics4mains3_00hEB11_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !223 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#2}, u8>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains0_0hEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !224 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#3}, i32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains1_0lEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !225 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#4}, ()>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains2_0uEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !226 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#5}, bool>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains3_0bEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !227 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; std::panicking::catch_unwind::do_catch::<panics::main::{closure#1}, u32>
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RINvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind8do_catchNCNvCseGb2pkncjeE_6panics4mains_0mEBZ_(ptr %data, ptr %payload) unnamed_addr #6 personality ptr @rust_eh_personality !guid !228 {
start:
  %0 = alloca [16 x i8], align 8
; invoke std::panicking::catch_unwind::cleanup
  %1 = invoke { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr %payload)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %start
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %obj.0 = extractvalue { ptr, ptr } %1, 0
  %obj.1 = extractvalue { ptr, ptr } %1, 1
; invoke <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %3 = invoke { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %obj.0, ptr align 8 %obj.1)
          to label %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit unwind label %cleanup

_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit: ; preds = %bb1
  %_2.0.i = extractvalue { ptr, ptr } %3, 0
  %_2.1.i = extractvalue { ptr, ptr } %3, 1
  br label %bb2

bb3:                                              ; preds = %cleanup
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #30
  unreachable

cleanup:                                          ; preds = %bb1
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb3

bb2:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics.exit
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
  store ptr %_4.0, ptr %data, align 8
  %8 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr %_4.1, ptr %8, align 8
  ret void
}

; <u8 as <[_]>::to_vec_in::ConvertVec>::to_vec::<alloc::alloc::Global>
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RINvXs_NvMNtCs7CppTae75M1_5alloc5sliceSp9to_vec_inhNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !229 {
start:
  %0 = alloca [16 x i8], align 8
  %_13 = alloca [1 x i8], align 1
  %v = alloca [24 x i8], align 8
  store i8 0, ptr %_13, align 1
  store i8 1, ptr %_13, align 1
  store i8 0, ptr %_13, align 1
; call <alloc::vec::Vec<u8>>::with_capacity_in
  call void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %v, i64 %s.1) #25
  br label %bb1

bb1:                                              ; preds = %start
  %_6 = icmp ugt i64 %s.1, 0
  br i1 %_6, label %bb2, label %bb6

bb6:                                              ; preds = %bb11, %bb1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %v, i64 24, i1 false)
  ret void

bb2:                                              ; preds = %bb1
  br label %bb3

bb7:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u8>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VechEECseGb2pkncjeE_6panics(ptr align 8 %v) #26
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb4, %bb5, %bb3
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb7

bb3:                                              ; preds = %bb2
; invoke <alloc::vec::Vec<u8>>::as_mut_ptr
  %_9 = invoke ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %v)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke core::ub_checks::check_language_ub
  %_4.i.i1 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
          to label %_4.i.i.noexc unwind label %cleanup

_4.i.i.noexc:                                     ; preds = %bb4
  br i1 %_4.i.i1, label %bb2.i.i, label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCseGb2pkncjeE_6panics.exit

bb2.i.i:                                          ; preds = %_4.i.i.noexc
; call core::ptr::copy_nonoverlapping::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCseGb2pkncjeE_6panics(ptr %s.0, ptr %_9, i64 1, i64 1, i64 %s.1, ptr align 8 @alloc_a4b6077411685917cd51431566be9305) #31
  br label %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCseGb2pkncjeE_6panics.exit

_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCseGb2pkncjeE_6panics.exit: ; preds = %_4.i.i.noexc, %bb2.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_9, ptr align 1 %s.0, i64 %s.1, i1 false)
  br label %bb5

bb5:                                              ; preds = %_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh22copy_to_nonoverlappingCseGb2pkncjeE_6panics.exit
; invoke <alloc::vec::Vec<u8>>::set_len
  invoke void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCseGb2pkncjeE_6panics(ptr align 8 %v, i64 %s.1)
          to label %bb11 unwind label %cleanup

bb11:                                             ; preds = %bb5
  br label %bb6

terminate:                                        ; preds = %bb7
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb10:                                             ; preds = %bb7
  %6 = load i8, ptr %_13, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb9, label %bb8

bb8:                                              ; preds = %bb9, %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12

bb9:                                              ; preds = %bb10
  br label %bb8
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics(ptr align 8 %_1) unnamed_addr #0 !guid !230 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsddYV2PBJW9h_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseGb2pkncjeE_6panics(ptr %_4) #32
; call <() as std::process::Termination>::report
  %_2 = call i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseGb2pkncjeE_6panics() #25
; call <std::process::ExitCode>::to_i32
  %_0 = call i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseGb2pkncjeE_6panics(i8 %_2) #25
  ret i32 %_0
}

; std::panicking::begin_panic::<u64>::{closure#0}
; Function Attrs: inlinehint minsize noreturn nonlazybind optsize uwtable
define internal void @_RNCINvNtCsddYV2PBJW9h_3std9panicking11begin_panicyE0CseGb2pkncjeE_6panics(ptr align 8 %_1.0, i64 %_1.1) unnamed_addr #7 personality ptr @rust_eh_personality !guid !231 {
start:
  %_4 = alloca [16 x i8], align 8
  store i64 1, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %_1.1, ptr %0, align 8
; call std::panicking::panic_with_hook
  call void @_RNvNtCsddYV2PBJW9h_3std9panicking15panic_with_hook(ptr %_4, ptr align 8 @vtable.1, ptr align 8 %_1.0, i1 zeroext true, i1 zeroext false) #33
  unreachable

bb1:                                              ; No predecessors!
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; panics::main::{closure#0}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4main00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) unnamed_addr #0 !guid !232 {
start:
; call <&str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) #25
  ret void
}

; panics::main::{closure#5}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNCNvCseGb2pkncjeE_6panics4mains3_00B5_() unnamed_addr #0 !guid !233 {
start:
; call <core::fmt::Arguments>::from_str
  %0 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_6c342f467cee9eb46aaa013cf1ccd49c, i64 5) #25
  %_3.0 = extractvalue { ptr, ptr } %0, 0
  %_3.1 = extractvalue { ptr, ptr } %0, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_3.0, ptr %_3.1, ptr align 8 @alloc_1378573dc70dc7b629a9d6b1d49c46c0) #28
  unreachable
}

; panics::main::{closure#7}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4mains5_00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) unnamed_addr #0 !guid !234 {
start:
; call <&str as alloc::string::ToString>::to_string
  call void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %s) #25
  ret void
}

; panics::main::{closure#8}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNCNvCseGb2pkncjeE_6panics4mains6_00B5_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !235 {
start:
  %s = alloca [8 x i8], align 8
  store ptr %0, ptr %s, align 8
  %_5 = load ptr, ptr %s, align 8
  %_7 = ptrtoint ptr %_5 to i64
  %_9 = and i64 %_7, 7
  %_10 = icmp eq i64 %_9, 0
  br i1 %_10, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_12 = ptrtoint ptr %_5 to i64
  %_14 = icmp eq i64 %_12, 0
  %_15 = and i1 %_14, true
  %_16 = xor i1 %_15, true
  br i1 %_16, label %bb3, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_7, ptr align 8 @alloc_bc2728ce27cec9f60e0626ade65acb4b) #34
  unreachable

bb3:                                              ; preds = %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_5, i64 24, i1 false)
; call <alloc::boxed::Box<alloc::string::String> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %s) #25
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_bc2728ce27cec9f60e0626ade65acb4b) #34
  unreachable
}

; panics::main::{closure#9}::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNCNCNvCseGb2pkncjeE_6panics4mains7_00B5_(ptr align 8 %0) unnamed_addr #0 !guid !236 {
start:
  %v = alloca [8 x i8], align 8
  store ptr %0, ptr %v, align 8
  %_3 = load ptr, ptr %v, align 8
  %_5 = ptrtoint ptr %_3 to i64
  %_7 = and i64 %_5, 7
  %_8 = icmp eq i64 %_7, 0
  br i1 %_8, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_10 = ptrtoint ptr %_3 to i64
  %_12 = icmp eq i64 %_10, 0
  %_13 = and i1 %_12, true
  %_14 = xor i1 %_13, true
  br i1 %_14, label %bb3, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_5, ptr align 8 @alloc_0aeb6e895488c55d15573141e7b7a3c2) #34
  unreachable

bb3:                                              ; preds = %bb2
  %_0 = load i64, ptr %_3, align 8
; call core::ptr::drop_glue::<alloc::boxed::Box<u64>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxyEECseGb2pkncjeE_6panics(ptr align 8 %v)
  ret i64 %_0

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_0aeb6e895488c55d15573141e7b7a3c2) #34
  unreachable
}

; panics::main::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4main0B3_(ptr %_1, ptr align 8 %i) unnamed_addr #0 personality ptr @rust_eh_personality !guid !237 {
start:
  %0 = alloca [16 x i8], align 8
  %_20 = alloca [1 x i8], align 1
  %_16 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_12 = alloca [24 x i8], align 8
  %_9 = alloca [24 x i8], align 8
  %_8 = alloca [24 x i8], align 8
  %_7 = alloca [24 x i8], align 8
  store i8 0, ptr %_20, align 1
; call <std::panic::PanicHookInfo>::payload
  %1 = call { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %i) #25
  %_11.0 = extractvalue { ptr, ptr } %1, 0
  %_11.1 = extractvalue { ptr, ptr } %1, 1
; call <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
  %_10 = call align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECseGb2pkncjeE_6panics(ptr %_11.0, ptr align 8 %_11.1) #25
  store i8 1, ptr %_20, align 1
; call <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#0}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4main00EB1y_(ptr sret([24 x i8]) align 8 %_9, ptr align 8 %_10) #25
; invoke <std::panic::PanicHookInfo>::payload
  %2 = invoke { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %i)
          to label %bb4 unwind label %cleanup

bb16:                                             ; preds = %cleanup
  %3 = load i8, ptr %_20, align 1
  %4 = trunc nuw i8 %3 to i1
  br i1 %4, label %bb15, label %bb14

cleanup:                                          ; preds = %bb6, %bb5, %bb4, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %0, align 8
  %8 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb16

bb4:                                              ; preds = %start
  %_14.0 = extractvalue { ptr, ptr } %2, 0
  %_14.1 = extractvalue { ptr, ptr } %2, 1
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<alloc::string::String>
  %_13 = invoke align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %_14.0, ptr align 8 %_14.1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke <core::option::Option<&alloc::string::String>>::cloned
  invoke void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_12, ptr align 8 %_13)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  store i8 0, ptr %_20, align 1
; invoke <core::option::Option<alloc::string::String>>::or
  invoke void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE2orCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_8, ptr align 8 %_9, ptr align 8 %_12)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_20, align 1
; call <core::option::Option<alloc::string::String>>::unwrap_or_default
  call void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_7, ptr align 8 %_8) #25
; invoke <core::fmt::rt::Argument>::new_display::<alloc::string::String>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displayNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_16, ptr align 8 %_7)
          to label %bb9 unwind label %cleanup1

bb13:                                             ; preds = %cleanup1
; invoke core::ptr::drop_glue::<alloc::string::String>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr align 8 %_7) #26
          to label %bb14 unwind label %terminate

cleanup1:                                         ; preds = %bb10, %bb9, %bb7
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  br label %bb13

bb9:                                              ; preds = %bb7
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_16, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %14 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_02b558d5b27198b9b90fbafced75e0cf, ptr align 8 %args)
          to label %bb10 unwind label %cleanup1

bb10:                                             ; preds = %bb9
  %_4.0 = extractvalue { ptr, ptr } %14, 0
  %_4.1 = extractvalue { ptr, ptr } %14, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_4.0, ptr %_4.1)
          to label %bb11 unwind label %cleanup1

bb11:                                             ; preds = %bb10
; call core::ptr::drop_glue::<alloc::string::String>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr align 8 %_7)
  ret void

terminate:                                        ; preds = %bb15, %bb13
  %15 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb14:                                             ; preds = %bb15, %bb16, %bb13
  %16 = load ptr, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  %18 = load i32, ptr %17, align 8
  %19 = insertvalue { ptr, i32 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i32 } %19, i32 %18, 1
  resume { ptr, i32 } %20

bb15:                                             ; preds = %bb16
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %_9) #26
          to label %bb14 unwind label %terminate
}

; panics::main::{closure#2}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNCNvCseGb2pkncjeE_6panics4mains0_0B3_() unnamed_addr #0 !guid !238 {
start:
; call core::hint::black_box::<u8>
  %x = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 -6) #25
; call core::hint::black_box::<u8>
  %_3 = call i8 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxhECseGb2pkncjeE_6panics(i8 10) #25
  %_4.0 = add i8 %x, %_3
  %_4.1 = icmp ult i8 %_4.0, %x
  br i1 %_4.1, label %panic, label %bb3

bb3:                                              ; preds = %start
  ret i8 %_4.0

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_26337d6526588881851e4b9aa79dd1e0) #28
  unreachable
}

; panics::main::{closure#3}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains1_0B3_() unnamed_addr #0 !guid !239 {
start:
  %_8 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_6 = alloca [4 x i8], align 4
; call core::hint::black_box::<i32>
  %0 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxlECseGb2pkncjeE_6panics(i32 42) #25
  store i32 %0, ptr %_6, align 4
; call <core::fmt::rt::Argument>::new_display::<i32>
  call void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaylECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_8, ptr align 4 %_6) #25
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<10, 1>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_12d2d02b2e0c041f3e841225de325fca, ptr align 8 %args) #25
  %_3.0 = extractvalue { ptr, ptr } %2, 0
  %_3.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_3.0, ptr %_3.1, ptr align 8 @alloc_e2740e3908ad36560b71cc9f5b200537) #28
  unreachable
}

; panics::main::{closure#4}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains2_0B3_() unnamed_addr #0 !guid !240 {
start:
; call core::hint::black_box::<u64>
  %_3 = call i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxyECseGb2pkncjeE_6panics(i64 7) #25
; call std::panic::panic_any::<u64>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic9panic_anyyECseGb2pkncjeE_6panics(i64 %_3, ptr align 8 @alloc_ed9180a32b8d1532dfca976b688cc762) #29
  unreachable
}

; panics::main::{closure#5}
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNCNvCseGb2pkncjeE_6panics4mains3_0B3_() unnamed_addr #0 personality ptr @rust_eh_personality !guid !241 {
start:
  %0 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
; call std::panic::catch_unwind::<panics::main::{closure#5}::{closure#0}, u8>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNCNvCseGb2pkncjeE_6panics4mains3_00hEBM_(ptr sret([16 x i8]) align 8 %_3)
; invoke <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %_0 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %_3)
          to label %bb2 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_3) #26
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb4

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %_3)
  ret i1 %_0

terminate:                                        ; preds = %bb4
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb5:                                              ; preds = %bb4
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; panics::main::{closure#6}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains4_0B3_(i8 %x) unnamed_addr #0 !guid !242 {
start:
  %_0 = zext i8 %x to i32
  ret i32 %_0
}

; panics::main::{closure#7}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains5_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %0, ptr align 8 %1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !243 {
start:
  %2 = alloca [16 x i8], align 8
  %e = alloca [16 x i8], align 8
  store ptr %0, ptr %e, align 8
  %3 = getelementptr inbounds i8, ptr %e, i64 8
  store ptr %1, ptr %3, align 8
  %_5.0 = load ptr, ptr %e, align 8
  %4 = getelementptr inbounds i8, ptr %e, i64 8
  %_5.1 = load ptr, ptr %4, align 8
; invoke <dyn core::any::Any + core::marker::Send>::downcast_ref::<&str>
  %_3 = invoke align 8 ptr @_RINvMs3_NtCsl10jNU3mE6R_4core3anyDNtB6_3AnyNtNtB8_6marker4SendEL_12downcast_refReECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1)
          to label %bb1 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %e) #26
          to label %bb5 unwind label %terminate

cleanup:                                          ; preds = %bb1, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb4

bb1:                                              ; preds = %start
; invoke <core::option::Option<&&str>>::map::<alloc::string::String, panics::main::{closure#7}::{closure#0}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRReE3mapNtNtCs7CppTae75M1_5alloc6string6StringNCNCNvCseGb2pkncjeE_6panics4mains5_00EB1y_(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_3)
          to label %bb2 unwind label %cleanup

bb2:                                              ; preds = %bb1
; call core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %e)
  ret void

terminate:                                        ; preds = %bb4
  %9 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb5:                                              ; preds = %bb4
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 8
  %12 = load i32, ptr %11, align 8
  %13 = insertvalue { ptr, i32 } poison, ptr %10, 0
  %14 = insertvalue { ptr, i32 } %13, i32 %12, 1
  resume { ptr, i32 } %14
}

; panics::main::{closure#8}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNCNvCseGb2pkncjeE_6panics4mains6_0B3_(ptr sret([24 x i8]) align 8 %_0, ptr %e.0, ptr align 8 %e.1) unnamed_addr #0 !guid !244 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
; call <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<alloc::string::String>
  call void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastNtNtBa_6string6StringECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_4, ptr %e.0, ptr align 8 %e.1) #25
; call <core::result::Result<alloc::boxed::Box<alloc::string::String>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<alloc::string::String, panics::main::{closure#8}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxNtNtBN_6string6StringEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapB1h_NCNCNvCseGb2pkncjeE_6panics4mains6_00EB2z_(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %_4) #25
; call <core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
  call void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtBL_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_3) #25
  ret void
}

; panics::main::{closure#9}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvCseGb2pkncjeE_6panics4mains7_0B3_(ptr %e.0, ptr align 8 %e.1) unnamed_addr #0 !guid !245 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
; call <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::downcast::<u64>
  call void @_RINvMsb_NtNtCs7CppTae75M1_5alloc5boxed7convertINtB8_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBX_6marker4SendEL_E8downcastyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_4, ptr %e.0, ptr align 8 %e.1) #25
; call <core::result::Result<alloc::boxed::Box<u64>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map::<u64, panics::main::{closure#9}::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultINtNtCs7CppTae75M1_5alloc5boxed3BoxyEIBJ_DNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE3mapyNCNCNvCseGb2pkncjeE_6panics4mains7_00EB2c_(ptr sret([16 x i8]) align 8 %_3, ptr align 8 %_4) #25
; call <core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
  %0 = call { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr align 8 %_3) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; panics::main::{closure#1}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNCNvCseGb2pkncjeE_6panics4mains_0B3_() unnamed_addr #0 !guid !246 {
start:
; call core::hint::black_box::<u32>
  %_2 = call i32 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxmECseGb2pkncjeE_6panics(i32 5) #25
; call panics::deep
  %_0 = call i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %_2)
  ret i32 %_0
}

; alloc::raw_vec::layout_array::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNCNvNtCs7CppTae75M1_5alloc7raw_vec12layout_array0CseGb2pkncjeE_6panics() unnamed_addr #0 !guid !247 {
start:
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %0 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCseGb2pkncjeE_6panics(i64 0, i64 undef, ptr align 8 @alloc_84e24ad25dfa3f90d9808e22947b437c) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNSNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_once6vtableCseGb2pkncjeE_6panics(ptr %_1) unnamed_addr #0 !guid !248 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %0) #25
  ret i32 %_0
}

; <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNSNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_once6vtableB8_(ptr %_1, ptr align 8 %0) unnamed_addr #0 !guid !249 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
  call void @_RNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %1) #25
  ret void
}

; panics::deep
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %n) unnamed_addr #1 personality ptr @rust_eh_personality !guid !250 {
start:
  %0 = alloca [16 x i8], align 8
  %v = alloca [24 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  %_2 = icmp eq i32 %n, 0
  br i1 %_2, label %bb1, label %bb5

bb5:                                              ; preds = %start
  %_9.0 = sub i32 %n, 1
  %_9.1 = icmp ult i32 %n, 1
  br i1 %_9.1, label %panic, label %bb6

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u32>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecmE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %v) #25
; invoke core::hint::black_box::<usize>
  %_6 = invoke i64 @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxjECseGb2pkncjeE_6panics(i64 7)
          to label %bb3 unwind label %cleanup

bb6:                                              ; preds = %bb5
; call panics::deep
  %_7 = call i32 @_RNvCseGb2pkncjeE_6panics4deep(i32 %_9.0)
  %_10.0 = add i32 %_7, 1
  %_10.1 = icmp ult i32 %_10.0, %_7
  br i1 %_10.1, label %panic1, label %bb8

panic:                                            ; preds = %bb5
; call core::panicking::panic_const::panic_const_sub_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8 @alloc_3aadfb4415466f9ec9f9a3c5fbb426c4) #28
  unreachable

bb8:                                              ; preds = %bb6
  store i32 %_10.0, ptr %_0, align 4
  br label %bb9

panic1:                                           ; preds = %bb6
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8 @alloc_d43dd53cfe4b9b827fd912a6e62abe23) #28
  unreachable

bb9:                                              ; preds = %bb4, %bb8
  %1 = load i32, ptr %_0, align 4
  ret i32 %1

bb10:                                             ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::vec::Vec<u32>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %v) #26
          to label %bb11 unwind label %terminate

cleanup:                                          ; preds = %bb3, %bb1
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb10

bb3:                                              ; preds = %bb1
; invoke <alloc::vec::Vec<u32> as core::ops::index::Index<usize>>::index
  %_4 = invoke align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCseGb2pkncjeE_6panics(ptr align 8 %v, i64 %_6, ptr align 8 @alloc_6a689db22d1294a68a0bad4756950543)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
  %6 = load i32, ptr %_4, align 4
  store i32 %6, ptr %_0, align 4
; call core::ptr::drop_glue::<alloc::vec::Vec<u32>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc3vec3VecmEECseGb2pkncjeE_6panics(ptr align 8 %v)
  br label %bb9

terminate:                                        ; preds = %bb10
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb11:                                             ; preds = %bb10
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; panics::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCseGb2pkncjeE_6panics4main() unnamed_addr #1 personality ptr @rust_eh_personality !guid !251 {
start:
  %0 = alloca [16 x i8], align 8
  %e.i = alloca [16 x i8], align 8
  %_4.i = alloca [1 x i8], align 1
  %1 = alloca [16 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %3 = alloca [16 x i8], align 8
  %_55 = alloca [16 x i8], align 8
  %_52 = alloca [16 x i8], align 8
  %args6 = alloca [16 x i8], align 8
  %_46 = alloca [16 x i8], align 8
  %n = alloca [1 x i8], align 1
  %_42 = alloca [16 x i8], align 8
  %args5 = alloca [16 x i8], align 8
  %_40 = alloca [16 x i8], align 8
  %_32 = alloca [16 x i8], align 8
  %args4 = alloca [16 x i8], align 8
  %_30 = alloca [24 x i8], align 8
  %r3 = alloca [16 x i8], align 8
  %_22 = alloca [16 x i8], align 8
  %args2 = alloca [16 x i8], align 8
  %_20 = alloca [24 x i8], align 8
  %r1 = alloca [16 x i8], align 8
  %_12 = alloca [16 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_9 = alloca [1 x i8], align 1
  %r = alloca [16 x i8], align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 1, i64 0) #25
  store i8 0, ptr %_4.i, align 1
; call std::panicking::set_hook
  call void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr %_3.i, ptr align 8 @vtable.2)
; call std::panic::catch_unwind::<panics::main::{closure#1}, u32>
  call void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains_0mEBK_(ptr sret([16 x i8]) align 8 %r)
; invoke <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
  %4 = invoke zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %r)
          to label %bb4 unwind label %cleanup

bb37:                                             ; preds = %bb36, %bb35, %cleanup.body
; invoke core::ptr::drop_glue::<core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %r) #26
          to label %bb38 unwind label %terminate

cleanup:                                          ; preds = %bb34, %bb33, %bb32, %bb31, %bb30, %bb29, %bb28, %bb27, %bb26, %bb24, %bb23, %bb22, %bb21, %bb20, %bb19, %bb18, %bb14, %bb13, %bb12, %bb8, %bb7, %bb6, %bb5, %bb4, %start
  %5 = landingpad { ptr, i32 }
          cleanup
  br label %cleanup.body

cleanup.body:                                     ; preds = %bb5.i, %cleanup
  %eh.lpad-body = phi { ptr, i32 } [ %5, %cleanup ], [ %48, %bb5.i ]
  %6 = extractvalue { ptr, i32 } %eh.lpad-body, 0
  %7 = extractvalue { ptr, i32 } %eh.lpad-body, 1
  store ptr %6, ptr %3, align 8
  %8 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %7, ptr %8, align 8
  br label %bb37

bb4:                                              ; preds = %start
  %9 = zext i1 %4 to i8
  store i8 %9, ptr %_9, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_12, ptr %_9)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_12, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<11, 1>
  %11 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjb_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_448fb98007976f236e6e677ba877f9b6, ptr align 8 %args)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
  %_6.0 = extractvalue { ptr, ptr } %11, 0
  %_6.1 = extractvalue { ptr, ptr } %11, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_6.0, ptr %_6.1)
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
; invoke std::panic::catch_unwind::<panics::main::{closure#2}, u8>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains0_0hEBK_(ptr sret([16 x i8]) align 8 %r1)
          to label %bb8 unwind label %cleanup

bb8:                                              ; preds = %bb7
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %r1, i64 16, i1 false)
; invoke <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#7}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains5_0EB2Q_(ptr sret([24 x i8]) align 8 %_20, ptr align 8 %2)
          to label %bb9 unwind label %cleanup

bb9:                                              ; preds = %bb8
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_22, ptr align 8 %_20)
          to label %bb10 unwind label %cleanup7

bb36:                                             ; preds = %cleanup7
; invoke core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_20) #26
          to label %bb37 unwind label %terminate

cleanup7:                                         ; preds = %bb11, %bb10, %bb9
  %12 = landingpad { ptr, i32 }
          cleanup
  %13 = extractvalue { ptr, i32 } %12, 0
  %14 = extractvalue { ptr, i32 } %12, 1
  store ptr %13, ptr %3, align 8
  %15 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %14, ptr %15, align 8
  br label %bb36

bb10:                                             ; preds = %bb9
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_22, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<15, 1>
  %17 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjf_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_3c431bcb3e5b1a19bfdfd590efb9375c, ptr align 8 %args2)
          to label %bb11 unwind label %cleanup7

bb11:                                             ; preds = %bb10
  %_17.0 = extractvalue { ptr, ptr } %17, 0
  %_17.1 = extractvalue { ptr, ptr } %17, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_17.0, ptr %_17.1)
          to label %bb12 unwind label %cleanup7

bb12:                                             ; preds = %bb11
; invoke core::ptr::drop_glue::<core::result::Result<u8, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResulthINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_20)
          to label %bb13 unwind label %cleanup

bb13:                                             ; preds = %bb12
; invoke std::panic::catch_unwind::<panics::main::{closure#3}, i32>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains1_0lEBK_(ptr sret([16 x i8]) align 8 %r3)
          to label %bb14 unwind label %cleanup

bb14:                                             ; preds = %bb13
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %r3, i64 16, i1 false)
; invoke <core::result::Result<i32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<alloc::string::String>, panics::main::{closure#8}>
  invoke void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultlINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionNtNtBO_6string6StringENCNvCseGb2pkncjeE_6panics4mains6_0EB2Q_(ptr sret([24 x i8]) align 8 %_30, ptr align 8 %1)
          to label %bb15 unwind label %cleanup

bb15:                                             ; preds = %bb14
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_32, ptr align 8 %_30)
          to label %bb16 unwind label %cleanup8

bb35:                                             ; preds = %cleanup8
; invoke core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_30) #26
          to label %bb37 unwind label %terminate

cleanup8:                                         ; preds = %bb17, %bb16, %bb15
  %18 = landingpad { ptr, i32 }
          cleanup
  %19 = extractvalue { ptr, i32 } %18, 0
  %20 = extractvalue { ptr, i32 } %18, 1
  store ptr %19, ptr %3, align 8
  %21 = getelementptr inbounds i8, ptr %3, i64 8
  store i32 %20, ptr %21, align 8
  br label %bb35

bb16:                                             ; preds = %bb15
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_32, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %23 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_3d7fb2aa6ae966f1e7013d6c153d46dc, ptr align 8 %args4)
          to label %bb17 unwind label %cleanup8

bb17:                                             ; preds = %bb16
  %_27.0 = extractvalue { ptr, ptr } %23, 0
  %_27.1 = extractvalue { ptr, ptr } %23, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_27.0, ptr %_27.1)
          to label %bb18 unwind label %cleanup8

bb18:                                             ; preds = %bb17
; invoke core::ptr::drop_glue::<core::result::Result<i32, core::option::Option<alloc::string::String>>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultlINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEECseGb2pkncjeE_6panics(ptr align 8 %_30)
          to label %bb19 unwind label %cleanup

bb19:                                             ; preds = %bb18
; invoke std::panic::catch_unwind::<panics::main::{closure#4}, ()>
  %24 = invoke { ptr, ptr } @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains2_0uEBK_()
          to label %bb20 unwind label %cleanup

bb20:                                             ; preds = %bb19
  %r.0 = extractvalue { ptr, ptr } %24, 0
  %r.1 = extractvalue { ptr, ptr } %24, 1
; invoke <core::result::Result<(), alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::map_err::<core::option::Option<u64>, panics::main::{closure#9}>
  %25 = invoke { i64, i64 } @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultuINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB5_3any3AnyNtNtB5_6marker4SendEL_EE7map_errINtNtB5_6option6OptionyENCNvCseGb2pkncjeE_6panics4mains7_0EB2w_(ptr %r.0, ptr %r.1)
          to label %bb21 unwind label %cleanup

bb21:                                             ; preds = %bb20
  %26 = extractvalue { i64, i64 } %25, 0
  %27 = extractvalue { i64, i64 } %25, 1
  store i64 %26, ptr %_40, align 8
  %28 = getelementptr inbounds i8, ptr %_40, i64 8
  store i64 %27, ptr %28, align 8
; invoke <core::fmt::rt::Argument>::new_debug::<core::result::Result<(), core::option::Option<u64>>>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument9new_debugINtNtB7_6result6ResultuINtNtB7_6option6OptionyEEECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_42, ptr align 8 %_40)
          to label %bb22 unwind label %cleanup

bb22:                                             ; preds = %bb21
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_42, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<10, 1>
  %30 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKja_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_b3985d69dd852d2586fba6caf63ad04a, ptr align 8 %args5)
          to label %bb23 unwind label %cleanup

bb23:                                             ; preds = %bb22
  %_37.0 = extractvalue { ptr, ptr } %30, 0
  %_37.1 = extractvalue { ptr, ptr } %30, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_37.0, ptr %_37.1)
          to label %bb24 unwind label %cleanup

bb24:                                             ; preds = %bb23
; invoke std::panic::catch_unwind::<panics::main::{closure#5}, bool>
  invoke void @_RINvNtCsddYV2PBJW9h_3std5panic12catch_unwindNCNvCseGb2pkncjeE_6panics4mains3_0bEBK_(ptr sret([16 x i8]) align 8 %_46)
          to label %bb25 unwind label %cleanup

bb25:                                             ; preds = %bb24
  %31 = load ptr, ptr %_46, align 8
  %32 = ptrtoint ptr %31 to i64
  %33 = icmp eq i64 %32, 0
  %_2.i = select i1 %33, i64 0, i64 1
  %34 = trunc nuw i64 %_2.i to i1
  br i1 %34, label %bb2.i, label %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit

bb2.i:                                            ; preds = %bb25
  %35 = load ptr, ptr %_46, align 8
  %36 = getelementptr inbounds i8, ptr %_46, i64 8
  %37 = load ptr, ptr %36, align 8
  store ptr %35, ptr %e.i, align 8
  %38 = getelementptr inbounds i8, ptr %e.i, i64 8
  store ptr %37, ptr %38, align 8
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.3, ptr align 8 @alloc_6c16facbf882c3c5f712b5f99d829949) #33
          to label %unreachable.i unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb2.i
  %39 = landingpad { ptr, i32 }
          cleanup
  %40 = extractvalue { ptr, i32 } %39, 0
  %41 = extractvalue { ptr, i32 } %39, 1
  store ptr %40, ptr %0, align 8
  %42 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %41, ptr %42, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %e.i) #26
          to label %bb5.i unwind label %terminate.i

unreachable.i:                                    ; preds = %bb2.i
  unreachable

terminate.i:                                      ; preds = %cleanup.i
  %43 = landingpad { ptr, i32 }
          cleanup
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb5.i:                                            ; preds = %cleanup.i
  %44 = load ptr, ptr %0, align 8
  %45 = getelementptr inbounds i8, ptr %0, i64 8
  %46 = load i32, ptr %45, align 8
  %47 = insertvalue { ptr, i32 } poison, ptr %44, 0
  %48 = insertvalue { ptr, i32 } %47, i32 %46, 1
  br label %cleanup.body

_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit: ; preds = %bb25
  %49 = getelementptr inbounds i8, ptr %_46, i64 8
  %50 = load i8, ptr %49, align 8
  %t.i = trunc nuw i8 %50 to i1
  br label %bb26

bb26:                                             ; preds = %_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultbINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6unwrapCseGb2pkncjeE_6panics.exit
  %51 = zext i1 %t.i to i8
  store i8 %51, ptr %n, align 1
; invoke <core::fmt::rt::Argument>::new_display::<bool>
  invoke void @_RINvMNtNtCsl10jNU3mE6R_4core3fmt2rtNtB3_8Argument11new_displaybECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_52, ptr %n)
          to label %bb27 unwind label %cleanup

bb27:                                             ; preds = %bb26
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_52, i64 16, i1 false)
; invoke <core::fmt::Arguments>::new::<13, 1>
  %53 = invoke { ptr, ptr } @_RINvMs2_NtCsl10jNU3mE6R_4core3fmtNtB6_9Arguments3newKjd_Kj1_ECseGb2pkncjeE_6panics(ptr @alloc_71d9bbd0f6c53403bb664fdb9799afa5, ptr align 8 %args6)
          to label %bb28 unwind label %cleanup

bb28:                                             ; preds = %bb27
  %_48.0 = extractvalue { ptr, ptr } %53, 0
  %_48.1 = extractvalue { ptr, ptr } %53, 1
; invoke std::io::stdio::_print
  invoke void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr %_48.0, ptr %_48.1)
          to label %bb29 unwind label %cleanup

bb29:                                             ; preds = %bb28
; invoke std::panicking::take_hook
  %54 = invoke { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook()
          to label %bb30 unwind label %cleanup

bb30:                                             ; preds = %bb29
  %55 = extractvalue { ptr, ptr } %54, 0
  %56 = extractvalue { ptr, ptr } %54, 1
  store ptr %55, ptr %_55, align 8
  %57 = getelementptr inbounds i8, ptr %_55, i64 8
  store ptr %56, ptr %57, align 8
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB4_6marker4SyncNtB2I_4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %_55)
          to label %bb31 unwind label %cleanup

bb31:                                             ; preds = %bb30
; invoke core::hint::black_box::<core::option::Option<u8>>
  %58 = invoke { i1, i8 } @_RINvNtCsl10jNU3mE6R_4core4hint9black_boxINtNtB4_6option6OptionhEECseGb2pkncjeE_6panics(i1 zeroext false, i8 undef)
          to label %bb32 unwind label %cleanup

bb32:                                             ; preds = %bb31
  %v.0 = extractvalue { i1, i8 } %58, 0
  %v.1 = extractvalue { i1, i8 } %58, 1
; invoke <core::option::Option<u8>>::map::<i32, panics::main::{closure#6}>
  %59 = invoke { i32, i32 } @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionhE3maplNCNvCseGb2pkncjeE_6panics4mains4_0EBT_(i1 zeroext %v.0, i8 %v.1)
          to label %bb33 unwind label %cleanup

bb33:                                             ; preds = %bb32
  %_60.0 = extractvalue { i32, i32 } %59, 0
  %_60.1 = extractvalue { i32, i32 } %59, 1
; invoke <core::option::Option<i32>>::unwrap_or
  %_59 = invoke i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE9unwrap_orCseGb2pkncjeE_6panics(i32 %_60.0, i32 %_60.1, i32 3)
          to label %bb34 unwind label %cleanup

bb34:                                             ; preds = %bb33
; invoke std::process::exit
  invoke void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32 %_59) #33
          to label %unreachable unwind label %cleanup

unreachable:                                      ; preds = %bb34
  unreachable

terminate:                                        ; preds = %bb37, %bb36, %bb35
  %60 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb38:                                             ; preds = %bb37
  %61 = load ptr, ptr %3, align 8
  %62 = getelementptr inbounds i8, ptr %3, i64 8
  %63 = load i32, ptr %62, align 8
  %64 = insertvalue { ptr, i32 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i32 } %64, i32 %63, 1
  resume { ptr, i32 } %65
}

; <alloc::vec::Vec<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !252 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCseGb2pkncjeE_6panics()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <alloc::vec::Vec<u32>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VecmE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !253 {
start:
; call <alloc::raw_vec::RawVec<u32>>::new
  %0 = call { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecmE3newCseGb2pkncjeE_6panics()
  %_1.0 = extractvalue { i64, ptr } %0, 0
  %_1.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_1.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_1.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <[u8]>::to_vec
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !254 {
start:
; call <[u8]>::to_vec_in::<alloc::alloc::Global>
  call void @_RINvMNtCs7CppTae75M1_5alloc5sliceSh9to_vec_inNtNtB5_5alloc6GlobalECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <alloc::string::String>::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %bytes) unnamed_addr #0 !guid !255 {
start:
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %bytes, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !256 {
start:
  %_1 = alloca [24 x i8], align 8
; call <alloc::vec::Vec<u8>>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc3vecINtB2_3VechE3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_1) #25
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_1, i64 24, i1 false)
  ret void
}

; <alloc::string::String>::as_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !257 {
start:
; call <alloc::vec::Vec<u8>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_2.0 = extractvalue { ptr, i64 } %0, 0
  %_2.1 = extractvalue { ptr, i64 } %0, 1
; call core::str::converts::from_utf8_unchecked
  %1 = call { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr %_2.0, i64 %_2.1) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <alloc::raw_vec::RawVec<u8>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVechE3newCseGb2pkncjeE_6panics() unnamed_addr #1 !guid !258 {
start:
; call <alloc::raw_vec::RawVec<u8>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCseGb2pkncjeE_6panics() #25
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <alloc::raw_vec::RawVec<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal { i64, ptr } @_RNvMNtCs7CppTae75M1_5alloc7raw_vecINtB2_6RawVecmE3newCseGb2pkncjeE_6panics() unnamed_addr #1 !guid !259 {
start:
; call <alloc::raw_vec::RawVec<u32>>::new_in
  %0 = call { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE6new_inCseGb2pkncjeE_6panics() #25
  %_0.0 = extractvalue { i64, ptr } %0, 0
  %_0.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_0.1, 1
  ret { i64, ptr } %2
}

; <std::panic::PanicHookInfo>::payload
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtCsddYV2PBJW9h_3std5panicNtB2_13PanicHookInfo7payloadCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !260 {
start:
  %_0.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0.1 = load ptr, ptr %0, align 8
  %1 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, ptr } %1, ptr %_0.1, 1
  ret { ptr, ptr } %2
}

; <str>::len
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !261 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret i64 %_2.1
}

; <core::option::Option<alloc::string::String>>::unwrap_or_default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE17unwrap_or_defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !262 {
start:
  %x = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb4

bb2:                                              ; preds = %start
; call <alloc::string::String as core::default::Default>::default
  call void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) #25
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<alloc::string::String>>::or
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionNtNtCs7CppTae75M1_5alloc6string6StringE2orCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, ptr align 8 %optb) unnamed_addr #0 personality ptr @rust_eh_personality !guid !263 {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = alloca [1 x i8], align 1
  %_5 = alloca [1 x i8], align 1
  %x = alloca [24 x i8], align 8
  store i8 0, ptr %_6, align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_6, align 1
  store i8 1, ptr %_5, align 1
  %1 = load i64, ptr %self, align 8
  %2 = icmp eq i64 %1, -1
  %_3 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_3 to i1
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
  store i8 0, ptr %_6, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb9

bb2:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %optb, i64 24, i1 false)
  br label %bb9

bb9:                                              ; preds = %bb3, %bb2
  %4 = load i8, ptr %_5, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb8, label %bb4

bb4:                                              ; preds = %bb8, %bb9
  %6 = load i8, ptr %_6, align 1
  %7 = trunc nuw i8 %6 to i1
  br i1 %7, label %bb10, label %bb5

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %optb)
          to label %bb4 unwind label %cleanup

bb6:                                              ; preds = %cleanup
  %8 = load i8, ptr %_6, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb11, label %bb7

cleanup:                                          ; preds = %bb8
  %10 = landingpad { ptr, i32 }
          cleanup
  %11 = extractvalue { ptr, i32 } %10, 0
  %12 = extractvalue { ptr, i32 } %10, 1
  store ptr %11, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %12, ptr %13, align 8
  br label %bb6

bb5:                                              ; preds = %bb10, %bb4
  ret void

bb10:                                             ; preds = %bb4
; call core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %self)
  br label %bb5

bb7:                                              ; preds = %bb11, %bb6
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr inbounds i8, ptr %0, i64 8
  %16 = load i32, ptr %15, align 8
  %17 = insertvalue { ptr, i32 } poison, ptr %14, 0
  %18 = insertvalue { ptr, i32 } %17, i32 %16, 1
  resume { ptr, i32 } %18

bb11:                                             ; preds = %bb6
; invoke core::ptr::drop_glue::<core::option::Option<alloc::string::String>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEECseGb2pkncjeE_6panics(ptr align 8 %self) #26
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb11
  %19 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<i32>>::unwrap_or
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionlE9unwrap_orCseGb2pkncjeE_6panics(i32 %0, i32 %1, i32 %default) unnamed_addr #0 !guid !264 {
start:
  %_5 = alloca [1 x i8], align 1
  %_0 = alloca [4 x i8], align 4
  %self = alloca [8 x i8], align 4
  store i32 %0, ptr %self, align 4
  %2 = getelementptr inbounds i8, ptr %self, i64 4
  store i32 %1, ptr %2, align 4
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
  %3 = load i32, ptr %self, align 4
  %4 = getelementptr inbounds i8, ptr %self, i64 4
  %5 = load i32, ptr %4, align 4
  %_3 = zext i32 %3 to i64
  %6 = trunc nuw i64 %_3 to i1
  br i1 %6, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %self, i64 4
  %x = load i32, ptr %7, align 4
  store i32 %x, ptr %_0, align 4
  br label %bb6

bb2:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
  store i32 %default, ptr %_0, align 4
  br label %bb6

bb6:                                              ; preds = %bb3, %bb2
  %8 = load i8, ptr %_5, align 1
  %9 = trunc nuw i8 %8 to i1
  br i1 %9, label %bb5, label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %10 = load i32, ptr %_0, align 4
  ret i32 %10

bb5:                                              ; preds = %bb6
  br label %bb4

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u64>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionyE4takeCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !265 {
start:
; call core::mem::replace::<core::option::Option<u64>>
  %0 = call { i64, i64 } @_RINvNtCsl10jNU3mE6R_4core3mem7replaceINtNtB4_6option6OptionyEECseGb2pkncjeE_6panics(ptr align 8 %self, i64 0, i64 undef) #25
  %_0.0 = extractvalue { i64, i64 } %0, 0
  %_0.1 = extractvalue { i64, i64 } %0, 1
  %1 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %2 = insertvalue { i64, i64 } %1, i64 %_0.1, 1
  ret { i64, i64 } %2
}

; <core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtBL_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !266 {
start:
  %x = alloca [24 x i8], align 8
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %x, ptr align 8 %self, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %x, i64 24, i1 false)
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %3 = load i64, ptr %self, align 8
  %4 = icmp eq i64 %3, -1
  %_4 = select i1 %4, i64 1, i64 0
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<alloc::string::String, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs7CppTae75M1_5alloc6string6StringINtNtB11_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %self)
  br label %bb4

bb4:                                              ; preds = %bb5, %bb6
  ret void

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !267 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !268 {
start:
; call <core::result::Result<u8, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResulthINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !269 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb3

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_0, align 1
  %5 = trunc nuw i8 %4 to i1
  ret i1 %5

bb4:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_err
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE6is_errCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !270 {
start:
; call <core::result::Result<u32, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::is_ok
  %_2 = call zeroext i1 @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultmINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE5is_okCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_0 = xor i1 %_2, true
  ret i1 %_0
}

; <core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::ok
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6resultINtB2_6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EE2okCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !271 {
start:
  %_0 = alloca [16 x i8], align 8
  %0 = load ptr, ptr %self, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_2 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  %x = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %x, ptr %5, align 8
  store i64 1, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb2, %bb3
  %6 = load ptr, ptr %self, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb5, label %bb4

bb5:                                              ; preds = %bb6
; call core::ptr::drop_glue::<core::result::Result<u64, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>
  call void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtB4_6result6ResultyINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECseGb2pkncjeE_6panics(ptr align 8 %self)
  br label %bb4

bb4:                                              ; preds = %bb5, %bb6
  %10 = load i64, ptr %_0, align 8
  %11 = getelementptr inbounds i8, ptr %_0, i64 8
  %12 = load i64, ptr %11, align 8
  %13 = insertvalue { i64, i64 } poison, i64 %10, 0
  %14 = insertvalue { i64, i64 } %13, i64 %12, 1
  ret { i64, i64 } %14

bb1:                                              ; No predecessors!
  unreachable
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}::{closure#0}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNCNvCseGb2pkncjeE_6panics4mains3_00E4takeB18_(ptr %slot) unnamed_addr #0 !guid !272 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E6as_refB1a_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#2}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains0_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !273 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#3}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains1_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !274 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#4}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains2_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !275 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#5}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains3_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !276 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::manually_drop::ManuallyDrop<panics::main::{closure#1}>>::take
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem13manually_dropINtB2_12ManuallyDropNCNvCseGb2pkncjeE_6panics4mains_0E4takeB16_(ptr %slot) unnamed_addr #0 !guid !277 {
start:
; call <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::as_ref
  %_3 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E6as_refB18_(ptr %slot)
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %x.0, ptr align 8 %x.1) unnamed_addr #1 !guid !278 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %x.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %x.1, 1
  ret { ptr, ptr } %1
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_mut
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_mutCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !279 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_refCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !280 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E3newB1a_() unnamed_addr #1 !guid !281 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}::{closure#0}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNCNvCseGb2pkncjeE_6panics4mains3_00E6as_refB1a_(ptr %self) unnamed_addr #1 !guid !282 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E3newB18_() unnamed_addr #1 !guid !283 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#2}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains0_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !284 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E3newB18_() unnamed_addr #1 !guid !285 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#3}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains1_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !286 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E3newB18_() unnamed_addr #1 !guid !287 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#4}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains2_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !288 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E3newB18_() unnamed_addr #1 !guid !289 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#5}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains3_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !290 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E3newB18_() unnamed_addr #1 !guid !291 {
start:
  ret void
}

; <core::mem::maybe_dangling::MaybeDangling<panics::main::{closure#1}>>::as_ref
; Function Attrs: nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingNCNvCseGb2pkncjeE_6panics4mains_0E6as_refB18_(ptr %self) unnamed_addr #1 !guid !292 {
start:
  ret ptr %self
}

; <core::mem::maybe_dangling::MaybeDangling<bool>>::new
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingbE3newCseGb2pkncjeE_6panics(i1 zeroext %x) unnamed_addr #1 !guid !293 {
start:
  ret i1 %x
}

; <core::mem::maybe_dangling::MaybeDangling<u8>>::new
; Function Attrs: nonlazybind uwtable
define internal i8 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinghE3newCseGb2pkncjeE_6panics(i8 %x) unnamed_addr #1 !guid !294 {
start:
  ret i8 %x
}

; <core::mem::maybe_dangling::MaybeDangling<i32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinglE3newCseGb2pkncjeE_6panics(i32 %x) unnamed_addr #1 !guid !295 {
start:
  ret i32 %x
}

; <core::mem::maybe_dangling::MaybeDangling<u32>>::new
; Function Attrs: nonlazybind uwtable
define internal i32 @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingmE3newCseGb2pkncjeE_6panics(i32 %x) unnamed_addr #1 !guid !296 {
start:
  ret i32 %x
}

; <core::mem::maybe_dangling::MaybeDangling<()>>::new
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglinguE3newCseGb2pkncjeE_6panics() unnamed_addr #1 !guid !297 {
start:
  ret void
}

; <core::mem::alignment::Alignment>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !298 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret i64 %align

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) #31
  br label %bb3
}

; <core::mem::alignment::Alignment>::as_nonzero_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %self) unnamed_addr #0 !guid !299 {
start:
  ret i64 %self
}

; <core::mem::alignment::Alignment>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCseGb2pkncjeE_6panics(i64 %align) unnamed_addr #0 !guid !300 {
start:
  %_0 = alloca [8 x i8], align 8
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i, label %bb2, label %bb4

bb4:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment13new_uncheckedCseGb2pkncjeE_6panics(i64 %align, ptr align 8 @alloc_988c380202cc7b7a37ca3d8d5930c44f) #25
  store i64 %_3, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb4
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::mem::alignment::Alignment>::as_usize
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCseGb2pkncjeE_6panics(i64 %self) unnamed_addr #0 !guid !301 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %self) #25
; call <core::num::nonzero::NonZero<usize>>::get
  %_0 = call i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCseGb2pkncjeE_6panics(i64 %_2) #25
  ret i64 %_0
}

; <*mut u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !302 {
start:
; call <*const u8>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCseGb2pkncjeE_6panics(ptr %self) #25
  ret i1 %_0
}

; <*mut ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !303 {
start:
; call <*const ()>::is_null
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCseGb2pkncjeE_6panics(ptr %self) #25
  ret i1 %_0
}

; <*const u8>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPh7is_nullCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !304 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCseGb2pkncjeE_6panics(ptr %self) #25
  ret i1 %_0
}

; <*const ()>::is_aligned_to
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCseGb2pkncjeE_6panics(ptr %self, i64 %align) unnamed_addr #0 !guid !305 {
start:
  %0 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %0 to i32
  %_0.i1 = icmp eq i32 %_0.i.i, 1
  br i1 %_0.i1, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Arguments>::from_str
  %1 = call { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_fad0cd83b7d1858a846a172eb260e593, i64 42) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr %_5.0, ptr %_5.1, ptr align 8 @alloc_7abc4ceda2d1d9be88f00c5dc522bc84) #28
  unreachable

bb2:                                              ; preds = %start
  %_0.i = ptrtoint ptr %self to i64
  %_8 = sub i64 %align, 1
  %_6 = and i64 %_0.i, %_8
  %_0 = icmp eq i64 %_6, 0
  ret i1 %_0
}

; <*const ()>::is_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !306 {
start:
; call <*const _>::is_null::runtime
  %_0 = call zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCseGb2pkncjeE_6panics(ptr %self) #25
  ret i1 %_0
}

; <core::alloc::layout::Layout>::dangling_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !307 {
start:
  %_3 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_2 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %_3) #25
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_0 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCseGb2pkncjeE_6panics(i64 %_2) #25
  ret ptr %_0
}

; <core::alloc::layout::Layout>::repeat_packed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %n) unnamed_addr #0 !guid !308 {
start:
  %_3 = alloca [16 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4 = load i64, ptr %0, align 8
; call <usize>::checked_mul
  %1 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCseGb2pkncjeE_6panics(i64 %_4, i64 %n) #25
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %size = load i64, ptr %8, align 8
  %_7 = load i64, ptr %self, align 8
; call <core::alloc::layout::Layout>::from_size_alignment
  %9 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCseGb2pkncjeE_6panics(i64 %size, i64 %_7) #25
  %10 = extractvalue { i64, i64 } %9, 0
  %11 = extractvalue { i64, i64 } %9, 1
  store i64 %10, ptr %_0, align 8
  %12 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %11, ptr %12, align 8
  br label %bb4

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %13 = load i64, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { i64, i64 } poison, i64 %13, 0
  %17 = insertvalue { i64, i64 } %16, i64 %15, 1
  ret { i64, i64 } %17

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19from_size_alignmentCseGb2pkncjeE_6panics(i64 %size, i64 %alignment) unnamed_addr #0 !guid !309 {
start:
  %_0 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %alignment, ptr %_0, align 8
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %size, ptr %0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %1 = load i64, ptr %_0, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 8
  %3 = load i64, ptr %2, align 8
  %4 = insertvalue { i64, i64 } poison, i64 %1, 0
  %5 = insertvalue { i64, i64 } %4, i64 %3, 1
  ret { i64, i64 } %5
}

; <core::alloc::layout::Layout>::is_size_align_valid
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCseGb2pkncjeE_6panics(i64 %size, i64 %align) unnamed_addr #0 !guid !310 {
start:
  %_4 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
; call <core::mem::alignment::Alignment>::new
  %0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment3newCseGb2pkncjeE_6panics(i64 %align) #25
  store i64 %0, ptr %_4, align 8
  %1 = load i64, ptr %_4, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %alignment = load i64, ptr %_4, align 8
; call <core::alloc::layout::Layout>::is_size_alignment_valid
  %4 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7

bb5:                                              ; No predecessors!
  unreachable
}

; <core::alloc::layout::Layout>::from_size_align_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCseGb2pkncjeE_6panics(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #0 !guid !311 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %align, ptr align 8 %0) #31
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %align, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout29from_size_alignment_uncheckedCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #0 !guid !312 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) #31
  br label %bb2

bb2:                                              ; preds = %bb1
  %1 = insertvalue { i64, i64 } poison, i64 %alignment, 0
  %2 = insertvalue { i64, i64 } %1, i64 %size, 1
  ret { i64, i64 } %2
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !313 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::alloc::layout::Layout>::align
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !314 {
start:
  %_2 = load i64, ptr %self, align 8
; call <core::mem::alignment::Alignment>::as_usize
  %_0 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment8as_usizeCseGb2pkncjeE_6panics(i64 %_2) #25
  ret i64 %_0
}

; <core::alloc::layout::Layout>::alignment
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !315 {
start:
  %_0 = load i64, ptr %self, align 8
  ret i64 %_0
}

; <alloc::alloc::Global>::alloc_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 !guid !316 {
start:
  %_4 = alloca [24 x i8], align 8
  store i64 %layout.0, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.1, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_4, i64 16
  %2 = zext i1 %zeroed to i8
  store i8 %2, ptr %1, align 8
  %3 = load i64, ptr %_4, align 8
  %4 = getelementptr inbounds i8, ptr %_4, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_4, i64 16
  %7 = load i8, ptr %6, align 8
  %8 = trunc nuw i8 %7 to i1
; call <alloc::alloc::Global>::alloc_impl_runtime
  %9 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCseGb2pkncjeE_6panics(i64 %3, i64 %5, i1 zeroext %8) #25
  %_0.0 = extractvalue { ptr, i64 } %9, 0
  %_0.1 = extractvalue { ptr, i64 } %9, 1
  %10 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %_0.1, 1
  ret { ptr, i64 } %11
}

; <alloc::alloc::Global>::deallocate_impl
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !317 {
start:
  %_4 = alloca [24 x i8], align 8
  store ptr %ptr, ptr %_4, align 8
  %0 = getelementptr inbounds i8, ptr %_4, i64 8
  store i64 %layout.0, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %0, i64 8
  store i64 %layout.1, ptr %1, align 8
  %2 = load ptr, ptr %_4, align 8
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global>::deallocate_impl_runtime
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCseGb2pkncjeE_6panics(ptr %2, i64 %4, i64 %6) #25
  ret void
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global18alloc_impl_runtimeCseGb2pkncjeE_6panics(i64 %0, i64 %1, i1 zeroext %zeroed) unnamed_addr #0 !guid !318 {
start:
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %size = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %3 = icmp eq i64 %size, 0
  br i1 %3, label %bb3, label %bb2

bb3:                                              ; preds = %start
; call <core::alloc::layout::Layout>::dangling_ptr
  %_6 = call ptr @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout12dangling_ptrCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %4 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCseGb2pkncjeE_6panics(ptr %_6, i64 0) #25
  %_5.0 = extractvalue { ptr, i64 } %4, 0
  %_5.1 = extractvalue { ptr, i64 } %4, 1
  store ptr %_5.0, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.1, ptr %5, align 8
  br label %bb16

bb2:                                              ; preds = %start
  br i1 %zeroed, label %bb6, label %bb7

bb16:                                             ; preds = %bb14, %bb13, %bb3
  %6 = load ptr, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { ptr, i64 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i64 } %9, i64 %8, 1
  ret { ptr, i64 } %10

bb7:                                              ; preds = %bb2
  %11 = load i64, ptr %layout, align 8
  %12 = getelementptr inbounds i8, ptr %layout, i64 8
  %13 = load i64, ptr %12, align 8
; call alloc::alloc::alloc
  %14 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCseGb2pkncjeE_6panics(i64 %11, i64 %13) #25
  store ptr %14, ptr %raw_ptr, align 8
  br label %bb8

bb6:                                              ; preds = %bb2
  %15 = load i64, ptr %layout, align 8
  %16 = getelementptr inbounds i8, ptr %layout, i64 8
  %17 = load i64, ptr %16, align 8
; call alloc::alloc::alloc_zeroed
  %18 = call ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCseGb2pkncjeE_6panics(i64 %15, i64 %17) #25
  store ptr %18, ptr %raw_ptr, align 8
  br label %bb8

bb8:                                              ; preds = %bb6, %bb7
  %_12 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<u8>>::new
  %_11 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCseGb2pkncjeE_6panics(ptr %_12) #25
; call <core::option::Option<core::ptr::non_null::NonNull<u8>>>::ok_or::<core::alloc::AllocError>
  %_10 = call ptr @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionINtNtNtB5_3ptr8non_null7NonNullhEE5ok_orNtNtB5_5alloc10AllocErrorECseGb2pkncjeE_6panics(ptr %_11) #25
; call <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
  %19 = call ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCseGb2pkncjeE_6panics(ptr %_10) #25
  store ptr %19, ptr %_9, align 8
  %20 = load ptr, ptr %_9, align 8
  %21 = ptrtoint ptr %20 to i64
  %22 = icmp eq i64 %21, 0
  %_13 = select i1 %22, i64 1, i64 0
  %23 = trunc nuw i64 %_13 to i1
  br i1 %23, label %bb14, label %bb13

bb14:                                             ; preds = %bb8
; call <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
  %24 = call { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCseGb2pkncjeE_6panics(ptr align 8 @alloc_d48fd52eabdd3dce4034ac7ef36523bb) #25
  %25 = extractvalue { ptr, i64 } %24, 0
  %26 = extractvalue { ptr, i64 } %24, 1
  store ptr %25, ptr %_0, align 8
  %27 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %26, ptr %27, align 8
  br label %bb16

bb13:                                             ; preds = %bb8
  %ptr = load ptr, ptr %_9, align 8
; call <core::ptr::non_null::NonNull<u8>>::cast_slice
  %28 = call { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCseGb2pkncjeE_6panics(ptr %ptr, i64 %size) #25
  %_15.0 = extractvalue { ptr, i64 } %28, 0
  %_15.1 = extractvalue { ptr, i64 } %28, 1
  store ptr %_15.0, ptr %_0, align 8
  %29 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_15.1, ptr %29, align 8
  br label %bb16

bb12:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global>::deallocate_impl_runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global23deallocate_impl_runtimeCseGb2pkncjeE_6panics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !319 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %_3 = icmp ne i64 %_4, 0
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
  %3 = load i64, ptr %layout, align 8
  %4 = getelementptr inbounds i8, ptr %layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::alloc::dealloc_nonnull
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCseGb2pkncjeE_6panics(ptr %ptr, i64 %3, i64 %5) #25
  br label %bb3
}

; <alloc::raw_vec::RawVec<u8>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !320 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u8>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrhECseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u8>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE6new_inCseGb2pkncjeE_6panics() unnamed_addr #0 personality ptr @rust_eh_personality !guid !321 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<u8>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofhECseGb2pkncjeE_6panics() #25
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCseGb2pkncjeE_6panics(i64 %_4) #25
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !322 {
start:
; call <alloc::raw_vec::RawVecInner>::capacity
  %_0 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCseGb2pkncjeE_6panics(ptr align 8 %self, i64 1) #25
  ret i64 %_0
}

; <alloc::raw_vec::RawVec<u32>>::ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !323 {
start:
; call <alloc::raw_vec::RawVecInner>::ptr::<u32>
  %_0 = call ptr @_RINvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB6_11RawVecInner3ptrmECseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::raw_vec::RawVec<u32>>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE6new_inCseGb2pkncjeE_6panics() unnamed_addr #0 personality ptr @rust_eh_personality !guid !324 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <core::mem::alignment::Alignment>::of::<u32>
  %_4 = call i64 @_RINvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB3_9Alignment2ofmECseGb2pkncjeE_6panics() #25
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %0 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCseGb2pkncjeE_6panics(i64 %_4) #25
  %_2.0 = extractvalue { i64, ptr } %0, 0
  %_2.1 = extractvalue { i64, ptr } %0, 1
  br label %bb2

bb2:                                              ; preds = %bb1
  store i8 0, ptr %_5, align 1
  %1 = insertvalue { i64, ptr } poison, i64 %_2.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_2.1, 1
  ret { i64, ptr } %2

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <i32>::unsigned_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCseGb2pkncjeE_6panics(i32 %self) unnamed_addr #0 !guid !325 {
start:
; call <i32>::wrapping_abs
  %_2 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCseGb2pkncjeE_6panics(i32 %self) #25
  ret i32 %_2
}

; <i32>::wrapping_abs
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12wrapping_absCseGb2pkncjeE_6panics(i32 %self) unnamed_addr #0 !guid !326 {
start:
  %_0 = alloca [4 x i8], align 4
  %_0.i = icmp slt i32 %self, 0
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i32 %self, ptr %_0, align 4
  br label %bb4

bb2:                                              ; preds = %start
  %_0.i2 = sub i32 0, %self
  store i32 %_0.i2, ptr %_0, align 4
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i32, ptr %_0, align 4
  ret i32 %0
}

; <core::ptr::non_null::NonNull<u8>>::without_provenance
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCseGb2pkncjeE_6panics(i64 %addr) unnamed_addr #0 !guid !327 {
start:
  %_0 = inttoptr i64 %addr to ptr
  ret ptr %_0
}

; <core::option::Option<&alloc::string::String>>::cloned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs1_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE6clonedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !328 {
start:
; call <core::option::Option<&alloc::string::String>>::map::<alloc::string::String, <alloc::string::String as core::clone::Clone>::clone>
  call void @_RINvMNtCsl10jNU3mE6R_4core6optionINtB3_6OptionRNtNtCs7CppTae75M1_5alloc6string6StringE3mapBJ_NvYBJ_NtNtB5_5clone5Clone5cloneECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <core::ptr::unique::Unique<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDG0_INtNtNtB9_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB9_6marker4SyncNtB2o_4SendEL_E6as_ptrCseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !329 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<dyn core::any::Any + core::marker::Send>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_3any3AnyNtNtB9_6marker4SendEL_E6as_ptrCseGb2pkncjeE_6panics(ptr %self.0, ptr align 8 %self.1) unnamed_addr #0 !guid !330 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %self.1, 1
  %_0.0 = extractvalue { ptr, ptr } %1, 0
  %_0.1 = extractvalue { ptr, ptr } %1, 1
  %2 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, ptr } %2, ptr %_0.1, 1
  ret { ptr, ptr } %3
}

; <core::ptr::unique::Unique<alloc::string::String>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !331 {
start:
; call <core::ptr::non_null::NonNull<alloc::string::String>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<alloc::string::String>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE6as_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !332 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u8>>::from_non_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCseGb2pkncjeE_6panics(ptr %pointer) unnamed_addr #0 !guid !333 {
start:
  ret ptr %pointer
}

; <core::ptr::unique::Unique<u8>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !334 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u32>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquemE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !335 {
start:
  ret ptr %self
}

; <core::ptr::unique::Unique<u64>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !336 {
start:
; call <core::ptr::non_null::NonNull<u64>>::new_unchecked
  %_2 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 @alloc_8e8e5d43991787ef9fba0c8fe53b59fb) #25
  ret ptr %_2
}

; <core::ptr::unique::Unique<u64>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE6as_ptrCseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !337 {
start:
  ret ptr %self
}

; <core::ptr::non_null::NonNull<core::result::Result<u8, core::option::Option<alloc::string::String>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResulthINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !338 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<i32, core::option::Option<alloc::string::String>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultlINtNtB9_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !339 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<core::result::Result<(), core::option::Option<u64>>>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullINtNtB9_6result6ResultuINtNtB9_6option6OptionyEEE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !340 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !341 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) #31
  br label %bb3
}

; <core::ptr::non_null::NonNull<alloc::string::String>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullNtNtCs7CppTae75M1_5alloc6string6StringE8from_refCseGb2pkncjeE_6panics(ptr align 8 %r) unnamed_addr #0 !guid !342 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr.0, i64 %ptr.1, ptr align 8 %0) unnamed_addr #0 !guid !343 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  %1 = insertvalue { ptr, i64 } poison, ptr %ptr.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %ptr.1, 1
  ret { ptr, i64 } %2

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr.0, ptr align 8 %0) #31
  br label %bb3
}

; <core::ptr::non_null::NonNull<bool>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullbE8from_refCseGb2pkncjeE_6panics(ptr %r) unnamed_addr #0 !guid !344 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u8>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !345 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) #31
  br label %bb3
}

; <core::ptr::non_null::NonNull<u8>>::new
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE3newCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !346 {
start:
  %_0 = alloca [8 x i8], align 8
; call <*mut u8>::is_null
  %_2 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh7is_nullCseGb2pkncjeE_6panics(ptr %ptr) #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 @alloc_e469ef44bf39c45bcb672a4bc963b9cb) #25
  store ptr %_3, ptr %_0, align 8
  br label %bb5

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb2, %bb3
  %0 = load ptr, ptr %_0, align 8
  ret ptr %0
}

; <core::ptr::non_null::NonNull<i32>>::from_ref
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNulllE8from_refCseGb2pkncjeE_6panics(ptr align 4 %r) unnamed_addr #0 !guid !347 {
start:
  ret ptr %r
}

; <core::ptr::non_null::NonNull<u64>>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #0 !guid !348 {
start:
; call core::ub_checks::check_language_ub
  %_2 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb2, %start
  ret ptr %ptr

bb2:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) #31
  br label %bb3
}

; <core::num::niche_types::UsizeNoHighBit>::new_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCseGb2pkncjeE_6panics(i64 %val) unnamed_addr #0 !guid !349 {
start:
  ret i64 %val
}

; <core::num::niche_types::UsizeNoHighBit>::as_inner
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCseGb2pkncjeE_6panics(i64 %self) unnamed_addr #0 !guid !350 {
start:
  ret i64 %self
}

; <alloc::raw_vec::RawVecInner>::needs_to_grow
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %len, i64 %additional, i64 %0, i64 %1) unnamed_addr #0 !guid !351 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %elem_layout) #25
; call <alloc::raw_vec::RawVecInner>::capacity
  %_6 = call i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %_7) #25
  %_0.i = sub i64 %_6, %len
  %_0 = icmp ugt i64 %additional, %_0.i
  ret i1 %_0
}

; <alloc::raw_vec::RawVecInner>::current_memory
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self, i64 %0, i64 %1) unnamed_addr #0 !guid !352 {
start:
  %_17 = alloca [24 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_4 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %elem_layout) #25
  %_3 = icmp eq i64 %_4, 0
  br i1 %_3, label %bb4, label %bb2

bb2:                                              ; preds = %start
  %_8 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_7 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCseGb2pkncjeE_6panics(i64 %_8) #25
  %_6 = icmp eq i64 %_7, 0
  br i1 %_6, label %bb4, label %bb5

bb4:                                              ; preds = %bb2, %start
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %3, align 8
  br label %bb12

bb5:                                              ; preds = %bb2
; call <core::alloc::layout::Layout>::size
  %_10 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %elem_layout) #25
  %_13 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %_12 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCseGb2pkncjeE_6panics(i64 %_13) #25
; call core::ub_checks::check_language_ub
  %_3.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_3.i, label %bb2.i, label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

bb2.i:                                            ; preds = %bb5
; call <usize>::unchecked_mul::precondition_check
  call void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCseGb2pkncjeE_6panics(i64 %_10, i64 %_12, ptr align 8 @alloc_85bcb8feb56634093aba2b8644936af9) #31
  br label %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit

_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit: ; preds = %bb5, %bb2.i
  %_0.i = mul nuw i64 %_10, %_12
; call <core::alloc::layout::Layout>::align
  %_15 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout5alignCseGb2pkncjeE_6panics(ptr align 8 %elem_layout) #25
; call <core::alloc::layout::Layout>::from_size_align_unchecked
  %4 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout25from_size_align_uncheckedCseGb2pkncjeE_6panics(i64 %_0.i, i64 %_15, ptr align 8 @alloc_17de00c3327446355700bd7db4b78ded) #25
  %layout.0 = extractvalue { i64, i64 } %4, 0
  %layout.1 = extractvalue { i64, i64 } %4, 1
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  %_19 = load ptr, ptr %5, align 8
; call <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
  %_18 = call ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCseGb2pkncjeE_6panics(ptr %_19, ptr align 8 @alloc_b9419d44288097f84422e162822ba96e) #25
  store ptr %_18, ptr %_17, align 8
  %6 = getelementptr inbounds i8, ptr %_17, i64 8
  store i64 %layout.0, ptr %6, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store i64 %layout.1, ptr %7, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_17, i64 24, i1 false)
  br label %bb12

bb12:                                             ; preds = %bb4, %_RNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::new_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCseGb2pkncjeE_6panics(i64 %align) unnamed_addr #0 personality ptr @rust_eh_personality !guid !353 {
start:
; call <core::mem::alignment::Alignment>::as_nonzero_usize
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB2_9Alignment16as_nonzero_usizeCseGb2pkncjeE_6panics(i64 %align) #25
  br label %bb1

bb1:                                              ; preds = %start
; call <core::ptr::non_null::NonNull<u8>>::without_provenance
  %_4 = call ptr @_RNvMs0_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE18without_provenanceCseGb2pkncjeE_6panics(i64 %_5) #25
  br label %bb2

bb2:                                              ; preds = %bb1
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %ptr = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCseGb2pkncjeE_6panics(ptr %_4) #25
  br label %bb3

bb3:                                              ; preds = %bb2
  %0 = insertvalue { i64, ptr } { i64 0, ptr poison }, ptr %ptr, 1
  ret { i64, ptr } %0

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner8capacityCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %elem_size) unnamed_addr #0 !guid !354 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 %elem_size, 0
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %_4 = load i64, ptr %self, align 8
; call <core::num::niche_types::UsizeNoHighBit>::as_inner
  %0 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit8as_innerCseGb2pkncjeE_6panics(i64 %_4) #25
  store i64 %0, ptr %_0, align 8
  br label %bb3

bb1:                                              ; preds = %start
  store i64 -1, ptr %_0, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %1 = load i64, ptr %_0, align 8
  ret i64 %1
}

; <core::ptr::non_null::NonNull<u8>>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs2_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhE10cast_sliceCseGb2pkncjeE_6panics(ptr %self, i64 %len) unnamed_addr #0 !guid !355 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
  %0 = call { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCseGb2pkncjeE_6panics(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #1 !guid !356 {
start:
  %_3 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::current_memory
  call void @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_3, ptr align 8 %self, i64 %elem_layout.0, i64 %elem_layout.1) #25
  %0 = getelementptr inbounds i8, ptr %_3, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %1, 0
  %_5 = select i1 %2, i64 0, i64 1
  %3 = trunc nuw i64 %_5 to i1
  br i1 %3, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %ptr = load ptr, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  %layout.0 = load i64, ptr %4, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 8
  %layout.1 = load i64, ptr %5, align 8
  %_9 = getelementptr inbounds i8, ptr %self, i64 16
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_9, ptr %ptr, i64 %layout.0, i64 %layout.1) #25
  br label %bb3

bb3:                                              ; preds = %bb2, %start
  ret void

bb4:                                              ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCseGb2pkncjeE_6panics(i64 %capacity) unnamed_addr #0 !guid !357 {
start:
; call <alloc::raw_vec::RawVecInner>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCseGb2pkncjeE_6panics(i64 %capacity, i64 1, i64 1) #25
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  %1 = insertvalue { i64, ptr } poison, i64 %_3.0, 0
  %2 = insertvalue { i64, ptr } %1, ptr %_3.1, 1
  ret { i64, ptr } %2
}

; <core::fmt::Arguments>::from_str
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !358 {
start:
; call <str>::len
  %_7 = call i64 @_RNvMNtCsl10jNU3mE6R_4core3stre3lenCseGb2pkncjeE_6panics(ptr %s.0, i64 %s.1) #25
  %_6 = shl i64 %_7, 1
  %_5 = or i64 %_6, 1
  %_4 = inttoptr i64 %_5 to ptr
  %0 = insertvalue { ptr, ptr } poison, ptr %s.0, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %_4, 1
  ret { ptr, ptr } %1
}

; <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !359 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
  %_2 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) #25
  ret ptr %_2
}

; <core::ptr::non_null::NonNull<[u8]>>::as_non_null_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !360 {
start:
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_0 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECseGb2pkncjeE_6panics(ptr %self.0, i64 %self.1) #25
  ret ptr %_0
}

; <core::ptr::non_null::NonNull<[u8]>>::slice_from_raw_parts
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE20slice_from_raw_partsCseGb2pkncjeE_6panics(ptr %data, i64 %len) unnamed_addr #0 !guid !361 {
start:
; call <*mut u8>::cast_slice
  %0 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCseGb2pkncjeE_6panics(ptr %data, i64 %len) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <core::ptr::non_null::NonNull<[u8]>>::new_unchecked
  %1 = call { ptr, i64 } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE13new_uncheckedCseGb2pkncjeE_6panics(ptr %_3.0, i64 %_3.1, ptr align 8 @alloc_af3623564924928dd3d563c9d84a8a0e) #25
  %_0.0 = extractvalue { ptr, i64 } %1, 0
  %_0.1 = extractvalue { ptr, i64 } %1, 1
  %2 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %3 = insertvalue { ptr, i64 } %2, i64 %_0.1, 1
  ret { ptr, i64 } %3
}

; <core::panic::location::Location>::caller
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core5panic8locationNtB5_8Location6callerCseGb2pkncjeE_6panics(ptr align 8 %_0) unnamed_addr #0 !guid !362 {
start:
  ret ptr %_0
}

; <alloc::raw_vec::RawVecInner>::try_allocate_in
; Function Attrs: nonlazybind uwtable
define internal void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity, i1 zeroext %init, i64 %0, i64 %1) unnamed_addr #1 personality ptr @rust_eh_personality !guid !363 {
start:
  %_32 = alloca [1 x i8], align 1
  %_31 = alloca [1 x i8], align 1
  %result = alloca [16 x i8], align 8
  %_6 = alloca [24 x i8], align 8
  %layout = alloca [16 x i8], align 8
  %elem_layout = alloca [16 x i8], align 8
  %alloc = alloca [0 x i8], align 1
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
  store i8 0, ptr %_31, align 1
  store i8 0, ptr %_32, align 1
  store i8 1, ptr %_31, align 1
  %3 = load i64, ptr %elem_layout, align 8
  %4 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  %5 = load i64, ptr %4, align 8
; call alloc::raw_vec::layout_array
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_6, i64 %capacity, i64 %3, i64 %5) #25
  br label %bb1

bb1:                                              ; preds = %start
  %_7 = load i64, ptr %_6, align 8
  %6 = trunc nuw i64 %_7 to i1
  br i1 %6, label %bb3, label %bb4

bb3:                                              ; preds = %bb1
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %7 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCseGb2pkncjeE_6panics(i64 0, i64 undef, ptr align 8 @alloc_099d793709fa470a3d5e7c79c938e035) #25
  %_9.0 = extractvalue { i64, i64 } %7, 0
  %_9.1 = extractvalue { i64, i64 } %7, 1
  br label %bb5

bb4:                                              ; preds = %bb1
  %8 = getelementptr inbounds i8, ptr %_6, i64 8
  %layout.0 = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 8
  %layout.1 = load i64, ptr %9, align 8
  store i64 %layout.0, ptr %layout, align 8
  %10 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %layout.1, ptr %10, align 8
; call <core::alloc::layout::Layout>::size
  %_12 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  br label %bb6

bb6:                                              ; preds = %bb4
  %_11 = icmp eq i64 %_12, 0
  br i1 %_11, label %bb7, label %bb10

bb10:                                             ; preds = %bb6
  %_19 = zext i1 %init to i64
  %11 = trunc nuw i64 %_19 to i1
  br i1 %11, label %bb11, label %bb12

bb7:                                              ; preds = %bb6
  store i8 0, ptr %_31, align 1
  store i8 1, ptr %_32, align 1
; call <core::alloc::layout::Layout>::alignment
  %_16 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %elem_layout) #25
  br label %bb8

bb11:                                             ; preds = %bb10
  %12 = load i64, ptr %layout, align 8
  %13 = getelementptr inbounds i8, ptr %layout, i64 8
  %14 = load i64, ptr %13, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
  %15 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCseGb2pkncjeE_6panics(ptr %alloc, i64 %12, i64 %14) #25
  %16 = extractvalue { ptr, i64 } %15, 0
  %17 = extractvalue { ptr, i64 } %15, 1
  store ptr %16, ptr %result, align 8
  %18 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %17, ptr %18, align 8
  br label %bb28

bb12:                                             ; preds = %bb10
  %19 = load i64, ptr %layout, align 8
  %20 = getelementptr inbounds i8, ptr %layout, i64 8
  %21 = load i64, ptr %20, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %22 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCseGb2pkncjeE_6panics(ptr %alloc, i64 %19, i64 %21) #25
  %23 = extractvalue { ptr, i64 } %22, 0
  %24 = extractvalue { ptr, i64 } %22, 1
  store ptr %23, ptr %result, align 8
  %25 = getelementptr inbounds i8, ptr %result, i64 8
  store i64 %24, ptr %25, align 8
  br label %bb29

bb29:                                             ; preds = %bb12
  br label %bb13

bb13:                                             ; preds = %bb28, %bb29
  %26 = load ptr, ptr %result, align 8
  %27 = getelementptr inbounds i8, ptr %result, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = ptrtoint ptr %26 to i64
  %30 = icmp eq i64 %29, 0
  %_22 = select i1 %30, i64 1, i64 0
  %31 = trunc nuw i64 %_22 to i1
  br i1 %31, label %bb14, label %bb15

bb28:                                             ; preds = %bb11
  br label %bb13

bb14:                                             ; preds = %bb13
  %_25.0 = load i64, ptr %layout, align 8
  %32 = getelementptr inbounds i8, ptr %layout, i64 8
  %_25.1 = load i64, ptr %32, align 8
; call <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
  %33 = call { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCseGb2pkncjeE_6panics(i64 %_25.0, i64 %_25.1, ptr align 8 @alloc_33dfd402c6ecbe2e6a32e76edf5f31a5) #25
  %_24.0 = extractvalue { i64, i64 } %33, 0
  %_24.1 = extractvalue { i64, i64 } %33, 1
  br label %bb16

bb15:                                             ; preds = %bb13
  %ptr.0 = load ptr, ptr %result, align 8
  %34 = getelementptr inbounds i8, ptr %result, i64 8
  %ptr.1 = load i64, ptr %34, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::cast::<u8>
  %_28 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB6_7NonNullShE4casthECseGb2pkncjeE_6panics(ptr %ptr.0, i64 %ptr.1) #25
  br label %bb17

bb17:                                             ; preds = %bb15
; call <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
  %_27 = call ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCseGb2pkncjeE_6panics(ptr %_28) #25
  br label %bb18

bb18:                                             ; preds = %bb17
; call <core::num::niche_types::UsizeNoHighBit>::new_unchecked
  %_29 = call i64 @_RNvMs1z_NtNtCsl10jNU3mE6R_4core3num11niche_typesNtB6_14UsizeNoHighBit13new_uncheckedCseGb2pkncjeE_6panics(i64 %capacity) #25
  br label %bb19

bb19:                                             ; preds = %bb18
  store i8 0, ptr %_31, align 1
  %35 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_29, ptr %35, align 8
  %36 = getelementptr inbounds i8, ptr %35, i64 8
  store ptr %_27, ptr %36, align 8
  store i64 0, ptr %_0, align 8
  br label %bb21

bb21:                                             ; preds = %bb23, %bb20, %bb19
  ret void

bb16:                                             ; preds = %bb14
  %37 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_24.0, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %37, i64 8
  store i64 %_24.1, ptr %38, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb20:                                             ; preds = %bb5, %bb9, %bb16
  %39 = load i8, ptr %_31, align 1
  %40 = trunc nuw i8 %39 to i1
  br i1 %40, label %bb23, label %bb21

bb8:                                              ; preds = %bb7
  store i8 0, ptr %_32, align 1
; call <alloc::raw_vec::RawVecInner>::new_in
  %41 = call { i64, ptr } @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner6new_inCseGb2pkncjeE_6panics(i64 %_16) #25
  %_14.0 = extractvalue { i64, ptr } %41, 0
  %_14.1 = extractvalue { i64, ptr } %41, 1
  br label %bb9

bb9:                                              ; preds = %bb8
  store i8 0, ptr %_32, align 1
  %42 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_14.0, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %42, i64 8
  store ptr %_14.1, ptr %43, align 8
  store i64 0, ptr %_0, align 8
  br label %bb20

bb5:                                              ; preds = %bb3
  %44 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_9.0, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 8
  store i64 %_9.1, ptr %45, align 8
  store i64 1, ptr %_0, align 8
  br label %bb20

bb23:                                             ; preds = %bb20
  br label %bb21

bb2:                                              ; No predecessors!
  unreachable

bb22:                                             ; No predecessors!
  unreachable

bb24:                                             ; No predecessors!
  unreachable

bb25:                                             ; No predecessors!
  unreachable

bb26:                                             ; No predecessors!
  unreachable

bb27:                                             ; No predecessors!
  unreachable
}

; <alloc::raw_vec::RawVecInner>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, ptr } @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCseGb2pkncjeE_6panics(i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) unnamed_addr #0 personality ptr @rust_eh_personality !guid !364 {
start:
  %this = alloca [16 x i8], align 8
  %_4 = alloca [24 x i8], align 8
; call <alloc::raw_vec::RawVecInner>::try_allocate_in
  call void @_RNvMs5_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_4, i64 %capacity, i1 zeroext false, i64 %elem_layout.0, i64 %elem_layout.1)
  %_6 = load i64, ptr %_4, align 8
  %0 = trunc nuw i64 %_6 to i1
  br i1 %0, label %bb3, label %bb4

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %_4, i64 8
  %err.0 = load i64, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 8
  %err.1 = load i64, ptr %2, align 8
; call alloc::raw_vec::handle_error
  call void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64 %err.0, i64 %err.1) #33
  unreachable

bb4:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_4, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds i8, ptr %3, i64 8
  %6 = load ptr, ptr %5, align 8
  store i64 %4, ptr %this, align 8
  %7 = getelementptr inbounds i8, ptr %this, i64 8
  store ptr %6, ptr %7, align 8
; call <alloc::raw_vec::RawVecInner>::needs_to_grow
  %_10 = call zeroext i1 @_RNvMs2_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner13needs_to_growCseGb2pkncjeE_6panics(ptr align 8 %this, i64 0, i64 %capacity, i64 %elem_layout.0, i64 %elem_layout.1) #25
  br label %bb5

bb5:                                              ; preds = %bb4
  %_9 = xor i1 %_10, true
; call core::ub_checks::check_language_ub
  %_2.i = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() #25
  br i1 %_2.i, label %bb2.i, label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

bb2.i:                                            ; preds = %bb5
; call core::hint::assert_unchecked::precondition_check
  call void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseGb2pkncjeE_6panics(i1 zeroext %_9, ptr align 8 @alloc_51424262946dd0794fad6132df857999) #31
  br label %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit

_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit: ; preds = %bb5, %bb2.i
  br label %bb6

bb6:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked.exit
  %_0.0 = load i64, ptr %this, align 8
  %8 = getelementptr inbounds i8, ptr %this, i64 8
  %_0.1 = load ptr, ptr %8, align 8
  %9 = insertvalue { i64, ptr } poison, i64 %_0.0, 0
  %10 = insertvalue { i64, ptr } %9, ptr %_0.1, 1
  ret { i64, ptr } %10

bb2:                                              ; No predecessors!
  unreachable

bb7:                                              ; No predecessors!
  unreachable

bb8:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E8into_rawCseGb2pkncjeE_6panics(ptr %b.0, ptr align 8 %b.1) unnamed_addr #0 !guid !365 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %b.0, ptr align 8 %b.1)
  %_2.0.i = extractvalue { ptr, ptr } %0, 0
  %_2.1.i = extractvalue { ptr, ptr } %0, 1
  %1 = extractvalue { ptr, ptr } %0, 0
  %2 = extractvalue { ptr, ptr } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store ptr %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_mut
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_mutCseGb2pkncjeE_6panics(ptr align 8 %b)
  %_6.0 = load ptr, ptr %_0.i, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i, i64 8
  %_6.1 = load ptr, ptr %4, align 8
  %5 = insertvalue { ptr, ptr } poison, ptr %_6.0, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_6.1, 1
  ret { ptr, ptr } %6
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw_with_allocator
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, ptr } @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E23into_raw_with_allocatorCseGb2pkncjeE_6panics(ptr %b.0, ptr align 8 %b.1) unnamed_addr #0 !guid !366 {
start:
  %b = alloca [16 x i8], align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::new
  %0 = call { ptr, ptr } @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE3newCseGb2pkncjeE_6panics(ptr %b.0, ptr align 8 %b.1)
  %_2.0.i = extractvalue { ptr, ptr } %0, 0
  %_2.1.i = extractvalue { ptr, ptr } %0, 1
  %1 = extractvalue { ptr, ptr } %0, 0
  %2 = extractvalue { ptr, ptr } %0, 1
  store ptr %1, ptr %b, align 8
  %3 = getelementptr inbounds i8, ptr %b, i64 8
  store ptr %2, ptr %3, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_mut
  %_0.i1 = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_mutCseGb2pkncjeE_6panics(ptr align 8 %b)
  %_11.0 = load ptr, ptr %_0.i1, align 8
  %4 = getelementptr inbounds i8, ptr %_0.i1, i64 8
  %_11.1 = load ptr, ptr %4, align 8
; call <core::mem::maybe_dangling::MaybeDangling<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>::as_ref
  %_0.i = call align 8 ptr @_RNvMNtNtCsl10jNU3mE6R_4core3mem14maybe_danglingINtB2_13MaybeDanglingINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB6_3any3AnyNtNtB6_6marker4SendEL_EE6as_refCseGb2pkncjeE_6panics(ptr align 8 %b)
  %_8 = getelementptr inbounds i8, ptr %_0.i, i64 16
  %5 = insertvalue { ptr, ptr } poison, ptr %_11.0, 0
  %6 = insertvalue { ptr, ptr } %5, ptr %_11.1, 1
  ret { ptr, ptr } %6
}

; <alloc::boxed::Box<alloc::string::String>>::from_raw_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringE11from_raw_inCseGb2pkncjeE_6panics(ptr %raw) unnamed_addr #0 personality ptr @rust_eh_personality !guid !367 {
start:
; call <core::ptr::unique::Unique<alloc::string::String>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE13new_uncheckedCseGb2pkncjeE_6panics(ptr %raw) #25
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_3

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <alloc::boxed::Box<u64>>::from_raw_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 8 ptr @_RNvMs7_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyE11from_raw_inCseGb2pkncjeE_6panics(ptr %raw) unnamed_addr #0 personality ptr @rust_eh_personality !guid !368 {
start:
; call <core::ptr::unique::Unique<u64>>::new_unchecked
  %_3 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE13new_uncheckedCseGb2pkncjeE_6panics(ptr %raw) #25
  br label %bb1

bb1:                                              ; preds = %start
  ret ptr %_3

bb2:                                              ; No predecessors!
  unreachable

bb3:                                              ; No predecessors!
  unreachable
}

; <std::sys::process::unix::common::ExitCode>::as_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseGb2pkncjeE_6panics(ptr %self) unnamed_addr #0 !guid !369 {
start:
  %_2 = load i8, ptr %self, align 1
  %_0 = zext i8 %_2 to i32
  ret i32 %_0
}

; <usize>::checked_mul
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCseGb2pkncjeE_6panics(i64 %self, i64 %rhs) unnamed_addr #0 !guid !370 {
start:
  %_0.i = alloca [1 x i8], align 1
  %_0 = alloca [16 x i8], align 8
  %0 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %self, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %0, 0
  %_5.1.i = extractvalue { i64, i1 } %0, 1
  %_5.0 = extractvalue { i64, i1 } %0, 0
  %_5.1 = extractvalue { i64, i1 } %0, 1
  br i1 %_5.1, label %bb1.i, label %bb3.i

bb3.i:                                            ; preds = %start
  store i8 0, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

bb1.i:                                            ; preds = %start
  store i8 1, ptr %_0.i, align 1
  br label %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit

_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit: ; preds = %bb3.i, %bb1.i
  %1 = load i8, ptr %_0.i, align 1
  %2 = trunc nuw i8 %1 to i1
  br i1 %2, label %bb3, label %bb4

bb4:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  %3 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %_5.0, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %_RNvNtCsl10jNU3mE6R_4core10intrinsics8unlikely.exit
  store i64 0, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load i64, ptr %_0, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = insertvalue { i64, i64 } poison, i64 %4, 0
  %8 = insertvalue { i64, i64 } %7, i64 %6, 1
  ret { i64, i64 } %8
}

; <usize>::abs_diff
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCseGb2pkncjeE_6panics(i64 %self, i64 %other) unnamed_addr #0 !guid !371 {
start:
  %_0 = alloca [8 x i8], align 8
  %_3 = icmp eq i64 8, 1
  br i1 %_3, label %bb2, label %bb5

bb5:                                              ; preds = %start
  %_9 = icmp ult i64 %self, %other
  br i1 %_9, label %bb6, label %bb7

bb2:                                              ; preds = %start
  %_7 = trunc i64 %self to i32
  %_8 = trunc i64 %other to i32
  %_0.i = sub i32 %_7, %_8
; call <i32>::unsigned_abs
  %_5 = call i32 @_RNvMs0_NtCsl10jNU3mE6R_4core3numl12unsigned_absCseGb2pkncjeE_6panics(i32 %_0.i) #25
  %0 = zext i32 %_5 to i64
  store i64 %0, ptr %_0, align 8
  br label %bb8

bb7:                                              ; preds = %bb5
  %1 = sub i64 %self, %other
  store i64 %1, ptr %_0, align 8
  br label %bb8

bb6:                                              ; preds = %bb5
  %2 = sub i64 %other, %self
  store i64 %2, ptr %_0, align 8
  br label %bb8

bb8:                                              ; preds = %bb2, %bb6, %bb7
  %3 = load i64, ptr %_0, align 8
  ret i64 %3
}

; <alloc::vec::Vec<u8>>::with_capacity_in
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMsG_NtCs7CppTae75M1_5alloc3vecINtB5_3VechE16with_capacity_inCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, i64 %capacity) unnamed_addr #0 !guid !372 {
start:
; call <alloc::raw_vec::RawVec<u8>>::with_capacity_in
  %0 = call { i64, ptr } @_RNvMs4_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE16with_capacity_inCseGb2pkncjeE_6panics(i64 %capacity) #25
  %_3.0 = extractvalue { i64, ptr } %0, 0
  %_3.1 = extractvalue { i64, ptr } %0, 1
  store i64 %_3.0, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store ptr %_3.1, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_0, i64 16
  store i64 0, ptr %2, align 8
  ret void
}

; <std::process::ExitCode>::to_i32
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvMsO_NtCsddYV2PBJW9h_3std7processNtB5_8ExitCode6to_i32CseGb2pkncjeE_6panics(i8 %0) unnamed_addr #0 !guid !373 {
start:
  %self = alloca [1 x i8], align 1
  store i8 %0, ptr %self, align 1
; call <std::sys::process::unix::common::ExitCode>::as_i32
  %_0 = call i32 @_RNvMs8_NtNtNtNtCsddYV2PBJW9h_3std3sys7process4unix6commonNtB5_8ExitCode6as_i32CseGb2pkncjeE_6panics(ptr %self) #25
  ret i32 %_0
}

; <alloc::vec::Vec<u8>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !374 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::vec::Vec<u8>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !375 {
start:
; call <alloc::raw_vec::RawVec<u8>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::vec::Vec<u8>>::set_len
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE7set_lenCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %new_len) unnamed_addr #0 !guid !376 {
start:
  br label %bb1

bb1:                                              ; preds = %start
; call <alloc::vec::Vec<u8>>::capacity
  %_5 = call i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCseGb2pkncjeE_6panics(ptr align 8 %self) #25
; call <alloc::vec::Vec<_, _>>::set_len::precondition_check
  call void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCseGb2pkncjeE_6panics(i64 %new_len, i64 %_5, ptr align 8 @alloc_0a847bcc9fc8270cda6b588be330f96e) #31
  br label %bb3

bb3:                                              ; preds = %bb1
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  store i64 %new_len, ptr %0, align 8
  ret void
}

; <alloc::vec::Vec<u8>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !377 {
start:
; call <alloc::vec::Vec<u8>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <alloc::vec::Vec<u8>>::capacity
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE8capacityCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !378 {
start:
; call <alloc::raw_vec::RawVec<u8>>::capacity
  %_0 = call i64 @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechE8capacityCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret i64 %_0
}

; <alloc::vec::Vec<u32>>::as_mut_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !379 {
start:
; call <alloc::raw_vec::RawVec<u32>>::ptr
  %_0 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_0
}

; <alloc::vec::Vec<u32>>::as_ptr
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !380 {
start:
; call <alloc::raw_vec::RawVec<u32>>::ptr
  %_2 = call ptr @_RNvMs0_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmE3ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  ret ptr %_2
}

; <alloc::vec::Vec<u32>>::as_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !381 {
start:
; call <alloc::vec::Vec<u32>>::as_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE6as_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
  %1 = insertvalue { ptr, i64 } poison, ptr %_3, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_4, 1
  ret { ptr, i64 } %2
}

; <*mut u8>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCseGb2pkncjeE_6panics(ptr %self, i64 %len) unnamed_addr #0 !guid !382 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u8>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_muthECseGb2pkncjeE_6panics(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <*mut u32>::cast_slice
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOm10cast_sliceCseGb2pkncjeE_6panics(ptr %self, i64 %len) unnamed_addr #0 !guid !383 {
start:
; call core::ptr::slice_from_raw_parts_mut::<u32>
  %0 = call { ptr, i64 } @_RINvNtCsl10jNU3mE6R_4core3ptr24slice_from_raw_parts_mutmECseGb2pkncjeE_6panics(ptr %self, i64 %len) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <core::num::nonzero::NonZero<usize>>::get
; Function Attrs: inlinehint nonlazybind uwtable
define internal i64 @_RNvMse_NtNtCsl10jNU3mE6R_4core3num7nonzeroINtB5_7NonZerojE3getCseGb2pkncjeE_6panics(i64 %self) unnamed_addr #0 !guid !384 {
start:
  ret i64 %self
}

; alloc::alloc::alloc_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc12alloc_zeroedCseGb2pkncjeE_6panics(i64 %0, i64 %1) unnamed_addr #0 !guid !385 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #35
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call __rustc::__rust_alloc_zeroed
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64 %_3, i64 %_5) #35
  ret ptr %_0
}

; alloc::alloc::dealloc_nonnull
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc5alloc15dealloc_nonnullCseGb2pkncjeE_6panics(ptr %ptr, i64 %0, i64 %1) unnamed_addr #0 !guid !386 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call __rustc::__rust_dealloc
  call void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr %ptr, i64 %_3, i64 %_5) #35
  ret void
}

; alloc::alloc::alloc
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5alloc5allocCseGb2pkncjeE_6panics(i64 %0, i64 %1) unnamed_addr #0 !guid !387 {
start:
  %layout = alloca [16 x i8], align 8
  store i64 %0, ptr %layout, align 8
  %2 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %1, ptr %2, align 8
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #35
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call <core::alloc::layout::Layout>::alignment
  %_5 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout9alignmentCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
; call __rustc::__rust_alloc
  %_0 = call ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64 %_3, i64 %_5) #35
  ret ptr %_0
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !388 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::allocate
  %0 = call { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCseGb2pkncjeE_6panics(ptr inttoptr (i64 1 to ptr), i64 %layout.0, i64 %layout.1) #25
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_4 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_4 to i1
  br i1 %9, label %bb3, label %bb4

bb3:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #33
  unreachable

bb4:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
; call <core::ptr::non_null::NonNull<[u8]>>::as_mut_ptr
  %_0 = call ptr @_RNvMs4_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullShE10as_mut_ptrCseGb2pkncjeE_6panics(ptr %ptr.0, i64 %ptr.1) #25
  ret ptr %_0

bb2:                                              ; No predecessors!
  unreachable
}

; alloc::raw_vec::layout_array
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12layout_arrayCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, i64 %cap, i64 %0, i64 %1) unnamed_addr #0 !guid !389 {
start:
  %elem_layout = alloca [16 x i8], align 8
  store i64 %0, ptr %elem_layout, align 8
  %2 = getelementptr inbounds i8, ptr %elem_layout, i64 8
  store i64 %1, ptr %2, align 8
; call <core::alloc::layout::Layout>::repeat_packed
  %3 = call { i64, i64 } @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout13repeat_packedCseGb2pkncjeE_6panics(ptr align 8 %elem_layout, i64 %cap) #25
  %_3.0 = extractvalue { i64, i64 } %3, 0
  %_3.1 = extractvalue { i64, i64 } %3, 1
; call <core::result::Result<core::alloc::layout::Layout, core::alloc::layout::LayoutError>>::map_err::<alloc::collections::TryReserveError, alloc::raw_vec::layout_array::{closure#0}>
  call void @_RINvMNtCsl10jNU3mE6R_4core6resultINtB3_6ResultNtNtNtB5_5alloc6layout6LayoutNtBK_11LayoutErrorE7map_errNtNtCs7CppTae75M1_5alloc11collections15TryReserveErrorNCNvNtB1G_7raw_vec12layout_array0ECseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, i64 %_3.0, i64 %_3.1) #25
  ret void
}

; core::intrinsics::type_id_eq
; Function Attrs: nounwind nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCseGb2pkncjeE_6panics(ptr align 8 %a, ptr align 8 %b) unnamed_addr #8 !guid !390 {
start:
  %_3 = load i128, ptr %a, align 8
  %_4 = load i128, ptr %b, align 8
  %_0 = icmp eq i128 %_3, %_4
  ret i1 %_0
}

; core::intrinsics::cold_path
; Function Attrs: cold nounwind nonlazybind uwtable
define internal void @_RNvNtCsl10jNU3mE6R_4core10intrinsics9cold_pathCseGb2pkncjeE_6panics() unnamed_addr #9 !guid !391 {
start:
  ret void
}

; core::ub_checks::maybe_is_aligned
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCseGb2pkncjeE_6panics(ptr %ptr, i64 %align) unnamed_addr #0 !guid !392 {
start:
; call core::ub_checks::maybe_is_aligned::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCseGb2pkncjeE_6panics(ptr %ptr, i64 %align) #25
  ret i1 %_0
}

; core::ub_checks::check_language_ub
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ubCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !393 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::check_language_ub::runtime
  %_1 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseGb2pkncjeE_6panics() #25
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb4

bb2:                                              ; preds = %start
  store i8 1, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1
}

; core::ub_checks::maybe_is_nonoverlapping
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCseGb2pkncjeE_6panics(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !394 {
start:
  %_5 = alloca [32 x i8], align 8
  store ptr %src, ptr %_5, align 8
  %0 = getelementptr inbounds i8, ptr %_5, i64 8
  store ptr %dst, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %_5, i64 16
  store i64 %size, ptr %1, align 8
  %2 = getelementptr inbounds i8, ptr %_5, i64 24
  store i64 %count, ptr %2, align 8
  %3 = load ptr, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds i8, ptr %_5, i64 16
  %7 = load i64, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %_5, i64 24
  %9 = load i64, ptr %8, align 8
; call core::ub_checks::maybe_is_nonoverlapping::runtime
  %_0 = call zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCseGb2pkncjeE_6panics(ptr %3, ptr %5, i64 %7, i64 %9) #25
  ret i1 %_0
}

; core::ub_checks::maybe_is_aligned_and_not_null
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCseGb2pkncjeE_6panics(ptr %ptr, i64 %align, i1 zeroext %is_zst) unnamed_addr #0 !guid !395 {
start:
  %_0 = alloca [1 x i8], align 1
; call core::ub_checks::maybe_is_aligned
  %_4 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_alignedCseGb2pkncjeE_6panics(ptr %ptr, i64 %align) #25
  br i1 %_4, label %bb2, label %bb3

bb3:                                              ; preds = %start
  store i8 0, ptr %_0, align 1
  br label %bb7

bb2:                                              ; preds = %start
  br i1 %is_zst, label %bb4, label %bb5

bb7:                                              ; preds = %bb4, %bb5, %bb3
  %0 = load i8, ptr %_0, align 1
  %1 = trunc nuw i8 %0 to i1
  ret i1 %1

bb5:                                              ; preds = %bb2
; call <*const ()>::is_null
  %_5 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu7is_nullCseGb2pkncjeE_6panics(ptr %ptr) #25
  %2 = xor i1 %_5, true
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb4:                                              ; preds = %bb2
  store i8 1, ptr %_0, align 1
  br label %bb7
}

; core::str::converts::from_utf8_unchecked
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvNtNtCsl10jNU3mE6R_4core3str8converts19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr %v.0, i64 %v.1) unnamed_addr #0 !guid !396 {
start:
  %0 = insertvalue { ptr, i64 } poison, ptr %v.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %v.1, 1
  ret { ptr, i64 } %1
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !397 {
start:
  %1 = call i64 @llvm.ctpop.i64(i64 %align)
  %_0.i.i = trunc i64 %1 to i32
  %_0.i = icmp eq i32 %_0.i.i, 1
  br label %bb1

terminate:                                        ; preds = %bb3
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  br i1 %_0.i, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_0625062a5eee489a7813ee965a38d15a, i64 198)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_4.0 = extractvalue { ptr, ptr } %3, 0
  %_4.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; <*const _>::is_null::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPp7is_null7runtimeCseGb2pkncjeE_6panics(ptr %ptr) unnamed_addr #0 !guid !398 {
start:
  %_0.i = ptrtoint ptr %ptr to i64
  %_0 = icmp eq i64 %_0.i, 0
  ret i1 %_0
}

; <core::alloc::layout::Layout>::from_size_align_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %align, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !399 {
start:
; invoke <core::alloc::layout::Layout>::is_size_align_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout19is_size_align_validCseGb2pkncjeE_6panics(i64 %size, i64 %align)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_1be5ea12ba708d9a11b6e93a7d387a75, i64 281)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCseGb2pkncjeE_6panics(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !400 {
start:
; invoke <core::alloc::layout::Layout>::is_size_alignment_valid
  %_3 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64 %size, i64 %alignment)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb3, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, i64 259)
          to label %bb4 unwind label %terminate

bb2:                                              ; preds = %bb1
  ret void

bb4:                                              ; preds = %bb3
  %_5.0 = extractvalue { ptr, ptr } %2, 0
  %_5.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs1_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCseGb2pkncjeE_6panics(ptr %ptr, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !401 {
start:
; invoke <*mut ()>::is_null
  %_2 = invoke zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOu7is_nullCseGb2pkncjeE_6panics(ptr %ptr)
          to label %bb1 unwind label %terminate

terminate:                                        ; preds = %bb2, %start
  %1 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  br i1 %_2, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %2 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, i64 210)
          to label %bb4 unwind label %terminate

bb4:                                              ; preds = %bb2
  %_4.0 = extractvalue { ptr, ptr } %2, 0
  %_4.1 = extractvalue { ptr, ptr } %2, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_4.0, ptr %_4.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; <usize>::unchecked_mul::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs9_NtCsl10jNU3mE6R_4core3numj13unchecked_mul18precondition_checkCseGb2pkncjeE_6panics(i64 %lhs, i64 %rhs, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !402 {
start:
  %1 = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %lhs, i64 %rhs)
  %_5.0.i = extractvalue { i64, i1 } %1, 0
  %_5.1.i = extractvalue { i64, i1 } %1, 1
  br label %bb1

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb1:                                              ; preds = %start
  %_4.0 = extractvalue { i64, i1 } %1, 0
  %_4.1 = extractvalue { i64, i1 } %1, 1
  br i1 %_4.1, label %bb2, label %bb4

bb4:                                              ; preds = %bb1
  ret void

bb2:                                              ; preds = %bb1
; invoke <core::fmt::Arguments>::from_str
  %3 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, i64 186)
          to label %bb3 unwind label %terminate

bb3:                                              ; preds = %bb2
  %_6.0 = extractvalue { ptr, ptr } %3, 0
  %_6.1 = extractvalue { ptr, ptr } %3, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_6.0, ptr %_6.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; <alloc::vec::Vec<_, _>>::set_len::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvMs_NtCs7CppTae75M1_5alloc3vecINtB6_3VecppE7set_len18precondition_checkCseGb2pkncjeE_6panics(i64 %new_len, i64 %capacity, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !403 {
start:
  %_3 = icmp ule i64 %new_len, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_57d70e9d94c65ecfc15225d29a5ed72b, i64 198)
          to label %bb3 unwind label %terminate

bb1:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb3:                                              ; preds = %bb2
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_5.0, ptr %_5.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; core::ptr::copy_nonoverlapping::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core3ptr19copy_nonoverlapping18precondition_checkCseGb2pkncjeE_6panics(ptr %src, ptr %dst, i64 %size, i64 %align, i64 %count, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !404 {
start:
  %zero_size = alloca [1 x i8], align 1
  %_6 = alloca [1 x i8], align 1
  %_8 = icmp eq i64 %count, 0
  br i1 %_8, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %1 = icmp eq i64 %size, 0
  %2 = zext i1 %1 to i8
  store i8 %2, ptr %zero_size, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 1, ptr %zero_size, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %zero_size, align 1
  %_10 = trunc nuw i8 %3 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_9 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCseGb2pkncjeE_6panics(ptr %src, i64 %align, i1 zeroext %_10)
          to label %bb4 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb7, %bb5, %bb3
  %4 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb4:                                              ; preds = %bb3
  br i1 %_9, label %bb5, label %bb8

bb8:                                              ; preds = %bb6, %bb4
  store i8 0, ptr %_6, align 1
  br label %bb9

bb5:                                              ; preds = %bb4
  %5 = load i8, ptr %zero_size, align 1
  %_13 = trunc nuw i8 %5 to i1
; invoke core::ub_checks::maybe_is_aligned_and_not_null
  %_11 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks29maybe_is_aligned_and_not_nullCseGb2pkncjeE_6panics(ptr %dst, i64 %align, i1 zeroext %_13)
          to label %bb6 unwind label %terminate

bb6:                                              ; preds = %bb5
  br i1 %_11, label %bb7, label %bb8

bb7:                                              ; preds = %bb6
; invoke core::ub_checks::maybe_is_nonoverlapping
  %6 = invoke zeroext i1 @_RNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlappingCseGb2pkncjeE_6panics(ptr %src, ptr %dst, i64 %size, i64 %count)
          to label %bb13 unwind label %terminate

bb9:                                              ; preds = %bb13, %bb8
  %7 = load i8, ptr %_6, align 1
  %8 = trunc nuw i8 %7 to i1
  br i1 %8, label %bb12, label %bb10

bb13:                                             ; preds = %bb7
  %9 = zext i1 %6 to i8
  store i8 %9, ptr %_6, align 1
  br label %bb9

bb10:                                             ; preds = %bb9
; invoke <core::fmt::Arguments>::from_str
  %10 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, i64 283)
          to label %bb11 unwind label %terminate

bb12:                                             ; preds = %bb9
  ret void

bb11:                                             ; preds = %bb10
  %_16.0 = extractvalue { ptr, ptr } %10, 0
  %_16.1 = extractvalue { ptr, ptr } %10, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_16.0, ptr %_16.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; core::hint::assert_unchecked::precondition_check
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal void @_RNvNvNtCsl10jNU3mE6R_4core4hint16assert_unchecked18precondition_checkCseGb2pkncjeE_6panics(i1 zeroext %cond, ptr align 8 %0) unnamed_addr #6 personality ptr @rust_eh_personality !guid !405 {
start:
  br i1 %cond, label %bb3, label %bb1

bb1:                                              ; preds = %start
; invoke <core::fmt::Arguments>::from_str
  %1 = invoke { ptr, ptr } @_RNvMs4_NtCsl10jNU3mE6R_4core3fmtNtB5_9Arguments8from_strCseGb2pkncjeE_6panics(ptr @alloc_64e308ef4babfeb8b6220184de794a17, i64 221)
          to label %bb2 unwind label %terminate

bb3:                                              ; preds = %start
  ret void

terminate:                                        ; preds = %bb1
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_cannot_unwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() #27
  unreachable

bb2:                                              ; preds = %bb1
  %_3.0 = extractvalue { ptr, ptr } %1, 0
  %_3.1 = extractvalue { ptr, ptr } %1, 1
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr %_3.0, ptr %_3.1, i1 zeroext false, ptr align 8 %0) #34
  unreachable
}

; core::ub_checks::maybe_is_aligned::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks16maybe_is_aligned7runtimeCseGb2pkncjeE_6panics(ptr %ptr, i64 %align) unnamed_addr #0 !guid !406 {
start:
; call <*const ()>::is_aligned_to
  %_0 = call zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core3ptr9const_ptrPu13is_aligned_toCseGb2pkncjeE_6panics(ptr %ptr, i64 %align) #25
  ret i1 %_0
}

; core::ub_checks::check_language_ub::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks17check_language_ub7runtimeCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !407 {
start:
  ret i1 true
}

; core::ub_checks::maybe_is_nonoverlapping::runtime
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvNvNtCsl10jNU3mE6R_4core9ub_checks23maybe_is_nonoverlapping7runtimeCseGb2pkncjeE_6panics(ptr %src, ptr %dst, i64 %size, i64 %count) unnamed_addr #0 !guid !408 {
start:
  %_9 = alloca [16 x i8], align 8
  %_0.i2 = ptrtoint ptr %src to i64
  %_0.i = ptrtoint ptr %dst to i64
; call <usize>::checked_mul
  %0 = call { i64, i64 } @_RNvMs9_NtCsl10jNU3mE6R_4core3numj11checked_mulCseGb2pkncjeE_6panics(i64 %size, i64 %count) #25
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %_9, align 8
  %3 = getelementptr inbounds i8, ptr %_9, i64 8
  store i64 %2, ptr %3, align 8
  %_10 = load i64, ptr %_9, align 8
  %4 = getelementptr inbounds i8, ptr %_9, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc nuw i64 %_10 to i1
  br i1 %6, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_9, i64 8
  %size1 = load i64, ptr %7, align 8
; call <usize>::abs_diff
  %diff = call i64 @_RNvMs9_NtCsl10jNU3mE6R_4core3numj8abs_diffCseGb2pkncjeE_6panics(i64 %_0.i2, i64 %_0.i) #25
  %_0 = icmp uge i64 %diff, %size1
  ret i1 %_0

bb5:                                              ; preds = %start
; call core::panicking::panic_nounwind
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr @alloc_763310d78c99c2c1ad3f8a9821e942f3, i64 61) #34
  unreachable

bb7:                                              ; No predecessors!
  unreachable
}

; <u64 as core::any::Any>::type_id
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXNtCsl10jNU3mE6R_4core3anyyNtB2_3Any7type_idCseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #1 !guid !409 {
start:
; call <core::any::TypeId>::of::<u64>
  call void @_RINvMs8_NtCsl10jNU3mE6R_4core3anyNtB6_6TypeId2ofyECseGb2pkncjeE_6panics(ptr sret([16 x i8]) align 8 %_0)
  ret void
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::get
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload3getCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !410 {
start:
  %_2 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_2 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %a = getelementptr inbounds i8, ptr %self, i64 8
  %3 = insertvalue { ptr, ptr } poison, ptr %a, 0
  %4 = insertvalue { ptr, ptr } %3, ptr @vtable.4, 1
  ret { ptr, ptr } %4

bb2:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #33
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::take_box
; Function Attrs: nonlazybind uwtable
define internal { ptr, ptr } @_RNvXNvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB2_7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload8take_boxCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !411 {
start:
  %_4.i = alloca [1 x i8], align 1
  %0 = alloca [16 x i8], align 8
  %_11 = alloca [1 x i8], align 1
  %_3 = alloca [16 x i8], align 8
  %data = alloca [16 x i8], align 8
  store i8 0, ptr %_11, align 1
; call <core::option::Option<u64>>::take
  %1 = call { i64, i64 } @_RNvMNtCsl10jNU3mE6R_4core6optionINtB2_6OptionyE4takeCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = trunc nuw i64 %_5 to i1
  br i1 %7, label %bb4, label %bb3

bb4:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %a = load i64, ptr %8, align 8
  store i8 0, ptr %_4.i, align 1
  store i8 1, ptr %_4.i, align 1
; call alloc::boxed::box_new_uninit
  %_3.i = call ptr @_RNvNtCs7CppTae75M1_5alloc5boxed14box_new_uninitCseGb2pkncjeE_6panics(i64 8, i64 8) #25
  store i8 0, ptr %_4.i, align 1
  store i64 %a, ptr %_3.i, align 8
  store i8 1, ptr %_11, align 1
  store ptr %_3.i, ptr %data, align 8
  %9 = getelementptr inbounds i8, ptr %data, i64 8
  store ptr @vtable.4, ptr %9, align 8
  store i8 0, ptr %_11, align 1
  %_10.0 = load ptr, ptr %data, align 8
  %10 = getelementptr inbounds i8, ptr %data, i64 8
  %_10.1 = load ptr, ptr %10, align 8
; invoke <alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>::into_raw
  %11 = invoke { ptr, ptr } @_RNvMs6_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_E8into_rawCseGb2pkncjeE_6panics(ptr %_10.0, ptr align 8 %_10.1)
          to label %bb6 unwind label %cleanup

bb3:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #33
  unreachable

bb7:                                              ; preds = %cleanup
  %12 = load i8, ptr %_11, align 1
  %13 = trunc nuw i8 %12 to i1
  br i1 %13, label %bb9, label %bb8

cleanup:                                          ; preds = %bb4
  %14 = landingpad { ptr, i32 }
          cleanup
  %15 = extractvalue { ptr, i32 } %14, 0
  %16 = extractvalue { ptr, i32 } %14, 1
  store ptr %15, ptr %0, align 8
  %17 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %16, ptr %17, align 8
  br label %bb7

bb6:                                              ; preds = %bb4
  %_0.0 = extractvalue { ptr, ptr } %11, 0
  %_0.1 = extractvalue { ptr, ptr } %11, 1
  store i8 0, ptr %_11, align 1
  %18 = insertvalue { ptr, ptr } poison, ptr %_0.0, 0
  %19 = insertvalue { ptr, ptr } %18, ptr %_0.1, 1
  ret { ptr, ptr } %19

bb8:                                              ; preds = %bb9, %bb7
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr inbounds i8, ptr %0, i64 8
  %22 = load i32, ptr %21, align 8
  %23 = insertvalue { ptr, i32 } poison, ptr %20, 0
  %24 = insertvalue { ptr, i32 } %23, i32 %22, 1
  resume { ptr, i32 } %24

bb9:                                              ; preds = %bb7
; invoke core::ptr::drop_glue::<alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>
  invoke void @_RINvNtCsl10jNU3mE6R_4core3ptr9drop_glueINtNtCs7CppTae75M1_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EECseGb2pkncjeE_6panics(ptr align 8 %data) #26
          to label %bb8 unwind label %terminate

terminate:                                        ; preds = %bb9
  %25 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() #27
  unreachable

bb2:                                              ; No predecessors!
  unreachable
}

; <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCseGb2pkncjeE_6panics(i64 %kind.0, i64 %kind.1) unnamed_addr #0 !guid !412 {
start:
  %0 = insertvalue { i64, i64 } poison, i64 %kind.0, 0
  %1 = insertvalue { i64, i64 } %0, i64 %kind.1, 1
  ret { i64, i64 } %1
}

; <usize as core::slice::index::SliceIndex<[u32]>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSmE5indexCseGb2pkncjeE_6panics(i64 %self, ptr align 4 %slice.0, i64 %slice.1, ptr align 8 %0) unnamed_addr #0 !guid !413 {
start:
  %_4 = icmp ult i64 %self, %slice.1
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_0 = getelementptr inbounds nuw i32, ptr %slice.0, i64 %self
  ret ptr %_0

panic:                                            ; preds = %start
; call core::panicking::panic_bounds_check
  call void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64 %self, i64 %slice.1, ptr align 8 %0) #28
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !414 {
start:
; call <alloc::alloc::Global>::deallocate_impl
  call void @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global15deallocate_implCseGb2pkncjeE_6panics(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) #25
  ret void
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate_zeroed
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator15allocate_zeroedCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !415 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext true) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::alloc::Global as core::alloc::Allocator>::allocate
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator8allocateCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1) unnamed_addr #0 !guid !416 {
start:
; call <alloc::alloc::Global>::alloc_impl
  %0 = call { ptr, i64 } @_RNvMs0_NtCs7CppTae75M1_5alloc5allocNtB5_6Global10alloc_implCseGb2pkncjeE_6panics(ptr %self, i64 %layout.0, i64 %layout.1, i1 zeroext false) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !417 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCseGb2pkncjeE_6panics(ptr align 8 %self, i64 1, i64 1)
  ret void
}

; <alloc::raw_vec::RawVec<u32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs1_NtCs7CppTae75M1_5alloc7raw_vecINtB5_6RawVecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !418 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs3_NtCs7CppTae75M1_5alloc7raw_vecNtB5_11RawVecInner10deallocateCseGb2pkncjeE_6panics(ptr align 8 %self, i64 4, i64 4)
  ret void
}

; <core::ptr::unique::Unique<u8> as core::convert::Into<core::ptr::non_null::NonNull<u8>>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXs1_NtCsl10jNU3mE6R_4core7convertINtNtNtB7_3ptr6unique6UniquehEINtB5_4IntoINtNtBD_8non_null7NonNullhEE4intoCseGb2pkncjeE_6panics(ptr %self, ptr align 8 %0) unnamed_addr #0 !guid !419 {
start:
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_0 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %self) #25
  ret ptr %_0
}

; <alloc::collections::TryReserveErrorKind as core::convert::Into<alloc::collections::TryReserveError>>::into
; Function Attrs: inlinehint nonlazybind uwtable
define internal { i64, i64 } @_RNvXs1_NtCsl10jNU3mE6R_4core7convertNtNtCs7CppTae75M1_5alloc11collections19TryReserveErrorKindINtB5_4IntoNtBA_15TryReserveErrorE4intoCseGb2pkncjeE_6panics(i64 %self.0, i64 %self.1, ptr align 8 %0) unnamed_addr #0 !guid !420 {
start:
; call <alloc::collections::TryReserveError as core::convert::From<alloc::collections::TryReserveErrorKind>>::from
  %1 = call { i64, i64 } @_RNvXs0_NtCs7CppTae75M1_5alloc11collectionsNtB5_15TryReserveErrorINtNtCsl10jNU3mE6R_4core7convert4FromNtB5_19TryReserveErrorKindE4fromCseGb2pkncjeE_6panics(i64 %self.0, i64 %self.1) #25
  %_0.0 = extractvalue { i64, i64 } %1, 0
  %_0.1 = extractvalue { i64, i64 } %1, 1
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; <&core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !421 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRINtNtB8_6option6OptionyENtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !422 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <core::option::Option<u64> as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRNtNtCs7CppTae75M1_5alloc6string6StringNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !423 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <alloc::string::String as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&u8 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRhNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !424 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u8 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&i32 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRlNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !425 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <i32 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 4 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&() as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRuNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !426 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <() as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCseGb2pkncjeE_6panics(ptr %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs1g_NtCsl10jNU3mE6R_4core3fmtRyNtB6_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !427 {
start:
  %_3 = load ptr, ptr %self, align 8
; call <u64 as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %f) #25
  ret i1 %_0
}

; <&str as alloc::string::SpecToString>::spec_to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !428 {
start:
  %s.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %s.1 = load i64, ptr %0, align 8
; call <alloc::string::String as core::convert::From<&str>>::from
  call void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #25
  ret void
}

; <str as alloc::borrow::ToOwned>::to_owned
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #0 !guid !429 {
start:
  %_2 = alloca [24 x i8], align 8
  %0 = insertvalue { ptr, i64 } poison, ptr %self.0, 0
  %1 = insertvalue { ptr, i64 } %0, i64 %self.1, 1
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
; call <[u8] as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_2, ptr %_3.0, i64 %_3.1)
; call <alloc::string::String>::from_utf8_unchecked
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String19from_utf8_uncheckedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %_2) #25
  ret void
}

; <[u8] as alloc::borrow::ToOwned>::to_owned
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXs7_NtCs7CppTae75M1_5alloc5sliceShNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) unnamed_addr #1 !guid !430 {
start:
; call <[u8]>::to_vec
  call void @_RNvMNtCs7CppTae75M1_5alloc5sliceSh6to_vecCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %self.0, i64 %self.1) #25
  ret void
}

; <core::any::TypeId as core::cmp::PartialEq>::eq
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXs7_NtCsl10jNU3mE6R_4core3anyNtB5_6TypeIdNtNtB7_3cmp9PartialEq2eqCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %other) unnamed_addr #0 !guid !431 {
start:
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [16 x i8], align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %self, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %other, i64 16, i1 false)
; call core::intrinsics::type_id_eq
  %_0 = call zeroext i1 @_RNvNtCsl10jNU3mE6R_4core10intrinsics10type_id_eqCseGb2pkncjeE_6panics(ptr align 8 %_3, ptr align 8 %_4) #35
  ret i1 %_0
}

; <alloc::vec::Vec<u32> as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !432 {
start:
; call <alloc::vec::Vec<u32>>::as_slice
  %0 = call { ptr, i64 } @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE8as_sliceCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <alloc::boxed::Box<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDG0_INtNtNtCsl10jNU3mE6R_4core3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBS_6marker4SyncNtB2v_4SendEL_ENtNtBQ_4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !433 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDG0_INtNtNtB9_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB9_6marker4SyncNtB2o_4SendEL_E6as_ptrCseGb2pkncjeE_6panics(ptr %ptr.0, ptr align 8 %ptr.1) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDG0_INtNtNtB7_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtB7_6marker4SyncNtB2C_4SendEL_ECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1) #25
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn for<'a, 'b> core::ops::function::Fn<(&'a std::panic::PanicHookInfo<'b>,), Output = ()> + core::marker::Sync + core::marker::Send>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDG0_INtNtNtBa_3ops8function2FnTRL1_INtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoL0_EEEp6OutputuNtNtBa_6marker4SyncNtB2p_4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %ptr.0, ptr align 8 %ptr.1) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %_12) #25
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %6, i64 %8) #25
  br label %bb7
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtNtBM_3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !434 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %ptr.1 = load ptr, ptr %0, align 8
; call <core::ptr::unique::Unique<dyn core::any::Any + core::marker::Send>>::as_ptr
  %1 = call { ptr, ptr } @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueDNtNtB9_3any3AnyNtNtB9_6marker4SendEL_E6as_ptrCseGb2pkncjeE_6panics(ptr %ptr.0, ptr align 8 %ptr.1) #25
  %_5.0 = extractvalue { ptr, ptr } %1, 0
  %_5.1 = extractvalue { ptr, ptr } %1, 1
; call <core::alloc::layout::Layout>::for_value_raw::<dyn core::any::Any + core::marker::Send>
  %2 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawDNtNtB7_3any3AnyNtNtB7_6marker4SendEL_ECseGb2pkncjeE_6panics(ptr %_5.0, ptr align 8 %_5.1) #25
  %3 = extractvalue { i64, i64 } %2, 0
  %4 = extractvalue { i64, i64 } %2, 1
  store i64 %3, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %4, ptr %5, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 16
; call <core::ptr::unique::Unique<dyn core::any::Any + core::marker::Send>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueDNtNtBa_3any3AnyNtNtBa_6marker4SendEL_E4casthECseGb2pkncjeE_6panics(ptr %ptr.0, ptr align 8 %ptr.1) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %_12) #25
  %6 = load i64, ptr %layout, align 8
  %7 = getelementptr inbounds i8, ptr %layout, i64 8
  %8 = load i64, ptr %7, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %6, i64 %8) #25
  br label %bb7
}

; <alloc::boxed::Box<alloc::string::String> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxNtNtB7_6string6StringENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !435 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<alloc::string::String>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE6as_ptrCseGb2pkncjeE_6panics(ptr %ptr) #25
; call <core::alloc::layout::Layout>::for_value_raw::<alloc::string::String>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawNtNtCs7CppTae75M1_5alloc6string6StringECseGb2pkncjeE_6panics(ptr %_5) #25
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<alloc::string::String>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueNtNtCs7CppTae75M1_5alloc6string6StringE4casthECseGb2pkncjeE_6panics(ptr %ptr) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %_12) #25
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %4, i64 %6) #25
  br label %bb7
}

; <alloc::boxed::Box<u64> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXs8_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxyENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !436 {
start:
  %layout = alloca [16 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
; call <core::ptr::unique::Unique<u64>>::as_ptr
  %_5 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniqueyE6as_ptrCseGb2pkncjeE_6panics(ptr %ptr) #25
; call <core::alloc::layout::Layout>::for_value_raw::<u64>
  %0 = call { i64, i64 } @_RINvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB3_6Layout13for_value_rawyECseGb2pkncjeE_6panics(ptr %_5) #25
  %1 = extractvalue { i64, i64 } %0, 0
  %2 = extractvalue { i64, i64 } %0, 1
  store i64 %1, ptr %layout, align 8
  %3 = getelementptr inbounds i8, ptr %layout, i64 8
  store i64 %2, ptr %3, align 8
; call <core::alloc::layout::Layout>::size
  %_7 = call i64 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout4sizeCseGb2pkncjeE_6panics(ptr align 8 %layout) #25
  %_6 = icmp ne i64 %_7, 0
  br i1 %_6, label %bb4, label %bb7

bb7:                                              ; preds = %bb4, %start
  ret void

bb4:                                              ; preds = %start
  %_10 = getelementptr inbounds i8, ptr %self, i64 8
; call <core::ptr::unique::Unique<u64>>::cast::<u8>
  %_12 = call ptr @_RINvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB6_6UniqueyE4casthECseGb2pkncjeE_6panics(ptr %ptr) #25
; call <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
  %_11 = call ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %_12) #25
  %4 = load i64, ptr %layout, align 8
  %5 = getelementptr inbounds i8, ptr %layout, i64 8
  %6 = load i64, ptr %5, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs1_NtCs7CppTae75M1_5alloc5allocNtB5_6GlobalNtNtCsl10jNU3mE6R_4core5alloc9Allocator10deallocateCseGb2pkncjeE_6panics(ptr %_10, ptr %_11, i64 %4, i64 %6) #25
  br label %bb7
}

; <&str as alloc::string::ToString>::to_string
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsB_NtCs7CppTae75M1_5alloc6stringReNtB5_8ToString9to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) unnamed_addr #0 !guid !437 {
start:
; call <&str as alloc::string::SpecToString>::spec_to_string
  call void @_RNvXs25_NtCs7CppTae75M1_5alloc6stringReNtB6_12SpecToString14spec_to_stringCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %self) #25
  ret void
}

; <alloc::string::String as core::convert::From<&str>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsK_NtCs7CppTae75M1_5alloc6stringNtB5_6StringINtNtCsl10jNU3mE6R_4core7convert4FromReE4fromCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) unnamed_addr #0 !guid !438 {
start:
; call <str as alloc::borrow::ToOwned>::to_owned
  call void @_RNvXs2_NtCs7CppTae75M1_5alloc3streNtNtB7_6borrow7ToOwned8to_ownedCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr %s.0, i64 %s.1) #25
  ret void
}

; <i32 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsQ_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 4 %self, ptr align 8 %f) unnamed_addr #0 !guid !439 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <i32 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <i32 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <i32 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <core::option::Option<alloc::string::String> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionNtNtCs7CppTae75M1_5alloc6string6StringENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !440 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -1
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.5)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %7 = load i8, ptr %_0, align 1
  %8 = trunc nuw i8 %7 to i1
  ret i1 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<u64> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsR_NtCsl10jNU3mE6R_4core6optionINtB5_6OptionyENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !441 {
start:
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %4 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_9535bf4c204f3eb9b19ec2c83e446e52, i64 4, ptr %__self_0, ptr align 8 @vtable.6)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr @alloc_37d2e53432a03a1f90b3e7253015eaf9, i64 4)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define internal i8 @_RNvXsU_NtCsddYV2PBJW9h_3std7processuNtB5_11Termination6reportCseGb2pkncjeE_6panics() unnamed_addr #0 !guid !442 {
start:
  ret i8 0
}

; <u8 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsU_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !443 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u8 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u8 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u8 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <u64 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsX_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !444 {
start:
  %_0 = alloca [1 x i8], align 1
; call <core::fmt::Formatter>::debug_lower_hex
  %_3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8 %f)
  br i1 %_3, label %bb2, label %bb3

bb3:                                              ; preds = %start
; call <core::fmt::Formatter>::debug_upper_hex
  %_5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8 %f)
  br i1 %_5, label %bb5, label %bb6

bb2:                                              ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %0 = call zeroext i1 @_RNvXsC_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8LowerHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %_0, align 1
  br label %bb7

bb6:                                              ; preds = %bb3
; call <u64 as core::fmt::Display>::fmt
  %2 = call zeroext i1 @_RNvXsd_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impyNtB9_7Display3fmt(ptr align 8 %self, ptr align 8 %f)
  %3 = zext i1 %2 to i8
  store i8 %3, ptr %_0, align 1
  br label %bb7

bb5:                                              ; preds = %bb3
; call <u64 as core::fmt::UpperHex>::fmt
  %4 = call zeroext i1 @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt(ptr align 8 %self, ptr align 8 %f)
  %5 = zext i1 %4 to i8
  store i8 %5, ptr %_0, align 1
  br label %bb7

bb7:                                              ; preds = %bb2, %bb5, %bb6
  %6 = load i8, ptr %_0, align 1
  %7 = trunc nuw i8 %6 to i1
  ret i1 %7
}

; <std::panicking::begin_panic::Payload<u64> as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXs_NvNtCsddYV2PBJW9h_3std9panicking11begin_panicINtB4_7PayloadyENtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !445 {
start:
  %_4 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  %2 = trunc nuw i64 %_4 to i1
  br i1 %2, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %a = getelementptr inbounds i8, ptr %self, i64 8
; call std::panicking::payload_as_str
  %3 = call { ptr, i64 } @_RNvNtCsddYV2PBJW9h_3std9panicking14payload_as_str(ptr %a, ptr align 8 @vtable.4)
  %_6.0 = extractvalue { ptr, i64 } %3, 0
  %_6.1 = extractvalue { ptr, i64 } %3, 1
; call <core::fmt::Formatter>::write_str
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8 %f, ptr %_6.0, i64 %_6.1)
  ret i1 %_0

bb2:                                              ; preds = %start
; call std::process::abort
  call void @_RNvNtCsddYV2PBJW9h_3std7process5abort() #33
  unreachable

bb1:                                              ; No predecessors!
  unreachable
}

; <core::ptr::unique::Unique<u8> as core::convert::From<core::ptr::non_null::NonNull<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsa_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehEINtNtB9_7convert4FromINtNtB7_8non_null7NonNullhEE4fromCseGb2pkncjeE_6panics(ptr %pointer) unnamed_addr #0 !guid !446 {
start:
; call <core::ptr::unique::Unique<u8>>::from_non_null
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE13from_non_nullCseGb2pkncjeE_6panics(ptr %pointer) #25
  ret ptr %_0
}

; <alloc::vec::Vec<u32> as core::ops::index::Index<usize>>::index
; Function Attrs: inlinehint nonlazybind uwtable
define internal align 4 ptr @_RNvXsd_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmEINtNtNtCsl10jNU3mE6R_4core3ops5index5IndexjE5indexCseGb2pkncjeE_6panics(ptr align 8 %self, i64 %index, ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !447 {
start:
  %_5 = alloca [1 x i8], align 1
  store i8 0, ptr %_5, align 1
  store i8 1, ptr %_5, align 1
; call <alloc::vec::Vec<u32> as core::ops::deref::Deref>::deref
  %1 = call { ptr, i64 } @_RNvXs8_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_3.0 = extractvalue { ptr, i64 } %1, 0
  %_3.1 = extractvalue { ptr, i64 } %1, 1
  br label %bb1

bb1:                                              ; preds = %start
  store i8 0, ptr %_5, align 1
; call <usize as core::slice::index::SliceIndex<[u32]>>::index
  %_0.i = call align 4 ptr @_RNvXs0_NtNtCsl10jNU3mE6R_4core5slice5indexjINtB5_10SliceIndexSmE5indexCseGb2pkncjeE_6panics(i64 %index, ptr align 4 %_3.0, i64 %_3.1, ptr align 8 %0) #25
  br label %bb2

bb2:                                              ; preds = %bb1
  ret ptr %_0.i

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable

bb5:                                              ; No predecessors!
  unreachable
}

; <core::ptr::non_null::NonNull<u8> as core::convert::From<core::ptr::unique::Unique<u8>>>::from
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsh_NtNtCsl10jNU3mE6R_4core3ptr8non_nullINtB5_7NonNullhEINtNtB9_7convert4FromINtNtB7_6unique6UniquehEE4fromCseGb2pkncjeE_6panics(ptr %unique) unnamed_addr #0 !guid !448 {
start:
; call <core::ptr::unique::Unique<u8>>::as_non_null_ptr
  %_0 = call ptr @_RNvMs1_NtNtCsl10jNU3mE6R_4core3ptr6uniqueINtB5_6UniquehE15as_non_null_ptrCseGb2pkncjeE_6panics(ptr %unique) #25
  ret ptr %_0
}

; <alloc::boxed::Box<dyn core::any::Any + core::marker::Send> as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
define internal zeroext i1 @_RNvXsn_NtCs7CppTae75M1_5alloc5boxedINtB5_3BoxDNtNtCsl10jNU3mE6R_4core3any3AnyNtNtBM_6marker4SendEL_ENtNtBM_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #1 !guid !449 {
start:
  %_4.0 = load ptr, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_4.1 = load ptr, ptr %0, align 8
; call <dyn core::any::Any + core::marker::Send as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXs0_NtCsl10jNU3mE6R_4core3anyDNtB5_3AnyNtNtB7_6marker4SendEL_NtNtB7_3fmt5Debug3fmt(ptr %_4.0, ptr align 8 %_4.1, ptr align 8 %f)
  ret i1 %_0
}

; <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VechENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !450 {
start:
; call <alloc::vec::Vec<u8>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VechE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u8>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOh10cast_sliceCseGb2pkncjeE_6panics(ptr %_3, i64 %_4) #25
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::vec::Vec<u32> as core::ops::drop::Drop>::drop
; Function Attrs: nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc3vecINtB5_3VecmENtNtNtCsl10jNU3mE6R_4core3ops4drop4Drop4dropCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !451 {
start:
; call <alloc::vec::Vec<u32>>::as_mut_ptr
  %_3 = call ptr @_RNvMs_NtCs7CppTae75M1_5alloc3vecINtB4_3VecmE10as_mut_ptrCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %0 = getelementptr inbounds i8, ptr %self, i64 16
  %_4 = load i64, ptr %0, align 8
; call <*mut u32>::cast_slice
  %1 = call { ptr, i64 } @_RNvMs_NtNtCsl10jNU3mE6R_4core3ptr7mut_ptrOm10cast_sliceCseGb2pkncjeE_6panics(ptr %_3, i64 %_4) #25
  %_2.0 = extractvalue { ptr, i64 } %1, 0
  %_2.1 = extractvalue { ptr, i64 } %1, 1
  ret void
}

; <alloc::string::String as core::default::Default>::default
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvXsp_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core7default7Default7defaultCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) unnamed_addr #0 !guid !452 {
start:
; call <alloc::string::String>::new
  call void @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String3newCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0) #25
  ret void
}

; <core::result::Result<core::ptr::non_null::NonNull<u8>, core::alloc::AllocError> as core::ops::try_trait::Try>::branch
; Function Attrs: inlinehint nonlazybind uwtable
define internal ptr @_RNvXsp_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullhENtNtB7_5alloc10AllocErrorENtNtNtB7_3ops9try_trait3Try6branchCseGb2pkncjeE_6panics(ptr %0) unnamed_addr #0 !guid !453 {
start:
  %_0 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 1, i64 0
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb4

bb3:                                              ; preds = %start
  %v = load ptr, ptr %self, align 8
  store ptr %v, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Display>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsq_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt7Display3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !454 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Display>::fmt
  %_0 = call zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <core::result::Result<core::ptr::non_null::NonNull<[u8]>, core::alloc::AllocError> as core::ops::try_trait::FromResidual<core::result::Result<core::convert::Infallible, core::alloc::AllocError>>>::from_residual
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsq_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultINtNtNtB7_3ptr8non_null7NonNullShENtNtB7_5alloc10AllocErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleB1i_EE13from_residualCseGb2pkncjeE_6panics(ptr align 8 %0) unnamed_addr #0 !guid !455 {
start:
  br label %bb2

bb2:                                              ; preds = %start
  ret { ptr, i64 } { ptr null, i64 undef }

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXsr_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !456 {
start:
; call <alloc::string::String as core::ops::deref::Deref>::deref
  %0 = call { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_3.0 = extractvalue { ptr, i64 } %0, 0
  %_3.1 = extractvalue { ptr, i64 } %0, 1
; call <str as core::fmt::Debug>::fmt
  %_0 = call zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr %_3.0, i64 %_3.1, ptr align 8 %f)
  ret i1 %_0
}

; <() as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXss_NtCsl10jNU3mE6R_4core3fmtuNtB5_5Debug3fmtCseGb2pkncjeE_6panics(ptr %self, ptr align 8 %f) unnamed_addr #0 !guid !457 {
start:
; call <core::fmt::Formatter>::pad
  %_0 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8 %f, ptr @alloc_ae6dc619079e3c3b08144a35532ecff7, i64 2)
  ret i1 %_0
}

; <core::result::Result<u8, core::option::Option<alloc::string::String>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResulthINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !458 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -2
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.8)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.7)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<i32, core::option::Option<alloc::string::String>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultlINtNtB7_6option6OptionNtNtCs7CppTae75M1_5alloc6string6StringEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !459 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = icmp eq i64 %0, -2
  %_3 = select i1 %1, i64 0, i64 1
  %2 = trunc nuw i64 %_3 to i1
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %3 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.8)
  %4 = zext i1 %3 to i8
  store i8 %4, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  %5 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %5, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %6 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.9)
  %7 = zext i1 %6 to i8
  store i8 %7, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %8 = load i8, ptr %_0, align 1
  %9 = trunc nuw i8 %8 to i1
  ret i1 %9

bb1:                                              ; No predecessors!
  unreachable
}

; <core::result::Result<(), core::option::Option<u64>> as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nonlazybind uwtable
define internal zeroext i1 @_RNvXst_NtCsl10jNU3mE6R_4core6resultINtB5_6ResultuINtNtB7_6option6OptionyEENtNtB7_3fmt5Debug3fmtCseGb2pkncjeE_6panics(ptr align 8 %self, ptr align 8 %f) unnamed_addr #0 !guid !460 {
start:
  %__self_01 = alloca [8 x i8], align 8
  %__self_0 = alloca [8 x i8], align 8
  %_0 = alloca [1 x i8], align 1
  %0 = load i64, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = icmp eq i64 %0, 2
  %_3 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_3 to i1
  br i1 %4, label %bb2, label %bb3

bb2:                                              ; preds = %start
  store ptr %self, ptr %__self_01, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %5 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_bf301217d548e4f1fd13189dd935c554, i64 3, ptr %__self_01, ptr align 8 @vtable.b)
  %6 = zext i1 %5 to i8
  store i8 %6, ptr %_0, align 1
  br label %bb4

bb3:                                              ; preds = %start
  store ptr %self, ptr %__self_0, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %7 = call zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_c73d17da7498663a071b898ac2218935, i64 2, ptr %__self_0, ptr align 8 @vtable.a)
  %8 = zext i1 %7 to i8
  store i8 %8, ptr %_0, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %9 = load i8, ptr %_0, align 1
  %10 = trunc nuw i8 %9 to i1
  ret i1 %10

bb1:                                              ; No predecessors!
  unreachable
}

; <alloc::string::String as core::ops::deref::Deref>::deref
; Function Attrs: inlinehint nonlazybind uwtable
define internal { ptr, i64 } @_RNvXsx_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtNtCsl10jNU3mE6R_4core3ops5deref5Deref5derefCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #0 !guid !461 {
start:
; call <alloc::string::String>::as_str
  %0 = call { ptr, i64 } @_RNvMNtCs7CppTae75M1_5alloc6stringNtB2_6String6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) #25
  %_0.0 = extractvalue { ptr, i64 } %0, 0
  %_0.1 = extractvalue { ptr, i64 } %0, 1
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %_0.1, 1
  ret { ptr, i64 } %2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYFEuINtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %_1) unnamed_addr #0 !guid !462 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::panicking::begin_panic::Payload<u64> as core::panic::PanicPayload>::as_str
; Function Attrs: nonlazybind uwtable
define internal { ptr, i64 } @_RNvYINtNvNtCsddYV2PBJW9h_3std9panicking11begin_panic7PayloadyENtNtCsl10jNU3mE6R_4core5panic12PanicPayload6as_strCseGb2pkncjeE_6panics(ptr align 8 %self) unnamed_addr #1 !guid !463 {
start:
  ret { ptr, i64 } { ptr null, i64 undef }
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal i32 @_RNvYNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceuE9call_onceCseGb2pkncjeE_6panics(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !464 {
start:
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; call std::rt::lang_start::<()>::{closure#0}
  %_0 = call i32 @_RNCINvNtCsddYV2PBJW9h_3std2rt10lang_startuE0CseGb2pkncjeE_6panics(ptr align 8 %_1) #25
  br label %bb1

bb1:                                              ; preds = %start
  ret i32 %_0

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <panics::main::{closure#0} as core::ops::function::FnOnce<(&std::panic::PanicHookInfo,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNCNvCseGb2pkncjeE_6panics4main0INtNtNtCsl10jNU3mE6R_4core3ops8function6FnOnceTRNtNtCsddYV2PBJW9h_3std5panic13PanicHookInfoEE9call_onceB6_(ptr align 8 %0) unnamed_addr #0 personality ptr @rust_eh_personality !guid !465 {
start:
  %_2 = alloca [8 x i8], align 8
  %_1 = alloca [0 x i8], align 1
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call panics::main::{closure#0}
  call void @_RNCNvCseGb2pkncjeE_6panics4main0B3_(ptr %_1, ptr align 8 %1) #25
  br label %bb1

bb1:                                              ; preds = %start
  ret void

bb3:                                              ; No predecessors!
  unreachable

bb4:                                              ; No predecessors!
  unreachable
}

; <<alloc::string::String as core::clone::Clone>::clone as core::ops::function::FnOnce<(&alloc::string::String,)>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define internal void @_RNvYNvYNtNtCs7CppTae75M1_5alloc6string6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5cloneINtNtNtBL_3ops8function6FnOnceTRB5_EE9call_onceCseGb2pkncjeE_6panics(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 !guid !466 {
start:
  %_2 = alloca [8 x i8], align 8
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
; call <alloc::string::String as core::clone::Clone>::clone
  call void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8 %_0, ptr align 8 %1)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #10

; <bool as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtCsl10jNU3mE6R_4core3fmtbNtB5_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs9_NtNtNtCsl10jNU3mE6R_4core3fmt3num3implNtB9_7Display3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #8

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking16panic_in_cleanup() unnamed_addr #11

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCsddYV2PBJW9h_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nonlazybind
define internal zeroext i1 @__rust_try(ptr %0, ptr %1, ptr %2) unnamed_addr #12 personality ptr @rust_eh_personality !guid !467 {
entry-block:
  invoke void %0(ptr %1)
          to label %then unwind label %catch

then:                                             ; preds = %entry-block
  ret i1 false

catch:                                            ; preds = %entry-block
  %3 = landingpad { ptr, i32 }
          catch ptr null
  %4 = extractvalue { ptr, i32 } %3, 0
  call void %2(ptr %1, ptr %4)
  ret i1 true
}

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #13

; std::panicking::catch_unwind::cleanup
; Function Attrs: cold minsize nonlazybind optsize uwtable
declare { ptr, ptr } @_RNvNvNtCsddYV2PBJW9h_3std9panicking12catch_unwind7cleanup(ptr) unnamed_addr #14

; core::panicking::panic_cannot_unwind
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking19panic_cannot_unwind() unnamed_addr #11

; std::panicking::panic_with_hook
; Function Attrs: minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking15panic_with_hook(ptr, ptr align 8, ptr align 8, i1 zeroext, i1 zeroext) unnamed_addr #15

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #16

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #11

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #11

; std::io::stdio::_print
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtNtCsddYV2PBJW9h_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_add_overflow(ptr align 8) unnamed_addr #16

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCsl10jNU3mE6R_4core9panicking11panic_const24panic_const_sub_overflow(ptr align 8) unnamed_addr #16

; std::panicking::set_hook
; Function Attrs: nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std9panicking8set_hook(ptr, ptr align 8) unnamed_addr #1

; std::panicking::take_hook
; Function Attrs: nonlazybind uwtable
declare { ptr, ptr } @_RNvNtCsddYV2PBJW9h_3std9panicking9take_hook() unnamed_addr #1

; std::process::exit
; Function Attrs: noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process4exit(i32) unnamed_addr #17

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #16

; <core::alloc::layout::Layout>::is_size_alignment_valid
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMNtNtCsl10jNU3mE6R_4core5alloc6layoutNtB2_6Layout23is_size_alignment_valid(i64, i64) unnamed_addr #1

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc7raw_vec12handle_error(i64, i64) unnamed_addr #18

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #19

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #19

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #8

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #20

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs6C7K2MLX5zw_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #21

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs6C7K2MLX5zw_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #22

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn nonlazybind optsize uwtable
declare void @_RNvNtCs7CppTae75M1_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #18

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #23

; core::panicking::panic_nounwind
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking14panic_nounwind(ptr, i64) unnamed_addr #23

; std::process::abort
; Function Attrs: cold noreturn nonlazybind uwtable
declare void @_RNvNtCsddYV2PBJW9h_3std7process5abort() unnamed_addr #24

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nonlazybind optsize uwtable
declare void @_RNvNtCsl10jNU3mE6R_4core9panicking18panic_bounds_check(i64, i64, ptr align 8) unnamed_addr #3

; <core::fmt::Formatter>::debug_lower_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_lower_hex(ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_upper_hex
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter15debug_upper_hex(ptr align 8) unnamed_addr #1

; <i32 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsx_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8UpperHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <i32 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsv_NtNtCsl10jNU3mE6R_4core3fmt3numlNtB7_8LowerHex3fmt(ptr align 4, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::write_str
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter9write_str(ptr align 8, ptr, i64) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXNtNtNtCsl10jNU3mE6R_4core3fmt3num3imphNtB6_7Display3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsg_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8UpperHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u8 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXse_NtNtCsl10jNU3mE6R_4core3fmt3numhNtB7_8LowerHex3fmt(ptr, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsd_NtNtNtCsl10jNU3mE6R_4core3fmt3num3impyNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::UpperHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsE_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8UpperHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; <u64 as core::fmt::LowerHex>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsC_NtNtCsl10jNU3mE6R_4core3fmt3numyNtB7_8LowerHex3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; std::panicking::payload_as_str
; Function Attrs: nonlazybind uwtable
declare { ptr, i64 } @_RNvNtCsddYV2PBJW9h_3std9panicking14payload_as_str(ptr, ptr align 8) unnamed_addr #1

; <dyn core::any::Any + core::marker::Send as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXs0_NtCsl10jNU3mE6R_4core3anyDNtB5_3AnyNtNtB7_6marker4SendEL_NtNtB7_3fmt5Debug3fmt(ptr, ptr align 8, ptr align 8) unnamed_addr #1

; <str as core::fmt::Display>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsi_NtCsl10jNU3mE6R_4core3fmteNtB5_7Display3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <str as core::fmt::Debug>::fmt
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvXsh_NtCsl10jNU3mE6R_4core3fmteNtB5_5Debug3fmt(ptr, i64, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::pad
; Function Attrs: nonlazybind uwtable
declare zeroext i1 @_RNvMsa_NtCsl10jNU3mE6R_4core3fmtNtB5_9Formatter3pad(ptr align 8, ptr, i64) unnamed_addr #1

; <alloc::string::String as core::clone::Clone>::clone
; Function Attrs: nonlazybind uwtable
declare void @_RNvXs4_NtCs7CppTae75M1_5alloc6stringNtB5_6StringNtNtCsl10jNU3mE6R_4core5clone5Clone5clone(ptr sret([24 x i8]) align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #12 !guid !468 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsddYV2PBJW9h_3std2rt10lang_startuECseGb2pkncjeE_6panics(ptr @_RNvCseGb2pkncjeE_6panics4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { inlinehint noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { cold minsize noinline noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #4 = { noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { inlinehint minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #10 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nonlazybind "target-cpu"="x86-64" }
attributes #13 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #14 = { cold minsize nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #15 = { minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #16 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #17 = { noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #18 = { cold minsize noreturn nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #19 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #20 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #21 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #22 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6C7K2MLX5zw_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #23 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #24 = { cold noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #25 = { inlinehint }
attributes #26 = { cold }
attributes #27 = { cold noreturn nounwind }
attributes #28 = { noinline noreturn }
attributes #29 = { inlinehint noreturn }
attributes #30 = { cold noinline noreturn nounwind }
attributes #31 = { inlinehint nounwind }
attributes #32 = { noinline }
attributes #33 = { noreturn }
attributes #34 = { noinline noreturn nounwind }
attributes #35 = { nounwind }

!llvm.module.flags = !{!83, !84, !85, !86}
!llvm.ident = !{!87}

!0 = !{i64 -2493779167280624301}
!1 = !{i64 1208957907717419987}
!2 = !{i64 6423594196526314803}
!3 = !{i64 -5356250704026679138}
!4 = !{i64 2961479790530443818}
!5 = !{i64 -3401444423719217253}
!6 = !{i64 8891002946310740290}
!7 = !{i64 788081539932565442}
!8 = !{i64 7732331829416495759}
!9 = !{i64 -3981664675184448266}
!10 = !{i64 -5071519447612155596}
!11 = !{i64 -4988292794645257178}
!12 = !{i64 980210168389032609}
!13 = !{i64 -4882986603634069232}
!14 = !{i64 -3005372252893661383}
!15 = !{i64 4609579291053422603}
!16 = !{i64 3596965049277782570}
!17 = !{i64 2777624885515822651}
!18 = !{i64 7844761308724398288}
!19 = !{i64 4842289176554857169}
!20 = !{i64 2921346418304255893}
!21 = !{i64 -6103199286651190864}
!22 = !{i64 8563473757190057284}
!23 = !{i64 -3108713904052565023}
!24 = !{i64 99499065819117685}
!25 = !{i64 -8432432487554342137}
!26 = !{i64 2134700603267569285}
!27 = !{i64 -5396612712977725596}
!28 = !{i64 -4412256379462227110}
!29 = !{i64 -8857369527434967825}
!30 = !{i64 2404126197610985173}
!31 = !{i64 576422902352836766}
!32 = !{i64 -5638321319456089788}
!33 = !{i64 -3207152940169518150}
!34 = !{i64 -3029844248624312979}
!35 = !{i64 5049289066004386945}
!36 = !{i64 -6729519479804392288}
!37 = !{i64 -3167056848200926882}
!38 = !{i64 5207604533642723614}
!39 = !{i64 7044128501033304411}
!40 = !{i64 6683193647633145676}
!41 = !{i64 -7457445578035369138}
!42 = !{i64 -1347217531411697799}
!43 = !{i64 -5481874300117241725}
!44 = !{i64 -8311165338614920329}
!45 = !{i64 -3066455594930163733}
!46 = !{i64 692931618294192451}
!47 = !{i64 -4507677279253300057}
!48 = !{i64 1736512444711130639}
!49 = !{i64 877294703120583304}
!50 = !{i64 -7317669195082763514}
!51 = !{i64 3702940736352118170}
!52 = !{i64 2643728822734262686}
!53 = !{i64 6768994950891968484}
!54 = !{i64 4320985874275133755}
!55 = !{i64 4052311488175971395}
!56 = !{i64 -2807819867776546229}
!57 = !{i64 -620909799470651325}
!58 = !{i64 -7334063765312658700}
!59 = !{i64 3022404309139606455}
!60 = !{i64 3334142572239290984}
!61 = !{i64 7423254117282367028}
!62 = !{i64 4200626085436102217}
!63 = !{i64 6082881058793857041}
!64 = !{i64 -6288849203889583699}
!65 = !{i64 302623715901051786}
!66 = !{i64 -9179103885220902954}
!67 = !{i64 -3456896445085774691}
!68 = !{i64 -505912989066123843}
!69 = !{i64 -726110331751001075}
!70 = !{i64 2000539387579406578}
!71 = !{i64 5529955749004293916}
!72 = !{i64 -7235210469069962263}
!73 = !{i64 6205583340840306213}
!74 = !{i64 -2079516508712941149}
!75 = !{i64 8989933794877671705}
!76 = !{i64 -4505891931221296063}
!77 = !{i64 8316537712808156689}
!78 = !{i64 6229991252516240826}
!79 = !{i64 6365320554810069131}
!80 = !{i64 -3521331006013510087}
!81 = !{i64 -1859781851218846456}
!82 = !{i64 -5032279224836018063}
!83 = !{i32 8, !"PIC Level", i32 2}
!84 = !{i32 7, !"PIE Level", i32 2}
!85 = !{i32 2, !"RtLibUseGOT", i32 1}
!86 = !{i32 7, !"uwtable", i32 2}
!87 = !{!"rustc version 1.99.1 (58cf8f9c3 2026-10-13) (Alpine Linux Rust 1.99.1-r0)"}
!88 = !{i64 -6952356556240661814}
!89 = !{i64 1133263438580251217}
!90 = !{i64 2224638660137371447}
!91 = !{i64 5572620180629208040}
!92 = !{i64 1761714520277447330}
!93 = !{i64 5082061661087059114}
!94 = !{i64 -7655186839982109514}
!95 = !{i64 -9106327572736421219}
!96 = !{i64 -8882773562057141829}
!97 = !{i64 8151770952107371830}
!98 = !{i64 4768298313051841941}
!99 = !{i64 -3738136729010150234}
!100 = !{i64 -2271441780443507501}
!101 = !{i64 -8199720594301612576}
!102 = !{i64 -7218086156134606932}
!103 = !{i64 5269422196824196945}
!104 = !{i64 2217149738215784870}
!105 = !{i64 -5089356076365160607}
!106 = !{i64 8027894719033211666}
!107 = !{i64 2694147326160939730}
!108 = !{i64 -2253009204424128743}
!109 = !{i64 7670066073845004524}
!110 = !{i64 1147408696861457250}
!111 = !{i64 1222595694332470589}
!112 = !{i64 3652923512638150484}
!113 = !{i64 -7952576561419812812}
!114 = !{i64 -4517012105260341799}
!115 = !{i64 -5464867015772116039}
!116 = !{i64 8976719125893870014}
!117 = !{i64 -2217331659247652135}
!118 = !{i64 8843668367424603988}
!119 = !{i64 -8160521358668488445}
!120 = !{i64 5728652024390193952}
!121 = !{i64 6478178445923673875}
!122 = !{i64 3016280594200504350}
!123 = !{i64 -4470062068271521906}
!124 = !{i64 -6965744514756882586}
!125 = !{i64 -240621713624905051}
!126 = !{i64 509958630160434231}
!127 = !{i64 -4671858223165155422}
!128 = !{i64 -3713016501546592714}
!129 = !{i64 -3665124076452927194}
!130 = !{i64 8776718972062272940}
!131 = !{i64 3873269745258327107}
!132 = !{i64 -4271769106560985845}
!133 = !{i64 -5629133200747891136}
!134 = !{i64 1518304822886422269}
!135 = !{i64 753661868382070996}
!136 = !{i64 2753412520765024960}
!137 = !{i64 -4576302244505805119}
!138 = !{i64 5567448280889261194}
!139 = !{i64 -3060073574493027915}
!140 = !{i64 -635867198150827427}
!141 = !{i64 2695047712100352886}
!142 = !{i64 -1362498895192875271}
!143 = !{i64 7258642191597712978}
!144 = !{}
!145 = !{i64 1457944944278032080}
!146 = !{i64 -1703480618747896273}
!147 = !{i64 4319444938500996405}
!148 = !{i64 1172222633294526077}
!149 = !{i64 2333457655006828776}
!150 = !{i64 -643543568240074914}
!151 = !{i64 -2647956039757952917}
!152 = !{i64 -2164485225933413429}
!153 = !{i64 964608857734655080}
!154 = !{i64 -7920072275997662697}
!155 = !{i64 3056155975417361644}
!156 = !{i64 -6995745809645439421}
!157 = !{i64 -4502938848911743220}
!158 = !{i64 -4010632222680605773}
!159 = !{i64 -963249951976168518}
!160 = !{i64 -8898058485598662946}
!161 = !{i64 -3268198669108626072}
!162 = !{i64 -4168046695701380807}
!163 = !{i64 -1988875521052614158}
!164 = !{i64 6821883899664113911}
!165 = !{i64 -6340184225945331994}
!166 = !{i64 1884650308998682136}
!167 = !{i64 4872637052914887925}
!168 = !{i64 435776538438485507}
!169 = !{i64 -8742019005803139187}
!170 = !{i64 1861970751934901077}
!171 = !{i64 -9026259935053962123}
!172 = !{i64 8164834616937106795}
!173 = !{i64 7926579248395741712}
!174 = !{i64 6545894656939472073}
!175 = !{i64 743855562828071151}
!176 = !{i64 7364987241347797797}
!177 = !{i64 7996463577896453157}
!178 = !{i64 -294140693094450715}
!179 = !{i64 3839739536483625434}
!180 = !{i64 7515942850166780773}
!181 = !{i64 442627378714031683}
!182 = !{i64 -1756830731746721402}
!183 = !{i64 -4413564777274010623}
!184 = !{i64 -9050075766900800808}
!185 = !{i64 -6042599337697936455}
!186 = !{i64 8577596716254700366}
!187 = !{i64 8441887133718696451}
!188 = !{i64 -8642685102604184103}
!189 = !{i64 -3354187849413904842}
!190 = !{i64 3504098879026380237}
!191 = !{i64 -6947769281004349913}
!192 = !{i64 1201345324733147127}
!193 = !{i64 -3688934762240791304}
!194 = !{i64 2277677993735861559}
!195 = !{i64 -6899602933721491208}
!196 = !{i64 -5466047578387750788}
!197 = !{i64 8217283934535255400}
!198 = !{i64 -6113563221550404169}
!199 = !{i64 -4953218395050461709}
!200 = !{i64 -5747564129198128789}
!201 = !{i64 -8989670239334155675}
!202 = !{i64 -2764390247450378804}
!203 = !{i64 8792996344165845051}
!204 = !{i64 -4864386066557686125}
!205 = !{i64 -2094620338651728568}
!206 = !{i64 1317781866065505}
!207 = !{i64 1324640065634921032}
!208 = !{i64 2229003545096304870}
!209 = !{i64 8708684069729819007}
!210 = !{i64 -4198634043639438075}
!211 = !{i64 8528850049794398043}
!212 = !{i64 3095575010650310376}
!213 = !{i64 -1261684364470924473}
!214 = !{i64 6973572072610238553}
!215 = !{i64 5166086312399630997}
!216 = !{i64 -4841057003702188408}
!217 = !{i64 -1974721998501145488}
!218 = !{i64 8188860582606171816}
!219 = !{i64 -5340046494180801143}
!220 = !{i64 -7554190426403637527}
!221 = !{i64 1456672556856389515}
!222 = !{i64 -6580344693357898314}
!223 = !{i64 3393877022876683785}
!224 = !{i64 -5991142457723329359}
!225 = !{i64 -8646164163127108748}
!226 = !{i64 -8497724877416256879}
!227 = !{i64 -6461360197485787082}
!228 = !{i64 -1039477695765711823}
!229 = !{i64 6254202374552442297}
!230 = !{i64 -3775161995293036592}
!231 = !{i64 3852851918349606188}
!232 = !{i64 -8392302851088250997}
!233 = !{i64 9184264244582243271}
!234 = !{i64 6361520969593812328}
!235 = !{i64 3038159018935187642}
!236 = !{i64 -4814645250736481124}
!237 = !{i64 8279767425853236006}
!238 = !{i64 8307965153042777408}
!239 = !{i64 -8265326322211251955}
!240 = !{i64 -6662938725145932966}
!241 = !{i64 -1822882181969888468}
!242 = !{i64 6074608682868900752}
!243 = !{i64 6227801940582305673}
!244 = !{i64 628969445224093317}
!245 = !{i64 2364622320996087613}
!246 = !{i64 -3293680003808909474}
!247 = !{i64 6396478518236781663}
!248 = !{i64 4617230870894404527}
!249 = !{i64 1740152363458035523}
!250 = !{i64 3993938978275726687}
!251 = !{i64 3132548509616971867}
!252 = !{i64 -40642646785485729}
!253 = !{i64 2606789744909526248}
!254 = !{i64 8751274939889053022}
!255 = !{i64 9178870146941793156}
!256 = !{i64 -3233061136429432758}
!257 = !{i64 3816323076261870142}
!258 = !{i64 2378935383915046223}
!259 = !{i64 -8845893073191810204}
!260 = !{i64 4582613916685560512}
!261 = !{i64 -6909857445594467514}
!262 = !{i64 6761627602321924331}
!263 = !{i64 -560269023889225501}
!264 = !{i64 -3240136902438193848}
!265 = !{i64 -5485060114546218156}
!266 = !{i64 8270054427073737945}
!267 = !{i64 911314053452120926}
!268 = !{i64 1877182796108078077}
!269 = !{i64 6827170824707073715}
!270 = !{i64 6798526975859915153}
!271 = !{i64 -4540083857836917887}
!272 = !{i64 969984789867905705}
!273 = !{i64 8797688039007324089}
!274 = !{i64 4274311021221847017}
!275 = !{i64 -5439544120652538416}
!276 = !{i64 8377821728774780319}
!277 = !{i64 -250936119651597897}
!278 = !{i64 -2651789050840950622}
!279 = !{i64 -7098751857668197291}
!280 = !{i64 4631064969503936645}
!281 = !{i64 -6008462575974975462}
!282 = !{i64 -4221087853340720554}
!283 = !{i64 -625836193462287077}
!284 = !{i64 -8036760724735186814}
!285 = !{i64 -8069288519486989822}
!286 = !{i64 3589080336701170611}
!287 = !{i64 -2946255707023913763}
!288 = !{i64 603105798031861374}
!289 = !{i64 -2223916365818429278}
!290 = !{i64 -4872203053891441844}
!291 = !{i64 4185460534806626813}
!292 = !{i64 -3291126169198111119}
!293 = !{i64 2193513613803235693}
!294 = !{i64 1027387497750642334}
!295 = !{i64 -582215508306346647}
!296 = !{i64 755202331056813600}
!297 = !{i64 7410036889571213650}
!298 = !{i64 -5680232268847202953}
!299 = !{i64 -4718962668758820594}
!300 = !{i64 -861867716879221684}
!301 = !{i64 -1996509927448887017}
!302 = !{i64 -7976567725226116445}
!303 = !{i64 8403791229579741356}
!304 = !{i64 7943120096224771977}
!305 = !{i64 -679254356118491641}
!306 = !{i64 -7905384415991226964}
!307 = !{i64 920996281870241555}
!308 = !{i64 -4154151048899110749}
!309 = !{i64 5106195378142639970}
!310 = !{i64 6813904099812256236}
!311 = !{i64 4024476195990447960}
!312 = !{i64 102107858229253846}
!313 = !{i64 685047982707958140}
!314 = !{i64 6099414823757201503}
!315 = !{i64 -6097260604204814695}
!316 = !{i64 -7266521994395967762}
!317 = !{i64 5860098013496398209}
!318 = !{i64 -4438439204017971540}
!319 = !{i64 -4927944946904730497}
!320 = !{i64 -77600087595065620}
!321 = !{i64 3512100545297986465}
!322 = !{i64 -4309751458831602919}
!323 = !{i64 -5293868592314058038}
!324 = !{i64 -2912674053402297990}
!325 = !{i64 509686021337924685}
!326 = !{i64 -709580205483824266}
!327 = !{i64 2035106730670819121}
!328 = !{i64 4014400766819656997}
!329 = !{i64 -2367802060766106567}
!330 = !{i64 -1994052493066816105}
!331 = !{i64 698599596574328199}
!332 = !{i64 7036615888491847442}
!333 = !{i64 -6865270139783451160}
!334 = !{i64 -980067060080316273}
!335 = !{i64 -6125528727597757192}
!336 = !{i64 -2037082091709337744}
!337 = !{i64 -8184553874587970345}
!338 = !{i64 3208406895400334301}
!339 = !{i64 -3752815637547068961}
!340 = !{i64 -1678522487719655038}
!341 = !{i64 -2997601288515956933}
!342 = !{i64 -8767397769133757208}
!343 = !{i64 -1447468607320587043}
!344 = !{i64 -6363770451128396554}
!345 = !{i64 -6021391578348642563}
!346 = !{i64 -7866685532314459126}
!347 = !{i64 -1000004758177196726}
!348 = !{i64 6700672834360432345}
!349 = !{i64 436102941257440115}
!350 = !{i64 90190579759062760}
!351 = !{i64 4623269014377030255}
!352 = !{i64 7517690197674258702}
!353 = !{i64 -8840720712504872286}
!354 = !{i64 4340475658800310563}
!355 = !{i64 -6950844088117830213}
!356 = !{i64 -8845452543962837663}
!357 = !{i64 -8303472255648643956}
!358 = !{i64 -4908851018894768552}
!359 = !{i64 -4330106366735211386}
!360 = !{i64 -7229188952408359395}
!361 = !{i64 5023027633549031592}
!362 = !{i64 4045862026971283700}
!363 = !{i64 -5158892371245612811}
!364 = !{i64 3713606846430906568}
!365 = !{i64 -8752969214390347308}
!366 = !{i64 1609589038781720879}
!367 = !{i64 3924040898618060945}
!368 = !{i64 -2476005197520479835}
!369 = !{i64 -1432665658785561984}
!370 = !{i64 5343055824091015689}
!371 = !{i64 -1343862333391621211}
!372 = !{i64 5705401455234433894}
!373 = !{i64 8406323178692658310}
!374 = !{i64 -5670997672785157295}
!375 = !{i64 1274286956123386035}
!376 = !{i64 1475612775256809551}
!377 = !{i64 4934800470033524624}
!378 = !{i64 -8453247733995640781}
!379 = !{i64 4628431546686540976}
!380 = !{i64 3243116870724392383}
!381 = !{i64 512311490497756534}
!382 = !{i64 -3169753529892943368}
!383 = !{i64 -2321076285018683494}
!384 = !{i64 3913741920722830567}
!385 = !{i64 673827160012687507}
!386 = !{i64 -6942687888014493335}
!387 = !{i64 1558557703929287480}
!388 = !{i64 -423893097844925362}
!389 = !{i64 -6061892751639681825}
!390 = !{i64 1005312155265887362}
!391 = !{i64 -4305422903907779412}
!392 = !{i64 226802698256750805}
!393 = !{i64 -6389441196477388746}
!394 = !{i64 -866462283150219}
!395 = !{i64 -1833113685198406983}
!396 = !{i64 -4095352174548544079}
!397 = !{i64 3544267021258248557}
!398 = !{i64 6027925398784475832}
!399 = !{i64 -2439549711136764642}
!400 = !{i64 3358492981697008189}
!401 = !{i64 5694257936774963863}
!402 = !{i64 7900199641090690628}
!403 = !{i64 -4145308177040719761}
!404 = !{i64 5666791314091481164}
!405 = !{i64 -5711324601256971662}
!406 = !{i64 -3743468362398233140}
!407 = !{i64 2042777209422420261}
!408 = !{i64 9004958115610356041}
!409 = !{i64 5222149809899979354}
!410 = !{i64 6799861780628996667}
!411 = !{i64 -3451065699460907515}
!412 = !{i64 125439131260134387}
!413 = !{i64 2268880559303429003}
!414 = !{i64 -4841745674710379277}
!415 = !{i64 -8868288920693130939}
!416 = !{i64 2991605329457611134}
!417 = !{i64 7255876862185723814}
!418 = !{i64 -4498303764927497984}
!419 = !{i64 -6688725255733141025}
!420 = !{i64 4993375924684469198}
!421 = !{i64 261905937459196452}
!422 = !{i64 -8149635205762438515}
!423 = !{i64 -4524934818297980858}
!424 = !{i64 -1094372416193026468}
!425 = !{i64 -9018941961404345948}
!426 = !{i64 -3218291904879622952}
!427 = !{i64 -5302644467134439577}
!428 = !{i64 -9195609212210476416}
!429 = !{i64 3789147084788905778}
!430 = !{i64 8407355072946361835}
!431 = !{i64 2110423025234355149}
!432 = !{i64 -5550870448663165119}
!433 = !{i64 5726240569488389223}
!434 = !{i64 -777744598322784249}
!435 = !{i64 2903431599885024645}
!436 = !{i64 -8026992919822840769}
!437 = !{i64 1512433693979055150}
!438 = !{i64 320121458441754668}
!439 = !{i64 -6311098623745847320}
!440 = !{i64 -4005680100744842706}
!441 = !{i64 5495701163451503543}
!442 = !{i64 -3106731790953631421}
!443 = !{i64 6166569272946530096}
!444 = !{i64 -3416375590731375166}
!445 = !{i64 -9221333948592381906}
!446 = !{i64 7284676899940004125}
!447 = !{i64 -4577917346625759239}
!448 = !{i64 -2502888870411546498}
!449 = !{i64 5879453042235638201}
!450 = !{i64 905918376157839407}
!451 = !{i64 -8114425130346640587}
!452 = !{i64 3573241012791516032}
!453 = !{i64 6117248896430114532}
!454 = !{i64 7497835115393955788}
!455 = !{i64 2832631407127306814}
!456 = !{i64 7077070301986270280}
!457 = !{i64 6476937503079526533}
!458 = !{i64 -6532429833960452330}
!459 = !{i64 -8944011964961764801}
!460 = !{i64 -6445883103901644176}
!461 = !{i64 1669988726900488455}
!462 = !{i64 7014981557723664926}
!463 = !{i64 6244821123098168303}
!464 = !{i64 5659697653897027325}
!465 = !{i64 502869261312355886}
!466 = !{i64 -7163031122851228909}
!467 = !{i64 -3126838782374109055}
!468 = !{i64 -2624081020897602054}
