; ModuleID = 'test/c/run/builtin-stdc.c'
source_filename = "test/c/run/builtin-stdc.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [5 x i8] c"-- 0\00", align 1
@.str.1 = private unnamed_addr constant [69 x i8] c"%-22s lz%u lo%u tz%u to%u fl0%u fl1%u ft0%u ft1%u c0%u c1%u s%d w%u\0A\00", align 1
@.str.2 = private unnamed_addr constant [14 x i8] c"unsigned char\00", align 1
@.str.3 = private unnamed_addr constant [110 x i8] c"  floor %llx.%llx.%llx ceil %llx.%llx.%llx rotl3 %llx.%llx.%llx rotr3 %llx.%llx.%llx rotl0 %llx rotlbig %llx\0A\00", align 1
@.str.4 = private unnamed_addr constant [15 x i8] c"unsigned short\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"unsigned int\00", align 1
@.str.6 = private unnamed_addr constant [19 x i8] c"unsigned long long\00", align 1
@.str.7 = private unnamed_addr constant [18 x i8] c"unsigned __int128\00", align 1
@.str.8 = private unnamed_addr constant [20 x i8] c"unsigned _BitInt(7)\00", align 1
@.str.9 = private unnamed_addr constant [21 x i8] c"unsigned _BitInt(65)\00", align 1
@.str.10 = private unnamed_addr constant [22 x i8] c"unsigned _BitInt(129)\00", align 1
@.str.11 = private unnamed_addr constant [22 x i8] c"unsigned _BitInt(256)\00", align 1
@.str.12 = private unnamed_addr constant [5 x i8] c"-- 1\00", align 1
@.str.13 = private unnamed_addr constant [12 x i8] c"-- all ones\00", align 1
@.str.14 = private unnamed_addr constant [8 x i8] c"-- 0x50\00", align 1
@.str.15 = private unnamed_addr constant [14 x i8] c"-- 5 (ceil 8)\00", align 1
@__const.main.t_ = private unnamed_addr constant [5 x i32] [i32 4, i32 1, i32 1, i32 1, i32 1], align 16
@.str.16 = private unnamed_addr constant [16 x i8] c"%d %d %d %d %d\0A\00", align 1
@__const.main.q_ = private unnamed_addr constant [3 x i32] [i32 128, i32 3, i32 65], align 4
@.str.17 = private unnamed_addr constant [10 x i8] c"%x %x %x\0A\00", align 1
@fails = internal global i32 0, align 4
@.str.18 = private unnamed_addr constant [14 x i8] c"leading_zeros\00", align 1
@.str.19 = private unnamed_addr constant [13 x i8] c"leading_ones\00", align 1
@.str.20 = private unnamed_addr constant [15 x i8] c"trailing_zeros\00", align 1
@.str.21 = private unnamed_addr constant [14 x i8] c"trailing_ones\00", align 1
@.str.22 = private unnamed_addr constant [19 x i8] c"first_leading_zero\00", align 1
@.str.23 = private unnamed_addr constant [18 x i8] c"first_leading_one\00", align 1
@.str.24 = private unnamed_addr constant [20 x i8] c"first_trailing_zero\00", align 1
@.str.25 = private unnamed_addr constant [19 x i8] c"first_trailing_one\00", align 1
@.str.26 = private unnamed_addr constant [12 x i8] c"count_zeros\00", align 1
@.str.27 = private unnamed_addr constant [11 x i8] c"count_ones\00", align 1
@.str.28 = private unnamed_addr constant [15 x i8] c"has_single_bit\00", align 1
@.str.29 = private unnamed_addr constant [10 x i8] c"bit_width\00", align 1
@.str.30 = private unnamed_addr constant [10 x i8] c"bit_floor\00", align 1
@.str.31 = private unnamed_addr constant [9 x i8] c"bit_ceil\00", align 1
@.str.32 = private unnamed_addr constant [14 x i8] c"rotate_left 3\00", align 1
@.str.33 = private unnamed_addr constant [15 x i8] c"rotate_right 3\00", align 1
@.str.34 = private unnamed_addr constant [14 x i8] c"rotate_left 0\00", align 1
@.str.35 = private unnamed_addr constant [17 x i8] c"rotate_left 1000\00", align 1
@stderr = external constant ptr, align 8
@.str.36 = private unnamed_addr constant [12 x i8] c"FAIL %s %s\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  %3 = alloca [12 x i32], align 16
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  %6 = alloca i8, align 1
  %7 = alloca i8, align 1
  %8 = alloca i8, align 1
  %9 = alloca i8, align 1
  %10 = alloca [72 x i8], align 8
  %11 = alloca [72 x i8], align 8
  %12 = alloca [72 x i8], align 8
  %13 = alloca [72 x i8], align 8
  %14 = alloca [72 x i8], align 8
  %15 = alloca [72 x i8], align 8
  %16 = alloca [72 x i8], align 8
  %17 = alloca i16, align 2
  %18 = alloca [12 x i32], align 16
  %19 = alloca i16, align 2
  %20 = alloca i16, align 2
  %21 = alloca i16, align 2
  %22 = alloca i16, align 2
  %23 = alloca i16, align 2
  %24 = alloca i16, align 2
  %25 = alloca [72 x i8], align 8
  %26 = alloca [72 x i8], align 8
  %27 = alloca [72 x i8], align 8
  %28 = alloca [72 x i8], align 8
  %29 = alloca [72 x i8], align 8
  %30 = alloca [72 x i8], align 8
  %31 = alloca [72 x i8], align 8
  %32 = alloca i32, align 4
  %33 = alloca [12 x i32], align 16
  %34 = alloca i32, align 4
  %35 = alloca i32, align 4
  %36 = alloca i32, align 4
  %37 = alloca i32, align 4
  %38 = alloca i32, align 4
  %39 = alloca i32, align 4
  %40 = alloca [72 x i8], align 8
  %41 = alloca [72 x i8], align 8
  %42 = alloca [72 x i8], align 8
  %43 = alloca [72 x i8], align 8
  %44 = alloca [72 x i8], align 8
  %45 = alloca [72 x i8], align 8
  %46 = alloca [72 x i8], align 8
  %47 = alloca i64, align 8
  %48 = alloca [12 x i32], align 16
  %49 = alloca i64, align 8
  %50 = alloca i64, align 8
  %51 = alloca i64, align 8
  %52 = alloca i64, align 8
  %53 = alloca i64, align 8
  %54 = alloca i64, align 8
  %55 = alloca [72 x i8], align 8
  %56 = alloca [72 x i8], align 8
  %57 = alloca [72 x i8], align 8
  %58 = alloca [72 x i8], align 8
  %59 = alloca [72 x i8], align 8
  %60 = alloca [72 x i8], align 8
  %61 = alloca [72 x i8], align 8
  %62 = alloca i128, align 16
  %63 = alloca [12 x i32], align 16
  %64 = alloca i128, align 16
  %65 = alloca i128, align 16
  %66 = alloca i128, align 16
  %67 = alloca i128, align 16
  %68 = alloca i128, align 16
  %69 = alloca i128, align 16
  %70 = alloca [72 x i8], align 8
  %71 = alloca [72 x i8], align 8
  %72 = alloca [72 x i8], align 8
  %73 = alloca [72 x i8], align 8
  %74 = alloca [72 x i8], align 8
  %75 = alloca [72 x i8], align 8
  %76 = alloca [72 x i8], align 8
  %77 = alloca i8, align 1
  %78 = alloca [12 x i32], align 16
  %79 = alloca i8, align 1
  %80 = alloca i8, align 1
  %81 = alloca i8, align 1
  %82 = alloca i8, align 1
  %83 = alloca i8, align 1
  %84 = alloca i8, align 1
  %85 = alloca [72 x i8], align 8
  %86 = alloca [72 x i8], align 8
  %87 = alloca [72 x i8], align 8
  %88 = alloca [72 x i8], align 8
  %89 = alloca [72 x i8], align 8
  %90 = alloca [72 x i8], align 8
  %91 = alloca [72 x i8], align 8
  %92 = alloca i128, align 8
  %93 = alloca [12 x i32], align 16
  %94 = alloca i128, align 8
  %95 = alloca i128, align 8
  %96 = alloca i128, align 8
  %97 = alloca i128, align 8
  %98 = alloca i128, align 8
  %99 = alloca i128, align 8
  %100 = alloca [72 x i8], align 8
  %101 = alloca [72 x i8], align 8
  %102 = alloca [72 x i8], align 8
  %103 = alloca [72 x i8], align 8
  %104 = alloca [72 x i8], align 8
  %105 = alloca [72 x i8], align 8
  %106 = alloca [72 x i8], align 8
  %107 = alloca [24 x i8], align 8
  %108 = alloca [12 x i32], align 16
  %109 = alloca [24 x i8], align 8
  %110 = alloca [24 x i8], align 8
  %111 = alloca [24 x i8], align 8
  %112 = alloca [24 x i8], align 8
  %113 = alloca [24 x i8], align 8
  %114 = alloca [24 x i8], align 8
  %115 = alloca [72 x i8], align 8
  %116 = alloca [72 x i8], align 8
  %117 = alloca [72 x i8], align 8
  %118 = alloca [72 x i8], align 8
  %119 = alloca [72 x i8], align 8
  %120 = alloca [72 x i8], align 8
  %121 = alloca [72 x i8], align 8
  %122 = alloca i256, align 8
  %123 = alloca [12 x i32], align 16
  %124 = alloca i256, align 8
  %125 = alloca i256, align 8
  %126 = alloca i256, align 8
  %127 = alloca i256, align 8
  %128 = alloca i256, align 8
  %129 = alloca i256, align 8
  %130 = alloca [72 x i8], align 8
  %131 = alloca [72 x i8], align 8
  %132 = alloca [72 x i8], align 8
  %133 = alloca [72 x i8], align 8
  %134 = alloca [72 x i8], align 8
  %135 = alloca [72 x i8], align 8
  %136 = alloca [72 x i8], align 8
  %137 = alloca i8, align 1
  %138 = alloca [12 x i32], align 16
  %139 = alloca i8, align 1
  %140 = alloca i8, align 1
  %141 = alloca i8, align 1
  %142 = alloca i8, align 1
  %143 = alloca i8, align 1
  %144 = alloca i8, align 1
  %145 = alloca [72 x i8], align 8
  %146 = alloca [72 x i8], align 8
  %147 = alloca [72 x i8], align 8
  %148 = alloca [72 x i8], align 8
  %149 = alloca [72 x i8], align 8
  %150 = alloca [72 x i8], align 8
  %151 = alloca [72 x i8], align 8
  %152 = alloca i16, align 2
  %153 = alloca [12 x i32], align 16
  %154 = alloca i16, align 2
  %155 = alloca i16, align 2
  %156 = alloca i16, align 2
  %157 = alloca i16, align 2
  %158 = alloca i16, align 2
  %159 = alloca i16, align 2
  %160 = alloca [72 x i8], align 8
  %161 = alloca [72 x i8], align 8
  %162 = alloca [72 x i8], align 8
  %163 = alloca [72 x i8], align 8
  %164 = alloca [72 x i8], align 8
  %165 = alloca [72 x i8], align 8
  %166 = alloca [72 x i8], align 8
  %167 = alloca i32, align 4
  %168 = alloca [12 x i32], align 16
  %169 = alloca i32, align 4
  %170 = alloca i32, align 4
  %171 = alloca i32, align 4
  %172 = alloca i32, align 4
  %173 = alloca i32, align 4
  %174 = alloca i32, align 4
  %175 = alloca [72 x i8], align 8
  %176 = alloca [72 x i8], align 8
  %177 = alloca [72 x i8], align 8
  %178 = alloca [72 x i8], align 8
  %179 = alloca [72 x i8], align 8
  %180 = alloca [72 x i8], align 8
  %181 = alloca [72 x i8], align 8
  %182 = alloca i64, align 8
  %183 = alloca [12 x i32], align 16
  %184 = alloca i64, align 8
  %185 = alloca i64, align 8
  %186 = alloca i64, align 8
  %187 = alloca i64, align 8
  %188 = alloca i64, align 8
  %189 = alloca i64, align 8
  %190 = alloca [72 x i8], align 8
  %191 = alloca [72 x i8], align 8
  %192 = alloca [72 x i8], align 8
  %193 = alloca [72 x i8], align 8
  %194 = alloca [72 x i8], align 8
  %195 = alloca [72 x i8], align 8
  %196 = alloca [72 x i8], align 8
  %197 = alloca i128, align 16
  %198 = alloca [12 x i32], align 16
  %199 = alloca i128, align 16
  %200 = alloca i128, align 16
  %201 = alloca i128, align 16
  %202 = alloca i128, align 16
  %203 = alloca i128, align 16
  %204 = alloca i128, align 16
  %205 = alloca [72 x i8], align 8
  %206 = alloca [72 x i8], align 8
  %207 = alloca [72 x i8], align 8
  %208 = alloca [72 x i8], align 8
  %209 = alloca [72 x i8], align 8
  %210 = alloca [72 x i8], align 8
  %211 = alloca [72 x i8], align 8
  %212 = alloca i8, align 1
  %213 = alloca [12 x i32], align 16
  %214 = alloca i8, align 1
  %215 = alloca i8, align 1
  %216 = alloca i8, align 1
  %217 = alloca i8, align 1
  %218 = alloca i8, align 1
  %219 = alloca i8, align 1
  %220 = alloca [72 x i8], align 8
  %221 = alloca [72 x i8], align 8
  %222 = alloca [72 x i8], align 8
  %223 = alloca [72 x i8], align 8
  %224 = alloca [72 x i8], align 8
  %225 = alloca [72 x i8], align 8
  %226 = alloca [72 x i8], align 8
  %227 = alloca i128, align 8
  %228 = alloca [12 x i32], align 16
  %229 = alloca i128, align 8
  %230 = alloca i128, align 8
  %231 = alloca i128, align 8
  %232 = alloca i128, align 8
  %233 = alloca i128, align 8
  %234 = alloca i128, align 8
  %235 = alloca [72 x i8], align 8
  %236 = alloca [72 x i8], align 8
  %237 = alloca [72 x i8], align 8
  %238 = alloca [72 x i8], align 8
  %239 = alloca [72 x i8], align 8
  %240 = alloca [72 x i8], align 8
  %241 = alloca [72 x i8], align 8
  %242 = alloca [24 x i8], align 8
  %243 = alloca [12 x i32], align 16
  %244 = alloca [24 x i8], align 8
  %245 = alloca [24 x i8], align 8
  %246 = alloca [24 x i8], align 8
  %247 = alloca [24 x i8], align 8
  %248 = alloca [24 x i8], align 8
  %249 = alloca [24 x i8], align 8
  %250 = alloca [72 x i8], align 8
  %251 = alloca [72 x i8], align 8
  %252 = alloca [72 x i8], align 8
  %253 = alloca [72 x i8], align 8
  %254 = alloca [72 x i8], align 8
  %255 = alloca [72 x i8], align 8
  %256 = alloca [72 x i8], align 8
  %257 = alloca i256, align 8
  %258 = alloca [12 x i32], align 16
  %259 = alloca i256, align 8
  %260 = alloca i256, align 8
  %261 = alloca i256, align 8
  %262 = alloca i256, align 8
  %263 = alloca i256, align 8
  %264 = alloca i256, align 8
  %265 = alloca [72 x i8], align 8
  %266 = alloca [72 x i8], align 8
  %267 = alloca [72 x i8], align 8
  %268 = alloca [72 x i8], align 8
  %269 = alloca [72 x i8], align 8
  %270 = alloca [72 x i8], align 8
  %271 = alloca [72 x i8], align 8
  %272 = alloca i8, align 1
  %273 = alloca [12 x i32], align 16
  %274 = alloca i8, align 1
  %275 = alloca i8, align 1
  %276 = alloca i8, align 1
  %277 = alloca i8, align 1
  %278 = alloca i8, align 1
  %279 = alloca i8, align 1
  %280 = alloca [72 x i8], align 8
  %281 = alloca [72 x i8], align 8
  %282 = alloca [72 x i8], align 8
  %283 = alloca [72 x i8], align 8
  %284 = alloca [72 x i8], align 8
  %285 = alloca [72 x i8], align 8
  %286 = alloca [72 x i8], align 8
  %287 = alloca i16, align 2
  %288 = alloca [12 x i32], align 16
  %289 = alloca i16, align 2
  %290 = alloca i16, align 2
  %291 = alloca i16, align 2
  %292 = alloca i16, align 2
  %293 = alloca i16, align 2
  %294 = alloca i16, align 2
  %295 = alloca [72 x i8], align 8
  %296 = alloca [72 x i8], align 8
  %297 = alloca [72 x i8], align 8
  %298 = alloca [72 x i8], align 8
  %299 = alloca [72 x i8], align 8
  %300 = alloca [72 x i8], align 8
  %301 = alloca [72 x i8], align 8
  %302 = alloca i32, align 4
  %303 = alloca [12 x i32], align 16
  %304 = alloca i32, align 4
  %305 = alloca i32, align 4
  %306 = alloca i32, align 4
  %307 = alloca i32, align 4
  %308 = alloca i32, align 4
  %309 = alloca i32, align 4
  %310 = alloca [72 x i8], align 8
  %311 = alloca [72 x i8], align 8
  %312 = alloca [72 x i8], align 8
  %313 = alloca [72 x i8], align 8
  %314 = alloca [72 x i8], align 8
  %315 = alloca [72 x i8], align 8
  %316 = alloca [72 x i8], align 8
  %317 = alloca i64, align 8
  %318 = alloca [12 x i32], align 16
  %319 = alloca i64, align 8
  %320 = alloca i64, align 8
  %321 = alloca i64, align 8
  %322 = alloca i64, align 8
  %323 = alloca i64, align 8
  %324 = alloca i64, align 8
  %325 = alloca [72 x i8], align 8
  %326 = alloca [72 x i8], align 8
  %327 = alloca [72 x i8], align 8
  %328 = alloca [72 x i8], align 8
  %329 = alloca [72 x i8], align 8
  %330 = alloca [72 x i8], align 8
  %331 = alloca [72 x i8], align 8
  %332 = alloca i128, align 16
  %333 = alloca [12 x i32], align 16
  %334 = alloca i128, align 16
  %335 = alloca i128, align 16
  %336 = alloca i128, align 16
  %337 = alloca i128, align 16
  %338 = alloca i128, align 16
  %339 = alloca i128, align 16
  %340 = alloca [72 x i8], align 8
  %341 = alloca [72 x i8], align 8
  %342 = alloca [72 x i8], align 8
  %343 = alloca [72 x i8], align 8
  %344 = alloca [72 x i8], align 8
  %345 = alloca [72 x i8], align 8
  %346 = alloca [72 x i8], align 8
  %347 = alloca i8, align 1
  %348 = alloca [12 x i32], align 16
  %349 = alloca i8, align 1
  %350 = alloca i8, align 1
  %351 = alloca i8, align 1
  %352 = alloca i8, align 1
  %353 = alloca i8, align 1
  %354 = alloca i8, align 1
  %355 = alloca [72 x i8], align 8
  %356 = alloca [72 x i8], align 8
  %357 = alloca [72 x i8], align 8
  %358 = alloca [72 x i8], align 8
  %359 = alloca [72 x i8], align 8
  %360 = alloca [72 x i8], align 8
  %361 = alloca [72 x i8], align 8
  %362 = alloca i128, align 8
  %363 = alloca [12 x i32], align 16
  %364 = alloca i128, align 8
  %365 = alloca i128, align 8
  %366 = alloca i128, align 8
  %367 = alloca i128, align 8
  %368 = alloca i128, align 8
  %369 = alloca i128, align 8
  %370 = alloca [72 x i8], align 8
  %371 = alloca [72 x i8], align 8
  %372 = alloca [72 x i8], align 8
  %373 = alloca [72 x i8], align 8
  %374 = alloca [72 x i8], align 8
  %375 = alloca [72 x i8], align 8
  %376 = alloca [72 x i8], align 8
  %377 = alloca [24 x i8], align 8
  %378 = alloca [12 x i32], align 16
  %379 = alloca [24 x i8], align 8
  %380 = alloca [24 x i8], align 8
  %381 = alloca [24 x i8], align 8
  %382 = alloca [24 x i8], align 8
  %383 = alloca [24 x i8], align 8
  %384 = alloca [24 x i8], align 8
  %385 = alloca [72 x i8], align 8
  %386 = alloca [72 x i8], align 8
  %387 = alloca [72 x i8], align 8
  %388 = alloca [72 x i8], align 8
  %389 = alloca [72 x i8], align 8
  %390 = alloca [72 x i8], align 8
  %391 = alloca [72 x i8], align 8
  %392 = alloca i256, align 8
  %393 = alloca [12 x i32], align 16
  %394 = alloca i256, align 8
  %395 = alloca i256, align 8
  %396 = alloca i256, align 8
  %397 = alloca i256, align 8
  %398 = alloca i256, align 8
  %399 = alloca i256, align 8
  %400 = alloca [72 x i8], align 8
  %401 = alloca [72 x i8], align 8
  %402 = alloca [72 x i8], align 8
  %403 = alloca [72 x i8], align 8
  %404 = alloca [72 x i8], align 8
  %405 = alloca [72 x i8], align 8
  %406 = alloca [72 x i8], align 8
  %407 = alloca i8, align 1
  %408 = alloca [12 x i32], align 16
  %409 = alloca i8, align 1
  %410 = alloca i8, align 1
  %411 = alloca i8, align 1
  %412 = alloca i8, align 1
  %413 = alloca i8, align 1
  %414 = alloca i8, align 1
  %415 = alloca [72 x i8], align 8
  %416 = alloca [72 x i8], align 8
  %417 = alloca [72 x i8], align 8
  %418 = alloca [72 x i8], align 8
  %419 = alloca [72 x i8], align 8
  %420 = alloca [72 x i8], align 8
  %421 = alloca [72 x i8], align 8
  %422 = alloca i16, align 2
  %423 = alloca [12 x i32], align 16
  %424 = alloca i16, align 2
  %425 = alloca i16, align 2
  %426 = alloca i16, align 2
  %427 = alloca i16, align 2
  %428 = alloca i16, align 2
  %429 = alloca i16, align 2
  %430 = alloca [72 x i8], align 8
  %431 = alloca [72 x i8], align 8
  %432 = alloca [72 x i8], align 8
  %433 = alloca [72 x i8], align 8
  %434 = alloca [72 x i8], align 8
  %435 = alloca [72 x i8], align 8
  %436 = alloca [72 x i8], align 8
  %437 = alloca i32, align 4
  %438 = alloca [12 x i32], align 16
  %439 = alloca i32, align 4
  %440 = alloca i32, align 4
  %441 = alloca i32, align 4
  %442 = alloca i32, align 4
  %443 = alloca i32, align 4
  %444 = alloca i32, align 4
  %445 = alloca [72 x i8], align 8
  %446 = alloca [72 x i8], align 8
  %447 = alloca [72 x i8], align 8
  %448 = alloca [72 x i8], align 8
  %449 = alloca [72 x i8], align 8
  %450 = alloca [72 x i8], align 8
  %451 = alloca [72 x i8], align 8
  %452 = alloca i64, align 8
  %453 = alloca [12 x i32], align 16
  %454 = alloca i64, align 8
  %455 = alloca i64, align 8
  %456 = alloca i64, align 8
  %457 = alloca i64, align 8
  %458 = alloca i64, align 8
  %459 = alloca i64, align 8
  %460 = alloca [72 x i8], align 8
  %461 = alloca [72 x i8], align 8
  %462 = alloca [72 x i8], align 8
  %463 = alloca [72 x i8], align 8
  %464 = alloca [72 x i8], align 8
  %465 = alloca [72 x i8], align 8
  %466 = alloca [72 x i8], align 8
  %467 = alloca i128, align 16
  %468 = alloca [12 x i32], align 16
  %469 = alloca i128, align 16
  %470 = alloca i128, align 16
  %471 = alloca i128, align 16
  %472 = alloca i128, align 16
  %473 = alloca i128, align 16
  %474 = alloca i128, align 16
  %475 = alloca [72 x i8], align 8
  %476 = alloca [72 x i8], align 8
  %477 = alloca [72 x i8], align 8
  %478 = alloca [72 x i8], align 8
  %479 = alloca [72 x i8], align 8
  %480 = alloca [72 x i8], align 8
  %481 = alloca [72 x i8], align 8
  %482 = alloca i8, align 1
  %483 = alloca [12 x i32], align 16
  %484 = alloca i8, align 1
  %485 = alloca i8, align 1
  %486 = alloca i8, align 1
  %487 = alloca i8, align 1
  %488 = alloca i8, align 1
  %489 = alloca i8, align 1
  %490 = alloca [72 x i8], align 8
  %491 = alloca [72 x i8], align 8
  %492 = alloca [72 x i8], align 8
  %493 = alloca [72 x i8], align 8
  %494 = alloca [72 x i8], align 8
  %495 = alloca [72 x i8], align 8
  %496 = alloca [72 x i8], align 8
  %497 = alloca i128, align 8
  %498 = alloca [12 x i32], align 16
  %499 = alloca i128, align 8
  %500 = alloca i128, align 8
  %501 = alloca i128, align 8
  %502 = alloca i128, align 8
  %503 = alloca i128, align 8
  %504 = alloca i128, align 8
  %505 = alloca [72 x i8], align 8
  %506 = alloca [72 x i8], align 8
  %507 = alloca [72 x i8], align 8
  %508 = alloca [72 x i8], align 8
  %509 = alloca [72 x i8], align 8
  %510 = alloca [72 x i8], align 8
  %511 = alloca [72 x i8], align 8
  %512 = alloca [24 x i8], align 8
  %513 = alloca [12 x i32], align 16
  %514 = alloca [24 x i8], align 8
  %515 = alloca [24 x i8], align 8
  %516 = alloca [24 x i8], align 8
  %517 = alloca [24 x i8], align 8
  %518 = alloca [24 x i8], align 8
  %519 = alloca [24 x i8], align 8
  %520 = alloca [72 x i8], align 8
  %521 = alloca [72 x i8], align 8
  %522 = alloca [72 x i8], align 8
  %523 = alloca [72 x i8], align 8
  %524 = alloca [72 x i8], align 8
  %525 = alloca [72 x i8], align 8
  %526 = alloca [72 x i8], align 8
  %527 = alloca i256, align 8
  %528 = alloca [12 x i32], align 16
  %529 = alloca i256, align 8
  %530 = alloca i256, align 8
  %531 = alloca i256, align 8
  %532 = alloca i256, align 8
  %533 = alloca i256, align 8
  %534 = alloca i256, align 8
  %535 = alloca [72 x i8], align 8
  %536 = alloca [72 x i8], align 8
  %537 = alloca [72 x i8], align 8
  %538 = alloca [72 x i8], align 8
  %539 = alloca [72 x i8], align 8
  %540 = alloca [72 x i8], align 8
  %541 = alloca [72 x i8], align 8
  %542 = alloca i8, align 1
  %543 = alloca [12 x i32], align 16
  %544 = alloca i8, align 1
  %545 = alloca i8, align 1
  %546 = alloca i8, align 1
  %547 = alloca i8, align 1
  %548 = alloca i8, align 1
  %549 = alloca i8, align 1
  %550 = alloca [72 x i8], align 8
  %551 = alloca [72 x i8], align 8
  %552 = alloca [72 x i8], align 8
  %553 = alloca [72 x i8], align 8
  %554 = alloca [72 x i8], align 8
  %555 = alloca [72 x i8], align 8
  %556 = alloca [72 x i8], align 8
  %557 = alloca i16, align 2
  %558 = alloca [12 x i32], align 16
  %559 = alloca i16, align 2
  %560 = alloca i16, align 2
  %561 = alloca i16, align 2
  %562 = alloca i16, align 2
  %563 = alloca i16, align 2
  %564 = alloca i16, align 2
  %565 = alloca [72 x i8], align 8
  %566 = alloca [72 x i8], align 8
  %567 = alloca [72 x i8], align 8
  %568 = alloca [72 x i8], align 8
  %569 = alloca [72 x i8], align 8
  %570 = alloca [72 x i8], align 8
  %571 = alloca [72 x i8], align 8
  %572 = alloca i32, align 4
  %573 = alloca [12 x i32], align 16
  %574 = alloca i32, align 4
  %575 = alloca i32, align 4
  %576 = alloca i32, align 4
  %577 = alloca i32, align 4
  %578 = alloca i32, align 4
  %579 = alloca i32, align 4
  %580 = alloca [72 x i8], align 8
  %581 = alloca [72 x i8], align 8
  %582 = alloca [72 x i8], align 8
  %583 = alloca [72 x i8], align 8
  %584 = alloca [72 x i8], align 8
  %585 = alloca [72 x i8], align 8
  %586 = alloca [72 x i8], align 8
  %587 = alloca i64, align 8
  %588 = alloca [12 x i32], align 16
  %589 = alloca i64, align 8
  %590 = alloca i64, align 8
  %591 = alloca i64, align 8
  %592 = alloca i64, align 8
  %593 = alloca i64, align 8
  %594 = alloca i64, align 8
  %595 = alloca [72 x i8], align 8
  %596 = alloca [72 x i8], align 8
  %597 = alloca [72 x i8], align 8
  %598 = alloca [72 x i8], align 8
  %599 = alloca [72 x i8], align 8
  %600 = alloca [72 x i8], align 8
  %601 = alloca [72 x i8], align 8
  %602 = alloca i128, align 16
  %603 = alloca [12 x i32], align 16
  %604 = alloca i128, align 16
  %605 = alloca i128, align 16
  %606 = alloca i128, align 16
  %607 = alloca i128, align 16
  %608 = alloca i128, align 16
  %609 = alloca i128, align 16
  %610 = alloca [72 x i8], align 8
  %611 = alloca [72 x i8], align 8
  %612 = alloca [72 x i8], align 8
  %613 = alloca [72 x i8], align 8
  %614 = alloca [72 x i8], align 8
  %615 = alloca [72 x i8], align 8
  %616 = alloca [72 x i8], align 8
  %617 = alloca i8, align 1
  %618 = alloca [12 x i32], align 16
  %619 = alloca i8, align 1
  %620 = alloca i8, align 1
  %621 = alloca i8, align 1
  %622 = alloca i8, align 1
  %623 = alloca i8, align 1
  %624 = alloca i8, align 1
  %625 = alloca [72 x i8], align 8
  %626 = alloca [72 x i8], align 8
  %627 = alloca [72 x i8], align 8
  %628 = alloca [72 x i8], align 8
  %629 = alloca [72 x i8], align 8
  %630 = alloca [72 x i8], align 8
  %631 = alloca [72 x i8], align 8
  %632 = alloca i128, align 8
  %633 = alloca [12 x i32], align 16
  %634 = alloca i128, align 8
  %635 = alloca i128, align 8
  %636 = alloca i128, align 8
  %637 = alloca i128, align 8
  %638 = alloca i128, align 8
  %639 = alloca i128, align 8
  %640 = alloca [72 x i8], align 8
  %641 = alloca [72 x i8], align 8
  %642 = alloca [72 x i8], align 8
  %643 = alloca [72 x i8], align 8
  %644 = alloca [72 x i8], align 8
  %645 = alloca [72 x i8], align 8
  %646 = alloca [72 x i8], align 8
  %647 = alloca [24 x i8], align 8
  %648 = alloca [12 x i32], align 16
  %649 = alloca [24 x i8], align 8
  %650 = alloca [24 x i8], align 8
  %651 = alloca [24 x i8], align 8
  %652 = alloca [24 x i8], align 8
  %653 = alloca [24 x i8], align 8
  %654 = alloca [24 x i8], align 8
  %655 = alloca [72 x i8], align 8
  %656 = alloca [72 x i8], align 8
  %657 = alloca [72 x i8], align 8
  %658 = alloca [72 x i8], align 8
  %659 = alloca [72 x i8], align 8
  %660 = alloca [72 x i8], align 8
  %661 = alloca [72 x i8], align 8
  %662 = alloca i256, align 8
  %663 = alloca [12 x i32], align 16
  %664 = alloca i256, align 8
  %665 = alloca i256, align 8
  %666 = alloca i256, align 8
  %667 = alloca i256, align 8
  %668 = alloca i256, align 8
  %669 = alloca i256, align 8
  %670 = alloca [72 x i8], align 8
  %671 = alloca [72 x i8], align 8
  %672 = alloca [72 x i8], align 8
  %673 = alloca [72 x i8], align 8
  %674 = alloca [72 x i8], align 8
  %675 = alloca [72 x i8], align 8
  %676 = alloca [72 x i8], align 8
  %677 = alloca [24 x i8], align 8
  %678 = alloca [24 x i8], align 8
  %679 = alloca [12 x i32], align 16
  %680 = alloca [24 x i8], align 8
  %681 = alloca [24 x i8], align 8
  %682 = alloca [24 x i8], align 8
  %683 = alloca [24 x i8], align 8
  %684 = alloca [24 x i8], align 8
  %685 = alloca [24 x i8], align 8
  %686 = alloca [72 x i8], align 8
  %687 = alloca [72 x i8], align 8
  %688 = alloca [72 x i8], align 8
  %689 = alloca [72 x i8], align 8
  %690 = alloca [72 x i8], align 8
  %691 = alloca [72 x i8], align 8
  %692 = alloca [72 x i8], align 8
  %693 = alloca [24 x i8], align 8
  %694 = alloca [12 x i32], align 16
  %695 = alloca [24 x i8], align 8
  %696 = alloca [24 x i8], align 8
  %697 = alloca [24 x i8], align 8
  %698 = alloca [24 x i8], align 8
  %699 = alloca [24 x i8], align 8
  %700 = alloca [24 x i8], align 8
  %701 = alloca [72 x i8], align 8
  %702 = alloca [72 x i8], align 8
  %703 = alloca [72 x i8], align 8
  %704 = alloca [72 x i8], align 8
  %705 = alloca [72 x i8], align 8
  %706 = alloca [72 x i8], align 8
  %707 = alloca [72 x i8], align 8
  %708 = alloca i8, align 1
  %709 = alloca i8, align 1
  %710 = alloca [12 x i32], align 16
  %711 = alloca i8, align 1
  %712 = alloca i8, align 1
  %713 = alloca i8, align 1
  %714 = alloca i8, align 1
  %715 = alloca i8, align 1
  %716 = alloca i8, align 1
  %717 = alloca [72 x i8], align 8
  %718 = alloca [72 x i8], align 8
  %719 = alloca [72 x i8], align 8
  %720 = alloca [72 x i8], align 8
  %721 = alloca [72 x i8], align 8
  %722 = alloca [72 x i8], align 8
  %723 = alloca [72 x i8], align 8
  %724 = alloca [5 x i32], align 16
  %725 = alloca [3 x i32], align 4
  store i32 0, ptr %1, align 4
  %726 = call i32 @puts(ptr noundef @.str)
  br label %727

727:                                              ; preds = %0
  store i8 0, ptr %2, align 1
  %728 = load i8, ptr %2, align 1
  %729 = call i8 @llvm.ctlz.i8(i8 %728, i1 false)
  %730 = zext i8 %729 to i32
  store i32 %730, ptr %3, align 4
  %731 = getelementptr inbounds i32, ptr %3, i64 1
  %732 = load i8, ptr %2, align 1
  %733 = xor i8 %732, -1
  %734 = call i8 @llvm.ctlz.i8(i8 %733, i1 false)
  %735 = zext i8 %734 to i32
  store i32 %735, ptr %731, align 4
  %736 = getelementptr inbounds i32, ptr %3, i64 2
  %737 = load i8, ptr %2, align 1
  %738 = call i8 @llvm.cttz.i8(i8 %737, i1 false)
  %739 = zext i8 %738 to i32
  store i32 %739, ptr %736, align 4
  %740 = getelementptr inbounds i32, ptr %3, i64 3
  %741 = load i8, ptr %2, align 1
  %742 = xor i8 %741, -1
  %743 = call i8 @llvm.cttz.i8(i8 %742, i1 false)
  %744 = zext i8 %743 to i32
  store i32 %744, ptr %740, align 4
  %745 = getelementptr inbounds i32, ptr %3, i64 4
  %746 = load i8, ptr %2, align 1
  %747 = xor i8 %746, -1
  %748 = call i8 @llvm.ctlz.i8(i8 %747, i1 false)
  %749 = add i8 %748, 1
  %750 = icmp eq i8 %747, 0
  %751 = select i1 %750, i8 0, i8 %749
  %752 = zext i8 %751 to i32
  store i32 %752, ptr %745, align 4
  %753 = getelementptr inbounds i32, ptr %3, i64 5
  %754 = load i8, ptr %2, align 1
  %755 = call i8 @llvm.ctlz.i8(i8 %754, i1 false)
  %756 = add i8 %755, 1
  %757 = icmp eq i8 %754, 0
  %758 = select i1 %757, i8 0, i8 %756
  %759 = zext i8 %758 to i32
  store i32 %759, ptr %753, align 4
  %760 = getelementptr inbounds i32, ptr %3, i64 6
  %761 = load i8, ptr %2, align 1
  %762 = xor i8 %761, -1
  %763 = call i8 @llvm.cttz.i8(i8 %762, i1 false)
  %764 = add i8 %763, 1
  %765 = icmp eq i8 %762, 0
  %766 = select i1 %765, i8 0, i8 %764
  %767 = zext i8 %766 to i32
  store i32 %767, ptr %760, align 4
  %768 = getelementptr inbounds i32, ptr %3, i64 7
  %769 = load i8, ptr %2, align 1
  %770 = call i8 @llvm.cttz.i8(i8 %769, i1 false)
  %771 = add i8 %770, 1
  %772 = icmp eq i8 %769, 0
  %773 = select i1 %772, i8 0, i8 %771
  %774 = zext i8 %773 to i32
  store i32 %774, ptr %768, align 4
  %775 = getelementptr inbounds i32, ptr %3, i64 8
  %776 = load i8, ptr %2, align 1
  %777 = call i8 @llvm.ctpop.i8(i8 %776)
  %778 = sub i8 8, %777
  %779 = zext i8 %778 to i32
  store i32 %779, ptr %775, align 4
  %780 = getelementptr inbounds i32, ptr %3, i64 9
  %781 = load i8, ptr %2, align 1
  %782 = call i8 @llvm.ctpop.i8(i8 %781)
  %783 = zext i8 %782 to i32
  store i32 %783, ptr %780, align 4
  %784 = getelementptr inbounds i32, ptr %3, i64 10
  %785 = load i8, ptr %2, align 1
  %786 = call i8 @llvm.ctpop.i8(i8 %785)
  %787 = icmp eq i8 %786, 1
  %788 = zext i1 %787 to i32
  store i32 %788, ptr %784, align 4
  %789 = getelementptr inbounds i32, ptr %3, i64 11
  %790 = load i8, ptr %2, align 1
  %791 = call i8 @llvm.ctlz.i8(i8 %790, i1 false)
  %792 = sub i8 8, %791
  %793 = zext i8 %792 to i32
  store i32 %793, ptr %789, align 4
  %794 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 0
  %795 = load i32, ptr %794, align 16
  %796 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 1
  %797 = load i32, ptr %796, align 4
  %798 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 2
  %799 = load i32, ptr %798, align 8
  %800 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 3
  %801 = load i32, ptr %800, align 4
  %802 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 4
  %803 = load i32, ptr %802, align 16
  %804 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 5
  %805 = load i32, ptr %804, align 4
  %806 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 6
  %807 = load i32, ptr %806, align 8
  %808 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 7
  %809 = load i32, ptr %808, align 4
  %810 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 8
  %811 = load i32, ptr %810, align 16
  %812 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 9
  %813 = load i32, ptr %812, align 4
  %814 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 10
  %815 = load i32, ptr %814, align 8
  %816 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 11
  %817 = load i32, ptr %816, align 4
  %818 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %795, i32 noundef %797, i32 noundef %799, i32 noundef %801, i32 noundef %803, i32 noundef %805, i32 noundef %807, i32 noundef %809, i32 noundef %811, i32 noundef %813, i32 noundef %815, i32 noundef %817)
  %819 = load i8, ptr %2, align 1
  %820 = call i8 @llvm.ctlz.i8(i8 %819, i1 true)
  %821 = sub i8 7, %820
  %822 = shl i8 1, %821
  %823 = icmp eq i8 %819, 0
  %824 = select i1 %823, i8 0, i8 %822
  store i8 %824, ptr %4, align 1
  %825 = load i8, ptr %2, align 1
  %826 = icmp ule i8 %825, 1
  br i1 %826, label %832, label %827

827:                                              ; preds = %727
  %828 = sub i8 %825, 1
  %829 = call i8 @llvm.ctlz.i8(i8 %828, i1 false)
  %830 = sub i8 7, %829
  %831 = shl i8 2, %830
  br label %832

832:                                              ; preds = %827, %727
  %833 = phi i8 [ 1, %727 ], [ %831, %827 ]
  store i8 %833, ptr %5, align 1
  %834 = load i8, ptr %2, align 1
  %835 = call i8 @llvm.fshl.i8(i8 %834, i8 %834, i8 3)
  store i8 %835, ptr %6, align 1
  %836 = load i8, ptr %2, align 1
  %837 = call i8 @llvm.fshr.i8(i8 %836, i8 %836, i8 3)
  store i8 %837, ptr %7, align 1
  %838 = load i8, ptr %2, align 1
  %839 = call i8 @llvm.fshl.i8(i8 %838, i8 %838, i8 0)
  store i8 %839, ptr %8, align 1
  %840 = load i8, ptr %2, align 1
  %841 = call i8 @llvm.fshl.i8(i8 %840, i8 %840, i8 0)
  store i8 %841, ptr %9, align 1
  %842 = load i8, ptr %4, align 1
  %843 = zext i8 %842 to i256
  %844 = lshr i256 %843, 128
  %845 = trunc i256 %844 to i64
  %846 = load i8, ptr %4, align 1
  %847 = zext i8 %846 to i256
  %848 = lshr i256 %847, 64
  %849 = trunc i256 %848 to i64
  %850 = load i8, ptr %4, align 1
  %851 = zext i8 %850 to i64
  %852 = load i8, ptr %5, align 1
  %853 = zext i8 %852 to i256
  %854 = lshr i256 %853, 128
  %855 = trunc i256 %854 to i64
  %856 = load i8, ptr %5, align 1
  %857 = zext i8 %856 to i256
  %858 = lshr i256 %857, 64
  %859 = trunc i256 %858 to i64
  %860 = load i8, ptr %5, align 1
  %861 = zext i8 %860 to i64
  %862 = load i8, ptr %6, align 1
  %863 = zext i8 %862 to i256
  %864 = lshr i256 %863, 128
  %865 = trunc i256 %864 to i64
  %866 = load i8, ptr %6, align 1
  %867 = zext i8 %866 to i256
  %868 = lshr i256 %867, 64
  %869 = trunc i256 %868 to i64
  %870 = load i8, ptr %6, align 1
  %871 = zext i8 %870 to i64
  %872 = load i8, ptr %7, align 1
  %873 = zext i8 %872 to i256
  %874 = lshr i256 %873, 128
  %875 = trunc i256 %874 to i64
  %876 = load i8, ptr %7, align 1
  %877 = zext i8 %876 to i256
  %878 = lshr i256 %877, 64
  %879 = trunc i256 %878 to i64
  %880 = load i8, ptr %7, align 1
  %881 = zext i8 %880 to i64
  %882 = load i8, ptr %8, align 1
  %883 = zext i8 %882 to i64
  %884 = load i8, ptr %9, align 1
  %885 = zext i8 %884 to i64
  %886 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %845, i64 noundef %849, i64 noundef %851, i64 noundef %855, i64 noundef %859, i64 noundef %861, i64 noundef %865, i64 noundef %869, i64 noundef %871, i64 noundef %875, i64 noundef %879, i64 noundef %881, i64 noundef %883, i64 noundef %885)
  %887 = load i8, ptr %2, align 1
  %888 = zext i8 %887 to i575
  %889 = getelementptr inbounds [12 x i32], ptr %3, i64 0, i64 0
  %890 = load i8, ptr %4, align 1
  %891 = zext i8 %890 to i575
  %892 = load i8, ptr %5, align 1
  %893 = zext i8 %892 to i575
  %894 = load i8, ptr %6, align 1
  %895 = zext i8 %894 to i575
  %896 = load i8, ptr %7, align 1
  %897 = zext i8 %896 to i575
  %898 = load i8, ptr %8, align 1
  %899 = zext i8 %898 to i575
  %900 = load i8, ptr %9, align 1
  %901 = zext i8 %900 to i575
  %902 = zext i575 %888 to i576
  store i576 %902, ptr %10, align 8
  %903 = zext i575 %891 to i576
  store i576 %903, ptr %11, align 8
  %904 = zext i575 %893 to i576
  store i576 %904, ptr %12, align 8
  %905 = zext i575 %895 to i576
  store i576 %905, ptr %13, align 8
  %906 = zext i575 %897 to i576
  store i576 %906, ptr %14, align 8
  %907 = zext i575 %899 to i576
  store i576 %907, ptr %15, align 8
  %908 = zext i575 %901 to i576
  store i576 %908, ptr %16, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %10, ptr noundef %889, ptr noundef byval([72 x i8]) align 8 %11, ptr noundef byval([72 x i8]) align 8 %12, ptr noundef byval([72 x i8]) align 8 %13, ptr noundef byval([72 x i8]) align 8 %14, ptr noundef byval([72 x i8]) align 8 %15, ptr noundef byval([72 x i8]) align 8 %16)
  br label %909

909:                                              ; preds = %832
  br label %910

910:                                              ; preds = %909
  store i16 0, ptr %17, align 2
  %911 = load i16, ptr %17, align 2
  %912 = call i16 @llvm.ctlz.i16(i16 %911, i1 false)
  %913 = zext i16 %912 to i32
  store i32 %913, ptr %18, align 4
  %914 = getelementptr inbounds i32, ptr %18, i64 1
  %915 = load i16, ptr %17, align 2
  %916 = xor i16 %915, -1
  %917 = call i16 @llvm.ctlz.i16(i16 %916, i1 false)
  %918 = zext i16 %917 to i32
  store i32 %918, ptr %914, align 4
  %919 = getelementptr inbounds i32, ptr %18, i64 2
  %920 = load i16, ptr %17, align 2
  %921 = call i16 @llvm.cttz.i16(i16 %920, i1 false)
  %922 = zext i16 %921 to i32
  store i32 %922, ptr %919, align 4
  %923 = getelementptr inbounds i32, ptr %18, i64 3
  %924 = load i16, ptr %17, align 2
  %925 = xor i16 %924, -1
  %926 = call i16 @llvm.cttz.i16(i16 %925, i1 false)
  %927 = zext i16 %926 to i32
  store i32 %927, ptr %923, align 4
  %928 = getelementptr inbounds i32, ptr %18, i64 4
  %929 = load i16, ptr %17, align 2
  %930 = xor i16 %929, -1
  %931 = call i16 @llvm.ctlz.i16(i16 %930, i1 false)
  %932 = add i16 %931, 1
  %933 = icmp eq i16 %930, 0
  %934 = select i1 %933, i16 0, i16 %932
  %935 = zext i16 %934 to i32
  store i32 %935, ptr %928, align 4
  %936 = getelementptr inbounds i32, ptr %18, i64 5
  %937 = load i16, ptr %17, align 2
  %938 = call i16 @llvm.ctlz.i16(i16 %937, i1 false)
  %939 = add i16 %938, 1
  %940 = icmp eq i16 %937, 0
  %941 = select i1 %940, i16 0, i16 %939
  %942 = zext i16 %941 to i32
  store i32 %942, ptr %936, align 4
  %943 = getelementptr inbounds i32, ptr %18, i64 6
  %944 = load i16, ptr %17, align 2
  %945 = xor i16 %944, -1
  %946 = call i16 @llvm.cttz.i16(i16 %945, i1 false)
  %947 = add i16 %946, 1
  %948 = icmp eq i16 %945, 0
  %949 = select i1 %948, i16 0, i16 %947
  %950 = zext i16 %949 to i32
  store i32 %950, ptr %943, align 4
  %951 = getelementptr inbounds i32, ptr %18, i64 7
  %952 = load i16, ptr %17, align 2
  %953 = call i16 @llvm.cttz.i16(i16 %952, i1 false)
  %954 = add i16 %953, 1
  %955 = icmp eq i16 %952, 0
  %956 = select i1 %955, i16 0, i16 %954
  %957 = zext i16 %956 to i32
  store i32 %957, ptr %951, align 4
  %958 = getelementptr inbounds i32, ptr %18, i64 8
  %959 = load i16, ptr %17, align 2
  %960 = call i16 @llvm.ctpop.i16(i16 %959)
  %961 = sub i16 16, %960
  %962 = zext i16 %961 to i32
  store i32 %962, ptr %958, align 4
  %963 = getelementptr inbounds i32, ptr %18, i64 9
  %964 = load i16, ptr %17, align 2
  %965 = call i16 @llvm.ctpop.i16(i16 %964)
  %966 = zext i16 %965 to i32
  store i32 %966, ptr %963, align 4
  %967 = getelementptr inbounds i32, ptr %18, i64 10
  %968 = load i16, ptr %17, align 2
  %969 = call i16 @llvm.ctpop.i16(i16 %968)
  %970 = icmp eq i16 %969, 1
  %971 = zext i1 %970 to i32
  store i32 %971, ptr %967, align 4
  %972 = getelementptr inbounds i32, ptr %18, i64 11
  %973 = load i16, ptr %17, align 2
  %974 = call i16 @llvm.ctlz.i16(i16 %973, i1 false)
  %975 = sub i16 16, %974
  %976 = zext i16 %975 to i32
  store i32 %976, ptr %972, align 4
  %977 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 0
  %978 = load i32, ptr %977, align 16
  %979 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 1
  %980 = load i32, ptr %979, align 4
  %981 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 2
  %982 = load i32, ptr %981, align 8
  %983 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 3
  %984 = load i32, ptr %983, align 4
  %985 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 4
  %986 = load i32, ptr %985, align 16
  %987 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 5
  %988 = load i32, ptr %987, align 4
  %989 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 6
  %990 = load i32, ptr %989, align 8
  %991 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 7
  %992 = load i32, ptr %991, align 4
  %993 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 8
  %994 = load i32, ptr %993, align 16
  %995 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 9
  %996 = load i32, ptr %995, align 4
  %997 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 10
  %998 = load i32, ptr %997, align 8
  %999 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 11
  %1000 = load i32, ptr %999, align 4
  %1001 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef %978, i32 noundef %980, i32 noundef %982, i32 noundef %984, i32 noundef %986, i32 noundef %988, i32 noundef %990, i32 noundef %992, i32 noundef %994, i32 noundef %996, i32 noundef %998, i32 noundef %1000)
  %1002 = load i16, ptr %17, align 2
  %1003 = call i16 @llvm.ctlz.i16(i16 %1002, i1 true)
  %1004 = sub i16 15, %1003
  %1005 = shl i16 1, %1004
  %1006 = icmp eq i16 %1002, 0
  %1007 = select i1 %1006, i16 0, i16 %1005
  store i16 %1007, ptr %19, align 2
  %1008 = load i16, ptr %17, align 2
  %1009 = icmp ule i16 %1008, 1
  br i1 %1009, label %1015, label %1010

1010:                                             ; preds = %910
  %1011 = sub i16 %1008, 1
  %1012 = call i16 @llvm.ctlz.i16(i16 %1011, i1 false)
  %1013 = sub i16 15, %1012
  %1014 = shl i16 2, %1013
  br label %1015

1015:                                             ; preds = %1010, %910
  %1016 = phi i16 [ 1, %910 ], [ %1014, %1010 ]
  store i16 %1016, ptr %20, align 2
  %1017 = load i16, ptr %17, align 2
  %1018 = call i16 @llvm.fshl.i16(i16 %1017, i16 %1017, i16 3)
  store i16 %1018, ptr %21, align 2
  %1019 = load i16, ptr %17, align 2
  %1020 = call i16 @llvm.fshr.i16(i16 %1019, i16 %1019, i16 3)
  store i16 %1020, ptr %22, align 2
  %1021 = load i16, ptr %17, align 2
  %1022 = call i16 @llvm.fshl.i16(i16 %1021, i16 %1021, i16 0)
  store i16 %1022, ptr %23, align 2
  %1023 = load i16, ptr %17, align 2
  %1024 = call i16 @llvm.fshl.i16(i16 %1023, i16 %1023, i16 8)
  store i16 %1024, ptr %24, align 2
  %1025 = load i16, ptr %19, align 2
  %1026 = zext i16 %1025 to i256
  %1027 = lshr i256 %1026, 128
  %1028 = trunc i256 %1027 to i64
  %1029 = load i16, ptr %19, align 2
  %1030 = zext i16 %1029 to i256
  %1031 = lshr i256 %1030, 64
  %1032 = trunc i256 %1031 to i64
  %1033 = load i16, ptr %19, align 2
  %1034 = zext i16 %1033 to i64
  %1035 = load i16, ptr %20, align 2
  %1036 = zext i16 %1035 to i256
  %1037 = lshr i256 %1036, 128
  %1038 = trunc i256 %1037 to i64
  %1039 = load i16, ptr %20, align 2
  %1040 = zext i16 %1039 to i256
  %1041 = lshr i256 %1040, 64
  %1042 = trunc i256 %1041 to i64
  %1043 = load i16, ptr %20, align 2
  %1044 = zext i16 %1043 to i64
  %1045 = load i16, ptr %21, align 2
  %1046 = zext i16 %1045 to i256
  %1047 = lshr i256 %1046, 128
  %1048 = trunc i256 %1047 to i64
  %1049 = load i16, ptr %21, align 2
  %1050 = zext i16 %1049 to i256
  %1051 = lshr i256 %1050, 64
  %1052 = trunc i256 %1051 to i64
  %1053 = load i16, ptr %21, align 2
  %1054 = zext i16 %1053 to i64
  %1055 = load i16, ptr %22, align 2
  %1056 = zext i16 %1055 to i256
  %1057 = lshr i256 %1056, 128
  %1058 = trunc i256 %1057 to i64
  %1059 = load i16, ptr %22, align 2
  %1060 = zext i16 %1059 to i256
  %1061 = lshr i256 %1060, 64
  %1062 = trunc i256 %1061 to i64
  %1063 = load i16, ptr %22, align 2
  %1064 = zext i16 %1063 to i64
  %1065 = load i16, ptr %23, align 2
  %1066 = zext i16 %1065 to i64
  %1067 = load i16, ptr %24, align 2
  %1068 = zext i16 %1067 to i64
  %1069 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1028, i64 noundef %1032, i64 noundef %1034, i64 noundef %1038, i64 noundef %1042, i64 noundef %1044, i64 noundef %1048, i64 noundef %1052, i64 noundef %1054, i64 noundef %1058, i64 noundef %1062, i64 noundef %1064, i64 noundef %1066, i64 noundef %1068)
  %1070 = load i16, ptr %17, align 2
  %1071 = zext i16 %1070 to i575
  %1072 = getelementptr inbounds [12 x i32], ptr %18, i64 0, i64 0
  %1073 = load i16, ptr %19, align 2
  %1074 = zext i16 %1073 to i575
  %1075 = load i16, ptr %20, align 2
  %1076 = zext i16 %1075 to i575
  %1077 = load i16, ptr %21, align 2
  %1078 = zext i16 %1077 to i575
  %1079 = load i16, ptr %22, align 2
  %1080 = zext i16 %1079 to i575
  %1081 = load i16, ptr %23, align 2
  %1082 = zext i16 %1081 to i575
  %1083 = load i16, ptr %24, align 2
  %1084 = zext i16 %1083 to i575
  %1085 = zext i575 %1071 to i576
  store i576 %1085, ptr %25, align 8
  %1086 = zext i575 %1074 to i576
  store i576 %1086, ptr %26, align 8
  %1087 = zext i575 %1076 to i576
  store i576 %1087, ptr %27, align 8
  %1088 = zext i575 %1078 to i576
  store i576 %1088, ptr %28, align 8
  %1089 = zext i575 %1080 to i576
  store i576 %1089, ptr %29, align 8
  %1090 = zext i575 %1082 to i576
  store i576 %1090, ptr %30, align 8
  %1091 = zext i575 %1084 to i576
  store i576 %1091, ptr %31, align 8
  call void @check(ptr noundef @.str.4, i32 noundef 16, ptr noundef byval([72 x i8]) align 8 %25, ptr noundef %1072, ptr noundef byval([72 x i8]) align 8 %26, ptr noundef byval([72 x i8]) align 8 %27, ptr noundef byval([72 x i8]) align 8 %28, ptr noundef byval([72 x i8]) align 8 %29, ptr noundef byval([72 x i8]) align 8 %30, ptr noundef byval([72 x i8]) align 8 %31)
  br label %1092

1092:                                             ; preds = %1015
  br label %1093

1093:                                             ; preds = %1092
  store i32 0, ptr %32, align 4
  %1094 = load i32, ptr %32, align 4
  %1095 = call i32 @llvm.ctlz.i32(i32 %1094, i1 false)
  store i32 %1095, ptr %33, align 4
  %1096 = getelementptr inbounds i32, ptr %33, i64 1
  %1097 = load i32, ptr %32, align 4
  %1098 = xor i32 %1097, -1
  %1099 = call i32 @llvm.ctlz.i32(i32 %1098, i1 false)
  store i32 %1099, ptr %1096, align 4
  %1100 = getelementptr inbounds i32, ptr %33, i64 2
  %1101 = load i32, ptr %32, align 4
  %1102 = call i32 @llvm.cttz.i32(i32 %1101, i1 false)
  store i32 %1102, ptr %1100, align 4
  %1103 = getelementptr inbounds i32, ptr %33, i64 3
  %1104 = load i32, ptr %32, align 4
  %1105 = xor i32 %1104, -1
  %1106 = call i32 @llvm.cttz.i32(i32 %1105, i1 false)
  store i32 %1106, ptr %1103, align 4
  %1107 = getelementptr inbounds i32, ptr %33, i64 4
  %1108 = load i32, ptr %32, align 4
  %1109 = xor i32 %1108, -1
  %1110 = call i32 @llvm.ctlz.i32(i32 %1109, i1 false)
  %1111 = add i32 %1110, 1
  %1112 = icmp eq i32 %1109, 0
  %1113 = select i1 %1112, i32 0, i32 %1111
  store i32 %1113, ptr %1107, align 4
  %1114 = getelementptr inbounds i32, ptr %33, i64 5
  %1115 = load i32, ptr %32, align 4
  %1116 = call i32 @llvm.ctlz.i32(i32 %1115, i1 false)
  %1117 = add i32 %1116, 1
  %1118 = icmp eq i32 %1115, 0
  %1119 = select i1 %1118, i32 0, i32 %1117
  store i32 %1119, ptr %1114, align 4
  %1120 = getelementptr inbounds i32, ptr %33, i64 6
  %1121 = load i32, ptr %32, align 4
  %1122 = xor i32 %1121, -1
  %1123 = call i32 @llvm.cttz.i32(i32 %1122, i1 false)
  %1124 = add i32 %1123, 1
  %1125 = icmp eq i32 %1122, 0
  %1126 = select i1 %1125, i32 0, i32 %1124
  store i32 %1126, ptr %1120, align 4
  %1127 = getelementptr inbounds i32, ptr %33, i64 7
  %1128 = load i32, ptr %32, align 4
  %1129 = call i32 @llvm.cttz.i32(i32 %1128, i1 false)
  %1130 = add i32 %1129, 1
  %1131 = icmp eq i32 %1128, 0
  %1132 = select i1 %1131, i32 0, i32 %1130
  store i32 %1132, ptr %1127, align 4
  %1133 = getelementptr inbounds i32, ptr %33, i64 8
  %1134 = load i32, ptr %32, align 4
  %1135 = call i32 @llvm.ctpop.i32(i32 %1134)
  %1136 = sub i32 32, %1135
  store i32 %1136, ptr %1133, align 4
  %1137 = getelementptr inbounds i32, ptr %33, i64 9
  %1138 = load i32, ptr %32, align 4
  %1139 = call i32 @llvm.ctpop.i32(i32 %1138)
  store i32 %1139, ptr %1137, align 4
  %1140 = getelementptr inbounds i32, ptr %33, i64 10
  %1141 = load i32, ptr %32, align 4
  %1142 = call i32 @llvm.ctpop.i32(i32 %1141)
  %1143 = icmp eq i32 %1142, 1
  %1144 = zext i1 %1143 to i32
  store i32 %1144, ptr %1140, align 4
  %1145 = getelementptr inbounds i32, ptr %33, i64 11
  %1146 = load i32, ptr %32, align 4
  %1147 = call i32 @llvm.ctlz.i32(i32 %1146, i1 false)
  %1148 = sub i32 32, %1147
  store i32 %1148, ptr %1145, align 4
  %1149 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 0
  %1150 = load i32, ptr %1149, align 16
  %1151 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 1
  %1152 = load i32, ptr %1151, align 4
  %1153 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 2
  %1154 = load i32, ptr %1153, align 8
  %1155 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 3
  %1156 = load i32, ptr %1155, align 4
  %1157 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 4
  %1158 = load i32, ptr %1157, align 16
  %1159 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 5
  %1160 = load i32, ptr %1159, align 4
  %1161 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 6
  %1162 = load i32, ptr %1161, align 8
  %1163 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 7
  %1164 = load i32, ptr %1163, align 4
  %1165 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 8
  %1166 = load i32, ptr %1165, align 16
  %1167 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 9
  %1168 = load i32, ptr %1167, align 4
  %1169 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 10
  %1170 = load i32, ptr %1169, align 8
  %1171 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 11
  %1172 = load i32, ptr %1171, align 4
  %1173 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef %1150, i32 noundef %1152, i32 noundef %1154, i32 noundef %1156, i32 noundef %1158, i32 noundef %1160, i32 noundef %1162, i32 noundef %1164, i32 noundef %1166, i32 noundef %1168, i32 noundef %1170, i32 noundef %1172)
  %1174 = load i32, ptr %32, align 4
  %1175 = call i32 @llvm.ctlz.i32(i32 %1174, i1 true)
  %1176 = sub i32 31, %1175
  %1177 = shl i32 1, %1176
  %1178 = icmp eq i32 %1174, 0
  %1179 = select i1 %1178, i32 0, i32 %1177
  store i32 %1179, ptr %34, align 4
  %1180 = load i32, ptr %32, align 4
  %1181 = icmp ule i32 %1180, 1
  br i1 %1181, label %1187, label %1182

1182:                                             ; preds = %1093
  %1183 = sub i32 %1180, 1
  %1184 = call i32 @llvm.ctlz.i32(i32 %1183, i1 false)
  %1185 = sub i32 31, %1184
  %1186 = shl i32 2, %1185
  br label %1187

1187:                                             ; preds = %1182, %1093
  %1188 = phi i32 [ 1, %1093 ], [ %1186, %1182 ]
  store i32 %1188, ptr %35, align 4
  %1189 = load i32, ptr %32, align 4
  %1190 = call i32 @llvm.fshl.i32(i32 %1189, i32 %1189, i32 3)
  store i32 %1190, ptr %36, align 4
  %1191 = load i32, ptr %32, align 4
  %1192 = call i32 @llvm.fshr.i32(i32 %1191, i32 %1191, i32 3)
  store i32 %1192, ptr %37, align 4
  %1193 = load i32, ptr %32, align 4
  %1194 = call i32 @llvm.fshl.i32(i32 %1193, i32 %1193, i32 0)
  store i32 %1194, ptr %38, align 4
  %1195 = load i32, ptr %32, align 4
  %1196 = call i32 @llvm.fshl.i32(i32 %1195, i32 %1195, i32 8)
  store i32 %1196, ptr %39, align 4
  %1197 = load i32, ptr %34, align 4
  %1198 = zext i32 %1197 to i256
  %1199 = lshr i256 %1198, 128
  %1200 = trunc i256 %1199 to i64
  %1201 = load i32, ptr %34, align 4
  %1202 = zext i32 %1201 to i256
  %1203 = lshr i256 %1202, 64
  %1204 = trunc i256 %1203 to i64
  %1205 = load i32, ptr %34, align 4
  %1206 = zext i32 %1205 to i64
  %1207 = load i32, ptr %35, align 4
  %1208 = zext i32 %1207 to i256
  %1209 = lshr i256 %1208, 128
  %1210 = trunc i256 %1209 to i64
  %1211 = load i32, ptr %35, align 4
  %1212 = zext i32 %1211 to i256
  %1213 = lshr i256 %1212, 64
  %1214 = trunc i256 %1213 to i64
  %1215 = load i32, ptr %35, align 4
  %1216 = zext i32 %1215 to i64
  %1217 = load i32, ptr %36, align 4
  %1218 = zext i32 %1217 to i256
  %1219 = lshr i256 %1218, 128
  %1220 = trunc i256 %1219 to i64
  %1221 = load i32, ptr %36, align 4
  %1222 = zext i32 %1221 to i256
  %1223 = lshr i256 %1222, 64
  %1224 = trunc i256 %1223 to i64
  %1225 = load i32, ptr %36, align 4
  %1226 = zext i32 %1225 to i64
  %1227 = load i32, ptr %37, align 4
  %1228 = zext i32 %1227 to i256
  %1229 = lshr i256 %1228, 128
  %1230 = trunc i256 %1229 to i64
  %1231 = load i32, ptr %37, align 4
  %1232 = zext i32 %1231 to i256
  %1233 = lshr i256 %1232, 64
  %1234 = trunc i256 %1233 to i64
  %1235 = load i32, ptr %37, align 4
  %1236 = zext i32 %1235 to i64
  %1237 = load i32, ptr %38, align 4
  %1238 = zext i32 %1237 to i64
  %1239 = load i32, ptr %39, align 4
  %1240 = zext i32 %1239 to i64
  %1241 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1200, i64 noundef %1204, i64 noundef %1206, i64 noundef %1210, i64 noundef %1214, i64 noundef %1216, i64 noundef %1220, i64 noundef %1224, i64 noundef %1226, i64 noundef %1230, i64 noundef %1234, i64 noundef %1236, i64 noundef %1238, i64 noundef %1240)
  %1242 = load i32, ptr %32, align 4
  %1243 = zext i32 %1242 to i575
  %1244 = getelementptr inbounds [12 x i32], ptr %33, i64 0, i64 0
  %1245 = load i32, ptr %34, align 4
  %1246 = zext i32 %1245 to i575
  %1247 = load i32, ptr %35, align 4
  %1248 = zext i32 %1247 to i575
  %1249 = load i32, ptr %36, align 4
  %1250 = zext i32 %1249 to i575
  %1251 = load i32, ptr %37, align 4
  %1252 = zext i32 %1251 to i575
  %1253 = load i32, ptr %38, align 4
  %1254 = zext i32 %1253 to i575
  %1255 = load i32, ptr %39, align 4
  %1256 = zext i32 %1255 to i575
  %1257 = zext i575 %1243 to i576
  store i576 %1257, ptr %40, align 8
  %1258 = zext i575 %1246 to i576
  store i576 %1258, ptr %41, align 8
  %1259 = zext i575 %1248 to i576
  store i576 %1259, ptr %42, align 8
  %1260 = zext i575 %1250 to i576
  store i576 %1260, ptr %43, align 8
  %1261 = zext i575 %1252 to i576
  store i576 %1261, ptr %44, align 8
  %1262 = zext i575 %1254 to i576
  store i576 %1262, ptr %45, align 8
  %1263 = zext i575 %1256 to i576
  store i576 %1263, ptr %46, align 8
  call void @check(ptr noundef @.str.5, i32 noundef 32, ptr noundef byval([72 x i8]) align 8 %40, ptr noundef %1244, ptr noundef byval([72 x i8]) align 8 %41, ptr noundef byval([72 x i8]) align 8 %42, ptr noundef byval([72 x i8]) align 8 %43, ptr noundef byval([72 x i8]) align 8 %44, ptr noundef byval([72 x i8]) align 8 %45, ptr noundef byval([72 x i8]) align 8 %46)
  br label %1264

1264:                                             ; preds = %1187
  br label %1265

1265:                                             ; preds = %1264
  store i64 0, ptr %47, align 8
  %1266 = load i64, ptr %47, align 8
  %1267 = call i64 @llvm.ctlz.i64(i64 %1266, i1 false)
  %1268 = trunc i64 %1267 to i32
  store i32 %1268, ptr %48, align 4
  %1269 = getelementptr inbounds i32, ptr %48, i64 1
  %1270 = load i64, ptr %47, align 8
  %1271 = xor i64 %1270, -1
  %1272 = call i64 @llvm.ctlz.i64(i64 %1271, i1 false)
  %1273 = trunc i64 %1272 to i32
  store i32 %1273, ptr %1269, align 4
  %1274 = getelementptr inbounds i32, ptr %48, i64 2
  %1275 = load i64, ptr %47, align 8
  %1276 = call i64 @llvm.cttz.i64(i64 %1275, i1 false)
  %1277 = trunc i64 %1276 to i32
  store i32 %1277, ptr %1274, align 4
  %1278 = getelementptr inbounds i32, ptr %48, i64 3
  %1279 = load i64, ptr %47, align 8
  %1280 = xor i64 %1279, -1
  %1281 = call i64 @llvm.cttz.i64(i64 %1280, i1 false)
  %1282 = trunc i64 %1281 to i32
  store i32 %1282, ptr %1278, align 4
  %1283 = getelementptr inbounds i32, ptr %48, i64 4
  %1284 = load i64, ptr %47, align 8
  %1285 = xor i64 %1284, -1
  %1286 = call i64 @llvm.ctlz.i64(i64 %1285, i1 false)
  %1287 = add i64 %1286, 1
  %1288 = icmp eq i64 %1285, 0
  %1289 = select i1 %1288, i64 0, i64 %1287
  %1290 = trunc i64 %1289 to i32
  store i32 %1290, ptr %1283, align 4
  %1291 = getelementptr inbounds i32, ptr %48, i64 5
  %1292 = load i64, ptr %47, align 8
  %1293 = call i64 @llvm.ctlz.i64(i64 %1292, i1 false)
  %1294 = add i64 %1293, 1
  %1295 = icmp eq i64 %1292, 0
  %1296 = select i1 %1295, i64 0, i64 %1294
  %1297 = trunc i64 %1296 to i32
  store i32 %1297, ptr %1291, align 4
  %1298 = getelementptr inbounds i32, ptr %48, i64 6
  %1299 = load i64, ptr %47, align 8
  %1300 = xor i64 %1299, -1
  %1301 = call i64 @llvm.cttz.i64(i64 %1300, i1 false)
  %1302 = add i64 %1301, 1
  %1303 = icmp eq i64 %1300, 0
  %1304 = select i1 %1303, i64 0, i64 %1302
  %1305 = trunc i64 %1304 to i32
  store i32 %1305, ptr %1298, align 4
  %1306 = getelementptr inbounds i32, ptr %48, i64 7
  %1307 = load i64, ptr %47, align 8
  %1308 = call i64 @llvm.cttz.i64(i64 %1307, i1 false)
  %1309 = add i64 %1308, 1
  %1310 = icmp eq i64 %1307, 0
  %1311 = select i1 %1310, i64 0, i64 %1309
  %1312 = trunc i64 %1311 to i32
  store i32 %1312, ptr %1306, align 4
  %1313 = getelementptr inbounds i32, ptr %48, i64 8
  %1314 = load i64, ptr %47, align 8
  %1315 = call i64 @llvm.ctpop.i64(i64 %1314)
  %1316 = sub i64 64, %1315
  %1317 = trunc i64 %1316 to i32
  store i32 %1317, ptr %1313, align 4
  %1318 = getelementptr inbounds i32, ptr %48, i64 9
  %1319 = load i64, ptr %47, align 8
  %1320 = call i64 @llvm.ctpop.i64(i64 %1319)
  %1321 = trunc i64 %1320 to i32
  store i32 %1321, ptr %1318, align 4
  %1322 = getelementptr inbounds i32, ptr %48, i64 10
  %1323 = load i64, ptr %47, align 8
  %1324 = call i64 @llvm.ctpop.i64(i64 %1323)
  %1325 = icmp eq i64 %1324, 1
  %1326 = zext i1 %1325 to i32
  store i32 %1326, ptr %1322, align 4
  %1327 = getelementptr inbounds i32, ptr %48, i64 11
  %1328 = load i64, ptr %47, align 8
  %1329 = call i64 @llvm.ctlz.i64(i64 %1328, i1 false)
  %1330 = sub i64 64, %1329
  %1331 = trunc i64 %1330 to i32
  store i32 %1331, ptr %1327, align 4
  %1332 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 0
  %1333 = load i32, ptr %1332, align 16
  %1334 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 1
  %1335 = load i32, ptr %1334, align 4
  %1336 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 2
  %1337 = load i32, ptr %1336, align 8
  %1338 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 3
  %1339 = load i32, ptr %1338, align 4
  %1340 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 4
  %1341 = load i32, ptr %1340, align 16
  %1342 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 5
  %1343 = load i32, ptr %1342, align 4
  %1344 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 6
  %1345 = load i32, ptr %1344, align 8
  %1346 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 7
  %1347 = load i32, ptr %1346, align 4
  %1348 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 8
  %1349 = load i32, ptr %1348, align 16
  %1350 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 9
  %1351 = load i32, ptr %1350, align 4
  %1352 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 10
  %1353 = load i32, ptr %1352, align 8
  %1354 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 11
  %1355 = load i32, ptr %1354, align 4
  %1356 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef %1333, i32 noundef %1335, i32 noundef %1337, i32 noundef %1339, i32 noundef %1341, i32 noundef %1343, i32 noundef %1345, i32 noundef %1347, i32 noundef %1349, i32 noundef %1351, i32 noundef %1353, i32 noundef %1355)
  %1357 = load i64, ptr %47, align 8
  %1358 = call i64 @llvm.ctlz.i64(i64 %1357, i1 true)
  %1359 = sub i64 63, %1358
  %1360 = shl i64 1, %1359
  %1361 = icmp eq i64 %1357, 0
  %1362 = select i1 %1361, i64 0, i64 %1360
  store i64 %1362, ptr %49, align 8
  %1363 = load i64, ptr %47, align 8
  %1364 = icmp ule i64 %1363, 1
  br i1 %1364, label %1370, label %1365

1365:                                             ; preds = %1265
  %1366 = sub i64 %1363, 1
  %1367 = call i64 @llvm.ctlz.i64(i64 %1366, i1 false)
  %1368 = sub i64 63, %1367
  %1369 = shl i64 2, %1368
  br label %1370

1370:                                             ; preds = %1365, %1265
  %1371 = phi i64 [ 1, %1265 ], [ %1369, %1365 ]
  store i64 %1371, ptr %50, align 8
  %1372 = load i64, ptr %47, align 8
  %1373 = call i64 @llvm.fshl.i64(i64 %1372, i64 %1372, i64 3)
  store i64 %1373, ptr %51, align 8
  %1374 = load i64, ptr %47, align 8
  %1375 = call i64 @llvm.fshr.i64(i64 %1374, i64 %1374, i64 3)
  store i64 %1375, ptr %52, align 8
  %1376 = load i64, ptr %47, align 8
  %1377 = call i64 @llvm.fshl.i64(i64 %1376, i64 %1376, i64 0)
  store i64 %1377, ptr %53, align 8
  %1378 = load i64, ptr %47, align 8
  %1379 = call i64 @llvm.fshl.i64(i64 %1378, i64 %1378, i64 40)
  store i64 %1379, ptr %54, align 8
  %1380 = load i64, ptr %49, align 8
  %1381 = zext i64 %1380 to i256
  %1382 = lshr i256 %1381, 128
  %1383 = trunc i256 %1382 to i64
  %1384 = load i64, ptr %49, align 8
  %1385 = zext i64 %1384 to i256
  %1386 = lshr i256 %1385, 64
  %1387 = trunc i256 %1386 to i64
  %1388 = load i64, ptr %49, align 8
  %1389 = load i64, ptr %50, align 8
  %1390 = zext i64 %1389 to i256
  %1391 = lshr i256 %1390, 128
  %1392 = trunc i256 %1391 to i64
  %1393 = load i64, ptr %50, align 8
  %1394 = zext i64 %1393 to i256
  %1395 = lshr i256 %1394, 64
  %1396 = trunc i256 %1395 to i64
  %1397 = load i64, ptr %50, align 8
  %1398 = load i64, ptr %51, align 8
  %1399 = zext i64 %1398 to i256
  %1400 = lshr i256 %1399, 128
  %1401 = trunc i256 %1400 to i64
  %1402 = load i64, ptr %51, align 8
  %1403 = zext i64 %1402 to i256
  %1404 = lshr i256 %1403, 64
  %1405 = trunc i256 %1404 to i64
  %1406 = load i64, ptr %51, align 8
  %1407 = load i64, ptr %52, align 8
  %1408 = zext i64 %1407 to i256
  %1409 = lshr i256 %1408, 128
  %1410 = trunc i256 %1409 to i64
  %1411 = load i64, ptr %52, align 8
  %1412 = zext i64 %1411 to i256
  %1413 = lshr i256 %1412, 64
  %1414 = trunc i256 %1413 to i64
  %1415 = load i64, ptr %52, align 8
  %1416 = load i64, ptr %53, align 8
  %1417 = load i64, ptr %54, align 8
  %1418 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1383, i64 noundef %1387, i64 noundef %1388, i64 noundef %1392, i64 noundef %1396, i64 noundef %1397, i64 noundef %1401, i64 noundef %1405, i64 noundef %1406, i64 noundef %1410, i64 noundef %1414, i64 noundef %1415, i64 noundef %1416, i64 noundef %1417)
  %1419 = load i64, ptr %47, align 8
  %1420 = zext i64 %1419 to i575
  %1421 = getelementptr inbounds [12 x i32], ptr %48, i64 0, i64 0
  %1422 = load i64, ptr %49, align 8
  %1423 = zext i64 %1422 to i575
  %1424 = load i64, ptr %50, align 8
  %1425 = zext i64 %1424 to i575
  %1426 = load i64, ptr %51, align 8
  %1427 = zext i64 %1426 to i575
  %1428 = load i64, ptr %52, align 8
  %1429 = zext i64 %1428 to i575
  %1430 = load i64, ptr %53, align 8
  %1431 = zext i64 %1430 to i575
  %1432 = load i64, ptr %54, align 8
  %1433 = zext i64 %1432 to i575
  %1434 = zext i575 %1420 to i576
  store i576 %1434, ptr %55, align 8
  %1435 = zext i575 %1423 to i576
  store i576 %1435, ptr %56, align 8
  %1436 = zext i575 %1425 to i576
  store i576 %1436, ptr %57, align 8
  %1437 = zext i575 %1427 to i576
  store i576 %1437, ptr %58, align 8
  %1438 = zext i575 %1429 to i576
  store i576 %1438, ptr %59, align 8
  %1439 = zext i575 %1431 to i576
  store i576 %1439, ptr %60, align 8
  %1440 = zext i575 %1433 to i576
  store i576 %1440, ptr %61, align 8
  call void @check(ptr noundef @.str.6, i32 noundef 64, ptr noundef byval([72 x i8]) align 8 %55, ptr noundef %1421, ptr noundef byval([72 x i8]) align 8 %56, ptr noundef byval([72 x i8]) align 8 %57, ptr noundef byval([72 x i8]) align 8 %58, ptr noundef byval([72 x i8]) align 8 %59, ptr noundef byval([72 x i8]) align 8 %60, ptr noundef byval([72 x i8]) align 8 %61)
  br label %1441

1441:                                             ; preds = %1370
  br label %1442

1442:                                             ; preds = %1441
  store i128 0, ptr %62, align 16
  %1443 = load i128, ptr %62, align 16
  %1444 = call i128 @llvm.ctlz.i128(i128 %1443, i1 false)
  %1445 = trunc i128 %1444 to i32
  store i32 %1445, ptr %63, align 4
  %1446 = getelementptr inbounds i32, ptr %63, i64 1
  %1447 = load i128, ptr %62, align 16
  %1448 = xor i128 %1447, -1
  %1449 = call i128 @llvm.ctlz.i128(i128 %1448, i1 false)
  %1450 = trunc i128 %1449 to i32
  store i32 %1450, ptr %1446, align 4
  %1451 = getelementptr inbounds i32, ptr %63, i64 2
  %1452 = load i128, ptr %62, align 16
  %1453 = call i128 @llvm.cttz.i128(i128 %1452, i1 false)
  %1454 = trunc i128 %1453 to i32
  store i32 %1454, ptr %1451, align 4
  %1455 = getelementptr inbounds i32, ptr %63, i64 3
  %1456 = load i128, ptr %62, align 16
  %1457 = xor i128 %1456, -1
  %1458 = call i128 @llvm.cttz.i128(i128 %1457, i1 false)
  %1459 = trunc i128 %1458 to i32
  store i32 %1459, ptr %1455, align 4
  %1460 = getelementptr inbounds i32, ptr %63, i64 4
  %1461 = load i128, ptr %62, align 16
  %1462 = xor i128 %1461, -1
  %1463 = call i128 @llvm.ctlz.i128(i128 %1462, i1 false)
  %1464 = add i128 %1463, 1
  %1465 = icmp eq i128 %1462, 0
  %1466 = select i1 %1465, i128 0, i128 %1464
  %1467 = trunc i128 %1466 to i32
  store i32 %1467, ptr %1460, align 4
  %1468 = getelementptr inbounds i32, ptr %63, i64 5
  %1469 = load i128, ptr %62, align 16
  %1470 = call i128 @llvm.ctlz.i128(i128 %1469, i1 false)
  %1471 = add i128 %1470, 1
  %1472 = icmp eq i128 %1469, 0
  %1473 = select i1 %1472, i128 0, i128 %1471
  %1474 = trunc i128 %1473 to i32
  store i32 %1474, ptr %1468, align 4
  %1475 = getelementptr inbounds i32, ptr %63, i64 6
  %1476 = load i128, ptr %62, align 16
  %1477 = xor i128 %1476, -1
  %1478 = call i128 @llvm.cttz.i128(i128 %1477, i1 false)
  %1479 = add i128 %1478, 1
  %1480 = icmp eq i128 %1477, 0
  %1481 = select i1 %1480, i128 0, i128 %1479
  %1482 = trunc i128 %1481 to i32
  store i32 %1482, ptr %1475, align 4
  %1483 = getelementptr inbounds i32, ptr %63, i64 7
  %1484 = load i128, ptr %62, align 16
  %1485 = call i128 @llvm.cttz.i128(i128 %1484, i1 false)
  %1486 = add i128 %1485, 1
  %1487 = icmp eq i128 %1484, 0
  %1488 = select i1 %1487, i128 0, i128 %1486
  %1489 = trunc i128 %1488 to i32
  store i32 %1489, ptr %1483, align 4
  %1490 = getelementptr inbounds i32, ptr %63, i64 8
  %1491 = load i128, ptr %62, align 16
  %1492 = call i128 @llvm.ctpop.i128(i128 %1491)
  %1493 = sub i128 128, %1492
  %1494 = trunc i128 %1493 to i32
  store i32 %1494, ptr %1490, align 4
  %1495 = getelementptr inbounds i32, ptr %63, i64 9
  %1496 = load i128, ptr %62, align 16
  %1497 = call i128 @llvm.ctpop.i128(i128 %1496)
  %1498 = trunc i128 %1497 to i32
  store i32 %1498, ptr %1495, align 4
  %1499 = getelementptr inbounds i32, ptr %63, i64 10
  %1500 = load i128, ptr %62, align 16
  %1501 = call i128 @llvm.ctpop.i128(i128 %1500)
  %1502 = icmp eq i128 %1501, 1
  %1503 = zext i1 %1502 to i32
  store i32 %1503, ptr %1499, align 4
  %1504 = getelementptr inbounds i32, ptr %63, i64 11
  %1505 = load i128, ptr %62, align 16
  %1506 = call i128 @llvm.ctlz.i128(i128 %1505, i1 false)
  %1507 = sub i128 128, %1506
  %1508 = trunc i128 %1507 to i32
  store i32 %1508, ptr %1504, align 4
  %1509 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 0
  %1510 = load i32, ptr %1509, align 16
  %1511 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 1
  %1512 = load i32, ptr %1511, align 4
  %1513 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 2
  %1514 = load i32, ptr %1513, align 8
  %1515 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 3
  %1516 = load i32, ptr %1515, align 4
  %1517 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 4
  %1518 = load i32, ptr %1517, align 16
  %1519 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 5
  %1520 = load i32, ptr %1519, align 4
  %1521 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 6
  %1522 = load i32, ptr %1521, align 8
  %1523 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 7
  %1524 = load i32, ptr %1523, align 4
  %1525 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 8
  %1526 = load i32, ptr %1525, align 16
  %1527 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 9
  %1528 = load i32, ptr %1527, align 4
  %1529 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 10
  %1530 = load i32, ptr %1529, align 8
  %1531 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 11
  %1532 = load i32, ptr %1531, align 4
  %1533 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef %1510, i32 noundef %1512, i32 noundef %1514, i32 noundef %1516, i32 noundef %1518, i32 noundef %1520, i32 noundef %1522, i32 noundef %1524, i32 noundef %1526, i32 noundef %1528, i32 noundef %1530, i32 noundef %1532)
  %1534 = load i128, ptr %62, align 16
  %1535 = call i128 @llvm.ctlz.i128(i128 %1534, i1 true)
  %1536 = sub i128 127, %1535
  %1537 = shl i128 1, %1536
  %1538 = icmp eq i128 %1534, 0
  %1539 = select i1 %1538, i128 0, i128 %1537
  store i128 %1539, ptr %64, align 16
  %1540 = load i128, ptr %62, align 16
  %1541 = icmp ule i128 %1540, 1
  br i1 %1541, label %1547, label %1542

1542:                                             ; preds = %1442
  %1543 = sub i128 %1540, 1
  %1544 = call i128 @llvm.ctlz.i128(i128 %1543, i1 false)
  %1545 = sub i128 127, %1544
  %1546 = shl i128 2, %1545
  br label %1547

1547:                                             ; preds = %1542, %1442
  %1548 = phi i128 [ 1, %1442 ], [ %1546, %1542 ]
  store i128 %1548, ptr %65, align 16
  %1549 = load i128, ptr %62, align 16
  %1550 = call i128 @llvm.fshl.i128(i128 %1549, i128 %1549, i128 3)
  store i128 %1550, ptr %66, align 16
  %1551 = load i128, ptr %62, align 16
  %1552 = call i128 @llvm.fshr.i128(i128 %1551, i128 %1551, i128 3)
  store i128 %1552, ptr %67, align 16
  %1553 = load i128, ptr %62, align 16
  %1554 = call i128 @llvm.fshl.i128(i128 %1553, i128 %1553, i128 0)
  store i128 %1554, ptr %68, align 16
  %1555 = load i128, ptr %62, align 16
  %1556 = call i128 @llvm.fshl.i128(i128 %1555, i128 %1555, i128 104)
  store i128 %1556, ptr %69, align 16
  %1557 = load i128, ptr %64, align 16
  %1558 = zext i128 %1557 to i256
  %1559 = lshr i256 %1558, 128
  %1560 = trunc i256 %1559 to i64
  %1561 = load i128, ptr %64, align 16
  %1562 = zext i128 %1561 to i256
  %1563 = lshr i256 %1562, 64
  %1564 = trunc i256 %1563 to i64
  %1565 = load i128, ptr %64, align 16
  %1566 = trunc i128 %1565 to i64
  %1567 = load i128, ptr %65, align 16
  %1568 = zext i128 %1567 to i256
  %1569 = lshr i256 %1568, 128
  %1570 = trunc i256 %1569 to i64
  %1571 = load i128, ptr %65, align 16
  %1572 = zext i128 %1571 to i256
  %1573 = lshr i256 %1572, 64
  %1574 = trunc i256 %1573 to i64
  %1575 = load i128, ptr %65, align 16
  %1576 = trunc i128 %1575 to i64
  %1577 = load i128, ptr %66, align 16
  %1578 = zext i128 %1577 to i256
  %1579 = lshr i256 %1578, 128
  %1580 = trunc i256 %1579 to i64
  %1581 = load i128, ptr %66, align 16
  %1582 = zext i128 %1581 to i256
  %1583 = lshr i256 %1582, 64
  %1584 = trunc i256 %1583 to i64
  %1585 = load i128, ptr %66, align 16
  %1586 = trunc i128 %1585 to i64
  %1587 = load i128, ptr %67, align 16
  %1588 = zext i128 %1587 to i256
  %1589 = lshr i256 %1588, 128
  %1590 = trunc i256 %1589 to i64
  %1591 = load i128, ptr %67, align 16
  %1592 = zext i128 %1591 to i256
  %1593 = lshr i256 %1592, 64
  %1594 = trunc i256 %1593 to i64
  %1595 = load i128, ptr %67, align 16
  %1596 = trunc i128 %1595 to i64
  %1597 = load i128, ptr %68, align 16
  %1598 = trunc i128 %1597 to i64
  %1599 = load i128, ptr %69, align 16
  %1600 = trunc i128 %1599 to i64
  %1601 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1560, i64 noundef %1564, i64 noundef %1566, i64 noundef %1570, i64 noundef %1574, i64 noundef %1576, i64 noundef %1580, i64 noundef %1584, i64 noundef %1586, i64 noundef %1590, i64 noundef %1594, i64 noundef %1596, i64 noundef %1598, i64 noundef %1600)
  %1602 = load i128, ptr %62, align 16
  %1603 = zext i128 %1602 to i575
  %1604 = getelementptr inbounds [12 x i32], ptr %63, i64 0, i64 0
  %1605 = load i128, ptr %64, align 16
  %1606 = zext i128 %1605 to i575
  %1607 = load i128, ptr %65, align 16
  %1608 = zext i128 %1607 to i575
  %1609 = load i128, ptr %66, align 16
  %1610 = zext i128 %1609 to i575
  %1611 = load i128, ptr %67, align 16
  %1612 = zext i128 %1611 to i575
  %1613 = load i128, ptr %68, align 16
  %1614 = zext i128 %1613 to i575
  %1615 = load i128, ptr %69, align 16
  %1616 = zext i128 %1615 to i575
  %1617 = zext i575 %1603 to i576
  store i576 %1617, ptr %70, align 8
  %1618 = zext i575 %1606 to i576
  store i576 %1618, ptr %71, align 8
  %1619 = zext i575 %1608 to i576
  store i576 %1619, ptr %72, align 8
  %1620 = zext i575 %1610 to i576
  store i576 %1620, ptr %73, align 8
  %1621 = zext i575 %1612 to i576
  store i576 %1621, ptr %74, align 8
  %1622 = zext i575 %1614 to i576
  store i576 %1622, ptr %75, align 8
  %1623 = zext i575 %1616 to i576
  store i576 %1623, ptr %76, align 8
  call void @check(ptr noundef @.str.7, i32 noundef 128, ptr noundef byval([72 x i8]) align 8 %70, ptr noundef %1604, ptr noundef byval([72 x i8]) align 8 %71, ptr noundef byval([72 x i8]) align 8 %72, ptr noundef byval([72 x i8]) align 8 %73, ptr noundef byval([72 x i8]) align 8 %74, ptr noundef byval([72 x i8]) align 8 %75, ptr noundef byval([72 x i8]) align 8 %76)
  br label %1624

1624:                                             ; preds = %1547
  br label %1625

1625:                                             ; preds = %1624
  store i8 0, ptr %77, align 1
  %1626 = load i8, ptr %77, align 1
  %1627 = trunc i8 %1626 to i7
  %1628 = call i7 @llvm.ctlz.i7(i7 %1627, i1 false)
  %1629 = zext i7 %1628 to i32
  store i32 %1629, ptr %78, align 4
  %1630 = getelementptr inbounds i32, ptr %78, i64 1
  %1631 = load i8, ptr %77, align 1
  %1632 = trunc i8 %1631 to i7
  %1633 = xor i7 %1632, -1
  %1634 = call i7 @llvm.ctlz.i7(i7 %1633, i1 false)
  %1635 = zext i7 %1634 to i32
  store i32 %1635, ptr %1630, align 4
  %1636 = getelementptr inbounds i32, ptr %78, i64 2
  %1637 = load i8, ptr %77, align 1
  %1638 = trunc i8 %1637 to i7
  %1639 = call i7 @llvm.cttz.i7(i7 %1638, i1 false)
  %1640 = zext i7 %1639 to i32
  store i32 %1640, ptr %1636, align 4
  %1641 = getelementptr inbounds i32, ptr %78, i64 3
  %1642 = load i8, ptr %77, align 1
  %1643 = trunc i8 %1642 to i7
  %1644 = xor i7 %1643, -1
  %1645 = call i7 @llvm.cttz.i7(i7 %1644, i1 false)
  %1646 = zext i7 %1645 to i32
  store i32 %1646, ptr %1641, align 4
  %1647 = getelementptr inbounds i32, ptr %78, i64 4
  %1648 = load i8, ptr %77, align 1
  %1649 = trunc i8 %1648 to i7
  %1650 = xor i7 %1649, -1
  %1651 = call i7 @llvm.ctlz.i7(i7 %1650, i1 false)
  %1652 = add i7 %1651, 1
  %1653 = icmp eq i7 %1650, 0
  %1654 = select i1 %1653, i7 0, i7 %1652
  %1655 = zext i7 %1654 to i32
  store i32 %1655, ptr %1647, align 4
  %1656 = getelementptr inbounds i32, ptr %78, i64 5
  %1657 = load i8, ptr %77, align 1
  %1658 = trunc i8 %1657 to i7
  %1659 = call i7 @llvm.ctlz.i7(i7 %1658, i1 false)
  %1660 = add i7 %1659, 1
  %1661 = icmp eq i7 %1658, 0
  %1662 = select i1 %1661, i7 0, i7 %1660
  %1663 = zext i7 %1662 to i32
  store i32 %1663, ptr %1656, align 4
  %1664 = getelementptr inbounds i32, ptr %78, i64 6
  %1665 = load i8, ptr %77, align 1
  %1666 = trunc i8 %1665 to i7
  %1667 = xor i7 %1666, -1
  %1668 = call i7 @llvm.cttz.i7(i7 %1667, i1 false)
  %1669 = add i7 %1668, 1
  %1670 = icmp eq i7 %1667, 0
  %1671 = select i1 %1670, i7 0, i7 %1669
  %1672 = zext i7 %1671 to i32
  store i32 %1672, ptr %1664, align 4
  %1673 = getelementptr inbounds i32, ptr %78, i64 7
  %1674 = load i8, ptr %77, align 1
  %1675 = trunc i8 %1674 to i7
  %1676 = call i7 @llvm.cttz.i7(i7 %1675, i1 false)
  %1677 = add i7 %1676, 1
  %1678 = icmp eq i7 %1675, 0
  %1679 = select i1 %1678, i7 0, i7 %1677
  %1680 = zext i7 %1679 to i32
  store i32 %1680, ptr %1673, align 4
  %1681 = getelementptr inbounds i32, ptr %78, i64 8
  %1682 = load i8, ptr %77, align 1
  %1683 = trunc i8 %1682 to i7
  %1684 = call i7 @llvm.ctpop.i7(i7 %1683)
  %1685 = sub i7 7, %1684
  %1686 = zext i7 %1685 to i32
  store i32 %1686, ptr %1681, align 4
  %1687 = getelementptr inbounds i32, ptr %78, i64 9
  %1688 = load i8, ptr %77, align 1
  %1689 = trunc i8 %1688 to i7
  %1690 = call i7 @llvm.ctpop.i7(i7 %1689)
  %1691 = zext i7 %1690 to i32
  store i32 %1691, ptr %1687, align 4
  %1692 = getelementptr inbounds i32, ptr %78, i64 10
  %1693 = load i8, ptr %77, align 1
  %1694 = trunc i8 %1693 to i7
  %1695 = call i7 @llvm.ctpop.i7(i7 %1694)
  %1696 = icmp eq i7 %1695, 1
  %1697 = zext i1 %1696 to i32
  store i32 %1697, ptr %1692, align 4
  %1698 = getelementptr inbounds i32, ptr %78, i64 11
  %1699 = load i8, ptr %77, align 1
  %1700 = trunc i8 %1699 to i7
  %1701 = call i7 @llvm.ctlz.i7(i7 %1700, i1 false)
  %1702 = sub i7 7, %1701
  %1703 = zext i7 %1702 to i32
  store i32 %1703, ptr %1698, align 4
  %1704 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 0
  %1705 = load i32, ptr %1704, align 16
  %1706 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 1
  %1707 = load i32, ptr %1706, align 4
  %1708 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 2
  %1709 = load i32, ptr %1708, align 8
  %1710 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 3
  %1711 = load i32, ptr %1710, align 4
  %1712 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 4
  %1713 = load i32, ptr %1712, align 16
  %1714 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 5
  %1715 = load i32, ptr %1714, align 4
  %1716 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 6
  %1717 = load i32, ptr %1716, align 8
  %1718 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 7
  %1719 = load i32, ptr %1718, align 4
  %1720 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 8
  %1721 = load i32, ptr %1720, align 16
  %1722 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 9
  %1723 = load i32, ptr %1722, align 4
  %1724 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 10
  %1725 = load i32, ptr %1724, align 8
  %1726 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 11
  %1727 = load i32, ptr %1726, align 4
  %1728 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef %1705, i32 noundef %1707, i32 noundef %1709, i32 noundef %1711, i32 noundef %1713, i32 noundef %1715, i32 noundef %1717, i32 noundef %1719, i32 noundef %1721, i32 noundef %1723, i32 noundef %1725, i32 noundef %1727)
  %1729 = load i8, ptr %77, align 1
  %1730 = trunc i8 %1729 to i7
  %1731 = call i7 @llvm.ctlz.i7(i7 %1730, i1 true)
  %1732 = sub i7 6, %1731
  %1733 = shl i7 1, %1732
  %1734 = icmp eq i7 %1730, 0
  %1735 = select i1 %1734, i7 0, i7 %1733
  %1736 = zext i7 %1735 to i8
  store i8 %1736, ptr %79, align 1
  %1737 = load i8, ptr %77, align 1
  %1738 = trunc i8 %1737 to i7
  %1739 = icmp ule i7 %1738, 1
  br i1 %1739, label %1745, label %1740

1740:                                             ; preds = %1625
  %1741 = sub i7 %1738, 1
  %1742 = call i7 @llvm.ctlz.i7(i7 %1741, i1 false)
  %1743 = sub i7 6, %1742
  %1744 = shl i7 2, %1743
  br label %1745

1745:                                             ; preds = %1740, %1625
  %1746 = phi i7 [ 1, %1625 ], [ %1744, %1740 ]
  %1747 = zext i7 %1746 to i8
  store i8 %1747, ptr %80, align 1
  %1748 = load i8, ptr %77, align 1
  %1749 = trunc i8 %1748 to i7
  %1750 = call i7 @llvm.fshl.i7(i7 %1749, i7 %1749, i7 3)
  %1751 = zext i7 %1750 to i8
  store i8 %1751, ptr %81, align 1
  %1752 = load i8, ptr %77, align 1
  %1753 = trunc i8 %1752 to i7
  %1754 = call i7 @llvm.fshr.i7(i7 %1753, i7 %1753, i7 3)
  %1755 = zext i7 %1754 to i8
  store i8 %1755, ptr %82, align 1
  %1756 = load i8, ptr %77, align 1
  %1757 = trunc i8 %1756 to i7
  %1758 = call i7 @llvm.fshl.i7(i7 %1757, i7 %1757, i7 0)
  %1759 = zext i7 %1758 to i8
  store i8 %1759, ptr %83, align 1
  %1760 = load i8, ptr %77, align 1
  %1761 = trunc i8 %1760 to i7
  %1762 = call i7 @llvm.fshl.i7(i7 %1761, i7 %1761, i7 6)
  %1763 = zext i7 %1762 to i8
  store i8 %1763, ptr %84, align 1
  %1764 = load i8, ptr %79, align 1
  %1765 = trunc i8 %1764 to i7
  %1766 = zext i7 %1765 to i256
  %1767 = lshr i256 %1766, 128
  %1768 = trunc i256 %1767 to i64
  %1769 = load i8, ptr %79, align 1
  %1770 = trunc i8 %1769 to i7
  %1771 = zext i7 %1770 to i256
  %1772 = lshr i256 %1771, 64
  %1773 = trunc i256 %1772 to i64
  %1774 = load i8, ptr %79, align 1
  %1775 = trunc i8 %1774 to i7
  %1776 = zext i7 %1775 to i64
  %1777 = load i8, ptr %80, align 1
  %1778 = trunc i8 %1777 to i7
  %1779 = zext i7 %1778 to i256
  %1780 = lshr i256 %1779, 128
  %1781 = trunc i256 %1780 to i64
  %1782 = load i8, ptr %80, align 1
  %1783 = trunc i8 %1782 to i7
  %1784 = zext i7 %1783 to i256
  %1785 = lshr i256 %1784, 64
  %1786 = trunc i256 %1785 to i64
  %1787 = load i8, ptr %80, align 1
  %1788 = trunc i8 %1787 to i7
  %1789 = zext i7 %1788 to i64
  %1790 = load i8, ptr %81, align 1
  %1791 = trunc i8 %1790 to i7
  %1792 = zext i7 %1791 to i256
  %1793 = lshr i256 %1792, 128
  %1794 = trunc i256 %1793 to i64
  %1795 = load i8, ptr %81, align 1
  %1796 = trunc i8 %1795 to i7
  %1797 = zext i7 %1796 to i256
  %1798 = lshr i256 %1797, 64
  %1799 = trunc i256 %1798 to i64
  %1800 = load i8, ptr %81, align 1
  %1801 = trunc i8 %1800 to i7
  %1802 = zext i7 %1801 to i64
  %1803 = load i8, ptr %82, align 1
  %1804 = trunc i8 %1803 to i7
  %1805 = zext i7 %1804 to i256
  %1806 = lshr i256 %1805, 128
  %1807 = trunc i256 %1806 to i64
  %1808 = load i8, ptr %82, align 1
  %1809 = trunc i8 %1808 to i7
  %1810 = zext i7 %1809 to i256
  %1811 = lshr i256 %1810, 64
  %1812 = trunc i256 %1811 to i64
  %1813 = load i8, ptr %82, align 1
  %1814 = trunc i8 %1813 to i7
  %1815 = zext i7 %1814 to i64
  %1816 = load i8, ptr %83, align 1
  %1817 = trunc i8 %1816 to i7
  %1818 = zext i7 %1817 to i64
  %1819 = load i8, ptr %84, align 1
  %1820 = trunc i8 %1819 to i7
  %1821 = zext i7 %1820 to i64
  %1822 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1768, i64 noundef %1773, i64 noundef %1776, i64 noundef %1781, i64 noundef %1786, i64 noundef %1789, i64 noundef %1794, i64 noundef %1799, i64 noundef %1802, i64 noundef %1807, i64 noundef %1812, i64 noundef %1815, i64 noundef %1818, i64 noundef %1821)
  %1823 = load i8, ptr %77, align 1
  %1824 = trunc i8 %1823 to i7
  %1825 = zext i7 %1824 to i575
  %1826 = getelementptr inbounds [12 x i32], ptr %78, i64 0, i64 0
  %1827 = load i8, ptr %79, align 1
  %1828 = trunc i8 %1827 to i7
  %1829 = zext i7 %1828 to i575
  %1830 = load i8, ptr %80, align 1
  %1831 = trunc i8 %1830 to i7
  %1832 = zext i7 %1831 to i575
  %1833 = load i8, ptr %81, align 1
  %1834 = trunc i8 %1833 to i7
  %1835 = zext i7 %1834 to i575
  %1836 = load i8, ptr %82, align 1
  %1837 = trunc i8 %1836 to i7
  %1838 = zext i7 %1837 to i575
  %1839 = load i8, ptr %83, align 1
  %1840 = trunc i8 %1839 to i7
  %1841 = zext i7 %1840 to i575
  %1842 = load i8, ptr %84, align 1
  %1843 = trunc i8 %1842 to i7
  %1844 = zext i7 %1843 to i575
  %1845 = zext i575 %1825 to i576
  store i576 %1845, ptr %85, align 8
  %1846 = zext i575 %1829 to i576
  store i576 %1846, ptr %86, align 8
  %1847 = zext i575 %1832 to i576
  store i576 %1847, ptr %87, align 8
  %1848 = zext i575 %1835 to i576
  store i576 %1848, ptr %88, align 8
  %1849 = zext i575 %1838 to i576
  store i576 %1849, ptr %89, align 8
  %1850 = zext i575 %1841 to i576
  store i576 %1850, ptr %90, align 8
  %1851 = zext i575 %1844 to i576
  store i576 %1851, ptr %91, align 8
  call void @check(ptr noundef @.str.8, i32 noundef 7, ptr noundef byval([72 x i8]) align 8 %85, ptr noundef %1826, ptr noundef byval([72 x i8]) align 8 %86, ptr noundef byval([72 x i8]) align 8 %87, ptr noundef byval([72 x i8]) align 8 %88, ptr noundef byval([72 x i8]) align 8 %89, ptr noundef byval([72 x i8]) align 8 %90, ptr noundef byval([72 x i8]) align 8 %91)
  br label %1852

1852:                                             ; preds = %1745
  br label %1853

1853:                                             ; preds = %1852
  store i128 0, ptr %92, align 8
  %1854 = load i128, ptr %92, align 8
  %1855 = trunc i128 %1854 to i65
  %1856 = call i65 @llvm.ctlz.i65(i65 %1855, i1 false)
  %1857 = trunc i65 %1856 to i32
  store i32 %1857, ptr %93, align 4
  %1858 = getelementptr inbounds i32, ptr %93, i64 1
  %1859 = load i128, ptr %92, align 8
  %1860 = trunc i128 %1859 to i65
  %1861 = xor i65 %1860, -1
  %1862 = call i65 @llvm.ctlz.i65(i65 %1861, i1 false)
  %1863 = trunc i65 %1862 to i32
  store i32 %1863, ptr %1858, align 4
  %1864 = getelementptr inbounds i32, ptr %93, i64 2
  %1865 = load i128, ptr %92, align 8
  %1866 = trunc i128 %1865 to i65
  %1867 = call i65 @llvm.cttz.i65(i65 %1866, i1 false)
  %1868 = trunc i65 %1867 to i32
  store i32 %1868, ptr %1864, align 4
  %1869 = getelementptr inbounds i32, ptr %93, i64 3
  %1870 = load i128, ptr %92, align 8
  %1871 = trunc i128 %1870 to i65
  %1872 = xor i65 %1871, -1
  %1873 = call i65 @llvm.cttz.i65(i65 %1872, i1 false)
  %1874 = trunc i65 %1873 to i32
  store i32 %1874, ptr %1869, align 4
  %1875 = getelementptr inbounds i32, ptr %93, i64 4
  %1876 = load i128, ptr %92, align 8
  %1877 = trunc i128 %1876 to i65
  %1878 = xor i65 %1877, -1
  %1879 = call i65 @llvm.ctlz.i65(i65 %1878, i1 false)
  %1880 = add i65 %1879, 1
  %1881 = icmp eq i65 %1878, 0
  %1882 = select i1 %1881, i65 0, i65 %1880
  %1883 = trunc i65 %1882 to i32
  store i32 %1883, ptr %1875, align 4
  %1884 = getelementptr inbounds i32, ptr %93, i64 5
  %1885 = load i128, ptr %92, align 8
  %1886 = trunc i128 %1885 to i65
  %1887 = call i65 @llvm.ctlz.i65(i65 %1886, i1 false)
  %1888 = add i65 %1887, 1
  %1889 = icmp eq i65 %1886, 0
  %1890 = select i1 %1889, i65 0, i65 %1888
  %1891 = trunc i65 %1890 to i32
  store i32 %1891, ptr %1884, align 4
  %1892 = getelementptr inbounds i32, ptr %93, i64 6
  %1893 = load i128, ptr %92, align 8
  %1894 = trunc i128 %1893 to i65
  %1895 = xor i65 %1894, -1
  %1896 = call i65 @llvm.cttz.i65(i65 %1895, i1 false)
  %1897 = add i65 %1896, 1
  %1898 = icmp eq i65 %1895, 0
  %1899 = select i1 %1898, i65 0, i65 %1897
  %1900 = trunc i65 %1899 to i32
  store i32 %1900, ptr %1892, align 4
  %1901 = getelementptr inbounds i32, ptr %93, i64 7
  %1902 = load i128, ptr %92, align 8
  %1903 = trunc i128 %1902 to i65
  %1904 = call i65 @llvm.cttz.i65(i65 %1903, i1 false)
  %1905 = add i65 %1904, 1
  %1906 = icmp eq i65 %1903, 0
  %1907 = select i1 %1906, i65 0, i65 %1905
  %1908 = trunc i65 %1907 to i32
  store i32 %1908, ptr %1901, align 4
  %1909 = getelementptr inbounds i32, ptr %93, i64 8
  %1910 = load i128, ptr %92, align 8
  %1911 = trunc i128 %1910 to i65
  %1912 = call i65 @llvm.ctpop.i65(i65 %1911)
  %1913 = sub i65 65, %1912
  %1914 = trunc i65 %1913 to i32
  store i32 %1914, ptr %1909, align 4
  %1915 = getelementptr inbounds i32, ptr %93, i64 9
  %1916 = load i128, ptr %92, align 8
  %1917 = trunc i128 %1916 to i65
  %1918 = call i65 @llvm.ctpop.i65(i65 %1917)
  %1919 = trunc i65 %1918 to i32
  store i32 %1919, ptr %1915, align 4
  %1920 = getelementptr inbounds i32, ptr %93, i64 10
  %1921 = load i128, ptr %92, align 8
  %1922 = trunc i128 %1921 to i65
  %1923 = call i65 @llvm.ctpop.i65(i65 %1922)
  %1924 = icmp eq i65 %1923, 1
  %1925 = zext i1 %1924 to i32
  store i32 %1925, ptr %1920, align 4
  %1926 = getelementptr inbounds i32, ptr %93, i64 11
  %1927 = load i128, ptr %92, align 8
  %1928 = trunc i128 %1927 to i65
  %1929 = call i65 @llvm.ctlz.i65(i65 %1928, i1 false)
  %1930 = sub i65 65, %1929
  %1931 = trunc i65 %1930 to i32
  store i32 %1931, ptr %1926, align 4
  %1932 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 0
  %1933 = load i32, ptr %1932, align 16
  %1934 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 1
  %1935 = load i32, ptr %1934, align 4
  %1936 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 2
  %1937 = load i32, ptr %1936, align 8
  %1938 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 3
  %1939 = load i32, ptr %1938, align 4
  %1940 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 4
  %1941 = load i32, ptr %1940, align 16
  %1942 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 5
  %1943 = load i32, ptr %1942, align 4
  %1944 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 6
  %1945 = load i32, ptr %1944, align 8
  %1946 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 7
  %1947 = load i32, ptr %1946, align 4
  %1948 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 8
  %1949 = load i32, ptr %1948, align 16
  %1950 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 9
  %1951 = load i32, ptr %1950, align 4
  %1952 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 10
  %1953 = load i32, ptr %1952, align 8
  %1954 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 11
  %1955 = load i32, ptr %1954, align 4
  %1956 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef %1933, i32 noundef %1935, i32 noundef %1937, i32 noundef %1939, i32 noundef %1941, i32 noundef %1943, i32 noundef %1945, i32 noundef %1947, i32 noundef %1949, i32 noundef %1951, i32 noundef %1953, i32 noundef %1955)
  %1957 = load i128, ptr %92, align 8
  %1958 = trunc i128 %1957 to i65
  %1959 = call i65 @llvm.ctlz.i65(i65 %1958, i1 true)
  %1960 = sub i65 64, %1959
  %1961 = shl i65 1, %1960
  %1962 = icmp eq i65 %1958, 0
  %1963 = select i1 %1962, i65 0, i65 %1961
  %1964 = zext i65 %1963 to i128
  store i128 %1964, ptr %94, align 8
  %1965 = load i128, ptr %92, align 8
  %1966 = trunc i128 %1965 to i65
  %1967 = icmp ule i65 %1966, 1
  br i1 %1967, label %1973, label %1968

1968:                                             ; preds = %1853
  %1969 = sub i65 %1966, 1
  %1970 = call i65 @llvm.ctlz.i65(i65 %1969, i1 false)
  %1971 = sub i65 64, %1970
  %1972 = shl i65 2, %1971
  br label %1973

1973:                                             ; preds = %1968, %1853
  %1974 = phi i65 [ 1, %1853 ], [ %1972, %1968 ]
  %1975 = zext i65 %1974 to i128
  store i128 %1975, ptr %95, align 8
  %1976 = load i128, ptr %92, align 8
  %1977 = trunc i128 %1976 to i65
  %1978 = call i65 @llvm.fshl.i65(i65 %1977, i65 %1977, i65 3)
  %1979 = zext i65 %1978 to i128
  store i128 %1979, ptr %96, align 8
  %1980 = load i128, ptr %92, align 8
  %1981 = trunc i128 %1980 to i65
  %1982 = call i65 @llvm.fshr.i65(i65 %1981, i65 %1981, i65 3)
  %1983 = zext i65 %1982 to i128
  store i128 %1983, ptr %97, align 8
  %1984 = load i128, ptr %92, align 8
  %1985 = trunc i128 %1984 to i65
  %1986 = call i65 @llvm.fshl.i65(i65 %1985, i65 %1985, i65 0)
  %1987 = zext i65 %1986 to i128
  store i128 %1987, ptr %98, align 8
  %1988 = load i128, ptr %92, align 8
  %1989 = trunc i128 %1988 to i65
  %1990 = call i65 @llvm.fshl.i65(i65 %1989, i65 %1989, i65 25)
  %1991 = zext i65 %1990 to i128
  store i128 %1991, ptr %99, align 8
  %1992 = load i128, ptr %94, align 8
  %1993 = trunc i128 %1992 to i65
  %1994 = zext i65 %1993 to i256
  %1995 = lshr i256 %1994, 128
  %1996 = trunc i256 %1995 to i64
  %1997 = load i128, ptr %94, align 8
  %1998 = trunc i128 %1997 to i65
  %1999 = zext i65 %1998 to i256
  %2000 = lshr i256 %1999, 64
  %2001 = trunc i256 %2000 to i64
  %2002 = load i128, ptr %94, align 8
  %2003 = trunc i128 %2002 to i65
  %2004 = trunc i65 %2003 to i64
  %2005 = load i128, ptr %95, align 8
  %2006 = trunc i128 %2005 to i65
  %2007 = zext i65 %2006 to i256
  %2008 = lshr i256 %2007, 128
  %2009 = trunc i256 %2008 to i64
  %2010 = load i128, ptr %95, align 8
  %2011 = trunc i128 %2010 to i65
  %2012 = zext i65 %2011 to i256
  %2013 = lshr i256 %2012, 64
  %2014 = trunc i256 %2013 to i64
  %2015 = load i128, ptr %95, align 8
  %2016 = trunc i128 %2015 to i65
  %2017 = trunc i65 %2016 to i64
  %2018 = load i128, ptr %96, align 8
  %2019 = trunc i128 %2018 to i65
  %2020 = zext i65 %2019 to i256
  %2021 = lshr i256 %2020, 128
  %2022 = trunc i256 %2021 to i64
  %2023 = load i128, ptr %96, align 8
  %2024 = trunc i128 %2023 to i65
  %2025 = zext i65 %2024 to i256
  %2026 = lshr i256 %2025, 64
  %2027 = trunc i256 %2026 to i64
  %2028 = load i128, ptr %96, align 8
  %2029 = trunc i128 %2028 to i65
  %2030 = trunc i65 %2029 to i64
  %2031 = load i128, ptr %97, align 8
  %2032 = trunc i128 %2031 to i65
  %2033 = zext i65 %2032 to i256
  %2034 = lshr i256 %2033, 128
  %2035 = trunc i256 %2034 to i64
  %2036 = load i128, ptr %97, align 8
  %2037 = trunc i128 %2036 to i65
  %2038 = zext i65 %2037 to i256
  %2039 = lshr i256 %2038, 64
  %2040 = trunc i256 %2039 to i64
  %2041 = load i128, ptr %97, align 8
  %2042 = trunc i128 %2041 to i65
  %2043 = trunc i65 %2042 to i64
  %2044 = load i128, ptr %98, align 8
  %2045 = trunc i128 %2044 to i65
  %2046 = trunc i65 %2045 to i64
  %2047 = load i128, ptr %99, align 8
  %2048 = trunc i128 %2047 to i65
  %2049 = trunc i65 %2048 to i64
  %2050 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %1996, i64 noundef %2001, i64 noundef %2004, i64 noundef %2009, i64 noundef %2014, i64 noundef %2017, i64 noundef %2022, i64 noundef %2027, i64 noundef %2030, i64 noundef %2035, i64 noundef %2040, i64 noundef %2043, i64 noundef %2046, i64 noundef %2049)
  %2051 = load i128, ptr %92, align 8
  %2052 = trunc i128 %2051 to i65
  %2053 = zext i65 %2052 to i575
  %2054 = getelementptr inbounds [12 x i32], ptr %93, i64 0, i64 0
  %2055 = load i128, ptr %94, align 8
  %2056 = trunc i128 %2055 to i65
  %2057 = zext i65 %2056 to i575
  %2058 = load i128, ptr %95, align 8
  %2059 = trunc i128 %2058 to i65
  %2060 = zext i65 %2059 to i575
  %2061 = load i128, ptr %96, align 8
  %2062 = trunc i128 %2061 to i65
  %2063 = zext i65 %2062 to i575
  %2064 = load i128, ptr %97, align 8
  %2065 = trunc i128 %2064 to i65
  %2066 = zext i65 %2065 to i575
  %2067 = load i128, ptr %98, align 8
  %2068 = trunc i128 %2067 to i65
  %2069 = zext i65 %2068 to i575
  %2070 = load i128, ptr %99, align 8
  %2071 = trunc i128 %2070 to i65
  %2072 = zext i65 %2071 to i575
  %2073 = zext i575 %2053 to i576
  store i576 %2073, ptr %100, align 8
  %2074 = zext i575 %2057 to i576
  store i576 %2074, ptr %101, align 8
  %2075 = zext i575 %2060 to i576
  store i576 %2075, ptr %102, align 8
  %2076 = zext i575 %2063 to i576
  store i576 %2076, ptr %103, align 8
  %2077 = zext i575 %2066 to i576
  store i576 %2077, ptr %104, align 8
  %2078 = zext i575 %2069 to i576
  store i576 %2078, ptr %105, align 8
  %2079 = zext i575 %2072 to i576
  store i576 %2079, ptr %106, align 8
  call void @check(ptr noundef @.str.9, i32 noundef 65, ptr noundef byval([72 x i8]) align 8 %100, ptr noundef %2054, ptr noundef byval([72 x i8]) align 8 %101, ptr noundef byval([72 x i8]) align 8 %102, ptr noundef byval([72 x i8]) align 8 %103, ptr noundef byval([72 x i8]) align 8 %104, ptr noundef byval([72 x i8]) align 8 %105, ptr noundef byval([72 x i8]) align 8 %106)
  br label %2080

2080:                                             ; preds = %1973
  br label %2081

2081:                                             ; preds = %2080
  store i192 0, ptr %107, align 8
  %2082 = load i192, ptr %107, align 8
  %2083 = trunc i192 %2082 to i129
  %2084 = call i129 @llvm.ctlz.i129(i129 %2083, i1 false)
  %2085 = trunc i129 %2084 to i32
  store i32 %2085, ptr %108, align 4
  %2086 = getelementptr inbounds i32, ptr %108, i64 1
  %2087 = load i192, ptr %107, align 8
  %2088 = trunc i192 %2087 to i129
  %2089 = xor i129 %2088, -1
  %2090 = call i129 @llvm.ctlz.i129(i129 %2089, i1 false)
  %2091 = trunc i129 %2090 to i32
  store i32 %2091, ptr %2086, align 4
  %2092 = getelementptr inbounds i32, ptr %108, i64 2
  %2093 = load i192, ptr %107, align 8
  %2094 = trunc i192 %2093 to i129
  %2095 = call i129 @llvm.cttz.i129(i129 %2094, i1 false)
  %2096 = trunc i129 %2095 to i32
  store i32 %2096, ptr %2092, align 4
  %2097 = getelementptr inbounds i32, ptr %108, i64 3
  %2098 = load i192, ptr %107, align 8
  %2099 = trunc i192 %2098 to i129
  %2100 = xor i129 %2099, -1
  %2101 = call i129 @llvm.cttz.i129(i129 %2100, i1 false)
  %2102 = trunc i129 %2101 to i32
  store i32 %2102, ptr %2097, align 4
  %2103 = getelementptr inbounds i32, ptr %108, i64 4
  %2104 = load i192, ptr %107, align 8
  %2105 = trunc i192 %2104 to i129
  %2106 = xor i129 %2105, -1
  %2107 = call i129 @llvm.ctlz.i129(i129 %2106, i1 false)
  %2108 = add i129 %2107, 1
  %2109 = icmp eq i129 %2106, 0
  %2110 = select i1 %2109, i129 0, i129 %2108
  %2111 = trunc i129 %2110 to i32
  store i32 %2111, ptr %2103, align 4
  %2112 = getelementptr inbounds i32, ptr %108, i64 5
  %2113 = load i192, ptr %107, align 8
  %2114 = trunc i192 %2113 to i129
  %2115 = call i129 @llvm.ctlz.i129(i129 %2114, i1 false)
  %2116 = add i129 %2115, 1
  %2117 = icmp eq i129 %2114, 0
  %2118 = select i1 %2117, i129 0, i129 %2116
  %2119 = trunc i129 %2118 to i32
  store i32 %2119, ptr %2112, align 4
  %2120 = getelementptr inbounds i32, ptr %108, i64 6
  %2121 = load i192, ptr %107, align 8
  %2122 = trunc i192 %2121 to i129
  %2123 = xor i129 %2122, -1
  %2124 = call i129 @llvm.cttz.i129(i129 %2123, i1 false)
  %2125 = add i129 %2124, 1
  %2126 = icmp eq i129 %2123, 0
  %2127 = select i1 %2126, i129 0, i129 %2125
  %2128 = trunc i129 %2127 to i32
  store i32 %2128, ptr %2120, align 4
  %2129 = getelementptr inbounds i32, ptr %108, i64 7
  %2130 = load i192, ptr %107, align 8
  %2131 = trunc i192 %2130 to i129
  %2132 = call i129 @llvm.cttz.i129(i129 %2131, i1 false)
  %2133 = add i129 %2132, 1
  %2134 = icmp eq i129 %2131, 0
  %2135 = select i1 %2134, i129 0, i129 %2133
  %2136 = trunc i129 %2135 to i32
  store i32 %2136, ptr %2129, align 4
  %2137 = getelementptr inbounds i32, ptr %108, i64 8
  %2138 = load i192, ptr %107, align 8
  %2139 = trunc i192 %2138 to i129
  %2140 = call i129 @llvm.ctpop.i129(i129 %2139)
  %2141 = sub i129 129, %2140
  %2142 = trunc i129 %2141 to i32
  store i32 %2142, ptr %2137, align 4
  %2143 = getelementptr inbounds i32, ptr %108, i64 9
  %2144 = load i192, ptr %107, align 8
  %2145 = trunc i192 %2144 to i129
  %2146 = call i129 @llvm.ctpop.i129(i129 %2145)
  %2147 = trunc i129 %2146 to i32
  store i32 %2147, ptr %2143, align 4
  %2148 = getelementptr inbounds i32, ptr %108, i64 10
  %2149 = load i192, ptr %107, align 8
  %2150 = trunc i192 %2149 to i129
  %2151 = call i129 @llvm.ctpop.i129(i129 %2150)
  %2152 = icmp eq i129 %2151, 1
  %2153 = zext i1 %2152 to i32
  store i32 %2153, ptr %2148, align 4
  %2154 = getelementptr inbounds i32, ptr %108, i64 11
  %2155 = load i192, ptr %107, align 8
  %2156 = trunc i192 %2155 to i129
  %2157 = call i129 @llvm.ctlz.i129(i129 %2156, i1 false)
  %2158 = sub i129 129, %2157
  %2159 = trunc i129 %2158 to i32
  store i32 %2159, ptr %2154, align 4
  %2160 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 0
  %2161 = load i32, ptr %2160, align 16
  %2162 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 1
  %2163 = load i32, ptr %2162, align 4
  %2164 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 2
  %2165 = load i32, ptr %2164, align 8
  %2166 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 3
  %2167 = load i32, ptr %2166, align 4
  %2168 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 4
  %2169 = load i32, ptr %2168, align 16
  %2170 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 5
  %2171 = load i32, ptr %2170, align 4
  %2172 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 6
  %2173 = load i32, ptr %2172, align 8
  %2174 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 7
  %2175 = load i32, ptr %2174, align 4
  %2176 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 8
  %2177 = load i32, ptr %2176, align 16
  %2178 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 9
  %2179 = load i32, ptr %2178, align 4
  %2180 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 10
  %2181 = load i32, ptr %2180, align 8
  %2182 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 11
  %2183 = load i32, ptr %2182, align 4
  %2184 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %2161, i32 noundef %2163, i32 noundef %2165, i32 noundef %2167, i32 noundef %2169, i32 noundef %2171, i32 noundef %2173, i32 noundef %2175, i32 noundef %2177, i32 noundef %2179, i32 noundef %2181, i32 noundef %2183)
  %2185 = load i192, ptr %107, align 8
  %2186 = trunc i192 %2185 to i129
  %2187 = call i129 @llvm.ctlz.i129(i129 %2186, i1 true)
  %2188 = sub i129 128, %2187
  %2189 = shl i129 1, %2188
  %2190 = icmp eq i129 %2186, 0
  %2191 = select i1 %2190, i129 0, i129 %2189
  %2192 = zext i129 %2191 to i192
  store i192 %2192, ptr %109, align 8
  %2193 = load i192, ptr %107, align 8
  %2194 = trunc i192 %2193 to i129
  %2195 = icmp ule i129 %2194, 1
  br i1 %2195, label %2201, label %2196

2196:                                             ; preds = %2081
  %2197 = sub i129 %2194, 1
  %2198 = call i129 @llvm.ctlz.i129(i129 %2197, i1 false)
  %2199 = sub i129 128, %2198
  %2200 = shl i129 2, %2199
  br label %2201

2201:                                             ; preds = %2196, %2081
  %2202 = phi i129 [ 1, %2081 ], [ %2200, %2196 ]
  %2203 = zext i129 %2202 to i192
  store i192 %2203, ptr %110, align 8
  %2204 = load i192, ptr %107, align 8
  %2205 = trunc i192 %2204 to i129
  %2206 = call i129 @llvm.fshl.i129(i129 %2205, i129 %2205, i129 3)
  %2207 = zext i129 %2206 to i192
  store i192 %2207, ptr %111, align 8
  %2208 = load i192, ptr %107, align 8
  %2209 = trunc i192 %2208 to i129
  %2210 = call i129 @llvm.fshr.i129(i129 %2209, i129 %2209, i129 3)
  %2211 = zext i129 %2210 to i192
  store i192 %2211, ptr %112, align 8
  %2212 = load i192, ptr %107, align 8
  %2213 = trunc i192 %2212 to i129
  %2214 = call i129 @llvm.fshl.i129(i129 %2213, i129 %2213, i129 0)
  %2215 = zext i129 %2214 to i192
  store i192 %2215, ptr %113, align 8
  %2216 = load i192, ptr %107, align 8
  %2217 = trunc i192 %2216 to i129
  %2218 = call i129 @llvm.fshl.i129(i129 %2217, i129 %2217, i129 97)
  %2219 = zext i129 %2218 to i192
  store i192 %2219, ptr %114, align 8
  %2220 = load i192, ptr %109, align 8
  %2221 = trunc i192 %2220 to i129
  %2222 = zext i129 %2221 to i256
  %2223 = lshr i256 %2222, 128
  %2224 = trunc i256 %2223 to i64
  %2225 = load i192, ptr %109, align 8
  %2226 = trunc i192 %2225 to i129
  %2227 = zext i129 %2226 to i256
  %2228 = lshr i256 %2227, 64
  %2229 = trunc i256 %2228 to i64
  %2230 = load i192, ptr %109, align 8
  %2231 = trunc i192 %2230 to i129
  %2232 = trunc i129 %2231 to i64
  %2233 = load i192, ptr %110, align 8
  %2234 = trunc i192 %2233 to i129
  %2235 = zext i129 %2234 to i256
  %2236 = lshr i256 %2235, 128
  %2237 = trunc i256 %2236 to i64
  %2238 = load i192, ptr %110, align 8
  %2239 = trunc i192 %2238 to i129
  %2240 = zext i129 %2239 to i256
  %2241 = lshr i256 %2240, 64
  %2242 = trunc i256 %2241 to i64
  %2243 = load i192, ptr %110, align 8
  %2244 = trunc i192 %2243 to i129
  %2245 = trunc i129 %2244 to i64
  %2246 = load i192, ptr %111, align 8
  %2247 = trunc i192 %2246 to i129
  %2248 = zext i129 %2247 to i256
  %2249 = lshr i256 %2248, 128
  %2250 = trunc i256 %2249 to i64
  %2251 = load i192, ptr %111, align 8
  %2252 = trunc i192 %2251 to i129
  %2253 = zext i129 %2252 to i256
  %2254 = lshr i256 %2253, 64
  %2255 = trunc i256 %2254 to i64
  %2256 = load i192, ptr %111, align 8
  %2257 = trunc i192 %2256 to i129
  %2258 = trunc i129 %2257 to i64
  %2259 = load i192, ptr %112, align 8
  %2260 = trunc i192 %2259 to i129
  %2261 = zext i129 %2260 to i256
  %2262 = lshr i256 %2261, 128
  %2263 = trunc i256 %2262 to i64
  %2264 = load i192, ptr %112, align 8
  %2265 = trunc i192 %2264 to i129
  %2266 = zext i129 %2265 to i256
  %2267 = lshr i256 %2266, 64
  %2268 = trunc i256 %2267 to i64
  %2269 = load i192, ptr %112, align 8
  %2270 = trunc i192 %2269 to i129
  %2271 = trunc i129 %2270 to i64
  %2272 = load i192, ptr %113, align 8
  %2273 = trunc i192 %2272 to i129
  %2274 = trunc i129 %2273 to i64
  %2275 = load i192, ptr %114, align 8
  %2276 = trunc i192 %2275 to i129
  %2277 = trunc i129 %2276 to i64
  %2278 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %2224, i64 noundef %2229, i64 noundef %2232, i64 noundef %2237, i64 noundef %2242, i64 noundef %2245, i64 noundef %2250, i64 noundef %2255, i64 noundef %2258, i64 noundef %2263, i64 noundef %2268, i64 noundef %2271, i64 noundef %2274, i64 noundef %2277)
  %2279 = load i192, ptr %107, align 8
  %2280 = trunc i192 %2279 to i129
  %2281 = zext i129 %2280 to i575
  %2282 = getelementptr inbounds [12 x i32], ptr %108, i64 0, i64 0
  %2283 = load i192, ptr %109, align 8
  %2284 = trunc i192 %2283 to i129
  %2285 = zext i129 %2284 to i575
  %2286 = load i192, ptr %110, align 8
  %2287 = trunc i192 %2286 to i129
  %2288 = zext i129 %2287 to i575
  %2289 = load i192, ptr %111, align 8
  %2290 = trunc i192 %2289 to i129
  %2291 = zext i129 %2290 to i575
  %2292 = load i192, ptr %112, align 8
  %2293 = trunc i192 %2292 to i129
  %2294 = zext i129 %2293 to i575
  %2295 = load i192, ptr %113, align 8
  %2296 = trunc i192 %2295 to i129
  %2297 = zext i129 %2296 to i575
  %2298 = load i192, ptr %114, align 8
  %2299 = trunc i192 %2298 to i129
  %2300 = zext i129 %2299 to i575
  %2301 = zext i575 %2281 to i576
  store i576 %2301, ptr %115, align 8
  %2302 = zext i575 %2285 to i576
  store i576 %2302, ptr %116, align 8
  %2303 = zext i575 %2288 to i576
  store i576 %2303, ptr %117, align 8
  %2304 = zext i575 %2291 to i576
  store i576 %2304, ptr %118, align 8
  %2305 = zext i575 %2294 to i576
  store i576 %2305, ptr %119, align 8
  %2306 = zext i575 %2297 to i576
  store i576 %2306, ptr %120, align 8
  %2307 = zext i575 %2300 to i576
  store i576 %2307, ptr %121, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %115, ptr noundef %2282, ptr noundef byval([72 x i8]) align 8 %116, ptr noundef byval([72 x i8]) align 8 %117, ptr noundef byval([72 x i8]) align 8 %118, ptr noundef byval([72 x i8]) align 8 %119, ptr noundef byval([72 x i8]) align 8 %120, ptr noundef byval([72 x i8]) align 8 %121)
  br label %2308

2308:                                             ; preds = %2201
  br label %2309

2309:                                             ; preds = %2308
  store i256 0, ptr %122, align 8
  %2310 = load i256, ptr %122, align 8
  %2311 = call i256 @llvm.ctlz.i256(i256 %2310, i1 false)
  %2312 = trunc i256 %2311 to i32
  store i32 %2312, ptr %123, align 4
  %2313 = getelementptr inbounds i32, ptr %123, i64 1
  %2314 = load i256, ptr %122, align 8
  %2315 = xor i256 %2314, -1
  %2316 = call i256 @llvm.ctlz.i256(i256 %2315, i1 false)
  %2317 = trunc i256 %2316 to i32
  store i32 %2317, ptr %2313, align 4
  %2318 = getelementptr inbounds i32, ptr %123, i64 2
  %2319 = load i256, ptr %122, align 8
  %2320 = call i256 @llvm.cttz.i256(i256 %2319, i1 false)
  %2321 = trunc i256 %2320 to i32
  store i32 %2321, ptr %2318, align 4
  %2322 = getelementptr inbounds i32, ptr %123, i64 3
  %2323 = load i256, ptr %122, align 8
  %2324 = xor i256 %2323, -1
  %2325 = call i256 @llvm.cttz.i256(i256 %2324, i1 false)
  %2326 = trunc i256 %2325 to i32
  store i32 %2326, ptr %2322, align 4
  %2327 = getelementptr inbounds i32, ptr %123, i64 4
  %2328 = load i256, ptr %122, align 8
  %2329 = xor i256 %2328, -1
  %2330 = call i256 @llvm.ctlz.i256(i256 %2329, i1 false)
  %2331 = add i256 %2330, 1
  %2332 = icmp eq i256 %2329, 0
  %2333 = select i1 %2332, i256 0, i256 %2331
  %2334 = trunc i256 %2333 to i32
  store i32 %2334, ptr %2327, align 4
  %2335 = getelementptr inbounds i32, ptr %123, i64 5
  %2336 = load i256, ptr %122, align 8
  %2337 = call i256 @llvm.ctlz.i256(i256 %2336, i1 false)
  %2338 = add i256 %2337, 1
  %2339 = icmp eq i256 %2336, 0
  %2340 = select i1 %2339, i256 0, i256 %2338
  %2341 = trunc i256 %2340 to i32
  store i32 %2341, ptr %2335, align 4
  %2342 = getelementptr inbounds i32, ptr %123, i64 6
  %2343 = load i256, ptr %122, align 8
  %2344 = xor i256 %2343, -1
  %2345 = call i256 @llvm.cttz.i256(i256 %2344, i1 false)
  %2346 = add i256 %2345, 1
  %2347 = icmp eq i256 %2344, 0
  %2348 = select i1 %2347, i256 0, i256 %2346
  %2349 = trunc i256 %2348 to i32
  store i32 %2349, ptr %2342, align 4
  %2350 = getelementptr inbounds i32, ptr %123, i64 7
  %2351 = load i256, ptr %122, align 8
  %2352 = call i256 @llvm.cttz.i256(i256 %2351, i1 false)
  %2353 = add i256 %2352, 1
  %2354 = icmp eq i256 %2351, 0
  %2355 = select i1 %2354, i256 0, i256 %2353
  %2356 = trunc i256 %2355 to i32
  store i32 %2356, ptr %2350, align 4
  %2357 = getelementptr inbounds i32, ptr %123, i64 8
  %2358 = load i256, ptr %122, align 8
  %2359 = call i256 @llvm.ctpop.i256(i256 %2358)
  %2360 = sub i256 256, %2359
  %2361 = trunc i256 %2360 to i32
  store i32 %2361, ptr %2357, align 4
  %2362 = getelementptr inbounds i32, ptr %123, i64 9
  %2363 = load i256, ptr %122, align 8
  %2364 = call i256 @llvm.ctpop.i256(i256 %2363)
  %2365 = trunc i256 %2364 to i32
  store i32 %2365, ptr %2362, align 4
  %2366 = getelementptr inbounds i32, ptr %123, i64 10
  %2367 = load i256, ptr %122, align 8
  %2368 = call i256 @llvm.ctpop.i256(i256 %2367)
  %2369 = icmp eq i256 %2368, 1
  %2370 = zext i1 %2369 to i32
  store i32 %2370, ptr %2366, align 4
  %2371 = getelementptr inbounds i32, ptr %123, i64 11
  %2372 = load i256, ptr %122, align 8
  %2373 = call i256 @llvm.ctlz.i256(i256 %2372, i1 false)
  %2374 = sub i256 256, %2373
  %2375 = trunc i256 %2374 to i32
  store i32 %2375, ptr %2371, align 4
  %2376 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 0
  %2377 = load i32, ptr %2376, align 16
  %2378 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 1
  %2379 = load i32, ptr %2378, align 4
  %2380 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 2
  %2381 = load i32, ptr %2380, align 8
  %2382 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 3
  %2383 = load i32, ptr %2382, align 4
  %2384 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 4
  %2385 = load i32, ptr %2384, align 16
  %2386 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 5
  %2387 = load i32, ptr %2386, align 4
  %2388 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 6
  %2389 = load i32, ptr %2388, align 8
  %2390 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 7
  %2391 = load i32, ptr %2390, align 4
  %2392 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 8
  %2393 = load i32, ptr %2392, align 16
  %2394 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 9
  %2395 = load i32, ptr %2394, align 4
  %2396 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 10
  %2397 = load i32, ptr %2396, align 8
  %2398 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 11
  %2399 = load i32, ptr %2398, align 4
  %2400 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %2377, i32 noundef %2379, i32 noundef %2381, i32 noundef %2383, i32 noundef %2385, i32 noundef %2387, i32 noundef %2389, i32 noundef %2391, i32 noundef %2393, i32 noundef %2395, i32 noundef %2397, i32 noundef %2399)
  %2401 = load i256, ptr %122, align 8
  %2402 = call i256 @llvm.ctlz.i256(i256 %2401, i1 true)
  %2403 = sub i256 255, %2402
  %2404 = shl i256 1, %2403
  %2405 = icmp eq i256 %2401, 0
  %2406 = select i1 %2405, i256 0, i256 %2404
  store i256 %2406, ptr %124, align 8
  %2407 = load i256, ptr %122, align 8
  %2408 = icmp ule i256 %2407, 1
  br i1 %2408, label %2414, label %2409

2409:                                             ; preds = %2309
  %2410 = sub i256 %2407, 1
  %2411 = call i256 @llvm.ctlz.i256(i256 %2410, i1 false)
  %2412 = sub i256 255, %2411
  %2413 = shl i256 2, %2412
  br label %2414

2414:                                             ; preds = %2409, %2309
  %2415 = phi i256 [ 1, %2309 ], [ %2413, %2409 ]
  store i256 %2415, ptr %125, align 8
  %2416 = load i256, ptr %122, align 8
  %2417 = call i256 @llvm.fshl.i256(i256 %2416, i256 %2416, i256 3)
  store i256 %2417, ptr %126, align 8
  %2418 = load i256, ptr %122, align 8
  %2419 = call i256 @llvm.fshr.i256(i256 %2418, i256 %2418, i256 3)
  store i256 %2419, ptr %127, align 8
  %2420 = load i256, ptr %122, align 8
  %2421 = call i256 @llvm.fshl.i256(i256 %2420, i256 %2420, i256 0)
  store i256 %2421, ptr %128, align 8
  %2422 = load i256, ptr %122, align 8
  %2423 = call i256 @llvm.fshl.i256(i256 %2422, i256 %2422, i256 232)
  store i256 %2423, ptr %129, align 8
  %2424 = load i256, ptr %124, align 8
  %2425 = lshr i256 %2424, 128
  %2426 = trunc i256 %2425 to i64
  %2427 = load i256, ptr %124, align 8
  %2428 = lshr i256 %2427, 64
  %2429 = trunc i256 %2428 to i64
  %2430 = load i256, ptr %124, align 8
  %2431 = trunc i256 %2430 to i64
  %2432 = load i256, ptr %125, align 8
  %2433 = lshr i256 %2432, 128
  %2434 = trunc i256 %2433 to i64
  %2435 = load i256, ptr %125, align 8
  %2436 = lshr i256 %2435, 64
  %2437 = trunc i256 %2436 to i64
  %2438 = load i256, ptr %125, align 8
  %2439 = trunc i256 %2438 to i64
  %2440 = load i256, ptr %126, align 8
  %2441 = lshr i256 %2440, 128
  %2442 = trunc i256 %2441 to i64
  %2443 = load i256, ptr %126, align 8
  %2444 = lshr i256 %2443, 64
  %2445 = trunc i256 %2444 to i64
  %2446 = load i256, ptr %126, align 8
  %2447 = trunc i256 %2446 to i64
  %2448 = load i256, ptr %127, align 8
  %2449 = lshr i256 %2448, 128
  %2450 = trunc i256 %2449 to i64
  %2451 = load i256, ptr %127, align 8
  %2452 = lshr i256 %2451, 64
  %2453 = trunc i256 %2452 to i64
  %2454 = load i256, ptr %127, align 8
  %2455 = trunc i256 %2454 to i64
  %2456 = load i256, ptr %128, align 8
  %2457 = trunc i256 %2456 to i64
  %2458 = load i256, ptr %129, align 8
  %2459 = trunc i256 %2458 to i64
  %2460 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %2426, i64 noundef %2429, i64 noundef %2431, i64 noundef %2434, i64 noundef %2437, i64 noundef %2439, i64 noundef %2442, i64 noundef %2445, i64 noundef %2447, i64 noundef %2450, i64 noundef %2453, i64 noundef %2455, i64 noundef %2457, i64 noundef %2459)
  %2461 = load i256, ptr %122, align 8
  %2462 = zext i256 %2461 to i575
  %2463 = getelementptr inbounds [12 x i32], ptr %123, i64 0, i64 0
  %2464 = load i256, ptr %124, align 8
  %2465 = zext i256 %2464 to i575
  %2466 = load i256, ptr %125, align 8
  %2467 = zext i256 %2466 to i575
  %2468 = load i256, ptr %126, align 8
  %2469 = zext i256 %2468 to i575
  %2470 = load i256, ptr %127, align 8
  %2471 = zext i256 %2470 to i575
  %2472 = load i256, ptr %128, align 8
  %2473 = zext i256 %2472 to i575
  %2474 = load i256, ptr %129, align 8
  %2475 = zext i256 %2474 to i575
  %2476 = zext i575 %2462 to i576
  store i576 %2476, ptr %130, align 8
  %2477 = zext i575 %2465 to i576
  store i576 %2477, ptr %131, align 8
  %2478 = zext i575 %2467 to i576
  store i576 %2478, ptr %132, align 8
  %2479 = zext i575 %2469 to i576
  store i576 %2479, ptr %133, align 8
  %2480 = zext i575 %2471 to i576
  store i576 %2480, ptr %134, align 8
  %2481 = zext i575 %2473 to i576
  store i576 %2481, ptr %135, align 8
  %2482 = zext i575 %2475 to i576
  store i576 %2482, ptr %136, align 8
  call void @check(ptr noundef @.str.11, i32 noundef 256, ptr noundef byval([72 x i8]) align 8 %130, ptr noundef %2463, ptr noundef byval([72 x i8]) align 8 %131, ptr noundef byval([72 x i8]) align 8 %132, ptr noundef byval([72 x i8]) align 8 %133, ptr noundef byval([72 x i8]) align 8 %134, ptr noundef byval([72 x i8]) align 8 %135, ptr noundef byval([72 x i8]) align 8 %136)
  br label %2483

2483:                                             ; preds = %2414
  %2484 = call i32 @puts(ptr noundef @.str.12)
  br label %2485

2485:                                             ; preds = %2483
  store i8 1, ptr %137, align 1
  %2486 = load i8, ptr %137, align 1
  %2487 = call i8 @llvm.ctlz.i8(i8 %2486, i1 false)
  %2488 = zext i8 %2487 to i32
  store i32 %2488, ptr %138, align 4
  %2489 = getelementptr inbounds i32, ptr %138, i64 1
  %2490 = load i8, ptr %137, align 1
  %2491 = xor i8 %2490, -1
  %2492 = call i8 @llvm.ctlz.i8(i8 %2491, i1 false)
  %2493 = zext i8 %2492 to i32
  store i32 %2493, ptr %2489, align 4
  %2494 = getelementptr inbounds i32, ptr %138, i64 2
  %2495 = load i8, ptr %137, align 1
  %2496 = call i8 @llvm.cttz.i8(i8 %2495, i1 false)
  %2497 = zext i8 %2496 to i32
  store i32 %2497, ptr %2494, align 4
  %2498 = getelementptr inbounds i32, ptr %138, i64 3
  %2499 = load i8, ptr %137, align 1
  %2500 = xor i8 %2499, -1
  %2501 = call i8 @llvm.cttz.i8(i8 %2500, i1 false)
  %2502 = zext i8 %2501 to i32
  store i32 %2502, ptr %2498, align 4
  %2503 = getelementptr inbounds i32, ptr %138, i64 4
  %2504 = load i8, ptr %137, align 1
  %2505 = xor i8 %2504, -1
  %2506 = call i8 @llvm.ctlz.i8(i8 %2505, i1 false)
  %2507 = add i8 %2506, 1
  %2508 = icmp eq i8 %2505, 0
  %2509 = select i1 %2508, i8 0, i8 %2507
  %2510 = zext i8 %2509 to i32
  store i32 %2510, ptr %2503, align 4
  %2511 = getelementptr inbounds i32, ptr %138, i64 5
  %2512 = load i8, ptr %137, align 1
  %2513 = call i8 @llvm.ctlz.i8(i8 %2512, i1 false)
  %2514 = add i8 %2513, 1
  %2515 = icmp eq i8 %2512, 0
  %2516 = select i1 %2515, i8 0, i8 %2514
  %2517 = zext i8 %2516 to i32
  store i32 %2517, ptr %2511, align 4
  %2518 = getelementptr inbounds i32, ptr %138, i64 6
  %2519 = load i8, ptr %137, align 1
  %2520 = xor i8 %2519, -1
  %2521 = call i8 @llvm.cttz.i8(i8 %2520, i1 false)
  %2522 = add i8 %2521, 1
  %2523 = icmp eq i8 %2520, 0
  %2524 = select i1 %2523, i8 0, i8 %2522
  %2525 = zext i8 %2524 to i32
  store i32 %2525, ptr %2518, align 4
  %2526 = getelementptr inbounds i32, ptr %138, i64 7
  %2527 = load i8, ptr %137, align 1
  %2528 = call i8 @llvm.cttz.i8(i8 %2527, i1 false)
  %2529 = add i8 %2528, 1
  %2530 = icmp eq i8 %2527, 0
  %2531 = select i1 %2530, i8 0, i8 %2529
  %2532 = zext i8 %2531 to i32
  store i32 %2532, ptr %2526, align 4
  %2533 = getelementptr inbounds i32, ptr %138, i64 8
  %2534 = load i8, ptr %137, align 1
  %2535 = call i8 @llvm.ctpop.i8(i8 %2534)
  %2536 = sub i8 8, %2535
  %2537 = zext i8 %2536 to i32
  store i32 %2537, ptr %2533, align 4
  %2538 = getelementptr inbounds i32, ptr %138, i64 9
  %2539 = load i8, ptr %137, align 1
  %2540 = call i8 @llvm.ctpop.i8(i8 %2539)
  %2541 = zext i8 %2540 to i32
  store i32 %2541, ptr %2538, align 4
  %2542 = getelementptr inbounds i32, ptr %138, i64 10
  %2543 = load i8, ptr %137, align 1
  %2544 = call i8 @llvm.ctpop.i8(i8 %2543)
  %2545 = icmp eq i8 %2544, 1
  %2546 = zext i1 %2545 to i32
  store i32 %2546, ptr %2542, align 4
  %2547 = getelementptr inbounds i32, ptr %138, i64 11
  %2548 = load i8, ptr %137, align 1
  %2549 = call i8 @llvm.ctlz.i8(i8 %2548, i1 false)
  %2550 = sub i8 8, %2549
  %2551 = zext i8 %2550 to i32
  store i32 %2551, ptr %2547, align 4
  %2552 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 0
  %2553 = load i32, ptr %2552, align 16
  %2554 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 1
  %2555 = load i32, ptr %2554, align 4
  %2556 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 2
  %2557 = load i32, ptr %2556, align 8
  %2558 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 3
  %2559 = load i32, ptr %2558, align 4
  %2560 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 4
  %2561 = load i32, ptr %2560, align 16
  %2562 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 5
  %2563 = load i32, ptr %2562, align 4
  %2564 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 6
  %2565 = load i32, ptr %2564, align 8
  %2566 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 7
  %2567 = load i32, ptr %2566, align 4
  %2568 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 8
  %2569 = load i32, ptr %2568, align 16
  %2570 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 9
  %2571 = load i32, ptr %2570, align 4
  %2572 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 10
  %2573 = load i32, ptr %2572, align 8
  %2574 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 11
  %2575 = load i32, ptr %2574, align 4
  %2576 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %2553, i32 noundef %2555, i32 noundef %2557, i32 noundef %2559, i32 noundef %2561, i32 noundef %2563, i32 noundef %2565, i32 noundef %2567, i32 noundef %2569, i32 noundef %2571, i32 noundef %2573, i32 noundef %2575)
  %2577 = load i8, ptr %137, align 1
  %2578 = call i8 @llvm.ctlz.i8(i8 %2577, i1 true)
  %2579 = sub i8 7, %2578
  %2580 = shl i8 1, %2579
  %2581 = icmp eq i8 %2577, 0
  %2582 = select i1 %2581, i8 0, i8 %2580
  store i8 %2582, ptr %139, align 1
  %2583 = load i8, ptr %137, align 1
  %2584 = icmp ule i8 %2583, 1
  br i1 %2584, label %2590, label %2585

2585:                                             ; preds = %2485
  %2586 = sub i8 %2583, 1
  %2587 = call i8 @llvm.ctlz.i8(i8 %2586, i1 false)
  %2588 = sub i8 7, %2587
  %2589 = shl i8 2, %2588
  br label %2590

2590:                                             ; preds = %2585, %2485
  %2591 = phi i8 [ 1, %2485 ], [ %2589, %2585 ]
  store i8 %2591, ptr %140, align 1
  %2592 = load i8, ptr %137, align 1
  %2593 = call i8 @llvm.fshl.i8(i8 %2592, i8 %2592, i8 3)
  store i8 %2593, ptr %141, align 1
  %2594 = load i8, ptr %137, align 1
  %2595 = call i8 @llvm.fshr.i8(i8 %2594, i8 %2594, i8 3)
  store i8 %2595, ptr %142, align 1
  %2596 = load i8, ptr %137, align 1
  %2597 = call i8 @llvm.fshl.i8(i8 %2596, i8 %2596, i8 0)
  store i8 %2597, ptr %143, align 1
  %2598 = load i8, ptr %137, align 1
  %2599 = call i8 @llvm.fshl.i8(i8 %2598, i8 %2598, i8 0)
  store i8 %2599, ptr %144, align 1
  %2600 = load i8, ptr %139, align 1
  %2601 = zext i8 %2600 to i256
  %2602 = lshr i256 %2601, 128
  %2603 = trunc i256 %2602 to i64
  %2604 = load i8, ptr %139, align 1
  %2605 = zext i8 %2604 to i256
  %2606 = lshr i256 %2605, 64
  %2607 = trunc i256 %2606 to i64
  %2608 = load i8, ptr %139, align 1
  %2609 = zext i8 %2608 to i64
  %2610 = load i8, ptr %140, align 1
  %2611 = zext i8 %2610 to i256
  %2612 = lshr i256 %2611, 128
  %2613 = trunc i256 %2612 to i64
  %2614 = load i8, ptr %140, align 1
  %2615 = zext i8 %2614 to i256
  %2616 = lshr i256 %2615, 64
  %2617 = trunc i256 %2616 to i64
  %2618 = load i8, ptr %140, align 1
  %2619 = zext i8 %2618 to i64
  %2620 = load i8, ptr %141, align 1
  %2621 = zext i8 %2620 to i256
  %2622 = lshr i256 %2621, 128
  %2623 = trunc i256 %2622 to i64
  %2624 = load i8, ptr %141, align 1
  %2625 = zext i8 %2624 to i256
  %2626 = lshr i256 %2625, 64
  %2627 = trunc i256 %2626 to i64
  %2628 = load i8, ptr %141, align 1
  %2629 = zext i8 %2628 to i64
  %2630 = load i8, ptr %142, align 1
  %2631 = zext i8 %2630 to i256
  %2632 = lshr i256 %2631, 128
  %2633 = trunc i256 %2632 to i64
  %2634 = load i8, ptr %142, align 1
  %2635 = zext i8 %2634 to i256
  %2636 = lshr i256 %2635, 64
  %2637 = trunc i256 %2636 to i64
  %2638 = load i8, ptr %142, align 1
  %2639 = zext i8 %2638 to i64
  %2640 = load i8, ptr %143, align 1
  %2641 = zext i8 %2640 to i64
  %2642 = load i8, ptr %144, align 1
  %2643 = zext i8 %2642 to i64
  %2644 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %2603, i64 noundef %2607, i64 noundef %2609, i64 noundef %2613, i64 noundef %2617, i64 noundef %2619, i64 noundef %2623, i64 noundef %2627, i64 noundef %2629, i64 noundef %2633, i64 noundef %2637, i64 noundef %2639, i64 noundef %2641, i64 noundef %2643)
  %2645 = load i8, ptr %137, align 1
  %2646 = zext i8 %2645 to i575
  %2647 = getelementptr inbounds [12 x i32], ptr %138, i64 0, i64 0
  %2648 = load i8, ptr %139, align 1
  %2649 = zext i8 %2648 to i575
  %2650 = load i8, ptr %140, align 1
  %2651 = zext i8 %2650 to i575
  %2652 = load i8, ptr %141, align 1
  %2653 = zext i8 %2652 to i575
  %2654 = load i8, ptr %142, align 1
  %2655 = zext i8 %2654 to i575
  %2656 = load i8, ptr %143, align 1
  %2657 = zext i8 %2656 to i575
  %2658 = load i8, ptr %144, align 1
  %2659 = zext i8 %2658 to i575
  %2660 = zext i575 %2646 to i576
  store i576 %2660, ptr %145, align 8
  %2661 = zext i575 %2649 to i576
  store i576 %2661, ptr %146, align 8
  %2662 = zext i575 %2651 to i576
  store i576 %2662, ptr %147, align 8
  %2663 = zext i575 %2653 to i576
  store i576 %2663, ptr %148, align 8
  %2664 = zext i575 %2655 to i576
  store i576 %2664, ptr %149, align 8
  %2665 = zext i575 %2657 to i576
  store i576 %2665, ptr %150, align 8
  %2666 = zext i575 %2659 to i576
  store i576 %2666, ptr %151, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %145, ptr noundef %2647, ptr noundef byval([72 x i8]) align 8 %146, ptr noundef byval([72 x i8]) align 8 %147, ptr noundef byval([72 x i8]) align 8 %148, ptr noundef byval([72 x i8]) align 8 %149, ptr noundef byval([72 x i8]) align 8 %150, ptr noundef byval([72 x i8]) align 8 %151)
  br label %2667

2667:                                             ; preds = %2590
  br label %2668

2668:                                             ; preds = %2667
  store i16 1, ptr %152, align 2
  %2669 = load i16, ptr %152, align 2
  %2670 = call i16 @llvm.ctlz.i16(i16 %2669, i1 false)
  %2671 = zext i16 %2670 to i32
  store i32 %2671, ptr %153, align 4
  %2672 = getelementptr inbounds i32, ptr %153, i64 1
  %2673 = load i16, ptr %152, align 2
  %2674 = xor i16 %2673, -1
  %2675 = call i16 @llvm.ctlz.i16(i16 %2674, i1 false)
  %2676 = zext i16 %2675 to i32
  store i32 %2676, ptr %2672, align 4
  %2677 = getelementptr inbounds i32, ptr %153, i64 2
  %2678 = load i16, ptr %152, align 2
  %2679 = call i16 @llvm.cttz.i16(i16 %2678, i1 false)
  %2680 = zext i16 %2679 to i32
  store i32 %2680, ptr %2677, align 4
  %2681 = getelementptr inbounds i32, ptr %153, i64 3
  %2682 = load i16, ptr %152, align 2
  %2683 = xor i16 %2682, -1
  %2684 = call i16 @llvm.cttz.i16(i16 %2683, i1 false)
  %2685 = zext i16 %2684 to i32
  store i32 %2685, ptr %2681, align 4
  %2686 = getelementptr inbounds i32, ptr %153, i64 4
  %2687 = load i16, ptr %152, align 2
  %2688 = xor i16 %2687, -1
  %2689 = call i16 @llvm.ctlz.i16(i16 %2688, i1 false)
  %2690 = add i16 %2689, 1
  %2691 = icmp eq i16 %2688, 0
  %2692 = select i1 %2691, i16 0, i16 %2690
  %2693 = zext i16 %2692 to i32
  store i32 %2693, ptr %2686, align 4
  %2694 = getelementptr inbounds i32, ptr %153, i64 5
  %2695 = load i16, ptr %152, align 2
  %2696 = call i16 @llvm.ctlz.i16(i16 %2695, i1 false)
  %2697 = add i16 %2696, 1
  %2698 = icmp eq i16 %2695, 0
  %2699 = select i1 %2698, i16 0, i16 %2697
  %2700 = zext i16 %2699 to i32
  store i32 %2700, ptr %2694, align 4
  %2701 = getelementptr inbounds i32, ptr %153, i64 6
  %2702 = load i16, ptr %152, align 2
  %2703 = xor i16 %2702, -1
  %2704 = call i16 @llvm.cttz.i16(i16 %2703, i1 false)
  %2705 = add i16 %2704, 1
  %2706 = icmp eq i16 %2703, 0
  %2707 = select i1 %2706, i16 0, i16 %2705
  %2708 = zext i16 %2707 to i32
  store i32 %2708, ptr %2701, align 4
  %2709 = getelementptr inbounds i32, ptr %153, i64 7
  %2710 = load i16, ptr %152, align 2
  %2711 = call i16 @llvm.cttz.i16(i16 %2710, i1 false)
  %2712 = add i16 %2711, 1
  %2713 = icmp eq i16 %2710, 0
  %2714 = select i1 %2713, i16 0, i16 %2712
  %2715 = zext i16 %2714 to i32
  store i32 %2715, ptr %2709, align 4
  %2716 = getelementptr inbounds i32, ptr %153, i64 8
  %2717 = load i16, ptr %152, align 2
  %2718 = call i16 @llvm.ctpop.i16(i16 %2717)
  %2719 = sub i16 16, %2718
  %2720 = zext i16 %2719 to i32
  store i32 %2720, ptr %2716, align 4
  %2721 = getelementptr inbounds i32, ptr %153, i64 9
  %2722 = load i16, ptr %152, align 2
  %2723 = call i16 @llvm.ctpop.i16(i16 %2722)
  %2724 = zext i16 %2723 to i32
  store i32 %2724, ptr %2721, align 4
  %2725 = getelementptr inbounds i32, ptr %153, i64 10
  %2726 = load i16, ptr %152, align 2
  %2727 = call i16 @llvm.ctpop.i16(i16 %2726)
  %2728 = icmp eq i16 %2727, 1
  %2729 = zext i1 %2728 to i32
  store i32 %2729, ptr %2725, align 4
  %2730 = getelementptr inbounds i32, ptr %153, i64 11
  %2731 = load i16, ptr %152, align 2
  %2732 = call i16 @llvm.ctlz.i16(i16 %2731, i1 false)
  %2733 = sub i16 16, %2732
  %2734 = zext i16 %2733 to i32
  store i32 %2734, ptr %2730, align 4
  %2735 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 0
  %2736 = load i32, ptr %2735, align 16
  %2737 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 1
  %2738 = load i32, ptr %2737, align 4
  %2739 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 2
  %2740 = load i32, ptr %2739, align 8
  %2741 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 3
  %2742 = load i32, ptr %2741, align 4
  %2743 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 4
  %2744 = load i32, ptr %2743, align 16
  %2745 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 5
  %2746 = load i32, ptr %2745, align 4
  %2747 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 6
  %2748 = load i32, ptr %2747, align 8
  %2749 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 7
  %2750 = load i32, ptr %2749, align 4
  %2751 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 8
  %2752 = load i32, ptr %2751, align 16
  %2753 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 9
  %2754 = load i32, ptr %2753, align 4
  %2755 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 10
  %2756 = load i32, ptr %2755, align 8
  %2757 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 11
  %2758 = load i32, ptr %2757, align 4
  %2759 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef %2736, i32 noundef %2738, i32 noundef %2740, i32 noundef %2742, i32 noundef %2744, i32 noundef %2746, i32 noundef %2748, i32 noundef %2750, i32 noundef %2752, i32 noundef %2754, i32 noundef %2756, i32 noundef %2758)
  %2760 = load i16, ptr %152, align 2
  %2761 = call i16 @llvm.ctlz.i16(i16 %2760, i1 true)
  %2762 = sub i16 15, %2761
  %2763 = shl i16 1, %2762
  %2764 = icmp eq i16 %2760, 0
  %2765 = select i1 %2764, i16 0, i16 %2763
  store i16 %2765, ptr %154, align 2
  %2766 = load i16, ptr %152, align 2
  %2767 = icmp ule i16 %2766, 1
  br i1 %2767, label %2773, label %2768

2768:                                             ; preds = %2668
  %2769 = sub i16 %2766, 1
  %2770 = call i16 @llvm.ctlz.i16(i16 %2769, i1 false)
  %2771 = sub i16 15, %2770
  %2772 = shl i16 2, %2771
  br label %2773

2773:                                             ; preds = %2768, %2668
  %2774 = phi i16 [ 1, %2668 ], [ %2772, %2768 ]
  store i16 %2774, ptr %155, align 2
  %2775 = load i16, ptr %152, align 2
  %2776 = call i16 @llvm.fshl.i16(i16 %2775, i16 %2775, i16 3)
  store i16 %2776, ptr %156, align 2
  %2777 = load i16, ptr %152, align 2
  %2778 = call i16 @llvm.fshr.i16(i16 %2777, i16 %2777, i16 3)
  store i16 %2778, ptr %157, align 2
  %2779 = load i16, ptr %152, align 2
  %2780 = call i16 @llvm.fshl.i16(i16 %2779, i16 %2779, i16 0)
  store i16 %2780, ptr %158, align 2
  %2781 = load i16, ptr %152, align 2
  %2782 = call i16 @llvm.fshl.i16(i16 %2781, i16 %2781, i16 8)
  store i16 %2782, ptr %159, align 2
  %2783 = load i16, ptr %154, align 2
  %2784 = zext i16 %2783 to i256
  %2785 = lshr i256 %2784, 128
  %2786 = trunc i256 %2785 to i64
  %2787 = load i16, ptr %154, align 2
  %2788 = zext i16 %2787 to i256
  %2789 = lshr i256 %2788, 64
  %2790 = trunc i256 %2789 to i64
  %2791 = load i16, ptr %154, align 2
  %2792 = zext i16 %2791 to i64
  %2793 = load i16, ptr %155, align 2
  %2794 = zext i16 %2793 to i256
  %2795 = lshr i256 %2794, 128
  %2796 = trunc i256 %2795 to i64
  %2797 = load i16, ptr %155, align 2
  %2798 = zext i16 %2797 to i256
  %2799 = lshr i256 %2798, 64
  %2800 = trunc i256 %2799 to i64
  %2801 = load i16, ptr %155, align 2
  %2802 = zext i16 %2801 to i64
  %2803 = load i16, ptr %156, align 2
  %2804 = zext i16 %2803 to i256
  %2805 = lshr i256 %2804, 128
  %2806 = trunc i256 %2805 to i64
  %2807 = load i16, ptr %156, align 2
  %2808 = zext i16 %2807 to i256
  %2809 = lshr i256 %2808, 64
  %2810 = trunc i256 %2809 to i64
  %2811 = load i16, ptr %156, align 2
  %2812 = zext i16 %2811 to i64
  %2813 = load i16, ptr %157, align 2
  %2814 = zext i16 %2813 to i256
  %2815 = lshr i256 %2814, 128
  %2816 = trunc i256 %2815 to i64
  %2817 = load i16, ptr %157, align 2
  %2818 = zext i16 %2817 to i256
  %2819 = lshr i256 %2818, 64
  %2820 = trunc i256 %2819 to i64
  %2821 = load i16, ptr %157, align 2
  %2822 = zext i16 %2821 to i64
  %2823 = load i16, ptr %158, align 2
  %2824 = zext i16 %2823 to i64
  %2825 = load i16, ptr %159, align 2
  %2826 = zext i16 %2825 to i64
  %2827 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %2786, i64 noundef %2790, i64 noundef %2792, i64 noundef %2796, i64 noundef %2800, i64 noundef %2802, i64 noundef %2806, i64 noundef %2810, i64 noundef %2812, i64 noundef %2816, i64 noundef %2820, i64 noundef %2822, i64 noundef %2824, i64 noundef %2826)
  %2828 = load i16, ptr %152, align 2
  %2829 = zext i16 %2828 to i575
  %2830 = getelementptr inbounds [12 x i32], ptr %153, i64 0, i64 0
  %2831 = load i16, ptr %154, align 2
  %2832 = zext i16 %2831 to i575
  %2833 = load i16, ptr %155, align 2
  %2834 = zext i16 %2833 to i575
  %2835 = load i16, ptr %156, align 2
  %2836 = zext i16 %2835 to i575
  %2837 = load i16, ptr %157, align 2
  %2838 = zext i16 %2837 to i575
  %2839 = load i16, ptr %158, align 2
  %2840 = zext i16 %2839 to i575
  %2841 = load i16, ptr %159, align 2
  %2842 = zext i16 %2841 to i575
  %2843 = zext i575 %2829 to i576
  store i576 %2843, ptr %160, align 8
  %2844 = zext i575 %2832 to i576
  store i576 %2844, ptr %161, align 8
  %2845 = zext i575 %2834 to i576
  store i576 %2845, ptr %162, align 8
  %2846 = zext i575 %2836 to i576
  store i576 %2846, ptr %163, align 8
  %2847 = zext i575 %2838 to i576
  store i576 %2847, ptr %164, align 8
  %2848 = zext i575 %2840 to i576
  store i576 %2848, ptr %165, align 8
  %2849 = zext i575 %2842 to i576
  store i576 %2849, ptr %166, align 8
  call void @check(ptr noundef @.str.4, i32 noundef 16, ptr noundef byval([72 x i8]) align 8 %160, ptr noundef %2830, ptr noundef byval([72 x i8]) align 8 %161, ptr noundef byval([72 x i8]) align 8 %162, ptr noundef byval([72 x i8]) align 8 %163, ptr noundef byval([72 x i8]) align 8 %164, ptr noundef byval([72 x i8]) align 8 %165, ptr noundef byval([72 x i8]) align 8 %166)
  br label %2850

2850:                                             ; preds = %2773
  br label %2851

2851:                                             ; preds = %2850
  store i32 1, ptr %167, align 4
  %2852 = load i32, ptr %167, align 4
  %2853 = call i32 @llvm.ctlz.i32(i32 %2852, i1 false)
  store i32 %2853, ptr %168, align 4
  %2854 = getelementptr inbounds i32, ptr %168, i64 1
  %2855 = load i32, ptr %167, align 4
  %2856 = xor i32 %2855, -1
  %2857 = call i32 @llvm.ctlz.i32(i32 %2856, i1 false)
  store i32 %2857, ptr %2854, align 4
  %2858 = getelementptr inbounds i32, ptr %168, i64 2
  %2859 = load i32, ptr %167, align 4
  %2860 = call i32 @llvm.cttz.i32(i32 %2859, i1 false)
  store i32 %2860, ptr %2858, align 4
  %2861 = getelementptr inbounds i32, ptr %168, i64 3
  %2862 = load i32, ptr %167, align 4
  %2863 = xor i32 %2862, -1
  %2864 = call i32 @llvm.cttz.i32(i32 %2863, i1 false)
  store i32 %2864, ptr %2861, align 4
  %2865 = getelementptr inbounds i32, ptr %168, i64 4
  %2866 = load i32, ptr %167, align 4
  %2867 = xor i32 %2866, -1
  %2868 = call i32 @llvm.ctlz.i32(i32 %2867, i1 false)
  %2869 = add i32 %2868, 1
  %2870 = icmp eq i32 %2867, 0
  %2871 = select i1 %2870, i32 0, i32 %2869
  store i32 %2871, ptr %2865, align 4
  %2872 = getelementptr inbounds i32, ptr %168, i64 5
  %2873 = load i32, ptr %167, align 4
  %2874 = call i32 @llvm.ctlz.i32(i32 %2873, i1 false)
  %2875 = add i32 %2874, 1
  %2876 = icmp eq i32 %2873, 0
  %2877 = select i1 %2876, i32 0, i32 %2875
  store i32 %2877, ptr %2872, align 4
  %2878 = getelementptr inbounds i32, ptr %168, i64 6
  %2879 = load i32, ptr %167, align 4
  %2880 = xor i32 %2879, -1
  %2881 = call i32 @llvm.cttz.i32(i32 %2880, i1 false)
  %2882 = add i32 %2881, 1
  %2883 = icmp eq i32 %2880, 0
  %2884 = select i1 %2883, i32 0, i32 %2882
  store i32 %2884, ptr %2878, align 4
  %2885 = getelementptr inbounds i32, ptr %168, i64 7
  %2886 = load i32, ptr %167, align 4
  %2887 = call i32 @llvm.cttz.i32(i32 %2886, i1 false)
  %2888 = add i32 %2887, 1
  %2889 = icmp eq i32 %2886, 0
  %2890 = select i1 %2889, i32 0, i32 %2888
  store i32 %2890, ptr %2885, align 4
  %2891 = getelementptr inbounds i32, ptr %168, i64 8
  %2892 = load i32, ptr %167, align 4
  %2893 = call i32 @llvm.ctpop.i32(i32 %2892)
  %2894 = sub i32 32, %2893
  store i32 %2894, ptr %2891, align 4
  %2895 = getelementptr inbounds i32, ptr %168, i64 9
  %2896 = load i32, ptr %167, align 4
  %2897 = call i32 @llvm.ctpop.i32(i32 %2896)
  store i32 %2897, ptr %2895, align 4
  %2898 = getelementptr inbounds i32, ptr %168, i64 10
  %2899 = load i32, ptr %167, align 4
  %2900 = call i32 @llvm.ctpop.i32(i32 %2899)
  %2901 = icmp eq i32 %2900, 1
  %2902 = zext i1 %2901 to i32
  store i32 %2902, ptr %2898, align 4
  %2903 = getelementptr inbounds i32, ptr %168, i64 11
  %2904 = load i32, ptr %167, align 4
  %2905 = call i32 @llvm.ctlz.i32(i32 %2904, i1 false)
  %2906 = sub i32 32, %2905
  store i32 %2906, ptr %2903, align 4
  %2907 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 0
  %2908 = load i32, ptr %2907, align 16
  %2909 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 1
  %2910 = load i32, ptr %2909, align 4
  %2911 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 2
  %2912 = load i32, ptr %2911, align 8
  %2913 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 3
  %2914 = load i32, ptr %2913, align 4
  %2915 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 4
  %2916 = load i32, ptr %2915, align 16
  %2917 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 5
  %2918 = load i32, ptr %2917, align 4
  %2919 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 6
  %2920 = load i32, ptr %2919, align 8
  %2921 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 7
  %2922 = load i32, ptr %2921, align 4
  %2923 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 8
  %2924 = load i32, ptr %2923, align 16
  %2925 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 9
  %2926 = load i32, ptr %2925, align 4
  %2927 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 10
  %2928 = load i32, ptr %2927, align 8
  %2929 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 11
  %2930 = load i32, ptr %2929, align 4
  %2931 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef %2908, i32 noundef %2910, i32 noundef %2912, i32 noundef %2914, i32 noundef %2916, i32 noundef %2918, i32 noundef %2920, i32 noundef %2922, i32 noundef %2924, i32 noundef %2926, i32 noundef %2928, i32 noundef %2930)
  %2932 = load i32, ptr %167, align 4
  %2933 = call i32 @llvm.ctlz.i32(i32 %2932, i1 true)
  %2934 = sub i32 31, %2933
  %2935 = shl i32 1, %2934
  %2936 = icmp eq i32 %2932, 0
  %2937 = select i1 %2936, i32 0, i32 %2935
  store i32 %2937, ptr %169, align 4
  %2938 = load i32, ptr %167, align 4
  %2939 = icmp ule i32 %2938, 1
  br i1 %2939, label %2945, label %2940

2940:                                             ; preds = %2851
  %2941 = sub i32 %2938, 1
  %2942 = call i32 @llvm.ctlz.i32(i32 %2941, i1 false)
  %2943 = sub i32 31, %2942
  %2944 = shl i32 2, %2943
  br label %2945

2945:                                             ; preds = %2940, %2851
  %2946 = phi i32 [ 1, %2851 ], [ %2944, %2940 ]
  store i32 %2946, ptr %170, align 4
  %2947 = load i32, ptr %167, align 4
  %2948 = call i32 @llvm.fshl.i32(i32 %2947, i32 %2947, i32 3)
  store i32 %2948, ptr %171, align 4
  %2949 = load i32, ptr %167, align 4
  %2950 = call i32 @llvm.fshr.i32(i32 %2949, i32 %2949, i32 3)
  store i32 %2950, ptr %172, align 4
  %2951 = load i32, ptr %167, align 4
  %2952 = call i32 @llvm.fshl.i32(i32 %2951, i32 %2951, i32 0)
  store i32 %2952, ptr %173, align 4
  %2953 = load i32, ptr %167, align 4
  %2954 = call i32 @llvm.fshl.i32(i32 %2953, i32 %2953, i32 8)
  store i32 %2954, ptr %174, align 4
  %2955 = load i32, ptr %169, align 4
  %2956 = zext i32 %2955 to i256
  %2957 = lshr i256 %2956, 128
  %2958 = trunc i256 %2957 to i64
  %2959 = load i32, ptr %169, align 4
  %2960 = zext i32 %2959 to i256
  %2961 = lshr i256 %2960, 64
  %2962 = trunc i256 %2961 to i64
  %2963 = load i32, ptr %169, align 4
  %2964 = zext i32 %2963 to i64
  %2965 = load i32, ptr %170, align 4
  %2966 = zext i32 %2965 to i256
  %2967 = lshr i256 %2966, 128
  %2968 = trunc i256 %2967 to i64
  %2969 = load i32, ptr %170, align 4
  %2970 = zext i32 %2969 to i256
  %2971 = lshr i256 %2970, 64
  %2972 = trunc i256 %2971 to i64
  %2973 = load i32, ptr %170, align 4
  %2974 = zext i32 %2973 to i64
  %2975 = load i32, ptr %171, align 4
  %2976 = zext i32 %2975 to i256
  %2977 = lshr i256 %2976, 128
  %2978 = trunc i256 %2977 to i64
  %2979 = load i32, ptr %171, align 4
  %2980 = zext i32 %2979 to i256
  %2981 = lshr i256 %2980, 64
  %2982 = trunc i256 %2981 to i64
  %2983 = load i32, ptr %171, align 4
  %2984 = zext i32 %2983 to i64
  %2985 = load i32, ptr %172, align 4
  %2986 = zext i32 %2985 to i256
  %2987 = lshr i256 %2986, 128
  %2988 = trunc i256 %2987 to i64
  %2989 = load i32, ptr %172, align 4
  %2990 = zext i32 %2989 to i256
  %2991 = lshr i256 %2990, 64
  %2992 = trunc i256 %2991 to i64
  %2993 = load i32, ptr %172, align 4
  %2994 = zext i32 %2993 to i64
  %2995 = load i32, ptr %173, align 4
  %2996 = zext i32 %2995 to i64
  %2997 = load i32, ptr %174, align 4
  %2998 = zext i32 %2997 to i64
  %2999 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %2958, i64 noundef %2962, i64 noundef %2964, i64 noundef %2968, i64 noundef %2972, i64 noundef %2974, i64 noundef %2978, i64 noundef %2982, i64 noundef %2984, i64 noundef %2988, i64 noundef %2992, i64 noundef %2994, i64 noundef %2996, i64 noundef %2998)
  %3000 = load i32, ptr %167, align 4
  %3001 = zext i32 %3000 to i575
  %3002 = getelementptr inbounds [12 x i32], ptr %168, i64 0, i64 0
  %3003 = load i32, ptr %169, align 4
  %3004 = zext i32 %3003 to i575
  %3005 = load i32, ptr %170, align 4
  %3006 = zext i32 %3005 to i575
  %3007 = load i32, ptr %171, align 4
  %3008 = zext i32 %3007 to i575
  %3009 = load i32, ptr %172, align 4
  %3010 = zext i32 %3009 to i575
  %3011 = load i32, ptr %173, align 4
  %3012 = zext i32 %3011 to i575
  %3013 = load i32, ptr %174, align 4
  %3014 = zext i32 %3013 to i575
  %3015 = zext i575 %3001 to i576
  store i576 %3015, ptr %175, align 8
  %3016 = zext i575 %3004 to i576
  store i576 %3016, ptr %176, align 8
  %3017 = zext i575 %3006 to i576
  store i576 %3017, ptr %177, align 8
  %3018 = zext i575 %3008 to i576
  store i576 %3018, ptr %178, align 8
  %3019 = zext i575 %3010 to i576
  store i576 %3019, ptr %179, align 8
  %3020 = zext i575 %3012 to i576
  store i576 %3020, ptr %180, align 8
  %3021 = zext i575 %3014 to i576
  store i576 %3021, ptr %181, align 8
  call void @check(ptr noundef @.str.5, i32 noundef 32, ptr noundef byval([72 x i8]) align 8 %175, ptr noundef %3002, ptr noundef byval([72 x i8]) align 8 %176, ptr noundef byval([72 x i8]) align 8 %177, ptr noundef byval([72 x i8]) align 8 %178, ptr noundef byval([72 x i8]) align 8 %179, ptr noundef byval([72 x i8]) align 8 %180, ptr noundef byval([72 x i8]) align 8 %181)
  br label %3022

3022:                                             ; preds = %2945
  br label %3023

3023:                                             ; preds = %3022
  store i64 1, ptr %182, align 8
  %3024 = load i64, ptr %182, align 8
  %3025 = call i64 @llvm.ctlz.i64(i64 %3024, i1 false)
  %3026 = trunc i64 %3025 to i32
  store i32 %3026, ptr %183, align 4
  %3027 = getelementptr inbounds i32, ptr %183, i64 1
  %3028 = load i64, ptr %182, align 8
  %3029 = xor i64 %3028, -1
  %3030 = call i64 @llvm.ctlz.i64(i64 %3029, i1 false)
  %3031 = trunc i64 %3030 to i32
  store i32 %3031, ptr %3027, align 4
  %3032 = getelementptr inbounds i32, ptr %183, i64 2
  %3033 = load i64, ptr %182, align 8
  %3034 = call i64 @llvm.cttz.i64(i64 %3033, i1 false)
  %3035 = trunc i64 %3034 to i32
  store i32 %3035, ptr %3032, align 4
  %3036 = getelementptr inbounds i32, ptr %183, i64 3
  %3037 = load i64, ptr %182, align 8
  %3038 = xor i64 %3037, -1
  %3039 = call i64 @llvm.cttz.i64(i64 %3038, i1 false)
  %3040 = trunc i64 %3039 to i32
  store i32 %3040, ptr %3036, align 4
  %3041 = getelementptr inbounds i32, ptr %183, i64 4
  %3042 = load i64, ptr %182, align 8
  %3043 = xor i64 %3042, -1
  %3044 = call i64 @llvm.ctlz.i64(i64 %3043, i1 false)
  %3045 = add i64 %3044, 1
  %3046 = icmp eq i64 %3043, 0
  %3047 = select i1 %3046, i64 0, i64 %3045
  %3048 = trunc i64 %3047 to i32
  store i32 %3048, ptr %3041, align 4
  %3049 = getelementptr inbounds i32, ptr %183, i64 5
  %3050 = load i64, ptr %182, align 8
  %3051 = call i64 @llvm.ctlz.i64(i64 %3050, i1 false)
  %3052 = add i64 %3051, 1
  %3053 = icmp eq i64 %3050, 0
  %3054 = select i1 %3053, i64 0, i64 %3052
  %3055 = trunc i64 %3054 to i32
  store i32 %3055, ptr %3049, align 4
  %3056 = getelementptr inbounds i32, ptr %183, i64 6
  %3057 = load i64, ptr %182, align 8
  %3058 = xor i64 %3057, -1
  %3059 = call i64 @llvm.cttz.i64(i64 %3058, i1 false)
  %3060 = add i64 %3059, 1
  %3061 = icmp eq i64 %3058, 0
  %3062 = select i1 %3061, i64 0, i64 %3060
  %3063 = trunc i64 %3062 to i32
  store i32 %3063, ptr %3056, align 4
  %3064 = getelementptr inbounds i32, ptr %183, i64 7
  %3065 = load i64, ptr %182, align 8
  %3066 = call i64 @llvm.cttz.i64(i64 %3065, i1 false)
  %3067 = add i64 %3066, 1
  %3068 = icmp eq i64 %3065, 0
  %3069 = select i1 %3068, i64 0, i64 %3067
  %3070 = trunc i64 %3069 to i32
  store i32 %3070, ptr %3064, align 4
  %3071 = getelementptr inbounds i32, ptr %183, i64 8
  %3072 = load i64, ptr %182, align 8
  %3073 = call i64 @llvm.ctpop.i64(i64 %3072)
  %3074 = sub i64 64, %3073
  %3075 = trunc i64 %3074 to i32
  store i32 %3075, ptr %3071, align 4
  %3076 = getelementptr inbounds i32, ptr %183, i64 9
  %3077 = load i64, ptr %182, align 8
  %3078 = call i64 @llvm.ctpop.i64(i64 %3077)
  %3079 = trunc i64 %3078 to i32
  store i32 %3079, ptr %3076, align 4
  %3080 = getelementptr inbounds i32, ptr %183, i64 10
  %3081 = load i64, ptr %182, align 8
  %3082 = call i64 @llvm.ctpop.i64(i64 %3081)
  %3083 = icmp eq i64 %3082, 1
  %3084 = zext i1 %3083 to i32
  store i32 %3084, ptr %3080, align 4
  %3085 = getelementptr inbounds i32, ptr %183, i64 11
  %3086 = load i64, ptr %182, align 8
  %3087 = call i64 @llvm.ctlz.i64(i64 %3086, i1 false)
  %3088 = sub i64 64, %3087
  %3089 = trunc i64 %3088 to i32
  store i32 %3089, ptr %3085, align 4
  %3090 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 0
  %3091 = load i32, ptr %3090, align 16
  %3092 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 1
  %3093 = load i32, ptr %3092, align 4
  %3094 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 2
  %3095 = load i32, ptr %3094, align 8
  %3096 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 3
  %3097 = load i32, ptr %3096, align 4
  %3098 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 4
  %3099 = load i32, ptr %3098, align 16
  %3100 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 5
  %3101 = load i32, ptr %3100, align 4
  %3102 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 6
  %3103 = load i32, ptr %3102, align 8
  %3104 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 7
  %3105 = load i32, ptr %3104, align 4
  %3106 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 8
  %3107 = load i32, ptr %3106, align 16
  %3108 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 9
  %3109 = load i32, ptr %3108, align 4
  %3110 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 10
  %3111 = load i32, ptr %3110, align 8
  %3112 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 11
  %3113 = load i32, ptr %3112, align 4
  %3114 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef %3091, i32 noundef %3093, i32 noundef %3095, i32 noundef %3097, i32 noundef %3099, i32 noundef %3101, i32 noundef %3103, i32 noundef %3105, i32 noundef %3107, i32 noundef %3109, i32 noundef %3111, i32 noundef %3113)
  %3115 = load i64, ptr %182, align 8
  %3116 = call i64 @llvm.ctlz.i64(i64 %3115, i1 true)
  %3117 = sub i64 63, %3116
  %3118 = shl i64 1, %3117
  %3119 = icmp eq i64 %3115, 0
  %3120 = select i1 %3119, i64 0, i64 %3118
  store i64 %3120, ptr %184, align 8
  %3121 = load i64, ptr %182, align 8
  %3122 = icmp ule i64 %3121, 1
  br i1 %3122, label %3128, label %3123

3123:                                             ; preds = %3023
  %3124 = sub i64 %3121, 1
  %3125 = call i64 @llvm.ctlz.i64(i64 %3124, i1 false)
  %3126 = sub i64 63, %3125
  %3127 = shl i64 2, %3126
  br label %3128

3128:                                             ; preds = %3123, %3023
  %3129 = phi i64 [ 1, %3023 ], [ %3127, %3123 ]
  store i64 %3129, ptr %185, align 8
  %3130 = load i64, ptr %182, align 8
  %3131 = call i64 @llvm.fshl.i64(i64 %3130, i64 %3130, i64 3)
  store i64 %3131, ptr %186, align 8
  %3132 = load i64, ptr %182, align 8
  %3133 = call i64 @llvm.fshr.i64(i64 %3132, i64 %3132, i64 3)
  store i64 %3133, ptr %187, align 8
  %3134 = load i64, ptr %182, align 8
  %3135 = call i64 @llvm.fshl.i64(i64 %3134, i64 %3134, i64 0)
  store i64 %3135, ptr %188, align 8
  %3136 = load i64, ptr %182, align 8
  %3137 = call i64 @llvm.fshl.i64(i64 %3136, i64 %3136, i64 40)
  store i64 %3137, ptr %189, align 8
  %3138 = load i64, ptr %184, align 8
  %3139 = zext i64 %3138 to i256
  %3140 = lshr i256 %3139, 128
  %3141 = trunc i256 %3140 to i64
  %3142 = load i64, ptr %184, align 8
  %3143 = zext i64 %3142 to i256
  %3144 = lshr i256 %3143, 64
  %3145 = trunc i256 %3144 to i64
  %3146 = load i64, ptr %184, align 8
  %3147 = load i64, ptr %185, align 8
  %3148 = zext i64 %3147 to i256
  %3149 = lshr i256 %3148, 128
  %3150 = trunc i256 %3149 to i64
  %3151 = load i64, ptr %185, align 8
  %3152 = zext i64 %3151 to i256
  %3153 = lshr i256 %3152, 64
  %3154 = trunc i256 %3153 to i64
  %3155 = load i64, ptr %185, align 8
  %3156 = load i64, ptr %186, align 8
  %3157 = zext i64 %3156 to i256
  %3158 = lshr i256 %3157, 128
  %3159 = trunc i256 %3158 to i64
  %3160 = load i64, ptr %186, align 8
  %3161 = zext i64 %3160 to i256
  %3162 = lshr i256 %3161, 64
  %3163 = trunc i256 %3162 to i64
  %3164 = load i64, ptr %186, align 8
  %3165 = load i64, ptr %187, align 8
  %3166 = zext i64 %3165 to i256
  %3167 = lshr i256 %3166, 128
  %3168 = trunc i256 %3167 to i64
  %3169 = load i64, ptr %187, align 8
  %3170 = zext i64 %3169 to i256
  %3171 = lshr i256 %3170, 64
  %3172 = trunc i256 %3171 to i64
  %3173 = load i64, ptr %187, align 8
  %3174 = load i64, ptr %188, align 8
  %3175 = load i64, ptr %189, align 8
  %3176 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %3141, i64 noundef %3145, i64 noundef %3146, i64 noundef %3150, i64 noundef %3154, i64 noundef %3155, i64 noundef %3159, i64 noundef %3163, i64 noundef %3164, i64 noundef %3168, i64 noundef %3172, i64 noundef %3173, i64 noundef %3174, i64 noundef %3175)
  %3177 = load i64, ptr %182, align 8
  %3178 = zext i64 %3177 to i575
  %3179 = getelementptr inbounds [12 x i32], ptr %183, i64 0, i64 0
  %3180 = load i64, ptr %184, align 8
  %3181 = zext i64 %3180 to i575
  %3182 = load i64, ptr %185, align 8
  %3183 = zext i64 %3182 to i575
  %3184 = load i64, ptr %186, align 8
  %3185 = zext i64 %3184 to i575
  %3186 = load i64, ptr %187, align 8
  %3187 = zext i64 %3186 to i575
  %3188 = load i64, ptr %188, align 8
  %3189 = zext i64 %3188 to i575
  %3190 = load i64, ptr %189, align 8
  %3191 = zext i64 %3190 to i575
  %3192 = zext i575 %3178 to i576
  store i576 %3192, ptr %190, align 8
  %3193 = zext i575 %3181 to i576
  store i576 %3193, ptr %191, align 8
  %3194 = zext i575 %3183 to i576
  store i576 %3194, ptr %192, align 8
  %3195 = zext i575 %3185 to i576
  store i576 %3195, ptr %193, align 8
  %3196 = zext i575 %3187 to i576
  store i576 %3196, ptr %194, align 8
  %3197 = zext i575 %3189 to i576
  store i576 %3197, ptr %195, align 8
  %3198 = zext i575 %3191 to i576
  store i576 %3198, ptr %196, align 8
  call void @check(ptr noundef @.str.6, i32 noundef 64, ptr noundef byval([72 x i8]) align 8 %190, ptr noundef %3179, ptr noundef byval([72 x i8]) align 8 %191, ptr noundef byval([72 x i8]) align 8 %192, ptr noundef byval([72 x i8]) align 8 %193, ptr noundef byval([72 x i8]) align 8 %194, ptr noundef byval([72 x i8]) align 8 %195, ptr noundef byval([72 x i8]) align 8 %196)
  br label %3199

3199:                                             ; preds = %3128
  br label %3200

3200:                                             ; preds = %3199
  store i128 1, ptr %197, align 16
  %3201 = load i128, ptr %197, align 16
  %3202 = call i128 @llvm.ctlz.i128(i128 %3201, i1 false)
  %3203 = trunc i128 %3202 to i32
  store i32 %3203, ptr %198, align 4
  %3204 = getelementptr inbounds i32, ptr %198, i64 1
  %3205 = load i128, ptr %197, align 16
  %3206 = xor i128 %3205, -1
  %3207 = call i128 @llvm.ctlz.i128(i128 %3206, i1 false)
  %3208 = trunc i128 %3207 to i32
  store i32 %3208, ptr %3204, align 4
  %3209 = getelementptr inbounds i32, ptr %198, i64 2
  %3210 = load i128, ptr %197, align 16
  %3211 = call i128 @llvm.cttz.i128(i128 %3210, i1 false)
  %3212 = trunc i128 %3211 to i32
  store i32 %3212, ptr %3209, align 4
  %3213 = getelementptr inbounds i32, ptr %198, i64 3
  %3214 = load i128, ptr %197, align 16
  %3215 = xor i128 %3214, -1
  %3216 = call i128 @llvm.cttz.i128(i128 %3215, i1 false)
  %3217 = trunc i128 %3216 to i32
  store i32 %3217, ptr %3213, align 4
  %3218 = getelementptr inbounds i32, ptr %198, i64 4
  %3219 = load i128, ptr %197, align 16
  %3220 = xor i128 %3219, -1
  %3221 = call i128 @llvm.ctlz.i128(i128 %3220, i1 false)
  %3222 = add i128 %3221, 1
  %3223 = icmp eq i128 %3220, 0
  %3224 = select i1 %3223, i128 0, i128 %3222
  %3225 = trunc i128 %3224 to i32
  store i32 %3225, ptr %3218, align 4
  %3226 = getelementptr inbounds i32, ptr %198, i64 5
  %3227 = load i128, ptr %197, align 16
  %3228 = call i128 @llvm.ctlz.i128(i128 %3227, i1 false)
  %3229 = add i128 %3228, 1
  %3230 = icmp eq i128 %3227, 0
  %3231 = select i1 %3230, i128 0, i128 %3229
  %3232 = trunc i128 %3231 to i32
  store i32 %3232, ptr %3226, align 4
  %3233 = getelementptr inbounds i32, ptr %198, i64 6
  %3234 = load i128, ptr %197, align 16
  %3235 = xor i128 %3234, -1
  %3236 = call i128 @llvm.cttz.i128(i128 %3235, i1 false)
  %3237 = add i128 %3236, 1
  %3238 = icmp eq i128 %3235, 0
  %3239 = select i1 %3238, i128 0, i128 %3237
  %3240 = trunc i128 %3239 to i32
  store i32 %3240, ptr %3233, align 4
  %3241 = getelementptr inbounds i32, ptr %198, i64 7
  %3242 = load i128, ptr %197, align 16
  %3243 = call i128 @llvm.cttz.i128(i128 %3242, i1 false)
  %3244 = add i128 %3243, 1
  %3245 = icmp eq i128 %3242, 0
  %3246 = select i1 %3245, i128 0, i128 %3244
  %3247 = trunc i128 %3246 to i32
  store i32 %3247, ptr %3241, align 4
  %3248 = getelementptr inbounds i32, ptr %198, i64 8
  %3249 = load i128, ptr %197, align 16
  %3250 = call i128 @llvm.ctpop.i128(i128 %3249)
  %3251 = sub i128 128, %3250
  %3252 = trunc i128 %3251 to i32
  store i32 %3252, ptr %3248, align 4
  %3253 = getelementptr inbounds i32, ptr %198, i64 9
  %3254 = load i128, ptr %197, align 16
  %3255 = call i128 @llvm.ctpop.i128(i128 %3254)
  %3256 = trunc i128 %3255 to i32
  store i32 %3256, ptr %3253, align 4
  %3257 = getelementptr inbounds i32, ptr %198, i64 10
  %3258 = load i128, ptr %197, align 16
  %3259 = call i128 @llvm.ctpop.i128(i128 %3258)
  %3260 = icmp eq i128 %3259, 1
  %3261 = zext i1 %3260 to i32
  store i32 %3261, ptr %3257, align 4
  %3262 = getelementptr inbounds i32, ptr %198, i64 11
  %3263 = load i128, ptr %197, align 16
  %3264 = call i128 @llvm.ctlz.i128(i128 %3263, i1 false)
  %3265 = sub i128 128, %3264
  %3266 = trunc i128 %3265 to i32
  store i32 %3266, ptr %3262, align 4
  %3267 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 0
  %3268 = load i32, ptr %3267, align 16
  %3269 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 1
  %3270 = load i32, ptr %3269, align 4
  %3271 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 2
  %3272 = load i32, ptr %3271, align 8
  %3273 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 3
  %3274 = load i32, ptr %3273, align 4
  %3275 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 4
  %3276 = load i32, ptr %3275, align 16
  %3277 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 5
  %3278 = load i32, ptr %3277, align 4
  %3279 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 6
  %3280 = load i32, ptr %3279, align 8
  %3281 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 7
  %3282 = load i32, ptr %3281, align 4
  %3283 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 8
  %3284 = load i32, ptr %3283, align 16
  %3285 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 9
  %3286 = load i32, ptr %3285, align 4
  %3287 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 10
  %3288 = load i32, ptr %3287, align 8
  %3289 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 11
  %3290 = load i32, ptr %3289, align 4
  %3291 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef %3268, i32 noundef %3270, i32 noundef %3272, i32 noundef %3274, i32 noundef %3276, i32 noundef %3278, i32 noundef %3280, i32 noundef %3282, i32 noundef %3284, i32 noundef %3286, i32 noundef %3288, i32 noundef %3290)
  %3292 = load i128, ptr %197, align 16
  %3293 = call i128 @llvm.ctlz.i128(i128 %3292, i1 true)
  %3294 = sub i128 127, %3293
  %3295 = shl i128 1, %3294
  %3296 = icmp eq i128 %3292, 0
  %3297 = select i1 %3296, i128 0, i128 %3295
  store i128 %3297, ptr %199, align 16
  %3298 = load i128, ptr %197, align 16
  %3299 = icmp ule i128 %3298, 1
  br i1 %3299, label %3305, label %3300

3300:                                             ; preds = %3200
  %3301 = sub i128 %3298, 1
  %3302 = call i128 @llvm.ctlz.i128(i128 %3301, i1 false)
  %3303 = sub i128 127, %3302
  %3304 = shl i128 2, %3303
  br label %3305

3305:                                             ; preds = %3300, %3200
  %3306 = phi i128 [ 1, %3200 ], [ %3304, %3300 ]
  store i128 %3306, ptr %200, align 16
  %3307 = load i128, ptr %197, align 16
  %3308 = call i128 @llvm.fshl.i128(i128 %3307, i128 %3307, i128 3)
  store i128 %3308, ptr %201, align 16
  %3309 = load i128, ptr %197, align 16
  %3310 = call i128 @llvm.fshr.i128(i128 %3309, i128 %3309, i128 3)
  store i128 %3310, ptr %202, align 16
  %3311 = load i128, ptr %197, align 16
  %3312 = call i128 @llvm.fshl.i128(i128 %3311, i128 %3311, i128 0)
  store i128 %3312, ptr %203, align 16
  %3313 = load i128, ptr %197, align 16
  %3314 = call i128 @llvm.fshl.i128(i128 %3313, i128 %3313, i128 104)
  store i128 %3314, ptr %204, align 16
  %3315 = load i128, ptr %199, align 16
  %3316 = zext i128 %3315 to i256
  %3317 = lshr i256 %3316, 128
  %3318 = trunc i256 %3317 to i64
  %3319 = load i128, ptr %199, align 16
  %3320 = zext i128 %3319 to i256
  %3321 = lshr i256 %3320, 64
  %3322 = trunc i256 %3321 to i64
  %3323 = load i128, ptr %199, align 16
  %3324 = trunc i128 %3323 to i64
  %3325 = load i128, ptr %200, align 16
  %3326 = zext i128 %3325 to i256
  %3327 = lshr i256 %3326, 128
  %3328 = trunc i256 %3327 to i64
  %3329 = load i128, ptr %200, align 16
  %3330 = zext i128 %3329 to i256
  %3331 = lshr i256 %3330, 64
  %3332 = trunc i256 %3331 to i64
  %3333 = load i128, ptr %200, align 16
  %3334 = trunc i128 %3333 to i64
  %3335 = load i128, ptr %201, align 16
  %3336 = zext i128 %3335 to i256
  %3337 = lshr i256 %3336, 128
  %3338 = trunc i256 %3337 to i64
  %3339 = load i128, ptr %201, align 16
  %3340 = zext i128 %3339 to i256
  %3341 = lshr i256 %3340, 64
  %3342 = trunc i256 %3341 to i64
  %3343 = load i128, ptr %201, align 16
  %3344 = trunc i128 %3343 to i64
  %3345 = load i128, ptr %202, align 16
  %3346 = zext i128 %3345 to i256
  %3347 = lshr i256 %3346, 128
  %3348 = trunc i256 %3347 to i64
  %3349 = load i128, ptr %202, align 16
  %3350 = zext i128 %3349 to i256
  %3351 = lshr i256 %3350, 64
  %3352 = trunc i256 %3351 to i64
  %3353 = load i128, ptr %202, align 16
  %3354 = trunc i128 %3353 to i64
  %3355 = load i128, ptr %203, align 16
  %3356 = trunc i128 %3355 to i64
  %3357 = load i128, ptr %204, align 16
  %3358 = trunc i128 %3357 to i64
  %3359 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %3318, i64 noundef %3322, i64 noundef %3324, i64 noundef %3328, i64 noundef %3332, i64 noundef %3334, i64 noundef %3338, i64 noundef %3342, i64 noundef %3344, i64 noundef %3348, i64 noundef %3352, i64 noundef %3354, i64 noundef %3356, i64 noundef %3358)
  %3360 = load i128, ptr %197, align 16
  %3361 = zext i128 %3360 to i575
  %3362 = getelementptr inbounds [12 x i32], ptr %198, i64 0, i64 0
  %3363 = load i128, ptr %199, align 16
  %3364 = zext i128 %3363 to i575
  %3365 = load i128, ptr %200, align 16
  %3366 = zext i128 %3365 to i575
  %3367 = load i128, ptr %201, align 16
  %3368 = zext i128 %3367 to i575
  %3369 = load i128, ptr %202, align 16
  %3370 = zext i128 %3369 to i575
  %3371 = load i128, ptr %203, align 16
  %3372 = zext i128 %3371 to i575
  %3373 = load i128, ptr %204, align 16
  %3374 = zext i128 %3373 to i575
  %3375 = zext i575 %3361 to i576
  store i576 %3375, ptr %205, align 8
  %3376 = zext i575 %3364 to i576
  store i576 %3376, ptr %206, align 8
  %3377 = zext i575 %3366 to i576
  store i576 %3377, ptr %207, align 8
  %3378 = zext i575 %3368 to i576
  store i576 %3378, ptr %208, align 8
  %3379 = zext i575 %3370 to i576
  store i576 %3379, ptr %209, align 8
  %3380 = zext i575 %3372 to i576
  store i576 %3380, ptr %210, align 8
  %3381 = zext i575 %3374 to i576
  store i576 %3381, ptr %211, align 8
  call void @check(ptr noundef @.str.7, i32 noundef 128, ptr noundef byval([72 x i8]) align 8 %205, ptr noundef %3362, ptr noundef byval([72 x i8]) align 8 %206, ptr noundef byval([72 x i8]) align 8 %207, ptr noundef byval([72 x i8]) align 8 %208, ptr noundef byval([72 x i8]) align 8 %209, ptr noundef byval([72 x i8]) align 8 %210, ptr noundef byval([72 x i8]) align 8 %211)
  br label %3382

3382:                                             ; preds = %3305
  br label %3383

3383:                                             ; preds = %3382
  store i8 1, ptr %212, align 1
  %3384 = load i8, ptr %212, align 1
  %3385 = trunc i8 %3384 to i7
  %3386 = call i7 @llvm.ctlz.i7(i7 %3385, i1 false)
  %3387 = zext i7 %3386 to i32
  store i32 %3387, ptr %213, align 4
  %3388 = getelementptr inbounds i32, ptr %213, i64 1
  %3389 = load i8, ptr %212, align 1
  %3390 = trunc i8 %3389 to i7
  %3391 = xor i7 %3390, -1
  %3392 = call i7 @llvm.ctlz.i7(i7 %3391, i1 false)
  %3393 = zext i7 %3392 to i32
  store i32 %3393, ptr %3388, align 4
  %3394 = getelementptr inbounds i32, ptr %213, i64 2
  %3395 = load i8, ptr %212, align 1
  %3396 = trunc i8 %3395 to i7
  %3397 = call i7 @llvm.cttz.i7(i7 %3396, i1 false)
  %3398 = zext i7 %3397 to i32
  store i32 %3398, ptr %3394, align 4
  %3399 = getelementptr inbounds i32, ptr %213, i64 3
  %3400 = load i8, ptr %212, align 1
  %3401 = trunc i8 %3400 to i7
  %3402 = xor i7 %3401, -1
  %3403 = call i7 @llvm.cttz.i7(i7 %3402, i1 false)
  %3404 = zext i7 %3403 to i32
  store i32 %3404, ptr %3399, align 4
  %3405 = getelementptr inbounds i32, ptr %213, i64 4
  %3406 = load i8, ptr %212, align 1
  %3407 = trunc i8 %3406 to i7
  %3408 = xor i7 %3407, -1
  %3409 = call i7 @llvm.ctlz.i7(i7 %3408, i1 false)
  %3410 = add i7 %3409, 1
  %3411 = icmp eq i7 %3408, 0
  %3412 = select i1 %3411, i7 0, i7 %3410
  %3413 = zext i7 %3412 to i32
  store i32 %3413, ptr %3405, align 4
  %3414 = getelementptr inbounds i32, ptr %213, i64 5
  %3415 = load i8, ptr %212, align 1
  %3416 = trunc i8 %3415 to i7
  %3417 = call i7 @llvm.ctlz.i7(i7 %3416, i1 false)
  %3418 = add i7 %3417, 1
  %3419 = icmp eq i7 %3416, 0
  %3420 = select i1 %3419, i7 0, i7 %3418
  %3421 = zext i7 %3420 to i32
  store i32 %3421, ptr %3414, align 4
  %3422 = getelementptr inbounds i32, ptr %213, i64 6
  %3423 = load i8, ptr %212, align 1
  %3424 = trunc i8 %3423 to i7
  %3425 = xor i7 %3424, -1
  %3426 = call i7 @llvm.cttz.i7(i7 %3425, i1 false)
  %3427 = add i7 %3426, 1
  %3428 = icmp eq i7 %3425, 0
  %3429 = select i1 %3428, i7 0, i7 %3427
  %3430 = zext i7 %3429 to i32
  store i32 %3430, ptr %3422, align 4
  %3431 = getelementptr inbounds i32, ptr %213, i64 7
  %3432 = load i8, ptr %212, align 1
  %3433 = trunc i8 %3432 to i7
  %3434 = call i7 @llvm.cttz.i7(i7 %3433, i1 false)
  %3435 = add i7 %3434, 1
  %3436 = icmp eq i7 %3433, 0
  %3437 = select i1 %3436, i7 0, i7 %3435
  %3438 = zext i7 %3437 to i32
  store i32 %3438, ptr %3431, align 4
  %3439 = getelementptr inbounds i32, ptr %213, i64 8
  %3440 = load i8, ptr %212, align 1
  %3441 = trunc i8 %3440 to i7
  %3442 = call i7 @llvm.ctpop.i7(i7 %3441)
  %3443 = sub i7 7, %3442
  %3444 = zext i7 %3443 to i32
  store i32 %3444, ptr %3439, align 4
  %3445 = getelementptr inbounds i32, ptr %213, i64 9
  %3446 = load i8, ptr %212, align 1
  %3447 = trunc i8 %3446 to i7
  %3448 = call i7 @llvm.ctpop.i7(i7 %3447)
  %3449 = zext i7 %3448 to i32
  store i32 %3449, ptr %3445, align 4
  %3450 = getelementptr inbounds i32, ptr %213, i64 10
  %3451 = load i8, ptr %212, align 1
  %3452 = trunc i8 %3451 to i7
  %3453 = call i7 @llvm.ctpop.i7(i7 %3452)
  %3454 = icmp eq i7 %3453, 1
  %3455 = zext i1 %3454 to i32
  store i32 %3455, ptr %3450, align 4
  %3456 = getelementptr inbounds i32, ptr %213, i64 11
  %3457 = load i8, ptr %212, align 1
  %3458 = trunc i8 %3457 to i7
  %3459 = call i7 @llvm.ctlz.i7(i7 %3458, i1 false)
  %3460 = sub i7 7, %3459
  %3461 = zext i7 %3460 to i32
  store i32 %3461, ptr %3456, align 4
  %3462 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 0
  %3463 = load i32, ptr %3462, align 16
  %3464 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 1
  %3465 = load i32, ptr %3464, align 4
  %3466 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 2
  %3467 = load i32, ptr %3466, align 8
  %3468 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 3
  %3469 = load i32, ptr %3468, align 4
  %3470 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 4
  %3471 = load i32, ptr %3470, align 16
  %3472 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 5
  %3473 = load i32, ptr %3472, align 4
  %3474 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 6
  %3475 = load i32, ptr %3474, align 8
  %3476 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 7
  %3477 = load i32, ptr %3476, align 4
  %3478 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 8
  %3479 = load i32, ptr %3478, align 16
  %3480 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 9
  %3481 = load i32, ptr %3480, align 4
  %3482 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 10
  %3483 = load i32, ptr %3482, align 8
  %3484 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 11
  %3485 = load i32, ptr %3484, align 4
  %3486 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef %3463, i32 noundef %3465, i32 noundef %3467, i32 noundef %3469, i32 noundef %3471, i32 noundef %3473, i32 noundef %3475, i32 noundef %3477, i32 noundef %3479, i32 noundef %3481, i32 noundef %3483, i32 noundef %3485)
  %3487 = load i8, ptr %212, align 1
  %3488 = trunc i8 %3487 to i7
  %3489 = call i7 @llvm.ctlz.i7(i7 %3488, i1 true)
  %3490 = sub i7 6, %3489
  %3491 = shl i7 1, %3490
  %3492 = icmp eq i7 %3488, 0
  %3493 = select i1 %3492, i7 0, i7 %3491
  %3494 = zext i7 %3493 to i8
  store i8 %3494, ptr %214, align 1
  %3495 = load i8, ptr %212, align 1
  %3496 = trunc i8 %3495 to i7
  %3497 = icmp ule i7 %3496, 1
  br i1 %3497, label %3503, label %3498

3498:                                             ; preds = %3383
  %3499 = sub i7 %3496, 1
  %3500 = call i7 @llvm.ctlz.i7(i7 %3499, i1 false)
  %3501 = sub i7 6, %3500
  %3502 = shl i7 2, %3501
  br label %3503

3503:                                             ; preds = %3498, %3383
  %3504 = phi i7 [ 1, %3383 ], [ %3502, %3498 ]
  %3505 = zext i7 %3504 to i8
  store i8 %3505, ptr %215, align 1
  %3506 = load i8, ptr %212, align 1
  %3507 = trunc i8 %3506 to i7
  %3508 = call i7 @llvm.fshl.i7(i7 %3507, i7 %3507, i7 3)
  %3509 = zext i7 %3508 to i8
  store i8 %3509, ptr %216, align 1
  %3510 = load i8, ptr %212, align 1
  %3511 = trunc i8 %3510 to i7
  %3512 = call i7 @llvm.fshr.i7(i7 %3511, i7 %3511, i7 3)
  %3513 = zext i7 %3512 to i8
  store i8 %3513, ptr %217, align 1
  %3514 = load i8, ptr %212, align 1
  %3515 = trunc i8 %3514 to i7
  %3516 = call i7 @llvm.fshl.i7(i7 %3515, i7 %3515, i7 0)
  %3517 = zext i7 %3516 to i8
  store i8 %3517, ptr %218, align 1
  %3518 = load i8, ptr %212, align 1
  %3519 = trunc i8 %3518 to i7
  %3520 = call i7 @llvm.fshl.i7(i7 %3519, i7 %3519, i7 6)
  %3521 = zext i7 %3520 to i8
  store i8 %3521, ptr %219, align 1
  %3522 = load i8, ptr %214, align 1
  %3523 = trunc i8 %3522 to i7
  %3524 = zext i7 %3523 to i256
  %3525 = lshr i256 %3524, 128
  %3526 = trunc i256 %3525 to i64
  %3527 = load i8, ptr %214, align 1
  %3528 = trunc i8 %3527 to i7
  %3529 = zext i7 %3528 to i256
  %3530 = lshr i256 %3529, 64
  %3531 = trunc i256 %3530 to i64
  %3532 = load i8, ptr %214, align 1
  %3533 = trunc i8 %3532 to i7
  %3534 = zext i7 %3533 to i64
  %3535 = load i8, ptr %215, align 1
  %3536 = trunc i8 %3535 to i7
  %3537 = zext i7 %3536 to i256
  %3538 = lshr i256 %3537, 128
  %3539 = trunc i256 %3538 to i64
  %3540 = load i8, ptr %215, align 1
  %3541 = trunc i8 %3540 to i7
  %3542 = zext i7 %3541 to i256
  %3543 = lshr i256 %3542, 64
  %3544 = trunc i256 %3543 to i64
  %3545 = load i8, ptr %215, align 1
  %3546 = trunc i8 %3545 to i7
  %3547 = zext i7 %3546 to i64
  %3548 = load i8, ptr %216, align 1
  %3549 = trunc i8 %3548 to i7
  %3550 = zext i7 %3549 to i256
  %3551 = lshr i256 %3550, 128
  %3552 = trunc i256 %3551 to i64
  %3553 = load i8, ptr %216, align 1
  %3554 = trunc i8 %3553 to i7
  %3555 = zext i7 %3554 to i256
  %3556 = lshr i256 %3555, 64
  %3557 = trunc i256 %3556 to i64
  %3558 = load i8, ptr %216, align 1
  %3559 = trunc i8 %3558 to i7
  %3560 = zext i7 %3559 to i64
  %3561 = load i8, ptr %217, align 1
  %3562 = trunc i8 %3561 to i7
  %3563 = zext i7 %3562 to i256
  %3564 = lshr i256 %3563, 128
  %3565 = trunc i256 %3564 to i64
  %3566 = load i8, ptr %217, align 1
  %3567 = trunc i8 %3566 to i7
  %3568 = zext i7 %3567 to i256
  %3569 = lshr i256 %3568, 64
  %3570 = trunc i256 %3569 to i64
  %3571 = load i8, ptr %217, align 1
  %3572 = trunc i8 %3571 to i7
  %3573 = zext i7 %3572 to i64
  %3574 = load i8, ptr %218, align 1
  %3575 = trunc i8 %3574 to i7
  %3576 = zext i7 %3575 to i64
  %3577 = load i8, ptr %219, align 1
  %3578 = trunc i8 %3577 to i7
  %3579 = zext i7 %3578 to i64
  %3580 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %3526, i64 noundef %3531, i64 noundef %3534, i64 noundef %3539, i64 noundef %3544, i64 noundef %3547, i64 noundef %3552, i64 noundef %3557, i64 noundef %3560, i64 noundef %3565, i64 noundef %3570, i64 noundef %3573, i64 noundef %3576, i64 noundef %3579)
  %3581 = load i8, ptr %212, align 1
  %3582 = trunc i8 %3581 to i7
  %3583 = zext i7 %3582 to i575
  %3584 = getelementptr inbounds [12 x i32], ptr %213, i64 0, i64 0
  %3585 = load i8, ptr %214, align 1
  %3586 = trunc i8 %3585 to i7
  %3587 = zext i7 %3586 to i575
  %3588 = load i8, ptr %215, align 1
  %3589 = trunc i8 %3588 to i7
  %3590 = zext i7 %3589 to i575
  %3591 = load i8, ptr %216, align 1
  %3592 = trunc i8 %3591 to i7
  %3593 = zext i7 %3592 to i575
  %3594 = load i8, ptr %217, align 1
  %3595 = trunc i8 %3594 to i7
  %3596 = zext i7 %3595 to i575
  %3597 = load i8, ptr %218, align 1
  %3598 = trunc i8 %3597 to i7
  %3599 = zext i7 %3598 to i575
  %3600 = load i8, ptr %219, align 1
  %3601 = trunc i8 %3600 to i7
  %3602 = zext i7 %3601 to i575
  %3603 = zext i575 %3583 to i576
  store i576 %3603, ptr %220, align 8
  %3604 = zext i575 %3587 to i576
  store i576 %3604, ptr %221, align 8
  %3605 = zext i575 %3590 to i576
  store i576 %3605, ptr %222, align 8
  %3606 = zext i575 %3593 to i576
  store i576 %3606, ptr %223, align 8
  %3607 = zext i575 %3596 to i576
  store i576 %3607, ptr %224, align 8
  %3608 = zext i575 %3599 to i576
  store i576 %3608, ptr %225, align 8
  %3609 = zext i575 %3602 to i576
  store i576 %3609, ptr %226, align 8
  call void @check(ptr noundef @.str.8, i32 noundef 7, ptr noundef byval([72 x i8]) align 8 %220, ptr noundef %3584, ptr noundef byval([72 x i8]) align 8 %221, ptr noundef byval([72 x i8]) align 8 %222, ptr noundef byval([72 x i8]) align 8 %223, ptr noundef byval([72 x i8]) align 8 %224, ptr noundef byval([72 x i8]) align 8 %225, ptr noundef byval([72 x i8]) align 8 %226)
  br label %3610

3610:                                             ; preds = %3503
  br label %3611

3611:                                             ; preds = %3610
  store i128 1, ptr %227, align 8
  %3612 = load i128, ptr %227, align 8
  %3613 = trunc i128 %3612 to i65
  %3614 = call i65 @llvm.ctlz.i65(i65 %3613, i1 false)
  %3615 = trunc i65 %3614 to i32
  store i32 %3615, ptr %228, align 4
  %3616 = getelementptr inbounds i32, ptr %228, i64 1
  %3617 = load i128, ptr %227, align 8
  %3618 = trunc i128 %3617 to i65
  %3619 = xor i65 %3618, -1
  %3620 = call i65 @llvm.ctlz.i65(i65 %3619, i1 false)
  %3621 = trunc i65 %3620 to i32
  store i32 %3621, ptr %3616, align 4
  %3622 = getelementptr inbounds i32, ptr %228, i64 2
  %3623 = load i128, ptr %227, align 8
  %3624 = trunc i128 %3623 to i65
  %3625 = call i65 @llvm.cttz.i65(i65 %3624, i1 false)
  %3626 = trunc i65 %3625 to i32
  store i32 %3626, ptr %3622, align 4
  %3627 = getelementptr inbounds i32, ptr %228, i64 3
  %3628 = load i128, ptr %227, align 8
  %3629 = trunc i128 %3628 to i65
  %3630 = xor i65 %3629, -1
  %3631 = call i65 @llvm.cttz.i65(i65 %3630, i1 false)
  %3632 = trunc i65 %3631 to i32
  store i32 %3632, ptr %3627, align 4
  %3633 = getelementptr inbounds i32, ptr %228, i64 4
  %3634 = load i128, ptr %227, align 8
  %3635 = trunc i128 %3634 to i65
  %3636 = xor i65 %3635, -1
  %3637 = call i65 @llvm.ctlz.i65(i65 %3636, i1 false)
  %3638 = add i65 %3637, 1
  %3639 = icmp eq i65 %3636, 0
  %3640 = select i1 %3639, i65 0, i65 %3638
  %3641 = trunc i65 %3640 to i32
  store i32 %3641, ptr %3633, align 4
  %3642 = getelementptr inbounds i32, ptr %228, i64 5
  %3643 = load i128, ptr %227, align 8
  %3644 = trunc i128 %3643 to i65
  %3645 = call i65 @llvm.ctlz.i65(i65 %3644, i1 false)
  %3646 = add i65 %3645, 1
  %3647 = icmp eq i65 %3644, 0
  %3648 = select i1 %3647, i65 0, i65 %3646
  %3649 = trunc i65 %3648 to i32
  store i32 %3649, ptr %3642, align 4
  %3650 = getelementptr inbounds i32, ptr %228, i64 6
  %3651 = load i128, ptr %227, align 8
  %3652 = trunc i128 %3651 to i65
  %3653 = xor i65 %3652, -1
  %3654 = call i65 @llvm.cttz.i65(i65 %3653, i1 false)
  %3655 = add i65 %3654, 1
  %3656 = icmp eq i65 %3653, 0
  %3657 = select i1 %3656, i65 0, i65 %3655
  %3658 = trunc i65 %3657 to i32
  store i32 %3658, ptr %3650, align 4
  %3659 = getelementptr inbounds i32, ptr %228, i64 7
  %3660 = load i128, ptr %227, align 8
  %3661 = trunc i128 %3660 to i65
  %3662 = call i65 @llvm.cttz.i65(i65 %3661, i1 false)
  %3663 = add i65 %3662, 1
  %3664 = icmp eq i65 %3661, 0
  %3665 = select i1 %3664, i65 0, i65 %3663
  %3666 = trunc i65 %3665 to i32
  store i32 %3666, ptr %3659, align 4
  %3667 = getelementptr inbounds i32, ptr %228, i64 8
  %3668 = load i128, ptr %227, align 8
  %3669 = trunc i128 %3668 to i65
  %3670 = call i65 @llvm.ctpop.i65(i65 %3669)
  %3671 = sub i65 65, %3670
  %3672 = trunc i65 %3671 to i32
  store i32 %3672, ptr %3667, align 4
  %3673 = getelementptr inbounds i32, ptr %228, i64 9
  %3674 = load i128, ptr %227, align 8
  %3675 = trunc i128 %3674 to i65
  %3676 = call i65 @llvm.ctpop.i65(i65 %3675)
  %3677 = trunc i65 %3676 to i32
  store i32 %3677, ptr %3673, align 4
  %3678 = getelementptr inbounds i32, ptr %228, i64 10
  %3679 = load i128, ptr %227, align 8
  %3680 = trunc i128 %3679 to i65
  %3681 = call i65 @llvm.ctpop.i65(i65 %3680)
  %3682 = icmp eq i65 %3681, 1
  %3683 = zext i1 %3682 to i32
  store i32 %3683, ptr %3678, align 4
  %3684 = getelementptr inbounds i32, ptr %228, i64 11
  %3685 = load i128, ptr %227, align 8
  %3686 = trunc i128 %3685 to i65
  %3687 = call i65 @llvm.ctlz.i65(i65 %3686, i1 false)
  %3688 = sub i65 65, %3687
  %3689 = trunc i65 %3688 to i32
  store i32 %3689, ptr %3684, align 4
  %3690 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 0
  %3691 = load i32, ptr %3690, align 16
  %3692 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 1
  %3693 = load i32, ptr %3692, align 4
  %3694 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 2
  %3695 = load i32, ptr %3694, align 8
  %3696 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 3
  %3697 = load i32, ptr %3696, align 4
  %3698 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 4
  %3699 = load i32, ptr %3698, align 16
  %3700 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 5
  %3701 = load i32, ptr %3700, align 4
  %3702 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 6
  %3703 = load i32, ptr %3702, align 8
  %3704 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 7
  %3705 = load i32, ptr %3704, align 4
  %3706 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 8
  %3707 = load i32, ptr %3706, align 16
  %3708 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 9
  %3709 = load i32, ptr %3708, align 4
  %3710 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 10
  %3711 = load i32, ptr %3710, align 8
  %3712 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 11
  %3713 = load i32, ptr %3712, align 4
  %3714 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef %3691, i32 noundef %3693, i32 noundef %3695, i32 noundef %3697, i32 noundef %3699, i32 noundef %3701, i32 noundef %3703, i32 noundef %3705, i32 noundef %3707, i32 noundef %3709, i32 noundef %3711, i32 noundef %3713)
  %3715 = load i128, ptr %227, align 8
  %3716 = trunc i128 %3715 to i65
  %3717 = call i65 @llvm.ctlz.i65(i65 %3716, i1 true)
  %3718 = sub i65 64, %3717
  %3719 = shl i65 1, %3718
  %3720 = icmp eq i65 %3716, 0
  %3721 = select i1 %3720, i65 0, i65 %3719
  %3722 = zext i65 %3721 to i128
  store i128 %3722, ptr %229, align 8
  %3723 = load i128, ptr %227, align 8
  %3724 = trunc i128 %3723 to i65
  %3725 = icmp ule i65 %3724, 1
  br i1 %3725, label %3731, label %3726

3726:                                             ; preds = %3611
  %3727 = sub i65 %3724, 1
  %3728 = call i65 @llvm.ctlz.i65(i65 %3727, i1 false)
  %3729 = sub i65 64, %3728
  %3730 = shl i65 2, %3729
  br label %3731

3731:                                             ; preds = %3726, %3611
  %3732 = phi i65 [ 1, %3611 ], [ %3730, %3726 ]
  %3733 = zext i65 %3732 to i128
  store i128 %3733, ptr %230, align 8
  %3734 = load i128, ptr %227, align 8
  %3735 = trunc i128 %3734 to i65
  %3736 = call i65 @llvm.fshl.i65(i65 %3735, i65 %3735, i65 3)
  %3737 = zext i65 %3736 to i128
  store i128 %3737, ptr %231, align 8
  %3738 = load i128, ptr %227, align 8
  %3739 = trunc i128 %3738 to i65
  %3740 = call i65 @llvm.fshr.i65(i65 %3739, i65 %3739, i65 3)
  %3741 = zext i65 %3740 to i128
  store i128 %3741, ptr %232, align 8
  %3742 = load i128, ptr %227, align 8
  %3743 = trunc i128 %3742 to i65
  %3744 = call i65 @llvm.fshl.i65(i65 %3743, i65 %3743, i65 0)
  %3745 = zext i65 %3744 to i128
  store i128 %3745, ptr %233, align 8
  %3746 = load i128, ptr %227, align 8
  %3747 = trunc i128 %3746 to i65
  %3748 = call i65 @llvm.fshl.i65(i65 %3747, i65 %3747, i65 25)
  %3749 = zext i65 %3748 to i128
  store i128 %3749, ptr %234, align 8
  %3750 = load i128, ptr %229, align 8
  %3751 = trunc i128 %3750 to i65
  %3752 = zext i65 %3751 to i256
  %3753 = lshr i256 %3752, 128
  %3754 = trunc i256 %3753 to i64
  %3755 = load i128, ptr %229, align 8
  %3756 = trunc i128 %3755 to i65
  %3757 = zext i65 %3756 to i256
  %3758 = lshr i256 %3757, 64
  %3759 = trunc i256 %3758 to i64
  %3760 = load i128, ptr %229, align 8
  %3761 = trunc i128 %3760 to i65
  %3762 = trunc i65 %3761 to i64
  %3763 = load i128, ptr %230, align 8
  %3764 = trunc i128 %3763 to i65
  %3765 = zext i65 %3764 to i256
  %3766 = lshr i256 %3765, 128
  %3767 = trunc i256 %3766 to i64
  %3768 = load i128, ptr %230, align 8
  %3769 = trunc i128 %3768 to i65
  %3770 = zext i65 %3769 to i256
  %3771 = lshr i256 %3770, 64
  %3772 = trunc i256 %3771 to i64
  %3773 = load i128, ptr %230, align 8
  %3774 = trunc i128 %3773 to i65
  %3775 = trunc i65 %3774 to i64
  %3776 = load i128, ptr %231, align 8
  %3777 = trunc i128 %3776 to i65
  %3778 = zext i65 %3777 to i256
  %3779 = lshr i256 %3778, 128
  %3780 = trunc i256 %3779 to i64
  %3781 = load i128, ptr %231, align 8
  %3782 = trunc i128 %3781 to i65
  %3783 = zext i65 %3782 to i256
  %3784 = lshr i256 %3783, 64
  %3785 = trunc i256 %3784 to i64
  %3786 = load i128, ptr %231, align 8
  %3787 = trunc i128 %3786 to i65
  %3788 = trunc i65 %3787 to i64
  %3789 = load i128, ptr %232, align 8
  %3790 = trunc i128 %3789 to i65
  %3791 = zext i65 %3790 to i256
  %3792 = lshr i256 %3791, 128
  %3793 = trunc i256 %3792 to i64
  %3794 = load i128, ptr %232, align 8
  %3795 = trunc i128 %3794 to i65
  %3796 = zext i65 %3795 to i256
  %3797 = lshr i256 %3796, 64
  %3798 = trunc i256 %3797 to i64
  %3799 = load i128, ptr %232, align 8
  %3800 = trunc i128 %3799 to i65
  %3801 = trunc i65 %3800 to i64
  %3802 = load i128, ptr %233, align 8
  %3803 = trunc i128 %3802 to i65
  %3804 = trunc i65 %3803 to i64
  %3805 = load i128, ptr %234, align 8
  %3806 = trunc i128 %3805 to i65
  %3807 = trunc i65 %3806 to i64
  %3808 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %3754, i64 noundef %3759, i64 noundef %3762, i64 noundef %3767, i64 noundef %3772, i64 noundef %3775, i64 noundef %3780, i64 noundef %3785, i64 noundef %3788, i64 noundef %3793, i64 noundef %3798, i64 noundef %3801, i64 noundef %3804, i64 noundef %3807)
  %3809 = load i128, ptr %227, align 8
  %3810 = trunc i128 %3809 to i65
  %3811 = zext i65 %3810 to i575
  %3812 = getelementptr inbounds [12 x i32], ptr %228, i64 0, i64 0
  %3813 = load i128, ptr %229, align 8
  %3814 = trunc i128 %3813 to i65
  %3815 = zext i65 %3814 to i575
  %3816 = load i128, ptr %230, align 8
  %3817 = trunc i128 %3816 to i65
  %3818 = zext i65 %3817 to i575
  %3819 = load i128, ptr %231, align 8
  %3820 = trunc i128 %3819 to i65
  %3821 = zext i65 %3820 to i575
  %3822 = load i128, ptr %232, align 8
  %3823 = trunc i128 %3822 to i65
  %3824 = zext i65 %3823 to i575
  %3825 = load i128, ptr %233, align 8
  %3826 = trunc i128 %3825 to i65
  %3827 = zext i65 %3826 to i575
  %3828 = load i128, ptr %234, align 8
  %3829 = trunc i128 %3828 to i65
  %3830 = zext i65 %3829 to i575
  %3831 = zext i575 %3811 to i576
  store i576 %3831, ptr %235, align 8
  %3832 = zext i575 %3815 to i576
  store i576 %3832, ptr %236, align 8
  %3833 = zext i575 %3818 to i576
  store i576 %3833, ptr %237, align 8
  %3834 = zext i575 %3821 to i576
  store i576 %3834, ptr %238, align 8
  %3835 = zext i575 %3824 to i576
  store i576 %3835, ptr %239, align 8
  %3836 = zext i575 %3827 to i576
  store i576 %3836, ptr %240, align 8
  %3837 = zext i575 %3830 to i576
  store i576 %3837, ptr %241, align 8
  call void @check(ptr noundef @.str.9, i32 noundef 65, ptr noundef byval([72 x i8]) align 8 %235, ptr noundef %3812, ptr noundef byval([72 x i8]) align 8 %236, ptr noundef byval([72 x i8]) align 8 %237, ptr noundef byval([72 x i8]) align 8 %238, ptr noundef byval([72 x i8]) align 8 %239, ptr noundef byval([72 x i8]) align 8 %240, ptr noundef byval([72 x i8]) align 8 %241)
  br label %3838

3838:                                             ; preds = %3731
  br label %3839

3839:                                             ; preds = %3838
  store i192 1, ptr %242, align 8
  %3840 = load i192, ptr %242, align 8
  %3841 = trunc i192 %3840 to i129
  %3842 = call i129 @llvm.ctlz.i129(i129 %3841, i1 false)
  %3843 = trunc i129 %3842 to i32
  store i32 %3843, ptr %243, align 4
  %3844 = getelementptr inbounds i32, ptr %243, i64 1
  %3845 = load i192, ptr %242, align 8
  %3846 = trunc i192 %3845 to i129
  %3847 = xor i129 %3846, -1
  %3848 = call i129 @llvm.ctlz.i129(i129 %3847, i1 false)
  %3849 = trunc i129 %3848 to i32
  store i32 %3849, ptr %3844, align 4
  %3850 = getelementptr inbounds i32, ptr %243, i64 2
  %3851 = load i192, ptr %242, align 8
  %3852 = trunc i192 %3851 to i129
  %3853 = call i129 @llvm.cttz.i129(i129 %3852, i1 false)
  %3854 = trunc i129 %3853 to i32
  store i32 %3854, ptr %3850, align 4
  %3855 = getelementptr inbounds i32, ptr %243, i64 3
  %3856 = load i192, ptr %242, align 8
  %3857 = trunc i192 %3856 to i129
  %3858 = xor i129 %3857, -1
  %3859 = call i129 @llvm.cttz.i129(i129 %3858, i1 false)
  %3860 = trunc i129 %3859 to i32
  store i32 %3860, ptr %3855, align 4
  %3861 = getelementptr inbounds i32, ptr %243, i64 4
  %3862 = load i192, ptr %242, align 8
  %3863 = trunc i192 %3862 to i129
  %3864 = xor i129 %3863, -1
  %3865 = call i129 @llvm.ctlz.i129(i129 %3864, i1 false)
  %3866 = add i129 %3865, 1
  %3867 = icmp eq i129 %3864, 0
  %3868 = select i1 %3867, i129 0, i129 %3866
  %3869 = trunc i129 %3868 to i32
  store i32 %3869, ptr %3861, align 4
  %3870 = getelementptr inbounds i32, ptr %243, i64 5
  %3871 = load i192, ptr %242, align 8
  %3872 = trunc i192 %3871 to i129
  %3873 = call i129 @llvm.ctlz.i129(i129 %3872, i1 false)
  %3874 = add i129 %3873, 1
  %3875 = icmp eq i129 %3872, 0
  %3876 = select i1 %3875, i129 0, i129 %3874
  %3877 = trunc i129 %3876 to i32
  store i32 %3877, ptr %3870, align 4
  %3878 = getelementptr inbounds i32, ptr %243, i64 6
  %3879 = load i192, ptr %242, align 8
  %3880 = trunc i192 %3879 to i129
  %3881 = xor i129 %3880, -1
  %3882 = call i129 @llvm.cttz.i129(i129 %3881, i1 false)
  %3883 = add i129 %3882, 1
  %3884 = icmp eq i129 %3881, 0
  %3885 = select i1 %3884, i129 0, i129 %3883
  %3886 = trunc i129 %3885 to i32
  store i32 %3886, ptr %3878, align 4
  %3887 = getelementptr inbounds i32, ptr %243, i64 7
  %3888 = load i192, ptr %242, align 8
  %3889 = trunc i192 %3888 to i129
  %3890 = call i129 @llvm.cttz.i129(i129 %3889, i1 false)
  %3891 = add i129 %3890, 1
  %3892 = icmp eq i129 %3889, 0
  %3893 = select i1 %3892, i129 0, i129 %3891
  %3894 = trunc i129 %3893 to i32
  store i32 %3894, ptr %3887, align 4
  %3895 = getelementptr inbounds i32, ptr %243, i64 8
  %3896 = load i192, ptr %242, align 8
  %3897 = trunc i192 %3896 to i129
  %3898 = call i129 @llvm.ctpop.i129(i129 %3897)
  %3899 = sub i129 129, %3898
  %3900 = trunc i129 %3899 to i32
  store i32 %3900, ptr %3895, align 4
  %3901 = getelementptr inbounds i32, ptr %243, i64 9
  %3902 = load i192, ptr %242, align 8
  %3903 = trunc i192 %3902 to i129
  %3904 = call i129 @llvm.ctpop.i129(i129 %3903)
  %3905 = trunc i129 %3904 to i32
  store i32 %3905, ptr %3901, align 4
  %3906 = getelementptr inbounds i32, ptr %243, i64 10
  %3907 = load i192, ptr %242, align 8
  %3908 = trunc i192 %3907 to i129
  %3909 = call i129 @llvm.ctpop.i129(i129 %3908)
  %3910 = icmp eq i129 %3909, 1
  %3911 = zext i1 %3910 to i32
  store i32 %3911, ptr %3906, align 4
  %3912 = getelementptr inbounds i32, ptr %243, i64 11
  %3913 = load i192, ptr %242, align 8
  %3914 = trunc i192 %3913 to i129
  %3915 = call i129 @llvm.ctlz.i129(i129 %3914, i1 false)
  %3916 = sub i129 129, %3915
  %3917 = trunc i129 %3916 to i32
  store i32 %3917, ptr %3912, align 4
  %3918 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 0
  %3919 = load i32, ptr %3918, align 16
  %3920 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 1
  %3921 = load i32, ptr %3920, align 4
  %3922 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 2
  %3923 = load i32, ptr %3922, align 8
  %3924 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 3
  %3925 = load i32, ptr %3924, align 4
  %3926 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 4
  %3927 = load i32, ptr %3926, align 16
  %3928 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 5
  %3929 = load i32, ptr %3928, align 4
  %3930 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 6
  %3931 = load i32, ptr %3930, align 8
  %3932 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 7
  %3933 = load i32, ptr %3932, align 4
  %3934 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 8
  %3935 = load i32, ptr %3934, align 16
  %3936 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 9
  %3937 = load i32, ptr %3936, align 4
  %3938 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 10
  %3939 = load i32, ptr %3938, align 8
  %3940 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 11
  %3941 = load i32, ptr %3940, align 4
  %3942 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %3919, i32 noundef %3921, i32 noundef %3923, i32 noundef %3925, i32 noundef %3927, i32 noundef %3929, i32 noundef %3931, i32 noundef %3933, i32 noundef %3935, i32 noundef %3937, i32 noundef %3939, i32 noundef %3941)
  %3943 = load i192, ptr %242, align 8
  %3944 = trunc i192 %3943 to i129
  %3945 = call i129 @llvm.ctlz.i129(i129 %3944, i1 true)
  %3946 = sub i129 128, %3945
  %3947 = shl i129 1, %3946
  %3948 = icmp eq i129 %3944, 0
  %3949 = select i1 %3948, i129 0, i129 %3947
  %3950 = zext i129 %3949 to i192
  store i192 %3950, ptr %244, align 8
  %3951 = load i192, ptr %242, align 8
  %3952 = trunc i192 %3951 to i129
  %3953 = icmp ule i129 %3952, 1
  br i1 %3953, label %3959, label %3954

3954:                                             ; preds = %3839
  %3955 = sub i129 %3952, 1
  %3956 = call i129 @llvm.ctlz.i129(i129 %3955, i1 false)
  %3957 = sub i129 128, %3956
  %3958 = shl i129 2, %3957
  br label %3959

3959:                                             ; preds = %3954, %3839
  %3960 = phi i129 [ 1, %3839 ], [ %3958, %3954 ]
  %3961 = zext i129 %3960 to i192
  store i192 %3961, ptr %245, align 8
  %3962 = load i192, ptr %242, align 8
  %3963 = trunc i192 %3962 to i129
  %3964 = call i129 @llvm.fshl.i129(i129 %3963, i129 %3963, i129 3)
  %3965 = zext i129 %3964 to i192
  store i192 %3965, ptr %246, align 8
  %3966 = load i192, ptr %242, align 8
  %3967 = trunc i192 %3966 to i129
  %3968 = call i129 @llvm.fshr.i129(i129 %3967, i129 %3967, i129 3)
  %3969 = zext i129 %3968 to i192
  store i192 %3969, ptr %247, align 8
  %3970 = load i192, ptr %242, align 8
  %3971 = trunc i192 %3970 to i129
  %3972 = call i129 @llvm.fshl.i129(i129 %3971, i129 %3971, i129 0)
  %3973 = zext i129 %3972 to i192
  store i192 %3973, ptr %248, align 8
  %3974 = load i192, ptr %242, align 8
  %3975 = trunc i192 %3974 to i129
  %3976 = call i129 @llvm.fshl.i129(i129 %3975, i129 %3975, i129 97)
  %3977 = zext i129 %3976 to i192
  store i192 %3977, ptr %249, align 8
  %3978 = load i192, ptr %244, align 8
  %3979 = trunc i192 %3978 to i129
  %3980 = zext i129 %3979 to i256
  %3981 = lshr i256 %3980, 128
  %3982 = trunc i256 %3981 to i64
  %3983 = load i192, ptr %244, align 8
  %3984 = trunc i192 %3983 to i129
  %3985 = zext i129 %3984 to i256
  %3986 = lshr i256 %3985, 64
  %3987 = trunc i256 %3986 to i64
  %3988 = load i192, ptr %244, align 8
  %3989 = trunc i192 %3988 to i129
  %3990 = trunc i129 %3989 to i64
  %3991 = load i192, ptr %245, align 8
  %3992 = trunc i192 %3991 to i129
  %3993 = zext i129 %3992 to i256
  %3994 = lshr i256 %3993, 128
  %3995 = trunc i256 %3994 to i64
  %3996 = load i192, ptr %245, align 8
  %3997 = trunc i192 %3996 to i129
  %3998 = zext i129 %3997 to i256
  %3999 = lshr i256 %3998, 64
  %4000 = trunc i256 %3999 to i64
  %4001 = load i192, ptr %245, align 8
  %4002 = trunc i192 %4001 to i129
  %4003 = trunc i129 %4002 to i64
  %4004 = load i192, ptr %246, align 8
  %4005 = trunc i192 %4004 to i129
  %4006 = zext i129 %4005 to i256
  %4007 = lshr i256 %4006, 128
  %4008 = trunc i256 %4007 to i64
  %4009 = load i192, ptr %246, align 8
  %4010 = trunc i192 %4009 to i129
  %4011 = zext i129 %4010 to i256
  %4012 = lshr i256 %4011, 64
  %4013 = trunc i256 %4012 to i64
  %4014 = load i192, ptr %246, align 8
  %4015 = trunc i192 %4014 to i129
  %4016 = trunc i129 %4015 to i64
  %4017 = load i192, ptr %247, align 8
  %4018 = trunc i192 %4017 to i129
  %4019 = zext i129 %4018 to i256
  %4020 = lshr i256 %4019, 128
  %4021 = trunc i256 %4020 to i64
  %4022 = load i192, ptr %247, align 8
  %4023 = trunc i192 %4022 to i129
  %4024 = zext i129 %4023 to i256
  %4025 = lshr i256 %4024, 64
  %4026 = trunc i256 %4025 to i64
  %4027 = load i192, ptr %247, align 8
  %4028 = trunc i192 %4027 to i129
  %4029 = trunc i129 %4028 to i64
  %4030 = load i192, ptr %248, align 8
  %4031 = trunc i192 %4030 to i129
  %4032 = trunc i129 %4031 to i64
  %4033 = load i192, ptr %249, align 8
  %4034 = trunc i192 %4033 to i129
  %4035 = trunc i129 %4034 to i64
  %4036 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %3982, i64 noundef %3987, i64 noundef %3990, i64 noundef %3995, i64 noundef %4000, i64 noundef %4003, i64 noundef %4008, i64 noundef %4013, i64 noundef %4016, i64 noundef %4021, i64 noundef %4026, i64 noundef %4029, i64 noundef %4032, i64 noundef %4035)
  %4037 = load i192, ptr %242, align 8
  %4038 = trunc i192 %4037 to i129
  %4039 = zext i129 %4038 to i575
  %4040 = getelementptr inbounds [12 x i32], ptr %243, i64 0, i64 0
  %4041 = load i192, ptr %244, align 8
  %4042 = trunc i192 %4041 to i129
  %4043 = zext i129 %4042 to i575
  %4044 = load i192, ptr %245, align 8
  %4045 = trunc i192 %4044 to i129
  %4046 = zext i129 %4045 to i575
  %4047 = load i192, ptr %246, align 8
  %4048 = trunc i192 %4047 to i129
  %4049 = zext i129 %4048 to i575
  %4050 = load i192, ptr %247, align 8
  %4051 = trunc i192 %4050 to i129
  %4052 = zext i129 %4051 to i575
  %4053 = load i192, ptr %248, align 8
  %4054 = trunc i192 %4053 to i129
  %4055 = zext i129 %4054 to i575
  %4056 = load i192, ptr %249, align 8
  %4057 = trunc i192 %4056 to i129
  %4058 = zext i129 %4057 to i575
  %4059 = zext i575 %4039 to i576
  store i576 %4059, ptr %250, align 8
  %4060 = zext i575 %4043 to i576
  store i576 %4060, ptr %251, align 8
  %4061 = zext i575 %4046 to i576
  store i576 %4061, ptr %252, align 8
  %4062 = zext i575 %4049 to i576
  store i576 %4062, ptr %253, align 8
  %4063 = zext i575 %4052 to i576
  store i576 %4063, ptr %254, align 8
  %4064 = zext i575 %4055 to i576
  store i576 %4064, ptr %255, align 8
  %4065 = zext i575 %4058 to i576
  store i576 %4065, ptr %256, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %250, ptr noundef %4040, ptr noundef byval([72 x i8]) align 8 %251, ptr noundef byval([72 x i8]) align 8 %252, ptr noundef byval([72 x i8]) align 8 %253, ptr noundef byval([72 x i8]) align 8 %254, ptr noundef byval([72 x i8]) align 8 %255, ptr noundef byval([72 x i8]) align 8 %256)
  br label %4066

4066:                                             ; preds = %3959
  br label %4067

4067:                                             ; preds = %4066
  store i256 1, ptr %257, align 8
  %4068 = load i256, ptr %257, align 8
  %4069 = call i256 @llvm.ctlz.i256(i256 %4068, i1 false)
  %4070 = trunc i256 %4069 to i32
  store i32 %4070, ptr %258, align 4
  %4071 = getelementptr inbounds i32, ptr %258, i64 1
  %4072 = load i256, ptr %257, align 8
  %4073 = xor i256 %4072, -1
  %4074 = call i256 @llvm.ctlz.i256(i256 %4073, i1 false)
  %4075 = trunc i256 %4074 to i32
  store i32 %4075, ptr %4071, align 4
  %4076 = getelementptr inbounds i32, ptr %258, i64 2
  %4077 = load i256, ptr %257, align 8
  %4078 = call i256 @llvm.cttz.i256(i256 %4077, i1 false)
  %4079 = trunc i256 %4078 to i32
  store i32 %4079, ptr %4076, align 4
  %4080 = getelementptr inbounds i32, ptr %258, i64 3
  %4081 = load i256, ptr %257, align 8
  %4082 = xor i256 %4081, -1
  %4083 = call i256 @llvm.cttz.i256(i256 %4082, i1 false)
  %4084 = trunc i256 %4083 to i32
  store i32 %4084, ptr %4080, align 4
  %4085 = getelementptr inbounds i32, ptr %258, i64 4
  %4086 = load i256, ptr %257, align 8
  %4087 = xor i256 %4086, -1
  %4088 = call i256 @llvm.ctlz.i256(i256 %4087, i1 false)
  %4089 = add i256 %4088, 1
  %4090 = icmp eq i256 %4087, 0
  %4091 = select i1 %4090, i256 0, i256 %4089
  %4092 = trunc i256 %4091 to i32
  store i32 %4092, ptr %4085, align 4
  %4093 = getelementptr inbounds i32, ptr %258, i64 5
  %4094 = load i256, ptr %257, align 8
  %4095 = call i256 @llvm.ctlz.i256(i256 %4094, i1 false)
  %4096 = add i256 %4095, 1
  %4097 = icmp eq i256 %4094, 0
  %4098 = select i1 %4097, i256 0, i256 %4096
  %4099 = trunc i256 %4098 to i32
  store i32 %4099, ptr %4093, align 4
  %4100 = getelementptr inbounds i32, ptr %258, i64 6
  %4101 = load i256, ptr %257, align 8
  %4102 = xor i256 %4101, -1
  %4103 = call i256 @llvm.cttz.i256(i256 %4102, i1 false)
  %4104 = add i256 %4103, 1
  %4105 = icmp eq i256 %4102, 0
  %4106 = select i1 %4105, i256 0, i256 %4104
  %4107 = trunc i256 %4106 to i32
  store i32 %4107, ptr %4100, align 4
  %4108 = getelementptr inbounds i32, ptr %258, i64 7
  %4109 = load i256, ptr %257, align 8
  %4110 = call i256 @llvm.cttz.i256(i256 %4109, i1 false)
  %4111 = add i256 %4110, 1
  %4112 = icmp eq i256 %4109, 0
  %4113 = select i1 %4112, i256 0, i256 %4111
  %4114 = trunc i256 %4113 to i32
  store i32 %4114, ptr %4108, align 4
  %4115 = getelementptr inbounds i32, ptr %258, i64 8
  %4116 = load i256, ptr %257, align 8
  %4117 = call i256 @llvm.ctpop.i256(i256 %4116)
  %4118 = sub i256 256, %4117
  %4119 = trunc i256 %4118 to i32
  store i32 %4119, ptr %4115, align 4
  %4120 = getelementptr inbounds i32, ptr %258, i64 9
  %4121 = load i256, ptr %257, align 8
  %4122 = call i256 @llvm.ctpop.i256(i256 %4121)
  %4123 = trunc i256 %4122 to i32
  store i32 %4123, ptr %4120, align 4
  %4124 = getelementptr inbounds i32, ptr %258, i64 10
  %4125 = load i256, ptr %257, align 8
  %4126 = call i256 @llvm.ctpop.i256(i256 %4125)
  %4127 = icmp eq i256 %4126, 1
  %4128 = zext i1 %4127 to i32
  store i32 %4128, ptr %4124, align 4
  %4129 = getelementptr inbounds i32, ptr %258, i64 11
  %4130 = load i256, ptr %257, align 8
  %4131 = call i256 @llvm.ctlz.i256(i256 %4130, i1 false)
  %4132 = sub i256 256, %4131
  %4133 = trunc i256 %4132 to i32
  store i32 %4133, ptr %4129, align 4
  %4134 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 0
  %4135 = load i32, ptr %4134, align 16
  %4136 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 1
  %4137 = load i32, ptr %4136, align 4
  %4138 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 2
  %4139 = load i32, ptr %4138, align 8
  %4140 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 3
  %4141 = load i32, ptr %4140, align 4
  %4142 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 4
  %4143 = load i32, ptr %4142, align 16
  %4144 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 5
  %4145 = load i32, ptr %4144, align 4
  %4146 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 6
  %4147 = load i32, ptr %4146, align 8
  %4148 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 7
  %4149 = load i32, ptr %4148, align 4
  %4150 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 8
  %4151 = load i32, ptr %4150, align 16
  %4152 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 9
  %4153 = load i32, ptr %4152, align 4
  %4154 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 10
  %4155 = load i32, ptr %4154, align 8
  %4156 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 11
  %4157 = load i32, ptr %4156, align 4
  %4158 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %4135, i32 noundef %4137, i32 noundef %4139, i32 noundef %4141, i32 noundef %4143, i32 noundef %4145, i32 noundef %4147, i32 noundef %4149, i32 noundef %4151, i32 noundef %4153, i32 noundef %4155, i32 noundef %4157)
  %4159 = load i256, ptr %257, align 8
  %4160 = call i256 @llvm.ctlz.i256(i256 %4159, i1 true)
  %4161 = sub i256 255, %4160
  %4162 = shl i256 1, %4161
  %4163 = icmp eq i256 %4159, 0
  %4164 = select i1 %4163, i256 0, i256 %4162
  store i256 %4164, ptr %259, align 8
  %4165 = load i256, ptr %257, align 8
  %4166 = icmp ule i256 %4165, 1
  br i1 %4166, label %4172, label %4167

4167:                                             ; preds = %4067
  %4168 = sub i256 %4165, 1
  %4169 = call i256 @llvm.ctlz.i256(i256 %4168, i1 false)
  %4170 = sub i256 255, %4169
  %4171 = shl i256 2, %4170
  br label %4172

4172:                                             ; preds = %4167, %4067
  %4173 = phi i256 [ 1, %4067 ], [ %4171, %4167 ]
  store i256 %4173, ptr %260, align 8
  %4174 = load i256, ptr %257, align 8
  %4175 = call i256 @llvm.fshl.i256(i256 %4174, i256 %4174, i256 3)
  store i256 %4175, ptr %261, align 8
  %4176 = load i256, ptr %257, align 8
  %4177 = call i256 @llvm.fshr.i256(i256 %4176, i256 %4176, i256 3)
  store i256 %4177, ptr %262, align 8
  %4178 = load i256, ptr %257, align 8
  %4179 = call i256 @llvm.fshl.i256(i256 %4178, i256 %4178, i256 0)
  store i256 %4179, ptr %263, align 8
  %4180 = load i256, ptr %257, align 8
  %4181 = call i256 @llvm.fshl.i256(i256 %4180, i256 %4180, i256 232)
  store i256 %4181, ptr %264, align 8
  %4182 = load i256, ptr %259, align 8
  %4183 = lshr i256 %4182, 128
  %4184 = trunc i256 %4183 to i64
  %4185 = load i256, ptr %259, align 8
  %4186 = lshr i256 %4185, 64
  %4187 = trunc i256 %4186 to i64
  %4188 = load i256, ptr %259, align 8
  %4189 = trunc i256 %4188 to i64
  %4190 = load i256, ptr %260, align 8
  %4191 = lshr i256 %4190, 128
  %4192 = trunc i256 %4191 to i64
  %4193 = load i256, ptr %260, align 8
  %4194 = lshr i256 %4193, 64
  %4195 = trunc i256 %4194 to i64
  %4196 = load i256, ptr %260, align 8
  %4197 = trunc i256 %4196 to i64
  %4198 = load i256, ptr %261, align 8
  %4199 = lshr i256 %4198, 128
  %4200 = trunc i256 %4199 to i64
  %4201 = load i256, ptr %261, align 8
  %4202 = lshr i256 %4201, 64
  %4203 = trunc i256 %4202 to i64
  %4204 = load i256, ptr %261, align 8
  %4205 = trunc i256 %4204 to i64
  %4206 = load i256, ptr %262, align 8
  %4207 = lshr i256 %4206, 128
  %4208 = trunc i256 %4207 to i64
  %4209 = load i256, ptr %262, align 8
  %4210 = lshr i256 %4209, 64
  %4211 = trunc i256 %4210 to i64
  %4212 = load i256, ptr %262, align 8
  %4213 = trunc i256 %4212 to i64
  %4214 = load i256, ptr %263, align 8
  %4215 = trunc i256 %4214 to i64
  %4216 = load i256, ptr %264, align 8
  %4217 = trunc i256 %4216 to i64
  %4218 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %4184, i64 noundef %4187, i64 noundef %4189, i64 noundef %4192, i64 noundef %4195, i64 noundef %4197, i64 noundef %4200, i64 noundef %4203, i64 noundef %4205, i64 noundef %4208, i64 noundef %4211, i64 noundef %4213, i64 noundef %4215, i64 noundef %4217)
  %4219 = load i256, ptr %257, align 8
  %4220 = zext i256 %4219 to i575
  %4221 = getelementptr inbounds [12 x i32], ptr %258, i64 0, i64 0
  %4222 = load i256, ptr %259, align 8
  %4223 = zext i256 %4222 to i575
  %4224 = load i256, ptr %260, align 8
  %4225 = zext i256 %4224 to i575
  %4226 = load i256, ptr %261, align 8
  %4227 = zext i256 %4226 to i575
  %4228 = load i256, ptr %262, align 8
  %4229 = zext i256 %4228 to i575
  %4230 = load i256, ptr %263, align 8
  %4231 = zext i256 %4230 to i575
  %4232 = load i256, ptr %264, align 8
  %4233 = zext i256 %4232 to i575
  %4234 = zext i575 %4220 to i576
  store i576 %4234, ptr %265, align 8
  %4235 = zext i575 %4223 to i576
  store i576 %4235, ptr %266, align 8
  %4236 = zext i575 %4225 to i576
  store i576 %4236, ptr %267, align 8
  %4237 = zext i575 %4227 to i576
  store i576 %4237, ptr %268, align 8
  %4238 = zext i575 %4229 to i576
  store i576 %4238, ptr %269, align 8
  %4239 = zext i575 %4231 to i576
  store i576 %4239, ptr %270, align 8
  %4240 = zext i575 %4233 to i576
  store i576 %4240, ptr %271, align 8
  call void @check(ptr noundef @.str.11, i32 noundef 256, ptr noundef byval([72 x i8]) align 8 %265, ptr noundef %4221, ptr noundef byval([72 x i8]) align 8 %266, ptr noundef byval([72 x i8]) align 8 %267, ptr noundef byval([72 x i8]) align 8 %268, ptr noundef byval([72 x i8]) align 8 %269, ptr noundef byval([72 x i8]) align 8 %270, ptr noundef byval([72 x i8]) align 8 %271)
  br label %4241

4241:                                             ; preds = %4172
  %4242 = call i32 @puts(ptr noundef @.str.13)
  br label %4243

4243:                                             ; preds = %4241
  store i8 -1, ptr %272, align 1
  %4244 = load i8, ptr %272, align 1
  %4245 = call i8 @llvm.ctlz.i8(i8 %4244, i1 false)
  %4246 = zext i8 %4245 to i32
  store i32 %4246, ptr %273, align 4
  %4247 = getelementptr inbounds i32, ptr %273, i64 1
  %4248 = load i8, ptr %272, align 1
  %4249 = xor i8 %4248, -1
  %4250 = call i8 @llvm.ctlz.i8(i8 %4249, i1 false)
  %4251 = zext i8 %4250 to i32
  store i32 %4251, ptr %4247, align 4
  %4252 = getelementptr inbounds i32, ptr %273, i64 2
  %4253 = load i8, ptr %272, align 1
  %4254 = call i8 @llvm.cttz.i8(i8 %4253, i1 false)
  %4255 = zext i8 %4254 to i32
  store i32 %4255, ptr %4252, align 4
  %4256 = getelementptr inbounds i32, ptr %273, i64 3
  %4257 = load i8, ptr %272, align 1
  %4258 = xor i8 %4257, -1
  %4259 = call i8 @llvm.cttz.i8(i8 %4258, i1 false)
  %4260 = zext i8 %4259 to i32
  store i32 %4260, ptr %4256, align 4
  %4261 = getelementptr inbounds i32, ptr %273, i64 4
  %4262 = load i8, ptr %272, align 1
  %4263 = xor i8 %4262, -1
  %4264 = call i8 @llvm.ctlz.i8(i8 %4263, i1 false)
  %4265 = add i8 %4264, 1
  %4266 = icmp eq i8 %4263, 0
  %4267 = select i1 %4266, i8 0, i8 %4265
  %4268 = zext i8 %4267 to i32
  store i32 %4268, ptr %4261, align 4
  %4269 = getelementptr inbounds i32, ptr %273, i64 5
  %4270 = load i8, ptr %272, align 1
  %4271 = call i8 @llvm.ctlz.i8(i8 %4270, i1 false)
  %4272 = add i8 %4271, 1
  %4273 = icmp eq i8 %4270, 0
  %4274 = select i1 %4273, i8 0, i8 %4272
  %4275 = zext i8 %4274 to i32
  store i32 %4275, ptr %4269, align 4
  %4276 = getelementptr inbounds i32, ptr %273, i64 6
  %4277 = load i8, ptr %272, align 1
  %4278 = xor i8 %4277, -1
  %4279 = call i8 @llvm.cttz.i8(i8 %4278, i1 false)
  %4280 = add i8 %4279, 1
  %4281 = icmp eq i8 %4278, 0
  %4282 = select i1 %4281, i8 0, i8 %4280
  %4283 = zext i8 %4282 to i32
  store i32 %4283, ptr %4276, align 4
  %4284 = getelementptr inbounds i32, ptr %273, i64 7
  %4285 = load i8, ptr %272, align 1
  %4286 = call i8 @llvm.cttz.i8(i8 %4285, i1 false)
  %4287 = add i8 %4286, 1
  %4288 = icmp eq i8 %4285, 0
  %4289 = select i1 %4288, i8 0, i8 %4287
  %4290 = zext i8 %4289 to i32
  store i32 %4290, ptr %4284, align 4
  %4291 = getelementptr inbounds i32, ptr %273, i64 8
  %4292 = load i8, ptr %272, align 1
  %4293 = call i8 @llvm.ctpop.i8(i8 %4292)
  %4294 = sub i8 8, %4293
  %4295 = zext i8 %4294 to i32
  store i32 %4295, ptr %4291, align 4
  %4296 = getelementptr inbounds i32, ptr %273, i64 9
  %4297 = load i8, ptr %272, align 1
  %4298 = call i8 @llvm.ctpop.i8(i8 %4297)
  %4299 = zext i8 %4298 to i32
  store i32 %4299, ptr %4296, align 4
  %4300 = getelementptr inbounds i32, ptr %273, i64 10
  %4301 = load i8, ptr %272, align 1
  %4302 = call i8 @llvm.ctpop.i8(i8 %4301)
  %4303 = icmp eq i8 %4302, 1
  %4304 = zext i1 %4303 to i32
  store i32 %4304, ptr %4300, align 4
  %4305 = getelementptr inbounds i32, ptr %273, i64 11
  %4306 = load i8, ptr %272, align 1
  %4307 = call i8 @llvm.ctlz.i8(i8 %4306, i1 false)
  %4308 = sub i8 8, %4307
  %4309 = zext i8 %4308 to i32
  store i32 %4309, ptr %4305, align 4
  %4310 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 0
  %4311 = load i32, ptr %4310, align 16
  %4312 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 1
  %4313 = load i32, ptr %4312, align 4
  %4314 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 2
  %4315 = load i32, ptr %4314, align 8
  %4316 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 3
  %4317 = load i32, ptr %4316, align 4
  %4318 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 4
  %4319 = load i32, ptr %4318, align 16
  %4320 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 5
  %4321 = load i32, ptr %4320, align 4
  %4322 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 6
  %4323 = load i32, ptr %4322, align 8
  %4324 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 7
  %4325 = load i32, ptr %4324, align 4
  %4326 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 8
  %4327 = load i32, ptr %4326, align 16
  %4328 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 9
  %4329 = load i32, ptr %4328, align 4
  %4330 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 10
  %4331 = load i32, ptr %4330, align 8
  %4332 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 11
  %4333 = load i32, ptr %4332, align 4
  %4334 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %4311, i32 noundef %4313, i32 noundef %4315, i32 noundef %4317, i32 noundef %4319, i32 noundef %4321, i32 noundef %4323, i32 noundef %4325, i32 noundef %4327, i32 noundef %4329, i32 noundef %4331, i32 noundef %4333)
  %4335 = load i8, ptr %272, align 1
  %4336 = call i8 @llvm.ctlz.i8(i8 %4335, i1 true)
  %4337 = sub i8 7, %4336
  %4338 = shl i8 1, %4337
  %4339 = icmp eq i8 %4335, 0
  %4340 = select i1 %4339, i8 0, i8 %4338
  store i8 %4340, ptr %274, align 1
  %4341 = load i8, ptr %272, align 1
  %4342 = icmp ule i8 %4341, 1
  br i1 %4342, label %4348, label %4343

4343:                                             ; preds = %4243
  %4344 = sub i8 %4341, 1
  %4345 = call i8 @llvm.ctlz.i8(i8 %4344, i1 false)
  %4346 = sub i8 7, %4345
  %4347 = shl i8 2, %4346
  br label %4348

4348:                                             ; preds = %4343, %4243
  %4349 = phi i8 [ 1, %4243 ], [ %4347, %4343 ]
  store i8 %4349, ptr %275, align 1
  %4350 = load i8, ptr %272, align 1
  %4351 = call i8 @llvm.fshl.i8(i8 %4350, i8 %4350, i8 3)
  store i8 %4351, ptr %276, align 1
  %4352 = load i8, ptr %272, align 1
  %4353 = call i8 @llvm.fshr.i8(i8 %4352, i8 %4352, i8 3)
  store i8 %4353, ptr %277, align 1
  %4354 = load i8, ptr %272, align 1
  %4355 = call i8 @llvm.fshl.i8(i8 %4354, i8 %4354, i8 0)
  store i8 %4355, ptr %278, align 1
  %4356 = load i8, ptr %272, align 1
  %4357 = call i8 @llvm.fshl.i8(i8 %4356, i8 %4356, i8 0)
  store i8 %4357, ptr %279, align 1
  %4358 = load i8, ptr %274, align 1
  %4359 = zext i8 %4358 to i256
  %4360 = lshr i256 %4359, 128
  %4361 = trunc i256 %4360 to i64
  %4362 = load i8, ptr %274, align 1
  %4363 = zext i8 %4362 to i256
  %4364 = lshr i256 %4363, 64
  %4365 = trunc i256 %4364 to i64
  %4366 = load i8, ptr %274, align 1
  %4367 = zext i8 %4366 to i64
  %4368 = load i8, ptr %275, align 1
  %4369 = zext i8 %4368 to i256
  %4370 = lshr i256 %4369, 128
  %4371 = trunc i256 %4370 to i64
  %4372 = load i8, ptr %275, align 1
  %4373 = zext i8 %4372 to i256
  %4374 = lshr i256 %4373, 64
  %4375 = trunc i256 %4374 to i64
  %4376 = load i8, ptr %275, align 1
  %4377 = zext i8 %4376 to i64
  %4378 = load i8, ptr %276, align 1
  %4379 = zext i8 %4378 to i256
  %4380 = lshr i256 %4379, 128
  %4381 = trunc i256 %4380 to i64
  %4382 = load i8, ptr %276, align 1
  %4383 = zext i8 %4382 to i256
  %4384 = lshr i256 %4383, 64
  %4385 = trunc i256 %4384 to i64
  %4386 = load i8, ptr %276, align 1
  %4387 = zext i8 %4386 to i64
  %4388 = load i8, ptr %277, align 1
  %4389 = zext i8 %4388 to i256
  %4390 = lshr i256 %4389, 128
  %4391 = trunc i256 %4390 to i64
  %4392 = load i8, ptr %277, align 1
  %4393 = zext i8 %4392 to i256
  %4394 = lshr i256 %4393, 64
  %4395 = trunc i256 %4394 to i64
  %4396 = load i8, ptr %277, align 1
  %4397 = zext i8 %4396 to i64
  %4398 = load i8, ptr %278, align 1
  %4399 = zext i8 %4398 to i64
  %4400 = load i8, ptr %279, align 1
  %4401 = zext i8 %4400 to i64
  %4402 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %4361, i64 noundef %4365, i64 noundef %4367, i64 noundef %4371, i64 noundef %4375, i64 noundef %4377, i64 noundef %4381, i64 noundef %4385, i64 noundef %4387, i64 noundef %4391, i64 noundef %4395, i64 noundef %4397, i64 noundef %4399, i64 noundef %4401)
  %4403 = load i8, ptr %272, align 1
  %4404 = zext i8 %4403 to i575
  %4405 = getelementptr inbounds [12 x i32], ptr %273, i64 0, i64 0
  %4406 = load i8, ptr %274, align 1
  %4407 = zext i8 %4406 to i575
  %4408 = load i8, ptr %275, align 1
  %4409 = zext i8 %4408 to i575
  %4410 = load i8, ptr %276, align 1
  %4411 = zext i8 %4410 to i575
  %4412 = load i8, ptr %277, align 1
  %4413 = zext i8 %4412 to i575
  %4414 = load i8, ptr %278, align 1
  %4415 = zext i8 %4414 to i575
  %4416 = load i8, ptr %279, align 1
  %4417 = zext i8 %4416 to i575
  %4418 = zext i575 %4404 to i576
  store i576 %4418, ptr %280, align 8
  %4419 = zext i575 %4407 to i576
  store i576 %4419, ptr %281, align 8
  %4420 = zext i575 %4409 to i576
  store i576 %4420, ptr %282, align 8
  %4421 = zext i575 %4411 to i576
  store i576 %4421, ptr %283, align 8
  %4422 = zext i575 %4413 to i576
  store i576 %4422, ptr %284, align 8
  %4423 = zext i575 %4415 to i576
  store i576 %4423, ptr %285, align 8
  %4424 = zext i575 %4417 to i576
  store i576 %4424, ptr %286, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %280, ptr noundef %4405, ptr noundef byval([72 x i8]) align 8 %281, ptr noundef byval([72 x i8]) align 8 %282, ptr noundef byval([72 x i8]) align 8 %283, ptr noundef byval([72 x i8]) align 8 %284, ptr noundef byval([72 x i8]) align 8 %285, ptr noundef byval([72 x i8]) align 8 %286)
  br label %4425

4425:                                             ; preds = %4348
  br label %4426

4426:                                             ; preds = %4425
  store i16 -1, ptr %287, align 2
  %4427 = load i16, ptr %287, align 2
  %4428 = call i16 @llvm.ctlz.i16(i16 %4427, i1 false)
  %4429 = zext i16 %4428 to i32
  store i32 %4429, ptr %288, align 4
  %4430 = getelementptr inbounds i32, ptr %288, i64 1
  %4431 = load i16, ptr %287, align 2
  %4432 = xor i16 %4431, -1
  %4433 = call i16 @llvm.ctlz.i16(i16 %4432, i1 false)
  %4434 = zext i16 %4433 to i32
  store i32 %4434, ptr %4430, align 4
  %4435 = getelementptr inbounds i32, ptr %288, i64 2
  %4436 = load i16, ptr %287, align 2
  %4437 = call i16 @llvm.cttz.i16(i16 %4436, i1 false)
  %4438 = zext i16 %4437 to i32
  store i32 %4438, ptr %4435, align 4
  %4439 = getelementptr inbounds i32, ptr %288, i64 3
  %4440 = load i16, ptr %287, align 2
  %4441 = xor i16 %4440, -1
  %4442 = call i16 @llvm.cttz.i16(i16 %4441, i1 false)
  %4443 = zext i16 %4442 to i32
  store i32 %4443, ptr %4439, align 4
  %4444 = getelementptr inbounds i32, ptr %288, i64 4
  %4445 = load i16, ptr %287, align 2
  %4446 = xor i16 %4445, -1
  %4447 = call i16 @llvm.ctlz.i16(i16 %4446, i1 false)
  %4448 = add i16 %4447, 1
  %4449 = icmp eq i16 %4446, 0
  %4450 = select i1 %4449, i16 0, i16 %4448
  %4451 = zext i16 %4450 to i32
  store i32 %4451, ptr %4444, align 4
  %4452 = getelementptr inbounds i32, ptr %288, i64 5
  %4453 = load i16, ptr %287, align 2
  %4454 = call i16 @llvm.ctlz.i16(i16 %4453, i1 false)
  %4455 = add i16 %4454, 1
  %4456 = icmp eq i16 %4453, 0
  %4457 = select i1 %4456, i16 0, i16 %4455
  %4458 = zext i16 %4457 to i32
  store i32 %4458, ptr %4452, align 4
  %4459 = getelementptr inbounds i32, ptr %288, i64 6
  %4460 = load i16, ptr %287, align 2
  %4461 = xor i16 %4460, -1
  %4462 = call i16 @llvm.cttz.i16(i16 %4461, i1 false)
  %4463 = add i16 %4462, 1
  %4464 = icmp eq i16 %4461, 0
  %4465 = select i1 %4464, i16 0, i16 %4463
  %4466 = zext i16 %4465 to i32
  store i32 %4466, ptr %4459, align 4
  %4467 = getelementptr inbounds i32, ptr %288, i64 7
  %4468 = load i16, ptr %287, align 2
  %4469 = call i16 @llvm.cttz.i16(i16 %4468, i1 false)
  %4470 = add i16 %4469, 1
  %4471 = icmp eq i16 %4468, 0
  %4472 = select i1 %4471, i16 0, i16 %4470
  %4473 = zext i16 %4472 to i32
  store i32 %4473, ptr %4467, align 4
  %4474 = getelementptr inbounds i32, ptr %288, i64 8
  %4475 = load i16, ptr %287, align 2
  %4476 = call i16 @llvm.ctpop.i16(i16 %4475)
  %4477 = sub i16 16, %4476
  %4478 = zext i16 %4477 to i32
  store i32 %4478, ptr %4474, align 4
  %4479 = getelementptr inbounds i32, ptr %288, i64 9
  %4480 = load i16, ptr %287, align 2
  %4481 = call i16 @llvm.ctpop.i16(i16 %4480)
  %4482 = zext i16 %4481 to i32
  store i32 %4482, ptr %4479, align 4
  %4483 = getelementptr inbounds i32, ptr %288, i64 10
  %4484 = load i16, ptr %287, align 2
  %4485 = call i16 @llvm.ctpop.i16(i16 %4484)
  %4486 = icmp eq i16 %4485, 1
  %4487 = zext i1 %4486 to i32
  store i32 %4487, ptr %4483, align 4
  %4488 = getelementptr inbounds i32, ptr %288, i64 11
  %4489 = load i16, ptr %287, align 2
  %4490 = call i16 @llvm.ctlz.i16(i16 %4489, i1 false)
  %4491 = sub i16 16, %4490
  %4492 = zext i16 %4491 to i32
  store i32 %4492, ptr %4488, align 4
  %4493 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 0
  %4494 = load i32, ptr %4493, align 16
  %4495 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 1
  %4496 = load i32, ptr %4495, align 4
  %4497 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 2
  %4498 = load i32, ptr %4497, align 8
  %4499 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 3
  %4500 = load i32, ptr %4499, align 4
  %4501 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 4
  %4502 = load i32, ptr %4501, align 16
  %4503 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 5
  %4504 = load i32, ptr %4503, align 4
  %4505 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 6
  %4506 = load i32, ptr %4505, align 8
  %4507 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 7
  %4508 = load i32, ptr %4507, align 4
  %4509 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 8
  %4510 = load i32, ptr %4509, align 16
  %4511 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 9
  %4512 = load i32, ptr %4511, align 4
  %4513 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 10
  %4514 = load i32, ptr %4513, align 8
  %4515 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 11
  %4516 = load i32, ptr %4515, align 4
  %4517 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef %4494, i32 noundef %4496, i32 noundef %4498, i32 noundef %4500, i32 noundef %4502, i32 noundef %4504, i32 noundef %4506, i32 noundef %4508, i32 noundef %4510, i32 noundef %4512, i32 noundef %4514, i32 noundef %4516)
  %4518 = load i16, ptr %287, align 2
  %4519 = call i16 @llvm.ctlz.i16(i16 %4518, i1 true)
  %4520 = sub i16 15, %4519
  %4521 = shl i16 1, %4520
  %4522 = icmp eq i16 %4518, 0
  %4523 = select i1 %4522, i16 0, i16 %4521
  store i16 %4523, ptr %289, align 2
  %4524 = load i16, ptr %287, align 2
  %4525 = icmp ule i16 %4524, 1
  br i1 %4525, label %4531, label %4526

4526:                                             ; preds = %4426
  %4527 = sub i16 %4524, 1
  %4528 = call i16 @llvm.ctlz.i16(i16 %4527, i1 false)
  %4529 = sub i16 15, %4528
  %4530 = shl i16 2, %4529
  br label %4531

4531:                                             ; preds = %4526, %4426
  %4532 = phi i16 [ 1, %4426 ], [ %4530, %4526 ]
  store i16 %4532, ptr %290, align 2
  %4533 = load i16, ptr %287, align 2
  %4534 = call i16 @llvm.fshl.i16(i16 %4533, i16 %4533, i16 3)
  store i16 %4534, ptr %291, align 2
  %4535 = load i16, ptr %287, align 2
  %4536 = call i16 @llvm.fshr.i16(i16 %4535, i16 %4535, i16 3)
  store i16 %4536, ptr %292, align 2
  %4537 = load i16, ptr %287, align 2
  %4538 = call i16 @llvm.fshl.i16(i16 %4537, i16 %4537, i16 0)
  store i16 %4538, ptr %293, align 2
  %4539 = load i16, ptr %287, align 2
  %4540 = call i16 @llvm.fshl.i16(i16 %4539, i16 %4539, i16 8)
  store i16 %4540, ptr %294, align 2
  %4541 = load i16, ptr %289, align 2
  %4542 = zext i16 %4541 to i256
  %4543 = lshr i256 %4542, 128
  %4544 = trunc i256 %4543 to i64
  %4545 = load i16, ptr %289, align 2
  %4546 = zext i16 %4545 to i256
  %4547 = lshr i256 %4546, 64
  %4548 = trunc i256 %4547 to i64
  %4549 = load i16, ptr %289, align 2
  %4550 = zext i16 %4549 to i64
  %4551 = load i16, ptr %290, align 2
  %4552 = zext i16 %4551 to i256
  %4553 = lshr i256 %4552, 128
  %4554 = trunc i256 %4553 to i64
  %4555 = load i16, ptr %290, align 2
  %4556 = zext i16 %4555 to i256
  %4557 = lshr i256 %4556, 64
  %4558 = trunc i256 %4557 to i64
  %4559 = load i16, ptr %290, align 2
  %4560 = zext i16 %4559 to i64
  %4561 = load i16, ptr %291, align 2
  %4562 = zext i16 %4561 to i256
  %4563 = lshr i256 %4562, 128
  %4564 = trunc i256 %4563 to i64
  %4565 = load i16, ptr %291, align 2
  %4566 = zext i16 %4565 to i256
  %4567 = lshr i256 %4566, 64
  %4568 = trunc i256 %4567 to i64
  %4569 = load i16, ptr %291, align 2
  %4570 = zext i16 %4569 to i64
  %4571 = load i16, ptr %292, align 2
  %4572 = zext i16 %4571 to i256
  %4573 = lshr i256 %4572, 128
  %4574 = trunc i256 %4573 to i64
  %4575 = load i16, ptr %292, align 2
  %4576 = zext i16 %4575 to i256
  %4577 = lshr i256 %4576, 64
  %4578 = trunc i256 %4577 to i64
  %4579 = load i16, ptr %292, align 2
  %4580 = zext i16 %4579 to i64
  %4581 = load i16, ptr %293, align 2
  %4582 = zext i16 %4581 to i64
  %4583 = load i16, ptr %294, align 2
  %4584 = zext i16 %4583 to i64
  %4585 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %4544, i64 noundef %4548, i64 noundef %4550, i64 noundef %4554, i64 noundef %4558, i64 noundef %4560, i64 noundef %4564, i64 noundef %4568, i64 noundef %4570, i64 noundef %4574, i64 noundef %4578, i64 noundef %4580, i64 noundef %4582, i64 noundef %4584)
  %4586 = load i16, ptr %287, align 2
  %4587 = zext i16 %4586 to i575
  %4588 = getelementptr inbounds [12 x i32], ptr %288, i64 0, i64 0
  %4589 = load i16, ptr %289, align 2
  %4590 = zext i16 %4589 to i575
  %4591 = load i16, ptr %290, align 2
  %4592 = zext i16 %4591 to i575
  %4593 = load i16, ptr %291, align 2
  %4594 = zext i16 %4593 to i575
  %4595 = load i16, ptr %292, align 2
  %4596 = zext i16 %4595 to i575
  %4597 = load i16, ptr %293, align 2
  %4598 = zext i16 %4597 to i575
  %4599 = load i16, ptr %294, align 2
  %4600 = zext i16 %4599 to i575
  %4601 = zext i575 %4587 to i576
  store i576 %4601, ptr %295, align 8
  %4602 = zext i575 %4590 to i576
  store i576 %4602, ptr %296, align 8
  %4603 = zext i575 %4592 to i576
  store i576 %4603, ptr %297, align 8
  %4604 = zext i575 %4594 to i576
  store i576 %4604, ptr %298, align 8
  %4605 = zext i575 %4596 to i576
  store i576 %4605, ptr %299, align 8
  %4606 = zext i575 %4598 to i576
  store i576 %4606, ptr %300, align 8
  %4607 = zext i575 %4600 to i576
  store i576 %4607, ptr %301, align 8
  call void @check(ptr noundef @.str.4, i32 noundef 16, ptr noundef byval([72 x i8]) align 8 %295, ptr noundef %4588, ptr noundef byval([72 x i8]) align 8 %296, ptr noundef byval([72 x i8]) align 8 %297, ptr noundef byval([72 x i8]) align 8 %298, ptr noundef byval([72 x i8]) align 8 %299, ptr noundef byval([72 x i8]) align 8 %300, ptr noundef byval([72 x i8]) align 8 %301)
  br label %4608

4608:                                             ; preds = %4531
  br label %4609

4609:                                             ; preds = %4608
  store i32 -1, ptr %302, align 4
  %4610 = load i32, ptr %302, align 4
  %4611 = call i32 @llvm.ctlz.i32(i32 %4610, i1 false)
  store i32 %4611, ptr %303, align 4
  %4612 = getelementptr inbounds i32, ptr %303, i64 1
  %4613 = load i32, ptr %302, align 4
  %4614 = xor i32 %4613, -1
  %4615 = call i32 @llvm.ctlz.i32(i32 %4614, i1 false)
  store i32 %4615, ptr %4612, align 4
  %4616 = getelementptr inbounds i32, ptr %303, i64 2
  %4617 = load i32, ptr %302, align 4
  %4618 = call i32 @llvm.cttz.i32(i32 %4617, i1 false)
  store i32 %4618, ptr %4616, align 4
  %4619 = getelementptr inbounds i32, ptr %303, i64 3
  %4620 = load i32, ptr %302, align 4
  %4621 = xor i32 %4620, -1
  %4622 = call i32 @llvm.cttz.i32(i32 %4621, i1 false)
  store i32 %4622, ptr %4619, align 4
  %4623 = getelementptr inbounds i32, ptr %303, i64 4
  %4624 = load i32, ptr %302, align 4
  %4625 = xor i32 %4624, -1
  %4626 = call i32 @llvm.ctlz.i32(i32 %4625, i1 false)
  %4627 = add i32 %4626, 1
  %4628 = icmp eq i32 %4625, 0
  %4629 = select i1 %4628, i32 0, i32 %4627
  store i32 %4629, ptr %4623, align 4
  %4630 = getelementptr inbounds i32, ptr %303, i64 5
  %4631 = load i32, ptr %302, align 4
  %4632 = call i32 @llvm.ctlz.i32(i32 %4631, i1 false)
  %4633 = add i32 %4632, 1
  %4634 = icmp eq i32 %4631, 0
  %4635 = select i1 %4634, i32 0, i32 %4633
  store i32 %4635, ptr %4630, align 4
  %4636 = getelementptr inbounds i32, ptr %303, i64 6
  %4637 = load i32, ptr %302, align 4
  %4638 = xor i32 %4637, -1
  %4639 = call i32 @llvm.cttz.i32(i32 %4638, i1 false)
  %4640 = add i32 %4639, 1
  %4641 = icmp eq i32 %4638, 0
  %4642 = select i1 %4641, i32 0, i32 %4640
  store i32 %4642, ptr %4636, align 4
  %4643 = getelementptr inbounds i32, ptr %303, i64 7
  %4644 = load i32, ptr %302, align 4
  %4645 = call i32 @llvm.cttz.i32(i32 %4644, i1 false)
  %4646 = add i32 %4645, 1
  %4647 = icmp eq i32 %4644, 0
  %4648 = select i1 %4647, i32 0, i32 %4646
  store i32 %4648, ptr %4643, align 4
  %4649 = getelementptr inbounds i32, ptr %303, i64 8
  %4650 = load i32, ptr %302, align 4
  %4651 = call i32 @llvm.ctpop.i32(i32 %4650)
  %4652 = sub i32 32, %4651
  store i32 %4652, ptr %4649, align 4
  %4653 = getelementptr inbounds i32, ptr %303, i64 9
  %4654 = load i32, ptr %302, align 4
  %4655 = call i32 @llvm.ctpop.i32(i32 %4654)
  store i32 %4655, ptr %4653, align 4
  %4656 = getelementptr inbounds i32, ptr %303, i64 10
  %4657 = load i32, ptr %302, align 4
  %4658 = call i32 @llvm.ctpop.i32(i32 %4657)
  %4659 = icmp eq i32 %4658, 1
  %4660 = zext i1 %4659 to i32
  store i32 %4660, ptr %4656, align 4
  %4661 = getelementptr inbounds i32, ptr %303, i64 11
  %4662 = load i32, ptr %302, align 4
  %4663 = call i32 @llvm.ctlz.i32(i32 %4662, i1 false)
  %4664 = sub i32 32, %4663
  store i32 %4664, ptr %4661, align 4
  %4665 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 0
  %4666 = load i32, ptr %4665, align 16
  %4667 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 1
  %4668 = load i32, ptr %4667, align 4
  %4669 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 2
  %4670 = load i32, ptr %4669, align 8
  %4671 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 3
  %4672 = load i32, ptr %4671, align 4
  %4673 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 4
  %4674 = load i32, ptr %4673, align 16
  %4675 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 5
  %4676 = load i32, ptr %4675, align 4
  %4677 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 6
  %4678 = load i32, ptr %4677, align 8
  %4679 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 7
  %4680 = load i32, ptr %4679, align 4
  %4681 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 8
  %4682 = load i32, ptr %4681, align 16
  %4683 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 9
  %4684 = load i32, ptr %4683, align 4
  %4685 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 10
  %4686 = load i32, ptr %4685, align 8
  %4687 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 11
  %4688 = load i32, ptr %4687, align 4
  %4689 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef %4666, i32 noundef %4668, i32 noundef %4670, i32 noundef %4672, i32 noundef %4674, i32 noundef %4676, i32 noundef %4678, i32 noundef %4680, i32 noundef %4682, i32 noundef %4684, i32 noundef %4686, i32 noundef %4688)
  %4690 = load i32, ptr %302, align 4
  %4691 = call i32 @llvm.ctlz.i32(i32 %4690, i1 true)
  %4692 = sub i32 31, %4691
  %4693 = shl i32 1, %4692
  %4694 = icmp eq i32 %4690, 0
  %4695 = select i1 %4694, i32 0, i32 %4693
  store i32 %4695, ptr %304, align 4
  %4696 = load i32, ptr %302, align 4
  %4697 = icmp ule i32 %4696, 1
  br i1 %4697, label %4703, label %4698

4698:                                             ; preds = %4609
  %4699 = sub i32 %4696, 1
  %4700 = call i32 @llvm.ctlz.i32(i32 %4699, i1 false)
  %4701 = sub i32 31, %4700
  %4702 = shl i32 2, %4701
  br label %4703

4703:                                             ; preds = %4698, %4609
  %4704 = phi i32 [ 1, %4609 ], [ %4702, %4698 ]
  store i32 %4704, ptr %305, align 4
  %4705 = load i32, ptr %302, align 4
  %4706 = call i32 @llvm.fshl.i32(i32 %4705, i32 %4705, i32 3)
  store i32 %4706, ptr %306, align 4
  %4707 = load i32, ptr %302, align 4
  %4708 = call i32 @llvm.fshr.i32(i32 %4707, i32 %4707, i32 3)
  store i32 %4708, ptr %307, align 4
  %4709 = load i32, ptr %302, align 4
  %4710 = call i32 @llvm.fshl.i32(i32 %4709, i32 %4709, i32 0)
  store i32 %4710, ptr %308, align 4
  %4711 = load i32, ptr %302, align 4
  %4712 = call i32 @llvm.fshl.i32(i32 %4711, i32 %4711, i32 8)
  store i32 %4712, ptr %309, align 4
  %4713 = load i32, ptr %304, align 4
  %4714 = zext i32 %4713 to i256
  %4715 = lshr i256 %4714, 128
  %4716 = trunc i256 %4715 to i64
  %4717 = load i32, ptr %304, align 4
  %4718 = zext i32 %4717 to i256
  %4719 = lshr i256 %4718, 64
  %4720 = trunc i256 %4719 to i64
  %4721 = load i32, ptr %304, align 4
  %4722 = zext i32 %4721 to i64
  %4723 = load i32, ptr %305, align 4
  %4724 = zext i32 %4723 to i256
  %4725 = lshr i256 %4724, 128
  %4726 = trunc i256 %4725 to i64
  %4727 = load i32, ptr %305, align 4
  %4728 = zext i32 %4727 to i256
  %4729 = lshr i256 %4728, 64
  %4730 = trunc i256 %4729 to i64
  %4731 = load i32, ptr %305, align 4
  %4732 = zext i32 %4731 to i64
  %4733 = load i32, ptr %306, align 4
  %4734 = zext i32 %4733 to i256
  %4735 = lshr i256 %4734, 128
  %4736 = trunc i256 %4735 to i64
  %4737 = load i32, ptr %306, align 4
  %4738 = zext i32 %4737 to i256
  %4739 = lshr i256 %4738, 64
  %4740 = trunc i256 %4739 to i64
  %4741 = load i32, ptr %306, align 4
  %4742 = zext i32 %4741 to i64
  %4743 = load i32, ptr %307, align 4
  %4744 = zext i32 %4743 to i256
  %4745 = lshr i256 %4744, 128
  %4746 = trunc i256 %4745 to i64
  %4747 = load i32, ptr %307, align 4
  %4748 = zext i32 %4747 to i256
  %4749 = lshr i256 %4748, 64
  %4750 = trunc i256 %4749 to i64
  %4751 = load i32, ptr %307, align 4
  %4752 = zext i32 %4751 to i64
  %4753 = load i32, ptr %308, align 4
  %4754 = zext i32 %4753 to i64
  %4755 = load i32, ptr %309, align 4
  %4756 = zext i32 %4755 to i64
  %4757 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %4716, i64 noundef %4720, i64 noundef %4722, i64 noundef %4726, i64 noundef %4730, i64 noundef %4732, i64 noundef %4736, i64 noundef %4740, i64 noundef %4742, i64 noundef %4746, i64 noundef %4750, i64 noundef %4752, i64 noundef %4754, i64 noundef %4756)
  %4758 = load i32, ptr %302, align 4
  %4759 = zext i32 %4758 to i575
  %4760 = getelementptr inbounds [12 x i32], ptr %303, i64 0, i64 0
  %4761 = load i32, ptr %304, align 4
  %4762 = zext i32 %4761 to i575
  %4763 = load i32, ptr %305, align 4
  %4764 = zext i32 %4763 to i575
  %4765 = load i32, ptr %306, align 4
  %4766 = zext i32 %4765 to i575
  %4767 = load i32, ptr %307, align 4
  %4768 = zext i32 %4767 to i575
  %4769 = load i32, ptr %308, align 4
  %4770 = zext i32 %4769 to i575
  %4771 = load i32, ptr %309, align 4
  %4772 = zext i32 %4771 to i575
  %4773 = zext i575 %4759 to i576
  store i576 %4773, ptr %310, align 8
  %4774 = zext i575 %4762 to i576
  store i576 %4774, ptr %311, align 8
  %4775 = zext i575 %4764 to i576
  store i576 %4775, ptr %312, align 8
  %4776 = zext i575 %4766 to i576
  store i576 %4776, ptr %313, align 8
  %4777 = zext i575 %4768 to i576
  store i576 %4777, ptr %314, align 8
  %4778 = zext i575 %4770 to i576
  store i576 %4778, ptr %315, align 8
  %4779 = zext i575 %4772 to i576
  store i576 %4779, ptr %316, align 8
  call void @check(ptr noundef @.str.5, i32 noundef 32, ptr noundef byval([72 x i8]) align 8 %310, ptr noundef %4760, ptr noundef byval([72 x i8]) align 8 %311, ptr noundef byval([72 x i8]) align 8 %312, ptr noundef byval([72 x i8]) align 8 %313, ptr noundef byval([72 x i8]) align 8 %314, ptr noundef byval([72 x i8]) align 8 %315, ptr noundef byval([72 x i8]) align 8 %316)
  br label %4780

4780:                                             ; preds = %4703
  br label %4781

4781:                                             ; preds = %4780
  store i64 -1, ptr %317, align 8
  %4782 = load i64, ptr %317, align 8
  %4783 = call i64 @llvm.ctlz.i64(i64 %4782, i1 false)
  %4784 = trunc i64 %4783 to i32
  store i32 %4784, ptr %318, align 4
  %4785 = getelementptr inbounds i32, ptr %318, i64 1
  %4786 = load i64, ptr %317, align 8
  %4787 = xor i64 %4786, -1
  %4788 = call i64 @llvm.ctlz.i64(i64 %4787, i1 false)
  %4789 = trunc i64 %4788 to i32
  store i32 %4789, ptr %4785, align 4
  %4790 = getelementptr inbounds i32, ptr %318, i64 2
  %4791 = load i64, ptr %317, align 8
  %4792 = call i64 @llvm.cttz.i64(i64 %4791, i1 false)
  %4793 = trunc i64 %4792 to i32
  store i32 %4793, ptr %4790, align 4
  %4794 = getelementptr inbounds i32, ptr %318, i64 3
  %4795 = load i64, ptr %317, align 8
  %4796 = xor i64 %4795, -1
  %4797 = call i64 @llvm.cttz.i64(i64 %4796, i1 false)
  %4798 = trunc i64 %4797 to i32
  store i32 %4798, ptr %4794, align 4
  %4799 = getelementptr inbounds i32, ptr %318, i64 4
  %4800 = load i64, ptr %317, align 8
  %4801 = xor i64 %4800, -1
  %4802 = call i64 @llvm.ctlz.i64(i64 %4801, i1 false)
  %4803 = add i64 %4802, 1
  %4804 = icmp eq i64 %4801, 0
  %4805 = select i1 %4804, i64 0, i64 %4803
  %4806 = trunc i64 %4805 to i32
  store i32 %4806, ptr %4799, align 4
  %4807 = getelementptr inbounds i32, ptr %318, i64 5
  %4808 = load i64, ptr %317, align 8
  %4809 = call i64 @llvm.ctlz.i64(i64 %4808, i1 false)
  %4810 = add i64 %4809, 1
  %4811 = icmp eq i64 %4808, 0
  %4812 = select i1 %4811, i64 0, i64 %4810
  %4813 = trunc i64 %4812 to i32
  store i32 %4813, ptr %4807, align 4
  %4814 = getelementptr inbounds i32, ptr %318, i64 6
  %4815 = load i64, ptr %317, align 8
  %4816 = xor i64 %4815, -1
  %4817 = call i64 @llvm.cttz.i64(i64 %4816, i1 false)
  %4818 = add i64 %4817, 1
  %4819 = icmp eq i64 %4816, 0
  %4820 = select i1 %4819, i64 0, i64 %4818
  %4821 = trunc i64 %4820 to i32
  store i32 %4821, ptr %4814, align 4
  %4822 = getelementptr inbounds i32, ptr %318, i64 7
  %4823 = load i64, ptr %317, align 8
  %4824 = call i64 @llvm.cttz.i64(i64 %4823, i1 false)
  %4825 = add i64 %4824, 1
  %4826 = icmp eq i64 %4823, 0
  %4827 = select i1 %4826, i64 0, i64 %4825
  %4828 = trunc i64 %4827 to i32
  store i32 %4828, ptr %4822, align 4
  %4829 = getelementptr inbounds i32, ptr %318, i64 8
  %4830 = load i64, ptr %317, align 8
  %4831 = call i64 @llvm.ctpop.i64(i64 %4830)
  %4832 = sub i64 64, %4831
  %4833 = trunc i64 %4832 to i32
  store i32 %4833, ptr %4829, align 4
  %4834 = getelementptr inbounds i32, ptr %318, i64 9
  %4835 = load i64, ptr %317, align 8
  %4836 = call i64 @llvm.ctpop.i64(i64 %4835)
  %4837 = trunc i64 %4836 to i32
  store i32 %4837, ptr %4834, align 4
  %4838 = getelementptr inbounds i32, ptr %318, i64 10
  %4839 = load i64, ptr %317, align 8
  %4840 = call i64 @llvm.ctpop.i64(i64 %4839)
  %4841 = icmp eq i64 %4840, 1
  %4842 = zext i1 %4841 to i32
  store i32 %4842, ptr %4838, align 4
  %4843 = getelementptr inbounds i32, ptr %318, i64 11
  %4844 = load i64, ptr %317, align 8
  %4845 = call i64 @llvm.ctlz.i64(i64 %4844, i1 false)
  %4846 = sub i64 64, %4845
  %4847 = trunc i64 %4846 to i32
  store i32 %4847, ptr %4843, align 4
  %4848 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 0
  %4849 = load i32, ptr %4848, align 16
  %4850 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 1
  %4851 = load i32, ptr %4850, align 4
  %4852 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 2
  %4853 = load i32, ptr %4852, align 8
  %4854 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 3
  %4855 = load i32, ptr %4854, align 4
  %4856 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 4
  %4857 = load i32, ptr %4856, align 16
  %4858 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 5
  %4859 = load i32, ptr %4858, align 4
  %4860 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 6
  %4861 = load i32, ptr %4860, align 8
  %4862 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 7
  %4863 = load i32, ptr %4862, align 4
  %4864 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 8
  %4865 = load i32, ptr %4864, align 16
  %4866 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 9
  %4867 = load i32, ptr %4866, align 4
  %4868 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 10
  %4869 = load i32, ptr %4868, align 8
  %4870 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 11
  %4871 = load i32, ptr %4870, align 4
  %4872 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef %4849, i32 noundef %4851, i32 noundef %4853, i32 noundef %4855, i32 noundef %4857, i32 noundef %4859, i32 noundef %4861, i32 noundef %4863, i32 noundef %4865, i32 noundef %4867, i32 noundef %4869, i32 noundef %4871)
  %4873 = load i64, ptr %317, align 8
  %4874 = call i64 @llvm.ctlz.i64(i64 %4873, i1 true)
  %4875 = sub i64 63, %4874
  %4876 = shl i64 1, %4875
  %4877 = icmp eq i64 %4873, 0
  %4878 = select i1 %4877, i64 0, i64 %4876
  store i64 %4878, ptr %319, align 8
  %4879 = load i64, ptr %317, align 8
  %4880 = icmp ule i64 %4879, 1
  br i1 %4880, label %4886, label %4881

4881:                                             ; preds = %4781
  %4882 = sub i64 %4879, 1
  %4883 = call i64 @llvm.ctlz.i64(i64 %4882, i1 false)
  %4884 = sub i64 63, %4883
  %4885 = shl i64 2, %4884
  br label %4886

4886:                                             ; preds = %4881, %4781
  %4887 = phi i64 [ 1, %4781 ], [ %4885, %4881 ]
  store i64 %4887, ptr %320, align 8
  %4888 = load i64, ptr %317, align 8
  %4889 = call i64 @llvm.fshl.i64(i64 %4888, i64 %4888, i64 3)
  store i64 %4889, ptr %321, align 8
  %4890 = load i64, ptr %317, align 8
  %4891 = call i64 @llvm.fshr.i64(i64 %4890, i64 %4890, i64 3)
  store i64 %4891, ptr %322, align 8
  %4892 = load i64, ptr %317, align 8
  %4893 = call i64 @llvm.fshl.i64(i64 %4892, i64 %4892, i64 0)
  store i64 %4893, ptr %323, align 8
  %4894 = load i64, ptr %317, align 8
  %4895 = call i64 @llvm.fshl.i64(i64 %4894, i64 %4894, i64 40)
  store i64 %4895, ptr %324, align 8
  %4896 = load i64, ptr %319, align 8
  %4897 = zext i64 %4896 to i256
  %4898 = lshr i256 %4897, 128
  %4899 = trunc i256 %4898 to i64
  %4900 = load i64, ptr %319, align 8
  %4901 = zext i64 %4900 to i256
  %4902 = lshr i256 %4901, 64
  %4903 = trunc i256 %4902 to i64
  %4904 = load i64, ptr %319, align 8
  %4905 = load i64, ptr %320, align 8
  %4906 = zext i64 %4905 to i256
  %4907 = lshr i256 %4906, 128
  %4908 = trunc i256 %4907 to i64
  %4909 = load i64, ptr %320, align 8
  %4910 = zext i64 %4909 to i256
  %4911 = lshr i256 %4910, 64
  %4912 = trunc i256 %4911 to i64
  %4913 = load i64, ptr %320, align 8
  %4914 = load i64, ptr %321, align 8
  %4915 = zext i64 %4914 to i256
  %4916 = lshr i256 %4915, 128
  %4917 = trunc i256 %4916 to i64
  %4918 = load i64, ptr %321, align 8
  %4919 = zext i64 %4918 to i256
  %4920 = lshr i256 %4919, 64
  %4921 = trunc i256 %4920 to i64
  %4922 = load i64, ptr %321, align 8
  %4923 = load i64, ptr %322, align 8
  %4924 = zext i64 %4923 to i256
  %4925 = lshr i256 %4924, 128
  %4926 = trunc i256 %4925 to i64
  %4927 = load i64, ptr %322, align 8
  %4928 = zext i64 %4927 to i256
  %4929 = lshr i256 %4928, 64
  %4930 = trunc i256 %4929 to i64
  %4931 = load i64, ptr %322, align 8
  %4932 = load i64, ptr %323, align 8
  %4933 = load i64, ptr %324, align 8
  %4934 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %4899, i64 noundef %4903, i64 noundef %4904, i64 noundef %4908, i64 noundef %4912, i64 noundef %4913, i64 noundef %4917, i64 noundef %4921, i64 noundef %4922, i64 noundef %4926, i64 noundef %4930, i64 noundef %4931, i64 noundef %4932, i64 noundef %4933)
  %4935 = load i64, ptr %317, align 8
  %4936 = zext i64 %4935 to i575
  %4937 = getelementptr inbounds [12 x i32], ptr %318, i64 0, i64 0
  %4938 = load i64, ptr %319, align 8
  %4939 = zext i64 %4938 to i575
  %4940 = load i64, ptr %320, align 8
  %4941 = zext i64 %4940 to i575
  %4942 = load i64, ptr %321, align 8
  %4943 = zext i64 %4942 to i575
  %4944 = load i64, ptr %322, align 8
  %4945 = zext i64 %4944 to i575
  %4946 = load i64, ptr %323, align 8
  %4947 = zext i64 %4946 to i575
  %4948 = load i64, ptr %324, align 8
  %4949 = zext i64 %4948 to i575
  %4950 = zext i575 %4936 to i576
  store i576 %4950, ptr %325, align 8
  %4951 = zext i575 %4939 to i576
  store i576 %4951, ptr %326, align 8
  %4952 = zext i575 %4941 to i576
  store i576 %4952, ptr %327, align 8
  %4953 = zext i575 %4943 to i576
  store i576 %4953, ptr %328, align 8
  %4954 = zext i575 %4945 to i576
  store i576 %4954, ptr %329, align 8
  %4955 = zext i575 %4947 to i576
  store i576 %4955, ptr %330, align 8
  %4956 = zext i575 %4949 to i576
  store i576 %4956, ptr %331, align 8
  call void @check(ptr noundef @.str.6, i32 noundef 64, ptr noundef byval([72 x i8]) align 8 %325, ptr noundef %4937, ptr noundef byval([72 x i8]) align 8 %326, ptr noundef byval([72 x i8]) align 8 %327, ptr noundef byval([72 x i8]) align 8 %328, ptr noundef byval([72 x i8]) align 8 %329, ptr noundef byval([72 x i8]) align 8 %330, ptr noundef byval([72 x i8]) align 8 %331)
  br label %4957

4957:                                             ; preds = %4886
  br label %4958

4958:                                             ; preds = %4957
  store i128 -1, ptr %332, align 16
  %4959 = load i128, ptr %332, align 16
  %4960 = call i128 @llvm.ctlz.i128(i128 %4959, i1 false)
  %4961 = trunc i128 %4960 to i32
  store i32 %4961, ptr %333, align 4
  %4962 = getelementptr inbounds i32, ptr %333, i64 1
  %4963 = load i128, ptr %332, align 16
  %4964 = xor i128 %4963, -1
  %4965 = call i128 @llvm.ctlz.i128(i128 %4964, i1 false)
  %4966 = trunc i128 %4965 to i32
  store i32 %4966, ptr %4962, align 4
  %4967 = getelementptr inbounds i32, ptr %333, i64 2
  %4968 = load i128, ptr %332, align 16
  %4969 = call i128 @llvm.cttz.i128(i128 %4968, i1 false)
  %4970 = trunc i128 %4969 to i32
  store i32 %4970, ptr %4967, align 4
  %4971 = getelementptr inbounds i32, ptr %333, i64 3
  %4972 = load i128, ptr %332, align 16
  %4973 = xor i128 %4972, -1
  %4974 = call i128 @llvm.cttz.i128(i128 %4973, i1 false)
  %4975 = trunc i128 %4974 to i32
  store i32 %4975, ptr %4971, align 4
  %4976 = getelementptr inbounds i32, ptr %333, i64 4
  %4977 = load i128, ptr %332, align 16
  %4978 = xor i128 %4977, -1
  %4979 = call i128 @llvm.ctlz.i128(i128 %4978, i1 false)
  %4980 = add i128 %4979, 1
  %4981 = icmp eq i128 %4978, 0
  %4982 = select i1 %4981, i128 0, i128 %4980
  %4983 = trunc i128 %4982 to i32
  store i32 %4983, ptr %4976, align 4
  %4984 = getelementptr inbounds i32, ptr %333, i64 5
  %4985 = load i128, ptr %332, align 16
  %4986 = call i128 @llvm.ctlz.i128(i128 %4985, i1 false)
  %4987 = add i128 %4986, 1
  %4988 = icmp eq i128 %4985, 0
  %4989 = select i1 %4988, i128 0, i128 %4987
  %4990 = trunc i128 %4989 to i32
  store i32 %4990, ptr %4984, align 4
  %4991 = getelementptr inbounds i32, ptr %333, i64 6
  %4992 = load i128, ptr %332, align 16
  %4993 = xor i128 %4992, -1
  %4994 = call i128 @llvm.cttz.i128(i128 %4993, i1 false)
  %4995 = add i128 %4994, 1
  %4996 = icmp eq i128 %4993, 0
  %4997 = select i1 %4996, i128 0, i128 %4995
  %4998 = trunc i128 %4997 to i32
  store i32 %4998, ptr %4991, align 4
  %4999 = getelementptr inbounds i32, ptr %333, i64 7
  %5000 = load i128, ptr %332, align 16
  %5001 = call i128 @llvm.cttz.i128(i128 %5000, i1 false)
  %5002 = add i128 %5001, 1
  %5003 = icmp eq i128 %5000, 0
  %5004 = select i1 %5003, i128 0, i128 %5002
  %5005 = trunc i128 %5004 to i32
  store i32 %5005, ptr %4999, align 4
  %5006 = getelementptr inbounds i32, ptr %333, i64 8
  %5007 = load i128, ptr %332, align 16
  %5008 = call i128 @llvm.ctpop.i128(i128 %5007)
  %5009 = sub i128 128, %5008
  %5010 = trunc i128 %5009 to i32
  store i32 %5010, ptr %5006, align 4
  %5011 = getelementptr inbounds i32, ptr %333, i64 9
  %5012 = load i128, ptr %332, align 16
  %5013 = call i128 @llvm.ctpop.i128(i128 %5012)
  %5014 = trunc i128 %5013 to i32
  store i32 %5014, ptr %5011, align 4
  %5015 = getelementptr inbounds i32, ptr %333, i64 10
  %5016 = load i128, ptr %332, align 16
  %5017 = call i128 @llvm.ctpop.i128(i128 %5016)
  %5018 = icmp eq i128 %5017, 1
  %5019 = zext i1 %5018 to i32
  store i32 %5019, ptr %5015, align 4
  %5020 = getelementptr inbounds i32, ptr %333, i64 11
  %5021 = load i128, ptr %332, align 16
  %5022 = call i128 @llvm.ctlz.i128(i128 %5021, i1 false)
  %5023 = sub i128 128, %5022
  %5024 = trunc i128 %5023 to i32
  store i32 %5024, ptr %5020, align 4
  %5025 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 0
  %5026 = load i32, ptr %5025, align 16
  %5027 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 1
  %5028 = load i32, ptr %5027, align 4
  %5029 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 2
  %5030 = load i32, ptr %5029, align 8
  %5031 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 3
  %5032 = load i32, ptr %5031, align 4
  %5033 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 4
  %5034 = load i32, ptr %5033, align 16
  %5035 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 5
  %5036 = load i32, ptr %5035, align 4
  %5037 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 6
  %5038 = load i32, ptr %5037, align 8
  %5039 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 7
  %5040 = load i32, ptr %5039, align 4
  %5041 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 8
  %5042 = load i32, ptr %5041, align 16
  %5043 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 9
  %5044 = load i32, ptr %5043, align 4
  %5045 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 10
  %5046 = load i32, ptr %5045, align 8
  %5047 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 11
  %5048 = load i32, ptr %5047, align 4
  %5049 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef %5026, i32 noundef %5028, i32 noundef %5030, i32 noundef %5032, i32 noundef %5034, i32 noundef %5036, i32 noundef %5038, i32 noundef %5040, i32 noundef %5042, i32 noundef %5044, i32 noundef %5046, i32 noundef %5048)
  %5050 = load i128, ptr %332, align 16
  %5051 = call i128 @llvm.ctlz.i128(i128 %5050, i1 true)
  %5052 = sub i128 127, %5051
  %5053 = shl i128 1, %5052
  %5054 = icmp eq i128 %5050, 0
  %5055 = select i1 %5054, i128 0, i128 %5053
  store i128 %5055, ptr %334, align 16
  %5056 = load i128, ptr %332, align 16
  %5057 = icmp ule i128 %5056, 1
  br i1 %5057, label %5063, label %5058

5058:                                             ; preds = %4958
  %5059 = sub i128 %5056, 1
  %5060 = call i128 @llvm.ctlz.i128(i128 %5059, i1 false)
  %5061 = sub i128 127, %5060
  %5062 = shl i128 2, %5061
  br label %5063

5063:                                             ; preds = %5058, %4958
  %5064 = phi i128 [ 1, %4958 ], [ %5062, %5058 ]
  store i128 %5064, ptr %335, align 16
  %5065 = load i128, ptr %332, align 16
  %5066 = call i128 @llvm.fshl.i128(i128 %5065, i128 %5065, i128 3)
  store i128 %5066, ptr %336, align 16
  %5067 = load i128, ptr %332, align 16
  %5068 = call i128 @llvm.fshr.i128(i128 %5067, i128 %5067, i128 3)
  store i128 %5068, ptr %337, align 16
  %5069 = load i128, ptr %332, align 16
  %5070 = call i128 @llvm.fshl.i128(i128 %5069, i128 %5069, i128 0)
  store i128 %5070, ptr %338, align 16
  %5071 = load i128, ptr %332, align 16
  %5072 = call i128 @llvm.fshl.i128(i128 %5071, i128 %5071, i128 104)
  store i128 %5072, ptr %339, align 16
  %5073 = load i128, ptr %334, align 16
  %5074 = zext i128 %5073 to i256
  %5075 = lshr i256 %5074, 128
  %5076 = trunc i256 %5075 to i64
  %5077 = load i128, ptr %334, align 16
  %5078 = zext i128 %5077 to i256
  %5079 = lshr i256 %5078, 64
  %5080 = trunc i256 %5079 to i64
  %5081 = load i128, ptr %334, align 16
  %5082 = trunc i128 %5081 to i64
  %5083 = load i128, ptr %335, align 16
  %5084 = zext i128 %5083 to i256
  %5085 = lshr i256 %5084, 128
  %5086 = trunc i256 %5085 to i64
  %5087 = load i128, ptr %335, align 16
  %5088 = zext i128 %5087 to i256
  %5089 = lshr i256 %5088, 64
  %5090 = trunc i256 %5089 to i64
  %5091 = load i128, ptr %335, align 16
  %5092 = trunc i128 %5091 to i64
  %5093 = load i128, ptr %336, align 16
  %5094 = zext i128 %5093 to i256
  %5095 = lshr i256 %5094, 128
  %5096 = trunc i256 %5095 to i64
  %5097 = load i128, ptr %336, align 16
  %5098 = zext i128 %5097 to i256
  %5099 = lshr i256 %5098, 64
  %5100 = trunc i256 %5099 to i64
  %5101 = load i128, ptr %336, align 16
  %5102 = trunc i128 %5101 to i64
  %5103 = load i128, ptr %337, align 16
  %5104 = zext i128 %5103 to i256
  %5105 = lshr i256 %5104, 128
  %5106 = trunc i256 %5105 to i64
  %5107 = load i128, ptr %337, align 16
  %5108 = zext i128 %5107 to i256
  %5109 = lshr i256 %5108, 64
  %5110 = trunc i256 %5109 to i64
  %5111 = load i128, ptr %337, align 16
  %5112 = trunc i128 %5111 to i64
  %5113 = load i128, ptr %338, align 16
  %5114 = trunc i128 %5113 to i64
  %5115 = load i128, ptr %339, align 16
  %5116 = trunc i128 %5115 to i64
  %5117 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %5076, i64 noundef %5080, i64 noundef %5082, i64 noundef %5086, i64 noundef %5090, i64 noundef %5092, i64 noundef %5096, i64 noundef %5100, i64 noundef %5102, i64 noundef %5106, i64 noundef %5110, i64 noundef %5112, i64 noundef %5114, i64 noundef %5116)
  %5118 = load i128, ptr %332, align 16
  %5119 = zext i128 %5118 to i575
  %5120 = getelementptr inbounds [12 x i32], ptr %333, i64 0, i64 0
  %5121 = load i128, ptr %334, align 16
  %5122 = zext i128 %5121 to i575
  %5123 = load i128, ptr %335, align 16
  %5124 = zext i128 %5123 to i575
  %5125 = load i128, ptr %336, align 16
  %5126 = zext i128 %5125 to i575
  %5127 = load i128, ptr %337, align 16
  %5128 = zext i128 %5127 to i575
  %5129 = load i128, ptr %338, align 16
  %5130 = zext i128 %5129 to i575
  %5131 = load i128, ptr %339, align 16
  %5132 = zext i128 %5131 to i575
  %5133 = zext i575 %5119 to i576
  store i576 %5133, ptr %340, align 8
  %5134 = zext i575 %5122 to i576
  store i576 %5134, ptr %341, align 8
  %5135 = zext i575 %5124 to i576
  store i576 %5135, ptr %342, align 8
  %5136 = zext i575 %5126 to i576
  store i576 %5136, ptr %343, align 8
  %5137 = zext i575 %5128 to i576
  store i576 %5137, ptr %344, align 8
  %5138 = zext i575 %5130 to i576
  store i576 %5138, ptr %345, align 8
  %5139 = zext i575 %5132 to i576
  store i576 %5139, ptr %346, align 8
  call void @check(ptr noundef @.str.7, i32 noundef 128, ptr noundef byval([72 x i8]) align 8 %340, ptr noundef %5120, ptr noundef byval([72 x i8]) align 8 %341, ptr noundef byval([72 x i8]) align 8 %342, ptr noundef byval([72 x i8]) align 8 %343, ptr noundef byval([72 x i8]) align 8 %344, ptr noundef byval([72 x i8]) align 8 %345, ptr noundef byval([72 x i8]) align 8 %346)
  br label %5140

5140:                                             ; preds = %5063
  br label %5141

5141:                                             ; preds = %5140
  store i8 127, ptr %347, align 1
  %5142 = load i8, ptr %347, align 1
  %5143 = trunc i8 %5142 to i7
  %5144 = call i7 @llvm.ctlz.i7(i7 %5143, i1 false)
  %5145 = zext i7 %5144 to i32
  store i32 %5145, ptr %348, align 4
  %5146 = getelementptr inbounds i32, ptr %348, i64 1
  %5147 = load i8, ptr %347, align 1
  %5148 = trunc i8 %5147 to i7
  %5149 = xor i7 %5148, -1
  %5150 = call i7 @llvm.ctlz.i7(i7 %5149, i1 false)
  %5151 = zext i7 %5150 to i32
  store i32 %5151, ptr %5146, align 4
  %5152 = getelementptr inbounds i32, ptr %348, i64 2
  %5153 = load i8, ptr %347, align 1
  %5154 = trunc i8 %5153 to i7
  %5155 = call i7 @llvm.cttz.i7(i7 %5154, i1 false)
  %5156 = zext i7 %5155 to i32
  store i32 %5156, ptr %5152, align 4
  %5157 = getelementptr inbounds i32, ptr %348, i64 3
  %5158 = load i8, ptr %347, align 1
  %5159 = trunc i8 %5158 to i7
  %5160 = xor i7 %5159, -1
  %5161 = call i7 @llvm.cttz.i7(i7 %5160, i1 false)
  %5162 = zext i7 %5161 to i32
  store i32 %5162, ptr %5157, align 4
  %5163 = getelementptr inbounds i32, ptr %348, i64 4
  %5164 = load i8, ptr %347, align 1
  %5165 = trunc i8 %5164 to i7
  %5166 = xor i7 %5165, -1
  %5167 = call i7 @llvm.ctlz.i7(i7 %5166, i1 false)
  %5168 = add i7 %5167, 1
  %5169 = icmp eq i7 %5166, 0
  %5170 = select i1 %5169, i7 0, i7 %5168
  %5171 = zext i7 %5170 to i32
  store i32 %5171, ptr %5163, align 4
  %5172 = getelementptr inbounds i32, ptr %348, i64 5
  %5173 = load i8, ptr %347, align 1
  %5174 = trunc i8 %5173 to i7
  %5175 = call i7 @llvm.ctlz.i7(i7 %5174, i1 false)
  %5176 = add i7 %5175, 1
  %5177 = icmp eq i7 %5174, 0
  %5178 = select i1 %5177, i7 0, i7 %5176
  %5179 = zext i7 %5178 to i32
  store i32 %5179, ptr %5172, align 4
  %5180 = getelementptr inbounds i32, ptr %348, i64 6
  %5181 = load i8, ptr %347, align 1
  %5182 = trunc i8 %5181 to i7
  %5183 = xor i7 %5182, -1
  %5184 = call i7 @llvm.cttz.i7(i7 %5183, i1 false)
  %5185 = add i7 %5184, 1
  %5186 = icmp eq i7 %5183, 0
  %5187 = select i1 %5186, i7 0, i7 %5185
  %5188 = zext i7 %5187 to i32
  store i32 %5188, ptr %5180, align 4
  %5189 = getelementptr inbounds i32, ptr %348, i64 7
  %5190 = load i8, ptr %347, align 1
  %5191 = trunc i8 %5190 to i7
  %5192 = call i7 @llvm.cttz.i7(i7 %5191, i1 false)
  %5193 = add i7 %5192, 1
  %5194 = icmp eq i7 %5191, 0
  %5195 = select i1 %5194, i7 0, i7 %5193
  %5196 = zext i7 %5195 to i32
  store i32 %5196, ptr %5189, align 4
  %5197 = getelementptr inbounds i32, ptr %348, i64 8
  %5198 = load i8, ptr %347, align 1
  %5199 = trunc i8 %5198 to i7
  %5200 = call i7 @llvm.ctpop.i7(i7 %5199)
  %5201 = sub i7 7, %5200
  %5202 = zext i7 %5201 to i32
  store i32 %5202, ptr %5197, align 4
  %5203 = getelementptr inbounds i32, ptr %348, i64 9
  %5204 = load i8, ptr %347, align 1
  %5205 = trunc i8 %5204 to i7
  %5206 = call i7 @llvm.ctpop.i7(i7 %5205)
  %5207 = zext i7 %5206 to i32
  store i32 %5207, ptr %5203, align 4
  %5208 = getelementptr inbounds i32, ptr %348, i64 10
  %5209 = load i8, ptr %347, align 1
  %5210 = trunc i8 %5209 to i7
  %5211 = call i7 @llvm.ctpop.i7(i7 %5210)
  %5212 = icmp eq i7 %5211, 1
  %5213 = zext i1 %5212 to i32
  store i32 %5213, ptr %5208, align 4
  %5214 = getelementptr inbounds i32, ptr %348, i64 11
  %5215 = load i8, ptr %347, align 1
  %5216 = trunc i8 %5215 to i7
  %5217 = call i7 @llvm.ctlz.i7(i7 %5216, i1 false)
  %5218 = sub i7 7, %5217
  %5219 = zext i7 %5218 to i32
  store i32 %5219, ptr %5214, align 4
  %5220 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 0
  %5221 = load i32, ptr %5220, align 16
  %5222 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 1
  %5223 = load i32, ptr %5222, align 4
  %5224 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 2
  %5225 = load i32, ptr %5224, align 8
  %5226 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 3
  %5227 = load i32, ptr %5226, align 4
  %5228 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 4
  %5229 = load i32, ptr %5228, align 16
  %5230 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 5
  %5231 = load i32, ptr %5230, align 4
  %5232 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 6
  %5233 = load i32, ptr %5232, align 8
  %5234 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 7
  %5235 = load i32, ptr %5234, align 4
  %5236 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 8
  %5237 = load i32, ptr %5236, align 16
  %5238 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 9
  %5239 = load i32, ptr %5238, align 4
  %5240 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 10
  %5241 = load i32, ptr %5240, align 8
  %5242 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 11
  %5243 = load i32, ptr %5242, align 4
  %5244 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef %5221, i32 noundef %5223, i32 noundef %5225, i32 noundef %5227, i32 noundef %5229, i32 noundef %5231, i32 noundef %5233, i32 noundef %5235, i32 noundef %5237, i32 noundef %5239, i32 noundef %5241, i32 noundef %5243)
  %5245 = load i8, ptr %347, align 1
  %5246 = trunc i8 %5245 to i7
  %5247 = call i7 @llvm.ctlz.i7(i7 %5246, i1 true)
  %5248 = sub i7 6, %5247
  %5249 = shl i7 1, %5248
  %5250 = icmp eq i7 %5246, 0
  %5251 = select i1 %5250, i7 0, i7 %5249
  %5252 = zext i7 %5251 to i8
  store i8 %5252, ptr %349, align 1
  %5253 = load i8, ptr %347, align 1
  %5254 = trunc i8 %5253 to i7
  %5255 = icmp ule i7 %5254, 1
  br i1 %5255, label %5261, label %5256

5256:                                             ; preds = %5141
  %5257 = sub i7 %5254, 1
  %5258 = call i7 @llvm.ctlz.i7(i7 %5257, i1 false)
  %5259 = sub i7 6, %5258
  %5260 = shl i7 2, %5259
  br label %5261

5261:                                             ; preds = %5256, %5141
  %5262 = phi i7 [ 1, %5141 ], [ %5260, %5256 ]
  %5263 = zext i7 %5262 to i8
  store i8 %5263, ptr %350, align 1
  %5264 = load i8, ptr %347, align 1
  %5265 = trunc i8 %5264 to i7
  %5266 = call i7 @llvm.fshl.i7(i7 %5265, i7 %5265, i7 3)
  %5267 = zext i7 %5266 to i8
  store i8 %5267, ptr %351, align 1
  %5268 = load i8, ptr %347, align 1
  %5269 = trunc i8 %5268 to i7
  %5270 = call i7 @llvm.fshr.i7(i7 %5269, i7 %5269, i7 3)
  %5271 = zext i7 %5270 to i8
  store i8 %5271, ptr %352, align 1
  %5272 = load i8, ptr %347, align 1
  %5273 = trunc i8 %5272 to i7
  %5274 = call i7 @llvm.fshl.i7(i7 %5273, i7 %5273, i7 0)
  %5275 = zext i7 %5274 to i8
  store i8 %5275, ptr %353, align 1
  %5276 = load i8, ptr %347, align 1
  %5277 = trunc i8 %5276 to i7
  %5278 = call i7 @llvm.fshl.i7(i7 %5277, i7 %5277, i7 6)
  %5279 = zext i7 %5278 to i8
  store i8 %5279, ptr %354, align 1
  %5280 = load i8, ptr %349, align 1
  %5281 = trunc i8 %5280 to i7
  %5282 = zext i7 %5281 to i256
  %5283 = lshr i256 %5282, 128
  %5284 = trunc i256 %5283 to i64
  %5285 = load i8, ptr %349, align 1
  %5286 = trunc i8 %5285 to i7
  %5287 = zext i7 %5286 to i256
  %5288 = lshr i256 %5287, 64
  %5289 = trunc i256 %5288 to i64
  %5290 = load i8, ptr %349, align 1
  %5291 = trunc i8 %5290 to i7
  %5292 = zext i7 %5291 to i64
  %5293 = load i8, ptr %350, align 1
  %5294 = trunc i8 %5293 to i7
  %5295 = zext i7 %5294 to i256
  %5296 = lshr i256 %5295, 128
  %5297 = trunc i256 %5296 to i64
  %5298 = load i8, ptr %350, align 1
  %5299 = trunc i8 %5298 to i7
  %5300 = zext i7 %5299 to i256
  %5301 = lshr i256 %5300, 64
  %5302 = trunc i256 %5301 to i64
  %5303 = load i8, ptr %350, align 1
  %5304 = trunc i8 %5303 to i7
  %5305 = zext i7 %5304 to i64
  %5306 = load i8, ptr %351, align 1
  %5307 = trunc i8 %5306 to i7
  %5308 = zext i7 %5307 to i256
  %5309 = lshr i256 %5308, 128
  %5310 = trunc i256 %5309 to i64
  %5311 = load i8, ptr %351, align 1
  %5312 = trunc i8 %5311 to i7
  %5313 = zext i7 %5312 to i256
  %5314 = lshr i256 %5313, 64
  %5315 = trunc i256 %5314 to i64
  %5316 = load i8, ptr %351, align 1
  %5317 = trunc i8 %5316 to i7
  %5318 = zext i7 %5317 to i64
  %5319 = load i8, ptr %352, align 1
  %5320 = trunc i8 %5319 to i7
  %5321 = zext i7 %5320 to i256
  %5322 = lshr i256 %5321, 128
  %5323 = trunc i256 %5322 to i64
  %5324 = load i8, ptr %352, align 1
  %5325 = trunc i8 %5324 to i7
  %5326 = zext i7 %5325 to i256
  %5327 = lshr i256 %5326, 64
  %5328 = trunc i256 %5327 to i64
  %5329 = load i8, ptr %352, align 1
  %5330 = trunc i8 %5329 to i7
  %5331 = zext i7 %5330 to i64
  %5332 = load i8, ptr %353, align 1
  %5333 = trunc i8 %5332 to i7
  %5334 = zext i7 %5333 to i64
  %5335 = load i8, ptr %354, align 1
  %5336 = trunc i8 %5335 to i7
  %5337 = zext i7 %5336 to i64
  %5338 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %5284, i64 noundef %5289, i64 noundef %5292, i64 noundef %5297, i64 noundef %5302, i64 noundef %5305, i64 noundef %5310, i64 noundef %5315, i64 noundef %5318, i64 noundef %5323, i64 noundef %5328, i64 noundef %5331, i64 noundef %5334, i64 noundef %5337)
  %5339 = load i8, ptr %347, align 1
  %5340 = trunc i8 %5339 to i7
  %5341 = zext i7 %5340 to i575
  %5342 = getelementptr inbounds [12 x i32], ptr %348, i64 0, i64 0
  %5343 = load i8, ptr %349, align 1
  %5344 = trunc i8 %5343 to i7
  %5345 = zext i7 %5344 to i575
  %5346 = load i8, ptr %350, align 1
  %5347 = trunc i8 %5346 to i7
  %5348 = zext i7 %5347 to i575
  %5349 = load i8, ptr %351, align 1
  %5350 = trunc i8 %5349 to i7
  %5351 = zext i7 %5350 to i575
  %5352 = load i8, ptr %352, align 1
  %5353 = trunc i8 %5352 to i7
  %5354 = zext i7 %5353 to i575
  %5355 = load i8, ptr %353, align 1
  %5356 = trunc i8 %5355 to i7
  %5357 = zext i7 %5356 to i575
  %5358 = load i8, ptr %354, align 1
  %5359 = trunc i8 %5358 to i7
  %5360 = zext i7 %5359 to i575
  %5361 = zext i575 %5341 to i576
  store i576 %5361, ptr %355, align 8
  %5362 = zext i575 %5345 to i576
  store i576 %5362, ptr %356, align 8
  %5363 = zext i575 %5348 to i576
  store i576 %5363, ptr %357, align 8
  %5364 = zext i575 %5351 to i576
  store i576 %5364, ptr %358, align 8
  %5365 = zext i575 %5354 to i576
  store i576 %5365, ptr %359, align 8
  %5366 = zext i575 %5357 to i576
  store i576 %5366, ptr %360, align 8
  %5367 = zext i575 %5360 to i576
  store i576 %5367, ptr %361, align 8
  call void @check(ptr noundef @.str.8, i32 noundef 7, ptr noundef byval([72 x i8]) align 8 %355, ptr noundef %5342, ptr noundef byval([72 x i8]) align 8 %356, ptr noundef byval([72 x i8]) align 8 %357, ptr noundef byval([72 x i8]) align 8 %358, ptr noundef byval([72 x i8]) align 8 %359, ptr noundef byval([72 x i8]) align 8 %360, ptr noundef byval([72 x i8]) align 8 %361)
  br label %5368

5368:                                             ; preds = %5261
  br label %5369

5369:                                             ; preds = %5368
  store i128 36893488147419103231, ptr %362, align 8
  %5370 = load i128, ptr %362, align 8
  %5371 = trunc i128 %5370 to i65
  %5372 = call i65 @llvm.ctlz.i65(i65 %5371, i1 false)
  %5373 = trunc i65 %5372 to i32
  store i32 %5373, ptr %363, align 4
  %5374 = getelementptr inbounds i32, ptr %363, i64 1
  %5375 = load i128, ptr %362, align 8
  %5376 = trunc i128 %5375 to i65
  %5377 = xor i65 %5376, -1
  %5378 = call i65 @llvm.ctlz.i65(i65 %5377, i1 false)
  %5379 = trunc i65 %5378 to i32
  store i32 %5379, ptr %5374, align 4
  %5380 = getelementptr inbounds i32, ptr %363, i64 2
  %5381 = load i128, ptr %362, align 8
  %5382 = trunc i128 %5381 to i65
  %5383 = call i65 @llvm.cttz.i65(i65 %5382, i1 false)
  %5384 = trunc i65 %5383 to i32
  store i32 %5384, ptr %5380, align 4
  %5385 = getelementptr inbounds i32, ptr %363, i64 3
  %5386 = load i128, ptr %362, align 8
  %5387 = trunc i128 %5386 to i65
  %5388 = xor i65 %5387, -1
  %5389 = call i65 @llvm.cttz.i65(i65 %5388, i1 false)
  %5390 = trunc i65 %5389 to i32
  store i32 %5390, ptr %5385, align 4
  %5391 = getelementptr inbounds i32, ptr %363, i64 4
  %5392 = load i128, ptr %362, align 8
  %5393 = trunc i128 %5392 to i65
  %5394 = xor i65 %5393, -1
  %5395 = call i65 @llvm.ctlz.i65(i65 %5394, i1 false)
  %5396 = add i65 %5395, 1
  %5397 = icmp eq i65 %5394, 0
  %5398 = select i1 %5397, i65 0, i65 %5396
  %5399 = trunc i65 %5398 to i32
  store i32 %5399, ptr %5391, align 4
  %5400 = getelementptr inbounds i32, ptr %363, i64 5
  %5401 = load i128, ptr %362, align 8
  %5402 = trunc i128 %5401 to i65
  %5403 = call i65 @llvm.ctlz.i65(i65 %5402, i1 false)
  %5404 = add i65 %5403, 1
  %5405 = icmp eq i65 %5402, 0
  %5406 = select i1 %5405, i65 0, i65 %5404
  %5407 = trunc i65 %5406 to i32
  store i32 %5407, ptr %5400, align 4
  %5408 = getelementptr inbounds i32, ptr %363, i64 6
  %5409 = load i128, ptr %362, align 8
  %5410 = trunc i128 %5409 to i65
  %5411 = xor i65 %5410, -1
  %5412 = call i65 @llvm.cttz.i65(i65 %5411, i1 false)
  %5413 = add i65 %5412, 1
  %5414 = icmp eq i65 %5411, 0
  %5415 = select i1 %5414, i65 0, i65 %5413
  %5416 = trunc i65 %5415 to i32
  store i32 %5416, ptr %5408, align 4
  %5417 = getelementptr inbounds i32, ptr %363, i64 7
  %5418 = load i128, ptr %362, align 8
  %5419 = trunc i128 %5418 to i65
  %5420 = call i65 @llvm.cttz.i65(i65 %5419, i1 false)
  %5421 = add i65 %5420, 1
  %5422 = icmp eq i65 %5419, 0
  %5423 = select i1 %5422, i65 0, i65 %5421
  %5424 = trunc i65 %5423 to i32
  store i32 %5424, ptr %5417, align 4
  %5425 = getelementptr inbounds i32, ptr %363, i64 8
  %5426 = load i128, ptr %362, align 8
  %5427 = trunc i128 %5426 to i65
  %5428 = call i65 @llvm.ctpop.i65(i65 %5427)
  %5429 = sub i65 65, %5428
  %5430 = trunc i65 %5429 to i32
  store i32 %5430, ptr %5425, align 4
  %5431 = getelementptr inbounds i32, ptr %363, i64 9
  %5432 = load i128, ptr %362, align 8
  %5433 = trunc i128 %5432 to i65
  %5434 = call i65 @llvm.ctpop.i65(i65 %5433)
  %5435 = trunc i65 %5434 to i32
  store i32 %5435, ptr %5431, align 4
  %5436 = getelementptr inbounds i32, ptr %363, i64 10
  %5437 = load i128, ptr %362, align 8
  %5438 = trunc i128 %5437 to i65
  %5439 = call i65 @llvm.ctpop.i65(i65 %5438)
  %5440 = icmp eq i65 %5439, 1
  %5441 = zext i1 %5440 to i32
  store i32 %5441, ptr %5436, align 4
  %5442 = getelementptr inbounds i32, ptr %363, i64 11
  %5443 = load i128, ptr %362, align 8
  %5444 = trunc i128 %5443 to i65
  %5445 = call i65 @llvm.ctlz.i65(i65 %5444, i1 false)
  %5446 = sub i65 65, %5445
  %5447 = trunc i65 %5446 to i32
  store i32 %5447, ptr %5442, align 4
  %5448 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 0
  %5449 = load i32, ptr %5448, align 16
  %5450 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 1
  %5451 = load i32, ptr %5450, align 4
  %5452 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 2
  %5453 = load i32, ptr %5452, align 8
  %5454 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 3
  %5455 = load i32, ptr %5454, align 4
  %5456 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 4
  %5457 = load i32, ptr %5456, align 16
  %5458 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 5
  %5459 = load i32, ptr %5458, align 4
  %5460 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 6
  %5461 = load i32, ptr %5460, align 8
  %5462 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 7
  %5463 = load i32, ptr %5462, align 4
  %5464 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 8
  %5465 = load i32, ptr %5464, align 16
  %5466 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 9
  %5467 = load i32, ptr %5466, align 4
  %5468 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 10
  %5469 = load i32, ptr %5468, align 8
  %5470 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 11
  %5471 = load i32, ptr %5470, align 4
  %5472 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef %5449, i32 noundef %5451, i32 noundef %5453, i32 noundef %5455, i32 noundef %5457, i32 noundef %5459, i32 noundef %5461, i32 noundef %5463, i32 noundef %5465, i32 noundef %5467, i32 noundef %5469, i32 noundef %5471)
  %5473 = load i128, ptr %362, align 8
  %5474 = trunc i128 %5473 to i65
  %5475 = call i65 @llvm.ctlz.i65(i65 %5474, i1 true)
  %5476 = sub i65 64, %5475
  %5477 = shl i65 1, %5476
  %5478 = icmp eq i65 %5474, 0
  %5479 = select i1 %5478, i65 0, i65 %5477
  %5480 = zext i65 %5479 to i128
  store i128 %5480, ptr %364, align 8
  %5481 = load i128, ptr %362, align 8
  %5482 = trunc i128 %5481 to i65
  %5483 = icmp ule i65 %5482, 1
  br i1 %5483, label %5489, label %5484

5484:                                             ; preds = %5369
  %5485 = sub i65 %5482, 1
  %5486 = call i65 @llvm.ctlz.i65(i65 %5485, i1 false)
  %5487 = sub i65 64, %5486
  %5488 = shl i65 2, %5487
  br label %5489

5489:                                             ; preds = %5484, %5369
  %5490 = phi i65 [ 1, %5369 ], [ %5488, %5484 ]
  %5491 = zext i65 %5490 to i128
  store i128 %5491, ptr %365, align 8
  %5492 = load i128, ptr %362, align 8
  %5493 = trunc i128 %5492 to i65
  %5494 = call i65 @llvm.fshl.i65(i65 %5493, i65 %5493, i65 3)
  %5495 = zext i65 %5494 to i128
  store i128 %5495, ptr %366, align 8
  %5496 = load i128, ptr %362, align 8
  %5497 = trunc i128 %5496 to i65
  %5498 = call i65 @llvm.fshr.i65(i65 %5497, i65 %5497, i65 3)
  %5499 = zext i65 %5498 to i128
  store i128 %5499, ptr %367, align 8
  %5500 = load i128, ptr %362, align 8
  %5501 = trunc i128 %5500 to i65
  %5502 = call i65 @llvm.fshl.i65(i65 %5501, i65 %5501, i65 0)
  %5503 = zext i65 %5502 to i128
  store i128 %5503, ptr %368, align 8
  %5504 = load i128, ptr %362, align 8
  %5505 = trunc i128 %5504 to i65
  %5506 = call i65 @llvm.fshl.i65(i65 %5505, i65 %5505, i65 25)
  %5507 = zext i65 %5506 to i128
  store i128 %5507, ptr %369, align 8
  %5508 = load i128, ptr %364, align 8
  %5509 = trunc i128 %5508 to i65
  %5510 = zext i65 %5509 to i256
  %5511 = lshr i256 %5510, 128
  %5512 = trunc i256 %5511 to i64
  %5513 = load i128, ptr %364, align 8
  %5514 = trunc i128 %5513 to i65
  %5515 = zext i65 %5514 to i256
  %5516 = lshr i256 %5515, 64
  %5517 = trunc i256 %5516 to i64
  %5518 = load i128, ptr %364, align 8
  %5519 = trunc i128 %5518 to i65
  %5520 = trunc i65 %5519 to i64
  %5521 = load i128, ptr %365, align 8
  %5522 = trunc i128 %5521 to i65
  %5523 = zext i65 %5522 to i256
  %5524 = lshr i256 %5523, 128
  %5525 = trunc i256 %5524 to i64
  %5526 = load i128, ptr %365, align 8
  %5527 = trunc i128 %5526 to i65
  %5528 = zext i65 %5527 to i256
  %5529 = lshr i256 %5528, 64
  %5530 = trunc i256 %5529 to i64
  %5531 = load i128, ptr %365, align 8
  %5532 = trunc i128 %5531 to i65
  %5533 = trunc i65 %5532 to i64
  %5534 = load i128, ptr %366, align 8
  %5535 = trunc i128 %5534 to i65
  %5536 = zext i65 %5535 to i256
  %5537 = lshr i256 %5536, 128
  %5538 = trunc i256 %5537 to i64
  %5539 = load i128, ptr %366, align 8
  %5540 = trunc i128 %5539 to i65
  %5541 = zext i65 %5540 to i256
  %5542 = lshr i256 %5541, 64
  %5543 = trunc i256 %5542 to i64
  %5544 = load i128, ptr %366, align 8
  %5545 = trunc i128 %5544 to i65
  %5546 = trunc i65 %5545 to i64
  %5547 = load i128, ptr %367, align 8
  %5548 = trunc i128 %5547 to i65
  %5549 = zext i65 %5548 to i256
  %5550 = lshr i256 %5549, 128
  %5551 = trunc i256 %5550 to i64
  %5552 = load i128, ptr %367, align 8
  %5553 = trunc i128 %5552 to i65
  %5554 = zext i65 %5553 to i256
  %5555 = lshr i256 %5554, 64
  %5556 = trunc i256 %5555 to i64
  %5557 = load i128, ptr %367, align 8
  %5558 = trunc i128 %5557 to i65
  %5559 = trunc i65 %5558 to i64
  %5560 = load i128, ptr %368, align 8
  %5561 = trunc i128 %5560 to i65
  %5562 = trunc i65 %5561 to i64
  %5563 = load i128, ptr %369, align 8
  %5564 = trunc i128 %5563 to i65
  %5565 = trunc i65 %5564 to i64
  %5566 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %5512, i64 noundef %5517, i64 noundef %5520, i64 noundef %5525, i64 noundef %5530, i64 noundef %5533, i64 noundef %5538, i64 noundef %5543, i64 noundef %5546, i64 noundef %5551, i64 noundef %5556, i64 noundef %5559, i64 noundef %5562, i64 noundef %5565)
  %5567 = load i128, ptr %362, align 8
  %5568 = trunc i128 %5567 to i65
  %5569 = zext i65 %5568 to i575
  %5570 = getelementptr inbounds [12 x i32], ptr %363, i64 0, i64 0
  %5571 = load i128, ptr %364, align 8
  %5572 = trunc i128 %5571 to i65
  %5573 = zext i65 %5572 to i575
  %5574 = load i128, ptr %365, align 8
  %5575 = trunc i128 %5574 to i65
  %5576 = zext i65 %5575 to i575
  %5577 = load i128, ptr %366, align 8
  %5578 = trunc i128 %5577 to i65
  %5579 = zext i65 %5578 to i575
  %5580 = load i128, ptr %367, align 8
  %5581 = trunc i128 %5580 to i65
  %5582 = zext i65 %5581 to i575
  %5583 = load i128, ptr %368, align 8
  %5584 = trunc i128 %5583 to i65
  %5585 = zext i65 %5584 to i575
  %5586 = load i128, ptr %369, align 8
  %5587 = trunc i128 %5586 to i65
  %5588 = zext i65 %5587 to i575
  %5589 = zext i575 %5569 to i576
  store i576 %5589, ptr %370, align 8
  %5590 = zext i575 %5573 to i576
  store i576 %5590, ptr %371, align 8
  %5591 = zext i575 %5576 to i576
  store i576 %5591, ptr %372, align 8
  %5592 = zext i575 %5579 to i576
  store i576 %5592, ptr %373, align 8
  %5593 = zext i575 %5582 to i576
  store i576 %5593, ptr %374, align 8
  %5594 = zext i575 %5585 to i576
  store i576 %5594, ptr %375, align 8
  %5595 = zext i575 %5588 to i576
  store i576 %5595, ptr %376, align 8
  call void @check(ptr noundef @.str.9, i32 noundef 65, ptr noundef byval([72 x i8]) align 8 %370, ptr noundef %5570, ptr noundef byval([72 x i8]) align 8 %371, ptr noundef byval([72 x i8]) align 8 %372, ptr noundef byval([72 x i8]) align 8 %373, ptr noundef byval([72 x i8]) align 8 %374, ptr noundef byval([72 x i8]) align 8 %375, ptr noundef byval([72 x i8]) align 8 %376)
  br label %5596

5596:                                             ; preds = %5489
  br label %5597

5597:                                             ; preds = %5596
  store i192 680564733841876926926749214863536422911, ptr %377, align 8
  %5598 = load i192, ptr %377, align 8
  %5599 = trunc i192 %5598 to i129
  %5600 = call i129 @llvm.ctlz.i129(i129 %5599, i1 false)
  %5601 = trunc i129 %5600 to i32
  store i32 %5601, ptr %378, align 4
  %5602 = getelementptr inbounds i32, ptr %378, i64 1
  %5603 = load i192, ptr %377, align 8
  %5604 = trunc i192 %5603 to i129
  %5605 = xor i129 %5604, -1
  %5606 = call i129 @llvm.ctlz.i129(i129 %5605, i1 false)
  %5607 = trunc i129 %5606 to i32
  store i32 %5607, ptr %5602, align 4
  %5608 = getelementptr inbounds i32, ptr %378, i64 2
  %5609 = load i192, ptr %377, align 8
  %5610 = trunc i192 %5609 to i129
  %5611 = call i129 @llvm.cttz.i129(i129 %5610, i1 false)
  %5612 = trunc i129 %5611 to i32
  store i32 %5612, ptr %5608, align 4
  %5613 = getelementptr inbounds i32, ptr %378, i64 3
  %5614 = load i192, ptr %377, align 8
  %5615 = trunc i192 %5614 to i129
  %5616 = xor i129 %5615, -1
  %5617 = call i129 @llvm.cttz.i129(i129 %5616, i1 false)
  %5618 = trunc i129 %5617 to i32
  store i32 %5618, ptr %5613, align 4
  %5619 = getelementptr inbounds i32, ptr %378, i64 4
  %5620 = load i192, ptr %377, align 8
  %5621 = trunc i192 %5620 to i129
  %5622 = xor i129 %5621, -1
  %5623 = call i129 @llvm.ctlz.i129(i129 %5622, i1 false)
  %5624 = add i129 %5623, 1
  %5625 = icmp eq i129 %5622, 0
  %5626 = select i1 %5625, i129 0, i129 %5624
  %5627 = trunc i129 %5626 to i32
  store i32 %5627, ptr %5619, align 4
  %5628 = getelementptr inbounds i32, ptr %378, i64 5
  %5629 = load i192, ptr %377, align 8
  %5630 = trunc i192 %5629 to i129
  %5631 = call i129 @llvm.ctlz.i129(i129 %5630, i1 false)
  %5632 = add i129 %5631, 1
  %5633 = icmp eq i129 %5630, 0
  %5634 = select i1 %5633, i129 0, i129 %5632
  %5635 = trunc i129 %5634 to i32
  store i32 %5635, ptr %5628, align 4
  %5636 = getelementptr inbounds i32, ptr %378, i64 6
  %5637 = load i192, ptr %377, align 8
  %5638 = trunc i192 %5637 to i129
  %5639 = xor i129 %5638, -1
  %5640 = call i129 @llvm.cttz.i129(i129 %5639, i1 false)
  %5641 = add i129 %5640, 1
  %5642 = icmp eq i129 %5639, 0
  %5643 = select i1 %5642, i129 0, i129 %5641
  %5644 = trunc i129 %5643 to i32
  store i32 %5644, ptr %5636, align 4
  %5645 = getelementptr inbounds i32, ptr %378, i64 7
  %5646 = load i192, ptr %377, align 8
  %5647 = trunc i192 %5646 to i129
  %5648 = call i129 @llvm.cttz.i129(i129 %5647, i1 false)
  %5649 = add i129 %5648, 1
  %5650 = icmp eq i129 %5647, 0
  %5651 = select i1 %5650, i129 0, i129 %5649
  %5652 = trunc i129 %5651 to i32
  store i32 %5652, ptr %5645, align 4
  %5653 = getelementptr inbounds i32, ptr %378, i64 8
  %5654 = load i192, ptr %377, align 8
  %5655 = trunc i192 %5654 to i129
  %5656 = call i129 @llvm.ctpop.i129(i129 %5655)
  %5657 = sub i129 129, %5656
  %5658 = trunc i129 %5657 to i32
  store i32 %5658, ptr %5653, align 4
  %5659 = getelementptr inbounds i32, ptr %378, i64 9
  %5660 = load i192, ptr %377, align 8
  %5661 = trunc i192 %5660 to i129
  %5662 = call i129 @llvm.ctpop.i129(i129 %5661)
  %5663 = trunc i129 %5662 to i32
  store i32 %5663, ptr %5659, align 4
  %5664 = getelementptr inbounds i32, ptr %378, i64 10
  %5665 = load i192, ptr %377, align 8
  %5666 = trunc i192 %5665 to i129
  %5667 = call i129 @llvm.ctpop.i129(i129 %5666)
  %5668 = icmp eq i129 %5667, 1
  %5669 = zext i1 %5668 to i32
  store i32 %5669, ptr %5664, align 4
  %5670 = getelementptr inbounds i32, ptr %378, i64 11
  %5671 = load i192, ptr %377, align 8
  %5672 = trunc i192 %5671 to i129
  %5673 = call i129 @llvm.ctlz.i129(i129 %5672, i1 false)
  %5674 = sub i129 129, %5673
  %5675 = trunc i129 %5674 to i32
  store i32 %5675, ptr %5670, align 4
  %5676 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 0
  %5677 = load i32, ptr %5676, align 16
  %5678 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 1
  %5679 = load i32, ptr %5678, align 4
  %5680 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 2
  %5681 = load i32, ptr %5680, align 8
  %5682 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 3
  %5683 = load i32, ptr %5682, align 4
  %5684 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 4
  %5685 = load i32, ptr %5684, align 16
  %5686 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 5
  %5687 = load i32, ptr %5686, align 4
  %5688 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 6
  %5689 = load i32, ptr %5688, align 8
  %5690 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 7
  %5691 = load i32, ptr %5690, align 4
  %5692 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 8
  %5693 = load i32, ptr %5692, align 16
  %5694 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 9
  %5695 = load i32, ptr %5694, align 4
  %5696 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 10
  %5697 = load i32, ptr %5696, align 8
  %5698 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 11
  %5699 = load i32, ptr %5698, align 4
  %5700 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %5677, i32 noundef %5679, i32 noundef %5681, i32 noundef %5683, i32 noundef %5685, i32 noundef %5687, i32 noundef %5689, i32 noundef %5691, i32 noundef %5693, i32 noundef %5695, i32 noundef %5697, i32 noundef %5699)
  %5701 = load i192, ptr %377, align 8
  %5702 = trunc i192 %5701 to i129
  %5703 = call i129 @llvm.ctlz.i129(i129 %5702, i1 true)
  %5704 = sub i129 128, %5703
  %5705 = shl i129 1, %5704
  %5706 = icmp eq i129 %5702, 0
  %5707 = select i1 %5706, i129 0, i129 %5705
  %5708 = zext i129 %5707 to i192
  store i192 %5708, ptr %379, align 8
  %5709 = load i192, ptr %377, align 8
  %5710 = trunc i192 %5709 to i129
  %5711 = icmp ule i129 %5710, 1
  br i1 %5711, label %5717, label %5712

5712:                                             ; preds = %5597
  %5713 = sub i129 %5710, 1
  %5714 = call i129 @llvm.ctlz.i129(i129 %5713, i1 false)
  %5715 = sub i129 128, %5714
  %5716 = shl i129 2, %5715
  br label %5717

5717:                                             ; preds = %5712, %5597
  %5718 = phi i129 [ 1, %5597 ], [ %5716, %5712 ]
  %5719 = zext i129 %5718 to i192
  store i192 %5719, ptr %380, align 8
  %5720 = load i192, ptr %377, align 8
  %5721 = trunc i192 %5720 to i129
  %5722 = call i129 @llvm.fshl.i129(i129 %5721, i129 %5721, i129 3)
  %5723 = zext i129 %5722 to i192
  store i192 %5723, ptr %381, align 8
  %5724 = load i192, ptr %377, align 8
  %5725 = trunc i192 %5724 to i129
  %5726 = call i129 @llvm.fshr.i129(i129 %5725, i129 %5725, i129 3)
  %5727 = zext i129 %5726 to i192
  store i192 %5727, ptr %382, align 8
  %5728 = load i192, ptr %377, align 8
  %5729 = trunc i192 %5728 to i129
  %5730 = call i129 @llvm.fshl.i129(i129 %5729, i129 %5729, i129 0)
  %5731 = zext i129 %5730 to i192
  store i192 %5731, ptr %383, align 8
  %5732 = load i192, ptr %377, align 8
  %5733 = trunc i192 %5732 to i129
  %5734 = call i129 @llvm.fshl.i129(i129 %5733, i129 %5733, i129 97)
  %5735 = zext i129 %5734 to i192
  store i192 %5735, ptr %384, align 8
  %5736 = load i192, ptr %379, align 8
  %5737 = trunc i192 %5736 to i129
  %5738 = zext i129 %5737 to i256
  %5739 = lshr i256 %5738, 128
  %5740 = trunc i256 %5739 to i64
  %5741 = load i192, ptr %379, align 8
  %5742 = trunc i192 %5741 to i129
  %5743 = zext i129 %5742 to i256
  %5744 = lshr i256 %5743, 64
  %5745 = trunc i256 %5744 to i64
  %5746 = load i192, ptr %379, align 8
  %5747 = trunc i192 %5746 to i129
  %5748 = trunc i129 %5747 to i64
  %5749 = load i192, ptr %380, align 8
  %5750 = trunc i192 %5749 to i129
  %5751 = zext i129 %5750 to i256
  %5752 = lshr i256 %5751, 128
  %5753 = trunc i256 %5752 to i64
  %5754 = load i192, ptr %380, align 8
  %5755 = trunc i192 %5754 to i129
  %5756 = zext i129 %5755 to i256
  %5757 = lshr i256 %5756, 64
  %5758 = trunc i256 %5757 to i64
  %5759 = load i192, ptr %380, align 8
  %5760 = trunc i192 %5759 to i129
  %5761 = trunc i129 %5760 to i64
  %5762 = load i192, ptr %381, align 8
  %5763 = trunc i192 %5762 to i129
  %5764 = zext i129 %5763 to i256
  %5765 = lshr i256 %5764, 128
  %5766 = trunc i256 %5765 to i64
  %5767 = load i192, ptr %381, align 8
  %5768 = trunc i192 %5767 to i129
  %5769 = zext i129 %5768 to i256
  %5770 = lshr i256 %5769, 64
  %5771 = trunc i256 %5770 to i64
  %5772 = load i192, ptr %381, align 8
  %5773 = trunc i192 %5772 to i129
  %5774 = trunc i129 %5773 to i64
  %5775 = load i192, ptr %382, align 8
  %5776 = trunc i192 %5775 to i129
  %5777 = zext i129 %5776 to i256
  %5778 = lshr i256 %5777, 128
  %5779 = trunc i256 %5778 to i64
  %5780 = load i192, ptr %382, align 8
  %5781 = trunc i192 %5780 to i129
  %5782 = zext i129 %5781 to i256
  %5783 = lshr i256 %5782, 64
  %5784 = trunc i256 %5783 to i64
  %5785 = load i192, ptr %382, align 8
  %5786 = trunc i192 %5785 to i129
  %5787 = trunc i129 %5786 to i64
  %5788 = load i192, ptr %383, align 8
  %5789 = trunc i192 %5788 to i129
  %5790 = trunc i129 %5789 to i64
  %5791 = load i192, ptr %384, align 8
  %5792 = trunc i192 %5791 to i129
  %5793 = trunc i129 %5792 to i64
  %5794 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %5740, i64 noundef %5745, i64 noundef %5748, i64 noundef %5753, i64 noundef %5758, i64 noundef %5761, i64 noundef %5766, i64 noundef %5771, i64 noundef %5774, i64 noundef %5779, i64 noundef %5784, i64 noundef %5787, i64 noundef %5790, i64 noundef %5793)
  %5795 = load i192, ptr %377, align 8
  %5796 = trunc i192 %5795 to i129
  %5797 = zext i129 %5796 to i575
  %5798 = getelementptr inbounds [12 x i32], ptr %378, i64 0, i64 0
  %5799 = load i192, ptr %379, align 8
  %5800 = trunc i192 %5799 to i129
  %5801 = zext i129 %5800 to i575
  %5802 = load i192, ptr %380, align 8
  %5803 = trunc i192 %5802 to i129
  %5804 = zext i129 %5803 to i575
  %5805 = load i192, ptr %381, align 8
  %5806 = trunc i192 %5805 to i129
  %5807 = zext i129 %5806 to i575
  %5808 = load i192, ptr %382, align 8
  %5809 = trunc i192 %5808 to i129
  %5810 = zext i129 %5809 to i575
  %5811 = load i192, ptr %383, align 8
  %5812 = trunc i192 %5811 to i129
  %5813 = zext i129 %5812 to i575
  %5814 = load i192, ptr %384, align 8
  %5815 = trunc i192 %5814 to i129
  %5816 = zext i129 %5815 to i575
  %5817 = zext i575 %5797 to i576
  store i576 %5817, ptr %385, align 8
  %5818 = zext i575 %5801 to i576
  store i576 %5818, ptr %386, align 8
  %5819 = zext i575 %5804 to i576
  store i576 %5819, ptr %387, align 8
  %5820 = zext i575 %5807 to i576
  store i576 %5820, ptr %388, align 8
  %5821 = zext i575 %5810 to i576
  store i576 %5821, ptr %389, align 8
  %5822 = zext i575 %5813 to i576
  store i576 %5822, ptr %390, align 8
  %5823 = zext i575 %5816 to i576
  store i576 %5823, ptr %391, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %385, ptr noundef %5798, ptr noundef byval([72 x i8]) align 8 %386, ptr noundef byval([72 x i8]) align 8 %387, ptr noundef byval([72 x i8]) align 8 %388, ptr noundef byval([72 x i8]) align 8 %389, ptr noundef byval([72 x i8]) align 8 %390, ptr noundef byval([72 x i8]) align 8 %391)
  br label %5824

5824:                                             ; preds = %5717
  br label %5825

5825:                                             ; preds = %5824
  store i256 -1, ptr %392, align 8
  %5826 = load i256, ptr %392, align 8
  %5827 = call i256 @llvm.ctlz.i256(i256 %5826, i1 false)
  %5828 = trunc i256 %5827 to i32
  store i32 %5828, ptr %393, align 4
  %5829 = getelementptr inbounds i32, ptr %393, i64 1
  %5830 = load i256, ptr %392, align 8
  %5831 = xor i256 %5830, -1
  %5832 = call i256 @llvm.ctlz.i256(i256 %5831, i1 false)
  %5833 = trunc i256 %5832 to i32
  store i32 %5833, ptr %5829, align 4
  %5834 = getelementptr inbounds i32, ptr %393, i64 2
  %5835 = load i256, ptr %392, align 8
  %5836 = call i256 @llvm.cttz.i256(i256 %5835, i1 false)
  %5837 = trunc i256 %5836 to i32
  store i32 %5837, ptr %5834, align 4
  %5838 = getelementptr inbounds i32, ptr %393, i64 3
  %5839 = load i256, ptr %392, align 8
  %5840 = xor i256 %5839, -1
  %5841 = call i256 @llvm.cttz.i256(i256 %5840, i1 false)
  %5842 = trunc i256 %5841 to i32
  store i32 %5842, ptr %5838, align 4
  %5843 = getelementptr inbounds i32, ptr %393, i64 4
  %5844 = load i256, ptr %392, align 8
  %5845 = xor i256 %5844, -1
  %5846 = call i256 @llvm.ctlz.i256(i256 %5845, i1 false)
  %5847 = add i256 %5846, 1
  %5848 = icmp eq i256 %5845, 0
  %5849 = select i1 %5848, i256 0, i256 %5847
  %5850 = trunc i256 %5849 to i32
  store i32 %5850, ptr %5843, align 4
  %5851 = getelementptr inbounds i32, ptr %393, i64 5
  %5852 = load i256, ptr %392, align 8
  %5853 = call i256 @llvm.ctlz.i256(i256 %5852, i1 false)
  %5854 = add i256 %5853, 1
  %5855 = icmp eq i256 %5852, 0
  %5856 = select i1 %5855, i256 0, i256 %5854
  %5857 = trunc i256 %5856 to i32
  store i32 %5857, ptr %5851, align 4
  %5858 = getelementptr inbounds i32, ptr %393, i64 6
  %5859 = load i256, ptr %392, align 8
  %5860 = xor i256 %5859, -1
  %5861 = call i256 @llvm.cttz.i256(i256 %5860, i1 false)
  %5862 = add i256 %5861, 1
  %5863 = icmp eq i256 %5860, 0
  %5864 = select i1 %5863, i256 0, i256 %5862
  %5865 = trunc i256 %5864 to i32
  store i32 %5865, ptr %5858, align 4
  %5866 = getelementptr inbounds i32, ptr %393, i64 7
  %5867 = load i256, ptr %392, align 8
  %5868 = call i256 @llvm.cttz.i256(i256 %5867, i1 false)
  %5869 = add i256 %5868, 1
  %5870 = icmp eq i256 %5867, 0
  %5871 = select i1 %5870, i256 0, i256 %5869
  %5872 = trunc i256 %5871 to i32
  store i32 %5872, ptr %5866, align 4
  %5873 = getelementptr inbounds i32, ptr %393, i64 8
  %5874 = load i256, ptr %392, align 8
  %5875 = call i256 @llvm.ctpop.i256(i256 %5874)
  %5876 = sub i256 256, %5875
  %5877 = trunc i256 %5876 to i32
  store i32 %5877, ptr %5873, align 4
  %5878 = getelementptr inbounds i32, ptr %393, i64 9
  %5879 = load i256, ptr %392, align 8
  %5880 = call i256 @llvm.ctpop.i256(i256 %5879)
  %5881 = trunc i256 %5880 to i32
  store i32 %5881, ptr %5878, align 4
  %5882 = getelementptr inbounds i32, ptr %393, i64 10
  %5883 = load i256, ptr %392, align 8
  %5884 = call i256 @llvm.ctpop.i256(i256 %5883)
  %5885 = icmp eq i256 %5884, 1
  %5886 = zext i1 %5885 to i32
  store i32 %5886, ptr %5882, align 4
  %5887 = getelementptr inbounds i32, ptr %393, i64 11
  %5888 = load i256, ptr %392, align 8
  %5889 = call i256 @llvm.ctlz.i256(i256 %5888, i1 false)
  %5890 = sub i256 256, %5889
  %5891 = trunc i256 %5890 to i32
  store i32 %5891, ptr %5887, align 4
  %5892 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 0
  %5893 = load i32, ptr %5892, align 16
  %5894 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 1
  %5895 = load i32, ptr %5894, align 4
  %5896 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 2
  %5897 = load i32, ptr %5896, align 8
  %5898 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 3
  %5899 = load i32, ptr %5898, align 4
  %5900 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 4
  %5901 = load i32, ptr %5900, align 16
  %5902 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 5
  %5903 = load i32, ptr %5902, align 4
  %5904 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 6
  %5905 = load i32, ptr %5904, align 8
  %5906 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 7
  %5907 = load i32, ptr %5906, align 4
  %5908 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 8
  %5909 = load i32, ptr %5908, align 16
  %5910 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 9
  %5911 = load i32, ptr %5910, align 4
  %5912 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 10
  %5913 = load i32, ptr %5912, align 8
  %5914 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 11
  %5915 = load i32, ptr %5914, align 4
  %5916 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %5893, i32 noundef %5895, i32 noundef %5897, i32 noundef %5899, i32 noundef %5901, i32 noundef %5903, i32 noundef %5905, i32 noundef %5907, i32 noundef %5909, i32 noundef %5911, i32 noundef %5913, i32 noundef %5915)
  %5917 = load i256, ptr %392, align 8
  %5918 = call i256 @llvm.ctlz.i256(i256 %5917, i1 true)
  %5919 = sub i256 255, %5918
  %5920 = shl i256 1, %5919
  %5921 = icmp eq i256 %5917, 0
  %5922 = select i1 %5921, i256 0, i256 %5920
  store i256 %5922, ptr %394, align 8
  %5923 = load i256, ptr %392, align 8
  %5924 = icmp ule i256 %5923, 1
  br i1 %5924, label %5930, label %5925

5925:                                             ; preds = %5825
  %5926 = sub i256 %5923, 1
  %5927 = call i256 @llvm.ctlz.i256(i256 %5926, i1 false)
  %5928 = sub i256 255, %5927
  %5929 = shl i256 2, %5928
  br label %5930

5930:                                             ; preds = %5925, %5825
  %5931 = phi i256 [ 1, %5825 ], [ %5929, %5925 ]
  store i256 %5931, ptr %395, align 8
  %5932 = load i256, ptr %392, align 8
  %5933 = call i256 @llvm.fshl.i256(i256 %5932, i256 %5932, i256 3)
  store i256 %5933, ptr %396, align 8
  %5934 = load i256, ptr %392, align 8
  %5935 = call i256 @llvm.fshr.i256(i256 %5934, i256 %5934, i256 3)
  store i256 %5935, ptr %397, align 8
  %5936 = load i256, ptr %392, align 8
  %5937 = call i256 @llvm.fshl.i256(i256 %5936, i256 %5936, i256 0)
  store i256 %5937, ptr %398, align 8
  %5938 = load i256, ptr %392, align 8
  %5939 = call i256 @llvm.fshl.i256(i256 %5938, i256 %5938, i256 232)
  store i256 %5939, ptr %399, align 8
  %5940 = load i256, ptr %394, align 8
  %5941 = lshr i256 %5940, 128
  %5942 = trunc i256 %5941 to i64
  %5943 = load i256, ptr %394, align 8
  %5944 = lshr i256 %5943, 64
  %5945 = trunc i256 %5944 to i64
  %5946 = load i256, ptr %394, align 8
  %5947 = trunc i256 %5946 to i64
  %5948 = load i256, ptr %395, align 8
  %5949 = lshr i256 %5948, 128
  %5950 = trunc i256 %5949 to i64
  %5951 = load i256, ptr %395, align 8
  %5952 = lshr i256 %5951, 64
  %5953 = trunc i256 %5952 to i64
  %5954 = load i256, ptr %395, align 8
  %5955 = trunc i256 %5954 to i64
  %5956 = load i256, ptr %396, align 8
  %5957 = lshr i256 %5956, 128
  %5958 = trunc i256 %5957 to i64
  %5959 = load i256, ptr %396, align 8
  %5960 = lshr i256 %5959, 64
  %5961 = trunc i256 %5960 to i64
  %5962 = load i256, ptr %396, align 8
  %5963 = trunc i256 %5962 to i64
  %5964 = load i256, ptr %397, align 8
  %5965 = lshr i256 %5964, 128
  %5966 = trunc i256 %5965 to i64
  %5967 = load i256, ptr %397, align 8
  %5968 = lshr i256 %5967, 64
  %5969 = trunc i256 %5968 to i64
  %5970 = load i256, ptr %397, align 8
  %5971 = trunc i256 %5970 to i64
  %5972 = load i256, ptr %398, align 8
  %5973 = trunc i256 %5972 to i64
  %5974 = load i256, ptr %399, align 8
  %5975 = trunc i256 %5974 to i64
  %5976 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %5942, i64 noundef %5945, i64 noundef %5947, i64 noundef %5950, i64 noundef %5953, i64 noundef %5955, i64 noundef %5958, i64 noundef %5961, i64 noundef %5963, i64 noundef %5966, i64 noundef %5969, i64 noundef %5971, i64 noundef %5973, i64 noundef %5975)
  %5977 = load i256, ptr %392, align 8
  %5978 = zext i256 %5977 to i575
  %5979 = getelementptr inbounds [12 x i32], ptr %393, i64 0, i64 0
  %5980 = load i256, ptr %394, align 8
  %5981 = zext i256 %5980 to i575
  %5982 = load i256, ptr %395, align 8
  %5983 = zext i256 %5982 to i575
  %5984 = load i256, ptr %396, align 8
  %5985 = zext i256 %5984 to i575
  %5986 = load i256, ptr %397, align 8
  %5987 = zext i256 %5986 to i575
  %5988 = load i256, ptr %398, align 8
  %5989 = zext i256 %5988 to i575
  %5990 = load i256, ptr %399, align 8
  %5991 = zext i256 %5990 to i575
  %5992 = zext i575 %5978 to i576
  store i576 %5992, ptr %400, align 8
  %5993 = zext i575 %5981 to i576
  store i576 %5993, ptr %401, align 8
  %5994 = zext i575 %5983 to i576
  store i576 %5994, ptr %402, align 8
  %5995 = zext i575 %5985 to i576
  store i576 %5995, ptr %403, align 8
  %5996 = zext i575 %5987 to i576
  store i576 %5996, ptr %404, align 8
  %5997 = zext i575 %5989 to i576
  store i576 %5997, ptr %405, align 8
  %5998 = zext i575 %5991 to i576
  store i576 %5998, ptr %406, align 8
  call void @check(ptr noundef @.str.11, i32 noundef 256, ptr noundef byval([72 x i8]) align 8 %400, ptr noundef %5979, ptr noundef byval([72 x i8]) align 8 %401, ptr noundef byval([72 x i8]) align 8 %402, ptr noundef byval([72 x i8]) align 8 %403, ptr noundef byval([72 x i8]) align 8 %404, ptr noundef byval([72 x i8]) align 8 %405, ptr noundef byval([72 x i8]) align 8 %406)
  br label %5999

5999:                                             ; preds = %5930
  %6000 = call i32 @puts(ptr noundef @.str.14)
  br label %6001

6001:                                             ; preds = %5999
  store i8 80, ptr %407, align 1
  %6002 = load i8, ptr %407, align 1
  %6003 = call i8 @llvm.ctlz.i8(i8 %6002, i1 false)
  %6004 = zext i8 %6003 to i32
  store i32 %6004, ptr %408, align 4
  %6005 = getelementptr inbounds i32, ptr %408, i64 1
  %6006 = load i8, ptr %407, align 1
  %6007 = xor i8 %6006, -1
  %6008 = call i8 @llvm.ctlz.i8(i8 %6007, i1 false)
  %6009 = zext i8 %6008 to i32
  store i32 %6009, ptr %6005, align 4
  %6010 = getelementptr inbounds i32, ptr %408, i64 2
  %6011 = load i8, ptr %407, align 1
  %6012 = call i8 @llvm.cttz.i8(i8 %6011, i1 false)
  %6013 = zext i8 %6012 to i32
  store i32 %6013, ptr %6010, align 4
  %6014 = getelementptr inbounds i32, ptr %408, i64 3
  %6015 = load i8, ptr %407, align 1
  %6016 = xor i8 %6015, -1
  %6017 = call i8 @llvm.cttz.i8(i8 %6016, i1 false)
  %6018 = zext i8 %6017 to i32
  store i32 %6018, ptr %6014, align 4
  %6019 = getelementptr inbounds i32, ptr %408, i64 4
  %6020 = load i8, ptr %407, align 1
  %6021 = xor i8 %6020, -1
  %6022 = call i8 @llvm.ctlz.i8(i8 %6021, i1 false)
  %6023 = add i8 %6022, 1
  %6024 = icmp eq i8 %6021, 0
  %6025 = select i1 %6024, i8 0, i8 %6023
  %6026 = zext i8 %6025 to i32
  store i32 %6026, ptr %6019, align 4
  %6027 = getelementptr inbounds i32, ptr %408, i64 5
  %6028 = load i8, ptr %407, align 1
  %6029 = call i8 @llvm.ctlz.i8(i8 %6028, i1 false)
  %6030 = add i8 %6029, 1
  %6031 = icmp eq i8 %6028, 0
  %6032 = select i1 %6031, i8 0, i8 %6030
  %6033 = zext i8 %6032 to i32
  store i32 %6033, ptr %6027, align 4
  %6034 = getelementptr inbounds i32, ptr %408, i64 6
  %6035 = load i8, ptr %407, align 1
  %6036 = xor i8 %6035, -1
  %6037 = call i8 @llvm.cttz.i8(i8 %6036, i1 false)
  %6038 = add i8 %6037, 1
  %6039 = icmp eq i8 %6036, 0
  %6040 = select i1 %6039, i8 0, i8 %6038
  %6041 = zext i8 %6040 to i32
  store i32 %6041, ptr %6034, align 4
  %6042 = getelementptr inbounds i32, ptr %408, i64 7
  %6043 = load i8, ptr %407, align 1
  %6044 = call i8 @llvm.cttz.i8(i8 %6043, i1 false)
  %6045 = add i8 %6044, 1
  %6046 = icmp eq i8 %6043, 0
  %6047 = select i1 %6046, i8 0, i8 %6045
  %6048 = zext i8 %6047 to i32
  store i32 %6048, ptr %6042, align 4
  %6049 = getelementptr inbounds i32, ptr %408, i64 8
  %6050 = load i8, ptr %407, align 1
  %6051 = call i8 @llvm.ctpop.i8(i8 %6050)
  %6052 = sub i8 8, %6051
  %6053 = zext i8 %6052 to i32
  store i32 %6053, ptr %6049, align 4
  %6054 = getelementptr inbounds i32, ptr %408, i64 9
  %6055 = load i8, ptr %407, align 1
  %6056 = call i8 @llvm.ctpop.i8(i8 %6055)
  %6057 = zext i8 %6056 to i32
  store i32 %6057, ptr %6054, align 4
  %6058 = getelementptr inbounds i32, ptr %408, i64 10
  %6059 = load i8, ptr %407, align 1
  %6060 = call i8 @llvm.ctpop.i8(i8 %6059)
  %6061 = icmp eq i8 %6060, 1
  %6062 = zext i1 %6061 to i32
  store i32 %6062, ptr %6058, align 4
  %6063 = getelementptr inbounds i32, ptr %408, i64 11
  %6064 = load i8, ptr %407, align 1
  %6065 = call i8 @llvm.ctlz.i8(i8 %6064, i1 false)
  %6066 = sub i8 8, %6065
  %6067 = zext i8 %6066 to i32
  store i32 %6067, ptr %6063, align 4
  %6068 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 0
  %6069 = load i32, ptr %6068, align 16
  %6070 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 1
  %6071 = load i32, ptr %6070, align 4
  %6072 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 2
  %6073 = load i32, ptr %6072, align 8
  %6074 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 3
  %6075 = load i32, ptr %6074, align 4
  %6076 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 4
  %6077 = load i32, ptr %6076, align 16
  %6078 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 5
  %6079 = load i32, ptr %6078, align 4
  %6080 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 6
  %6081 = load i32, ptr %6080, align 8
  %6082 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 7
  %6083 = load i32, ptr %6082, align 4
  %6084 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 8
  %6085 = load i32, ptr %6084, align 16
  %6086 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 9
  %6087 = load i32, ptr %6086, align 4
  %6088 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 10
  %6089 = load i32, ptr %6088, align 8
  %6090 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 11
  %6091 = load i32, ptr %6090, align 4
  %6092 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %6069, i32 noundef %6071, i32 noundef %6073, i32 noundef %6075, i32 noundef %6077, i32 noundef %6079, i32 noundef %6081, i32 noundef %6083, i32 noundef %6085, i32 noundef %6087, i32 noundef %6089, i32 noundef %6091)
  %6093 = load i8, ptr %407, align 1
  %6094 = call i8 @llvm.ctlz.i8(i8 %6093, i1 true)
  %6095 = sub i8 7, %6094
  %6096 = shl i8 1, %6095
  %6097 = icmp eq i8 %6093, 0
  %6098 = select i1 %6097, i8 0, i8 %6096
  store i8 %6098, ptr %409, align 1
  %6099 = load i8, ptr %407, align 1
  %6100 = icmp ule i8 %6099, 1
  br i1 %6100, label %6106, label %6101

6101:                                             ; preds = %6001
  %6102 = sub i8 %6099, 1
  %6103 = call i8 @llvm.ctlz.i8(i8 %6102, i1 false)
  %6104 = sub i8 7, %6103
  %6105 = shl i8 2, %6104
  br label %6106

6106:                                             ; preds = %6101, %6001
  %6107 = phi i8 [ 1, %6001 ], [ %6105, %6101 ]
  store i8 %6107, ptr %410, align 1
  %6108 = load i8, ptr %407, align 1
  %6109 = call i8 @llvm.fshl.i8(i8 %6108, i8 %6108, i8 3)
  store i8 %6109, ptr %411, align 1
  %6110 = load i8, ptr %407, align 1
  %6111 = call i8 @llvm.fshr.i8(i8 %6110, i8 %6110, i8 3)
  store i8 %6111, ptr %412, align 1
  %6112 = load i8, ptr %407, align 1
  %6113 = call i8 @llvm.fshl.i8(i8 %6112, i8 %6112, i8 0)
  store i8 %6113, ptr %413, align 1
  %6114 = load i8, ptr %407, align 1
  %6115 = call i8 @llvm.fshl.i8(i8 %6114, i8 %6114, i8 0)
  store i8 %6115, ptr %414, align 1
  %6116 = load i8, ptr %409, align 1
  %6117 = zext i8 %6116 to i256
  %6118 = lshr i256 %6117, 128
  %6119 = trunc i256 %6118 to i64
  %6120 = load i8, ptr %409, align 1
  %6121 = zext i8 %6120 to i256
  %6122 = lshr i256 %6121, 64
  %6123 = trunc i256 %6122 to i64
  %6124 = load i8, ptr %409, align 1
  %6125 = zext i8 %6124 to i64
  %6126 = load i8, ptr %410, align 1
  %6127 = zext i8 %6126 to i256
  %6128 = lshr i256 %6127, 128
  %6129 = trunc i256 %6128 to i64
  %6130 = load i8, ptr %410, align 1
  %6131 = zext i8 %6130 to i256
  %6132 = lshr i256 %6131, 64
  %6133 = trunc i256 %6132 to i64
  %6134 = load i8, ptr %410, align 1
  %6135 = zext i8 %6134 to i64
  %6136 = load i8, ptr %411, align 1
  %6137 = zext i8 %6136 to i256
  %6138 = lshr i256 %6137, 128
  %6139 = trunc i256 %6138 to i64
  %6140 = load i8, ptr %411, align 1
  %6141 = zext i8 %6140 to i256
  %6142 = lshr i256 %6141, 64
  %6143 = trunc i256 %6142 to i64
  %6144 = load i8, ptr %411, align 1
  %6145 = zext i8 %6144 to i64
  %6146 = load i8, ptr %412, align 1
  %6147 = zext i8 %6146 to i256
  %6148 = lshr i256 %6147, 128
  %6149 = trunc i256 %6148 to i64
  %6150 = load i8, ptr %412, align 1
  %6151 = zext i8 %6150 to i256
  %6152 = lshr i256 %6151, 64
  %6153 = trunc i256 %6152 to i64
  %6154 = load i8, ptr %412, align 1
  %6155 = zext i8 %6154 to i64
  %6156 = load i8, ptr %413, align 1
  %6157 = zext i8 %6156 to i64
  %6158 = load i8, ptr %414, align 1
  %6159 = zext i8 %6158 to i64
  %6160 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %6119, i64 noundef %6123, i64 noundef %6125, i64 noundef %6129, i64 noundef %6133, i64 noundef %6135, i64 noundef %6139, i64 noundef %6143, i64 noundef %6145, i64 noundef %6149, i64 noundef %6153, i64 noundef %6155, i64 noundef %6157, i64 noundef %6159)
  %6161 = load i8, ptr %407, align 1
  %6162 = zext i8 %6161 to i575
  %6163 = getelementptr inbounds [12 x i32], ptr %408, i64 0, i64 0
  %6164 = load i8, ptr %409, align 1
  %6165 = zext i8 %6164 to i575
  %6166 = load i8, ptr %410, align 1
  %6167 = zext i8 %6166 to i575
  %6168 = load i8, ptr %411, align 1
  %6169 = zext i8 %6168 to i575
  %6170 = load i8, ptr %412, align 1
  %6171 = zext i8 %6170 to i575
  %6172 = load i8, ptr %413, align 1
  %6173 = zext i8 %6172 to i575
  %6174 = load i8, ptr %414, align 1
  %6175 = zext i8 %6174 to i575
  %6176 = zext i575 %6162 to i576
  store i576 %6176, ptr %415, align 8
  %6177 = zext i575 %6165 to i576
  store i576 %6177, ptr %416, align 8
  %6178 = zext i575 %6167 to i576
  store i576 %6178, ptr %417, align 8
  %6179 = zext i575 %6169 to i576
  store i576 %6179, ptr %418, align 8
  %6180 = zext i575 %6171 to i576
  store i576 %6180, ptr %419, align 8
  %6181 = zext i575 %6173 to i576
  store i576 %6181, ptr %420, align 8
  %6182 = zext i575 %6175 to i576
  store i576 %6182, ptr %421, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %415, ptr noundef %6163, ptr noundef byval([72 x i8]) align 8 %416, ptr noundef byval([72 x i8]) align 8 %417, ptr noundef byval([72 x i8]) align 8 %418, ptr noundef byval([72 x i8]) align 8 %419, ptr noundef byval([72 x i8]) align 8 %420, ptr noundef byval([72 x i8]) align 8 %421)
  br label %6183

6183:                                             ; preds = %6106
  br label %6184

6184:                                             ; preds = %6183
  store i16 80, ptr %422, align 2
  %6185 = load i16, ptr %422, align 2
  %6186 = call i16 @llvm.ctlz.i16(i16 %6185, i1 false)
  %6187 = zext i16 %6186 to i32
  store i32 %6187, ptr %423, align 4
  %6188 = getelementptr inbounds i32, ptr %423, i64 1
  %6189 = load i16, ptr %422, align 2
  %6190 = xor i16 %6189, -1
  %6191 = call i16 @llvm.ctlz.i16(i16 %6190, i1 false)
  %6192 = zext i16 %6191 to i32
  store i32 %6192, ptr %6188, align 4
  %6193 = getelementptr inbounds i32, ptr %423, i64 2
  %6194 = load i16, ptr %422, align 2
  %6195 = call i16 @llvm.cttz.i16(i16 %6194, i1 false)
  %6196 = zext i16 %6195 to i32
  store i32 %6196, ptr %6193, align 4
  %6197 = getelementptr inbounds i32, ptr %423, i64 3
  %6198 = load i16, ptr %422, align 2
  %6199 = xor i16 %6198, -1
  %6200 = call i16 @llvm.cttz.i16(i16 %6199, i1 false)
  %6201 = zext i16 %6200 to i32
  store i32 %6201, ptr %6197, align 4
  %6202 = getelementptr inbounds i32, ptr %423, i64 4
  %6203 = load i16, ptr %422, align 2
  %6204 = xor i16 %6203, -1
  %6205 = call i16 @llvm.ctlz.i16(i16 %6204, i1 false)
  %6206 = add i16 %6205, 1
  %6207 = icmp eq i16 %6204, 0
  %6208 = select i1 %6207, i16 0, i16 %6206
  %6209 = zext i16 %6208 to i32
  store i32 %6209, ptr %6202, align 4
  %6210 = getelementptr inbounds i32, ptr %423, i64 5
  %6211 = load i16, ptr %422, align 2
  %6212 = call i16 @llvm.ctlz.i16(i16 %6211, i1 false)
  %6213 = add i16 %6212, 1
  %6214 = icmp eq i16 %6211, 0
  %6215 = select i1 %6214, i16 0, i16 %6213
  %6216 = zext i16 %6215 to i32
  store i32 %6216, ptr %6210, align 4
  %6217 = getelementptr inbounds i32, ptr %423, i64 6
  %6218 = load i16, ptr %422, align 2
  %6219 = xor i16 %6218, -1
  %6220 = call i16 @llvm.cttz.i16(i16 %6219, i1 false)
  %6221 = add i16 %6220, 1
  %6222 = icmp eq i16 %6219, 0
  %6223 = select i1 %6222, i16 0, i16 %6221
  %6224 = zext i16 %6223 to i32
  store i32 %6224, ptr %6217, align 4
  %6225 = getelementptr inbounds i32, ptr %423, i64 7
  %6226 = load i16, ptr %422, align 2
  %6227 = call i16 @llvm.cttz.i16(i16 %6226, i1 false)
  %6228 = add i16 %6227, 1
  %6229 = icmp eq i16 %6226, 0
  %6230 = select i1 %6229, i16 0, i16 %6228
  %6231 = zext i16 %6230 to i32
  store i32 %6231, ptr %6225, align 4
  %6232 = getelementptr inbounds i32, ptr %423, i64 8
  %6233 = load i16, ptr %422, align 2
  %6234 = call i16 @llvm.ctpop.i16(i16 %6233)
  %6235 = sub i16 16, %6234
  %6236 = zext i16 %6235 to i32
  store i32 %6236, ptr %6232, align 4
  %6237 = getelementptr inbounds i32, ptr %423, i64 9
  %6238 = load i16, ptr %422, align 2
  %6239 = call i16 @llvm.ctpop.i16(i16 %6238)
  %6240 = zext i16 %6239 to i32
  store i32 %6240, ptr %6237, align 4
  %6241 = getelementptr inbounds i32, ptr %423, i64 10
  %6242 = load i16, ptr %422, align 2
  %6243 = call i16 @llvm.ctpop.i16(i16 %6242)
  %6244 = icmp eq i16 %6243, 1
  %6245 = zext i1 %6244 to i32
  store i32 %6245, ptr %6241, align 4
  %6246 = getelementptr inbounds i32, ptr %423, i64 11
  %6247 = load i16, ptr %422, align 2
  %6248 = call i16 @llvm.ctlz.i16(i16 %6247, i1 false)
  %6249 = sub i16 16, %6248
  %6250 = zext i16 %6249 to i32
  store i32 %6250, ptr %6246, align 4
  %6251 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 0
  %6252 = load i32, ptr %6251, align 16
  %6253 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 1
  %6254 = load i32, ptr %6253, align 4
  %6255 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 2
  %6256 = load i32, ptr %6255, align 8
  %6257 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 3
  %6258 = load i32, ptr %6257, align 4
  %6259 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 4
  %6260 = load i32, ptr %6259, align 16
  %6261 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 5
  %6262 = load i32, ptr %6261, align 4
  %6263 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 6
  %6264 = load i32, ptr %6263, align 8
  %6265 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 7
  %6266 = load i32, ptr %6265, align 4
  %6267 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 8
  %6268 = load i32, ptr %6267, align 16
  %6269 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 9
  %6270 = load i32, ptr %6269, align 4
  %6271 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 10
  %6272 = load i32, ptr %6271, align 8
  %6273 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 11
  %6274 = load i32, ptr %6273, align 4
  %6275 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef %6252, i32 noundef %6254, i32 noundef %6256, i32 noundef %6258, i32 noundef %6260, i32 noundef %6262, i32 noundef %6264, i32 noundef %6266, i32 noundef %6268, i32 noundef %6270, i32 noundef %6272, i32 noundef %6274)
  %6276 = load i16, ptr %422, align 2
  %6277 = call i16 @llvm.ctlz.i16(i16 %6276, i1 true)
  %6278 = sub i16 15, %6277
  %6279 = shl i16 1, %6278
  %6280 = icmp eq i16 %6276, 0
  %6281 = select i1 %6280, i16 0, i16 %6279
  store i16 %6281, ptr %424, align 2
  %6282 = load i16, ptr %422, align 2
  %6283 = icmp ule i16 %6282, 1
  br i1 %6283, label %6289, label %6284

6284:                                             ; preds = %6184
  %6285 = sub i16 %6282, 1
  %6286 = call i16 @llvm.ctlz.i16(i16 %6285, i1 false)
  %6287 = sub i16 15, %6286
  %6288 = shl i16 2, %6287
  br label %6289

6289:                                             ; preds = %6284, %6184
  %6290 = phi i16 [ 1, %6184 ], [ %6288, %6284 ]
  store i16 %6290, ptr %425, align 2
  %6291 = load i16, ptr %422, align 2
  %6292 = call i16 @llvm.fshl.i16(i16 %6291, i16 %6291, i16 3)
  store i16 %6292, ptr %426, align 2
  %6293 = load i16, ptr %422, align 2
  %6294 = call i16 @llvm.fshr.i16(i16 %6293, i16 %6293, i16 3)
  store i16 %6294, ptr %427, align 2
  %6295 = load i16, ptr %422, align 2
  %6296 = call i16 @llvm.fshl.i16(i16 %6295, i16 %6295, i16 0)
  store i16 %6296, ptr %428, align 2
  %6297 = load i16, ptr %422, align 2
  %6298 = call i16 @llvm.fshl.i16(i16 %6297, i16 %6297, i16 8)
  store i16 %6298, ptr %429, align 2
  %6299 = load i16, ptr %424, align 2
  %6300 = zext i16 %6299 to i256
  %6301 = lshr i256 %6300, 128
  %6302 = trunc i256 %6301 to i64
  %6303 = load i16, ptr %424, align 2
  %6304 = zext i16 %6303 to i256
  %6305 = lshr i256 %6304, 64
  %6306 = trunc i256 %6305 to i64
  %6307 = load i16, ptr %424, align 2
  %6308 = zext i16 %6307 to i64
  %6309 = load i16, ptr %425, align 2
  %6310 = zext i16 %6309 to i256
  %6311 = lshr i256 %6310, 128
  %6312 = trunc i256 %6311 to i64
  %6313 = load i16, ptr %425, align 2
  %6314 = zext i16 %6313 to i256
  %6315 = lshr i256 %6314, 64
  %6316 = trunc i256 %6315 to i64
  %6317 = load i16, ptr %425, align 2
  %6318 = zext i16 %6317 to i64
  %6319 = load i16, ptr %426, align 2
  %6320 = zext i16 %6319 to i256
  %6321 = lshr i256 %6320, 128
  %6322 = trunc i256 %6321 to i64
  %6323 = load i16, ptr %426, align 2
  %6324 = zext i16 %6323 to i256
  %6325 = lshr i256 %6324, 64
  %6326 = trunc i256 %6325 to i64
  %6327 = load i16, ptr %426, align 2
  %6328 = zext i16 %6327 to i64
  %6329 = load i16, ptr %427, align 2
  %6330 = zext i16 %6329 to i256
  %6331 = lshr i256 %6330, 128
  %6332 = trunc i256 %6331 to i64
  %6333 = load i16, ptr %427, align 2
  %6334 = zext i16 %6333 to i256
  %6335 = lshr i256 %6334, 64
  %6336 = trunc i256 %6335 to i64
  %6337 = load i16, ptr %427, align 2
  %6338 = zext i16 %6337 to i64
  %6339 = load i16, ptr %428, align 2
  %6340 = zext i16 %6339 to i64
  %6341 = load i16, ptr %429, align 2
  %6342 = zext i16 %6341 to i64
  %6343 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %6302, i64 noundef %6306, i64 noundef %6308, i64 noundef %6312, i64 noundef %6316, i64 noundef %6318, i64 noundef %6322, i64 noundef %6326, i64 noundef %6328, i64 noundef %6332, i64 noundef %6336, i64 noundef %6338, i64 noundef %6340, i64 noundef %6342)
  %6344 = load i16, ptr %422, align 2
  %6345 = zext i16 %6344 to i575
  %6346 = getelementptr inbounds [12 x i32], ptr %423, i64 0, i64 0
  %6347 = load i16, ptr %424, align 2
  %6348 = zext i16 %6347 to i575
  %6349 = load i16, ptr %425, align 2
  %6350 = zext i16 %6349 to i575
  %6351 = load i16, ptr %426, align 2
  %6352 = zext i16 %6351 to i575
  %6353 = load i16, ptr %427, align 2
  %6354 = zext i16 %6353 to i575
  %6355 = load i16, ptr %428, align 2
  %6356 = zext i16 %6355 to i575
  %6357 = load i16, ptr %429, align 2
  %6358 = zext i16 %6357 to i575
  %6359 = zext i575 %6345 to i576
  store i576 %6359, ptr %430, align 8
  %6360 = zext i575 %6348 to i576
  store i576 %6360, ptr %431, align 8
  %6361 = zext i575 %6350 to i576
  store i576 %6361, ptr %432, align 8
  %6362 = zext i575 %6352 to i576
  store i576 %6362, ptr %433, align 8
  %6363 = zext i575 %6354 to i576
  store i576 %6363, ptr %434, align 8
  %6364 = zext i575 %6356 to i576
  store i576 %6364, ptr %435, align 8
  %6365 = zext i575 %6358 to i576
  store i576 %6365, ptr %436, align 8
  call void @check(ptr noundef @.str.4, i32 noundef 16, ptr noundef byval([72 x i8]) align 8 %430, ptr noundef %6346, ptr noundef byval([72 x i8]) align 8 %431, ptr noundef byval([72 x i8]) align 8 %432, ptr noundef byval([72 x i8]) align 8 %433, ptr noundef byval([72 x i8]) align 8 %434, ptr noundef byval([72 x i8]) align 8 %435, ptr noundef byval([72 x i8]) align 8 %436)
  br label %6366

6366:                                             ; preds = %6289
  br label %6367

6367:                                             ; preds = %6366
  store i32 80, ptr %437, align 4
  %6368 = load i32, ptr %437, align 4
  %6369 = call i32 @llvm.ctlz.i32(i32 %6368, i1 false)
  store i32 %6369, ptr %438, align 4
  %6370 = getelementptr inbounds i32, ptr %438, i64 1
  %6371 = load i32, ptr %437, align 4
  %6372 = xor i32 %6371, -1
  %6373 = call i32 @llvm.ctlz.i32(i32 %6372, i1 false)
  store i32 %6373, ptr %6370, align 4
  %6374 = getelementptr inbounds i32, ptr %438, i64 2
  %6375 = load i32, ptr %437, align 4
  %6376 = call i32 @llvm.cttz.i32(i32 %6375, i1 false)
  store i32 %6376, ptr %6374, align 4
  %6377 = getelementptr inbounds i32, ptr %438, i64 3
  %6378 = load i32, ptr %437, align 4
  %6379 = xor i32 %6378, -1
  %6380 = call i32 @llvm.cttz.i32(i32 %6379, i1 false)
  store i32 %6380, ptr %6377, align 4
  %6381 = getelementptr inbounds i32, ptr %438, i64 4
  %6382 = load i32, ptr %437, align 4
  %6383 = xor i32 %6382, -1
  %6384 = call i32 @llvm.ctlz.i32(i32 %6383, i1 false)
  %6385 = add i32 %6384, 1
  %6386 = icmp eq i32 %6383, 0
  %6387 = select i1 %6386, i32 0, i32 %6385
  store i32 %6387, ptr %6381, align 4
  %6388 = getelementptr inbounds i32, ptr %438, i64 5
  %6389 = load i32, ptr %437, align 4
  %6390 = call i32 @llvm.ctlz.i32(i32 %6389, i1 false)
  %6391 = add i32 %6390, 1
  %6392 = icmp eq i32 %6389, 0
  %6393 = select i1 %6392, i32 0, i32 %6391
  store i32 %6393, ptr %6388, align 4
  %6394 = getelementptr inbounds i32, ptr %438, i64 6
  %6395 = load i32, ptr %437, align 4
  %6396 = xor i32 %6395, -1
  %6397 = call i32 @llvm.cttz.i32(i32 %6396, i1 false)
  %6398 = add i32 %6397, 1
  %6399 = icmp eq i32 %6396, 0
  %6400 = select i1 %6399, i32 0, i32 %6398
  store i32 %6400, ptr %6394, align 4
  %6401 = getelementptr inbounds i32, ptr %438, i64 7
  %6402 = load i32, ptr %437, align 4
  %6403 = call i32 @llvm.cttz.i32(i32 %6402, i1 false)
  %6404 = add i32 %6403, 1
  %6405 = icmp eq i32 %6402, 0
  %6406 = select i1 %6405, i32 0, i32 %6404
  store i32 %6406, ptr %6401, align 4
  %6407 = getelementptr inbounds i32, ptr %438, i64 8
  %6408 = load i32, ptr %437, align 4
  %6409 = call i32 @llvm.ctpop.i32(i32 %6408)
  %6410 = sub i32 32, %6409
  store i32 %6410, ptr %6407, align 4
  %6411 = getelementptr inbounds i32, ptr %438, i64 9
  %6412 = load i32, ptr %437, align 4
  %6413 = call i32 @llvm.ctpop.i32(i32 %6412)
  store i32 %6413, ptr %6411, align 4
  %6414 = getelementptr inbounds i32, ptr %438, i64 10
  %6415 = load i32, ptr %437, align 4
  %6416 = call i32 @llvm.ctpop.i32(i32 %6415)
  %6417 = icmp eq i32 %6416, 1
  %6418 = zext i1 %6417 to i32
  store i32 %6418, ptr %6414, align 4
  %6419 = getelementptr inbounds i32, ptr %438, i64 11
  %6420 = load i32, ptr %437, align 4
  %6421 = call i32 @llvm.ctlz.i32(i32 %6420, i1 false)
  %6422 = sub i32 32, %6421
  store i32 %6422, ptr %6419, align 4
  %6423 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 0
  %6424 = load i32, ptr %6423, align 16
  %6425 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 1
  %6426 = load i32, ptr %6425, align 4
  %6427 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 2
  %6428 = load i32, ptr %6427, align 8
  %6429 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 3
  %6430 = load i32, ptr %6429, align 4
  %6431 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 4
  %6432 = load i32, ptr %6431, align 16
  %6433 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 5
  %6434 = load i32, ptr %6433, align 4
  %6435 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 6
  %6436 = load i32, ptr %6435, align 8
  %6437 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 7
  %6438 = load i32, ptr %6437, align 4
  %6439 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 8
  %6440 = load i32, ptr %6439, align 16
  %6441 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 9
  %6442 = load i32, ptr %6441, align 4
  %6443 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 10
  %6444 = load i32, ptr %6443, align 8
  %6445 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 11
  %6446 = load i32, ptr %6445, align 4
  %6447 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef %6424, i32 noundef %6426, i32 noundef %6428, i32 noundef %6430, i32 noundef %6432, i32 noundef %6434, i32 noundef %6436, i32 noundef %6438, i32 noundef %6440, i32 noundef %6442, i32 noundef %6444, i32 noundef %6446)
  %6448 = load i32, ptr %437, align 4
  %6449 = call i32 @llvm.ctlz.i32(i32 %6448, i1 true)
  %6450 = sub i32 31, %6449
  %6451 = shl i32 1, %6450
  %6452 = icmp eq i32 %6448, 0
  %6453 = select i1 %6452, i32 0, i32 %6451
  store i32 %6453, ptr %439, align 4
  %6454 = load i32, ptr %437, align 4
  %6455 = icmp ule i32 %6454, 1
  br i1 %6455, label %6461, label %6456

6456:                                             ; preds = %6367
  %6457 = sub i32 %6454, 1
  %6458 = call i32 @llvm.ctlz.i32(i32 %6457, i1 false)
  %6459 = sub i32 31, %6458
  %6460 = shl i32 2, %6459
  br label %6461

6461:                                             ; preds = %6456, %6367
  %6462 = phi i32 [ 1, %6367 ], [ %6460, %6456 ]
  store i32 %6462, ptr %440, align 4
  %6463 = load i32, ptr %437, align 4
  %6464 = call i32 @llvm.fshl.i32(i32 %6463, i32 %6463, i32 3)
  store i32 %6464, ptr %441, align 4
  %6465 = load i32, ptr %437, align 4
  %6466 = call i32 @llvm.fshr.i32(i32 %6465, i32 %6465, i32 3)
  store i32 %6466, ptr %442, align 4
  %6467 = load i32, ptr %437, align 4
  %6468 = call i32 @llvm.fshl.i32(i32 %6467, i32 %6467, i32 0)
  store i32 %6468, ptr %443, align 4
  %6469 = load i32, ptr %437, align 4
  %6470 = call i32 @llvm.fshl.i32(i32 %6469, i32 %6469, i32 8)
  store i32 %6470, ptr %444, align 4
  %6471 = load i32, ptr %439, align 4
  %6472 = zext i32 %6471 to i256
  %6473 = lshr i256 %6472, 128
  %6474 = trunc i256 %6473 to i64
  %6475 = load i32, ptr %439, align 4
  %6476 = zext i32 %6475 to i256
  %6477 = lshr i256 %6476, 64
  %6478 = trunc i256 %6477 to i64
  %6479 = load i32, ptr %439, align 4
  %6480 = zext i32 %6479 to i64
  %6481 = load i32, ptr %440, align 4
  %6482 = zext i32 %6481 to i256
  %6483 = lshr i256 %6482, 128
  %6484 = trunc i256 %6483 to i64
  %6485 = load i32, ptr %440, align 4
  %6486 = zext i32 %6485 to i256
  %6487 = lshr i256 %6486, 64
  %6488 = trunc i256 %6487 to i64
  %6489 = load i32, ptr %440, align 4
  %6490 = zext i32 %6489 to i64
  %6491 = load i32, ptr %441, align 4
  %6492 = zext i32 %6491 to i256
  %6493 = lshr i256 %6492, 128
  %6494 = trunc i256 %6493 to i64
  %6495 = load i32, ptr %441, align 4
  %6496 = zext i32 %6495 to i256
  %6497 = lshr i256 %6496, 64
  %6498 = trunc i256 %6497 to i64
  %6499 = load i32, ptr %441, align 4
  %6500 = zext i32 %6499 to i64
  %6501 = load i32, ptr %442, align 4
  %6502 = zext i32 %6501 to i256
  %6503 = lshr i256 %6502, 128
  %6504 = trunc i256 %6503 to i64
  %6505 = load i32, ptr %442, align 4
  %6506 = zext i32 %6505 to i256
  %6507 = lshr i256 %6506, 64
  %6508 = trunc i256 %6507 to i64
  %6509 = load i32, ptr %442, align 4
  %6510 = zext i32 %6509 to i64
  %6511 = load i32, ptr %443, align 4
  %6512 = zext i32 %6511 to i64
  %6513 = load i32, ptr %444, align 4
  %6514 = zext i32 %6513 to i64
  %6515 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %6474, i64 noundef %6478, i64 noundef %6480, i64 noundef %6484, i64 noundef %6488, i64 noundef %6490, i64 noundef %6494, i64 noundef %6498, i64 noundef %6500, i64 noundef %6504, i64 noundef %6508, i64 noundef %6510, i64 noundef %6512, i64 noundef %6514)
  %6516 = load i32, ptr %437, align 4
  %6517 = zext i32 %6516 to i575
  %6518 = getelementptr inbounds [12 x i32], ptr %438, i64 0, i64 0
  %6519 = load i32, ptr %439, align 4
  %6520 = zext i32 %6519 to i575
  %6521 = load i32, ptr %440, align 4
  %6522 = zext i32 %6521 to i575
  %6523 = load i32, ptr %441, align 4
  %6524 = zext i32 %6523 to i575
  %6525 = load i32, ptr %442, align 4
  %6526 = zext i32 %6525 to i575
  %6527 = load i32, ptr %443, align 4
  %6528 = zext i32 %6527 to i575
  %6529 = load i32, ptr %444, align 4
  %6530 = zext i32 %6529 to i575
  %6531 = zext i575 %6517 to i576
  store i576 %6531, ptr %445, align 8
  %6532 = zext i575 %6520 to i576
  store i576 %6532, ptr %446, align 8
  %6533 = zext i575 %6522 to i576
  store i576 %6533, ptr %447, align 8
  %6534 = zext i575 %6524 to i576
  store i576 %6534, ptr %448, align 8
  %6535 = zext i575 %6526 to i576
  store i576 %6535, ptr %449, align 8
  %6536 = zext i575 %6528 to i576
  store i576 %6536, ptr %450, align 8
  %6537 = zext i575 %6530 to i576
  store i576 %6537, ptr %451, align 8
  call void @check(ptr noundef @.str.5, i32 noundef 32, ptr noundef byval([72 x i8]) align 8 %445, ptr noundef %6518, ptr noundef byval([72 x i8]) align 8 %446, ptr noundef byval([72 x i8]) align 8 %447, ptr noundef byval([72 x i8]) align 8 %448, ptr noundef byval([72 x i8]) align 8 %449, ptr noundef byval([72 x i8]) align 8 %450, ptr noundef byval([72 x i8]) align 8 %451)
  br label %6538

6538:                                             ; preds = %6461
  br label %6539

6539:                                             ; preds = %6538
  store i64 80, ptr %452, align 8
  %6540 = load i64, ptr %452, align 8
  %6541 = call i64 @llvm.ctlz.i64(i64 %6540, i1 false)
  %6542 = trunc i64 %6541 to i32
  store i32 %6542, ptr %453, align 4
  %6543 = getelementptr inbounds i32, ptr %453, i64 1
  %6544 = load i64, ptr %452, align 8
  %6545 = xor i64 %6544, -1
  %6546 = call i64 @llvm.ctlz.i64(i64 %6545, i1 false)
  %6547 = trunc i64 %6546 to i32
  store i32 %6547, ptr %6543, align 4
  %6548 = getelementptr inbounds i32, ptr %453, i64 2
  %6549 = load i64, ptr %452, align 8
  %6550 = call i64 @llvm.cttz.i64(i64 %6549, i1 false)
  %6551 = trunc i64 %6550 to i32
  store i32 %6551, ptr %6548, align 4
  %6552 = getelementptr inbounds i32, ptr %453, i64 3
  %6553 = load i64, ptr %452, align 8
  %6554 = xor i64 %6553, -1
  %6555 = call i64 @llvm.cttz.i64(i64 %6554, i1 false)
  %6556 = trunc i64 %6555 to i32
  store i32 %6556, ptr %6552, align 4
  %6557 = getelementptr inbounds i32, ptr %453, i64 4
  %6558 = load i64, ptr %452, align 8
  %6559 = xor i64 %6558, -1
  %6560 = call i64 @llvm.ctlz.i64(i64 %6559, i1 false)
  %6561 = add i64 %6560, 1
  %6562 = icmp eq i64 %6559, 0
  %6563 = select i1 %6562, i64 0, i64 %6561
  %6564 = trunc i64 %6563 to i32
  store i32 %6564, ptr %6557, align 4
  %6565 = getelementptr inbounds i32, ptr %453, i64 5
  %6566 = load i64, ptr %452, align 8
  %6567 = call i64 @llvm.ctlz.i64(i64 %6566, i1 false)
  %6568 = add i64 %6567, 1
  %6569 = icmp eq i64 %6566, 0
  %6570 = select i1 %6569, i64 0, i64 %6568
  %6571 = trunc i64 %6570 to i32
  store i32 %6571, ptr %6565, align 4
  %6572 = getelementptr inbounds i32, ptr %453, i64 6
  %6573 = load i64, ptr %452, align 8
  %6574 = xor i64 %6573, -1
  %6575 = call i64 @llvm.cttz.i64(i64 %6574, i1 false)
  %6576 = add i64 %6575, 1
  %6577 = icmp eq i64 %6574, 0
  %6578 = select i1 %6577, i64 0, i64 %6576
  %6579 = trunc i64 %6578 to i32
  store i32 %6579, ptr %6572, align 4
  %6580 = getelementptr inbounds i32, ptr %453, i64 7
  %6581 = load i64, ptr %452, align 8
  %6582 = call i64 @llvm.cttz.i64(i64 %6581, i1 false)
  %6583 = add i64 %6582, 1
  %6584 = icmp eq i64 %6581, 0
  %6585 = select i1 %6584, i64 0, i64 %6583
  %6586 = trunc i64 %6585 to i32
  store i32 %6586, ptr %6580, align 4
  %6587 = getelementptr inbounds i32, ptr %453, i64 8
  %6588 = load i64, ptr %452, align 8
  %6589 = call i64 @llvm.ctpop.i64(i64 %6588)
  %6590 = sub i64 64, %6589
  %6591 = trunc i64 %6590 to i32
  store i32 %6591, ptr %6587, align 4
  %6592 = getelementptr inbounds i32, ptr %453, i64 9
  %6593 = load i64, ptr %452, align 8
  %6594 = call i64 @llvm.ctpop.i64(i64 %6593)
  %6595 = trunc i64 %6594 to i32
  store i32 %6595, ptr %6592, align 4
  %6596 = getelementptr inbounds i32, ptr %453, i64 10
  %6597 = load i64, ptr %452, align 8
  %6598 = call i64 @llvm.ctpop.i64(i64 %6597)
  %6599 = icmp eq i64 %6598, 1
  %6600 = zext i1 %6599 to i32
  store i32 %6600, ptr %6596, align 4
  %6601 = getelementptr inbounds i32, ptr %453, i64 11
  %6602 = load i64, ptr %452, align 8
  %6603 = call i64 @llvm.ctlz.i64(i64 %6602, i1 false)
  %6604 = sub i64 64, %6603
  %6605 = trunc i64 %6604 to i32
  store i32 %6605, ptr %6601, align 4
  %6606 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 0
  %6607 = load i32, ptr %6606, align 16
  %6608 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 1
  %6609 = load i32, ptr %6608, align 4
  %6610 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 2
  %6611 = load i32, ptr %6610, align 8
  %6612 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 3
  %6613 = load i32, ptr %6612, align 4
  %6614 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 4
  %6615 = load i32, ptr %6614, align 16
  %6616 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 5
  %6617 = load i32, ptr %6616, align 4
  %6618 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 6
  %6619 = load i32, ptr %6618, align 8
  %6620 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 7
  %6621 = load i32, ptr %6620, align 4
  %6622 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 8
  %6623 = load i32, ptr %6622, align 16
  %6624 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 9
  %6625 = load i32, ptr %6624, align 4
  %6626 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 10
  %6627 = load i32, ptr %6626, align 8
  %6628 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 11
  %6629 = load i32, ptr %6628, align 4
  %6630 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef %6607, i32 noundef %6609, i32 noundef %6611, i32 noundef %6613, i32 noundef %6615, i32 noundef %6617, i32 noundef %6619, i32 noundef %6621, i32 noundef %6623, i32 noundef %6625, i32 noundef %6627, i32 noundef %6629)
  %6631 = load i64, ptr %452, align 8
  %6632 = call i64 @llvm.ctlz.i64(i64 %6631, i1 true)
  %6633 = sub i64 63, %6632
  %6634 = shl i64 1, %6633
  %6635 = icmp eq i64 %6631, 0
  %6636 = select i1 %6635, i64 0, i64 %6634
  store i64 %6636, ptr %454, align 8
  %6637 = load i64, ptr %452, align 8
  %6638 = icmp ule i64 %6637, 1
  br i1 %6638, label %6644, label %6639

6639:                                             ; preds = %6539
  %6640 = sub i64 %6637, 1
  %6641 = call i64 @llvm.ctlz.i64(i64 %6640, i1 false)
  %6642 = sub i64 63, %6641
  %6643 = shl i64 2, %6642
  br label %6644

6644:                                             ; preds = %6639, %6539
  %6645 = phi i64 [ 1, %6539 ], [ %6643, %6639 ]
  store i64 %6645, ptr %455, align 8
  %6646 = load i64, ptr %452, align 8
  %6647 = call i64 @llvm.fshl.i64(i64 %6646, i64 %6646, i64 3)
  store i64 %6647, ptr %456, align 8
  %6648 = load i64, ptr %452, align 8
  %6649 = call i64 @llvm.fshr.i64(i64 %6648, i64 %6648, i64 3)
  store i64 %6649, ptr %457, align 8
  %6650 = load i64, ptr %452, align 8
  %6651 = call i64 @llvm.fshl.i64(i64 %6650, i64 %6650, i64 0)
  store i64 %6651, ptr %458, align 8
  %6652 = load i64, ptr %452, align 8
  %6653 = call i64 @llvm.fshl.i64(i64 %6652, i64 %6652, i64 40)
  store i64 %6653, ptr %459, align 8
  %6654 = load i64, ptr %454, align 8
  %6655 = zext i64 %6654 to i256
  %6656 = lshr i256 %6655, 128
  %6657 = trunc i256 %6656 to i64
  %6658 = load i64, ptr %454, align 8
  %6659 = zext i64 %6658 to i256
  %6660 = lshr i256 %6659, 64
  %6661 = trunc i256 %6660 to i64
  %6662 = load i64, ptr %454, align 8
  %6663 = load i64, ptr %455, align 8
  %6664 = zext i64 %6663 to i256
  %6665 = lshr i256 %6664, 128
  %6666 = trunc i256 %6665 to i64
  %6667 = load i64, ptr %455, align 8
  %6668 = zext i64 %6667 to i256
  %6669 = lshr i256 %6668, 64
  %6670 = trunc i256 %6669 to i64
  %6671 = load i64, ptr %455, align 8
  %6672 = load i64, ptr %456, align 8
  %6673 = zext i64 %6672 to i256
  %6674 = lshr i256 %6673, 128
  %6675 = trunc i256 %6674 to i64
  %6676 = load i64, ptr %456, align 8
  %6677 = zext i64 %6676 to i256
  %6678 = lshr i256 %6677, 64
  %6679 = trunc i256 %6678 to i64
  %6680 = load i64, ptr %456, align 8
  %6681 = load i64, ptr %457, align 8
  %6682 = zext i64 %6681 to i256
  %6683 = lshr i256 %6682, 128
  %6684 = trunc i256 %6683 to i64
  %6685 = load i64, ptr %457, align 8
  %6686 = zext i64 %6685 to i256
  %6687 = lshr i256 %6686, 64
  %6688 = trunc i256 %6687 to i64
  %6689 = load i64, ptr %457, align 8
  %6690 = load i64, ptr %458, align 8
  %6691 = load i64, ptr %459, align 8
  %6692 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %6657, i64 noundef %6661, i64 noundef %6662, i64 noundef %6666, i64 noundef %6670, i64 noundef %6671, i64 noundef %6675, i64 noundef %6679, i64 noundef %6680, i64 noundef %6684, i64 noundef %6688, i64 noundef %6689, i64 noundef %6690, i64 noundef %6691)
  %6693 = load i64, ptr %452, align 8
  %6694 = zext i64 %6693 to i575
  %6695 = getelementptr inbounds [12 x i32], ptr %453, i64 0, i64 0
  %6696 = load i64, ptr %454, align 8
  %6697 = zext i64 %6696 to i575
  %6698 = load i64, ptr %455, align 8
  %6699 = zext i64 %6698 to i575
  %6700 = load i64, ptr %456, align 8
  %6701 = zext i64 %6700 to i575
  %6702 = load i64, ptr %457, align 8
  %6703 = zext i64 %6702 to i575
  %6704 = load i64, ptr %458, align 8
  %6705 = zext i64 %6704 to i575
  %6706 = load i64, ptr %459, align 8
  %6707 = zext i64 %6706 to i575
  %6708 = zext i575 %6694 to i576
  store i576 %6708, ptr %460, align 8
  %6709 = zext i575 %6697 to i576
  store i576 %6709, ptr %461, align 8
  %6710 = zext i575 %6699 to i576
  store i576 %6710, ptr %462, align 8
  %6711 = zext i575 %6701 to i576
  store i576 %6711, ptr %463, align 8
  %6712 = zext i575 %6703 to i576
  store i576 %6712, ptr %464, align 8
  %6713 = zext i575 %6705 to i576
  store i576 %6713, ptr %465, align 8
  %6714 = zext i575 %6707 to i576
  store i576 %6714, ptr %466, align 8
  call void @check(ptr noundef @.str.6, i32 noundef 64, ptr noundef byval([72 x i8]) align 8 %460, ptr noundef %6695, ptr noundef byval([72 x i8]) align 8 %461, ptr noundef byval([72 x i8]) align 8 %462, ptr noundef byval([72 x i8]) align 8 %463, ptr noundef byval([72 x i8]) align 8 %464, ptr noundef byval([72 x i8]) align 8 %465, ptr noundef byval([72 x i8]) align 8 %466)
  br label %6715

6715:                                             ; preds = %6644
  br label %6716

6716:                                             ; preds = %6715
  store i128 80, ptr %467, align 16
  %6717 = load i128, ptr %467, align 16
  %6718 = call i128 @llvm.ctlz.i128(i128 %6717, i1 false)
  %6719 = trunc i128 %6718 to i32
  store i32 %6719, ptr %468, align 4
  %6720 = getelementptr inbounds i32, ptr %468, i64 1
  %6721 = load i128, ptr %467, align 16
  %6722 = xor i128 %6721, -1
  %6723 = call i128 @llvm.ctlz.i128(i128 %6722, i1 false)
  %6724 = trunc i128 %6723 to i32
  store i32 %6724, ptr %6720, align 4
  %6725 = getelementptr inbounds i32, ptr %468, i64 2
  %6726 = load i128, ptr %467, align 16
  %6727 = call i128 @llvm.cttz.i128(i128 %6726, i1 false)
  %6728 = trunc i128 %6727 to i32
  store i32 %6728, ptr %6725, align 4
  %6729 = getelementptr inbounds i32, ptr %468, i64 3
  %6730 = load i128, ptr %467, align 16
  %6731 = xor i128 %6730, -1
  %6732 = call i128 @llvm.cttz.i128(i128 %6731, i1 false)
  %6733 = trunc i128 %6732 to i32
  store i32 %6733, ptr %6729, align 4
  %6734 = getelementptr inbounds i32, ptr %468, i64 4
  %6735 = load i128, ptr %467, align 16
  %6736 = xor i128 %6735, -1
  %6737 = call i128 @llvm.ctlz.i128(i128 %6736, i1 false)
  %6738 = add i128 %6737, 1
  %6739 = icmp eq i128 %6736, 0
  %6740 = select i1 %6739, i128 0, i128 %6738
  %6741 = trunc i128 %6740 to i32
  store i32 %6741, ptr %6734, align 4
  %6742 = getelementptr inbounds i32, ptr %468, i64 5
  %6743 = load i128, ptr %467, align 16
  %6744 = call i128 @llvm.ctlz.i128(i128 %6743, i1 false)
  %6745 = add i128 %6744, 1
  %6746 = icmp eq i128 %6743, 0
  %6747 = select i1 %6746, i128 0, i128 %6745
  %6748 = trunc i128 %6747 to i32
  store i32 %6748, ptr %6742, align 4
  %6749 = getelementptr inbounds i32, ptr %468, i64 6
  %6750 = load i128, ptr %467, align 16
  %6751 = xor i128 %6750, -1
  %6752 = call i128 @llvm.cttz.i128(i128 %6751, i1 false)
  %6753 = add i128 %6752, 1
  %6754 = icmp eq i128 %6751, 0
  %6755 = select i1 %6754, i128 0, i128 %6753
  %6756 = trunc i128 %6755 to i32
  store i32 %6756, ptr %6749, align 4
  %6757 = getelementptr inbounds i32, ptr %468, i64 7
  %6758 = load i128, ptr %467, align 16
  %6759 = call i128 @llvm.cttz.i128(i128 %6758, i1 false)
  %6760 = add i128 %6759, 1
  %6761 = icmp eq i128 %6758, 0
  %6762 = select i1 %6761, i128 0, i128 %6760
  %6763 = trunc i128 %6762 to i32
  store i32 %6763, ptr %6757, align 4
  %6764 = getelementptr inbounds i32, ptr %468, i64 8
  %6765 = load i128, ptr %467, align 16
  %6766 = call i128 @llvm.ctpop.i128(i128 %6765)
  %6767 = sub i128 128, %6766
  %6768 = trunc i128 %6767 to i32
  store i32 %6768, ptr %6764, align 4
  %6769 = getelementptr inbounds i32, ptr %468, i64 9
  %6770 = load i128, ptr %467, align 16
  %6771 = call i128 @llvm.ctpop.i128(i128 %6770)
  %6772 = trunc i128 %6771 to i32
  store i32 %6772, ptr %6769, align 4
  %6773 = getelementptr inbounds i32, ptr %468, i64 10
  %6774 = load i128, ptr %467, align 16
  %6775 = call i128 @llvm.ctpop.i128(i128 %6774)
  %6776 = icmp eq i128 %6775, 1
  %6777 = zext i1 %6776 to i32
  store i32 %6777, ptr %6773, align 4
  %6778 = getelementptr inbounds i32, ptr %468, i64 11
  %6779 = load i128, ptr %467, align 16
  %6780 = call i128 @llvm.ctlz.i128(i128 %6779, i1 false)
  %6781 = sub i128 128, %6780
  %6782 = trunc i128 %6781 to i32
  store i32 %6782, ptr %6778, align 4
  %6783 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 0
  %6784 = load i32, ptr %6783, align 16
  %6785 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 1
  %6786 = load i32, ptr %6785, align 4
  %6787 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 2
  %6788 = load i32, ptr %6787, align 8
  %6789 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 3
  %6790 = load i32, ptr %6789, align 4
  %6791 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 4
  %6792 = load i32, ptr %6791, align 16
  %6793 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 5
  %6794 = load i32, ptr %6793, align 4
  %6795 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 6
  %6796 = load i32, ptr %6795, align 8
  %6797 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 7
  %6798 = load i32, ptr %6797, align 4
  %6799 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 8
  %6800 = load i32, ptr %6799, align 16
  %6801 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 9
  %6802 = load i32, ptr %6801, align 4
  %6803 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 10
  %6804 = load i32, ptr %6803, align 8
  %6805 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 11
  %6806 = load i32, ptr %6805, align 4
  %6807 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef %6784, i32 noundef %6786, i32 noundef %6788, i32 noundef %6790, i32 noundef %6792, i32 noundef %6794, i32 noundef %6796, i32 noundef %6798, i32 noundef %6800, i32 noundef %6802, i32 noundef %6804, i32 noundef %6806)
  %6808 = load i128, ptr %467, align 16
  %6809 = call i128 @llvm.ctlz.i128(i128 %6808, i1 true)
  %6810 = sub i128 127, %6809
  %6811 = shl i128 1, %6810
  %6812 = icmp eq i128 %6808, 0
  %6813 = select i1 %6812, i128 0, i128 %6811
  store i128 %6813, ptr %469, align 16
  %6814 = load i128, ptr %467, align 16
  %6815 = icmp ule i128 %6814, 1
  br i1 %6815, label %6821, label %6816

6816:                                             ; preds = %6716
  %6817 = sub i128 %6814, 1
  %6818 = call i128 @llvm.ctlz.i128(i128 %6817, i1 false)
  %6819 = sub i128 127, %6818
  %6820 = shl i128 2, %6819
  br label %6821

6821:                                             ; preds = %6816, %6716
  %6822 = phi i128 [ 1, %6716 ], [ %6820, %6816 ]
  store i128 %6822, ptr %470, align 16
  %6823 = load i128, ptr %467, align 16
  %6824 = call i128 @llvm.fshl.i128(i128 %6823, i128 %6823, i128 3)
  store i128 %6824, ptr %471, align 16
  %6825 = load i128, ptr %467, align 16
  %6826 = call i128 @llvm.fshr.i128(i128 %6825, i128 %6825, i128 3)
  store i128 %6826, ptr %472, align 16
  %6827 = load i128, ptr %467, align 16
  %6828 = call i128 @llvm.fshl.i128(i128 %6827, i128 %6827, i128 0)
  store i128 %6828, ptr %473, align 16
  %6829 = load i128, ptr %467, align 16
  %6830 = call i128 @llvm.fshl.i128(i128 %6829, i128 %6829, i128 104)
  store i128 %6830, ptr %474, align 16
  %6831 = load i128, ptr %469, align 16
  %6832 = zext i128 %6831 to i256
  %6833 = lshr i256 %6832, 128
  %6834 = trunc i256 %6833 to i64
  %6835 = load i128, ptr %469, align 16
  %6836 = zext i128 %6835 to i256
  %6837 = lshr i256 %6836, 64
  %6838 = trunc i256 %6837 to i64
  %6839 = load i128, ptr %469, align 16
  %6840 = trunc i128 %6839 to i64
  %6841 = load i128, ptr %470, align 16
  %6842 = zext i128 %6841 to i256
  %6843 = lshr i256 %6842, 128
  %6844 = trunc i256 %6843 to i64
  %6845 = load i128, ptr %470, align 16
  %6846 = zext i128 %6845 to i256
  %6847 = lshr i256 %6846, 64
  %6848 = trunc i256 %6847 to i64
  %6849 = load i128, ptr %470, align 16
  %6850 = trunc i128 %6849 to i64
  %6851 = load i128, ptr %471, align 16
  %6852 = zext i128 %6851 to i256
  %6853 = lshr i256 %6852, 128
  %6854 = trunc i256 %6853 to i64
  %6855 = load i128, ptr %471, align 16
  %6856 = zext i128 %6855 to i256
  %6857 = lshr i256 %6856, 64
  %6858 = trunc i256 %6857 to i64
  %6859 = load i128, ptr %471, align 16
  %6860 = trunc i128 %6859 to i64
  %6861 = load i128, ptr %472, align 16
  %6862 = zext i128 %6861 to i256
  %6863 = lshr i256 %6862, 128
  %6864 = trunc i256 %6863 to i64
  %6865 = load i128, ptr %472, align 16
  %6866 = zext i128 %6865 to i256
  %6867 = lshr i256 %6866, 64
  %6868 = trunc i256 %6867 to i64
  %6869 = load i128, ptr %472, align 16
  %6870 = trunc i128 %6869 to i64
  %6871 = load i128, ptr %473, align 16
  %6872 = trunc i128 %6871 to i64
  %6873 = load i128, ptr %474, align 16
  %6874 = trunc i128 %6873 to i64
  %6875 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %6834, i64 noundef %6838, i64 noundef %6840, i64 noundef %6844, i64 noundef %6848, i64 noundef %6850, i64 noundef %6854, i64 noundef %6858, i64 noundef %6860, i64 noundef %6864, i64 noundef %6868, i64 noundef %6870, i64 noundef %6872, i64 noundef %6874)
  %6876 = load i128, ptr %467, align 16
  %6877 = zext i128 %6876 to i575
  %6878 = getelementptr inbounds [12 x i32], ptr %468, i64 0, i64 0
  %6879 = load i128, ptr %469, align 16
  %6880 = zext i128 %6879 to i575
  %6881 = load i128, ptr %470, align 16
  %6882 = zext i128 %6881 to i575
  %6883 = load i128, ptr %471, align 16
  %6884 = zext i128 %6883 to i575
  %6885 = load i128, ptr %472, align 16
  %6886 = zext i128 %6885 to i575
  %6887 = load i128, ptr %473, align 16
  %6888 = zext i128 %6887 to i575
  %6889 = load i128, ptr %474, align 16
  %6890 = zext i128 %6889 to i575
  %6891 = zext i575 %6877 to i576
  store i576 %6891, ptr %475, align 8
  %6892 = zext i575 %6880 to i576
  store i576 %6892, ptr %476, align 8
  %6893 = zext i575 %6882 to i576
  store i576 %6893, ptr %477, align 8
  %6894 = zext i575 %6884 to i576
  store i576 %6894, ptr %478, align 8
  %6895 = zext i575 %6886 to i576
  store i576 %6895, ptr %479, align 8
  %6896 = zext i575 %6888 to i576
  store i576 %6896, ptr %480, align 8
  %6897 = zext i575 %6890 to i576
  store i576 %6897, ptr %481, align 8
  call void @check(ptr noundef @.str.7, i32 noundef 128, ptr noundef byval([72 x i8]) align 8 %475, ptr noundef %6878, ptr noundef byval([72 x i8]) align 8 %476, ptr noundef byval([72 x i8]) align 8 %477, ptr noundef byval([72 x i8]) align 8 %478, ptr noundef byval([72 x i8]) align 8 %479, ptr noundef byval([72 x i8]) align 8 %480, ptr noundef byval([72 x i8]) align 8 %481)
  br label %6898

6898:                                             ; preds = %6821
  br label %6899

6899:                                             ; preds = %6898
  store i8 80, ptr %482, align 1
  %6900 = load i8, ptr %482, align 1
  %6901 = trunc i8 %6900 to i7
  %6902 = call i7 @llvm.ctlz.i7(i7 %6901, i1 false)
  %6903 = zext i7 %6902 to i32
  store i32 %6903, ptr %483, align 4
  %6904 = getelementptr inbounds i32, ptr %483, i64 1
  %6905 = load i8, ptr %482, align 1
  %6906 = trunc i8 %6905 to i7
  %6907 = xor i7 %6906, -1
  %6908 = call i7 @llvm.ctlz.i7(i7 %6907, i1 false)
  %6909 = zext i7 %6908 to i32
  store i32 %6909, ptr %6904, align 4
  %6910 = getelementptr inbounds i32, ptr %483, i64 2
  %6911 = load i8, ptr %482, align 1
  %6912 = trunc i8 %6911 to i7
  %6913 = call i7 @llvm.cttz.i7(i7 %6912, i1 false)
  %6914 = zext i7 %6913 to i32
  store i32 %6914, ptr %6910, align 4
  %6915 = getelementptr inbounds i32, ptr %483, i64 3
  %6916 = load i8, ptr %482, align 1
  %6917 = trunc i8 %6916 to i7
  %6918 = xor i7 %6917, -1
  %6919 = call i7 @llvm.cttz.i7(i7 %6918, i1 false)
  %6920 = zext i7 %6919 to i32
  store i32 %6920, ptr %6915, align 4
  %6921 = getelementptr inbounds i32, ptr %483, i64 4
  %6922 = load i8, ptr %482, align 1
  %6923 = trunc i8 %6922 to i7
  %6924 = xor i7 %6923, -1
  %6925 = call i7 @llvm.ctlz.i7(i7 %6924, i1 false)
  %6926 = add i7 %6925, 1
  %6927 = icmp eq i7 %6924, 0
  %6928 = select i1 %6927, i7 0, i7 %6926
  %6929 = zext i7 %6928 to i32
  store i32 %6929, ptr %6921, align 4
  %6930 = getelementptr inbounds i32, ptr %483, i64 5
  %6931 = load i8, ptr %482, align 1
  %6932 = trunc i8 %6931 to i7
  %6933 = call i7 @llvm.ctlz.i7(i7 %6932, i1 false)
  %6934 = add i7 %6933, 1
  %6935 = icmp eq i7 %6932, 0
  %6936 = select i1 %6935, i7 0, i7 %6934
  %6937 = zext i7 %6936 to i32
  store i32 %6937, ptr %6930, align 4
  %6938 = getelementptr inbounds i32, ptr %483, i64 6
  %6939 = load i8, ptr %482, align 1
  %6940 = trunc i8 %6939 to i7
  %6941 = xor i7 %6940, -1
  %6942 = call i7 @llvm.cttz.i7(i7 %6941, i1 false)
  %6943 = add i7 %6942, 1
  %6944 = icmp eq i7 %6941, 0
  %6945 = select i1 %6944, i7 0, i7 %6943
  %6946 = zext i7 %6945 to i32
  store i32 %6946, ptr %6938, align 4
  %6947 = getelementptr inbounds i32, ptr %483, i64 7
  %6948 = load i8, ptr %482, align 1
  %6949 = trunc i8 %6948 to i7
  %6950 = call i7 @llvm.cttz.i7(i7 %6949, i1 false)
  %6951 = add i7 %6950, 1
  %6952 = icmp eq i7 %6949, 0
  %6953 = select i1 %6952, i7 0, i7 %6951
  %6954 = zext i7 %6953 to i32
  store i32 %6954, ptr %6947, align 4
  %6955 = getelementptr inbounds i32, ptr %483, i64 8
  %6956 = load i8, ptr %482, align 1
  %6957 = trunc i8 %6956 to i7
  %6958 = call i7 @llvm.ctpop.i7(i7 %6957)
  %6959 = sub i7 7, %6958
  %6960 = zext i7 %6959 to i32
  store i32 %6960, ptr %6955, align 4
  %6961 = getelementptr inbounds i32, ptr %483, i64 9
  %6962 = load i8, ptr %482, align 1
  %6963 = trunc i8 %6962 to i7
  %6964 = call i7 @llvm.ctpop.i7(i7 %6963)
  %6965 = zext i7 %6964 to i32
  store i32 %6965, ptr %6961, align 4
  %6966 = getelementptr inbounds i32, ptr %483, i64 10
  %6967 = load i8, ptr %482, align 1
  %6968 = trunc i8 %6967 to i7
  %6969 = call i7 @llvm.ctpop.i7(i7 %6968)
  %6970 = icmp eq i7 %6969, 1
  %6971 = zext i1 %6970 to i32
  store i32 %6971, ptr %6966, align 4
  %6972 = getelementptr inbounds i32, ptr %483, i64 11
  %6973 = load i8, ptr %482, align 1
  %6974 = trunc i8 %6973 to i7
  %6975 = call i7 @llvm.ctlz.i7(i7 %6974, i1 false)
  %6976 = sub i7 7, %6975
  %6977 = zext i7 %6976 to i32
  store i32 %6977, ptr %6972, align 4
  %6978 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 0
  %6979 = load i32, ptr %6978, align 16
  %6980 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 1
  %6981 = load i32, ptr %6980, align 4
  %6982 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 2
  %6983 = load i32, ptr %6982, align 8
  %6984 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 3
  %6985 = load i32, ptr %6984, align 4
  %6986 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 4
  %6987 = load i32, ptr %6986, align 16
  %6988 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 5
  %6989 = load i32, ptr %6988, align 4
  %6990 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 6
  %6991 = load i32, ptr %6990, align 8
  %6992 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 7
  %6993 = load i32, ptr %6992, align 4
  %6994 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 8
  %6995 = load i32, ptr %6994, align 16
  %6996 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 9
  %6997 = load i32, ptr %6996, align 4
  %6998 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 10
  %6999 = load i32, ptr %6998, align 8
  %7000 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 11
  %7001 = load i32, ptr %7000, align 4
  %7002 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef %6979, i32 noundef %6981, i32 noundef %6983, i32 noundef %6985, i32 noundef %6987, i32 noundef %6989, i32 noundef %6991, i32 noundef %6993, i32 noundef %6995, i32 noundef %6997, i32 noundef %6999, i32 noundef %7001)
  %7003 = load i8, ptr %482, align 1
  %7004 = trunc i8 %7003 to i7
  %7005 = call i7 @llvm.ctlz.i7(i7 %7004, i1 true)
  %7006 = sub i7 6, %7005
  %7007 = shl i7 1, %7006
  %7008 = icmp eq i7 %7004, 0
  %7009 = select i1 %7008, i7 0, i7 %7007
  %7010 = zext i7 %7009 to i8
  store i8 %7010, ptr %484, align 1
  %7011 = load i8, ptr %482, align 1
  %7012 = trunc i8 %7011 to i7
  %7013 = icmp ule i7 %7012, 1
  br i1 %7013, label %7019, label %7014

7014:                                             ; preds = %6899
  %7015 = sub i7 %7012, 1
  %7016 = call i7 @llvm.ctlz.i7(i7 %7015, i1 false)
  %7017 = sub i7 6, %7016
  %7018 = shl i7 2, %7017
  br label %7019

7019:                                             ; preds = %7014, %6899
  %7020 = phi i7 [ 1, %6899 ], [ %7018, %7014 ]
  %7021 = zext i7 %7020 to i8
  store i8 %7021, ptr %485, align 1
  %7022 = load i8, ptr %482, align 1
  %7023 = trunc i8 %7022 to i7
  %7024 = call i7 @llvm.fshl.i7(i7 %7023, i7 %7023, i7 3)
  %7025 = zext i7 %7024 to i8
  store i8 %7025, ptr %486, align 1
  %7026 = load i8, ptr %482, align 1
  %7027 = trunc i8 %7026 to i7
  %7028 = call i7 @llvm.fshr.i7(i7 %7027, i7 %7027, i7 3)
  %7029 = zext i7 %7028 to i8
  store i8 %7029, ptr %487, align 1
  %7030 = load i8, ptr %482, align 1
  %7031 = trunc i8 %7030 to i7
  %7032 = call i7 @llvm.fshl.i7(i7 %7031, i7 %7031, i7 0)
  %7033 = zext i7 %7032 to i8
  store i8 %7033, ptr %488, align 1
  %7034 = load i8, ptr %482, align 1
  %7035 = trunc i8 %7034 to i7
  %7036 = call i7 @llvm.fshl.i7(i7 %7035, i7 %7035, i7 6)
  %7037 = zext i7 %7036 to i8
  store i8 %7037, ptr %489, align 1
  %7038 = load i8, ptr %484, align 1
  %7039 = trunc i8 %7038 to i7
  %7040 = zext i7 %7039 to i256
  %7041 = lshr i256 %7040, 128
  %7042 = trunc i256 %7041 to i64
  %7043 = load i8, ptr %484, align 1
  %7044 = trunc i8 %7043 to i7
  %7045 = zext i7 %7044 to i256
  %7046 = lshr i256 %7045, 64
  %7047 = trunc i256 %7046 to i64
  %7048 = load i8, ptr %484, align 1
  %7049 = trunc i8 %7048 to i7
  %7050 = zext i7 %7049 to i64
  %7051 = load i8, ptr %485, align 1
  %7052 = trunc i8 %7051 to i7
  %7053 = zext i7 %7052 to i256
  %7054 = lshr i256 %7053, 128
  %7055 = trunc i256 %7054 to i64
  %7056 = load i8, ptr %485, align 1
  %7057 = trunc i8 %7056 to i7
  %7058 = zext i7 %7057 to i256
  %7059 = lshr i256 %7058, 64
  %7060 = trunc i256 %7059 to i64
  %7061 = load i8, ptr %485, align 1
  %7062 = trunc i8 %7061 to i7
  %7063 = zext i7 %7062 to i64
  %7064 = load i8, ptr %486, align 1
  %7065 = trunc i8 %7064 to i7
  %7066 = zext i7 %7065 to i256
  %7067 = lshr i256 %7066, 128
  %7068 = trunc i256 %7067 to i64
  %7069 = load i8, ptr %486, align 1
  %7070 = trunc i8 %7069 to i7
  %7071 = zext i7 %7070 to i256
  %7072 = lshr i256 %7071, 64
  %7073 = trunc i256 %7072 to i64
  %7074 = load i8, ptr %486, align 1
  %7075 = trunc i8 %7074 to i7
  %7076 = zext i7 %7075 to i64
  %7077 = load i8, ptr %487, align 1
  %7078 = trunc i8 %7077 to i7
  %7079 = zext i7 %7078 to i256
  %7080 = lshr i256 %7079, 128
  %7081 = trunc i256 %7080 to i64
  %7082 = load i8, ptr %487, align 1
  %7083 = trunc i8 %7082 to i7
  %7084 = zext i7 %7083 to i256
  %7085 = lshr i256 %7084, 64
  %7086 = trunc i256 %7085 to i64
  %7087 = load i8, ptr %487, align 1
  %7088 = trunc i8 %7087 to i7
  %7089 = zext i7 %7088 to i64
  %7090 = load i8, ptr %488, align 1
  %7091 = trunc i8 %7090 to i7
  %7092 = zext i7 %7091 to i64
  %7093 = load i8, ptr %489, align 1
  %7094 = trunc i8 %7093 to i7
  %7095 = zext i7 %7094 to i64
  %7096 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %7042, i64 noundef %7047, i64 noundef %7050, i64 noundef %7055, i64 noundef %7060, i64 noundef %7063, i64 noundef %7068, i64 noundef %7073, i64 noundef %7076, i64 noundef %7081, i64 noundef %7086, i64 noundef %7089, i64 noundef %7092, i64 noundef %7095)
  %7097 = load i8, ptr %482, align 1
  %7098 = trunc i8 %7097 to i7
  %7099 = zext i7 %7098 to i575
  %7100 = getelementptr inbounds [12 x i32], ptr %483, i64 0, i64 0
  %7101 = load i8, ptr %484, align 1
  %7102 = trunc i8 %7101 to i7
  %7103 = zext i7 %7102 to i575
  %7104 = load i8, ptr %485, align 1
  %7105 = trunc i8 %7104 to i7
  %7106 = zext i7 %7105 to i575
  %7107 = load i8, ptr %486, align 1
  %7108 = trunc i8 %7107 to i7
  %7109 = zext i7 %7108 to i575
  %7110 = load i8, ptr %487, align 1
  %7111 = trunc i8 %7110 to i7
  %7112 = zext i7 %7111 to i575
  %7113 = load i8, ptr %488, align 1
  %7114 = trunc i8 %7113 to i7
  %7115 = zext i7 %7114 to i575
  %7116 = load i8, ptr %489, align 1
  %7117 = trunc i8 %7116 to i7
  %7118 = zext i7 %7117 to i575
  %7119 = zext i575 %7099 to i576
  store i576 %7119, ptr %490, align 8
  %7120 = zext i575 %7103 to i576
  store i576 %7120, ptr %491, align 8
  %7121 = zext i575 %7106 to i576
  store i576 %7121, ptr %492, align 8
  %7122 = zext i575 %7109 to i576
  store i576 %7122, ptr %493, align 8
  %7123 = zext i575 %7112 to i576
  store i576 %7123, ptr %494, align 8
  %7124 = zext i575 %7115 to i576
  store i576 %7124, ptr %495, align 8
  %7125 = zext i575 %7118 to i576
  store i576 %7125, ptr %496, align 8
  call void @check(ptr noundef @.str.8, i32 noundef 7, ptr noundef byval([72 x i8]) align 8 %490, ptr noundef %7100, ptr noundef byval([72 x i8]) align 8 %491, ptr noundef byval([72 x i8]) align 8 %492, ptr noundef byval([72 x i8]) align 8 %493, ptr noundef byval([72 x i8]) align 8 %494, ptr noundef byval([72 x i8]) align 8 %495, ptr noundef byval([72 x i8]) align 8 %496)
  br label %7126

7126:                                             ; preds = %7019
  br label %7127

7127:                                             ; preds = %7126
  store i128 80, ptr %497, align 8
  %7128 = load i128, ptr %497, align 8
  %7129 = trunc i128 %7128 to i65
  %7130 = call i65 @llvm.ctlz.i65(i65 %7129, i1 false)
  %7131 = trunc i65 %7130 to i32
  store i32 %7131, ptr %498, align 4
  %7132 = getelementptr inbounds i32, ptr %498, i64 1
  %7133 = load i128, ptr %497, align 8
  %7134 = trunc i128 %7133 to i65
  %7135 = xor i65 %7134, -1
  %7136 = call i65 @llvm.ctlz.i65(i65 %7135, i1 false)
  %7137 = trunc i65 %7136 to i32
  store i32 %7137, ptr %7132, align 4
  %7138 = getelementptr inbounds i32, ptr %498, i64 2
  %7139 = load i128, ptr %497, align 8
  %7140 = trunc i128 %7139 to i65
  %7141 = call i65 @llvm.cttz.i65(i65 %7140, i1 false)
  %7142 = trunc i65 %7141 to i32
  store i32 %7142, ptr %7138, align 4
  %7143 = getelementptr inbounds i32, ptr %498, i64 3
  %7144 = load i128, ptr %497, align 8
  %7145 = trunc i128 %7144 to i65
  %7146 = xor i65 %7145, -1
  %7147 = call i65 @llvm.cttz.i65(i65 %7146, i1 false)
  %7148 = trunc i65 %7147 to i32
  store i32 %7148, ptr %7143, align 4
  %7149 = getelementptr inbounds i32, ptr %498, i64 4
  %7150 = load i128, ptr %497, align 8
  %7151 = trunc i128 %7150 to i65
  %7152 = xor i65 %7151, -1
  %7153 = call i65 @llvm.ctlz.i65(i65 %7152, i1 false)
  %7154 = add i65 %7153, 1
  %7155 = icmp eq i65 %7152, 0
  %7156 = select i1 %7155, i65 0, i65 %7154
  %7157 = trunc i65 %7156 to i32
  store i32 %7157, ptr %7149, align 4
  %7158 = getelementptr inbounds i32, ptr %498, i64 5
  %7159 = load i128, ptr %497, align 8
  %7160 = trunc i128 %7159 to i65
  %7161 = call i65 @llvm.ctlz.i65(i65 %7160, i1 false)
  %7162 = add i65 %7161, 1
  %7163 = icmp eq i65 %7160, 0
  %7164 = select i1 %7163, i65 0, i65 %7162
  %7165 = trunc i65 %7164 to i32
  store i32 %7165, ptr %7158, align 4
  %7166 = getelementptr inbounds i32, ptr %498, i64 6
  %7167 = load i128, ptr %497, align 8
  %7168 = trunc i128 %7167 to i65
  %7169 = xor i65 %7168, -1
  %7170 = call i65 @llvm.cttz.i65(i65 %7169, i1 false)
  %7171 = add i65 %7170, 1
  %7172 = icmp eq i65 %7169, 0
  %7173 = select i1 %7172, i65 0, i65 %7171
  %7174 = trunc i65 %7173 to i32
  store i32 %7174, ptr %7166, align 4
  %7175 = getelementptr inbounds i32, ptr %498, i64 7
  %7176 = load i128, ptr %497, align 8
  %7177 = trunc i128 %7176 to i65
  %7178 = call i65 @llvm.cttz.i65(i65 %7177, i1 false)
  %7179 = add i65 %7178, 1
  %7180 = icmp eq i65 %7177, 0
  %7181 = select i1 %7180, i65 0, i65 %7179
  %7182 = trunc i65 %7181 to i32
  store i32 %7182, ptr %7175, align 4
  %7183 = getelementptr inbounds i32, ptr %498, i64 8
  %7184 = load i128, ptr %497, align 8
  %7185 = trunc i128 %7184 to i65
  %7186 = call i65 @llvm.ctpop.i65(i65 %7185)
  %7187 = sub i65 65, %7186
  %7188 = trunc i65 %7187 to i32
  store i32 %7188, ptr %7183, align 4
  %7189 = getelementptr inbounds i32, ptr %498, i64 9
  %7190 = load i128, ptr %497, align 8
  %7191 = trunc i128 %7190 to i65
  %7192 = call i65 @llvm.ctpop.i65(i65 %7191)
  %7193 = trunc i65 %7192 to i32
  store i32 %7193, ptr %7189, align 4
  %7194 = getelementptr inbounds i32, ptr %498, i64 10
  %7195 = load i128, ptr %497, align 8
  %7196 = trunc i128 %7195 to i65
  %7197 = call i65 @llvm.ctpop.i65(i65 %7196)
  %7198 = icmp eq i65 %7197, 1
  %7199 = zext i1 %7198 to i32
  store i32 %7199, ptr %7194, align 4
  %7200 = getelementptr inbounds i32, ptr %498, i64 11
  %7201 = load i128, ptr %497, align 8
  %7202 = trunc i128 %7201 to i65
  %7203 = call i65 @llvm.ctlz.i65(i65 %7202, i1 false)
  %7204 = sub i65 65, %7203
  %7205 = trunc i65 %7204 to i32
  store i32 %7205, ptr %7200, align 4
  %7206 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 0
  %7207 = load i32, ptr %7206, align 16
  %7208 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 1
  %7209 = load i32, ptr %7208, align 4
  %7210 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 2
  %7211 = load i32, ptr %7210, align 8
  %7212 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 3
  %7213 = load i32, ptr %7212, align 4
  %7214 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 4
  %7215 = load i32, ptr %7214, align 16
  %7216 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 5
  %7217 = load i32, ptr %7216, align 4
  %7218 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 6
  %7219 = load i32, ptr %7218, align 8
  %7220 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 7
  %7221 = load i32, ptr %7220, align 4
  %7222 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 8
  %7223 = load i32, ptr %7222, align 16
  %7224 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 9
  %7225 = load i32, ptr %7224, align 4
  %7226 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 10
  %7227 = load i32, ptr %7226, align 8
  %7228 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 11
  %7229 = load i32, ptr %7228, align 4
  %7230 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef %7207, i32 noundef %7209, i32 noundef %7211, i32 noundef %7213, i32 noundef %7215, i32 noundef %7217, i32 noundef %7219, i32 noundef %7221, i32 noundef %7223, i32 noundef %7225, i32 noundef %7227, i32 noundef %7229)
  %7231 = load i128, ptr %497, align 8
  %7232 = trunc i128 %7231 to i65
  %7233 = call i65 @llvm.ctlz.i65(i65 %7232, i1 true)
  %7234 = sub i65 64, %7233
  %7235 = shl i65 1, %7234
  %7236 = icmp eq i65 %7232, 0
  %7237 = select i1 %7236, i65 0, i65 %7235
  %7238 = zext i65 %7237 to i128
  store i128 %7238, ptr %499, align 8
  %7239 = load i128, ptr %497, align 8
  %7240 = trunc i128 %7239 to i65
  %7241 = icmp ule i65 %7240, 1
  br i1 %7241, label %7247, label %7242

7242:                                             ; preds = %7127
  %7243 = sub i65 %7240, 1
  %7244 = call i65 @llvm.ctlz.i65(i65 %7243, i1 false)
  %7245 = sub i65 64, %7244
  %7246 = shl i65 2, %7245
  br label %7247

7247:                                             ; preds = %7242, %7127
  %7248 = phi i65 [ 1, %7127 ], [ %7246, %7242 ]
  %7249 = zext i65 %7248 to i128
  store i128 %7249, ptr %500, align 8
  %7250 = load i128, ptr %497, align 8
  %7251 = trunc i128 %7250 to i65
  %7252 = call i65 @llvm.fshl.i65(i65 %7251, i65 %7251, i65 3)
  %7253 = zext i65 %7252 to i128
  store i128 %7253, ptr %501, align 8
  %7254 = load i128, ptr %497, align 8
  %7255 = trunc i128 %7254 to i65
  %7256 = call i65 @llvm.fshr.i65(i65 %7255, i65 %7255, i65 3)
  %7257 = zext i65 %7256 to i128
  store i128 %7257, ptr %502, align 8
  %7258 = load i128, ptr %497, align 8
  %7259 = trunc i128 %7258 to i65
  %7260 = call i65 @llvm.fshl.i65(i65 %7259, i65 %7259, i65 0)
  %7261 = zext i65 %7260 to i128
  store i128 %7261, ptr %503, align 8
  %7262 = load i128, ptr %497, align 8
  %7263 = trunc i128 %7262 to i65
  %7264 = call i65 @llvm.fshl.i65(i65 %7263, i65 %7263, i65 25)
  %7265 = zext i65 %7264 to i128
  store i128 %7265, ptr %504, align 8
  %7266 = load i128, ptr %499, align 8
  %7267 = trunc i128 %7266 to i65
  %7268 = zext i65 %7267 to i256
  %7269 = lshr i256 %7268, 128
  %7270 = trunc i256 %7269 to i64
  %7271 = load i128, ptr %499, align 8
  %7272 = trunc i128 %7271 to i65
  %7273 = zext i65 %7272 to i256
  %7274 = lshr i256 %7273, 64
  %7275 = trunc i256 %7274 to i64
  %7276 = load i128, ptr %499, align 8
  %7277 = trunc i128 %7276 to i65
  %7278 = trunc i65 %7277 to i64
  %7279 = load i128, ptr %500, align 8
  %7280 = trunc i128 %7279 to i65
  %7281 = zext i65 %7280 to i256
  %7282 = lshr i256 %7281, 128
  %7283 = trunc i256 %7282 to i64
  %7284 = load i128, ptr %500, align 8
  %7285 = trunc i128 %7284 to i65
  %7286 = zext i65 %7285 to i256
  %7287 = lshr i256 %7286, 64
  %7288 = trunc i256 %7287 to i64
  %7289 = load i128, ptr %500, align 8
  %7290 = trunc i128 %7289 to i65
  %7291 = trunc i65 %7290 to i64
  %7292 = load i128, ptr %501, align 8
  %7293 = trunc i128 %7292 to i65
  %7294 = zext i65 %7293 to i256
  %7295 = lshr i256 %7294, 128
  %7296 = trunc i256 %7295 to i64
  %7297 = load i128, ptr %501, align 8
  %7298 = trunc i128 %7297 to i65
  %7299 = zext i65 %7298 to i256
  %7300 = lshr i256 %7299, 64
  %7301 = trunc i256 %7300 to i64
  %7302 = load i128, ptr %501, align 8
  %7303 = trunc i128 %7302 to i65
  %7304 = trunc i65 %7303 to i64
  %7305 = load i128, ptr %502, align 8
  %7306 = trunc i128 %7305 to i65
  %7307 = zext i65 %7306 to i256
  %7308 = lshr i256 %7307, 128
  %7309 = trunc i256 %7308 to i64
  %7310 = load i128, ptr %502, align 8
  %7311 = trunc i128 %7310 to i65
  %7312 = zext i65 %7311 to i256
  %7313 = lshr i256 %7312, 64
  %7314 = trunc i256 %7313 to i64
  %7315 = load i128, ptr %502, align 8
  %7316 = trunc i128 %7315 to i65
  %7317 = trunc i65 %7316 to i64
  %7318 = load i128, ptr %503, align 8
  %7319 = trunc i128 %7318 to i65
  %7320 = trunc i65 %7319 to i64
  %7321 = load i128, ptr %504, align 8
  %7322 = trunc i128 %7321 to i65
  %7323 = trunc i65 %7322 to i64
  %7324 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %7270, i64 noundef %7275, i64 noundef %7278, i64 noundef %7283, i64 noundef %7288, i64 noundef %7291, i64 noundef %7296, i64 noundef %7301, i64 noundef %7304, i64 noundef %7309, i64 noundef %7314, i64 noundef %7317, i64 noundef %7320, i64 noundef %7323)
  %7325 = load i128, ptr %497, align 8
  %7326 = trunc i128 %7325 to i65
  %7327 = zext i65 %7326 to i575
  %7328 = getelementptr inbounds [12 x i32], ptr %498, i64 0, i64 0
  %7329 = load i128, ptr %499, align 8
  %7330 = trunc i128 %7329 to i65
  %7331 = zext i65 %7330 to i575
  %7332 = load i128, ptr %500, align 8
  %7333 = trunc i128 %7332 to i65
  %7334 = zext i65 %7333 to i575
  %7335 = load i128, ptr %501, align 8
  %7336 = trunc i128 %7335 to i65
  %7337 = zext i65 %7336 to i575
  %7338 = load i128, ptr %502, align 8
  %7339 = trunc i128 %7338 to i65
  %7340 = zext i65 %7339 to i575
  %7341 = load i128, ptr %503, align 8
  %7342 = trunc i128 %7341 to i65
  %7343 = zext i65 %7342 to i575
  %7344 = load i128, ptr %504, align 8
  %7345 = trunc i128 %7344 to i65
  %7346 = zext i65 %7345 to i575
  %7347 = zext i575 %7327 to i576
  store i576 %7347, ptr %505, align 8
  %7348 = zext i575 %7331 to i576
  store i576 %7348, ptr %506, align 8
  %7349 = zext i575 %7334 to i576
  store i576 %7349, ptr %507, align 8
  %7350 = zext i575 %7337 to i576
  store i576 %7350, ptr %508, align 8
  %7351 = zext i575 %7340 to i576
  store i576 %7351, ptr %509, align 8
  %7352 = zext i575 %7343 to i576
  store i576 %7352, ptr %510, align 8
  %7353 = zext i575 %7346 to i576
  store i576 %7353, ptr %511, align 8
  call void @check(ptr noundef @.str.9, i32 noundef 65, ptr noundef byval([72 x i8]) align 8 %505, ptr noundef %7328, ptr noundef byval([72 x i8]) align 8 %506, ptr noundef byval([72 x i8]) align 8 %507, ptr noundef byval([72 x i8]) align 8 %508, ptr noundef byval([72 x i8]) align 8 %509, ptr noundef byval([72 x i8]) align 8 %510, ptr noundef byval([72 x i8]) align 8 %511)
  br label %7354

7354:                                             ; preds = %7247
  br label %7355

7355:                                             ; preds = %7354
  store i192 80, ptr %512, align 8
  %7356 = load i192, ptr %512, align 8
  %7357 = trunc i192 %7356 to i129
  %7358 = call i129 @llvm.ctlz.i129(i129 %7357, i1 false)
  %7359 = trunc i129 %7358 to i32
  store i32 %7359, ptr %513, align 4
  %7360 = getelementptr inbounds i32, ptr %513, i64 1
  %7361 = load i192, ptr %512, align 8
  %7362 = trunc i192 %7361 to i129
  %7363 = xor i129 %7362, -1
  %7364 = call i129 @llvm.ctlz.i129(i129 %7363, i1 false)
  %7365 = trunc i129 %7364 to i32
  store i32 %7365, ptr %7360, align 4
  %7366 = getelementptr inbounds i32, ptr %513, i64 2
  %7367 = load i192, ptr %512, align 8
  %7368 = trunc i192 %7367 to i129
  %7369 = call i129 @llvm.cttz.i129(i129 %7368, i1 false)
  %7370 = trunc i129 %7369 to i32
  store i32 %7370, ptr %7366, align 4
  %7371 = getelementptr inbounds i32, ptr %513, i64 3
  %7372 = load i192, ptr %512, align 8
  %7373 = trunc i192 %7372 to i129
  %7374 = xor i129 %7373, -1
  %7375 = call i129 @llvm.cttz.i129(i129 %7374, i1 false)
  %7376 = trunc i129 %7375 to i32
  store i32 %7376, ptr %7371, align 4
  %7377 = getelementptr inbounds i32, ptr %513, i64 4
  %7378 = load i192, ptr %512, align 8
  %7379 = trunc i192 %7378 to i129
  %7380 = xor i129 %7379, -1
  %7381 = call i129 @llvm.ctlz.i129(i129 %7380, i1 false)
  %7382 = add i129 %7381, 1
  %7383 = icmp eq i129 %7380, 0
  %7384 = select i1 %7383, i129 0, i129 %7382
  %7385 = trunc i129 %7384 to i32
  store i32 %7385, ptr %7377, align 4
  %7386 = getelementptr inbounds i32, ptr %513, i64 5
  %7387 = load i192, ptr %512, align 8
  %7388 = trunc i192 %7387 to i129
  %7389 = call i129 @llvm.ctlz.i129(i129 %7388, i1 false)
  %7390 = add i129 %7389, 1
  %7391 = icmp eq i129 %7388, 0
  %7392 = select i1 %7391, i129 0, i129 %7390
  %7393 = trunc i129 %7392 to i32
  store i32 %7393, ptr %7386, align 4
  %7394 = getelementptr inbounds i32, ptr %513, i64 6
  %7395 = load i192, ptr %512, align 8
  %7396 = trunc i192 %7395 to i129
  %7397 = xor i129 %7396, -1
  %7398 = call i129 @llvm.cttz.i129(i129 %7397, i1 false)
  %7399 = add i129 %7398, 1
  %7400 = icmp eq i129 %7397, 0
  %7401 = select i1 %7400, i129 0, i129 %7399
  %7402 = trunc i129 %7401 to i32
  store i32 %7402, ptr %7394, align 4
  %7403 = getelementptr inbounds i32, ptr %513, i64 7
  %7404 = load i192, ptr %512, align 8
  %7405 = trunc i192 %7404 to i129
  %7406 = call i129 @llvm.cttz.i129(i129 %7405, i1 false)
  %7407 = add i129 %7406, 1
  %7408 = icmp eq i129 %7405, 0
  %7409 = select i1 %7408, i129 0, i129 %7407
  %7410 = trunc i129 %7409 to i32
  store i32 %7410, ptr %7403, align 4
  %7411 = getelementptr inbounds i32, ptr %513, i64 8
  %7412 = load i192, ptr %512, align 8
  %7413 = trunc i192 %7412 to i129
  %7414 = call i129 @llvm.ctpop.i129(i129 %7413)
  %7415 = sub i129 129, %7414
  %7416 = trunc i129 %7415 to i32
  store i32 %7416, ptr %7411, align 4
  %7417 = getelementptr inbounds i32, ptr %513, i64 9
  %7418 = load i192, ptr %512, align 8
  %7419 = trunc i192 %7418 to i129
  %7420 = call i129 @llvm.ctpop.i129(i129 %7419)
  %7421 = trunc i129 %7420 to i32
  store i32 %7421, ptr %7417, align 4
  %7422 = getelementptr inbounds i32, ptr %513, i64 10
  %7423 = load i192, ptr %512, align 8
  %7424 = trunc i192 %7423 to i129
  %7425 = call i129 @llvm.ctpop.i129(i129 %7424)
  %7426 = icmp eq i129 %7425, 1
  %7427 = zext i1 %7426 to i32
  store i32 %7427, ptr %7422, align 4
  %7428 = getelementptr inbounds i32, ptr %513, i64 11
  %7429 = load i192, ptr %512, align 8
  %7430 = trunc i192 %7429 to i129
  %7431 = call i129 @llvm.ctlz.i129(i129 %7430, i1 false)
  %7432 = sub i129 129, %7431
  %7433 = trunc i129 %7432 to i32
  store i32 %7433, ptr %7428, align 4
  %7434 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 0
  %7435 = load i32, ptr %7434, align 16
  %7436 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 1
  %7437 = load i32, ptr %7436, align 4
  %7438 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 2
  %7439 = load i32, ptr %7438, align 8
  %7440 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 3
  %7441 = load i32, ptr %7440, align 4
  %7442 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 4
  %7443 = load i32, ptr %7442, align 16
  %7444 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 5
  %7445 = load i32, ptr %7444, align 4
  %7446 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 6
  %7447 = load i32, ptr %7446, align 8
  %7448 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 7
  %7449 = load i32, ptr %7448, align 4
  %7450 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 8
  %7451 = load i32, ptr %7450, align 16
  %7452 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 9
  %7453 = load i32, ptr %7452, align 4
  %7454 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 10
  %7455 = load i32, ptr %7454, align 8
  %7456 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 11
  %7457 = load i32, ptr %7456, align 4
  %7458 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %7435, i32 noundef %7437, i32 noundef %7439, i32 noundef %7441, i32 noundef %7443, i32 noundef %7445, i32 noundef %7447, i32 noundef %7449, i32 noundef %7451, i32 noundef %7453, i32 noundef %7455, i32 noundef %7457)
  %7459 = load i192, ptr %512, align 8
  %7460 = trunc i192 %7459 to i129
  %7461 = call i129 @llvm.ctlz.i129(i129 %7460, i1 true)
  %7462 = sub i129 128, %7461
  %7463 = shl i129 1, %7462
  %7464 = icmp eq i129 %7460, 0
  %7465 = select i1 %7464, i129 0, i129 %7463
  %7466 = zext i129 %7465 to i192
  store i192 %7466, ptr %514, align 8
  %7467 = load i192, ptr %512, align 8
  %7468 = trunc i192 %7467 to i129
  %7469 = icmp ule i129 %7468, 1
  br i1 %7469, label %7475, label %7470

7470:                                             ; preds = %7355
  %7471 = sub i129 %7468, 1
  %7472 = call i129 @llvm.ctlz.i129(i129 %7471, i1 false)
  %7473 = sub i129 128, %7472
  %7474 = shl i129 2, %7473
  br label %7475

7475:                                             ; preds = %7470, %7355
  %7476 = phi i129 [ 1, %7355 ], [ %7474, %7470 ]
  %7477 = zext i129 %7476 to i192
  store i192 %7477, ptr %515, align 8
  %7478 = load i192, ptr %512, align 8
  %7479 = trunc i192 %7478 to i129
  %7480 = call i129 @llvm.fshl.i129(i129 %7479, i129 %7479, i129 3)
  %7481 = zext i129 %7480 to i192
  store i192 %7481, ptr %516, align 8
  %7482 = load i192, ptr %512, align 8
  %7483 = trunc i192 %7482 to i129
  %7484 = call i129 @llvm.fshr.i129(i129 %7483, i129 %7483, i129 3)
  %7485 = zext i129 %7484 to i192
  store i192 %7485, ptr %517, align 8
  %7486 = load i192, ptr %512, align 8
  %7487 = trunc i192 %7486 to i129
  %7488 = call i129 @llvm.fshl.i129(i129 %7487, i129 %7487, i129 0)
  %7489 = zext i129 %7488 to i192
  store i192 %7489, ptr %518, align 8
  %7490 = load i192, ptr %512, align 8
  %7491 = trunc i192 %7490 to i129
  %7492 = call i129 @llvm.fshl.i129(i129 %7491, i129 %7491, i129 97)
  %7493 = zext i129 %7492 to i192
  store i192 %7493, ptr %519, align 8
  %7494 = load i192, ptr %514, align 8
  %7495 = trunc i192 %7494 to i129
  %7496 = zext i129 %7495 to i256
  %7497 = lshr i256 %7496, 128
  %7498 = trunc i256 %7497 to i64
  %7499 = load i192, ptr %514, align 8
  %7500 = trunc i192 %7499 to i129
  %7501 = zext i129 %7500 to i256
  %7502 = lshr i256 %7501, 64
  %7503 = trunc i256 %7502 to i64
  %7504 = load i192, ptr %514, align 8
  %7505 = trunc i192 %7504 to i129
  %7506 = trunc i129 %7505 to i64
  %7507 = load i192, ptr %515, align 8
  %7508 = trunc i192 %7507 to i129
  %7509 = zext i129 %7508 to i256
  %7510 = lshr i256 %7509, 128
  %7511 = trunc i256 %7510 to i64
  %7512 = load i192, ptr %515, align 8
  %7513 = trunc i192 %7512 to i129
  %7514 = zext i129 %7513 to i256
  %7515 = lshr i256 %7514, 64
  %7516 = trunc i256 %7515 to i64
  %7517 = load i192, ptr %515, align 8
  %7518 = trunc i192 %7517 to i129
  %7519 = trunc i129 %7518 to i64
  %7520 = load i192, ptr %516, align 8
  %7521 = trunc i192 %7520 to i129
  %7522 = zext i129 %7521 to i256
  %7523 = lshr i256 %7522, 128
  %7524 = trunc i256 %7523 to i64
  %7525 = load i192, ptr %516, align 8
  %7526 = trunc i192 %7525 to i129
  %7527 = zext i129 %7526 to i256
  %7528 = lshr i256 %7527, 64
  %7529 = trunc i256 %7528 to i64
  %7530 = load i192, ptr %516, align 8
  %7531 = trunc i192 %7530 to i129
  %7532 = trunc i129 %7531 to i64
  %7533 = load i192, ptr %517, align 8
  %7534 = trunc i192 %7533 to i129
  %7535 = zext i129 %7534 to i256
  %7536 = lshr i256 %7535, 128
  %7537 = trunc i256 %7536 to i64
  %7538 = load i192, ptr %517, align 8
  %7539 = trunc i192 %7538 to i129
  %7540 = zext i129 %7539 to i256
  %7541 = lshr i256 %7540, 64
  %7542 = trunc i256 %7541 to i64
  %7543 = load i192, ptr %517, align 8
  %7544 = trunc i192 %7543 to i129
  %7545 = trunc i129 %7544 to i64
  %7546 = load i192, ptr %518, align 8
  %7547 = trunc i192 %7546 to i129
  %7548 = trunc i129 %7547 to i64
  %7549 = load i192, ptr %519, align 8
  %7550 = trunc i192 %7549 to i129
  %7551 = trunc i129 %7550 to i64
  %7552 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %7498, i64 noundef %7503, i64 noundef %7506, i64 noundef %7511, i64 noundef %7516, i64 noundef %7519, i64 noundef %7524, i64 noundef %7529, i64 noundef %7532, i64 noundef %7537, i64 noundef %7542, i64 noundef %7545, i64 noundef %7548, i64 noundef %7551)
  %7553 = load i192, ptr %512, align 8
  %7554 = trunc i192 %7553 to i129
  %7555 = zext i129 %7554 to i575
  %7556 = getelementptr inbounds [12 x i32], ptr %513, i64 0, i64 0
  %7557 = load i192, ptr %514, align 8
  %7558 = trunc i192 %7557 to i129
  %7559 = zext i129 %7558 to i575
  %7560 = load i192, ptr %515, align 8
  %7561 = trunc i192 %7560 to i129
  %7562 = zext i129 %7561 to i575
  %7563 = load i192, ptr %516, align 8
  %7564 = trunc i192 %7563 to i129
  %7565 = zext i129 %7564 to i575
  %7566 = load i192, ptr %517, align 8
  %7567 = trunc i192 %7566 to i129
  %7568 = zext i129 %7567 to i575
  %7569 = load i192, ptr %518, align 8
  %7570 = trunc i192 %7569 to i129
  %7571 = zext i129 %7570 to i575
  %7572 = load i192, ptr %519, align 8
  %7573 = trunc i192 %7572 to i129
  %7574 = zext i129 %7573 to i575
  %7575 = zext i575 %7555 to i576
  store i576 %7575, ptr %520, align 8
  %7576 = zext i575 %7559 to i576
  store i576 %7576, ptr %521, align 8
  %7577 = zext i575 %7562 to i576
  store i576 %7577, ptr %522, align 8
  %7578 = zext i575 %7565 to i576
  store i576 %7578, ptr %523, align 8
  %7579 = zext i575 %7568 to i576
  store i576 %7579, ptr %524, align 8
  %7580 = zext i575 %7571 to i576
  store i576 %7580, ptr %525, align 8
  %7581 = zext i575 %7574 to i576
  store i576 %7581, ptr %526, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %520, ptr noundef %7556, ptr noundef byval([72 x i8]) align 8 %521, ptr noundef byval([72 x i8]) align 8 %522, ptr noundef byval([72 x i8]) align 8 %523, ptr noundef byval([72 x i8]) align 8 %524, ptr noundef byval([72 x i8]) align 8 %525, ptr noundef byval([72 x i8]) align 8 %526)
  br label %7582

7582:                                             ; preds = %7475
  br label %7583

7583:                                             ; preds = %7582
  store i256 80, ptr %527, align 8
  %7584 = load i256, ptr %527, align 8
  %7585 = call i256 @llvm.ctlz.i256(i256 %7584, i1 false)
  %7586 = trunc i256 %7585 to i32
  store i32 %7586, ptr %528, align 4
  %7587 = getelementptr inbounds i32, ptr %528, i64 1
  %7588 = load i256, ptr %527, align 8
  %7589 = xor i256 %7588, -1
  %7590 = call i256 @llvm.ctlz.i256(i256 %7589, i1 false)
  %7591 = trunc i256 %7590 to i32
  store i32 %7591, ptr %7587, align 4
  %7592 = getelementptr inbounds i32, ptr %528, i64 2
  %7593 = load i256, ptr %527, align 8
  %7594 = call i256 @llvm.cttz.i256(i256 %7593, i1 false)
  %7595 = trunc i256 %7594 to i32
  store i32 %7595, ptr %7592, align 4
  %7596 = getelementptr inbounds i32, ptr %528, i64 3
  %7597 = load i256, ptr %527, align 8
  %7598 = xor i256 %7597, -1
  %7599 = call i256 @llvm.cttz.i256(i256 %7598, i1 false)
  %7600 = trunc i256 %7599 to i32
  store i32 %7600, ptr %7596, align 4
  %7601 = getelementptr inbounds i32, ptr %528, i64 4
  %7602 = load i256, ptr %527, align 8
  %7603 = xor i256 %7602, -1
  %7604 = call i256 @llvm.ctlz.i256(i256 %7603, i1 false)
  %7605 = add i256 %7604, 1
  %7606 = icmp eq i256 %7603, 0
  %7607 = select i1 %7606, i256 0, i256 %7605
  %7608 = trunc i256 %7607 to i32
  store i32 %7608, ptr %7601, align 4
  %7609 = getelementptr inbounds i32, ptr %528, i64 5
  %7610 = load i256, ptr %527, align 8
  %7611 = call i256 @llvm.ctlz.i256(i256 %7610, i1 false)
  %7612 = add i256 %7611, 1
  %7613 = icmp eq i256 %7610, 0
  %7614 = select i1 %7613, i256 0, i256 %7612
  %7615 = trunc i256 %7614 to i32
  store i32 %7615, ptr %7609, align 4
  %7616 = getelementptr inbounds i32, ptr %528, i64 6
  %7617 = load i256, ptr %527, align 8
  %7618 = xor i256 %7617, -1
  %7619 = call i256 @llvm.cttz.i256(i256 %7618, i1 false)
  %7620 = add i256 %7619, 1
  %7621 = icmp eq i256 %7618, 0
  %7622 = select i1 %7621, i256 0, i256 %7620
  %7623 = trunc i256 %7622 to i32
  store i32 %7623, ptr %7616, align 4
  %7624 = getelementptr inbounds i32, ptr %528, i64 7
  %7625 = load i256, ptr %527, align 8
  %7626 = call i256 @llvm.cttz.i256(i256 %7625, i1 false)
  %7627 = add i256 %7626, 1
  %7628 = icmp eq i256 %7625, 0
  %7629 = select i1 %7628, i256 0, i256 %7627
  %7630 = trunc i256 %7629 to i32
  store i32 %7630, ptr %7624, align 4
  %7631 = getelementptr inbounds i32, ptr %528, i64 8
  %7632 = load i256, ptr %527, align 8
  %7633 = call i256 @llvm.ctpop.i256(i256 %7632)
  %7634 = sub i256 256, %7633
  %7635 = trunc i256 %7634 to i32
  store i32 %7635, ptr %7631, align 4
  %7636 = getelementptr inbounds i32, ptr %528, i64 9
  %7637 = load i256, ptr %527, align 8
  %7638 = call i256 @llvm.ctpop.i256(i256 %7637)
  %7639 = trunc i256 %7638 to i32
  store i32 %7639, ptr %7636, align 4
  %7640 = getelementptr inbounds i32, ptr %528, i64 10
  %7641 = load i256, ptr %527, align 8
  %7642 = call i256 @llvm.ctpop.i256(i256 %7641)
  %7643 = icmp eq i256 %7642, 1
  %7644 = zext i1 %7643 to i32
  store i32 %7644, ptr %7640, align 4
  %7645 = getelementptr inbounds i32, ptr %528, i64 11
  %7646 = load i256, ptr %527, align 8
  %7647 = call i256 @llvm.ctlz.i256(i256 %7646, i1 false)
  %7648 = sub i256 256, %7647
  %7649 = trunc i256 %7648 to i32
  store i32 %7649, ptr %7645, align 4
  %7650 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 0
  %7651 = load i32, ptr %7650, align 16
  %7652 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 1
  %7653 = load i32, ptr %7652, align 4
  %7654 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 2
  %7655 = load i32, ptr %7654, align 8
  %7656 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 3
  %7657 = load i32, ptr %7656, align 4
  %7658 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 4
  %7659 = load i32, ptr %7658, align 16
  %7660 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 5
  %7661 = load i32, ptr %7660, align 4
  %7662 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 6
  %7663 = load i32, ptr %7662, align 8
  %7664 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 7
  %7665 = load i32, ptr %7664, align 4
  %7666 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 8
  %7667 = load i32, ptr %7666, align 16
  %7668 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 9
  %7669 = load i32, ptr %7668, align 4
  %7670 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 10
  %7671 = load i32, ptr %7670, align 8
  %7672 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 11
  %7673 = load i32, ptr %7672, align 4
  %7674 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %7651, i32 noundef %7653, i32 noundef %7655, i32 noundef %7657, i32 noundef %7659, i32 noundef %7661, i32 noundef %7663, i32 noundef %7665, i32 noundef %7667, i32 noundef %7669, i32 noundef %7671, i32 noundef %7673)
  %7675 = load i256, ptr %527, align 8
  %7676 = call i256 @llvm.ctlz.i256(i256 %7675, i1 true)
  %7677 = sub i256 255, %7676
  %7678 = shl i256 1, %7677
  %7679 = icmp eq i256 %7675, 0
  %7680 = select i1 %7679, i256 0, i256 %7678
  store i256 %7680, ptr %529, align 8
  %7681 = load i256, ptr %527, align 8
  %7682 = icmp ule i256 %7681, 1
  br i1 %7682, label %7688, label %7683

7683:                                             ; preds = %7583
  %7684 = sub i256 %7681, 1
  %7685 = call i256 @llvm.ctlz.i256(i256 %7684, i1 false)
  %7686 = sub i256 255, %7685
  %7687 = shl i256 2, %7686
  br label %7688

7688:                                             ; preds = %7683, %7583
  %7689 = phi i256 [ 1, %7583 ], [ %7687, %7683 ]
  store i256 %7689, ptr %530, align 8
  %7690 = load i256, ptr %527, align 8
  %7691 = call i256 @llvm.fshl.i256(i256 %7690, i256 %7690, i256 3)
  store i256 %7691, ptr %531, align 8
  %7692 = load i256, ptr %527, align 8
  %7693 = call i256 @llvm.fshr.i256(i256 %7692, i256 %7692, i256 3)
  store i256 %7693, ptr %532, align 8
  %7694 = load i256, ptr %527, align 8
  %7695 = call i256 @llvm.fshl.i256(i256 %7694, i256 %7694, i256 0)
  store i256 %7695, ptr %533, align 8
  %7696 = load i256, ptr %527, align 8
  %7697 = call i256 @llvm.fshl.i256(i256 %7696, i256 %7696, i256 232)
  store i256 %7697, ptr %534, align 8
  %7698 = load i256, ptr %529, align 8
  %7699 = lshr i256 %7698, 128
  %7700 = trunc i256 %7699 to i64
  %7701 = load i256, ptr %529, align 8
  %7702 = lshr i256 %7701, 64
  %7703 = trunc i256 %7702 to i64
  %7704 = load i256, ptr %529, align 8
  %7705 = trunc i256 %7704 to i64
  %7706 = load i256, ptr %530, align 8
  %7707 = lshr i256 %7706, 128
  %7708 = trunc i256 %7707 to i64
  %7709 = load i256, ptr %530, align 8
  %7710 = lshr i256 %7709, 64
  %7711 = trunc i256 %7710 to i64
  %7712 = load i256, ptr %530, align 8
  %7713 = trunc i256 %7712 to i64
  %7714 = load i256, ptr %531, align 8
  %7715 = lshr i256 %7714, 128
  %7716 = trunc i256 %7715 to i64
  %7717 = load i256, ptr %531, align 8
  %7718 = lshr i256 %7717, 64
  %7719 = trunc i256 %7718 to i64
  %7720 = load i256, ptr %531, align 8
  %7721 = trunc i256 %7720 to i64
  %7722 = load i256, ptr %532, align 8
  %7723 = lshr i256 %7722, 128
  %7724 = trunc i256 %7723 to i64
  %7725 = load i256, ptr %532, align 8
  %7726 = lshr i256 %7725, 64
  %7727 = trunc i256 %7726 to i64
  %7728 = load i256, ptr %532, align 8
  %7729 = trunc i256 %7728 to i64
  %7730 = load i256, ptr %533, align 8
  %7731 = trunc i256 %7730 to i64
  %7732 = load i256, ptr %534, align 8
  %7733 = trunc i256 %7732 to i64
  %7734 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %7700, i64 noundef %7703, i64 noundef %7705, i64 noundef %7708, i64 noundef %7711, i64 noundef %7713, i64 noundef %7716, i64 noundef %7719, i64 noundef %7721, i64 noundef %7724, i64 noundef %7727, i64 noundef %7729, i64 noundef %7731, i64 noundef %7733)
  %7735 = load i256, ptr %527, align 8
  %7736 = zext i256 %7735 to i575
  %7737 = getelementptr inbounds [12 x i32], ptr %528, i64 0, i64 0
  %7738 = load i256, ptr %529, align 8
  %7739 = zext i256 %7738 to i575
  %7740 = load i256, ptr %530, align 8
  %7741 = zext i256 %7740 to i575
  %7742 = load i256, ptr %531, align 8
  %7743 = zext i256 %7742 to i575
  %7744 = load i256, ptr %532, align 8
  %7745 = zext i256 %7744 to i575
  %7746 = load i256, ptr %533, align 8
  %7747 = zext i256 %7746 to i575
  %7748 = load i256, ptr %534, align 8
  %7749 = zext i256 %7748 to i575
  %7750 = zext i575 %7736 to i576
  store i576 %7750, ptr %535, align 8
  %7751 = zext i575 %7739 to i576
  store i576 %7751, ptr %536, align 8
  %7752 = zext i575 %7741 to i576
  store i576 %7752, ptr %537, align 8
  %7753 = zext i575 %7743 to i576
  store i576 %7753, ptr %538, align 8
  %7754 = zext i575 %7745 to i576
  store i576 %7754, ptr %539, align 8
  %7755 = zext i575 %7747 to i576
  store i576 %7755, ptr %540, align 8
  %7756 = zext i575 %7749 to i576
  store i576 %7756, ptr %541, align 8
  call void @check(ptr noundef @.str.11, i32 noundef 256, ptr noundef byval([72 x i8]) align 8 %535, ptr noundef %7737, ptr noundef byval([72 x i8]) align 8 %536, ptr noundef byval([72 x i8]) align 8 %537, ptr noundef byval([72 x i8]) align 8 %538, ptr noundef byval([72 x i8]) align 8 %539, ptr noundef byval([72 x i8]) align 8 %540, ptr noundef byval([72 x i8]) align 8 %541)
  br label %7757

7757:                                             ; preds = %7688
  %7758 = call i32 @puts(ptr noundef @.str.15)
  br label %7759

7759:                                             ; preds = %7757
  store i8 5, ptr %542, align 1
  %7760 = load i8, ptr %542, align 1
  %7761 = call i8 @llvm.ctlz.i8(i8 %7760, i1 false)
  %7762 = zext i8 %7761 to i32
  store i32 %7762, ptr %543, align 4
  %7763 = getelementptr inbounds i32, ptr %543, i64 1
  %7764 = load i8, ptr %542, align 1
  %7765 = xor i8 %7764, -1
  %7766 = call i8 @llvm.ctlz.i8(i8 %7765, i1 false)
  %7767 = zext i8 %7766 to i32
  store i32 %7767, ptr %7763, align 4
  %7768 = getelementptr inbounds i32, ptr %543, i64 2
  %7769 = load i8, ptr %542, align 1
  %7770 = call i8 @llvm.cttz.i8(i8 %7769, i1 false)
  %7771 = zext i8 %7770 to i32
  store i32 %7771, ptr %7768, align 4
  %7772 = getelementptr inbounds i32, ptr %543, i64 3
  %7773 = load i8, ptr %542, align 1
  %7774 = xor i8 %7773, -1
  %7775 = call i8 @llvm.cttz.i8(i8 %7774, i1 false)
  %7776 = zext i8 %7775 to i32
  store i32 %7776, ptr %7772, align 4
  %7777 = getelementptr inbounds i32, ptr %543, i64 4
  %7778 = load i8, ptr %542, align 1
  %7779 = xor i8 %7778, -1
  %7780 = call i8 @llvm.ctlz.i8(i8 %7779, i1 false)
  %7781 = add i8 %7780, 1
  %7782 = icmp eq i8 %7779, 0
  %7783 = select i1 %7782, i8 0, i8 %7781
  %7784 = zext i8 %7783 to i32
  store i32 %7784, ptr %7777, align 4
  %7785 = getelementptr inbounds i32, ptr %543, i64 5
  %7786 = load i8, ptr %542, align 1
  %7787 = call i8 @llvm.ctlz.i8(i8 %7786, i1 false)
  %7788 = add i8 %7787, 1
  %7789 = icmp eq i8 %7786, 0
  %7790 = select i1 %7789, i8 0, i8 %7788
  %7791 = zext i8 %7790 to i32
  store i32 %7791, ptr %7785, align 4
  %7792 = getelementptr inbounds i32, ptr %543, i64 6
  %7793 = load i8, ptr %542, align 1
  %7794 = xor i8 %7793, -1
  %7795 = call i8 @llvm.cttz.i8(i8 %7794, i1 false)
  %7796 = add i8 %7795, 1
  %7797 = icmp eq i8 %7794, 0
  %7798 = select i1 %7797, i8 0, i8 %7796
  %7799 = zext i8 %7798 to i32
  store i32 %7799, ptr %7792, align 4
  %7800 = getelementptr inbounds i32, ptr %543, i64 7
  %7801 = load i8, ptr %542, align 1
  %7802 = call i8 @llvm.cttz.i8(i8 %7801, i1 false)
  %7803 = add i8 %7802, 1
  %7804 = icmp eq i8 %7801, 0
  %7805 = select i1 %7804, i8 0, i8 %7803
  %7806 = zext i8 %7805 to i32
  store i32 %7806, ptr %7800, align 4
  %7807 = getelementptr inbounds i32, ptr %543, i64 8
  %7808 = load i8, ptr %542, align 1
  %7809 = call i8 @llvm.ctpop.i8(i8 %7808)
  %7810 = sub i8 8, %7809
  %7811 = zext i8 %7810 to i32
  store i32 %7811, ptr %7807, align 4
  %7812 = getelementptr inbounds i32, ptr %543, i64 9
  %7813 = load i8, ptr %542, align 1
  %7814 = call i8 @llvm.ctpop.i8(i8 %7813)
  %7815 = zext i8 %7814 to i32
  store i32 %7815, ptr %7812, align 4
  %7816 = getelementptr inbounds i32, ptr %543, i64 10
  %7817 = load i8, ptr %542, align 1
  %7818 = call i8 @llvm.ctpop.i8(i8 %7817)
  %7819 = icmp eq i8 %7818, 1
  %7820 = zext i1 %7819 to i32
  store i32 %7820, ptr %7816, align 4
  %7821 = getelementptr inbounds i32, ptr %543, i64 11
  %7822 = load i8, ptr %542, align 1
  %7823 = call i8 @llvm.ctlz.i8(i8 %7822, i1 false)
  %7824 = sub i8 8, %7823
  %7825 = zext i8 %7824 to i32
  store i32 %7825, ptr %7821, align 4
  %7826 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 0
  %7827 = load i32, ptr %7826, align 16
  %7828 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 1
  %7829 = load i32, ptr %7828, align 4
  %7830 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 2
  %7831 = load i32, ptr %7830, align 8
  %7832 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 3
  %7833 = load i32, ptr %7832, align 4
  %7834 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 4
  %7835 = load i32, ptr %7834, align 16
  %7836 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 5
  %7837 = load i32, ptr %7836, align 4
  %7838 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 6
  %7839 = load i32, ptr %7838, align 8
  %7840 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 7
  %7841 = load i32, ptr %7840, align 4
  %7842 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 8
  %7843 = load i32, ptr %7842, align 16
  %7844 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 9
  %7845 = load i32, ptr %7844, align 4
  %7846 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 10
  %7847 = load i32, ptr %7846, align 8
  %7848 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 11
  %7849 = load i32, ptr %7848, align 4
  %7850 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %7827, i32 noundef %7829, i32 noundef %7831, i32 noundef %7833, i32 noundef %7835, i32 noundef %7837, i32 noundef %7839, i32 noundef %7841, i32 noundef %7843, i32 noundef %7845, i32 noundef %7847, i32 noundef %7849)
  %7851 = load i8, ptr %542, align 1
  %7852 = call i8 @llvm.ctlz.i8(i8 %7851, i1 true)
  %7853 = sub i8 7, %7852
  %7854 = shl i8 1, %7853
  %7855 = icmp eq i8 %7851, 0
  %7856 = select i1 %7855, i8 0, i8 %7854
  store i8 %7856, ptr %544, align 1
  %7857 = load i8, ptr %542, align 1
  %7858 = icmp ule i8 %7857, 1
  br i1 %7858, label %7864, label %7859

7859:                                             ; preds = %7759
  %7860 = sub i8 %7857, 1
  %7861 = call i8 @llvm.ctlz.i8(i8 %7860, i1 false)
  %7862 = sub i8 7, %7861
  %7863 = shl i8 2, %7862
  br label %7864

7864:                                             ; preds = %7859, %7759
  %7865 = phi i8 [ 1, %7759 ], [ %7863, %7859 ]
  store i8 %7865, ptr %545, align 1
  %7866 = load i8, ptr %542, align 1
  %7867 = call i8 @llvm.fshl.i8(i8 %7866, i8 %7866, i8 3)
  store i8 %7867, ptr %546, align 1
  %7868 = load i8, ptr %542, align 1
  %7869 = call i8 @llvm.fshr.i8(i8 %7868, i8 %7868, i8 3)
  store i8 %7869, ptr %547, align 1
  %7870 = load i8, ptr %542, align 1
  %7871 = call i8 @llvm.fshl.i8(i8 %7870, i8 %7870, i8 0)
  store i8 %7871, ptr %548, align 1
  %7872 = load i8, ptr %542, align 1
  %7873 = call i8 @llvm.fshl.i8(i8 %7872, i8 %7872, i8 0)
  store i8 %7873, ptr %549, align 1
  %7874 = load i8, ptr %544, align 1
  %7875 = zext i8 %7874 to i256
  %7876 = lshr i256 %7875, 128
  %7877 = trunc i256 %7876 to i64
  %7878 = load i8, ptr %544, align 1
  %7879 = zext i8 %7878 to i256
  %7880 = lshr i256 %7879, 64
  %7881 = trunc i256 %7880 to i64
  %7882 = load i8, ptr %544, align 1
  %7883 = zext i8 %7882 to i64
  %7884 = load i8, ptr %545, align 1
  %7885 = zext i8 %7884 to i256
  %7886 = lshr i256 %7885, 128
  %7887 = trunc i256 %7886 to i64
  %7888 = load i8, ptr %545, align 1
  %7889 = zext i8 %7888 to i256
  %7890 = lshr i256 %7889, 64
  %7891 = trunc i256 %7890 to i64
  %7892 = load i8, ptr %545, align 1
  %7893 = zext i8 %7892 to i64
  %7894 = load i8, ptr %546, align 1
  %7895 = zext i8 %7894 to i256
  %7896 = lshr i256 %7895, 128
  %7897 = trunc i256 %7896 to i64
  %7898 = load i8, ptr %546, align 1
  %7899 = zext i8 %7898 to i256
  %7900 = lshr i256 %7899, 64
  %7901 = trunc i256 %7900 to i64
  %7902 = load i8, ptr %546, align 1
  %7903 = zext i8 %7902 to i64
  %7904 = load i8, ptr %547, align 1
  %7905 = zext i8 %7904 to i256
  %7906 = lshr i256 %7905, 128
  %7907 = trunc i256 %7906 to i64
  %7908 = load i8, ptr %547, align 1
  %7909 = zext i8 %7908 to i256
  %7910 = lshr i256 %7909, 64
  %7911 = trunc i256 %7910 to i64
  %7912 = load i8, ptr %547, align 1
  %7913 = zext i8 %7912 to i64
  %7914 = load i8, ptr %548, align 1
  %7915 = zext i8 %7914 to i64
  %7916 = load i8, ptr %549, align 1
  %7917 = zext i8 %7916 to i64
  %7918 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %7877, i64 noundef %7881, i64 noundef %7883, i64 noundef %7887, i64 noundef %7891, i64 noundef %7893, i64 noundef %7897, i64 noundef %7901, i64 noundef %7903, i64 noundef %7907, i64 noundef %7911, i64 noundef %7913, i64 noundef %7915, i64 noundef %7917)
  %7919 = load i8, ptr %542, align 1
  %7920 = zext i8 %7919 to i575
  %7921 = getelementptr inbounds [12 x i32], ptr %543, i64 0, i64 0
  %7922 = load i8, ptr %544, align 1
  %7923 = zext i8 %7922 to i575
  %7924 = load i8, ptr %545, align 1
  %7925 = zext i8 %7924 to i575
  %7926 = load i8, ptr %546, align 1
  %7927 = zext i8 %7926 to i575
  %7928 = load i8, ptr %547, align 1
  %7929 = zext i8 %7928 to i575
  %7930 = load i8, ptr %548, align 1
  %7931 = zext i8 %7930 to i575
  %7932 = load i8, ptr %549, align 1
  %7933 = zext i8 %7932 to i575
  %7934 = zext i575 %7920 to i576
  store i576 %7934, ptr %550, align 8
  %7935 = zext i575 %7923 to i576
  store i576 %7935, ptr %551, align 8
  %7936 = zext i575 %7925 to i576
  store i576 %7936, ptr %552, align 8
  %7937 = zext i575 %7927 to i576
  store i576 %7937, ptr %553, align 8
  %7938 = zext i575 %7929 to i576
  store i576 %7938, ptr %554, align 8
  %7939 = zext i575 %7931 to i576
  store i576 %7939, ptr %555, align 8
  %7940 = zext i575 %7933 to i576
  store i576 %7940, ptr %556, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %550, ptr noundef %7921, ptr noundef byval([72 x i8]) align 8 %551, ptr noundef byval([72 x i8]) align 8 %552, ptr noundef byval([72 x i8]) align 8 %553, ptr noundef byval([72 x i8]) align 8 %554, ptr noundef byval([72 x i8]) align 8 %555, ptr noundef byval([72 x i8]) align 8 %556)
  br label %7941

7941:                                             ; preds = %7864
  br label %7942

7942:                                             ; preds = %7941
  store i16 5, ptr %557, align 2
  %7943 = load i16, ptr %557, align 2
  %7944 = call i16 @llvm.ctlz.i16(i16 %7943, i1 false)
  %7945 = zext i16 %7944 to i32
  store i32 %7945, ptr %558, align 4
  %7946 = getelementptr inbounds i32, ptr %558, i64 1
  %7947 = load i16, ptr %557, align 2
  %7948 = xor i16 %7947, -1
  %7949 = call i16 @llvm.ctlz.i16(i16 %7948, i1 false)
  %7950 = zext i16 %7949 to i32
  store i32 %7950, ptr %7946, align 4
  %7951 = getelementptr inbounds i32, ptr %558, i64 2
  %7952 = load i16, ptr %557, align 2
  %7953 = call i16 @llvm.cttz.i16(i16 %7952, i1 false)
  %7954 = zext i16 %7953 to i32
  store i32 %7954, ptr %7951, align 4
  %7955 = getelementptr inbounds i32, ptr %558, i64 3
  %7956 = load i16, ptr %557, align 2
  %7957 = xor i16 %7956, -1
  %7958 = call i16 @llvm.cttz.i16(i16 %7957, i1 false)
  %7959 = zext i16 %7958 to i32
  store i32 %7959, ptr %7955, align 4
  %7960 = getelementptr inbounds i32, ptr %558, i64 4
  %7961 = load i16, ptr %557, align 2
  %7962 = xor i16 %7961, -1
  %7963 = call i16 @llvm.ctlz.i16(i16 %7962, i1 false)
  %7964 = add i16 %7963, 1
  %7965 = icmp eq i16 %7962, 0
  %7966 = select i1 %7965, i16 0, i16 %7964
  %7967 = zext i16 %7966 to i32
  store i32 %7967, ptr %7960, align 4
  %7968 = getelementptr inbounds i32, ptr %558, i64 5
  %7969 = load i16, ptr %557, align 2
  %7970 = call i16 @llvm.ctlz.i16(i16 %7969, i1 false)
  %7971 = add i16 %7970, 1
  %7972 = icmp eq i16 %7969, 0
  %7973 = select i1 %7972, i16 0, i16 %7971
  %7974 = zext i16 %7973 to i32
  store i32 %7974, ptr %7968, align 4
  %7975 = getelementptr inbounds i32, ptr %558, i64 6
  %7976 = load i16, ptr %557, align 2
  %7977 = xor i16 %7976, -1
  %7978 = call i16 @llvm.cttz.i16(i16 %7977, i1 false)
  %7979 = add i16 %7978, 1
  %7980 = icmp eq i16 %7977, 0
  %7981 = select i1 %7980, i16 0, i16 %7979
  %7982 = zext i16 %7981 to i32
  store i32 %7982, ptr %7975, align 4
  %7983 = getelementptr inbounds i32, ptr %558, i64 7
  %7984 = load i16, ptr %557, align 2
  %7985 = call i16 @llvm.cttz.i16(i16 %7984, i1 false)
  %7986 = add i16 %7985, 1
  %7987 = icmp eq i16 %7984, 0
  %7988 = select i1 %7987, i16 0, i16 %7986
  %7989 = zext i16 %7988 to i32
  store i32 %7989, ptr %7983, align 4
  %7990 = getelementptr inbounds i32, ptr %558, i64 8
  %7991 = load i16, ptr %557, align 2
  %7992 = call i16 @llvm.ctpop.i16(i16 %7991)
  %7993 = sub i16 16, %7992
  %7994 = zext i16 %7993 to i32
  store i32 %7994, ptr %7990, align 4
  %7995 = getelementptr inbounds i32, ptr %558, i64 9
  %7996 = load i16, ptr %557, align 2
  %7997 = call i16 @llvm.ctpop.i16(i16 %7996)
  %7998 = zext i16 %7997 to i32
  store i32 %7998, ptr %7995, align 4
  %7999 = getelementptr inbounds i32, ptr %558, i64 10
  %8000 = load i16, ptr %557, align 2
  %8001 = call i16 @llvm.ctpop.i16(i16 %8000)
  %8002 = icmp eq i16 %8001, 1
  %8003 = zext i1 %8002 to i32
  store i32 %8003, ptr %7999, align 4
  %8004 = getelementptr inbounds i32, ptr %558, i64 11
  %8005 = load i16, ptr %557, align 2
  %8006 = call i16 @llvm.ctlz.i16(i16 %8005, i1 false)
  %8007 = sub i16 16, %8006
  %8008 = zext i16 %8007 to i32
  store i32 %8008, ptr %8004, align 4
  %8009 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 0
  %8010 = load i32, ptr %8009, align 16
  %8011 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 1
  %8012 = load i32, ptr %8011, align 4
  %8013 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 2
  %8014 = load i32, ptr %8013, align 8
  %8015 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 3
  %8016 = load i32, ptr %8015, align 4
  %8017 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 4
  %8018 = load i32, ptr %8017, align 16
  %8019 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 5
  %8020 = load i32, ptr %8019, align 4
  %8021 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 6
  %8022 = load i32, ptr %8021, align 8
  %8023 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 7
  %8024 = load i32, ptr %8023, align 4
  %8025 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 8
  %8026 = load i32, ptr %8025, align 16
  %8027 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 9
  %8028 = load i32, ptr %8027, align 4
  %8029 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 10
  %8030 = load i32, ptr %8029, align 8
  %8031 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 11
  %8032 = load i32, ptr %8031, align 4
  %8033 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef %8010, i32 noundef %8012, i32 noundef %8014, i32 noundef %8016, i32 noundef %8018, i32 noundef %8020, i32 noundef %8022, i32 noundef %8024, i32 noundef %8026, i32 noundef %8028, i32 noundef %8030, i32 noundef %8032)
  %8034 = load i16, ptr %557, align 2
  %8035 = call i16 @llvm.ctlz.i16(i16 %8034, i1 true)
  %8036 = sub i16 15, %8035
  %8037 = shl i16 1, %8036
  %8038 = icmp eq i16 %8034, 0
  %8039 = select i1 %8038, i16 0, i16 %8037
  store i16 %8039, ptr %559, align 2
  %8040 = load i16, ptr %557, align 2
  %8041 = icmp ule i16 %8040, 1
  br i1 %8041, label %8047, label %8042

8042:                                             ; preds = %7942
  %8043 = sub i16 %8040, 1
  %8044 = call i16 @llvm.ctlz.i16(i16 %8043, i1 false)
  %8045 = sub i16 15, %8044
  %8046 = shl i16 2, %8045
  br label %8047

8047:                                             ; preds = %8042, %7942
  %8048 = phi i16 [ 1, %7942 ], [ %8046, %8042 ]
  store i16 %8048, ptr %560, align 2
  %8049 = load i16, ptr %557, align 2
  %8050 = call i16 @llvm.fshl.i16(i16 %8049, i16 %8049, i16 3)
  store i16 %8050, ptr %561, align 2
  %8051 = load i16, ptr %557, align 2
  %8052 = call i16 @llvm.fshr.i16(i16 %8051, i16 %8051, i16 3)
  store i16 %8052, ptr %562, align 2
  %8053 = load i16, ptr %557, align 2
  %8054 = call i16 @llvm.fshl.i16(i16 %8053, i16 %8053, i16 0)
  store i16 %8054, ptr %563, align 2
  %8055 = load i16, ptr %557, align 2
  %8056 = call i16 @llvm.fshl.i16(i16 %8055, i16 %8055, i16 8)
  store i16 %8056, ptr %564, align 2
  %8057 = load i16, ptr %559, align 2
  %8058 = zext i16 %8057 to i256
  %8059 = lshr i256 %8058, 128
  %8060 = trunc i256 %8059 to i64
  %8061 = load i16, ptr %559, align 2
  %8062 = zext i16 %8061 to i256
  %8063 = lshr i256 %8062, 64
  %8064 = trunc i256 %8063 to i64
  %8065 = load i16, ptr %559, align 2
  %8066 = zext i16 %8065 to i64
  %8067 = load i16, ptr %560, align 2
  %8068 = zext i16 %8067 to i256
  %8069 = lshr i256 %8068, 128
  %8070 = trunc i256 %8069 to i64
  %8071 = load i16, ptr %560, align 2
  %8072 = zext i16 %8071 to i256
  %8073 = lshr i256 %8072, 64
  %8074 = trunc i256 %8073 to i64
  %8075 = load i16, ptr %560, align 2
  %8076 = zext i16 %8075 to i64
  %8077 = load i16, ptr %561, align 2
  %8078 = zext i16 %8077 to i256
  %8079 = lshr i256 %8078, 128
  %8080 = trunc i256 %8079 to i64
  %8081 = load i16, ptr %561, align 2
  %8082 = zext i16 %8081 to i256
  %8083 = lshr i256 %8082, 64
  %8084 = trunc i256 %8083 to i64
  %8085 = load i16, ptr %561, align 2
  %8086 = zext i16 %8085 to i64
  %8087 = load i16, ptr %562, align 2
  %8088 = zext i16 %8087 to i256
  %8089 = lshr i256 %8088, 128
  %8090 = trunc i256 %8089 to i64
  %8091 = load i16, ptr %562, align 2
  %8092 = zext i16 %8091 to i256
  %8093 = lshr i256 %8092, 64
  %8094 = trunc i256 %8093 to i64
  %8095 = load i16, ptr %562, align 2
  %8096 = zext i16 %8095 to i64
  %8097 = load i16, ptr %563, align 2
  %8098 = zext i16 %8097 to i64
  %8099 = load i16, ptr %564, align 2
  %8100 = zext i16 %8099 to i64
  %8101 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %8060, i64 noundef %8064, i64 noundef %8066, i64 noundef %8070, i64 noundef %8074, i64 noundef %8076, i64 noundef %8080, i64 noundef %8084, i64 noundef %8086, i64 noundef %8090, i64 noundef %8094, i64 noundef %8096, i64 noundef %8098, i64 noundef %8100)
  %8102 = load i16, ptr %557, align 2
  %8103 = zext i16 %8102 to i575
  %8104 = getelementptr inbounds [12 x i32], ptr %558, i64 0, i64 0
  %8105 = load i16, ptr %559, align 2
  %8106 = zext i16 %8105 to i575
  %8107 = load i16, ptr %560, align 2
  %8108 = zext i16 %8107 to i575
  %8109 = load i16, ptr %561, align 2
  %8110 = zext i16 %8109 to i575
  %8111 = load i16, ptr %562, align 2
  %8112 = zext i16 %8111 to i575
  %8113 = load i16, ptr %563, align 2
  %8114 = zext i16 %8113 to i575
  %8115 = load i16, ptr %564, align 2
  %8116 = zext i16 %8115 to i575
  %8117 = zext i575 %8103 to i576
  store i576 %8117, ptr %565, align 8
  %8118 = zext i575 %8106 to i576
  store i576 %8118, ptr %566, align 8
  %8119 = zext i575 %8108 to i576
  store i576 %8119, ptr %567, align 8
  %8120 = zext i575 %8110 to i576
  store i576 %8120, ptr %568, align 8
  %8121 = zext i575 %8112 to i576
  store i576 %8121, ptr %569, align 8
  %8122 = zext i575 %8114 to i576
  store i576 %8122, ptr %570, align 8
  %8123 = zext i575 %8116 to i576
  store i576 %8123, ptr %571, align 8
  call void @check(ptr noundef @.str.4, i32 noundef 16, ptr noundef byval([72 x i8]) align 8 %565, ptr noundef %8104, ptr noundef byval([72 x i8]) align 8 %566, ptr noundef byval([72 x i8]) align 8 %567, ptr noundef byval([72 x i8]) align 8 %568, ptr noundef byval([72 x i8]) align 8 %569, ptr noundef byval([72 x i8]) align 8 %570, ptr noundef byval([72 x i8]) align 8 %571)
  br label %8124

8124:                                             ; preds = %8047
  br label %8125

8125:                                             ; preds = %8124
  store i32 5, ptr %572, align 4
  %8126 = load i32, ptr %572, align 4
  %8127 = call i32 @llvm.ctlz.i32(i32 %8126, i1 false)
  store i32 %8127, ptr %573, align 4
  %8128 = getelementptr inbounds i32, ptr %573, i64 1
  %8129 = load i32, ptr %572, align 4
  %8130 = xor i32 %8129, -1
  %8131 = call i32 @llvm.ctlz.i32(i32 %8130, i1 false)
  store i32 %8131, ptr %8128, align 4
  %8132 = getelementptr inbounds i32, ptr %573, i64 2
  %8133 = load i32, ptr %572, align 4
  %8134 = call i32 @llvm.cttz.i32(i32 %8133, i1 false)
  store i32 %8134, ptr %8132, align 4
  %8135 = getelementptr inbounds i32, ptr %573, i64 3
  %8136 = load i32, ptr %572, align 4
  %8137 = xor i32 %8136, -1
  %8138 = call i32 @llvm.cttz.i32(i32 %8137, i1 false)
  store i32 %8138, ptr %8135, align 4
  %8139 = getelementptr inbounds i32, ptr %573, i64 4
  %8140 = load i32, ptr %572, align 4
  %8141 = xor i32 %8140, -1
  %8142 = call i32 @llvm.ctlz.i32(i32 %8141, i1 false)
  %8143 = add i32 %8142, 1
  %8144 = icmp eq i32 %8141, 0
  %8145 = select i1 %8144, i32 0, i32 %8143
  store i32 %8145, ptr %8139, align 4
  %8146 = getelementptr inbounds i32, ptr %573, i64 5
  %8147 = load i32, ptr %572, align 4
  %8148 = call i32 @llvm.ctlz.i32(i32 %8147, i1 false)
  %8149 = add i32 %8148, 1
  %8150 = icmp eq i32 %8147, 0
  %8151 = select i1 %8150, i32 0, i32 %8149
  store i32 %8151, ptr %8146, align 4
  %8152 = getelementptr inbounds i32, ptr %573, i64 6
  %8153 = load i32, ptr %572, align 4
  %8154 = xor i32 %8153, -1
  %8155 = call i32 @llvm.cttz.i32(i32 %8154, i1 false)
  %8156 = add i32 %8155, 1
  %8157 = icmp eq i32 %8154, 0
  %8158 = select i1 %8157, i32 0, i32 %8156
  store i32 %8158, ptr %8152, align 4
  %8159 = getelementptr inbounds i32, ptr %573, i64 7
  %8160 = load i32, ptr %572, align 4
  %8161 = call i32 @llvm.cttz.i32(i32 %8160, i1 false)
  %8162 = add i32 %8161, 1
  %8163 = icmp eq i32 %8160, 0
  %8164 = select i1 %8163, i32 0, i32 %8162
  store i32 %8164, ptr %8159, align 4
  %8165 = getelementptr inbounds i32, ptr %573, i64 8
  %8166 = load i32, ptr %572, align 4
  %8167 = call i32 @llvm.ctpop.i32(i32 %8166)
  %8168 = sub i32 32, %8167
  store i32 %8168, ptr %8165, align 4
  %8169 = getelementptr inbounds i32, ptr %573, i64 9
  %8170 = load i32, ptr %572, align 4
  %8171 = call i32 @llvm.ctpop.i32(i32 %8170)
  store i32 %8171, ptr %8169, align 4
  %8172 = getelementptr inbounds i32, ptr %573, i64 10
  %8173 = load i32, ptr %572, align 4
  %8174 = call i32 @llvm.ctpop.i32(i32 %8173)
  %8175 = icmp eq i32 %8174, 1
  %8176 = zext i1 %8175 to i32
  store i32 %8176, ptr %8172, align 4
  %8177 = getelementptr inbounds i32, ptr %573, i64 11
  %8178 = load i32, ptr %572, align 4
  %8179 = call i32 @llvm.ctlz.i32(i32 %8178, i1 false)
  %8180 = sub i32 32, %8179
  store i32 %8180, ptr %8177, align 4
  %8181 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 0
  %8182 = load i32, ptr %8181, align 16
  %8183 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 1
  %8184 = load i32, ptr %8183, align 4
  %8185 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 2
  %8186 = load i32, ptr %8185, align 8
  %8187 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 3
  %8188 = load i32, ptr %8187, align 4
  %8189 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 4
  %8190 = load i32, ptr %8189, align 16
  %8191 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 5
  %8192 = load i32, ptr %8191, align 4
  %8193 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 6
  %8194 = load i32, ptr %8193, align 8
  %8195 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 7
  %8196 = load i32, ptr %8195, align 4
  %8197 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 8
  %8198 = load i32, ptr %8197, align 16
  %8199 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 9
  %8200 = load i32, ptr %8199, align 4
  %8201 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 10
  %8202 = load i32, ptr %8201, align 8
  %8203 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 11
  %8204 = load i32, ptr %8203, align 4
  %8205 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef %8182, i32 noundef %8184, i32 noundef %8186, i32 noundef %8188, i32 noundef %8190, i32 noundef %8192, i32 noundef %8194, i32 noundef %8196, i32 noundef %8198, i32 noundef %8200, i32 noundef %8202, i32 noundef %8204)
  %8206 = load i32, ptr %572, align 4
  %8207 = call i32 @llvm.ctlz.i32(i32 %8206, i1 true)
  %8208 = sub i32 31, %8207
  %8209 = shl i32 1, %8208
  %8210 = icmp eq i32 %8206, 0
  %8211 = select i1 %8210, i32 0, i32 %8209
  store i32 %8211, ptr %574, align 4
  %8212 = load i32, ptr %572, align 4
  %8213 = icmp ule i32 %8212, 1
  br i1 %8213, label %8219, label %8214

8214:                                             ; preds = %8125
  %8215 = sub i32 %8212, 1
  %8216 = call i32 @llvm.ctlz.i32(i32 %8215, i1 false)
  %8217 = sub i32 31, %8216
  %8218 = shl i32 2, %8217
  br label %8219

8219:                                             ; preds = %8214, %8125
  %8220 = phi i32 [ 1, %8125 ], [ %8218, %8214 ]
  store i32 %8220, ptr %575, align 4
  %8221 = load i32, ptr %572, align 4
  %8222 = call i32 @llvm.fshl.i32(i32 %8221, i32 %8221, i32 3)
  store i32 %8222, ptr %576, align 4
  %8223 = load i32, ptr %572, align 4
  %8224 = call i32 @llvm.fshr.i32(i32 %8223, i32 %8223, i32 3)
  store i32 %8224, ptr %577, align 4
  %8225 = load i32, ptr %572, align 4
  %8226 = call i32 @llvm.fshl.i32(i32 %8225, i32 %8225, i32 0)
  store i32 %8226, ptr %578, align 4
  %8227 = load i32, ptr %572, align 4
  %8228 = call i32 @llvm.fshl.i32(i32 %8227, i32 %8227, i32 8)
  store i32 %8228, ptr %579, align 4
  %8229 = load i32, ptr %574, align 4
  %8230 = zext i32 %8229 to i256
  %8231 = lshr i256 %8230, 128
  %8232 = trunc i256 %8231 to i64
  %8233 = load i32, ptr %574, align 4
  %8234 = zext i32 %8233 to i256
  %8235 = lshr i256 %8234, 64
  %8236 = trunc i256 %8235 to i64
  %8237 = load i32, ptr %574, align 4
  %8238 = zext i32 %8237 to i64
  %8239 = load i32, ptr %575, align 4
  %8240 = zext i32 %8239 to i256
  %8241 = lshr i256 %8240, 128
  %8242 = trunc i256 %8241 to i64
  %8243 = load i32, ptr %575, align 4
  %8244 = zext i32 %8243 to i256
  %8245 = lshr i256 %8244, 64
  %8246 = trunc i256 %8245 to i64
  %8247 = load i32, ptr %575, align 4
  %8248 = zext i32 %8247 to i64
  %8249 = load i32, ptr %576, align 4
  %8250 = zext i32 %8249 to i256
  %8251 = lshr i256 %8250, 128
  %8252 = trunc i256 %8251 to i64
  %8253 = load i32, ptr %576, align 4
  %8254 = zext i32 %8253 to i256
  %8255 = lshr i256 %8254, 64
  %8256 = trunc i256 %8255 to i64
  %8257 = load i32, ptr %576, align 4
  %8258 = zext i32 %8257 to i64
  %8259 = load i32, ptr %577, align 4
  %8260 = zext i32 %8259 to i256
  %8261 = lshr i256 %8260, 128
  %8262 = trunc i256 %8261 to i64
  %8263 = load i32, ptr %577, align 4
  %8264 = zext i32 %8263 to i256
  %8265 = lshr i256 %8264, 64
  %8266 = trunc i256 %8265 to i64
  %8267 = load i32, ptr %577, align 4
  %8268 = zext i32 %8267 to i64
  %8269 = load i32, ptr %578, align 4
  %8270 = zext i32 %8269 to i64
  %8271 = load i32, ptr %579, align 4
  %8272 = zext i32 %8271 to i64
  %8273 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %8232, i64 noundef %8236, i64 noundef %8238, i64 noundef %8242, i64 noundef %8246, i64 noundef %8248, i64 noundef %8252, i64 noundef %8256, i64 noundef %8258, i64 noundef %8262, i64 noundef %8266, i64 noundef %8268, i64 noundef %8270, i64 noundef %8272)
  %8274 = load i32, ptr %572, align 4
  %8275 = zext i32 %8274 to i575
  %8276 = getelementptr inbounds [12 x i32], ptr %573, i64 0, i64 0
  %8277 = load i32, ptr %574, align 4
  %8278 = zext i32 %8277 to i575
  %8279 = load i32, ptr %575, align 4
  %8280 = zext i32 %8279 to i575
  %8281 = load i32, ptr %576, align 4
  %8282 = zext i32 %8281 to i575
  %8283 = load i32, ptr %577, align 4
  %8284 = zext i32 %8283 to i575
  %8285 = load i32, ptr %578, align 4
  %8286 = zext i32 %8285 to i575
  %8287 = load i32, ptr %579, align 4
  %8288 = zext i32 %8287 to i575
  %8289 = zext i575 %8275 to i576
  store i576 %8289, ptr %580, align 8
  %8290 = zext i575 %8278 to i576
  store i576 %8290, ptr %581, align 8
  %8291 = zext i575 %8280 to i576
  store i576 %8291, ptr %582, align 8
  %8292 = zext i575 %8282 to i576
  store i576 %8292, ptr %583, align 8
  %8293 = zext i575 %8284 to i576
  store i576 %8293, ptr %584, align 8
  %8294 = zext i575 %8286 to i576
  store i576 %8294, ptr %585, align 8
  %8295 = zext i575 %8288 to i576
  store i576 %8295, ptr %586, align 8
  call void @check(ptr noundef @.str.5, i32 noundef 32, ptr noundef byval([72 x i8]) align 8 %580, ptr noundef %8276, ptr noundef byval([72 x i8]) align 8 %581, ptr noundef byval([72 x i8]) align 8 %582, ptr noundef byval([72 x i8]) align 8 %583, ptr noundef byval([72 x i8]) align 8 %584, ptr noundef byval([72 x i8]) align 8 %585, ptr noundef byval([72 x i8]) align 8 %586)
  br label %8296

8296:                                             ; preds = %8219
  br label %8297

8297:                                             ; preds = %8296
  store i64 5, ptr %587, align 8
  %8298 = load i64, ptr %587, align 8
  %8299 = call i64 @llvm.ctlz.i64(i64 %8298, i1 false)
  %8300 = trunc i64 %8299 to i32
  store i32 %8300, ptr %588, align 4
  %8301 = getelementptr inbounds i32, ptr %588, i64 1
  %8302 = load i64, ptr %587, align 8
  %8303 = xor i64 %8302, -1
  %8304 = call i64 @llvm.ctlz.i64(i64 %8303, i1 false)
  %8305 = trunc i64 %8304 to i32
  store i32 %8305, ptr %8301, align 4
  %8306 = getelementptr inbounds i32, ptr %588, i64 2
  %8307 = load i64, ptr %587, align 8
  %8308 = call i64 @llvm.cttz.i64(i64 %8307, i1 false)
  %8309 = trunc i64 %8308 to i32
  store i32 %8309, ptr %8306, align 4
  %8310 = getelementptr inbounds i32, ptr %588, i64 3
  %8311 = load i64, ptr %587, align 8
  %8312 = xor i64 %8311, -1
  %8313 = call i64 @llvm.cttz.i64(i64 %8312, i1 false)
  %8314 = trunc i64 %8313 to i32
  store i32 %8314, ptr %8310, align 4
  %8315 = getelementptr inbounds i32, ptr %588, i64 4
  %8316 = load i64, ptr %587, align 8
  %8317 = xor i64 %8316, -1
  %8318 = call i64 @llvm.ctlz.i64(i64 %8317, i1 false)
  %8319 = add i64 %8318, 1
  %8320 = icmp eq i64 %8317, 0
  %8321 = select i1 %8320, i64 0, i64 %8319
  %8322 = trunc i64 %8321 to i32
  store i32 %8322, ptr %8315, align 4
  %8323 = getelementptr inbounds i32, ptr %588, i64 5
  %8324 = load i64, ptr %587, align 8
  %8325 = call i64 @llvm.ctlz.i64(i64 %8324, i1 false)
  %8326 = add i64 %8325, 1
  %8327 = icmp eq i64 %8324, 0
  %8328 = select i1 %8327, i64 0, i64 %8326
  %8329 = trunc i64 %8328 to i32
  store i32 %8329, ptr %8323, align 4
  %8330 = getelementptr inbounds i32, ptr %588, i64 6
  %8331 = load i64, ptr %587, align 8
  %8332 = xor i64 %8331, -1
  %8333 = call i64 @llvm.cttz.i64(i64 %8332, i1 false)
  %8334 = add i64 %8333, 1
  %8335 = icmp eq i64 %8332, 0
  %8336 = select i1 %8335, i64 0, i64 %8334
  %8337 = trunc i64 %8336 to i32
  store i32 %8337, ptr %8330, align 4
  %8338 = getelementptr inbounds i32, ptr %588, i64 7
  %8339 = load i64, ptr %587, align 8
  %8340 = call i64 @llvm.cttz.i64(i64 %8339, i1 false)
  %8341 = add i64 %8340, 1
  %8342 = icmp eq i64 %8339, 0
  %8343 = select i1 %8342, i64 0, i64 %8341
  %8344 = trunc i64 %8343 to i32
  store i32 %8344, ptr %8338, align 4
  %8345 = getelementptr inbounds i32, ptr %588, i64 8
  %8346 = load i64, ptr %587, align 8
  %8347 = call i64 @llvm.ctpop.i64(i64 %8346)
  %8348 = sub i64 64, %8347
  %8349 = trunc i64 %8348 to i32
  store i32 %8349, ptr %8345, align 4
  %8350 = getelementptr inbounds i32, ptr %588, i64 9
  %8351 = load i64, ptr %587, align 8
  %8352 = call i64 @llvm.ctpop.i64(i64 %8351)
  %8353 = trunc i64 %8352 to i32
  store i32 %8353, ptr %8350, align 4
  %8354 = getelementptr inbounds i32, ptr %588, i64 10
  %8355 = load i64, ptr %587, align 8
  %8356 = call i64 @llvm.ctpop.i64(i64 %8355)
  %8357 = icmp eq i64 %8356, 1
  %8358 = zext i1 %8357 to i32
  store i32 %8358, ptr %8354, align 4
  %8359 = getelementptr inbounds i32, ptr %588, i64 11
  %8360 = load i64, ptr %587, align 8
  %8361 = call i64 @llvm.ctlz.i64(i64 %8360, i1 false)
  %8362 = sub i64 64, %8361
  %8363 = trunc i64 %8362 to i32
  store i32 %8363, ptr %8359, align 4
  %8364 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 0
  %8365 = load i32, ptr %8364, align 16
  %8366 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 1
  %8367 = load i32, ptr %8366, align 4
  %8368 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 2
  %8369 = load i32, ptr %8368, align 8
  %8370 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 3
  %8371 = load i32, ptr %8370, align 4
  %8372 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 4
  %8373 = load i32, ptr %8372, align 16
  %8374 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 5
  %8375 = load i32, ptr %8374, align 4
  %8376 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 6
  %8377 = load i32, ptr %8376, align 8
  %8378 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 7
  %8379 = load i32, ptr %8378, align 4
  %8380 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 8
  %8381 = load i32, ptr %8380, align 16
  %8382 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 9
  %8383 = load i32, ptr %8382, align 4
  %8384 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 10
  %8385 = load i32, ptr %8384, align 8
  %8386 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 11
  %8387 = load i32, ptr %8386, align 4
  %8388 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef %8365, i32 noundef %8367, i32 noundef %8369, i32 noundef %8371, i32 noundef %8373, i32 noundef %8375, i32 noundef %8377, i32 noundef %8379, i32 noundef %8381, i32 noundef %8383, i32 noundef %8385, i32 noundef %8387)
  %8389 = load i64, ptr %587, align 8
  %8390 = call i64 @llvm.ctlz.i64(i64 %8389, i1 true)
  %8391 = sub i64 63, %8390
  %8392 = shl i64 1, %8391
  %8393 = icmp eq i64 %8389, 0
  %8394 = select i1 %8393, i64 0, i64 %8392
  store i64 %8394, ptr %589, align 8
  %8395 = load i64, ptr %587, align 8
  %8396 = icmp ule i64 %8395, 1
  br i1 %8396, label %8402, label %8397

8397:                                             ; preds = %8297
  %8398 = sub i64 %8395, 1
  %8399 = call i64 @llvm.ctlz.i64(i64 %8398, i1 false)
  %8400 = sub i64 63, %8399
  %8401 = shl i64 2, %8400
  br label %8402

8402:                                             ; preds = %8397, %8297
  %8403 = phi i64 [ 1, %8297 ], [ %8401, %8397 ]
  store i64 %8403, ptr %590, align 8
  %8404 = load i64, ptr %587, align 8
  %8405 = call i64 @llvm.fshl.i64(i64 %8404, i64 %8404, i64 3)
  store i64 %8405, ptr %591, align 8
  %8406 = load i64, ptr %587, align 8
  %8407 = call i64 @llvm.fshr.i64(i64 %8406, i64 %8406, i64 3)
  store i64 %8407, ptr %592, align 8
  %8408 = load i64, ptr %587, align 8
  %8409 = call i64 @llvm.fshl.i64(i64 %8408, i64 %8408, i64 0)
  store i64 %8409, ptr %593, align 8
  %8410 = load i64, ptr %587, align 8
  %8411 = call i64 @llvm.fshl.i64(i64 %8410, i64 %8410, i64 40)
  store i64 %8411, ptr %594, align 8
  %8412 = load i64, ptr %589, align 8
  %8413 = zext i64 %8412 to i256
  %8414 = lshr i256 %8413, 128
  %8415 = trunc i256 %8414 to i64
  %8416 = load i64, ptr %589, align 8
  %8417 = zext i64 %8416 to i256
  %8418 = lshr i256 %8417, 64
  %8419 = trunc i256 %8418 to i64
  %8420 = load i64, ptr %589, align 8
  %8421 = load i64, ptr %590, align 8
  %8422 = zext i64 %8421 to i256
  %8423 = lshr i256 %8422, 128
  %8424 = trunc i256 %8423 to i64
  %8425 = load i64, ptr %590, align 8
  %8426 = zext i64 %8425 to i256
  %8427 = lshr i256 %8426, 64
  %8428 = trunc i256 %8427 to i64
  %8429 = load i64, ptr %590, align 8
  %8430 = load i64, ptr %591, align 8
  %8431 = zext i64 %8430 to i256
  %8432 = lshr i256 %8431, 128
  %8433 = trunc i256 %8432 to i64
  %8434 = load i64, ptr %591, align 8
  %8435 = zext i64 %8434 to i256
  %8436 = lshr i256 %8435, 64
  %8437 = trunc i256 %8436 to i64
  %8438 = load i64, ptr %591, align 8
  %8439 = load i64, ptr %592, align 8
  %8440 = zext i64 %8439 to i256
  %8441 = lshr i256 %8440, 128
  %8442 = trunc i256 %8441 to i64
  %8443 = load i64, ptr %592, align 8
  %8444 = zext i64 %8443 to i256
  %8445 = lshr i256 %8444, 64
  %8446 = trunc i256 %8445 to i64
  %8447 = load i64, ptr %592, align 8
  %8448 = load i64, ptr %593, align 8
  %8449 = load i64, ptr %594, align 8
  %8450 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %8415, i64 noundef %8419, i64 noundef %8420, i64 noundef %8424, i64 noundef %8428, i64 noundef %8429, i64 noundef %8433, i64 noundef %8437, i64 noundef %8438, i64 noundef %8442, i64 noundef %8446, i64 noundef %8447, i64 noundef %8448, i64 noundef %8449)
  %8451 = load i64, ptr %587, align 8
  %8452 = zext i64 %8451 to i575
  %8453 = getelementptr inbounds [12 x i32], ptr %588, i64 0, i64 0
  %8454 = load i64, ptr %589, align 8
  %8455 = zext i64 %8454 to i575
  %8456 = load i64, ptr %590, align 8
  %8457 = zext i64 %8456 to i575
  %8458 = load i64, ptr %591, align 8
  %8459 = zext i64 %8458 to i575
  %8460 = load i64, ptr %592, align 8
  %8461 = zext i64 %8460 to i575
  %8462 = load i64, ptr %593, align 8
  %8463 = zext i64 %8462 to i575
  %8464 = load i64, ptr %594, align 8
  %8465 = zext i64 %8464 to i575
  %8466 = zext i575 %8452 to i576
  store i576 %8466, ptr %595, align 8
  %8467 = zext i575 %8455 to i576
  store i576 %8467, ptr %596, align 8
  %8468 = zext i575 %8457 to i576
  store i576 %8468, ptr %597, align 8
  %8469 = zext i575 %8459 to i576
  store i576 %8469, ptr %598, align 8
  %8470 = zext i575 %8461 to i576
  store i576 %8470, ptr %599, align 8
  %8471 = zext i575 %8463 to i576
  store i576 %8471, ptr %600, align 8
  %8472 = zext i575 %8465 to i576
  store i576 %8472, ptr %601, align 8
  call void @check(ptr noundef @.str.6, i32 noundef 64, ptr noundef byval([72 x i8]) align 8 %595, ptr noundef %8453, ptr noundef byval([72 x i8]) align 8 %596, ptr noundef byval([72 x i8]) align 8 %597, ptr noundef byval([72 x i8]) align 8 %598, ptr noundef byval([72 x i8]) align 8 %599, ptr noundef byval([72 x i8]) align 8 %600, ptr noundef byval([72 x i8]) align 8 %601)
  br label %8473

8473:                                             ; preds = %8402
  br label %8474

8474:                                             ; preds = %8473
  store i128 5, ptr %602, align 16
  %8475 = load i128, ptr %602, align 16
  %8476 = call i128 @llvm.ctlz.i128(i128 %8475, i1 false)
  %8477 = trunc i128 %8476 to i32
  store i32 %8477, ptr %603, align 4
  %8478 = getelementptr inbounds i32, ptr %603, i64 1
  %8479 = load i128, ptr %602, align 16
  %8480 = xor i128 %8479, -1
  %8481 = call i128 @llvm.ctlz.i128(i128 %8480, i1 false)
  %8482 = trunc i128 %8481 to i32
  store i32 %8482, ptr %8478, align 4
  %8483 = getelementptr inbounds i32, ptr %603, i64 2
  %8484 = load i128, ptr %602, align 16
  %8485 = call i128 @llvm.cttz.i128(i128 %8484, i1 false)
  %8486 = trunc i128 %8485 to i32
  store i32 %8486, ptr %8483, align 4
  %8487 = getelementptr inbounds i32, ptr %603, i64 3
  %8488 = load i128, ptr %602, align 16
  %8489 = xor i128 %8488, -1
  %8490 = call i128 @llvm.cttz.i128(i128 %8489, i1 false)
  %8491 = trunc i128 %8490 to i32
  store i32 %8491, ptr %8487, align 4
  %8492 = getelementptr inbounds i32, ptr %603, i64 4
  %8493 = load i128, ptr %602, align 16
  %8494 = xor i128 %8493, -1
  %8495 = call i128 @llvm.ctlz.i128(i128 %8494, i1 false)
  %8496 = add i128 %8495, 1
  %8497 = icmp eq i128 %8494, 0
  %8498 = select i1 %8497, i128 0, i128 %8496
  %8499 = trunc i128 %8498 to i32
  store i32 %8499, ptr %8492, align 4
  %8500 = getelementptr inbounds i32, ptr %603, i64 5
  %8501 = load i128, ptr %602, align 16
  %8502 = call i128 @llvm.ctlz.i128(i128 %8501, i1 false)
  %8503 = add i128 %8502, 1
  %8504 = icmp eq i128 %8501, 0
  %8505 = select i1 %8504, i128 0, i128 %8503
  %8506 = trunc i128 %8505 to i32
  store i32 %8506, ptr %8500, align 4
  %8507 = getelementptr inbounds i32, ptr %603, i64 6
  %8508 = load i128, ptr %602, align 16
  %8509 = xor i128 %8508, -1
  %8510 = call i128 @llvm.cttz.i128(i128 %8509, i1 false)
  %8511 = add i128 %8510, 1
  %8512 = icmp eq i128 %8509, 0
  %8513 = select i1 %8512, i128 0, i128 %8511
  %8514 = trunc i128 %8513 to i32
  store i32 %8514, ptr %8507, align 4
  %8515 = getelementptr inbounds i32, ptr %603, i64 7
  %8516 = load i128, ptr %602, align 16
  %8517 = call i128 @llvm.cttz.i128(i128 %8516, i1 false)
  %8518 = add i128 %8517, 1
  %8519 = icmp eq i128 %8516, 0
  %8520 = select i1 %8519, i128 0, i128 %8518
  %8521 = trunc i128 %8520 to i32
  store i32 %8521, ptr %8515, align 4
  %8522 = getelementptr inbounds i32, ptr %603, i64 8
  %8523 = load i128, ptr %602, align 16
  %8524 = call i128 @llvm.ctpop.i128(i128 %8523)
  %8525 = sub i128 128, %8524
  %8526 = trunc i128 %8525 to i32
  store i32 %8526, ptr %8522, align 4
  %8527 = getelementptr inbounds i32, ptr %603, i64 9
  %8528 = load i128, ptr %602, align 16
  %8529 = call i128 @llvm.ctpop.i128(i128 %8528)
  %8530 = trunc i128 %8529 to i32
  store i32 %8530, ptr %8527, align 4
  %8531 = getelementptr inbounds i32, ptr %603, i64 10
  %8532 = load i128, ptr %602, align 16
  %8533 = call i128 @llvm.ctpop.i128(i128 %8532)
  %8534 = icmp eq i128 %8533, 1
  %8535 = zext i1 %8534 to i32
  store i32 %8535, ptr %8531, align 4
  %8536 = getelementptr inbounds i32, ptr %603, i64 11
  %8537 = load i128, ptr %602, align 16
  %8538 = call i128 @llvm.ctlz.i128(i128 %8537, i1 false)
  %8539 = sub i128 128, %8538
  %8540 = trunc i128 %8539 to i32
  store i32 %8540, ptr %8536, align 4
  %8541 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 0
  %8542 = load i32, ptr %8541, align 16
  %8543 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 1
  %8544 = load i32, ptr %8543, align 4
  %8545 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 2
  %8546 = load i32, ptr %8545, align 8
  %8547 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 3
  %8548 = load i32, ptr %8547, align 4
  %8549 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 4
  %8550 = load i32, ptr %8549, align 16
  %8551 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 5
  %8552 = load i32, ptr %8551, align 4
  %8553 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 6
  %8554 = load i32, ptr %8553, align 8
  %8555 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 7
  %8556 = load i32, ptr %8555, align 4
  %8557 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 8
  %8558 = load i32, ptr %8557, align 16
  %8559 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 9
  %8560 = load i32, ptr %8559, align 4
  %8561 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 10
  %8562 = load i32, ptr %8561, align 8
  %8563 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 11
  %8564 = load i32, ptr %8563, align 4
  %8565 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef %8542, i32 noundef %8544, i32 noundef %8546, i32 noundef %8548, i32 noundef %8550, i32 noundef %8552, i32 noundef %8554, i32 noundef %8556, i32 noundef %8558, i32 noundef %8560, i32 noundef %8562, i32 noundef %8564)
  %8566 = load i128, ptr %602, align 16
  %8567 = call i128 @llvm.ctlz.i128(i128 %8566, i1 true)
  %8568 = sub i128 127, %8567
  %8569 = shl i128 1, %8568
  %8570 = icmp eq i128 %8566, 0
  %8571 = select i1 %8570, i128 0, i128 %8569
  store i128 %8571, ptr %604, align 16
  %8572 = load i128, ptr %602, align 16
  %8573 = icmp ule i128 %8572, 1
  br i1 %8573, label %8579, label %8574

8574:                                             ; preds = %8474
  %8575 = sub i128 %8572, 1
  %8576 = call i128 @llvm.ctlz.i128(i128 %8575, i1 false)
  %8577 = sub i128 127, %8576
  %8578 = shl i128 2, %8577
  br label %8579

8579:                                             ; preds = %8574, %8474
  %8580 = phi i128 [ 1, %8474 ], [ %8578, %8574 ]
  store i128 %8580, ptr %605, align 16
  %8581 = load i128, ptr %602, align 16
  %8582 = call i128 @llvm.fshl.i128(i128 %8581, i128 %8581, i128 3)
  store i128 %8582, ptr %606, align 16
  %8583 = load i128, ptr %602, align 16
  %8584 = call i128 @llvm.fshr.i128(i128 %8583, i128 %8583, i128 3)
  store i128 %8584, ptr %607, align 16
  %8585 = load i128, ptr %602, align 16
  %8586 = call i128 @llvm.fshl.i128(i128 %8585, i128 %8585, i128 0)
  store i128 %8586, ptr %608, align 16
  %8587 = load i128, ptr %602, align 16
  %8588 = call i128 @llvm.fshl.i128(i128 %8587, i128 %8587, i128 104)
  store i128 %8588, ptr %609, align 16
  %8589 = load i128, ptr %604, align 16
  %8590 = zext i128 %8589 to i256
  %8591 = lshr i256 %8590, 128
  %8592 = trunc i256 %8591 to i64
  %8593 = load i128, ptr %604, align 16
  %8594 = zext i128 %8593 to i256
  %8595 = lshr i256 %8594, 64
  %8596 = trunc i256 %8595 to i64
  %8597 = load i128, ptr %604, align 16
  %8598 = trunc i128 %8597 to i64
  %8599 = load i128, ptr %605, align 16
  %8600 = zext i128 %8599 to i256
  %8601 = lshr i256 %8600, 128
  %8602 = trunc i256 %8601 to i64
  %8603 = load i128, ptr %605, align 16
  %8604 = zext i128 %8603 to i256
  %8605 = lshr i256 %8604, 64
  %8606 = trunc i256 %8605 to i64
  %8607 = load i128, ptr %605, align 16
  %8608 = trunc i128 %8607 to i64
  %8609 = load i128, ptr %606, align 16
  %8610 = zext i128 %8609 to i256
  %8611 = lshr i256 %8610, 128
  %8612 = trunc i256 %8611 to i64
  %8613 = load i128, ptr %606, align 16
  %8614 = zext i128 %8613 to i256
  %8615 = lshr i256 %8614, 64
  %8616 = trunc i256 %8615 to i64
  %8617 = load i128, ptr %606, align 16
  %8618 = trunc i128 %8617 to i64
  %8619 = load i128, ptr %607, align 16
  %8620 = zext i128 %8619 to i256
  %8621 = lshr i256 %8620, 128
  %8622 = trunc i256 %8621 to i64
  %8623 = load i128, ptr %607, align 16
  %8624 = zext i128 %8623 to i256
  %8625 = lshr i256 %8624, 64
  %8626 = trunc i256 %8625 to i64
  %8627 = load i128, ptr %607, align 16
  %8628 = trunc i128 %8627 to i64
  %8629 = load i128, ptr %608, align 16
  %8630 = trunc i128 %8629 to i64
  %8631 = load i128, ptr %609, align 16
  %8632 = trunc i128 %8631 to i64
  %8633 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %8592, i64 noundef %8596, i64 noundef %8598, i64 noundef %8602, i64 noundef %8606, i64 noundef %8608, i64 noundef %8612, i64 noundef %8616, i64 noundef %8618, i64 noundef %8622, i64 noundef %8626, i64 noundef %8628, i64 noundef %8630, i64 noundef %8632)
  %8634 = load i128, ptr %602, align 16
  %8635 = zext i128 %8634 to i575
  %8636 = getelementptr inbounds [12 x i32], ptr %603, i64 0, i64 0
  %8637 = load i128, ptr %604, align 16
  %8638 = zext i128 %8637 to i575
  %8639 = load i128, ptr %605, align 16
  %8640 = zext i128 %8639 to i575
  %8641 = load i128, ptr %606, align 16
  %8642 = zext i128 %8641 to i575
  %8643 = load i128, ptr %607, align 16
  %8644 = zext i128 %8643 to i575
  %8645 = load i128, ptr %608, align 16
  %8646 = zext i128 %8645 to i575
  %8647 = load i128, ptr %609, align 16
  %8648 = zext i128 %8647 to i575
  %8649 = zext i575 %8635 to i576
  store i576 %8649, ptr %610, align 8
  %8650 = zext i575 %8638 to i576
  store i576 %8650, ptr %611, align 8
  %8651 = zext i575 %8640 to i576
  store i576 %8651, ptr %612, align 8
  %8652 = zext i575 %8642 to i576
  store i576 %8652, ptr %613, align 8
  %8653 = zext i575 %8644 to i576
  store i576 %8653, ptr %614, align 8
  %8654 = zext i575 %8646 to i576
  store i576 %8654, ptr %615, align 8
  %8655 = zext i575 %8648 to i576
  store i576 %8655, ptr %616, align 8
  call void @check(ptr noundef @.str.7, i32 noundef 128, ptr noundef byval([72 x i8]) align 8 %610, ptr noundef %8636, ptr noundef byval([72 x i8]) align 8 %611, ptr noundef byval([72 x i8]) align 8 %612, ptr noundef byval([72 x i8]) align 8 %613, ptr noundef byval([72 x i8]) align 8 %614, ptr noundef byval([72 x i8]) align 8 %615, ptr noundef byval([72 x i8]) align 8 %616)
  br label %8656

8656:                                             ; preds = %8579
  br label %8657

8657:                                             ; preds = %8656
  store i8 5, ptr %617, align 1
  %8658 = load i8, ptr %617, align 1
  %8659 = trunc i8 %8658 to i7
  %8660 = call i7 @llvm.ctlz.i7(i7 %8659, i1 false)
  %8661 = zext i7 %8660 to i32
  store i32 %8661, ptr %618, align 4
  %8662 = getelementptr inbounds i32, ptr %618, i64 1
  %8663 = load i8, ptr %617, align 1
  %8664 = trunc i8 %8663 to i7
  %8665 = xor i7 %8664, -1
  %8666 = call i7 @llvm.ctlz.i7(i7 %8665, i1 false)
  %8667 = zext i7 %8666 to i32
  store i32 %8667, ptr %8662, align 4
  %8668 = getelementptr inbounds i32, ptr %618, i64 2
  %8669 = load i8, ptr %617, align 1
  %8670 = trunc i8 %8669 to i7
  %8671 = call i7 @llvm.cttz.i7(i7 %8670, i1 false)
  %8672 = zext i7 %8671 to i32
  store i32 %8672, ptr %8668, align 4
  %8673 = getelementptr inbounds i32, ptr %618, i64 3
  %8674 = load i8, ptr %617, align 1
  %8675 = trunc i8 %8674 to i7
  %8676 = xor i7 %8675, -1
  %8677 = call i7 @llvm.cttz.i7(i7 %8676, i1 false)
  %8678 = zext i7 %8677 to i32
  store i32 %8678, ptr %8673, align 4
  %8679 = getelementptr inbounds i32, ptr %618, i64 4
  %8680 = load i8, ptr %617, align 1
  %8681 = trunc i8 %8680 to i7
  %8682 = xor i7 %8681, -1
  %8683 = call i7 @llvm.ctlz.i7(i7 %8682, i1 false)
  %8684 = add i7 %8683, 1
  %8685 = icmp eq i7 %8682, 0
  %8686 = select i1 %8685, i7 0, i7 %8684
  %8687 = zext i7 %8686 to i32
  store i32 %8687, ptr %8679, align 4
  %8688 = getelementptr inbounds i32, ptr %618, i64 5
  %8689 = load i8, ptr %617, align 1
  %8690 = trunc i8 %8689 to i7
  %8691 = call i7 @llvm.ctlz.i7(i7 %8690, i1 false)
  %8692 = add i7 %8691, 1
  %8693 = icmp eq i7 %8690, 0
  %8694 = select i1 %8693, i7 0, i7 %8692
  %8695 = zext i7 %8694 to i32
  store i32 %8695, ptr %8688, align 4
  %8696 = getelementptr inbounds i32, ptr %618, i64 6
  %8697 = load i8, ptr %617, align 1
  %8698 = trunc i8 %8697 to i7
  %8699 = xor i7 %8698, -1
  %8700 = call i7 @llvm.cttz.i7(i7 %8699, i1 false)
  %8701 = add i7 %8700, 1
  %8702 = icmp eq i7 %8699, 0
  %8703 = select i1 %8702, i7 0, i7 %8701
  %8704 = zext i7 %8703 to i32
  store i32 %8704, ptr %8696, align 4
  %8705 = getelementptr inbounds i32, ptr %618, i64 7
  %8706 = load i8, ptr %617, align 1
  %8707 = trunc i8 %8706 to i7
  %8708 = call i7 @llvm.cttz.i7(i7 %8707, i1 false)
  %8709 = add i7 %8708, 1
  %8710 = icmp eq i7 %8707, 0
  %8711 = select i1 %8710, i7 0, i7 %8709
  %8712 = zext i7 %8711 to i32
  store i32 %8712, ptr %8705, align 4
  %8713 = getelementptr inbounds i32, ptr %618, i64 8
  %8714 = load i8, ptr %617, align 1
  %8715 = trunc i8 %8714 to i7
  %8716 = call i7 @llvm.ctpop.i7(i7 %8715)
  %8717 = sub i7 7, %8716
  %8718 = zext i7 %8717 to i32
  store i32 %8718, ptr %8713, align 4
  %8719 = getelementptr inbounds i32, ptr %618, i64 9
  %8720 = load i8, ptr %617, align 1
  %8721 = trunc i8 %8720 to i7
  %8722 = call i7 @llvm.ctpop.i7(i7 %8721)
  %8723 = zext i7 %8722 to i32
  store i32 %8723, ptr %8719, align 4
  %8724 = getelementptr inbounds i32, ptr %618, i64 10
  %8725 = load i8, ptr %617, align 1
  %8726 = trunc i8 %8725 to i7
  %8727 = call i7 @llvm.ctpop.i7(i7 %8726)
  %8728 = icmp eq i7 %8727, 1
  %8729 = zext i1 %8728 to i32
  store i32 %8729, ptr %8724, align 4
  %8730 = getelementptr inbounds i32, ptr %618, i64 11
  %8731 = load i8, ptr %617, align 1
  %8732 = trunc i8 %8731 to i7
  %8733 = call i7 @llvm.ctlz.i7(i7 %8732, i1 false)
  %8734 = sub i7 7, %8733
  %8735 = zext i7 %8734 to i32
  store i32 %8735, ptr %8730, align 4
  %8736 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 0
  %8737 = load i32, ptr %8736, align 16
  %8738 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 1
  %8739 = load i32, ptr %8738, align 4
  %8740 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 2
  %8741 = load i32, ptr %8740, align 8
  %8742 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 3
  %8743 = load i32, ptr %8742, align 4
  %8744 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 4
  %8745 = load i32, ptr %8744, align 16
  %8746 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 5
  %8747 = load i32, ptr %8746, align 4
  %8748 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 6
  %8749 = load i32, ptr %8748, align 8
  %8750 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 7
  %8751 = load i32, ptr %8750, align 4
  %8752 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 8
  %8753 = load i32, ptr %8752, align 16
  %8754 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 9
  %8755 = load i32, ptr %8754, align 4
  %8756 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 10
  %8757 = load i32, ptr %8756, align 8
  %8758 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 11
  %8759 = load i32, ptr %8758, align 4
  %8760 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef %8737, i32 noundef %8739, i32 noundef %8741, i32 noundef %8743, i32 noundef %8745, i32 noundef %8747, i32 noundef %8749, i32 noundef %8751, i32 noundef %8753, i32 noundef %8755, i32 noundef %8757, i32 noundef %8759)
  %8761 = load i8, ptr %617, align 1
  %8762 = trunc i8 %8761 to i7
  %8763 = call i7 @llvm.ctlz.i7(i7 %8762, i1 true)
  %8764 = sub i7 6, %8763
  %8765 = shl i7 1, %8764
  %8766 = icmp eq i7 %8762, 0
  %8767 = select i1 %8766, i7 0, i7 %8765
  %8768 = zext i7 %8767 to i8
  store i8 %8768, ptr %619, align 1
  %8769 = load i8, ptr %617, align 1
  %8770 = trunc i8 %8769 to i7
  %8771 = icmp ule i7 %8770, 1
  br i1 %8771, label %8777, label %8772

8772:                                             ; preds = %8657
  %8773 = sub i7 %8770, 1
  %8774 = call i7 @llvm.ctlz.i7(i7 %8773, i1 false)
  %8775 = sub i7 6, %8774
  %8776 = shl i7 2, %8775
  br label %8777

8777:                                             ; preds = %8772, %8657
  %8778 = phi i7 [ 1, %8657 ], [ %8776, %8772 ]
  %8779 = zext i7 %8778 to i8
  store i8 %8779, ptr %620, align 1
  %8780 = load i8, ptr %617, align 1
  %8781 = trunc i8 %8780 to i7
  %8782 = call i7 @llvm.fshl.i7(i7 %8781, i7 %8781, i7 3)
  %8783 = zext i7 %8782 to i8
  store i8 %8783, ptr %621, align 1
  %8784 = load i8, ptr %617, align 1
  %8785 = trunc i8 %8784 to i7
  %8786 = call i7 @llvm.fshr.i7(i7 %8785, i7 %8785, i7 3)
  %8787 = zext i7 %8786 to i8
  store i8 %8787, ptr %622, align 1
  %8788 = load i8, ptr %617, align 1
  %8789 = trunc i8 %8788 to i7
  %8790 = call i7 @llvm.fshl.i7(i7 %8789, i7 %8789, i7 0)
  %8791 = zext i7 %8790 to i8
  store i8 %8791, ptr %623, align 1
  %8792 = load i8, ptr %617, align 1
  %8793 = trunc i8 %8792 to i7
  %8794 = call i7 @llvm.fshl.i7(i7 %8793, i7 %8793, i7 6)
  %8795 = zext i7 %8794 to i8
  store i8 %8795, ptr %624, align 1
  %8796 = load i8, ptr %619, align 1
  %8797 = trunc i8 %8796 to i7
  %8798 = zext i7 %8797 to i256
  %8799 = lshr i256 %8798, 128
  %8800 = trunc i256 %8799 to i64
  %8801 = load i8, ptr %619, align 1
  %8802 = trunc i8 %8801 to i7
  %8803 = zext i7 %8802 to i256
  %8804 = lshr i256 %8803, 64
  %8805 = trunc i256 %8804 to i64
  %8806 = load i8, ptr %619, align 1
  %8807 = trunc i8 %8806 to i7
  %8808 = zext i7 %8807 to i64
  %8809 = load i8, ptr %620, align 1
  %8810 = trunc i8 %8809 to i7
  %8811 = zext i7 %8810 to i256
  %8812 = lshr i256 %8811, 128
  %8813 = trunc i256 %8812 to i64
  %8814 = load i8, ptr %620, align 1
  %8815 = trunc i8 %8814 to i7
  %8816 = zext i7 %8815 to i256
  %8817 = lshr i256 %8816, 64
  %8818 = trunc i256 %8817 to i64
  %8819 = load i8, ptr %620, align 1
  %8820 = trunc i8 %8819 to i7
  %8821 = zext i7 %8820 to i64
  %8822 = load i8, ptr %621, align 1
  %8823 = trunc i8 %8822 to i7
  %8824 = zext i7 %8823 to i256
  %8825 = lshr i256 %8824, 128
  %8826 = trunc i256 %8825 to i64
  %8827 = load i8, ptr %621, align 1
  %8828 = trunc i8 %8827 to i7
  %8829 = zext i7 %8828 to i256
  %8830 = lshr i256 %8829, 64
  %8831 = trunc i256 %8830 to i64
  %8832 = load i8, ptr %621, align 1
  %8833 = trunc i8 %8832 to i7
  %8834 = zext i7 %8833 to i64
  %8835 = load i8, ptr %622, align 1
  %8836 = trunc i8 %8835 to i7
  %8837 = zext i7 %8836 to i256
  %8838 = lshr i256 %8837, 128
  %8839 = trunc i256 %8838 to i64
  %8840 = load i8, ptr %622, align 1
  %8841 = trunc i8 %8840 to i7
  %8842 = zext i7 %8841 to i256
  %8843 = lshr i256 %8842, 64
  %8844 = trunc i256 %8843 to i64
  %8845 = load i8, ptr %622, align 1
  %8846 = trunc i8 %8845 to i7
  %8847 = zext i7 %8846 to i64
  %8848 = load i8, ptr %623, align 1
  %8849 = trunc i8 %8848 to i7
  %8850 = zext i7 %8849 to i64
  %8851 = load i8, ptr %624, align 1
  %8852 = trunc i8 %8851 to i7
  %8853 = zext i7 %8852 to i64
  %8854 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %8800, i64 noundef %8805, i64 noundef %8808, i64 noundef %8813, i64 noundef %8818, i64 noundef %8821, i64 noundef %8826, i64 noundef %8831, i64 noundef %8834, i64 noundef %8839, i64 noundef %8844, i64 noundef %8847, i64 noundef %8850, i64 noundef %8853)
  %8855 = load i8, ptr %617, align 1
  %8856 = trunc i8 %8855 to i7
  %8857 = zext i7 %8856 to i575
  %8858 = getelementptr inbounds [12 x i32], ptr %618, i64 0, i64 0
  %8859 = load i8, ptr %619, align 1
  %8860 = trunc i8 %8859 to i7
  %8861 = zext i7 %8860 to i575
  %8862 = load i8, ptr %620, align 1
  %8863 = trunc i8 %8862 to i7
  %8864 = zext i7 %8863 to i575
  %8865 = load i8, ptr %621, align 1
  %8866 = trunc i8 %8865 to i7
  %8867 = zext i7 %8866 to i575
  %8868 = load i8, ptr %622, align 1
  %8869 = trunc i8 %8868 to i7
  %8870 = zext i7 %8869 to i575
  %8871 = load i8, ptr %623, align 1
  %8872 = trunc i8 %8871 to i7
  %8873 = zext i7 %8872 to i575
  %8874 = load i8, ptr %624, align 1
  %8875 = trunc i8 %8874 to i7
  %8876 = zext i7 %8875 to i575
  %8877 = zext i575 %8857 to i576
  store i576 %8877, ptr %625, align 8
  %8878 = zext i575 %8861 to i576
  store i576 %8878, ptr %626, align 8
  %8879 = zext i575 %8864 to i576
  store i576 %8879, ptr %627, align 8
  %8880 = zext i575 %8867 to i576
  store i576 %8880, ptr %628, align 8
  %8881 = zext i575 %8870 to i576
  store i576 %8881, ptr %629, align 8
  %8882 = zext i575 %8873 to i576
  store i576 %8882, ptr %630, align 8
  %8883 = zext i575 %8876 to i576
  store i576 %8883, ptr %631, align 8
  call void @check(ptr noundef @.str.8, i32 noundef 7, ptr noundef byval([72 x i8]) align 8 %625, ptr noundef %8858, ptr noundef byval([72 x i8]) align 8 %626, ptr noundef byval([72 x i8]) align 8 %627, ptr noundef byval([72 x i8]) align 8 %628, ptr noundef byval([72 x i8]) align 8 %629, ptr noundef byval([72 x i8]) align 8 %630, ptr noundef byval([72 x i8]) align 8 %631)
  br label %8884

8884:                                             ; preds = %8777
  br label %8885

8885:                                             ; preds = %8884
  store i128 5, ptr %632, align 8
  %8886 = load i128, ptr %632, align 8
  %8887 = trunc i128 %8886 to i65
  %8888 = call i65 @llvm.ctlz.i65(i65 %8887, i1 false)
  %8889 = trunc i65 %8888 to i32
  store i32 %8889, ptr %633, align 4
  %8890 = getelementptr inbounds i32, ptr %633, i64 1
  %8891 = load i128, ptr %632, align 8
  %8892 = trunc i128 %8891 to i65
  %8893 = xor i65 %8892, -1
  %8894 = call i65 @llvm.ctlz.i65(i65 %8893, i1 false)
  %8895 = trunc i65 %8894 to i32
  store i32 %8895, ptr %8890, align 4
  %8896 = getelementptr inbounds i32, ptr %633, i64 2
  %8897 = load i128, ptr %632, align 8
  %8898 = trunc i128 %8897 to i65
  %8899 = call i65 @llvm.cttz.i65(i65 %8898, i1 false)
  %8900 = trunc i65 %8899 to i32
  store i32 %8900, ptr %8896, align 4
  %8901 = getelementptr inbounds i32, ptr %633, i64 3
  %8902 = load i128, ptr %632, align 8
  %8903 = trunc i128 %8902 to i65
  %8904 = xor i65 %8903, -1
  %8905 = call i65 @llvm.cttz.i65(i65 %8904, i1 false)
  %8906 = trunc i65 %8905 to i32
  store i32 %8906, ptr %8901, align 4
  %8907 = getelementptr inbounds i32, ptr %633, i64 4
  %8908 = load i128, ptr %632, align 8
  %8909 = trunc i128 %8908 to i65
  %8910 = xor i65 %8909, -1
  %8911 = call i65 @llvm.ctlz.i65(i65 %8910, i1 false)
  %8912 = add i65 %8911, 1
  %8913 = icmp eq i65 %8910, 0
  %8914 = select i1 %8913, i65 0, i65 %8912
  %8915 = trunc i65 %8914 to i32
  store i32 %8915, ptr %8907, align 4
  %8916 = getelementptr inbounds i32, ptr %633, i64 5
  %8917 = load i128, ptr %632, align 8
  %8918 = trunc i128 %8917 to i65
  %8919 = call i65 @llvm.ctlz.i65(i65 %8918, i1 false)
  %8920 = add i65 %8919, 1
  %8921 = icmp eq i65 %8918, 0
  %8922 = select i1 %8921, i65 0, i65 %8920
  %8923 = trunc i65 %8922 to i32
  store i32 %8923, ptr %8916, align 4
  %8924 = getelementptr inbounds i32, ptr %633, i64 6
  %8925 = load i128, ptr %632, align 8
  %8926 = trunc i128 %8925 to i65
  %8927 = xor i65 %8926, -1
  %8928 = call i65 @llvm.cttz.i65(i65 %8927, i1 false)
  %8929 = add i65 %8928, 1
  %8930 = icmp eq i65 %8927, 0
  %8931 = select i1 %8930, i65 0, i65 %8929
  %8932 = trunc i65 %8931 to i32
  store i32 %8932, ptr %8924, align 4
  %8933 = getelementptr inbounds i32, ptr %633, i64 7
  %8934 = load i128, ptr %632, align 8
  %8935 = trunc i128 %8934 to i65
  %8936 = call i65 @llvm.cttz.i65(i65 %8935, i1 false)
  %8937 = add i65 %8936, 1
  %8938 = icmp eq i65 %8935, 0
  %8939 = select i1 %8938, i65 0, i65 %8937
  %8940 = trunc i65 %8939 to i32
  store i32 %8940, ptr %8933, align 4
  %8941 = getelementptr inbounds i32, ptr %633, i64 8
  %8942 = load i128, ptr %632, align 8
  %8943 = trunc i128 %8942 to i65
  %8944 = call i65 @llvm.ctpop.i65(i65 %8943)
  %8945 = sub i65 65, %8944
  %8946 = trunc i65 %8945 to i32
  store i32 %8946, ptr %8941, align 4
  %8947 = getelementptr inbounds i32, ptr %633, i64 9
  %8948 = load i128, ptr %632, align 8
  %8949 = trunc i128 %8948 to i65
  %8950 = call i65 @llvm.ctpop.i65(i65 %8949)
  %8951 = trunc i65 %8950 to i32
  store i32 %8951, ptr %8947, align 4
  %8952 = getelementptr inbounds i32, ptr %633, i64 10
  %8953 = load i128, ptr %632, align 8
  %8954 = trunc i128 %8953 to i65
  %8955 = call i65 @llvm.ctpop.i65(i65 %8954)
  %8956 = icmp eq i65 %8955, 1
  %8957 = zext i1 %8956 to i32
  store i32 %8957, ptr %8952, align 4
  %8958 = getelementptr inbounds i32, ptr %633, i64 11
  %8959 = load i128, ptr %632, align 8
  %8960 = trunc i128 %8959 to i65
  %8961 = call i65 @llvm.ctlz.i65(i65 %8960, i1 false)
  %8962 = sub i65 65, %8961
  %8963 = trunc i65 %8962 to i32
  store i32 %8963, ptr %8958, align 4
  %8964 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 0
  %8965 = load i32, ptr %8964, align 16
  %8966 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 1
  %8967 = load i32, ptr %8966, align 4
  %8968 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 2
  %8969 = load i32, ptr %8968, align 8
  %8970 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 3
  %8971 = load i32, ptr %8970, align 4
  %8972 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 4
  %8973 = load i32, ptr %8972, align 16
  %8974 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 5
  %8975 = load i32, ptr %8974, align 4
  %8976 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 6
  %8977 = load i32, ptr %8976, align 8
  %8978 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 7
  %8979 = load i32, ptr %8978, align 4
  %8980 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 8
  %8981 = load i32, ptr %8980, align 16
  %8982 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 9
  %8983 = load i32, ptr %8982, align 4
  %8984 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 10
  %8985 = load i32, ptr %8984, align 8
  %8986 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 11
  %8987 = load i32, ptr %8986, align 4
  %8988 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef %8965, i32 noundef %8967, i32 noundef %8969, i32 noundef %8971, i32 noundef %8973, i32 noundef %8975, i32 noundef %8977, i32 noundef %8979, i32 noundef %8981, i32 noundef %8983, i32 noundef %8985, i32 noundef %8987)
  %8989 = load i128, ptr %632, align 8
  %8990 = trunc i128 %8989 to i65
  %8991 = call i65 @llvm.ctlz.i65(i65 %8990, i1 true)
  %8992 = sub i65 64, %8991
  %8993 = shl i65 1, %8992
  %8994 = icmp eq i65 %8990, 0
  %8995 = select i1 %8994, i65 0, i65 %8993
  %8996 = zext i65 %8995 to i128
  store i128 %8996, ptr %634, align 8
  %8997 = load i128, ptr %632, align 8
  %8998 = trunc i128 %8997 to i65
  %8999 = icmp ule i65 %8998, 1
  br i1 %8999, label %9005, label %9000

9000:                                             ; preds = %8885
  %9001 = sub i65 %8998, 1
  %9002 = call i65 @llvm.ctlz.i65(i65 %9001, i1 false)
  %9003 = sub i65 64, %9002
  %9004 = shl i65 2, %9003
  br label %9005

9005:                                             ; preds = %9000, %8885
  %9006 = phi i65 [ 1, %8885 ], [ %9004, %9000 ]
  %9007 = zext i65 %9006 to i128
  store i128 %9007, ptr %635, align 8
  %9008 = load i128, ptr %632, align 8
  %9009 = trunc i128 %9008 to i65
  %9010 = call i65 @llvm.fshl.i65(i65 %9009, i65 %9009, i65 3)
  %9011 = zext i65 %9010 to i128
  store i128 %9011, ptr %636, align 8
  %9012 = load i128, ptr %632, align 8
  %9013 = trunc i128 %9012 to i65
  %9014 = call i65 @llvm.fshr.i65(i65 %9013, i65 %9013, i65 3)
  %9015 = zext i65 %9014 to i128
  store i128 %9015, ptr %637, align 8
  %9016 = load i128, ptr %632, align 8
  %9017 = trunc i128 %9016 to i65
  %9018 = call i65 @llvm.fshl.i65(i65 %9017, i65 %9017, i65 0)
  %9019 = zext i65 %9018 to i128
  store i128 %9019, ptr %638, align 8
  %9020 = load i128, ptr %632, align 8
  %9021 = trunc i128 %9020 to i65
  %9022 = call i65 @llvm.fshl.i65(i65 %9021, i65 %9021, i65 25)
  %9023 = zext i65 %9022 to i128
  store i128 %9023, ptr %639, align 8
  %9024 = load i128, ptr %634, align 8
  %9025 = trunc i128 %9024 to i65
  %9026 = zext i65 %9025 to i256
  %9027 = lshr i256 %9026, 128
  %9028 = trunc i256 %9027 to i64
  %9029 = load i128, ptr %634, align 8
  %9030 = trunc i128 %9029 to i65
  %9031 = zext i65 %9030 to i256
  %9032 = lshr i256 %9031, 64
  %9033 = trunc i256 %9032 to i64
  %9034 = load i128, ptr %634, align 8
  %9035 = trunc i128 %9034 to i65
  %9036 = trunc i65 %9035 to i64
  %9037 = load i128, ptr %635, align 8
  %9038 = trunc i128 %9037 to i65
  %9039 = zext i65 %9038 to i256
  %9040 = lshr i256 %9039, 128
  %9041 = trunc i256 %9040 to i64
  %9042 = load i128, ptr %635, align 8
  %9043 = trunc i128 %9042 to i65
  %9044 = zext i65 %9043 to i256
  %9045 = lshr i256 %9044, 64
  %9046 = trunc i256 %9045 to i64
  %9047 = load i128, ptr %635, align 8
  %9048 = trunc i128 %9047 to i65
  %9049 = trunc i65 %9048 to i64
  %9050 = load i128, ptr %636, align 8
  %9051 = trunc i128 %9050 to i65
  %9052 = zext i65 %9051 to i256
  %9053 = lshr i256 %9052, 128
  %9054 = trunc i256 %9053 to i64
  %9055 = load i128, ptr %636, align 8
  %9056 = trunc i128 %9055 to i65
  %9057 = zext i65 %9056 to i256
  %9058 = lshr i256 %9057, 64
  %9059 = trunc i256 %9058 to i64
  %9060 = load i128, ptr %636, align 8
  %9061 = trunc i128 %9060 to i65
  %9062 = trunc i65 %9061 to i64
  %9063 = load i128, ptr %637, align 8
  %9064 = trunc i128 %9063 to i65
  %9065 = zext i65 %9064 to i256
  %9066 = lshr i256 %9065, 128
  %9067 = trunc i256 %9066 to i64
  %9068 = load i128, ptr %637, align 8
  %9069 = trunc i128 %9068 to i65
  %9070 = zext i65 %9069 to i256
  %9071 = lshr i256 %9070, 64
  %9072 = trunc i256 %9071 to i64
  %9073 = load i128, ptr %637, align 8
  %9074 = trunc i128 %9073 to i65
  %9075 = trunc i65 %9074 to i64
  %9076 = load i128, ptr %638, align 8
  %9077 = trunc i128 %9076 to i65
  %9078 = trunc i65 %9077 to i64
  %9079 = load i128, ptr %639, align 8
  %9080 = trunc i128 %9079 to i65
  %9081 = trunc i65 %9080 to i64
  %9082 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %9028, i64 noundef %9033, i64 noundef %9036, i64 noundef %9041, i64 noundef %9046, i64 noundef %9049, i64 noundef %9054, i64 noundef %9059, i64 noundef %9062, i64 noundef %9067, i64 noundef %9072, i64 noundef %9075, i64 noundef %9078, i64 noundef %9081)
  %9083 = load i128, ptr %632, align 8
  %9084 = trunc i128 %9083 to i65
  %9085 = zext i65 %9084 to i575
  %9086 = getelementptr inbounds [12 x i32], ptr %633, i64 0, i64 0
  %9087 = load i128, ptr %634, align 8
  %9088 = trunc i128 %9087 to i65
  %9089 = zext i65 %9088 to i575
  %9090 = load i128, ptr %635, align 8
  %9091 = trunc i128 %9090 to i65
  %9092 = zext i65 %9091 to i575
  %9093 = load i128, ptr %636, align 8
  %9094 = trunc i128 %9093 to i65
  %9095 = zext i65 %9094 to i575
  %9096 = load i128, ptr %637, align 8
  %9097 = trunc i128 %9096 to i65
  %9098 = zext i65 %9097 to i575
  %9099 = load i128, ptr %638, align 8
  %9100 = trunc i128 %9099 to i65
  %9101 = zext i65 %9100 to i575
  %9102 = load i128, ptr %639, align 8
  %9103 = trunc i128 %9102 to i65
  %9104 = zext i65 %9103 to i575
  %9105 = zext i575 %9085 to i576
  store i576 %9105, ptr %640, align 8
  %9106 = zext i575 %9089 to i576
  store i576 %9106, ptr %641, align 8
  %9107 = zext i575 %9092 to i576
  store i576 %9107, ptr %642, align 8
  %9108 = zext i575 %9095 to i576
  store i576 %9108, ptr %643, align 8
  %9109 = zext i575 %9098 to i576
  store i576 %9109, ptr %644, align 8
  %9110 = zext i575 %9101 to i576
  store i576 %9110, ptr %645, align 8
  %9111 = zext i575 %9104 to i576
  store i576 %9111, ptr %646, align 8
  call void @check(ptr noundef @.str.9, i32 noundef 65, ptr noundef byval([72 x i8]) align 8 %640, ptr noundef %9086, ptr noundef byval([72 x i8]) align 8 %641, ptr noundef byval([72 x i8]) align 8 %642, ptr noundef byval([72 x i8]) align 8 %643, ptr noundef byval([72 x i8]) align 8 %644, ptr noundef byval([72 x i8]) align 8 %645, ptr noundef byval([72 x i8]) align 8 %646)
  br label %9112

9112:                                             ; preds = %9005
  br label %9113

9113:                                             ; preds = %9112
  store i192 5, ptr %647, align 8
  %9114 = load i192, ptr %647, align 8
  %9115 = trunc i192 %9114 to i129
  %9116 = call i129 @llvm.ctlz.i129(i129 %9115, i1 false)
  %9117 = trunc i129 %9116 to i32
  store i32 %9117, ptr %648, align 4
  %9118 = getelementptr inbounds i32, ptr %648, i64 1
  %9119 = load i192, ptr %647, align 8
  %9120 = trunc i192 %9119 to i129
  %9121 = xor i129 %9120, -1
  %9122 = call i129 @llvm.ctlz.i129(i129 %9121, i1 false)
  %9123 = trunc i129 %9122 to i32
  store i32 %9123, ptr %9118, align 4
  %9124 = getelementptr inbounds i32, ptr %648, i64 2
  %9125 = load i192, ptr %647, align 8
  %9126 = trunc i192 %9125 to i129
  %9127 = call i129 @llvm.cttz.i129(i129 %9126, i1 false)
  %9128 = trunc i129 %9127 to i32
  store i32 %9128, ptr %9124, align 4
  %9129 = getelementptr inbounds i32, ptr %648, i64 3
  %9130 = load i192, ptr %647, align 8
  %9131 = trunc i192 %9130 to i129
  %9132 = xor i129 %9131, -1
  %9133 = call i129 @llvm.cttz.i129(i129 %9132, i1 false)
  %9134 = trunc i129 %9133 to i32
  store i32 %9134, ptr %9129, align 4
  %9135 = getelementptr inbounds i32, ptr %648, i64 4
  %9136 = load i192, ptr %647, align 8
  %9137 = trunc i192 %9136 to i129
  %9138 = xor i129 %9137, -1
  %9139 = call i129 @llvm.ctlz.i129(i129 %9138, i1 false)
  %9140 = add i129 %9139, 1
  %9141 = icmp eq i129 %9138, 0
  %9142 = select i1 %9141, i129 0, i129 %9140
  %9143 = trunc i129 %9142 to i32
  store i32 %9143, ptr %9135, align 4
  %9144 = getelementptr inbounds i32, ptr %648, i64 5
  %9145 = load i192, ptr %647, align 8
  %9146 = trunc i192 %9145 to i129
  %9147 = call i129 @llvm.ctlz.i129(i129 %9146, i1 false)
  %9148 = add i129 %9147, 1
  %9149 = icmp eq i129 %9146, 0
  %9150 = select i1 %9149, i129 0, i129 %9148
  %9151 = trunc i129 %9150 to i32
  store i32 %9151, ptr %9144, align 4
  %9152 = getelementptr inbounds i32, ptr %648, i64 6
  %9153 = load i192, ptr %647, align 8
  %9154 = trunc i192 %9153 to i129
  %9155 = xor i129 %9154, -1
  %9156 = call i129 @llvm.cttz.i129(i129 %9155, i1 false)
  %9157 = add i129 %9156, 1
  %9158 = icmp eq i129 %9155, 0
  %9159 = select i1 %9158, i129 0, i129 %9157
  %9160 = trunc i129 %9159 to i32
  store i32 %9160, ptr %9152, align 4
  %9161 = getelementptr inbounds i32, ptr %648, i64 7
  %9162 = load i192, ptr %647, align 8
  %9163 = trunc i192 %9162 to i129
  %9164 = call i129 @llvm.cttz.i129(i129 %9163, i1 false)
  %9165 = add i129 %9164, 1
  %9166 = icmp eq i129 %9163, 0
  %9167 = select i1 %9166, i129 0, i129 %9165
  %9168 = trunc i129 %9167 to i32
  store i32 %9168, ptr %9161, align 4
  %9169 = getelementptr inbounds i32, ptr %648, i64 8
  %9170 = load i192, ptr %647, align 8
  %9171 = trunc i192 %9170 to i129
  %9172 = call i129 @llvm.ctpop.i129(i129 %9171)
  %9173 = sub i129 129, %9172
  %9174 = trunc i129 %9173 to i32
  store i32 %9174, ptr %9169, align 4
  %9175 = getelementptr inbounds i32, ptr %648, i64 9
  %9176 = load i192, ptr %647, align 8
  %9177 = trunc i192 %9176 to i129
  %9178 = call i129 @llvm.ctpop.i129(i129 %9177)
  %9179 = trunc i129 %9178 to i32
  store i32 %9179, ptr %9175, align 4
  %9180 = getelementptr inbounds i32, ptr %648, i64 10
  %9181 = load i192, ptr %647, align 8
  %9182 = trunc i192 %9181 to i129
  %9183 = call i129 @llvm.ctpop.i129(i129 %9182)
  %9184 = icmp eq i129 %9183, 1
  %9185 = zext i1 %9184 to i32
  store i32 %9185, ptr %9180, align 4
  %9186 = getelementptr inbounds i32, ptr %648, i64 11
  %9187 = load i192, ptr %647, align 8
  %9188 = trunc i192 %9187 to i129
  %9189 = call i129 @llvm.ctlz.i129(i129 %9188, i1 false)
  %9190 = sub i129 129, %9189
  %9191 = trunc i129 %9190 to i32
  store i32 %9191, ptr %9186, align 4
  %9192 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 0
  %9193 = load i32, ptr %9192, align 16
  %9194 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 1
  %9195 = load i32, ptr %9194, align 4
  %9196 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 2
  %9197 = load i32, ptr %9196, align 8
  %9198 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 3
  %9199 = load i32, ptr %9198, align 4
  %9200 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 4
  %9201 = load i32, ptr %9200, align 16
  %9202 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 5
  %9203 = load i32, ptr %9202, align 4
  %9204 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 6
  %9205 = load i32, ptr %9204, align 8
  %9206 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 7
  %9207 = load i32, ptr %9206, align 4
  %9208 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 8
  %9209 = load i32, ptr %9208, align 16
  %9210 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 9
  %9211 = load i32, ptr %9210, align 4
  %9212 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 10
  %9213 = load i32, ptr %9212, align 8
  %9214 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 11
  %9215 = load i32, ptr %9214, align 4
  %9216 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %9193, i32 noundef %9195, i32 noundef %9197, i32 noundef %9199, i32 noundef %9201, i32 noundef %9203, i32 noundef %9205, i32 noundef %9207, i32 noundef %9209, i32 noundef %9211, i32 noundef %9213, i32 noundef %9215)
  %9217 = load i192, ptr %647, align 8
  %9218 = trunc i192 %9217 to i129
  %9219 = call i129 @llvm.ctlz.i129(i129 %9218, i1 true)
  %9220 = sub i129 128, %9219
  %9221 = shl i129 1, %9220
  %9222 = icmp eq i129 %9218, 0
  %9223 = select i1 %9222, i129 0, i129 %9221
  %9224 = zext i129 %9223 to i192
  store i192 %9224, ptr %649, align 8
  %9225 = load i192, ptr %647, align 8
  %9226 = trunc i192 %9225 to i129
  %9227 = icmp ule i129 %9226, 1
  br i1 %9227, label %9233, label %9228

9228:                                             ; preds = %9113
  %9229 = sub i129 %9226, 1
  %9230 = call i129 @llvm.ctlz.i129(i129 %9229, i1 false)
  %9231 = sub i129 128, %9230
  %9232 = shl i129 2, %9231
  br label %9233

9233:                                             ; preds = %9228, %9113
  %9234 = phi i129 [ 1, %9113 ], [ %9232, %9228 ]
  %9235 = zext i129 %9234 to i192
  store i192 %9235, ptr %650, align 8
  %9236 = load i192, ptr %647, align 8
  %9237 = trunc i192 %9236 to i129
  %9238 = call i129 @llvm.fshl.i129(i129 %9237, i129 %9237, i129 3)
  %9239 = zext i129 %9238 to i192
  store i192 %9239, ptr %651, align 8
  %9240 = load i192, ptr %647, align 8
  %9241 = trunc i192 %9240 to i129
  %9242 = call i129 @llvm.fshr.i129(i129 %9241, i129 %9241, i129 3)
  %9243 = zext i129 %9242 to i192
  store i192 %9243, ptr %652, align 8
  %9244 = load i192, ptr %647, align 8
  %9245 = trunc i192 %9244 to i129
  %9246 = call i129 @llvm.fshl.i129(i129 %9245, i129 %9245, i129 0)
  %9247 = zext i129 %9246 to i192
  store i192 %9247, ptr %653, align 8
  %9248 = load i192, ptr %647, align 8
  %9249 = trunc i192 %9248 to i129
  %9250 = call i129 @llvm.fshl.i129(i129 %9249, i129 %9249, i129 97)
  %9251 = zext i129 %9250 to i192
  store i192 %9251, ptr %654, align 8
  %9252 = load i192, ptr %649, align 8
  %9253 = trunc i192 %9252 to i129
  %9254 = zext i129 %9253 to i256
  %9255 = lshr i256 %9254, 128
  %9256 = trunc i256 %9255 to i64
  %9257 = load i192, ptr %649, align 8
  %9258 = trunc i192 %9257 to i129
  %9259 = zext i129 %9258 to i256
  %9260 = lshr i256 %9259, 64
  %9261 = trunc i256 %9260 to i64
  %9262 = load i192, ptr %649, align 8
  %9263 = trunc i192 %9262 to i129
  %9264 = trunc i129 %9263 to i64
  %9265 = load i192, ptr %650, align 8
  %9266 = trunc i192 %9265 to i129
  %9267 = zext i129 %9266 to i256
  %9268 = lshr i256 %9267, 128
  %9269 = trunc i256 %9268 to i64
  %9270 = load i192, ptr %650, align 8
  %9271 = trunc i192 %9270 to i129
  %9272 = zext i129 %9271 to i256
  %9273 = lshr i256 %9272, 64
  %9274 = trunc i256 %9273 to i64
  %9275 = load i192, ptr %650, align 8
  %9276 = trunc i192 %9275 to i129
  %9277 = trunc i129 %9276 to i64
  %9278 = load i192, ptr %651, align 8
  %9279 = trunc i192 %9278 to i129
  %9280 = zext i129 %9279 to i256
  %9281 = lshr i256 %9280, 128
  %9282 = trunc i256 %9281 to i64
  %9283 = load i192, ptr %651, align 8
  %9284 = trunc i192 %9283 to i129
  %9285 = zext i129 %9284 to i256
  %9286 = lshr i256 %9285, 64
  %9287 = trunc i256 %9286 to i64
  %9288 = load i192, ptr %651, align 8
  %9289 = trunc i192 %9288 to i129
  %9290 = trunc i129 %9289 to i64
  %9291 = load i192, ptr %652, align 8
  %9292 = trunc i192 %9291 to i129
  %9293 = zext i129 %9292 to i256
  %9294 = lshr i256 %9293, 128
  %9295 = trunc i256 %9294 to i64
  %9296 = load i192, ptr %652, align 8
  %9297 = trunc i192 %9296 to i129
  %9298 = zext i129 %9297 to i256
  %9299 = lshr i256 %9298, 64
  %9300 = trunc i256 %9299 to i64
  %9301 = load i192, ptr %652, align 8
  %9302 = trunc i192 %9301 to i129
  %9303 = trunc i129 %9302 to i64
  %9304 = load i192, ptr %653, align 8
  %9305 = trunc i192 %9304 to i129
  %9306 = trunc i129 %9305 to i64
  %9307 = load i192, ptr %654, align 8
  %9308 = trunc i192 %9307 to i129
  %9309 = trunc i129 %9308 to i64
  %9310 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %9256, i64 noundef %9261, i64 noundef %9264, i64 noundef %9269, i64 noundef %9274, i64 noundef %9277, i64 noundef %9282, i64 noundef %9287, i64 noundef %9290, i64 noundef %9295, i64 noundef %9300, i64 noundef %9303, i64 noundef %9306, i64 noundef %9309)
  %9311 = load i192, ptr %647, align 8
  %9312 = trunc i192 %9311 to i129
  %9313 = zext i129 %9312 to i575
  %9314 = getelementptr inbounds [12 x i32], ptr %648, i64 0, i64 0
  %9315 = load i192, ptr %649, align 8
  %9316 = trunc i192 %9315 to i129
  %9317 = zext i129 %9316 to i575
  %9318 = load i192, ptr %650, align 8
  %9319 = trunc i192 %9318 to i129
  %9320 = zext i129 %9319 to i575
  %9321 = load i192, ptr %651, align 8
  %9322 = trunc i192 %9321 to i129
  %9323 = zext i129 %9322 to i575
  %9324 = load i192, ptr %652, align 8
  %9325 = trunc i192 %9324 to i129
  %9326 = zext i129 %9325 to i575
  %9327 = load i192, ptr %653, align 8
  %9328 = trunc i192 %9327 to i129
  %9329 = zext i129 %9328 to i575
  %9330 = load i192, ptr %654, align 8
  %9331 = trunc i192 %9330 to i129
  %9332 = zext i129 %9331 to i575
  %9333 = zext i575 %9313 to i576
  store i576 %9333, ptr %655, align 8
  %9334 = zext i575 %9317 to i576
  store i576 %9334, ptr %656, align 8
  %9335 = zext i575 %9320 to i576
  store i576 %9335, ptr %657, align 8
  %9336 = zext i575 %9323 to i576
  store i576 %9336, ptr %658, align 8
  %9337 = zext i575 %9326 to i576
  store i576 %9337, ptr %659, align 8
  %9338 = zext i575 %9329 to i576
  store i576 %9338, ptr %660, align 8
  %9339 = zext i575 %9332 to i576
  store i576 %9339, ptr %661, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %655, ptr noundef %9314, ptr noundef byval([72 x i8]) align 8 %656, ptr noundef byval([72 x i8]) align 8 %657, ptr noundef byval([72 x i8]) align 8 %658, ptr noundef byval([72 x i8]) align 8 %659, ptr noundef byval([72 x i8]) align 8 %660, ptr noundef byval([72 x i8]) align 8 %661)
  br label %9340

9340:                                             ; preds = %9233
  br label %9341

9341:                                             ; preds = %9340
  store i256 5, ptr %662, align 8
  %9342 = load i256, ptr %662, align 8
  %9343 = call i256 @llvm.ctlz.i256(i256 %9342, i1 false)
  %9344 = trunc i256 %9343 to i32
  store i32 %9344, ptr %663, align 4
  %9345 = getelementptr inbounds i32, ptr %663, i64 1
  %9346 = load i256, ptr %662, align 8
  %9347 = xor i256 %9346, -1
  %9348 = call i256 @llvm.ctlz.i256(i256 %9347, i1 false)
  %9349 = trunc i256 %9348 to i32
  store i32 %9349, ptr %9345, align 4
  %9350 = getelementptr inbounds i32, ptr %663, i64 2
  %9351 = load i256, ptr %662, align 8
  %9352 = call i256 @llvm.cttz.i256(i256 %9351, i1 false)
  %9353 = trunc i256 %9352 to i32
  store i32 %9353, ptr %9350, align 4
  %9354 = getelementptr inbounds i32, ptr %663, i64 3
  %9355 = load i256, ptr %662, align 8
  %9356 = xor i256 %9355, -1
  %9357 = call i256 @llvm.cttz.i256(i256 %9356, i1 false)
  %9358 = trunc i256 %9357 to i32
  store i32 %9358, ptr %9354, align 4
  %9359 = getelementptr inbounds i32, ptr %663, i64 4
  %9360 = load i256, ptr %662, align 8
  %9361 = xor i256 %9360, -1
  %9362 = call i256 @llvm.ctlz.i256(i256 %9361, i1 false)
  %9363 = add i256 %9362, 1
  %9364 = icmp eq i256 %9361, 0
  %9365 = select i1 %9364, i256 0, i256 %9363
  %9366 = trunc i256 %9365 to i32
  store i32 %9366, ptr %9359, align 4
  %9367 = getelementptr inbounds i32, ptr %663, i64 5
  %9368 = load i256, ptr %662, align 8
  %9369 = call i256 @llvm.ctlz.i256(i256 %9368, i1 false)
  %9370 = add i256 %9369, 1
  %9371 = icmp eq i256 %9368, 0
  %9372 = select i1 %9371, i256 0, i256 %9370
  %9373 = trunc i256 %9372 to i32
  store i32 %9373, ptr %9367, align 4
  %9374 = getelementptr inbounds i32, ptr %663, i64 6
  %9375 = load i256, ptr %662, align 8
  %9376 = xor i256 %9375, -1
  %9377 = call i256 @llvm.cttz.i256(i256 %9376, i1 false)
  %9378 = add i256 %9377, 1
  %9379 = icmp eq i256 %9376, 0
  %9380 = select i1 %9379, i256 0, i256 %9378
  %9381 = trunc i256 %9380 to i32
  store i32 %9381, ptr %9374, align 4
  %9382 = getelementptr inbounds i32, ptr %663, i64 7
  %9383 = load i256, ptr %662, align 8
  %9384 = call i256 @llvm.cttz.i256(i256 %9383, i1 false)
  %9385 = add i256 %9384, 1
  %9386 = icmp eq i256 %9383, 0
  %9387 = select i1 %9386, i256 0, i256 %9385
  %9388 = trunc i256 %9387 to i32
  store i32 %9388, ptr %9382, align 4
  %9389 = getelementptr inbounds i32, ptr %663, i64 8
  %9390 = load i256, ptr %662, align 8
  %9391 = call i256 @llvm.ctpop.i256(i256 %9390)
  %9392 = sub i256 256, %9391
  %9393 = trunc i256 %9392 to i32
  store i32 %9393, ptr %9389, align 4
  %9394 = getelementptr inbounds i32, ptr %663, i64 9
  %9395 = load i256, ptr %662, align 8
  %9396 = call i256 @llvm.ctpop.i256(i256 %9395)
  %9397 = trunc i256 %9396 to i32
  store i32 %9397, ptr %9394, align 4
  %9398 = getelementptr inbounds i32, ptr %663, i64 10
  %9399 = load i256, ptr %662, align 8
  %9400 = call i256 @llvm.ctpop.i256(i256 %9399)
  %9401 = icmp eq i256 %9400, 1
  %9402 = zext i1 %9401 to i32
  store i32 %9402, ptr %9398, align 4
  %9403 = getelementptr inbounds i32, ptr %663, i64 11
  %9404 = load i256, ptr %662, align 8
  %9405 = call i256 @llvm.ctlz.i256(i256 %9404, i1 false)
  %9406 = sub i256 256, %9405
  %9407 = trunc i256 %9406 to i32
  store i32 %9407, ptr %9403, align 4
  %9408 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 0
  %9409 = load i32, ptr %9408, align 16
  %9410 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 1
  %9411 = load i32, ptr %9410, align 4
  %9412 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 2
  %9413 = load i32, ptr %9412, align 8
  %9414 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 3
  %9415 = load i32, ptr %9414, align 4
  %9416 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 4
  %9417 = load i32, ptr %9416, align 16
  %9418 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 5
  %9419 = load i32, ptr %9418, align 4
  %9420 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 6
  %9421 = load i32, ptr %9420, align 8
  %9422 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 7
  %9423 = load i32, ptr %9422, align 4
  %9424 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 8
  %9425 = load i32, ptr %9424, align 16
  %9426 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 9
  %9427 = load i32, ptr %9426, align 4
  %9428 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 10
  %9429 = load i32, ptr %9428, align 8
  %9430 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 11
  %9431 = load i32, ptr %9430, align 4
  %9432 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %9409, i32 noundef %9411, i32 noundef %9413, i32 noundef %9415, i32 noundef %9417, i32 noundef %9419, i32 noundef %9421, i32 noundef %9423, i32 noundef %9425, i32 noundef %9427, i32 noundef %9429, i32 noundef %9431)
  %9433 = load i256, ptr %662, align 8
  %9434 = call i256 @llvm.ctlz.i256(i256 %9433, i1 true)
  %9435 = sub i256 255, %9434
  %9436 = shl i256 1, %9435
  %9437 = icmp eq i256 %9433, 0
  %9438 = select i1 %9437, i256 0, i256 %9436
  store i256 %9438, ptr %664, align 8
  %9439 = load i256, ptr %662, align 8
  %9440 = icmp ule i256 %9439, 1
  br i1 %9440, label %9446, label %9441

9441:                                             ; preds = %9341
  %9442 = sub i256 %9439, 1
  %9443 = call i256 @llvm.ctlz.i256(i256 %9442, i1 false)
  %9444 = sub i256 255, %9443
  %9445 = shl i256 2, %9444
  br label %9446

9446:                                             ; preds = %9441, %9341
  %9447 = phi i256 [ 1, %9341 ], [ %9445, %9441 ]
  store i256 %9447, ptr %665, align 8
  %9448 = load i256, ptr %662, align 8
  %9449 = call i256 @llvm.fshl.i256(i256 %9448, i256 %9448, i256 3)
  store i256 %9449, ptr %666, align 8
  %9450 = load i256, ptr %662, align 8
  %9451 = call i256 @llvm.fshr.i256(i256 %9450, i256 %9450, i256 3)
  store i256 %9451, ptr %667, align 8
  %9452 = load i256, ptr %662, align 8
  %9453 = call i256 @llvm.fshl.i256(i256 %9452, i256 %9452, i256 0)
  store i256 %9453, ptr %668, align 8
  %9454 = load i256, ptr %662, align 8
  %9455 = call i256 @llvm.fshl.i256(i256 %9454, i256 %9454, i256 232)
  store i256 %9455, ptr %669, align 8
  %9456 = load i256, ptr %664, align 8
  %9457 = lshr i256 %9456, 128
  %9458 = trunc i256 %9457 to i64
  %9459 = load i256, ptr %664, align 8
  %9460 = lshr i256 %9459, 64
  %9461 = trunc i256 %9460 to i64
  %9462 = load i256, ptr %664, align 8
  %9463 = trunc i256 %9462 to i64
  %9464 = load i256, ptr %665, align 8
  %9465 = lshr i256 %9464, 128
  %9466 = trunc i256 %9465 to i64
  %9467 = load i256, ptr %665, align 8
  %9468 = lshr i256 %9467, 64
  %9469 = trunc i256 %9468 to i64
  %9470 = load i256, ptr %665, align 8
  %9471 = trunc i256 %9470 to i64
  %9472 = load i256, ptr %666, align 8
  %9473 = lshr i256 %9472, 128
  %9474 = trunc i256 %9473 to i64
  %9475 = load i256, ptr %666, align 8
  %9476 = lshr i256 %9475, 64
  %9477 = trunc i256 %9476 to i64
  %9478 = load i256, ptr %666, align 8
  %9479 = trunc i256 %9478 to i64
  %9480 = load i256, ptr %667, align 8
  %9481 = lshr i256 %9480, 128
  %9482 = trunc i256 %9481 to i64
  %9483 = load i256, ptr %667, align 8
  %9484 = lshr i256 %9483, 64
  %9485 = trunc i256 %9484 to i64
  %9486 = load i256, ptr %667, align 8
  %9487 = trunc i256 %9486 to i64
  %9488 = load i256, ptr %668, align 8
  %9489 = trunc i256 %9488 to i64
  %9490 = load i256, ptr %669, align 8
  %9491 = trunc i256 %9490 to i64
  %9492 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %9458, i64 noundef %9461, i64 noundef %9463, i64 noundef %9466, i64 noundef %9469, i64 noundef %9471, i64 noundef %9474, i64 noundef %9477, i64 noundef %9479, i64 noundef %9482, i64 noundef %9485, i64 noundef %9487, i64 noundef %9489, i64 noundef %9491)
  %9493 = load i256, ptr %662, align 8
  %9494 = zext i256 %9493 to i575
  %9495 = getelementptr inbounds [12 x i32], ptr %663, i64 0, i64 0
  %9496 = load i256, ptr %664, align 8
  %9497 = zext i256 %9496 to i575
  %9498 = load i256, ptr %665, align 8
  %9499 = zext i256 %9498 to i575
  %9500 = load i256, ptr %666, align 8
  %9501 = zext i256 %9500 to i575
  %9502 = load i256, ptr %667, align 8
  %9503 = zext i256 %9502 to i575
  %9504 = load i256, ptr %668, align 8
  %9505 = zext i256 %9504 to i575
  %9506 = load i256, ptr %669, align 8
  %9507 = zext i256 %9506 to i575
  %9508 = zext i575 %9494 to i576
  store i576 %9508, ptr %670, align 8
  %9509 = zext i575 %9497 to i576
  store i576 %9509, ptr %671, align 8
  %9510 = zext i575 %9499 to i576
  store i576 %9510, ptr %672, align 8
  %9511 = zext i575 %9501 to i576
  store i576 %9511, ptr %673, align 8
  %9512 = zext i575 %9503 to i576
  store i576 %9512, ptr %674, align 8
  %9513 = zext i575 %9505 to i576
  store i576 %9513, ptr %675, align 8
  %9514 = zext i575 %9507 to i576
  store i576 %9514, ptr %676, align 8
  call void @check(ptr noundef @.str.11, i32 noundef 256, ptr noundef byval([72 x i8]) align 8 %670, ptr noundef %9495, ptr noundef byval([72 x i8]) align 8 %671, ptr noundef byval([72 x i8]) align 8 %672, ptr noundef byval([72 x i8]) align 8 %673, ptr noundef byval([72 x i8]) align 8 %674, ptr noundef byval([72 x i8]) align 8 %675, ptr noundef byval([72 x i8]) align 8 %676)
  br label %9515

9515:                                             ; preds = %9446
  store i192 1, ptr %677, align 8
  %9516 = load i192, ptr %677, align 8
  %9517 = trunc i192 %9516 to i129
  %9518 = shl i129 %9517, 128
  %9519 = zext i129 %9518 to i192
  store i192 %9519, ptr %677, align 8
  br label %9520

9520:                                             ; preds = %9515
  %9521 = load i192, ptr %677, align 8
  %9522 = trunc i192 %9521 to i129
  %9523 = zext i129 %9522 to i192
  store i192 %9523, ptr %678, align 8
  %9524 = load i192, ptr %678, align 8
  %9525 = trunc i192 %9524 to i129
  %9526 = call i129 @llvm.ctlz.i129(i129 %9525, i1 false)
  %9527 = trunc i129 %9526 to i32
  store i32 %9527, ptr %679, align 4
  %9528 = getelementptr inbounds i32, ptr %679, i64 1
  %9529 = load i192, ptr %678, align 8
  %9530 = trunc i192 %9529 to i129
  %9531 = xor i129 %9530, -1
  %9532 = call i129 @llvm.ctlz.i129(i129 %9531, i1 false)
  %9533 = trunc i129 %9532 to i32
  store i32 %9533, ptr %9528, align 4
  %9534 = getelementptr inbounds i32, ptr %679, i64 2
  %9535 = load i192, ptr %678, align 8
  %9536 = trunc i192 %9535 to i129
  %9537 = call i129 @llvm.cttz.i129(i129 %9536, i1 false)
  %9538 = trunc i129 %9537 to i32
  store i32 %9538, ptr %9534, align 4
  %9539 = getelementptr inbounds i32, ptr %679, i64 3
  %9540 = load i192, ptr %678, align 8
  %9541 = trunc i192 %9540 to i129
  %9542 = xor i129 %9541, -1
  %9543 = call i129 @llvm.cttz.i129(i129 %9542, i1 false)
  %9544 = trunc i129 %9543 to i32
  store i32 %9544, ptr %9539, align 4
  %9545 = getelementptr inbounds i32, ptr %679, i64 4
  %9546 = load i192, ptr %678, align 8
  %9547 = trunc i192 %9546 to i129
  %9548 = xor i129 %9547, -1
  %9549 = call i129 @llvm.ctlz.i129(i129 %9548, i1 false)
  %9550 = add i129 %9549, 1
  %9551 = icmp eq i129 %9548, 0
  %9552 = select i1 %9551, i129 0, i129 %9550
  %9553 = trunc i129 %9552 to i32
  store i32 %9553, ptr %9545, align 4
  %9554 = getelementptr inbounds i32, ptr %679, i64 5
  %9555 = load i192, ptr %678, align 8
  %9556 = trunc i192 %9555 to i129
  %9557 = call i129 @llvm.ctlz.i129(i129 %9556, i1 false)
  %9558 = add i129 %9557, 1
  %9559 = icmp eq i129 %9556, 0
  %9560 = select i1 %9559, i129 0, i129 %9558
  %9561 = trunc i129 %9560 to i32
  store i32 %9561, ptr %9554, align 4
  %9562 = getelementptr inbounds i32, ptr %679, i64 6
  %9563 = load i192, ptr %678, align 8
  %9564 = trunc i192 %9563 to i129
  %9565 = xor i129 %9564, -1
  %9566 = call i129 @llvm.cttz.i129(i129 %9565, i1 false)
  %9567 = add i129 %9566, 1
  %9568 = icmp eq i129 %9565, 0
  %9569 = select i1 %9568, i129 0, i129 %9567
  %9570 = trunc i129 %9569 to i32
  store i32 %9570, ptr %9562, align 4
  %9571 = getelementptr inbounds i32, ptr %679, i64 7
  %9572 = load i192, ptr %678, align 8
  %9573 = trunc i192 %9572 to i129
  %9574 = call i129 @llvm.cttz.i129(i129 %9573, i1 false)
  %9575 = add i129 %9574, 1
  %9576 = icmp eq i129 %9573, 0
  %9577 = select i1 %9576, i129 0, i129 %9575
  %9578 = trunc i129 %9577 to i32
  store i32 %9578, ptr %9571, align 4
  %9579 = getelementptr inbounds i32, ptr %679, i64 8
  %9580 = load i192, ptr %678, align 8
  %9581 = trunc i192 %9580 to i129
  %9582 = call i129 @llvm.ctpop.i129(i129 %9581)
  %9583 = sub i129 129, %9582
  %9584 = trunc i129 %9583 to i32
  store i32 %9584, ptr %9579, align 4
  %9585 = getelementptr inbounds i32, ptr %679, i64 9
  %9586 = load i192, ptr %678, align 8
  %9587 = trunc i192 %9586 to i129
  %9588 = call i129 @llvm.ctpop.i129(i129 %9587)
  %9589 = trunc i129 %9588 to i32
  store i32 %9589, ptr %9585, align 4
  %9590 = getelementptr inbounds i32, ptr %679, i64 10
  %9591 = load i192, ptr %678, align 8
  %9592 = trunc i192 %9591 to i129
  %9593 = call i129 @llvm.ctpop.i129(i129 %9592)
  %9594 = icmp eq i129 %9593, 1
  %9595 = zext i1 %9594 to i32
  store i32 %9595, ptr %9590, align 4
  %9596 = getelementptr inbounds i32, ptr %679, i64 11
  %9597 = load i192, ptr %678, align 8
  %9598 = trunc i192 %9597 to i129
  %9599 = call i129 @llvm.ctlz.i129(i129 %9598, i1 false)
  %9600 = sub i129 129, %9599
  %9601 = trunc i129 %9600 to i32
  store i32 %9601, ptr %9596, align 4
  %9602 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 0
  %9603 = load i32, ptr %9602, align 16
  %9604 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 1
  %9605 = load i32, ptr %9604, align 4
  %9606 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 2
  %9607 = load i32, ptr %9606, align 8
  %9608 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 3
  %9609 = load i32, ptr %9608, align 4
  %9610 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 4
  %9611 = load i32, ptr %9610, align 16
  %9612 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 5
  %9613 = load i32, ptr %9612, align 4
  %9614 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 6
  %9615 = load i32, ptr %9614, align 8
  %9616 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 7
  %9617 = load i32, ptr %9616, align 4
  %9618 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 8
  %9619 = load i32, ptr %9618, align 16
  %9620 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 9
  %9621 = load i32, ptr %9620, align 4
  %9622 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 10
  %9623 = load i32, ptr %9622, align 8
  %9624 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 11
  %9625 = load i32, ptr %9624, align 4
  %9626 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %9603, i32 noundef %9605, i32 noundef %9607, i32 noundef %9609, i32 noundef %9611, i32 noundef %9613, i32 noundef %9615, i32 noundef %9617, i32 noundef %9619, i32 noundef %9621, i32 noundef %9623, i32 noundef %9625)
  %9627 = load i192, ptr %678, align 8
  %9628 = trunc i192 %9627 to i129
  %9629 = call i129 @llvm.ctlz.i129(i129 %9628, i1 true)
  %9630 = sub i129 128, %9629
  %9631 = shl i129 1, %9630
  %9632 = icmp eq i129 %9628, 0
  %9633 = select i1 %9632, i129 0, i129 %9631
  %9634 = zext i129 %9633 to i192
  store i192 %9634, ptr %680, align 8
  %9635 = load i192, ptr %678, align 8
  %9636 = trunc i192 %9635 to i129
  %9637 = icmp ule i129 %9636, 1
  br i1 %9637, label %9643, label %9638

9638:                                             ; preds = %9520
  %9639 = sub i129 %9636, 1
  %9640 = call i129 @llvm.ctlz.i129(i129 %9639, i1 false)
  %9641 = sub i129 128, %9640
  %9642 = shl i129 2, %9641
  br label %9643

9643:                                             ; preds = %9638, %9520
  %9644 = phi i129 [ 1, %9520 ], [ %9642, %9638 ]
  %9645 = zext i129 %9644 to i192
  store i192 %9645, ptr %681, align 8
  %9646 = load i192, ptr %678, align 8
  %9647 = trunc i192 %9646 to i129
  %9648 = call i129 @llvm.fshl.i129(i129 %9647, i129 %9647, i129 3)
  %9649 = zext i129 %9648 to i192
  store i192 %9649, ptr %682, align 8
  %9650 = load i192, ptr %678, align 8
  %9651 = trunc i192 %9650 to i129
  %9652 = call i129 @llvm.fshr.i129(i129 %9651, i129 %9651, i129 3)
  %9653 = zext i129 %9652 to i192
  store i192 %9653, ptr %683, align 8
  %9654 = load i192, ptr %678, align 8
  %9655 = trunc i192 %9654 to i129
  %9656 = call i129 @llvm.fshl.i129(i129 %9655, i129 %9655, i129 0)
  %9657 = zext i129 %9656 to i192
  store i192 %9657, ptr %684, align 8
  %9658 = load i192, ptr %678, align 8
  %9659 = trunc i192 %9658 to i129
  %9660 = call i129 @llvm.fshl.i129(i129 %9659, i129 %9659, i129 97)
  %9661 = zext i129 %9660 to i192
  store i192 %9661, ptr %685, align 8
  %9662 = load i192, ptr %680, align 8
  %9663 = trunc i192 %9662 to i129
  %9664 = zext i129 %9663 to i256
  %9665 = lshr i256 %9664, 128
  %9666 = trunc i256 %9665 to i64
  %9667 = load i192, ptr %680, align 8
  %9668 = trunc i192 %9667 to i129
  %9669 = zext i129 %9668 to i256
  %9670 = lshr i256 %9669, 64
  %9671 = trunc i256 %9670 to i64
  %9672 = load i192, ptr %680, align 8
  %9673 = trunc i192 %9672 to i129
  %9674 = trunc i129 %9673 to i64
  %9675 = load i192, ptr %681, align 8
  %9676 = trunc i192 %9675 to i129
  %9677 = zext i129 %9676 to i256
  %9678 = lshr i256 %9677, 128
  %9679 = trunc i256 %9678 to i64
  %9680 = load i192, ptr %681, align 8
  %9681 = trunc i192 %9680 to i129
  %9682 = zext i129 %9681 to i256
  %9683 = lshr i256 %9682, 64
  %9684 = trunc i256 %9683 to i64
  %9685 = load i192, ptr %681, align 8
  %9686 = trunc i192 %9685 to i129
  %9687 = trunc i129 %9686 to i64
  %9688 = load i192, ptr %682, align 8
  %9689 = trunc i192 %9688 to i129
  %9690 = zext i129 %9689 to i256
  %9691 = lshr i256 %9690, 128
  %9692 = trunc i256 %9691 to i64
  %9693 = load i192, ptr %682, align 8
  %9694 = trunc i192 %9693 to i129
  %9695 = zext i129 %9694 to i256
  %9696 = lshr i256 %9695, 64
  %9697 = trunc i256 %9696 to i64
  %9698 = load i192, ptr %682, align 8
  %9699 = trunc i192 %9698 to i129
  %9700 = trunc i129 %9699 to i64
  %9701 = load i192, ptr %683, align 8
  %9702 = trunc i192 %9701 to i129
  %9703 = zext i129 %9702 to i256
  %9704 = lshr i256 %9703, 128
  %9705 = trunc i256 %9704 to i64
  %9706 = load i192, ptr %683, align 8
  %9707 = trunc i192 %9706 to i129
  %9708 = zext i129 %9707 to i256
  %9709 = lshr i256 %9708, 64
  %9710 = trunc i256 %9709 to i64
  %9711 = load i192, ptr %683, align 8
  %9712 = trunc i192 %9711 to i129
  %9713 = trunc i129 %9712 to i64
  %9714 = load i192, ptr %684, align 8
  %9715 = trunc i192 %9714 to i129
  %9716 = trunc i129 %9715 to i64
  %9717 = load i192, ptr %685, align 8
  %9718 = trunc i192 %9717 to i129
  %9719 = trunc i129 %9718 to i64
  %9720 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %9666, i64 noundef %9671, i64 noundef %9674, i64 noundef %9679, i64 noundef %9684, i64 noundef %9687, i64 noundef %9692, i64 noundef %9697, i64 noundef %9700, i64 noundef %9705, i64 noundef %9710, i64 noundef %9713, i64 noundef %9716, i64 noundef %9719)
  %9721 = load i192, ptr %678, align 8
  %9722 = trunc i192 %9721 to i129
  %9723 = zext i129 %9722 to i575
  %9724 = getelementptr inbounds [12 x i32], ptr %679, i64 0, i64 0
  %9725 = load i192, ptr %680, align 8
  %9726 = trunc i192 %9725 to i129
  %9727 = zext i129 %9726 to i575
  %9728 = load i192, ptr %681, align 8
  %9729 = trunc i192 %9728 to i129
  %9730 = zext i129 %9729 to i575
  %9731 = load i192, ptr %682, align 8
  %9732 = trunc i192 %9731 to i129
  %9733 = zext i129 %9732 to i575
  %9734 = load i192, ptr %683, align 8
  %9735 = trunc i192 %9734 to i129
  %9736 = zext i129 %9735 to i575
  %9737 = load i192, ptr %684, align 8
  %9738 = trunc i192 %9737 to i129
  %9739 = zext i129 %9738 to i575
  %9740 = load i192, ptr %685, align 8
  %9741 = trunc i192 %9740 to i129
  %9742 = zext i129 %9741 to i575
  %9743 = zext i575 %9723 to i576
  store i576 %9743, ptr %686, align 8
  %9744 = zext i575 %9727 to i576
  store i576 %9744, ptr %687, align 8
  %9745 = zext i575 %9730 to i576
  store i576 %9745, ptr %688, align 8
  %9746 = zext i575 %9733 to i576
  store i576 %9746, ptr %689, align 8
  %9747 = zext i575 %9736 to i576
  store i576 %9747, ptr %690, align 8
  %9748 = zext i575 %9739 to i576
  store i576 %9748, ptr %691, align 8
  %9749 = zext i575 %9742 to i576
  store i576 %9749, ptr %692, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %686, ptr noundef %9724, ptr noundef byval([72 x i8]) align 8 %687, ptr noundef byval([72 x i8]) align 8 %688, ptr noundef byval([72 x i8]) align 8 %689, ptr noundef byval([72 x i8]) align 8 %690, ptr noundef byval([72 x i8]) align 8 %691, ptr noundef byval([72 x i8]) align 8 %692)
  br label %9750

9750:                                             ; preds = %9643
  br label %9751

9751:                                             ; preds = %9750
  %9752 = load i192, ptr %677, align 8
  %9753 = trunc i192 %9752 to i129
  %9754 = add i129 %9753, 1
  %9755 = zext i129 %9754 to i192
  store i192 %9755, ptr %693, align 8
  %9756 = load i192, ptr %693, align 8
  %9757 = trunc i192 %9756 to i129
  %9758 = call i129 @llvm.ctlz.i129(i129 %9757, i1 false)
  %9759 = trunc i129 %9758 to i32
  store i32 %9759, ptr %694, align 4
  %9760 = getelementptr inbounds i32, ptr %694, i64 1
  %9761 = load i192, ptr %693, align 8
  %9762 = trunc i192 %9761 to i129
  %9763 = xor i129 %9762, -1
  %9764 = call i129 @llvm.ctlz.i129(i129 %9763, i1 false)
  %9765 = trunc i129 %9764 to i32
  store i32 %9765, ptr %9760, align 4
  %9766 = getelementptr inbounds i32, ptr %694, i64 2
  %9767 = load i192, ptr %693, align 8
  %9768 = trunc i192 %9767 to i129
  %9769 = call i129 @llvm.cttz.i129(i129 %9768, i1 false)
  %9770 = trunc i129 %9769 to i32
  store i32 %9770, ptr %9766, align 4
  %9771 = getelementptr inbounds i32, ptr %694, i64 3
  %9772 = load i192, ptr %693, align 8
  %9773 = trunc i192 %9772 to i129
  %9774 = xor i129 %9773, -1
  %9775 = call i129 @llvm.cttz.i129(i129 %9774, i1 false)
  %9776 = trunc i129 %9775 to i32
  store i32 %9776, ptr %9771, align 4
  %9777 = getelementptr inbounds i32, ptr %694, i64 4
  %9778 = load i192, ptr %693, align 8
  %9779 = trunc i192 %9778 to i129
  %9780 = xor i129 %9779, -1
  %9781 = call i129 @llvm.ctlz.i129(i129 %9780, i1 false)
  %9782 = add i129 %9781, 1
  %9783 = icmp eq i129 %9780, 0
  %9784 = select i1 %9783, i129 0, i129 %9782
  %9785 = trunc i129 %9784 to i32
  store i32 %9785, ptr %9777, align 4
  %9786 = getelementptr inbounds i32, ptr %694, i64 5
  %9787 = load i192, ptr %693, align 8
  %9788 = trunc i192 %9787 to i129
  %9789 = call i129 @llvm.ctlz.i129(i129 %9788, i1 false)
  %9790 = add i129 %9789, 1
  %9791 = icmp eq i129 %9788, 0
  %9792 = select i1 %9791, i129 0, i129 %9790
  %9793 = trunc i129 %9792 to i32
  store i32 %9793, ptr %9786, align 4
  %9794 = getelementptr inbounds i32, ptr %694, i64 6
  %9795 = load i192, ptr %693, align 8
  %9796 = trunc i192 %9795 to i129
  %9797 = xor i129 %9796, -1
  %9798 = call i129 @llvm.cttz.i129(i129 %9797, i1 false)
  %9799 = add i129 %9798, 1
  %9800 = icmp eq i129 %9797, 0
  %9801 = select i1 %9800, i129 0, i129 %9799
  %9802 = trunc i129 %9801 to i32
  store i32 %9802, ptr %9794, align 4
  %9803 = getelementptr inbounds i32, ptr %694, i64 7
  %9804 = load i192, ptr %693, align 8
  %9805 = trunc i192 %9804 to i129
  %9806 = call i129 @llvm.cttz.i129(i129 %9805, i1 false)
  %9807 = add i129 %9806, 1
  %9808 = icmp eq i129 %9805, 0
  %9809 = select i1 %9808, i129 0, i129 %9807
  %9810 = trunc i129 %9809 to i32
  store i32 %9810, ptr %9803, align 4
  %9811 = getelementptr inbounds i32, ptr %694, i64 8
  %9812 = load i192, ptr %693, align 8
  %9813 = trunc i192 %9812 to i129
  %9814 = call i129 @llvm.ctpop.i129(i129 %9813)
  %9815 = sub i129 129, %9814
  %9816 = trunc i129 %9815 to i32
  store i32 %9816, ptr %9811, align 4
  %9817 = getelementptr inbounds i32, ptr %694, i64 9
  %9818 = load i192, ptr %693, align 8
  %9819 = trunc i192 %9818 to i129
  %9820 = call i129 @llvm.ctpop.i129(i129 %9819)
  %9821 = trunc i129 %9820 to i32
  store i32 %9821, ptr %9817, align 4
  %9822 = getelementptr inbounds i32, ptr %694, i64 10
  %9823 = load i192, ptr %693, align 8
  %9824 = trunc i192 %9823 to i129
  %9825 = call i129 @llvm.ctpop.i129(i129 %9824)
  %9826 = icmp eq i129 %9825, 1
  %9827 = zext i1 %9826 to i32
  store i32 %9827, ptr %9822, align 4
  %9828 = getelementptr inbounds i32, ptr %694, i64 11
  %9829 = load i192, ptr %693, align 8
  %9830 = trunc i192 %9829 to i129
  %9831 = call i129 @llvm.ctlz.i129(i129 %9830, i1 false)
  %9832 = sub i129 129, %9831
  %9833 = trunc i129 %9832 to i32
  store i32 %9833, ptr %9828, align 4
  %9834 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 0
  %9835 = load i32, ptr %9834, align 16
  %9836 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 1
  %9837 = load i32, ptr %9836, align 4
  %9838 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 2
  %9839 = load i32, ptr %9838, align 8
  %9840 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 3
  %9841 = load i32, ptr %9840, align 4
  %9842 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 4
  %9843 = load i32, ptr %9842, align 16
  %9844 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 5
  %9845 = load i32, ptr %9844, align 4
  %9846 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 6
  %9847 = load i32, ptr %9846, align 8
  %9848 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 7
  %9849 = load i32, ptr %9848, align 4
  %9850 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 8
  %9851 = load i32, ptr %9850, align 16
  %9852 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 9
  %9853 = load i32, ptr %9852, align 4
  %9854 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 10
  %9855 = load i32, ptr %9854, align 8
  %9856 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 11
  %9857 = load i32, ptr %9856, align 4
  %9858 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef %9835, i32 noundef %9837, i32 noundef %9839, i32 noundef %9841, i32 noundef %9843, i32 noundef %9845, i32 noundef %9847, i32 noundef %9849, i32 noundef %9851, i32 noundef %9853, i32 noundef %9855, i32 noundef %9857)
  %9859 = load i192, ptr %693, align 8
  %9860 = trunc i192 %9859 to i129
  %9861 = call i129 @llvm.ctlz.i129(i129 %9860, i1 true)
  %9862 = sub i129 128, %9861
  %9863 = shl i129 1, %9862
  %9864 = icmp eq i129 %9860, 0
  %9865 = select i1 %9864, i129 0, i129 %9863
  %9866 = zext i129 %9865 to i192
  store i192 %9866, ptr %695, align 8
  %9867 = load i192, ptr %693, align 8
  %9868 = trunc i192 %9867 to i129
  %9869 = icmp ule i129 %9868, 1
  br i1 %9869, label %9875, label %9870

9870:                                             ; preds = %9751
  %9871 = sub i129 %9868, 1
  %9872 = call i129 @llvm.ctlz.i129(i129 %9871, i1 false)
  %9873 = sub i129 128, %9872
  %9874 = shl i129 2, %9873
  br label %9875

9875:                                             ; preds = %9870, %9751
  %9876 = phi i129 [ 1, %9751 ], [ %9874, %9870 ]
  %9877 = zext i129 %9876 to i192
  store i192 %9877, ptr %696, align 8
  %9878 = load i192, ptr %693, align 8
  %9879 = trunc i192 %9878 to i129
  %9880 = call i129 @llvm.fshl.i129(i129 %9879, i129 %9879, i129 3)
  %9881 = zext i129 %9880 to i192
  store i192 %9881, ptr %697, align 8
  %9882 = load i192, ptr %693, align 8
  %9883 = trunc i192 %9882 to i129
  %9884 = call i129 @llvm.fshr.i129(i129 %9883, i129 %9883, i129 3)
  %9885 = zext i129 %9884 to i192
  store i192 %9885, ptr %698, align 8
  %9886 = load i192, ptr %693, align 8
  %9887 = trunc i192 %9886 to i129
  %9888 = call i129 @llvm.fshl.i129(i129 %9887, i129 %9887, i129 0)
  %9889 = zext i129 %9888 to i192
  store i192 %9889, ptr %699, align 8
  %9890 = load i192, ptr %693, align 8
  %9891 = trunc i192 %9890 to i129
  %9892 = call i129 @llvm.fshl.i129(i129 %9891, i129 %9891, i129 97)
  %9893 = zext i129 %9892 to i192
  store i192 %9893, ptr %700, align 8
  %9894 = load i192, ptr %695, align 8
  %9895 = trunc i192 %9894 to i129
  %9896 = zext i129 %9895 to i256
  %9897 = lshr i256 %9896, 128
  %9898 = trunc i256 %9897 to i64
  %9899 = load i192, ptr %695, align 8
  %9900 = trunc i192 %9899 to i129
  %9901 = zext i129 %9900 to i256
  %9902 = lshr i256 %9901, 64
  %9903 = trunc i256 %9902 to i64
  %9904 = load i192, ptr %695, align 8
  %9905 = trunc i192 %9904 to i129
  %9906 = trunc i129 %9905 to i64
  %9907 = load i192, ptr %696, align 8
  %9908 = trunc i192 %9907 to i129
  %9909 = zext i129 %9908 to i256
  %9910 = lshr i256 %9909, 128
  %9911 = trunc i256 %9910 to i64
  %9912 = load i192, ptr %696, align 8
  %9913 = trunc i192 %9912 to i129
  %9914 = zext i129 %9913 to i256
  %9915 = lshr i256 %9914, 64
  %9916 = trunc i256 %9915 to i64
  %9917 = load i192, ptr %696, align 8
  %9918 = trunc i192 %9917 to i129
  %9919 = trunc i129 %9918 to i64
  %9920 = load i192, ptr %697, align 8
  %9921 = trunc i192 %9920 to i129
  %9922 = zext i129 %9921 to i256
  %9923 = lshr i256 %9922, 128
  %9924 = trunc i256 %9923 to i64
  %9925 = load i192, ptr %697, align 8
  %9926 = trunc i192 %9925 to i129
  %9927 = zext i129 %9926 to i256
  %9928 = lshr i256 %9927, 64
  %9929 = trunc i256 %9928 to i64
  %9930 = load i192, ptr %697, align 8
  %9931 = trunc i192 %9930 to i129
  %9932 = trunc i129 %9931 to i64
  %9933 = load i192, ptr %698, align 8
  %9934 = trunc i192 %9933 to i129
  %9935 = zext i129 %9934 to i256
  %9936 = lshr i256 %9935, 128
  %9937 = trunc i256 %9936 to i64
  %9938 = load i192, ptr %698, align 8
  %9939 = trunc i192 %9938 to i129
  %9940 = zext i129 %9939 to i256
  %9941 = lshr i256 %9940, 64
  %9942 = trunc i256 %9941 to i64
  %9943 = load i192, ptr %698, align 8
  %9944 = trunc i192 %9943 to i129
  %9945 = trunc i129 %9944 to i64
  %9946 = load i192, ptr %699, align 8
  %9947 = trunc i192 %9946 to i129
  %9948 = trunc i129 %9947 to i64
  %9949 = load i192, ptr %700, align 8
  %9950 = trunc i192 %9949 to i129
  %9951 = trunc i129 %9950 to i64
  %9952 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %9898, i64 noundef %9903, i64 noundef %9906, i64 noundef %9911, i64 noundef %9916, i64 noundef %9919, i64 noundef %9924, i64 noundef %9929, i64 noundef %9932, i64 noundef %9937, i64 noundef %9942, i64 noundef %9945, i64 noundef %9948, i64 noundef %9951)
  %9953 = load i192, ptr %693, align 8
  %9954 = trunc i192 %9953 to i129
  %9955 = zext i129 %9954 to i575
  %9956 = getelementptr inbounds [12 x i32], ptr %694, i64 0, i64 0
  %9957 = load i192, ptr %695, align 8
  %9958 = trunc i192 %9957 to i129
  %9959 = zext i129 %9958 to i575
  %9960 = load i192, ptr %696, align 8
  %9961 = trunc i192 %9960 to i129
  %9962 = zext i129 %9961 to i575
  %9963 = load i192, ptr %697, align 8
  %9964 = trunc i192 %9963 to i129
  %9965 = zext i129 %9964 to i575
  %9966 = load i192, ptr %698, align 8
  %9967 = trunc i192 %9966 to i129
  %9968 = zext i129 %9967 to i575
  %9969 = load i192, ptr %699, align 8
  %9970 = trunc i192 %9969 to i129
  %9971 = zext i129 %9970 to i575
  %9972 = load i192, ptr %700, align 8
  %9973 = trunc i192 %9972 to i129
  %9974 = zext i129 %9973 to i575
  %9975 = zext i575 %9955 to i576
  store i576 %9975, ptr %701, align 8
  %9976 = zext i575 %9959 to i576
  store i576 %9976, ptr %702, align 8
  %9977 = zext i575 %9962 to i576
  store i576 %9977, ptr %703, align 8
  %9978 = zext i575 %9965 to i576
  store i576 %9978, ptr %704, align 8
  %9979 = zext i575 %9968 to i576
  store i576 %9979, ptr %705, align 8
  %9980 = zext i575 %9971 to i576
  store i576 %9980, ptr %706, align 8
  %9981 = zext i575 %9974 to i576
  store i576 %9981, ptr %707, align 8
  call void @check(ptr noundef @.str.10, i32 noundef 129, ptr noundef byval([72 x i8]) align 8 %701, ptr noundef %9956, ptr noundef byval([72 x i8]) align 8 %702, ptr noundef byval([72 x i8]) align 8 %703, ptr noundef byval([72 x i8]) align 8 %704, ptr noundef byval([72 x i8]) align 8 %705, ptr noundef byval([72 x i8]) align 8 %706, ptr noundef byval([72 x i8]) align 8 %707)
  br label %9982

9982:                                             ; preds = %9875
  store i8 -127, ptr %708, align 1
  br label %9983

9983:                                             ; preds = %9982
  %9984 = load i8, ptr %708, align 1
  store i8 %9984, ptr %709, align 1
  %9985 = load i8, ptr %709, align 1
  %9986 = call i8 @llvm.ctlz.i8(i8 %9985, i1 false)
  %9987 = zext i8 %9986 to i32
  store i32 %9987, ptr %710, align 4
  %9988 = getelementptr inbounds i32, ptr %710, i64 1
  %9989 = load i8, ptr %709, align 1
  %9990 = xor i8 %9989, -1
  %9991 = call i8 @llvm.ctlz.i8(i8 %9990, i1 false)
  %9992 = zext i8 %9991 to i32
  store i32 %9992, ptr %9988, align 4
  %9993 = getelementptr inbounds i32, ptr %710, i64 2
  %9994 = load i8, ptr %709, align 1
  %9995 = call i8 @llvm.cttz.i8(i8 %9994, i1 false)
  %9996 = zext i8 %9995 to i32
  store i32 %9996, ptr %9993, align 4
  %9997 = getelementptr inbounds i32, ptr %710, i64 3
  %9998 = load i8, ptr %709, align 1
  %9999 = xor i8 %9998, -1
  %10000 = call i8 @llvm.cttz.i8(i8 %9999, i1 false)
  %10001 = zext i8 %10000 to i32
  store i32 %10001, ptr %9997, align 4
  %10002 = getelementptr inbounds i32, ptr %710, i64 4
  %10003 = load i8, ptr %709, align 1
  %10004 = xor i8 %10003, -1
  %10005 = call i8 @llvm.ctlz.i8(i8 %10004, i1 false)
  %10006 = add i8 %10005, 1
  %10007 = icmp eq i8 %10004, 0
  %10008 = select i1 %10007, i8 0, i8 %10006
  %10009 = zext i8 %10008 to i32
  store i32 %10009, ptr %10002, align 4
  %10010 = getelementptr inbounds i32, ptr %710, i64 5
  %10011 = load i8, ptr %709, align 1
  %10012 = call i8 @llvm.ctlz.i8(i8 %10011, i1 false)
  %10013 = add i8 %10012, 1
  %10014 = icmp eq i8 %10011, 0
  %10015 = select i1 %10014, i8 0, i8 %10013
  %10016 = zext i8 %10015 to i32
  store i32 %10016, ptr %10010, align 4
  %10017 = getelementptr inbounds i32, ptr %710, i64 6
  %10018 = load i8, ptr %709, align 1
  %10019 = xor i8 %10018, -1
  %10020 = call i8 @llvm.cttz.i8(i8 %10019, i1 false)
  %10021 = add i8 %10020, 1
  %10022 = icmp eq i8 %10019, 0
  %10023 = select i1 %10022, i8 0, i8 %10021
  %10024 = zext i8 %10023 to i32
  store i32 %10024, ptr %10017, align 4
  %10025 = getelementptr inbounds i32, ptr %710, i64 7
  %10026 = load i8, ptr %709, align 1
  %10027 = call i8 @llvm.cttz.i8(i8 %10026, i1 false)
  %10028 = add i8 %10027, 1
  %10029 = icmp eq i8 %10026, 0
  %10030 = select i1 %10029, i8 0, i8 %10028
  %10031 = zext i8 %10030 to i32
  store i32 %10031, ptr %10025, align 4
  %10032 = getelementptr inbounds i32, ptr %710, i64 8
  %10033 = load i8, ptr %709, align 1
  %10034 = call i8 @llvm.ctpop.i8(i8 %10033)
  %10035 = sub i8 8, %10034
  %10036 = zext i8 %10035 to i32
  store i32 %10036, ptr %10032, align 4
  %10037 = getelementptr inbounds i32, ptr %710, i64 9
  %10038 = load i8, ptr %709, align 1
  %10039 = call i8 @llvm.ctpop.i8(i8 %10038)
  %10040 = zext i8 %10039 to i32
  store i32 %10040, ptr %10037, align 4
  %10041 = getelementptr inbounds i32, ptr %710, i64 10
  %10042 = load i8, ptr %709, align 1
  %10043 = call i8 @llvm.ctpop.i8(i8 %10042)
  %10044 = icmp eq i8 %10043, 1
  %10045 = zext i1 %10044 to i32
  store i32 %10045, ptr %10041, align 4
  %10046 = getelementptr inbounds i32, ptr %710, i64 11
  %10047 = load i8, ptr %709, align 1
  %10048 = call i8 @llvm.ctlz.i8(i8 %10047, i1 false)
  %10049 = sub i8 8, %10048
  %10050 = zext i8 %10049 to i32
  store i32 %10050, ptr %10046, align 4
  %10051 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 0
  %10052 = load i32, ptr %10051, align 16
  %10053 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 1
  %10054 = load i32, ptr %10053, align 4
  %10055 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 2
  %10056 = load i32, ptr %10055, align 8
  %10057 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 3
  %10058 = load i32, ptr %10057, align 4
  %10059 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 4
  %10060 = load i32, ptr %10059, align 16
  %10061 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 5
  %10062 = load i32, ptr %10061, align 4
  %10063 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 6
  %10064 = load i32, ptr %10063, align 8
  %10065 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 7
  %10066 = load i32, ptr %10065, align 4
  %10067 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 8
  %10068 = load i32, ptr %10067, align 16
  %10069 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 9
  %10070 = load i32, ptr %10069, align 4
  %10071 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 10
  %10072 = load i32, ptr %10071, align 8
  %10073 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 11
  %10074 = load i32, ptr %10073, align 4
  %10075 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef %10052, i32 noundef %10054, i32 noundef %10056, i32 noundef %10058, i32 noundef %10060, i32 noundef %10062, i32 noundef %10064, i32 noundef %10066, i32 noundef %10068, i32 noundef %10070, i32 noundef %10072, i32 noundef %10074)
  %10076 = load i8, ptr %709, align 1
  %10077 = call i8 @llvm.ctlz.i8(i8 %10076, i1 true)
  %10078 = sub i8 7, %10077
  %10079 = shl i8 1, %10078
  %10080 = icmp eq i8 %10076, 0
  %10081 = select i1 %10080, i8 0, i8 %10079
  store i8 %10081, ptr %711, align 1
  %10082 = load i8, ptr %709, align 1
  %10083 = icmp ule i8 %10082, 1
  br i1 %10083, label %10089, label %10084

10084:                                            ; preds = %9983
  %10085 = sub i8 %10082, 1
  %10086 = call i8 @llvm.ctlz.i8(i8 %10085, i1 false)
  %10087 = sub i8 7, %10086
  %10088 = shl i8 2, %10087
  br label %10089

10089:                                            ; preds = %10084, %9983
  %10090 = phi i8 [ 1, %9983 ], [ %10088, %10084 ]
  store i8 %10090, ptr %712, align 1
  %10091 = load i8, ptr %709, align 1
  %10092 = call i8 @llvm.fshl.i8(i8 %10091, i8 %10091, i8 3)
  store i8 %10092, ptr %713, align 1
  %10093 = load i8, ptr %709, align 1
  %10094 = call i8 @llvm.fshr.i8(i8 %10093, i8 %10093, i8 3)
  store i8 %10094, ptr %714, align 1
  %10095 = load i8, ptr %709, align 1
  %10096 = call i8 @llvm.fshl.i8(i8 %10095, i8 %10095, i8 0)
  store i8 %10096, ptr %715, align 1
  %10097 = load i8, ptr %709, align 1
  %10098 = call i8 @llvm.fshl.i8(i8 %10097, i8 %10097, i8 0)
  store i8 %10098, ptr %716, align 1
  %10099 = load i8, ptr %711, align 1
  %10100 = zext i8 %10099 to i256
  %10101 = lshr i256 %10100, 128
  %10102 = trunc i256 %10101 to i64
  %10103 = load i8, ptr %711, align 1
  %10104 = zext i8 %10103 to i256
  %10105 = lshr i256 %10104, 64
  %10106 = trunc i256 %10105 to i64
  %10107 = load i8, ptr %711, align 1
  %10108 = zext i8 %10107 to i64
  %10109 = load i8, ptr %712, align 1
  %10110 = zext i8 %10109 to i256
  %10111 = lshr i256 %10110, 128
  %10112 = trunc i256 %10111 to i64
  %10113 = load i8, ptr %712, align 1
  %10114 = zext i8 %10113 to i256
  %10115 = lshr i256 %10114, 64
  %10116 = trunc i256 %10115 to i64
  %10117 = load i8, ptr %712, align 1
  %10118 = zext i8 %10117 to i64
  %10119 = load i8, ptr %713, align 1
  %10120 = zext i8 %10119 to i256
  %10121 = lshr i256 %10120, 128
  %10122 = trunc i256 %10121 to i64
  %10123 = load i8, ptr %713, align 1
  %10124 = zext i8 %10123 to i256
  %10125 = lshr i256 %10124, 64
  %10126 = trunc i256 %10125 to i64
  %10127 = load i8, ptr %713, align 1
  %10128 = zext i8 %10127 to i64
  %10129 = load i8, ptr %714, align 1
  %10130 = zext i8 %10129 to i256
  %10131 = lshr i256 %10130, 128
  %10132 = trunc i256 %10131 to i64
  %10133 = load i8, ptr %714, align 1
  %10134 = zext i8 %10133 to i256
  %10135 = lshr i256 %10134, 64
  %10136 = trunc i256 %10135 to i64
  %10137 = load i8, ptr %714, align 1
  %10138 = zext i8 %10137 to i64
  %10139 = load i8, ptr %715, align 1
  %10140 = zext i8 %10139 to i64
  %10141 = load i8, ptr %716, align 1
  %10142 = zext i8 %10141 to i64
  %10143 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %10102, i64 noundef %10106, i64 noundef %10108, i64 noundef %10112, i64 noundef %10116, i64 noundef %10118, i64 noundef %10122, i64 noundef %10126, i64 noundef %10128, i64 noundef %10132, i64 noundef %10136, i64 noundef %10138, i64 noundef %10140, i64 noundef %10142)
  %10144 = load i8, ptr %709, align 1
  %10145 = zext i8 %10144 to i575
  %10146 = getelementptr inbounds [12 x i32], ptr %710, i64 0, i64 0
  %10147 = load i8, ptr %711, align 1
  %10148 = zext i8 %10147 to i575
  %10149 = load i8, ptr %712, align 1
  %10150 = zext i8 %10149 to i575
  %10151 = load i8, ptr %713, align 1
  %10152 = zext i8 %10151 to i575
  %10153 = load i8, ptr %714, align 1
  %10154 = zext i8 %10153 to i575
  %10155 = load i8, ptr %715, align 1
  %10156 = zext i8 %10155 to i575
  %10157 = load i8, ptr %716, align 1
  %10158 = zext i8 %10157 to i575
  %10159 = zext i575 %10145 to i576
  store i576 %10159, ptr %717, align 8
  %10160 = zext i575 %10148 to i576
  store i576 %10160, ptr %718, align 8
  %10161 = zext i575 %10150 to i576
  store i576 %10161, ptr %719, align 8
  %10162 = zext i575 %10152 to i576
  store i576 %10162, ptr %720, align 8
  %10163 = zext i575 %10154 to i576
  store i576 %10163, ptr %721, align 8
  %10164 = zext i575 %10156 to i576
  store i576 %10164, ptr %722, align 8
  %10165 = zext i575 %10158 to i576
  store i576 %10165, ptr %723, align 8
  call void @check(ptr noundef @.str.2, i32 noundef 8, ptr noundef byval([72 x i8]) align 8 %717, ptr noundef %10146, ptr noundef byval([72 x i8]) align 8 %718, ptr noundef byval([72 x i8]) align 8 %719, ptr noundef byval([72 x i8]) align 8 %720, ptr noundef byval([72 x i8]) align 8 %721, ptr noundef byval([72 x i8]) align 8 %722, ptr noundef byval([72 x i8]) align 8 %723)
  br label %10166

10166:                                            ; preds = %10089
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %724, ptr align 16 @__const.main.t_, i64 20, i1 false)
  %10167 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 0
  %10168 = load i32, ptr %10167, align 16
  %10169 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 1
  %10170 = load i32, ptr %10169, align 4
  %10171 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 2
  %10172 = load i32, ptr %10171, align 8
  %10173 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 3
  %10174 = load i32, ptr %10173, align 4
  %10175 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 4
  %10176 = load i32, ptr %10175, align 16
  %10177 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, i32 noundef %10168, i32 noundef %10170, i32 noundef %10172, i32 noundef %10174, i32 noundef %10176)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %725, ptr align 4 @__const.main.q_, i64 12, i1 false)
  %10178 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 0
  %10179 = load i32, ptr %10178, align 4
  %10180 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 1
  %10181 = load i32, ptr %10180, align 4
  %10182 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 2
  %10183 = load i32, ptr %10182, align 4
  %10184 = call i32 (ptr, ...) @printf(ptr noundef @.str.17, i32 noundef %10179, i32 noundef %10181, i32 noundef %10183)
  %10185 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, i32 noundef 10, i32 noundef 16, i32 noundef 3, i32 noundef 0, i32 noundef 1)
  %10186 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 0
  %10187 = load i32, ptr %10186, align 16
  %10188 = icmp eq i32 %10187, 4
  br i1 %10188, label %10189, label %10205

10189:                                            ; preds = %10166
  %10190 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 1
  %10191 = load i32, ptr %10190, align 4
  %10192 = icmp ne i32 %10191, 0
  br i1 %10192, label %10193, label %10205

10193:                                            ; preds = %10189
  %10194 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 2
  %10195 = load i32, ptr %10194, align 8
  %10196 = icmp ne i32 %10195, 0
  br i1 %10196, label %10197, label %10205

10197:                                            ; preds = %10193
  %10198 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 3
  %10199 = load i32, ptr %10198, align 4
  %10200 = icmp ne i32 %10199, 0
  br i1 %10200, label %10201, label %10205

10201:                                            ; preds = %10197
  %10202 = getelementptr inbounds [5 x i32], ptr %724, i64 0, i64 4
  %10203 = load i32, ptr %10202, align 16
  %10204 = icmp ne i32 %10203, 0
  br i1 %10204, label %10208, label %10205

10205:                                            ; preds = %10201, %10197, %10193, %10189, %10166
  %10206 = load i32, ptr @fails, align 4
  %10207 = add nsw i32 %10206, 1
  store i32 %10207, ptr @fails, align 4
  br label %10208

10208:                                            ; preds = %10205, %10201
  %10209 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 0
  %10210 = load i32, ptr %10209, align 4
  %10211 = icmp eq i32 %10210, 128
  br i1 %10211, label %10212, label %10220

10212:                                            ; preds = %10208
  %10213 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 1
  %10214 = load i32, ptr %10213, align 4
  %10215 = icmp eq i32 %10214, 3
  br i1 %10215, label %10216, label %10220

10216:                                            ; preds = %10212
  %10217 = getelementptr inbounds [3 x i32], ptr %725, i64 0, i64 2
  %10218 = load i32, ptr %10217, align 4
  %10219 = icmp eq i32 %10218, 65
  br i1 %10219, label %10223, label %10220

10220:                                            ; preds = %10216, %10212, %10208
  %10221 = load i32, ptr @fails, align 4
  %10222 = add nsw i32 %10221, 1
  store i32 %10222, ptr @fails, align 4
  br label %10223

10223:                                            ; preds = %10220, %10216
  %10224 = load i32, ptr @fails, align 4
  %10225 = icmp ne i32 %10224, 0
  %10226 = zext i1 %10225 to i64
  %10227 = select i1 %10225, i32 1, i32 0
  ret i32 %10227
}

declare i32 @puts(ptr noundef) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctlz.i8(i8, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #3

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshl.i8(i8, i8, i8) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.fshr.i8(i8, i8, i8) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @check(ptr noundef %0, i32 noundef %1, ptr noundef byval([72 x i8]) align 8 %2, ptr noundef %3, ptr noundef byval([72 x i8]) align 8 %4, ptr noundef byval([72 x i8]) align 8 %5, ptr noundef byval([72 x i8]) align 8 %6, ptr noundef byval([72 x i8]) align 8 %7, ptr noundef byval([72 x i8]) align 8 %8, ptr noundef byval([72 x i8]) align 8 %9) #0 {
  %11 = alloca ptr, align 8
  %12 = alloca i32, align 4
  %13 = alloca [72 x i8], align 8
  %14 = alloca ptr, align 8
  %15 = alloca [72 x i8], align 8
  %16 = alloca [72 x i8], align 8
  %17 = alloca [72 x i8], align 8
  %18 = alloca [72 x i8], align 8
  %19 = alloca [72 x i8], align 8
  %20 = alloca [72 x i8], align 8
  %21 = alloca [72 x i8], align 8
  %22 = alloca [72 x i8], align 8
  %23 = alloca i32, align 4
  %24 = alloca [72 x i8], align 8
  %25 = alloca i32, align 4
  %26 = alloca [72 x i8], align 8
  %27 = alloca i32, align 4
  %28 = alloca [72 x i8], align 8
  %29 = alloca i32, align 4
  %30 = alloca [72 x i8], align 8
  %31 = alloca [72 x i8], align 8
  %32 = alloca [72 x i8], align 8
  %33 = alloca [72 x i8], align 8
  %34 = alloca [72 x i8], align 8
  %35 = alloca [72 x i8], align 8
  %36 = alloca [72 x i8], align 8
  %37 = alloca [72 x i8], align 8
  %38 = alloca [72 x i8], align 8
  %39 = alloca [72 x i8], align 8
  %40 = alloca [72 x i8], align 8
  %41 = alloca [72 x i8], align 8
  %42 = alloca [72 x i8], align 8
  %43 = alloca [72 x i8], align 8
  %44 = load i576, ptr %2, align 8
  %45 = trunc i576 %44 to i575
  %46 = load i576, ptr %4, align 8
  %47 = trunc i576 %46 to i575
  %48 = load i576, ptr %5, align 8
  %49 = trunc i576 %48 to i575
  %50 = load i576, ptr %6, align 8
  %51 = trunc i576 %50 to i575
  %52 = load i576, ptr %7, align 8
  %53 = trunc i576 %52 to i575
  %54 = load i576, ptr %8, align 8
  %55 = trunc i576 %54 to i575
  %56 = load i576, ptr %9, align 8
  %57 = trunc i576 %56 to i575
  store ptr %0, ptr %11, align 8
  store i32 %1, ptr %12, align 4
  %58 = zext i575 %45 to i576
  store i576 %58, ptr %13, align 8
  store ptr %3, ptr %14, align 8
  %59 = zext i575 %47 to i576
  store i576 %59, ptr %15, align 8
  %60 = zext i575 %49 to i576
  store i576 %60, ptr %16, align 8
  %61 = zext i575 %51 to i576
  store i576 %61, ptr %17, align 8
  %62 = zext i575 %53 to i576
  store i576 %62, ptr %18, align 8
  %63 = zext i575 %55 to i576
  store i576 %63, ptr %19, align 8
  %64 = zext i575 %57 to i576
  store i576 %64, ptr %20, align 8
  %65 = load i576, ptr %13, align 8
  %66 = trunc i576 %65 to i575
  %67 = xor i575 %66, -1
  %68 = load i32, ptr %12, align 4
  call void @mask(ptr dead_on_unwind writable sret([72 x i8]) align 8 %22, i32 noundef %68)
  %69 = load i576, ptr %22, align 8
  %70 = trunc i576 %69 to i575
  %71 = and i575 %67, %70
  %72 = zext i575 %71 to i576
  store i576 %72, ptr %21, align 8
  %73 = load i576, ptr %13, align 8
  %74 = trunc i576 %73 to i575
  %75 = load i32, ptr %12, align 4
  %76 = zext i575 %74 to i576
  store i576 %76, ptr %24, align 8
  %77 = call i32 @lz(ptr noundef byval([72 x i8]) align 8 %24, i32 noundef %75)
  store i32 %77, ptr %23, align 4
  %78 = load i576, ptr %21, align 8
  %79 = trunc i576 %78 to i575
  %80 = load i32, ptr %12, align 4
  %81 = zext i575 %79 to i576
  store i576 %81, ptr %26, align 8
  %82 = call i32 @lz(ptr noundef byval([72 x i8]) align 8 %26, i32 noundef %80)
  store i32 %82, ptr %25, align 4
  %83 = load i576, ptr %13, align 8
  %84 = trunc i576 %83 to i575
  %85 = load i32, ptr %12, align 4
  %86 = zext i575 %84 to i576
  store i576 %86, ptr %28, align 8
  %87 = call i32 @tz(ptr noundef byval([72 x i8]) align 8 %28, i32 noundef %85)
  store i32 %87, ptr %27, align 4
  %88 = load i576, ptr %21, align 8
  %89 = trunc i576 %88 to i575
  %90 = load i32, ptr %12, align 4
  %91 = zext i575 %89 to i576
  store i576 %91, ptr %30, align 8
  %92 = call i32 @tz(ptr noundef byval([72 x i8]) align 8 %30, i32 noundef %90)
  store i32 %92, ptr %29, align 4
  %93 = load ptr, ptr %11, align 8
  %94 = load ptr, ptr %14, align 8
  %95 = getelementptr inbounds i32, ptr %94, i64 0
  %96 = load i32, ptr %95, align 4
  %97 = load i32, ptr %23, align 4
  %98 = icmp eq i32 %96, %97
  %99 = zext i1 %98 to i32
  call void @want(ptr noundef %93, ptr noundef @.str.18, i32 noundef %99)
  %100 = load ptr, ptr %11, align 8
  %101 = load ptr, ptr %14, align 8
  %102 = getelementptr inbounds i32, ptr %101, i64 1
  %103 = load i32, ptr %102, align 4
  %104 = load i32, ptr %25, align 4
  %105 = icmp eq i32 %103, %104
  %106 = zext i1 %105 to i32
  call void @want(ptr noundef %100, ptr noundef @.str.19, i32 noundef %106)
  %107 = load ptr, ptr %11, align 8
  %108 = load ptr, ptr %14, align 8
  %109 = getelementptr inbounds i32, ptr %108, i64 2
  %110 = load i32, ptr %109, align 4
  %111 = load i32, ptr %27, align 4
  %112 = icmp eq i32 %110, %111
  %113 = zext i1 %112 to i32
  call void @want(ptr noundef %107, ptr noundef @.str.20, i32 noundef %113)
  %114 = load ptr, ptr %11, align 8
  %115 = load ptr, ptr %14, align 8
  %116 = getelementptr inbounds i32, ptr %115, i64 3
  %117 = load i32, ptr %116, align 4
  %118 = load i32, ptr %29, align 4
  %119 = icmp eq i32 %117, %118
  %120 = zext i1 %119 to i32
  call void @want(ptr noundef %114, ptr noundef @.str.21, i32 noundef %120)
  %121 = load ptr, ptr %11, align 8
  %122 = load ptr, ptr %14, align 8
  %123 = getelementptr inbounds i32, ptr %122, i64 4
  %124 = load i32, ptr %123, align 4
  %125 = load i32, ptr %25, align 4
  %126 = load i32, ptr %12, align 4
  %127 = icmp slt i32 %125, %126
  br i1 %127, label %128, label %131

128:                                              ; preds = %10
  %129 = load i32, ptr %25, align 4
  %130 = add nsw i32 %129, 1
  br label %132

131:                                              ; preds = %10
  br label %132

132:                                              ; preds = %131, %128
  %133 = phi i32 [ %130, %128 ], [ 0, %131 ]
  %134 = icmp eq i32 %124, %133
  %135 = zext i1 %134 to i32
  call void @want(ptr noundef %121, ptr noundef @.str.22, i32 noundef %135)
  %136 = load ptr, ptr %11, align 8
  %137 = load ptr, ptr %14, align 8
  %138 = getelementptr inbounds i32, ptr %137, i64 5
  %139 = load i32, ptr %138, align 4
  %140 = load i32, ptr %23, align 4
  %141 = load i32, ptr %12, align 4
  %142 = icmp slt i32 %140, %141
  br i1 %142, label %143, label %146

143:                                              ; preds = %132
  %144 = load i32, ptr %23, align 4
  %145 = add nsw i32 %144, 1
  br label %147

146:                                              ; preds = %132
  br label %147

147:                                              ; preds = %146, %143
  %148 = phi i32 [ %145, %143 ], [ 0, %146 ]
  %149 = icmp eq i32 %139, %148
  %150 = zext i1 %149 to i32
  call void @want(ptr noundef %136, ptr noundef @.str.23, i32 noundef %150)
  %151 = load ptr, ptr %11, align 8
  %152 = load ptr, ptr %14, align 8
  %153 = getelementptr inbounds i32, ptr %152, i64 6
  %154 = load i32, ptr %153, align 4
  %155 = load i32, ptr %29, align 4
  %156 = load i32, ptr %12, align 4
  %157 = icmp slt i32 %155, %156
  br i1 %157, label %158, label %161

158:                                              ; preds = %147
  %159 = load i32, ptr %29, align 4
  %160 = add nsw i32 %159, 1
  br label %162

161:                                              ; preds = %147
  br label %162

162:                                              ; preds = %161, %158
  %163 = phi i32 [ %160, %158 ], [ 0, %161 ]
  %164 = icmp eq i32 %154, %163
  %165 = zext i1 %164 to i32
  call void @want(ptr noundef %151, ptr noundef @.str.24, i32 noundef %165)
  %166 = load ptr, ptr %11, align 8
  %167 = load ptr, ptr %14, align 8
  %168 = getelementptr inbounds i32, ptr %167, i64 7
  %169 = load i32, ptr %168, align 4
  %170 = load i32, ptr %27, align 4
  %171 = load i32, ptr %12, align 4
  %172 = icmp slt i32 %170, %171
  br i1 %172, label %173, label %176

173:                                              ; preds = %162
  %174 = load i32, ptr %27, align 4
  %175 = add nsw i32 %174, 1
  br label %177

176:                                              ; preds = %162
  br label %177

177:                                              ; preds = %176, %173
  %178 = phi i32 [ %175, %173 ], [ 0, %176 ]
  %179 = icmp eq i32 %169, %178
  %180 = zext i1 %179 to i32
  call void @want(ptr noundef %166, ptr noundef @.str.25, i32 noundef %180)
  %181 = load ptr, ptr %11, align 8
  %182 = load ptr, ptr %14, align 8
  %183 = getelementptr inbounds i32, ptr %182, i64 8
  %184 = load i32, ptr %183, align 4
  %185 = load i32, ptr %12, align 4
  %186 = load i576, ptr %13, align 8
  %187 = trunc i576 %186 to i575
  %188 = load i32, ptr %12, align 4
  %189 = zext i575 %187 to i576
  store i576 %189, ptr %31, align 8
  %190 = call i32 @pop(ptr noundef byval([72 x i8]) align 8 %31, i32 noundef %188)
  %191 = sub nsw i32 %185, %190
  %192 = icmp eq i32 %184, %191
  %193 = zext i1 %192 to i32
  call void @want(ptr noundef %181, ptr noundef @.str.26, i32 noundef %193)
  %194 = load ptr, ptr %11, align 8
  %195 = load ptr, ptr %14, align 8
  %196 = getelementptr inbounds i32, ptr %195, i64 9
  %197 = load i32, ptr %196, align 4
  %198 = load i576, ptr %13, align 8
  %199 = trunc i576 %198 to i575
  %200 = load i32, ptr %12, align 4
  %201 = zext i575 %199 to i576
  store i576 %201, ptr %32, align 8
  %202 = call i32 @pop(ptr noundef byval([72 x i8]) align 8 %32, i32 noundef %200)
  %203 = icmp eq i32 %197, %202
  %204 = zext i1 %203 to i32
  call void @want(ptr noundef %194, ptr noundef @.str.27, i32 noundef %204)
  %205 = load ptr, ptr %11, align 8
  %206 = load ptr, ptr %14, align 8
  %207 = getelementptr inbounds i32, ptr %206, i64 10
  %208 = load i32, ptr %207, align 4
  %209 = load i576, ptr %13, align 8
  %210 = trunc i576 %209 to i575
  %211 = load i32, ptr %12, align 4
  %212 = zext i575 %210 to i576
  store i576 %212, ptr %33, align 8
  %213 = call i32 @pop(ptr noundef byval([72 x i8]) align 8 %33, i32 noundef %211)
  %214 = icmp eq i32 %213, 1
  %215 = zext i1 %214 to i32
  %216 = icmp eq i32 %208, %215
  %217 = zext i1 %216 to i32
  call void @want(ptr noundef %205, ptr noundef @.str.28, i32 noundef %217)
  %218 = load ptr, ptr %11, align 8
  %219 = load ptr, ptr %14, align 8
  %220 = getelementptr inbounds i32, ptr %219, i64 11
  %221 = load i32, ptr %220, align 4
  %222 = load i32, ptr %12, align 4
  %223 = load i32, ptr %23, align 4
  %224 = sub nsw i32 %222, %223
  %225 = icmp eq i32 %221, %224
  %226 = zext i1 %225 to i32
  call void @want(ptr noundef %218, ptr noundef @.str.29, i32 noundef %226)
  %227 = load ptr, ptr %11, align 8
  %228 = load i576, ptr %15, align 8
  %229 = trunc i576 %228 to i575
  %230 = load i576, ptr %13, align 8
  %231 = trunc i576 %230 to i575
  %232 = icmp ne i575 %231, 0
  br i1 %232, label %233, label %240

233:                                              ; preds = %177
  %234 = load i32, ptr %12, align 4
  %235 = sub nsw i32 %234, 1
  %236 = load i32, ptr %23, align 4
  %237 = sub nsw i32 %235, %236
  call void @one(ptr dead_on_unwind writable sret([72 x i8]) align 8 %34, i32 noundef %237)
  %238 = load i576, ptr %34, align 8
  %239 = trunc i576 %238 to i575
  br label %241

240:                                              ; preds = %177
  br label %241

241:                                              ; preds = %240, %233
  %242 = phi i575 [ %239, %233 ], [ 0, %240 ]
  %243 = icmp eq i575 %229, %242
  %244 = zext i1 %243 to i32
  call void @want(ptr noundef %227, ptr noundef @.str.30, i32 noundef %244)
  %245 = load ptr, ptr %11, align 8
  %246 = load i576, ptr %16, align 8
  %247 = trunc i576 %246 to i575
  %248 = load i576, ptr %13, align 8
  %249 = trunc i576 %248 to i575
  %250 = icmp ule i575 %249, 1
  br i1 %250, label %251, label %252

251:                                              ; preds = %241
  br label %277

252:                                              ; preds = %241
  %253 = load i32, ptr %12, align 4
  %254 = load i576, ptr %13, align 8
  %255 = trunc i576 %254 to i575
  %256 = sub i575 %255, 1
  %257 = load i32, ptr %12, align 4
  %258 = zext i575 %256 to i576
  store i576 %258, ptr %35, align 8
  %259 = call i32 @lz(ptr noundef byval([72 x i8]) align 8 %35, i32 noundef %257)
  %260 = sub nsw i32 %253, %259
  %261 = load i32, ptr %12, align 4
  %262 = icmp sge i32 %260, %261
  br i1 %262, label %263, label %264

263:                                              ; preds = %252
  br label %275

264:                                              ; preds = %252
  %265 = load i32, ptr %12, align 4
  %266 = load i576, ptr %13, align 8
  %267 = trunc i576 %266 to i575
  %268 = sub i575 %267, 1
  %269 = load i32, ptr %12, align 4
  %270 = zext i575 %268 to i576
  store i576 %270, ptr %36, align 8
  %271 = call i32 @lz(ptr noundef byval([72 x i8]) align 8 %36, i32 noundef %269)
  %272 = sub nsw i32 %265, %271
  call void @one(ptr dead_on_unwind writable sret([72 x i8]) align 8 %37, i32 noundef %272)
  %273 = load i576, ptr %37, align 8
  %274 = trunc i576 %273 to i575
  br label %275

275:                                              ; preds = %264, %263
  %276 = phi i575 [ 0, %263 ], [ %274, %264 ]
  br label %277

277:                                              ; preds = %275, %251
  %278 = phi i575 [ 1, %251 ], [ %276, %275 ]
  %279 = icmp eq i575 %247, %278
  %280 = zext i1 %279 to i32
  call void @want(ptr noundef %245, ptr noundef @.str.31, i32 noundef %280)
  %281 = load ptr, ptr %11, align 8
  %282 = load i576, ptr %17, align 8
  %283 = trunc i576 %282 to i575
  %284 = load i576, ptr %13, align 8
  %285 = trunc i576 %284 to i575
  %286 = load i32, ptr %12, align 4
  %287 = zext i575 %285 to i576
  store i576 %287, ptr %39, align 8
  call void @rotl(ptr dead_on_unwind writable sret([72 x i8]) align 8 %38, ptr noundef byval([72 x i8]) align 8 %39, i32 noundef %286, i64 noundef 3)
  %288 = load i576, ptr %38, align 8
  %289 = trunc i576 %288 to i575
  %290 = icmp eq i575 %283, %289
  %291 = zext i1 %290 to i32
  call void @want(ptr noundef %281, ptr noundef @.str.32, i32 noundef %291)
  %292 = load ptr, ptr %11, align 8
  %293 = load i576, ptr %18, align 8
  %294 = trunc i576 %293 to i575
  %295 = load i576, ptr %13, align 8
  %296 = trunc i576 %295 to i575
  %297 = load i32, ptr %12, align 4
  %298 = load i32, ptr %12, align 4
  %299 = load i32, ptr %12, align 4
  %300 = srem i32 3, %299
  %301 = sub i32 %298, %300
  %302 = zext i32 %301 to i64
  %303 = zext i575 %296 to i576
  store i576 %303, ptr %41, align 8
  call void @rotl(ptr dead_on_unwind writable sret([72 x i8]) align 8 %40, ptr noundef byval([72 x i8]) align 8 %41, i32 noundef %297, i64 noundef %302)
  %304 = load i576, ptr %40, align 8
  %305 = trunc i576 %304 to i575
  %306 = icmp eq i575 %294, %305
  %307 = zext i1 %306 to i32
  call void @want(ptr noundef %292, ptr noundef @.str.33, i32 noundef %307)
  %308 = load ptr, ptr %11, align 8
  %309 = load i576, ptr %19, align 8
  %310 = trunc i576 %309 to i575
  %311 = load i576, ptr %13, align 8
  %312 = trunc i576 %311 to i575
  %313 = icmp eq i575 %310, %312
  %314 = zext i1 %313 to i32
  call void @want(ptr noundef %308, ptr noundef @.str.34, i32 noundef %314)
  %315 = load ptr, ptr %11, align 8
  %316 = load i576, ptr %20, align 8
  %317 = trunc i576 %316 to i575
  %318 = load i576, ptr %13, align 8
  %319 = trunc i576 %318 to i575
  %320 = load i32, ptr %12, align 4
  %321 = zext i575 %319 to i576
  store i576 %321, ptr %43, align 8
  call void @rotl(ptr dead_on_unwind writable sret([72 x i8]) align 8 %42, ptr noundef byval([72 x i8]) align 8 %43, i32 noundef %320, i64 noundef 1000)
  %322 = load i576, ptr %42, align 8
  %323 = trunc i576 %322 to i575
  %324 = icmp eq i575 %317, %323
  %325 = zext i1 %324 to i32
  call void @want(ptr noundef %315, ptr noundef @.str.35, i32 noundef %325)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctlz.i16(i16, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.cttz.i16(i16, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.ctpop.i16(i16) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshl.i16(i16, i16, i16) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.fshr.i16(i16, i16, i16) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.cttz.i32(i32, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshr.i32(i32, i32, i32) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshl.i64(i64, i64, i64) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshr.i64(i64, i64, i64) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctlz.i128(i128, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.cttz.i128(i128, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.ctpop.i128(i128) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshl.i128(i128, i128, i128) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i128 @llvm.fshr.i128(i128, i128, i128) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i7 @llvm.ctlz.i7(i7, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i7 @llvm.cttz.i7(i7, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i7 @llvm.ctpop.i7(i7) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i7 @llvm.fshl.i7(i7, i7, i7) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i7 @llvm.fshr.i7(i7, i7, i7) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i65 @llvm.ctlz.i65(i65, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i65 @llvm.cttz.i65(i65, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i65 @llvm.ctpop.i65(i65) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i65 @llvm.fshl.i65(i65, i65, i65) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i65 @llvm.fshr.i65(i65, i65, i65) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i129 @llvm.ctlz.i129(i129, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i129 @llvm.cttz.i129(i129, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i129 @llvm.ctpop.i129(i129) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i129 @llvm.fshl.i129(i129, i129, i129) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i129 @llvm.fshr.i129(i129, i129, i129) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i256 @llvm.ctlz.i256(i256, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i256 @llvm.cttz.i256(i256, i1 immarg) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i256 @llvm.ctpop.i256(i256) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i256 @llvm.fshl.i256(i256, i256, i256) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i256 @llvm.fshr.i256(i256, i256, i256) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @mask(ptr dead_on_unwind noalias writable sret([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca [72 x i8], align 8
  store i32 %1, ptr %3, align 4
  %5 = load i32, ptr %3, align 4
  %6 = icmp eq i32 %5, 575
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  br label %13

8:                                                ; preds = %2
  %9 = load i32, ptr %3, align 4
  call void @one(ptr dead_on_unwind writable sret([72 x i8]) align 8 %4, i32 noundef %9)
  %10 = load i576, ptr %4, align 8
  %11 = trunc i576 %10 to i575
  %12 = sub i575 %11, 1
  br label %13

13:                                               ; preds = %8, %7
  %14 = phi i575 [ -1, %7 ], [ %12, %8 ]
  %15 = zext i575 %14 to i576
  store i576 %15, ptr %0, align 8
  %16 = load i576, ptr %0, align 8
  %17 = trunc i576 %16 to i575
  %18 = zext i575 %17 to i576
  store i576 %18, ptr %0, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @lz(ptr noundef byval([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca [72 x i8], align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca [72 x i8], align 8
  %8 = load i576, ptr %0, align 8
  %9 = trunc i576 %8 to i575
  %10 = zext i575 %9 to i576
  store i576 %10, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  %11 = load i32, ptr %4, align 4
  %12 = sub nsw i32 %11, 1
  store i32 %12, ptr %6, align 4
  br label %13

13:                                               ; preds = %29, %2
  %14 = load i32, ptr %6, align 4
  %15 = icmp sge i32 %14, 0
  br i1 %15, label %16, label %24

16:                                               ; preds = %13
  %17 = load i576, ptr %3, align 8
  %18 = trunc i576 %17 to i575
  %19 = load i32, ptr %6, align 4
  %20 = zext i575 %18 to i576
  store i576 %20, ptr %7, align 8
  %21 = call i32 @bit(ptr noundef byval([72 x i8]) align 8 %7, i32 noundef %19)
  %22 = icmp ne i32 %21, 0
  %23 = xor i1 %22, true
  br label %24

24:                                               ; preds = %16, %13
  %25 = phi i1 [ false, %13 ], [ %23, %16 ]
  br i1 %25, label %26, label %32

26:                                               ; preds = %24
  %27 = load i32, ptr %5, align 4
  %28 = add nsw i32 %27, 1
  store i32 %28, ptr %5, align 4
  br label %29

29:                                               ; preds = %26
  %30 = load i32, ptr %6, align 4
  %31 = add nsw i32 %30, -1
  store i32 %31, ptr %6, align 4
  br label %13, !llvm.loop !6

32:                                               ; preds = %24
  %33 = load i32, ptr %5, align 4
  ret i32 %33
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @tz(ptr noundef byval([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca [72 x i8], align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca [72 x i8], align 8
  %8 = load i576, ptr %0, align 8
  %9 = trunc i576 %8 to i575
  %10 = zext i575 %9 to i576
  store i576 %10, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  store i32 0, ptr %6, align 4
  br label %11

11:                                               ; preds = %28, %2
  %12 = load i32, ptr %6, align 4
  %13 = load i32, ptr %4, align 4
  %14 = icmp slt i32 %12, %13
  br i1 %14, label %15, label %23

15:                                               ; preds = %11
  %16 = load i576, ptr %3, align 8
  %17 = trunc i576 %16 to i575
  %18 = load i32, ptr %6, align 4
  %19 = zext i575 %17 to i576
  store i576 %19, ptr %7, align 8
  %20 = call i32 @bit(ptr noundef byval([72 x i8]) align 8 %7, i32 noundef %18)
  %21 = icmp ne i32 %20, 0
  %22 = xor i1 %21, true
  br label %23

23:                                               ; preds = %15, %11
  %24 = phi i1 [ false, %11 ], [ %22, %15 ]
  br i1 %24, label %25, label %31

25:                                               ; preds = %23
  %26 = load i32, ptr %5, align 4
  %27 = add nsw i32 %26, 1
  store i32 %27, ptr %5, align 4
  br label %28

28:                                               ; preds = %25
  %29 = load i32, ptr %6, align 4
  %30 = add nsw i32 %29, 1
  store i32 %30, ptr %6, align 4
  br label %11, !llvm.loop !8

31:                                               ; preds = %23
  %32 = load i32, ptr %5, align 4
  ret i32 %32
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @want(ptr noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  %7 = load i32, ptr %6, align 4
  %8 = icmp ne i32 %7, 0
  br i1 %8, label %16, label %9

9:                                                ; preds = %3
  %10 = load ptr, ptr @stderr, align 8
  %11 = load ptr, ptr %4, align 8
  %12 = load ptr, ptr %5, align 8
  %13 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %10, ptr noundef @.str.36, ptr noundef %11, ptr noundef %12) #6
  %14 = load i32, ptr @fails, align 4
  %15 = add nsw i32 %14, 1
  store i32 %15, ptr @fails, align 4
  br label %16

16:                                               ; preds = %9, %3
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @pop(ptr noundef byval([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca [72 x i8], align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca [72 x i8], align 8
  %8 = load i576, ptr %0, align 8
  %9 = trunc i576 %8 to i575
  %10 = zext i575 %9 to i576
  store i576 %10, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  store i32 0, ptr %6, align 4
  br label %11

11:                                               ; preds = %23, %2
  %12 = load i32, ptr %6, align 4
  %13 = load i32, ptr %4, align 4
  %14 = icmp slt i32 %12, %13
  br i1 %14, label %15, label %26

15:                                               ; preds = %11
  %16 = load i576, ptr %3, align 8
  %17 = trunc i576 %16 to i575
  %18 = load i32, ptr %6, align 4
  %19 = zext i575 %17 to i576
  store i576 %19, ptr %7, align 8
  %20 = call i32 @bit(ptr noundef byval([72 x i8]) align 8 %7, i32 noundef %18)
  %21 = load i32, ptr %5, align 4
  %22 = add nsw i32 %21, %20
  store i32 %22, ptr %5, align 4
  br label %23

23:                                               ; preds = %15
  %24 = load i32, ptr %6, align 4
  %25 = add nsw i32 %24, 1
  store i32 %25, ptr %6, align 4
  br label %11, !llvm.loop !9

26:                                               ; preds = %11
  %27 = load i32, ptr %5, align 4
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @one(ptr dead_on_unwind noalias writable sret([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  store i32 %1, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = zext i32 %4 to i575
  %6 = shl i575 1, %5
  %7 = zext i575 %6 to i576
  store i576 %7, ptr %0, align 8
  %8 = load i576, ptr %0, align 8
  %9 = trunc i576 %8 to i575
  %10 = zext i575 %9 to i576
  store i576 %10, ptr %0, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @rotl(ptr dead_on_unwind noalias writable sret([72 x i8]) align 8 %0, ptr noundef byval([72 x i8]) align 8 %1, i32 noundef %2, i64 noundef %3) #0 {
  %5 = alloca [72 x i8], align 8
  %6 = alloca i32, align 4
  %7 = alloca i64, align 8
  %8 = alloca i32, align 4
  %9 = alloca [72 x i8], align 8
  %10 = alloca i32, align 4
  %11 = alloca [72 x i8], align 8
  %12 = alloca [72 x i8], align 8
  %13 = load i576, ptr %1, align 8
  %14 = trunc i576 %13 to i575
  %15 = zext i575 %14 to i576
  store i576 %15, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  store i64 %3, ptr %7, align 8
  %16 = load i64, ptr %7, align 8
  %17 = load i32, ptr %6, align 4
  %18 = zext i32 %17 to i64
  %19 = urem i64 %16, %18
  %20 = trunc i64 %19 to i32
  store i32 %20, ptr %8, align 4
  store i576 0, ptr %9, align 8
  store i32 0, ptr %10, align 4
  br label %21

21:                                               ; preds = %45, %4
  %22 = load i32, ptr %10, align 4
  %23 = load i32, ptr %6, align 4
  %24 = icmp slt i32 %22, %23
  br i1 %24, label %25, label %48

25:                                               ; preds = %21
  %26 = load i576, ptr %5, align 8
  %27 = trunc i576 %26 to i575
  %28 = load i32, ptr %10, align 4
  %29 = zext i575 %27 to i576
  store i576 %29, ptr %11, align 8
  %30 = call i32 @bit(ptr noundef byval([72 x i8]) align 8 %11, i32 noundef %28)
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %32, label %44

32:                                               ; preds = %25
  %33 = load i32, ptr %10, align 4
  %34 = load i32, ptr %8, align 4
  %35 = add nsw i32 %33, %34
  %36 = load i32, ptr %6, align 4
  %37 = srem i32 %35, %36
  call void @one(ptr dead_on_unwind writable sret([72 x i8]) align 8 %12, i32 noundef %37)
  %38 = load i576, ptr %12, align 8
  %39 = trunc i576 %38 to i575
  %40 = load i576, ptr %9, align 8
  %41 = trunc i576 %40 to i575
  %42 = or i575 %41, %39
  %43 = zext i575 %42 to i576
  store i576 %43, ptr %9, align 8
  br label %44

44:                                               ; preds = %32, %25
  br label %45

45:                                               ; preds = %44
  %46 = load i32, ptr %10, align 4
  %47 = add nsw i32 %46, 1
  store i32 %47, ptr %10, align 4
  br label %21, !llvm.loop !10

48:                                               ; preds = %21
  %49 = load i576, ptr %9, align 8
  %50 = trunc i576 %49 to i575
  %51 = zext i575 %50 to i576
  store i576 %51, ptr %0, align 8
  %52 = load i576, ptr %0, align 8
  %53 = trunc i576 %52 to i575
  %54 = zext i575 %53 to i576
  store i576 %54, ptr %0, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @bit(ptr noundef byval([72 x i8]) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca [72 x i8], align 8
  %4 = alloca i32, align 4
  %5 = load i576, ptr %0, align 8
  %6 = trunc i576 %5 to i575
  %7 = zext i575 %6 to i576
  store i576 %7, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %8 = load i576, ptr %3, align 8
  %9 = trunc i576 %8 to i575
  %10 = load i32, ptr %4, align 4
  %11 = zext i32 %10 to i575
  %12 = lshr i575 %9, %11
  %13 = and i575 %12, 1
  %14 = trunc i575 %13 to i32
  ret i32 %14
}

; Function Attrs: nounwind
declare i32 @fprintf(ptr noundef, ptr noundef, ...) #5

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.5"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
