; ModuleID = 'test/c/synth/expr-bitwise-logical.c'
source_filename = "test/c/synth/expr-bitwise-logical.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [12 x i8] c"0xF0 & 0x3C\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"0xF0 ^ 0x3C\00", align 1
@.str.3 = private unnamed_addr constant [12 x i8] c"0xF0 | 0x0F\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"and1\00", align 1
@.str.5 = private unnamed_addr constant [4 x i8] c"or1\00", align 1
@.str.6 = private unnamed_addr constant [5 x i8] c"and2\00", align 1
@.str.7 = private unnamed_addr constant [6 x i8] c"calls\00", align 1
@calls = internal global i32 0, align 4
@.str.8 = private unnamed_addr constant [7 x i8] c"0 || 0\00", align 1
@.str.9 = private unnamed_addr constant [7 x i8] c"5 && 7\00", align 1
@.str.10 = private unnamed_addr constant [10 x i8] c"!(1 && 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %5 = call i32 @hit(i32 noundef 0)
  %6 = icmp ne i32 %5, 0
  br i1 %6, label %7, label %10

7:                                                ; preds = %0
  %8 = call i32 @hit(i32 noundef 1)
  %9 = icmp ne i32 %8, 0
  br label %10

10:                                               ; preds = %7, %0
  %11 = phi i1 [ false, %0 ], [ %9, %7 ]
  %12 = zext i1 %11 to i32
  store i32 %12, ptr %2, align 4
  %13 = call i32 @hit(i32 noundef 1)
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %18, label %15

15:                                               ; preds = %10
  %16 = call i32 @hit(i32 noundef 0)
  %17 = icmp ne i32 %16, 0
  br label %18

18:                                               ; preds = %15, %10
  %19 = phi i1 [ true, %10 ], [ %17, %15 ]
  %20 = zext i1 %19 to i32
  store i32 %20, ptr %3, align 4
  %21 = call i32 @hit(i32 noundef 1)
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %23, label %26

23:                                               ; preds = %18
  %24 = call i32 @hit(i32 noundef 2)
  %25 = icmp ne i32 %24, 0
  br label %26

26:                                               ; preds = %23, %18
  %27 = phi i1 [ false, %18 ], [ %25, %23 ]
  %28 = zext i1 %27 to i32
  store i32 %28, ptr %4, align 4
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 48)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 204)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 255)
  %32 = load i32, ptr %2, align 4
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %32)
  %34 = load i32, ptr %3, align 4
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %34)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %36)
  %38 = load i32, ptr @calls, align 4
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %38)
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 0)
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 1)
  %42 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 1)
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @hit(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr @calls, align 4
  %4 = add nsw i32 %3, 1
  store i32 %4, ptr @calls, align 4
  %5 = load i32, ptr %2, align 4
  ret i32 %5
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
