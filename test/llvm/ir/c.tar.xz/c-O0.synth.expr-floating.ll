; ModuleID = 'test/c/synth/expr-floating.c'
source_filename = "test/c/synth/expr-floating.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [12 x i8] c"%s = %.17g\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"a + b\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"%s = %.9g\0A\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"(double)f\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"a + b == 0.3\00", align 1
@.str.6 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"1.0 / 4\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"-z\00", align 1
@.str.9 = private unnamed_addr constant [16 x i8] c"1.0 / 3 > 0.333\00", align 1
@.str.10 = private unnamed_addr constant [31 x i8] c"1e308 * 10 > 1e308 ? 1.0 : 0.0\00", align 1
@.str.11 = private unnamed_addr constant [11 x i8] c"%s = %.3f\0A\00", align 1
@.str.12 = private unnamed_addr constant [17 x i8] c"2.0 * 1.5 - 0.25\00", align 1
@.str.13 = private unnamed_addr constant [17 x i8] c"(int)(7.0 / 2.0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca float, align 4
  %5 = alloca double, align 8
  store i32 0, ptr %1, align 4
  store double 1.000000e-01, ptr %2, align 8
  store double 2.000000e-01, ptr %3, align 8
  store float f0x3EAAAAAB, ptr %4, align 4
  store double 0.000000e+00, ptr %5, align 8
  %6 = load double, ptr %2, align 8
  %7 = load double, ptr %3, align 8
  %8 = fadd double %6, %7
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, double noundef %8)
  %10 = load float, ptr %4, align 4
  %11 = fpext float %10 to double
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, double noundef %11)
  %13 = load double, ptr %2, align 8
  %14 = load double, ptr %3, align 8
  %15 = fadd double %13, %14
  %16 = fcmp oeq double %15, 3.000000e-01
  %17 = zext i1 %16 to i32
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef %17)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.7, double noundef 2.500000e-01)
  %20 = load double, ptr %5, align 8
  %21 = fneg double %20
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.8, double noundef %21)
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.9, i32 noundef 1)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.10, double noundef 1.000000e+00)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.12, double noundef 2.750000e+00)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.13, i32 noundef 3)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
