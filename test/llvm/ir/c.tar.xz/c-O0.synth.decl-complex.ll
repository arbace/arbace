; ModuleID = 'test/c/synth/decl-complex.c'
source_filename = "test/c/synth/decl-complex.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { { double, double } }
%union.anon.0 = type { { double, double } }

@.str = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"creal(w)\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"cimag(w)\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"crealf(fz)\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"cimag(c)\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.6 = private unnamed_addr constant [19 x i8] c"z == 1.0 + 2.0 * I\00", align 1
@.str.7 = private unnamed_addr constant [13 x i8] c"creal(z + w)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca { double, double }, align 8
  %3 = alloca { double, double }, align 8
  %4 = alloca { float, float }, align 4
  %5 = alloca { double, double }, align 8
  %6 = alloca %union.anon, align 8
  %7 = alloca %union.anon.0, align 8
  store i32 0, ptr %1, align 4
  %8 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %9 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  store double 1.000000e+00, ptr %8, align 8
  store double 2.000000e+00, ptr %9, align 8
  %10 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %11 = load double, ptr %10, align 8
  %12 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %13 = load double, ptr %12, align 8
  %14 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %15 = load double, ptr %14, align 8
  %16 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %17 = load double, ptr %16, align 8
  %18 = fmul double %11, %15
  %19 = fmul double %13, %17
  %20 = fmul double %11, %17
  %21 = fmul double %13, %15
  %22 = fsub double %18, %19
  %23 = fadd double %20, %21
  %24 = fcmp uno double %22, %22
  br i1 %24, label %25, label %31, !prof !6

25:                                               ; preds = %0
  %26 = fcmp uno double %23, %23
  br i1 %26, label %27, label %31, !prof !6

27:                                               ; preds = %25
  %28 = call { double, double } @__muldc3(double noundef %11, double noundef %13, double noundef %15, double noundef %17) #2
  %29 = extractvalue { double, double } %28, 0
  %30 = extractvalue { double, double } %28, 1
  br label %31

31:                                               ; preds = %27, %25, %0
  %32 = phi double [ %22, %0 ], [ %22, %25 ], [ %29, %27 ]
  %33 = phi double [ %23, %0 ], [ %23, %25 ], [ %30, %27 ]
  %34 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %35 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  store double %32, ptr %34, align 8
  store double %33, ptr %35, align 8
  %36 = getelementptr inbounds nuw { float, float }, ptr %4, i32 0, i32 0
  %37 = getelementptr inbounds nuw { float, float }, ptr %4, i32 0, i32 1
  store float 3.000000e+00, ptr %36, align 4
  store float 0.000000e+00, ptr %37, align 4
  %38 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %39 = load double, ptr %38, align 8
  %40 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %41 = load double, ptr %40, align 8
  %42 = fneg double %41
  %43 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 0
  %44 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 1
  store double %39, ptr %43, align 8
  store double %42, ptr %44, align 8
  %45 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %46 = load double, ptr %45, align 8
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, double noundef %46)
  %48 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %49 = load double, ptr %48, align 8
  %50 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  %51 = load double, ptr %50, align 8
  %52 = getelementptr inbounds nuw { double, double }, ptr %6, i32 0, i32 0
  %53 = getelementptr inbounds nuw { double, double }, ptr %6, i32 0, i32 1
  store double %49, ptr %52, align 8
  store double %51, ptr %53, align 8
  %54 = getelementptr inbounds [2 x double], ptr %6, i64 0, i64 1
  %55 = load double, ptr %54, align 8
  %56 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, double noundef %55)
  %57 = getelementptr inbounds nuw { float, float }, ptr %4, i32 0, i32 0
  %58 = load float, ptr %57, align 4
  %59 = fpext float %58 to double
  %60 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, double noundef %59)
  %61 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 0
  %62 = load double, ptr %61, align 8
  %63 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 1
  %64 = load double, ptr %63, align 8
  %65 = getelementptr inbounds nuw { double, double }, ptr %7, i32 0, i32 0
  %66 = getelementptr inbounds nuw { double, double }, ptr %7, i32 0, i32 1
  store double %62, ptr %65, align 8
  store double %64, ptr %66, align 8
  %67 = getelementptr inbounds [2 x double], ptr %7, i64 0, i64 1
  %68 = load double, ptr %67, align 8
  %69 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, double noundef %68)
  %70 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %71 = load double, ptr %70, align 8
  %72 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %73 = load double, ptr %72, align 8
  %74 = fcmp oeq double %71, 1.000000e+00
  %75 = fcmp oeq double %73, 2.000000e+00
  %76 = and i1 %74, %75
  %77 = zext i1 %76 to i32
  %78 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.6, i32 noundef %77)
  %79 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %80 = load double, ptr %79, align 8
  %81 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %82 = load double, ptr %81, align 8
  %83 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %84 = load double, ptr %83, align 8
  %85 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  %86 = load double, ptr %85, align 8
  %87 = fadd double %80, %84
  %88 = fadd double %82, %86
  %89 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, double noundef %87)
  ret i32 0
}

declare { double, double } @__muldc3(double, double, double, double)

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{!"branch_weights", i32 1, i32 1048575}
