; ModuleID = 'test/c/synth/pp-embed.c'
source_filename = "test/c/synth/pp-embed.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"sizeof all\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"all[0]\00", align 1
@all = internal constant [5 x i8] c"C23!\0A", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"all[3]\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"all[4]\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"sizeof two\00", align 1
@.str.7 = private unnamed_addr constant [7 x i8] c"two[1]\00", align 1
@two = internal constant [2 x i8] c"C2", align 1
@.str.8 = private unnamed_addr constant [33 x i8] c"sizeof framed / sizeof framed[0]\00", align 1
@.str.9 = private unnamed_addr constant [10 x i8] c"framed[0]\00", align 1
@framed = internal constant [3 x i32] [i32 100, i32 67, i32 200], align 4
@.str.10 = private unnamed_addr constant [10 x i8] c"framed[1]\00", align 1
@.str.11 = private unnamed_addr constant [10 x i8] c"framed[2]\00", align 1
@.str.12 = private unnamed_addr constant [8 x i8] c"none[0]\00", align 1
@none = internal constant [1 x i32] [i32 42], align 4
@.str.13 = private unnamed_addr constant [6 x i8] c"count\00", align 1
@.str.14 = private unnamed_addr constant [7 x i8] c"has_ok\00", align 1
@has_ok = internal global i32 1, align 4
@.str.15 = private unnamed_addr constant [25 x i8] c"__STDC_EMBED_NOT_FOUND__\00", align 1
@.str.16 = private unnamed_addr constant [21 x i8] c"__STDC_EMBED_FOUND__\00", align 1
@.str.17 = private unnamed_addr constant [21 x i8] c"__STDC_EMBED_EMPTY__\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i64 noundef 5)
  %3 = load i8, ptr @all, align 1
  %4 = zext i8 %3 to i32
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i32 noundef %4)
  %6 = load i8, ptr getelementptr inbounds nuw (i8, ptr @all, i64 3), align 1
  %7 = zext i8 %6 to i32
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.4, i32 noundef %7)
  %9 = load i8, ptr getelementptr inbounds nuw (i8, ptr @all, i64 4), align 1
  %10 = zext i8 %9 to i32
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.5, i32 noundef %10)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i64 noundef 2)
  %13 = load i8, ptr getelementptr inbounds nuw (i8, ptr @two, i64 1), align 1
  %14 = zext i8 %13 to i32
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.7, i32 noundef %14)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i64 noundef 3)
  %17 = load i32, ptr @framed, align 4
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.9, i32 noundef %17)
  %19 = load i32, ptr getelementptr inbounds nuw (i8, ptr @framed, i64 4), align 4
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.10, i32 noundef %19)
  %21 = load i32, ptr getelementptr inbounds nuw (i8, ptr @framed, i64 8), align 4
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.11, i32 noundef %21)
  %23 = load i32, ptr @none, align 4
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.12, i32 noundef %23)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.13, i32 noundef 5)
  %26 = load i32, ptr @has_ok, align 4
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.14, i32 noundef %26)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.15, i32 noundef 0)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.16, i32 noundef 1)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.17, i32 noundef 2)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
