; ModuleID = 'test/c/synth/expr-sizeof-vla.c'
source_filename = "test/c/synth/expr-sizeof-vla.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"width(5)\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.3 = private unnamed_addr constant [23 x i8] c"sizeof m / sizeof m[0]\00", align 1
@.str.4 = private unnamed_addr constant [29 x i8] c"sizeof m[0] / sizeof m[0][0]\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"k\00", align 1
@.str.6 = private unnamed_addr constant [16 x i8] c"s / sizeof(int)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i32, align 4
  %7 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store i32 6, ptr %2, align 4
  %8 = load i32, ptr %2, align 4
  %9 = zext i32 %8 to i64
  %10 = load i32, ptr %2, align 4
  %11 = add nsw i32 %10, 1
  %12 = zext i32 %11 to i64
  %13 = call ptr @llvm.stacksave.p0()
  store ptr %13, ptr %3, align 8
  %14 = mul nuw i64 %9, %12
  %15 = alloca i32, i64 %14, align 16
  store i64 %9, ptr %4, align 8
  store i64 %12, ptr %5, align 8
  store i32 0, ptr %6, align 4
  %16 = load i32, ptr %6, align 4
  %17 = add nsw i32 %16, 1
  store i32 %17, ptr %6, align 4
  %18 = zext i32 %17 to i64
  %19 = mul nuw i64 4, %18
  store i64 %19, ptr %7, align 8
  %20 = call i32 @width(i32 noundef 5)
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %20)
  %22 = mul nuw i64 %9, %12
  %23 = mul nuw i64 4, %22
  %24 = mul nsw i64 0, %12
  %25 = getelementptr inbounds i32, ptr %15, i64 %24
  %26 = mul nuw i64 4, %12
  %27 = udiv i64 %23, %26
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i64 noundef %27)
  %29 = mul nsw i64 0, %12
  %30 = getelementptr inbounds i32, ptr %15, i64 %29
  %31 = mul nuw i64 4, %12
  %32 = udiv i64 %31, 4
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.4, i64 noundef %32)
  %34 = load i32, ptr %6, align 4
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %34)
  %36 = load i64, ptr %7, align 8
  %37 = udiv i64 %36, 4
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.6, i64 noundef %37)
  store i32 0, ptr %1, align 4
  %39 = load ptr, ptr %3, align 8
  call void @llvm.stackrestore.p0(ptr %39)
  %40 = load i32, ptr %1, align 4
  ret i32 %40
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #1

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @width(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store i32 %0, ptr %2, align 4
  %5 = load i32, ptr %2, align 4
  %6 = zext i32 %5 to i64
  %7 = call ptr @llvm.stacksave.p0()
  store ptr %7, ptr %3, align 8
  %8 = alloca i32, i64 %6, align 16
  store i64 %6, ptr %4, align 8
  %9 = mul nuw i64 4, %6
  %10 = udiv i64 %9, 4
  %11 = trunc i64 %10 to i32
  %12 = load ptr, ptr %3, align 8
  call void @llvm.stackrestore.p0(ptr %12)
  ret i32 %11
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
