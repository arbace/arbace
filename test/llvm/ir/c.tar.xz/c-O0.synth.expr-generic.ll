; ModuleID = 'test/c/synth/expr-generic.c'
source_filename = "test/c/synth/expr-generic.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.s = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"KIND(1)\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"KIND(1u)\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"KIND(1l)\00", align 1
@.str.4 = private unnamed_addr constant [10 x i8] c"KIND(1.0)\00", align 1
@.str.5 = private unnamed_addr constant [8 x i8] c"KIND(s)\00", align 1
@.str.6 = private unnamed_addr constant [22 x i8] c"KIND((const char *)s)\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"KIND(a)\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"KIND(ci)\00", align 1
@.str.9 = private unnamed_addr constant [11 x i8] c"KIND(1.0f)\00", align 1
@.str.10 = private unnamed_addr constant [9 x i8] c"KIND(sh)\00", align 1
@.str.11 = private unnamed_addr constant [10 x i8] c"KIND(+sh)\00", align 1
@.str.12 = private unnamed_addr constant [35 x i8] c"_Generic(ci, int: 1, const int: 2)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [2 x i32], align 4
  %4 = alloca [2 x i8], align 1
  %5 = alloca i16, align 2
  store i32 0, ptr %1, align 4
  store i32 1, ptr %2, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %3, i8 0, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %4, ptr align 1 @__const.main.s, i64 2, i1 false)
  store i16 1, ptr %5, align 2
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 1)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 2)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 3)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 4)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 5)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 6)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 7)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 1)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 0)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 0)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 1)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 1)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

declare i32 @printf(ptr noundef, ...) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
