; ModuleID = 'test/c/synth/lex-char-constants.c'
source_filename = "test/c/synth/lex-char-constants.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"'a'\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"'\\n'\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"'\\t'\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"'\\0'\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"'\\101'\00", align 1
@.str.6 = private unnamed_addr constant [7 x i8] c"'\\x41'\00", align 1
@.str.7 = private unnamed_addr constant [5 x i8] c"'\\''\00", align 1
@.str.8 = private unnamed_addr constant [5 x i8] c"'\\\22'\00", align 1
@.str.9 = private unnamed_addr constant [5 x i8] c"'\\\\'\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"'\\?'\00", align 1
@.str.11 = private unnamed_addr constant [5 x i8] c"'\\a'\00", align 1
@.str.12 = private unnamed_addr constant [5 x i8] c"'\\b'\00", align 1
@.str.13 = private unnamed_addr constant [5 x i8] c"'\\f'\00", align 1
@.str.14 = private unnamed_addr constant [5 x i8] c"'\\r'\00", align 1
@.str.15 = private unnamed_addr constant [5 x i8] c"'\\v'\00", align 1
@.str.16 = private unnamed_addr constant [5 x i8] c"L'a'\00", align 1
@.str.17 = private unnamed_addr constant [5 x i8] c"u'a'\00", align 1
@.str.18 = private unnamed_addr constant [5 x i8] c"U'a'\00", align 1
@.str.19 = private unnamed_addr constant [6 x i8] c"u8'a'\00", align 1
@.str.20 = private unnamed_addr constant [10 x i8] c"U'\\u00e9'\00", align 1
@.str.21 = private unnamed_addr constant [10 x i8] c"u'\\u20AC'\00", align 1
@.str.22 = private unnamed_addr constant [19 x i8] c"(int)U'\\U0001F600'\00", align 1
@.str.23 = private unnamed_addr constant [46 x i8] c"_Generic(u8'a', unsigned char: 1, default: 0)\00", align 1
@.str.24 = private unnamed_addr constant [46 x i8] c"_Generic(u'a', unsigned short: 1, default: 0)\00", align 1
@.str.25 = private unnamed_addr constant [44 x i8] c"_Generic(U'a', unsigned int: 1, default: 0)\00", align 1
@.str.26 = private unnamed_addr constant [34 x i8] c"_Generic('a', int: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 97)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 10)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 9)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 0)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 65)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 65)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 39)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 34)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 92)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 63)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 7)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 8)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef 12)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef 13)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 11)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef 97)
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17, i32 noundef 97)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.18, i32 noundef 97)
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.19, i32 noundef 97)
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.20, i32 noundef 233)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.21, i32 noundef 8364)
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.22, i32 noundef 128512)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.23, i32 noundef 1)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.24, i32 noundef 1)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.25, i32 noundef 1)
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.26, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
