; ModuleID = 'test/c/synth/expr-arithmetic.c'
source_filename = "test/c/synth/expr-arithmetic.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.a = private unnamed_addr constant [5 x i32] [i32 1, i32 2, i32 3, i32 4, i32 5], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"7 * 6\00", align 1
@.str.2 = private unnamed_addr constant [7 x i8] c"17 / 5\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"17 % 5\00", align 1
@.str.4 = private unnamed_addr constant [8 x i8] c"-17 / 5\00", align 1
@.str.5 = private unnamed_addr constant [8 x i8] c"-17 % 5\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"17 / -5\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"17 % -5\00", align 1
@.str.8 = private unnamed_addr constant [6 x i8] c"3 + 4\00", align 1
@.str.9 = private unnamed_addr constant [7 x i8] c"3 - 10\00", align 1
@.str.10 = private unnamed_addr constant [9 x i8] c"*(p + 2)\00", align 1
@.str.11 = private unnamed_addr constant [9 x i8] c"*(q - 1)\00", align 1
@.str.12 = private unnamed_addr constant [10 x i8] c"%s = %td\0A\00", align 1
@.str.13 = private unnamed_addr constant [6 x i8] c"q - p\00", align 1
@.str.14 = private unnamed_addr constant [6 x i8] c"p - q\00", align 1
@.str.15 = private unnamed_addr constant [8 x i8] c"-1 < 0u\00", align 1
@.str.16 = private unnamed_addr constant [26 x i8] c"(unsigned short)65535 + 1\00", align 1
@.str.17 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.18 = private unnamed_addr constant [8 x i8] c"1 / 2.0\00", align 1
@.str.19 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.20 = private unnamed_addr constant [8 x i8] c"0u - 1u\00", align 1
@.str.21 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.22 = private unnamed_addr constant [20 x i8] c"1000000LL * 1000000\00", align 1
@.str.23 = private unnamed_addr constant [8 x i8] c"'a' + 1\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [5 x i32], align 16
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.a, i64 20, i1 false)
  %5 = getelementptr inbounds [5 x i32], ptr %2, i64 0, i64 0
  %6 = getelementptr inbounds i32, ptr %5, i64 1
  store ptr %6, ptr %3, align 8
  %7 = getelementptr inbounds [5 x i32], ptr %2, i64 0, i64 4
  store ptr %7, ptr %4, align 8
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 42)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 3)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 2)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef -3)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef -2)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef -3)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 2)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 7)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef -7)
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds i32, ptr %17, i64 2
  %19 = load i32, ptr %18, align 4
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %19)
  %21 = load ptr, ptr %4, align 8
  %22 = getelementptr inbounds i32, ptr %21, i64 -1
  %23 = load i32, ptr %22, align 4
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %23)
  %25 = load ptr, ptr %4, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = ptrtoint ptr %25 to i64
  %28 = ptrtoint ptr %26 to i64
  %29 = sub i64 %27, %28
  %30 = sdiv exact i64 %29, 4
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.12, ptr noundef @.str.13, i64 noundef %30)
  %32 = load ptr, ptr %3, align 8
  %33 = load ptr, ptr %4, align 8
  %34 = ptrtoint ptr %32 to i64
  %35 = ptrtoint ptr %33 to i64
  %36 = sub i64 %34, %35
  %37 = sdiv exact i64 %36, 4
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str.12, ptr noundef @.str.14, i64 noundef %37)
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 0)
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef 65536)
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str.17, ptr noundef @.str.18, double noundef 5.000000e-01)
  %42 = call i32 (ptr, ...) @printf(ptr noundef @.str.19, ptr noundef @.str.20, i32 noundef -1)
  %43 = call i32 (ptr, ...) @printf(ptr noundef @.str.21, ptr noundef @.str.22, i64 noundef 1000000000000)
  %44 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.23, i32 noundef 98)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
