; ModuleID = 'test/c/synth/decl-attributes-standard.c'
source_filename = "test/c/synth/decl-attributes-standard.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"old()\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"older()\00", align 1
@.str.3 = private unnamed_addr constant [8 x i8] c"must2()\00", align 1
@.str.4 = private unnamed_addr constant [11 x i8] c"pure_sq(5)\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"repro(5)\00", align 1
@.str.6 = private unnamed_addr constant [7 x i8] c"both()\00", align 1
@.str.7 = private unnamed_addr constant [12 x i8] c"empty_attrs\00", align 1
@empty_attrs = internal global i32 7, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  %3 = call i32 @must()
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %0
  call void @quit() #4
  unreachable

6:                                                ; preds = %0
  %7 = call i32 @old()
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %7)
  %9 = call i32 @older()
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %9)
  %11 = call i32 @must2()
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %11)
  %13 = call i32 @pure_sq(i32 noundef 5)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %13)
  %15 = call i32 @repro(i32 noundef 5)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %15)
  %17 = call i32 @both()
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %17)
  %19 = load i32, ptr @empty_attrs, align 4
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %19)
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @must() #0 {
  ret i32 3
}

; Function Attrs: noinline noreturn nounwind optnone sspstrong uwtable
define internal void @quit() #1 {
  call void @exit(i32 noundef 0) #4
  unreachable
}

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @old() #0 {
  ret i32 1
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @older() #0 {
  ret i32 2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @must2() #0 {
  ret i32 4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @pure_sq(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr %2, align 4
  %5 = mul nsw i32 %3, %4
  ret i32 %5
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @repro(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 1
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @both() #0 {
  ret i32 6
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noinline noreturn nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
