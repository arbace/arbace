; ModuleID = 'test/c/synth/decl-type-specifiers.c'
source_filename = "test/c/synth/decl-type-specifiers.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"vp == 0\00", align 1
@.str.2 = private unnamed_addr constant [2 x i8] c"c\00", align 1
@.str.3 = private unnamed_addr constant [3 x i8] c"sc\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"uc\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.6 = private unnamed_addr constant [3 x i8] c"si\00", align 1
@.str.7 = private unnamed_addr constant [3 x i8] c"us\00", align 1
@.str.8 = private unnamed_addr constant [2 x i8] c"i\00", align 1
@.str.9 = private unnamed_addr constant [4 x i8] c"si2\00", align 1
@.str.10 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.11 = private unnamed_addr constant [2 x i8] c"u\00", align 1
@.str.12 = private unnamed_addr constant [3 x i8] c"ui\00", align 1
@.str.13 = private unnamed_addr constant [10 x i8] c"%s = %ld\0A\00", align 1
@.str.14 = private unnamed_addr constant [2 x i8] c"l\00", align 1
@.str.15 = private unnamed_addr constant [3 x i8] c"li\00", align 1
@.str.16 = private unnamed_addr constant [10 x i8] c"%s = %lu\0A\00", align 1
@.str.17 = private unnamed_addr constant [3 x i8] c"ul\00", align 1
@.str.18 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.19 = private unnamed_addr constant [3 x i8] c"ll\00", align 1
@.str.20 = private unnamed_addr constant [4 x i8] c"lli\00", align 1
@.str.21 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.22 = private unnamed_addr constant [4 x i8] c"ull\00", align 1
@.str.23 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.24 = private unnamed_addr constant [2 x i8] c"f\00", align 1
@.str.25 = private unnamed_addr constant [2 x i8] c"d\00", align 1
@.str.26 = private unnamed_addr constant [11 x i8] c"(double)ld\00", align 1
@.str.27 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@.str.28 = private unnamed_addr constant [3 x i8] c"b2\00", align 1
@.str.29 = private unnamed_addr constant [5 x i8] c"slli\00", align 1
@.str.30 = private unnamed_addr constant [4 x i8] c"lui\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  %6 = alloca i16, align 2
  %7 = alloca i16, align 2
  %8 = alloca i16, align 2
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i64, align 8
  %14 = alloca i64, align 8
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  %18 = alloca i64, align 8
  %19 = alloca float, align 4
  %20 = alloca double, align 8
  %21 = alloca x86_fp80, align 16
  %22 = alloca i8, align 1
  %23 = alloca i8, align 1
  %24 = alloca i64, align 8
  %25 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store ptr null, ptr %2, align 8
  store i8 99, ptr %3, align 1
  store i8 -1, ptr %4, align 1
  store i8 -1, ptr %5, align 1
  store i16 -2, ptr %6, align 2
  store i16 3, ptr %7, align 2
  store i16 4, ptr %8, align 2
  store i32 -5, ptr %9, align 4
  store i32 -6, ptr %10, align 4
  store i32 7, ptr %11, align 4
  store i32 8, ptr %12, align 4
  store i64 -9, ptr %13, align 8
  store i64 10, ptr %14, align 8
  store i64 11, ptr %15, align 8
  store i64 -12, ptr %16, align 8
  store i64 13, ptr %17, align 8
  store i64 14, ptr %18, align 8
  store float 1.500000e+00, ptr %19, align 4
  store double 2.500000e+00, ptr %20, align 8
  store x86_fp80 3.500000e+00, ptr %21, align 16
  store i8 1, ptr %22, align 1
  store i8 1, ptr %23, align 1
  store i64 -15, ptr %24, align 8
  store i64 16, ptr %25, align 8
  %26 = load ptr, ptr %2, align 8
  %27 = icmp eq ptr %26, null
  %28 = zext i1 %27 to i32
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %28)
  %30 = load i8, ptr %3, align 1
  %31 = sext i8 %30 to i32
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %31)
  %33 = load i8, ptr %4, align 1
  %34 = sext i8 %33 to i32
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %34)
  %36 = load i8, ptr %5, align 1
  %37 = zext i8 %36 to i32
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %37)
  %39 = load i16, ptr %6, align 2
  %40 = sext i16 %39 to i32
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %40)
  %42 = load i16, ptr %7, align 2
  %43 = sext i16 %42 to i32
  %44 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %43)
  %45 = load i16, ptr %8, align 2
  %46 = zext i16 %45 to i32
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %46)
  %48 = load i32, ptr %9, align 4
  %49 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %48)
  %50 = load i32, ptr %10, align 4
  %51 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %50)
  %52 = load i32, ptr %11, align 4
  %53 = call i32 (ptr, ...) @printf(ptr noundef @.str.10, ptr noundef @.str.11, i32 noundef %52)
  %54 = load i32, ptr %12, align 4
  %55 = call i32 (ptr, ...) @printf(ptr noundef @.str.10, ptr noundef @.str.12, i32 noundef %54)
  %56 = load i64, ptr %13, align 8
  %57 = call i32 (ptr, ...) @printf(ptr noundef @.str.13, ptr noundef @.str.14, i64 noundef %56)
  %58 = load i64, ptr %14, align 8
  %59 = call i32 (ptr, ...) @printf(ptr noundef @.str.13, ptr noundef @.str.15, i64 noundef %58)
  %60 = load i64, ptr %15, align 8
  %61 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.17, i64 noundef %60)
  %62 = load i64, ptr %16, align 8
  %63 = call i32 (ptr, ...) @printf(ptr noundef @.str.18, ptr noundef @.str.19, i64 noundef %62)
  %64 = load i64, ptr %17, align 8
  %65 = call i32 (ptr, ...) @printf(ptr noundef @.str.18, ptr noundef @.str.20, i64 noundef %64)
  %66 = load i64, ptr %18, align 8
  %67 = call i32 (ptr, ...) @printf(ptr noundef @.str.21, ptr noundef @.str.22, i64 noundef %66)
  %68 = load float, ptr %19, align 4
  %69 = fpext float %68 to double
  %70 = call i32 (ptr, ...) @printf(ptr noundef @.str.23, ptr noundef @.str.24, double noundef %69)
  %71 = load double, ptr %20, align 8
  %72 = call i32 (ptr, ...) @printf(ptr noundef @.str.23, ptr noundef @.str.25, double noundef %71)
  %73 = load x86_fp80, ptr %21, align 16
  %74 = fptrunc x86_fp80 %73 to double
  %75 = call i32 (ptr, ...) @printf(ptr noundef @.str.23, ptr noundef @.str.26, double noundef %74)
  %76 = load i8, ptr %22, align 1
  %77 = icmp ne i8 %76, 0
  %78 = zext i1 %77 to i32
  %79 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.27, i32 noundef %78)
  %80 = load i8, ptr %23, align 1
  %81 = icmp ne i8 %80, 0
  %82 = zext i1 %81 to i32
  %83 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.28, i32 noundef %82)
  %84 = load i64, ptr %24, align 8
  %85 = call i32 (ptr, ...) @printf(ptr noundef @.str.18, ptr noundef @.str.29, i64 noundef %84)
  %86 = load i64, ptr %25, align 8
  %87 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.30, i64 noundef %86)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
