; ModuleID = 'test/c/synth/lex-string-literals.c'
source_filename = "test/c/synth/lex-string-literals.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"\22ab\22 \22cd\22\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"abcd\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"\22tab\\tend\22\00", align 1
@.str.4 = private unnamed_addr constant [8 x i8] c"tab\09end\00", align 1
@.str.5 = private unnamed_addr constant [12 x i8] c"\22\\x41\\102C\22\00", align 1
@.str.6 = private unnamed_addr constant [4 x i8] c"ABC\00", align 1
@.str.7 = private unnamed_addr constant [12 x i8] c"\22??=??/??(\22\00", align 1
@.str.8 = private unnamed_addr constant [10 x i8] c"??=??/??(\00", align 1
@.str.9 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.10 = private unnamed_addr constant [13 x i8] c"sizeof \22abc\22\00", align 1
@.str.11 = private unnamed_addr constant [18 x i8] c"sizeof u8\22\\u00e9\22\00", align 1
@.str.12 = private unnamed_addr constant [31 x i8] c"sizeof L\22ab\22 / sizeof L\22ab\22[0]\00", align 1
@.str.13 = private unnamed_addr constant [31 x i8] c"sizeof u\22ab\22 / sizeof u\22ab\22[0]\00", align 1
@.str.14 = private unnamed_addr constant [31 x i8] c"sizeof U\22ab\22 / sizeof U\22ab\22[0]\00", align 1
@.str.15 = private unnamed_addr constant [19 x i8] c"sizeof \22a\22 \22b\22 \22c\22\00", align 1
@.str.16 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.17 = private unnamed_addr constant [14 x i8] c"u8\22\\u00e9\22[0]\00", align 1
@.str.19 = private unnamed_addr constant [14 x i8] c"u8\22\\u00e9\22[1]\00", align 1
@.str.20 = private unnamed_addr constant [23 x i8] c"(int)U\22x\\U0001F600\22[1]\00", align 1
@.str.22 = private unnamed_addr constant [49 x i8] c"_Generic(u8\22a\22[0], unsigned char: 1, default: 0)\00", align 1
@.str.23 = private unnamed_addr constant [41 x i8] c"_Generic(&\22a\22[0], char *: 1, default: 0)\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, ptr noundef nonnull @.str.2)
  %2 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.4)
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.5, ptr noundef nonnull @.str.6)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.7, ptr noundef nonnull @.str.8)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.10, i64 noundef 4)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.11, i64 noundef 3)
  %7 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.12, i64 noundef 3)
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.13, i64 noundef 3)
  %9 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.14, i64 noundef 3)
  %10 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.9, ptr noundef nonnull @.str.15, i64 noundef 4)
  %11 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.16, ptr noundef nonnull @.str.17, i32 noundef 195)
  %12 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.16, ptr noundef nonnull @.str.19, i32 noundef 169)
  %13 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.16, ptr noundef nonnull @.str.20, i32 noundef 128512)
  %14 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.16, ptr noundef nonnull @.str.22, i32 noundef 1)
  %15 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.16, ptr noundef nonnull @.str.23, i32 noundef 1)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
