; ModuleID = 'test/c/synth/lib-musl-tables.c'
source_filename = "test/c/synth/lib-musl-tables.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"strerror(ENOENT)\00", align 1
@.str.2 = private unnamed_addr constant [17 x i8] c"strerror(ERANGE)\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"strerror(EDOM)\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [20 x i8] c"iswalpha(L'a') != 0\00", align 1
@.str.6 = private unnamed_addr constant [20 x i8] c"iswalpha(L'7') != 0\00", align 1
@.str.7 = private unnamed_addr constant [20 x i8] c"iswalpha(0xe9) != 0\00", align 1
@.str.8 = private unnamed_addr constant [20 x i8] c"iswpunct(L'!') != 0\00", align 1
@.str.9 = private unnamed_addr constant [20 x i8] c"iswpunct(L'a') != 0\00", align 1
@.str.10 = private unnamed_addr constant [14 x i8] c"wcwidth(L'a')\00", align 1
@.str.11 = private unnamed_addr constant [16 x i8] c"wcwidth(0x4e00)\00", align 1
@.str.12 = private unnamed_addr constant [16 x i8] c"wcwidth(0x0301)\00", align 1
@.str.13 = private unnamed_addr constant [17 x i8] c"latin1_to_utf8()\00", align 1
@.str.14 = private unnamed_addr constant [6 x i8] c"UTF-8\00", align 1
@.str.15 = private unnamed_addr constant [11 x i8] c"ISO-8859-1\00", align 1

; Function Attrs: nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [4 x i8], align 4
  %2 = alloca [16 x i8], align 16
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = tail call ptr @strerror(i32 noundef 2) #5
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, ptr noundef %7)
  %9 = tail call ptr @strerror(i32 noundef 34) #5
  %10 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.2, ptr noundef %9)
  %11 = tail call ptr @strerror(i32 noundef 33) #5
  %12 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.3, ptr noundef %11)
  %13 = tail call i32 @iswalpha(i32 noundef 97) #5
  %14 = icmp ne i32 %13, 0
  %15 = zext i1 %14 to i32
  %16 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.5, i32 noundef %15)
  %17 = tail call i32 @iswalpha(i32 noundef 55) #5
  %18 = icmp ne i32 %17, 0
  %19 = zext i1 %18 to i32
  %20 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.6, i32 noundef %19)
  %21 = tail call i32 @iswalpha(i32 noundef 233) #5
  %22 = icmp ne i32 %21, 0
  %23 = zext i1 %22 to i32
  %24 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.7, i32 noundef %23)
  %25 = tail call i32 @iswpunct(i32 noundef 33) #5
  %26 = icmp ne i32 %25, 0
  %27 = zext i1 %26 to i32
  %28 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.8, i32 noundef %27)
  %29 = tail call i32 @iswpunct(i32 noundef 97) #5
  %30 = icmp ne i32 %29, 0
  %31 = zext i1 %30 to i32
  %32 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.9, i32 noundef %31)
  %33 = tail call i32 @wcwidth(i32 noundef 97) #5
  %34 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.10, i32 noundef %33)
  %35 = tail call i32 @wcwidth(i32 noundef 19968) #5
  %36 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.11, i32 noundef %35)
  %37 = tail call i32 @wcwidth(i32 noundef 769) #5
  %38 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.12, i32 noundef %37)
  %39 = tail call ptr @iconv_open(ptr noundef nonnull @.str.14, ptr noundef nonnull @.str.15) #5
  %40 = icmp eq ptr %39, inttoptr (i64 -1 to ptr)
  br i1 %40, label %51, label %41

41:                                               ; preds = %0
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #5
  store i32 15299817, ptr %1, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #5
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(16) %2, i8 0, i64 16, i1 false)
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #5
  store ptr %1, ptr %3, align 8, !tbaa !10
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #5
  store ptr %2, ptr %4, align 8, !tbaa !10
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #5
  store i64 3, ptr %5, align 8, !tbaa !13
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #5
  store i64 15, ptr %6, align 8, !tbaa !13
  %42 = call i64 @iconv(ptr noundef %39, ptr noundef nonnull %3, ptr noundef nonnull %5, ptr noundef nonnull %4, ptr noundef nonnull %6) #5
  %43 = call i32 @iconv_close(ptr noundef %39) #5
  %44 = icmp eq i64 %42, -1
  %45 = load ptr, ptr %4, align 8
  %46 = ptrtoint ptr %45 to i64
  %47 = ptrtoint ptr %2 to i64
  %48 = sub i64 %46, %47
  %49 = trunc i64 %48 to i32
  %50 = select i1 %44, i32 -2, i32 %49
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #5
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #5
  br label %51

51:                                               ; preds = %0, %41
  %52 = phi i32 [ %50, %41 ], [ -1, %0 ]
  %53 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.13, i32 noundef %52)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

declare ptr @strerror(i32 noundef) local_unnamed_addr #2

declare i32 @iswalpha(i32 noundef) local_unnamed_addr #2

declare i32 @iswpunct(i32 noundef) local_unnamed_addr #2

declare i32 @wcwidth(i32 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #3

declare ptr @iconv_open(ptr noundef, ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

declare i64 @iconv(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #2

declare i32 @iconv_close(ptr noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #3

attributes #0 = { nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!11, !11, i64 0}
!11 = !{!"p1 omnipotent char", !12, i64 0}
!12 = !{!"any pointer", !8, i64 0}
!13 = !{!14, !14, i64 0}
!14 = !{!"long", !8, i64 0}
