; ModuleID = 'test/c/run/vla-types.c'
source_filename = "test/c/run/vla-types.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [17 x i8] c"typedef %ld %ld\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"rows %ld\0A\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"sides %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [12 x i8] c"unnamed %d\0A\00", align 1
@.str.4 = private unnamed_addr constant [16 x i8] c"rowparam %d %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"types %ld\0A\00", align 1
@.str.6 = private unnamed_addr constant [14 x i8] c"zeroed %d %d\0A\00", align 1
@calls = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [10 x i32], align 16
  %3 = alloca [64 x i8], align 16
  %4 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %5 = call i64 @typedef_size(i32 noundef 3)
  %6 = call i64 @typedef_size(i32 noundef 20)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %5, i64 noundef %6)
  %8 = call i64 @rows(i32 noundef 4, i32 noundef 3)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i64 noundef %8)
  %10 = getelementptr inbounds [10 x i32], ptr %2, i64 0, i64 0
  %11 = getelementptr inbounds [10 x i32], ptr %2, i64 0, i64 0
  %12 = call i32 @sides(i32 noundef 1, ptr noundef %10, i32 noundef 4, ptr noundef %11)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %12)
  %14 = getelementptr inbounds [10 x i32], ptr %2, i64 0, i64 0
  %15 = call i32 @unnamed(i32 noundef 1, ptr noundef %14, i32 noundef 3)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i32 noundef %15)
  %17 = getelementptr inbounds [64 x i8], ptr %3, i64 0, i64 0
  %18 = call i32 @rowparam(i32 noundef 5, ptr noundef %17)
  store i32 %18, ptr %4, align 4
  %19 = load i32, ptr %4, align 4
  %20 = getelementptr inbounds [64 x i8], ptr %3, i64 0, i64 5
  %21 = load i8, ptr %20, align 1
  %22 = sext i8 %21 to i32
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, i32 noundef %19, i32 noundef %22)
  %24 = call i64 @types(i32 noundef 2)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, i64 noundef %24)
  %26 = call i32 @zeroed(i32 noundef 50)
  %27 = call i32 @zeroed(i32 noundef 50)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, i32 noundef %26, i32 noundef %27)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @typedef_size(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 2
  %5 = zext i32 %4 to i64
  store i32 100, ptr %2, align 4
  %6 = mul nuw i64 4, %5
  ret i64 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @rows(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i64, align 8
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %12 = load i32, ptr %3, align 4
  %13 = zext i32 %12 to i64
  %14 = load i32, ptr %4, align 4
  %15 = zext i32 %14 to i64
  %16 = call ptr @llvm.stacksave.p0()
  store ptr %16, ptr %5, align 8
  %17 = mul nuw i64 %13, %15
  %18 = alloca i32, i64 %17, align 16
  store i64 %13, ptr %6, align 8
  store i64 %15, ptr %7, align 8
  %19 = load i32, ptr %4, align 4
  %20 = zext i32 %19 to i64
  store ptr %18, ptr %8, align 8
  %21 = mul nuw i64 %13, %15
  %22 = mul nuw i64 4, %21
  %23 = mul nsw i64 1, %15
  %24 = getelementptr inbounds i32, ptr %18, i64 %23
  %25 = mul nuw i64 4, %15
  %26 = add i64 %22, %25
  %27 = load ptr, ptr %8, align 8
  %28 = mul nuw i64 4, %20
  %29 = add i64 %26, %28
  store i64 %29, ptr %9, align 8
  %30 = load ptr, ptr %8, align 8
  %31 = getelementptr inbounds nuw i32, ptr %30, i64 %20
  store ptr %31, ptr %8, align 8
  %32 = load ptr, ptr %8, align 8
  %33 = mul nsw i64 1, %20
  %34 = getelementptr inbounds i32, ptr %32, i64 %33
  store ptr %34, ptr %8, align 8
  %35 = load ptr, ptr %8, align 8
  %36 = ptrtoint ptr %35 to i64
  %37 = ptrtoint ptr %18 to i64
  %38 = sub i64 %36, %37
  %39 = load i64, ptr %9, align 8
  %40 = add nsw i64 %39, %38
  store i64 %40, ptr %9, align 8
  %41 = load ptr, ptr %8, align 8
  %42 = mul nsw i64 0, %15
  %43 = getelementptr inbounds i32, ptr %18, i64 %42
  %44 = ptrtoint ptr %41 to i64
  %45 = ptrtoint ptr %43 to i64
  %46 = sub i64 %44, %45
  %47 = mul nuw i64 4, %20
  %48 = sdiv exact i64 %46, %47
  %49 = load i64, ptr %9, align 8
  %50 = add nsw i64 %49, %48
  store i64 %50, ptr %9, align 8
  store i32 0, ptr %10, align 4
  br label %51

51:                                               ; preds = %76, %2
  %52 = load i32, ptr %10, align 4
  %53 = load i32, ptr %3, align 4
  %54 = icmp slt i32 %52, %53
  br i1 %54, label %55, label %79

55:                                               ; preds = %51
  store i32 0, ptr %11, align 4
  br label %56

56:                                               ; preds = %72, %55
  %57 = load i32, ptr %11, align 4
  %58 = load i32, ptr %4, align 4
  %59 = icmp slt i32 %57, %58
  br i1 %59, label %60, label %75

60:                                               ; preds = %56
  %61 = load i32, ptr %10, align 4
  %62 = mul nsw i32 %61, 10
  %63 = load i32, ptr %11, align 4
  %64 = add nsw i32 %62, %63
  %65 = load i32, ptr %10, align 4
  %66 = sext i32 %65 to i64
  %67 = mul nsw i64 %66, %15
  %68 = getelementptr inbounds i32, ptr %18, i64 %67
  %69 = load i32, ptr %11, align 4
  %70 = sext i32 %69 to i64
  %71 = getelementptr inbounds i32, ptr %68, i64 %70
  store i32 %64, ptr %71, align 4
  br label %72

72:                                               ; preds = %60
  %73 = load i32, ptr %11, align 4
  %74 = add nsw i32 %73, 1
  store i32 %74, ptr %11, align 4
  br label %56, !llvm.loop !6

75:                                               ; preds = %56
  br label %76

76:                                               ; preds = %75
  %77 = load i32, ptr %10, align 4
  %78 = add nsw i32 %77, 1
  store i32 %78, ptr %10, align 4
  br label %51, !llvm.loop !8

79:                                               ; preds = %51
  %80 = mul nsw i64 2, %15
  %81 = getelementptr inbounds i32, ptr %18, i64 %80
  %82 = getelementptr inbounds i32, ptr %81, i64 1
  %83 = load i32, ptr %82, align 4
  %84 = load ptr, ptr %8, align 8
  %85 = mul nsw i64 -1, %20
  %86 = getelementptr inbounds i32, ptr %84, i64 %85
  %87 = getelementptr inbounds i32, ptr %86, i64 2
  %88 = load i32, ptr %87, align 4
  %89 = add nsw i32 %83, %88
  %90 = load ptr, ptr %8, align 8
  %91 = mul nsw i64 -2, %20
  %92 = getelementptr inbounds i32, ptr %90, i64 %91
  %93 = getelementptr inbounds i32, ptr %92, i64 1
  %94 = load i32, ptr %93, align 4
  %95 = add nsw i32 %89, %94
  %96 = sext i32 %95 to i64
  %97 = load i64, ptr %9, align 8
  %98 = add nsw i64 %97, %96
  store i64 %98, ptr %9, align 8
  %99 = load i64, ptr %9, align 8
  %100 = load ptr, ptr %5, align 8
  call void @llvm.stackrestore.p0(ptr %100)
  ret i64 %99
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @sides(i32 noundef %0, ptr noundef %1, i32 noundef %2, ptr noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  store i32 %0, ptr %5, align 4
  store ptr %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  store ptr %3, ptr %8, align 8
  %9 = load i32, ptr %5, align 4
  %10 = add nsw i32 %9, 1
  store i32 %10, ptr %5, align 4
  %11 = zext i32 %9 to i64
  %12 = load i32, ptr %7, align 4
  %13 = add nsw i32 %12, 1
  store i32 %13, ptr %7, align 4
  %14 = zext i32 %12 to i64
  %15 = load i32, ptr %5, align 4
  %16 = mul nsw i32 %15, 10
  %17 = load i32, ptr %7, align 4
  %18 = add nsw i32 %16, %17
  ret i32 %18
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @unnamed(i32 noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  %7 = load i32, ptr %4, align 4
  %8 = add nsw i32 %7, 1
  store i32 %8, ptr %4, align 4
  %9 = zext i32 %8 to i64
  %10 = load i32, ptr %4, align 4
  %11 = mul nsw i32 %10, 10
  %12 = load i32, ptr %6, align 4
  %13 = add nsw i32 %11, %12
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @rowparam(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  store i32 %0, ptr %3, align 4
  store ptr %1, ptr %4, align 8
  %5 = load i32, ptr %3, align 4
  %6 = zext i32 %5 to i64
  %7 = load ptr, ptr %4, align 8
  %8 = mul nsw i64 1, %6
  %9 = getelementptr inbounds i8, ptr %7, i64 %8
  %10 = getelementptr inbounds i8, ptr %9, i64 0
  store i8 7, ptr %10, align 1
  %11 = load ptr, ptr %4, align 8
  %12 = mul nsw i64 1, %6
  %13 = getelementptr inbounds i8, ptr %11, i64 %12
  %14 = load ptr, ptr %4, align 8
  %15 = mul nsw i64 0, %6
  %16 = getelementptr inbounds i8, ptr %14, i64 %15
  %17 = ptrtoint ptr %13 to i64
  %18 = ptrtoint ptr %16 to i64
  %19 = sub i64 %17, %18
  %20 = trunc i64 %19 to i32
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @types(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store i32 %0, ptr %2, align 4
  %6 = load i32, ptr %2, align 4
  %7 = add nsw i32 %6, 1
  store i32 %7, ptr %2, align 4
  %8 = zext i32 %7 to i64
  store ptr null, ptr %3, align 8
  %9 = load i32, ptr %2, align 4
  %10 = sext i32 %9 to i64
  %11 = load ptr, ptr %3, align 8
  %12 = mul nuw i64 4, %8
  %13 = add i64 %10, %12
  store i64 %13, ptr %4, align 8
  %14 = load i32, ptr %2, align 4
  %15 = call i32 @count(i32 noundef %14)
  %16 = zext i32 %15 to i64
  store ptr null, ptr %5, align 8
  %17 = load ptr, ptr %5, align 8
  %18 = mul nuw i64 4, %16
  %19 = load i32, ptr @calls, align 4
  %20 = sext i32 %19 to i64
  %21 = add i64 %18, %20
  %22 = load i64, ptr %4, align 8
  %23 = add i64 %22, %21
  store i64 %23, ptr %4, align 8
  %24 = load i32, ptr %2, align 4
  %25 = add nsw i32 %24, 1
  %26 = call i32 @count(i32 noundef %25)
  %27 = zext i32 %26 to i64
  %28 = mul nuw i64 4, %27
  %29 = load i32, ptr @calls, align 4
  %30 = sext i32 %29 to i64
  %31 = add i64 %28, %30
  %32 = load i64, ptr %4, align 8
  %33 = add i64 %32, %31
  store i64 %33, ptr %4, align 8
  %34 = load i32, ptr %2, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 8, %35
  %37 = load i64, ptr %4, align 8
  %38 = add i64 %37, %36
  store i64 %38, ptr %4, align 8
  %39 = load i64, ptr %4, align 8
  ret i64 %39
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @zeroed(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %8 = load i32, ptr %2, align 4
  %9 = zext i32 %8 to i64
  %10 = call ptr @llvm.stacksave.p0()
  store ptr %10, ptr %3, align 8
  %11 = alloca i32, i64 %9, align 16
  store i64 %9, ptr %4, align 8
  %12 = mul nuw i64 %9, 4
  call void @llvm.memset.p0.i64(ptr align 16 %11, i8 0, i64 %12, i1 false)
  store i32 0, ptr %5, align 4
  store i32 0, ptr %6, align 4
  br label %13

13:                                               ; preds = %26, %1
  %14 = load i32, ptr %6, align 4
  %15 = load i32, ptr %2, align 4
  %16 = icmp slt i32 %14, %15
  br i1 %16, label %17, label %29

17:                                               ; preds = %13
  %18 = load i32, ptr %6, align 4
  %19 = sext i32 %18 to i64
  %20 = getelementptr inbounds i32, ptr %11, i64 %19
  %21 = load volatile i32, ptr %20, align 4
  %22 = icmp ne i32 %21, 0
  %23 = zext i1 %22 to i32
  %24 = load i32, ptr %5, align 4
  %25 = add nsw i32 %24, %23
  store i32 %25, ptr %5, align 4
  br label %26

26:                                               ; preds = %17
  %27 = load i32, ptr %6, align 4
  %28 = add nsw i32 %27, 1
  store i32 %28, ptr %6, align 4
  br label %13, !llvm.loop !9

29:                                               ; preds = %13
  store i32 0, ptr %7, align 4
  br label %30

30:                                               ; preds = %38, %29
  %31 = load i32, ptr %7, align 4
  %32 = load i32, ptr %2, align 4
  %33 = icmp slt i32 %31, %32
  br i1 %33, label %34, label %41

34:                                               ; preds = %30
  %35 = load i32, ptr %7, align 4
  %36 = sext i32 %35 to i64
  %37 = getelementptr inbounds i32, ptr %11, i64 %36
  store volatile i32 -1, ptr %37, align 4
  br label %38

38:                                               ; preds = %34
  %39 = load i32, ptr %7, align 4
  %40 = add nsw i32 %39, 1
  store i32 %40, ptr %7, align 4
  br label %30, !llvm.loop !10

41:                                               ; preds = %30
  %42 = load i32, ptr %5, align 4
  %43 = load ptr, ptr %3, align 8
  call void @llvm.stackrestore.p0(ptr %43)
  ret i32 %42
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @count(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr @calls, align 4
  %4 = add nsw i32 %3, 1
  store i32 %4, ptr @calls, align 4
  %5 = load i32, ptr %2, align 4
  ret i32 %5
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
