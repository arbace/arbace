; ModuleID = 'test/c/synth/lib-math-builtins.c'
source_filename = "test/c/synth/lib-math-builtins.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"log2(2.75)\00", align 1
@.str.2 = private unnamed_addr constant [21 x i8] c"__builtin_log2(2.75)\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"exp2(3.5)\00", align 1
@.str.4 = private unnamed_addr constant [20 x i8] c"__builtin_exp2(3.5)\00", align 1
@.str.5 = private unnamed_addr constant [30 x i8] c"(double)__builtin_log2f(8.0f)\00", align 1
@.str.6 = private unnamed_addr constant [30 x i8] c"(double)__builtin_exp2f(3.5f)\00", align 1
@.str.7 = private unnamed_addr constant [31 x i8] c"(double)__builtin_log2l(16.0L)\00", align 1
@.str.8 = private unnamed_addr constant [22 x i8] c"__builtin_trunc(-2.5)\00", align 1
@.str.9 = private unnamed_addr constant [21 x i8] c"__builtin_round(2.5)\00", align 1
@.str.10 = private unnamed_addr constant [20 x i8] c"__builtin_rint(2.5)\00", align 1
@.str.11 = private unnamed_addr constant [25 x i8] c"__builtin_nearbyint(3.5)\00", align 1
@.str.12 = private unnamed_addr constant [21 x i8] c"__builtin_cbrt(27.0)\00", align 1
@.str.13 = private unnamed_addr constant [26 x i8] c"__builtin_fmin(1.5, -2.0)\00", align 1
@.str.14 = private unnamed_addr constant [26 x i8] c"__builtin_fmax(1.5, -2.0)\00", align 1
@.str.15 = private unnamed_addr constant [26 x i8] c"__builtin_hypot(3.0, 4.0)\00", align 1
@.str.16 = private unnamed_addr constant [25 x i8] c"__builtin_fdim(5.0, 2.0)\00", align 1
@.str.17 = private unnamed_addr constant [29 x i8] c"__builtin_fma(2.0, 3.0, 1.0)\00", align 1
@.str.18 = private unnamed_addr constant [41 x i8] c"(double)__builtin_fmaf(2.0f, 3.0f, 0.5f)\00", align 1
@.str.19 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.20 = private unnamed_addr constant [22 x i8] c"__builtin_ilogb(40.0)\00", align 1
@.str.21 = private unnamed_addr constant [10 x i8] c"%s = %ld\0A\00", align 1
@.str.22 = private unnamed_addr constant [22 x i8] c"__builtin_lround(2.5)\00", align 1
@.str.23 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.24 = private unnamed_addr constant [23 x i8] c"__builtin_llrint(-3.5)\00", align 1
@.str.25 = private unnamed_addr constant [25 x i8] c"__builtin_scalbn(1.5, 3)\00", align 1
@.str.26 = private unnamed_addr constant [30 x i8] c"__builtin_remainder(7.0, 2.0)\00", align 1
@.str.27 = private unnamed_addr constant [21 x i8] c"__builtin_logb(40.0)\00", align 1
@.str.28 = private unnamed_addr constant [32 x i8] c"fmin(2.0, 3.0) + fmax(2.0, 3.0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call double @llvm.log2.f64(double 2.750000e+00)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, double noundef %2)
  %4 = call double @llvm.log2.f64(double 2.750000e+00)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, double noundef %4)
  %6 = call double @llvm.exp2.f64(double 3.500000e+00)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, double noundef %6)
  %8 = call double @llvm.exp2.f64(double 3.500000e+00)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, double noundef %8)
  %10 = call float @llvm.log2.f32(float 8.000000e+00)
  %11 = fpext float %10 to double
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, double noundef %11)
  %13 = call float @llvm.exp2.f32(float 3.500000e+00)
  %14 = fpext float %13 to double
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, double noundef %14)
  %16 = call x86_fp80 @llvm.log2.f80(x86_fp80 1.600000e+01)
  %17 = fptrunc x86_fp80 %16 to double
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, double noundef %17)
  %19 = call double @llvm.trunc.f64(double -2.500000e+00)
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, double noundef %19)
  %21 = call double @llvm.round.f64(double 2.500000e+00)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, double noundef %21)
  %23 = call double @llvm.rint.f64(double 2.500000e+00)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, double noundef %23)
  %25 = call double @llvm.nearbyint.f64(double 3.500000e+00)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, double noundef %25)
  %27 = call double @cbrt(double noundef 2.700000e+01) #4
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, double noundef %27)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, double noundef -2.000000e+00)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, double noundef 1.500000e+00)
  %31 = call double @hypot(double noundef 3.000000e+00, double noundef 4.000000e+00) #4
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, double noundef %31)
  %33 = call double @fdim(double noundef 5.000000e+00, double noundef 2.000000e+00) #4
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, double noundef %33)
  %35 = call double @llvm.fma.f64(double 2.000000e+00, double 3.000000e+00, double 1.000000e+00)
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17, double noundef %35)
  %37 = call float @llvm.fma.f32(float 2.000000e+00, float 3.000000e+00, float 5.000000e-01)
  %38 = fpext float %37 to double
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.18, double noundef %38)
  %40 = call i32 @ilogb(double noundef 4.000000e+01) #4
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str.19, ptr noundef @.str.20, i32 noundef %40)
  %42 = call i64 @llvm.lround.i64.f64(double 2.500000e+00)
  %43 = call i32 (ptr, ...) @printf(ptr noundef @.str.21, ptr noundef @.str.22, i64 noundef %42)
  %44 = call i64 @llvm.llrint.i64.f64(double -3.500000e+00)
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str.23, ptr noundef @.str.24, i64 noundef %44)
  %46 = call double @scalbn(double noundef 1.500000e+00, i32 noundef 3) #4
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.25, double noundef %46)
  %48 = call double @remainder(double noundef 7.000000e+00, double noundef 2.000000e+00) #4
  %49 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.26, double noundef %48)
  %50 = call double @logb(double noundef 4.000000e+01) #4
  %51 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.27, double noundef %50)
  %52 = call nsz double @llvm.minnum.f64(double 2.000000e+00, double 3.000000e+00)
  %53 = call nsz double @llvm.maxnum.f64(double 2.000000e+00, double 3.000000e+00)
  %54 = fadd double %52, %53
  %55 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.28, double noundef %54)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp2.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.log2.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.exp2.f32(float) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare x86_fp80 @llvm.log2.f80(x86_fp80) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.trunc.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.round.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.rint.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.nearbyint.f64(double) #2

; Function Attrs: nounwind willreturn memory(none)
declare double @cbrt(double noundef) #3

; Function Attrs: nounwind willreturn memory(none)
declare double @hypot(double noundef, double noundef) #3

; Function Attrs: nounwind willreturn memory(none)
declare double @fdim(double noundef, double noundef) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fma.f64(double, double, double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #2

; Function Attrs: nounwind willreturn memory(none)
declare i32 @ilogb(double noundef) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.lround.i64.f64(double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.llrint.i64.f64(double) #2

; Function Attrs: nounwind willreturn memory(none)
declare double @scalbn(double noundef, i32 noundef) #3

; Function Attrs: nounwind willreturn memory(none)
declare double @remainder(double noundef, double noundef) #3

; Function Attrs: nounwind willreturn memory(none)
declare double @logb(double noundef) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.minnum.f64(double, double) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.maxnum.f64(double, double) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
