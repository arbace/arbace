; ModuleID = 'test/c/synth/expr-primary.c'
source_filename = "test/c/synth/expr-primary.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"v\00", align 1
@v = internal global i32 9, align 4
@.str.2 = private unnamed_addr constant [4 x i8] c"(v)\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"((v + 1))\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"\22xyz\22[1]\00", align 1
@.str.5 = private unnamed_addr constant [4 x i8] c"xyz\00", align 1
@.str.6 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.7 = private unnamed_addr constant [7 x i8] c"name()\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"__func__\00", align 1
@__func__.main = private unnamed_addr constant [5 x i8] c"main\00", align 1
@__func__.name = private unnamed_addr constant [5 x i8] c"name\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i32, ptr @v, align 4
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %2)
  %4 = load i32, ptr @v, align 4
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %4)
  %6 = load i32, ptr @v, align 4
  %7 = add nsw i32 %6, 1
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %7)
  %9 = load i8, ptr getelementptr inbounds nuw (i8, ptr @.str.5, i64 1), align 1
  %10 = sext i8 %9 to i32
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %10)
  %12 = call ptr @name()
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.7, ptr noundef %12)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.8, ptr noundef @__func__.main)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @name() #0 {
  ret ptr @__func__.name
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
