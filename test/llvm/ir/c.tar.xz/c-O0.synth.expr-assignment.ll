; ModuleID = 'test/c/synth/expr-assignment.c'
source_filename = "test/c/synth/expr-assignment.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"r[0]\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"r[1]\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"r[2]\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"r[3]\00", align 1
@.str.5 = private unnamed_addr constant [5 x i8] c"r[4]\00", align 1
@.str.6 = private unnamed_addr constant [5 x i8] c"r[5]\00", align 1
@.str.7 = private unnamed_addr constant [5 x i8] c"r[6]\00", align 1
@.str.8 = private unnamed_addr constant [5 x i8] c"r[7]\00", align 1
@.str.9 = private unnamed_addr constant [5 x i8] c"r[8]\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"r[9]\00", align 1
@.str.11 = private unnamed_addr constant [6 x i8] c"r[10]\00", align 1
@.str.12 = private unnamed_addr constant [2 x i8] c"y\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca [11 x i32], align 16
  store i32 0, ptr %1, align 4
  store i32 100, ptr %2, align 4
  %5 = load i32, ptr %2, align 4
  %6 = mul nsw i32 %5, 3
  store i32 %6, ptr %2, align 4
  %7 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 0
  store i32 %6, ptr %7, align 16
  %8 = load i32, ptr %2, align 4
  %9 = sdiv i32 %8, 7
  store i32 %9, ptr %2, align 4
  %10 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 1
  store i32 %9, ptr %10, align 4
  %11 = load i32, ptr %2, align 4
  %12 = srem i32 %11, 11
  store i32 %12, ptr %2, align 4
  %13 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 2
  store i32 %12, ptr %13, align 8
  %14 = load i32, ptr %2, align 4
  %15 = add nsw i32 %14, 40
  store i32 %15, ptr %2, align 4
  %16 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 3
  store i32 %15, ptr %16, align 4
  %17 = load i32, ptr %2, align 4
  %18 = sub nsw i32 %17, 2
  store i32 %18, ptr %2, align 4
  %19 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 4
  store i32 %18, ptr %19, align 16
  %20 = load i32, ptr %2, align 4
  %21 = shl i32 %20, 3
  store i32 %21, ptr %2, align 4
  %22 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 5
  store i32 %21, ptr %22, align 4
  %23 = load i32, ptr %2, align 4
  %24 = ashr i32 %23, 1
  store i32 %24, ptr %2, align 4
  %25 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 6
  store i32 %24, ptr %25, align 8
  %26 = load i32, ptr %2, align 4
  %27 = and i32 %26, 124
  store i32 %27, ptr %2, align 4
  %28 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 7
  store i32 %27, ptr %28, align 4
  %29 = load i32, ptr %2, align 4
  %30 = xor i32 %29, 85
  store i32 %30, ptr %2, align 4
  %31 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 8
  store i32 %30, ptr %31, align 16
  %32 = load i32, ptr %2, align 4
  %33 = or i32 %32, 256
  store i32 %33, ptr %2, align 4
  %34 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 9
  store i32 %33, ptr %34, align 4
  store i32 5, ptr %2, align 4
  store i32 5, ptr %3, align 4
  %35 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 10
  store i32 5, ptr %35, align 8
  %36 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 0
  %37 = load i32, ptr %36, align 16
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %37)
  %39 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 1
  %40 = load i32, ptr %39, align 4
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %40)
  %42 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 2
  %43 = load i32, ptr %42, align 8
  %44 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %43)
  %45 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 3
  %46 = load i32, ptr %45, align 4
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %46)
  %48 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 4
  %49 = load i32, ptr %48, align 16
  %50 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %49)
  %51 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 5
  %52 = load i32, ptr %51, align 4
  %53 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %52)
  %54 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 6
  %55 = load i32, ptr %54, align 8
  %56 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %55)
  %57 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 7
  %58 = load i32, ptr %57, align 4
  %59 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %58)
  %60 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 8
  %61 = load i32, ptr %60, align 16
  %62 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %61)
  %63 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 9
  %64 = load i32, ptr %63, align 4
  %65 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %64)
  %66 = getelementptr inbounds [11 x i32], ptr %4, i64 0, i64 10
  %67 = load i32, ptr %66, align 8
  %68 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %67)
  %69 = load i32, ptr %3, align 4
  %70 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef %69)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
