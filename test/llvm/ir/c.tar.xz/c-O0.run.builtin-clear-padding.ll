; ModuleID = 'test/c/run/builtin-clear-padding.c'
source_filename = "test/c/run/builtin-clear-padding.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i8, i32, i16 }
%struct.B = type { i8, [3 x i8] }
%struct.C = type { i16, i8 }
%union.U = type { %struct.anon }
%struct.anon = type { i8, i32 }
%struct.D = type { [2 x %struct.A], %union.U, i8 }
%struct.E = type { i8, %struct.anon.0, double }
%struct.anon.0 = type { i32, i8 }
%struct.F = type { i8, i8 }

@.str = private unnamed_addr constant [5 x i8] c"%-8s\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"struct A\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c" %02x\00", align 1
@.str.3 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"struct B\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"struct C\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"union U\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"struct D\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"struct E\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"struct F\00", align 1
@.str.10 = private unnamed_addr constant [4 x i8] c"int\00", align 1
@.str.11 = private unnamed_addr constant [6 x i8] c"_Bool\00", align 1
@.str.12 = private unnamed_addr constant [7 x i8] c"char *\00", align 1
@.str.13 = private unnamed_addr constant [5 x i8] c"%02x\00", align 1
@.str.14 = private unnamed_addr constant [9 x i8] c"%d %02x\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.A, align 4
  %3 = alloca [12 x i8], align 1
  %4 = alloca i32, align 4
  %5 = alloca %struct.B, align 4
  %6 = alloca [4 x i8], align 1
  %7 = alloca i32, align 4
  %8 = alloca %struct.C, align 4
  %9 = alloca [4 x i8], align 1
  %10 = alloca i32, align 4
  %11 = alloca %union.U, align 4
  %12 = alloca [8 x i8], align 1
  %13 = alloca i32, align 4
  %14 = alloca %struct.D, align 4
  %15 = alloca [36 x i8], align 16
  %16 = alloca i32, align 4
  %17 = alloca %struct.E, align 8
  %18 = alloca [24 x i8], align 16
  %19 = alloca i32, align 4
  %20 = alloca %struct.F, align 1
  %21 = alloca [2 x i8], align 1
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca [4 x i8], align 1
  %25 = alloca i32, align 4
  %26 = alloca i8, align 1
  %27 = alloca [1 x i8], align 1
  %28 = alloca i32, align 4
  %29 = alloca ptr, align 8
  %30 = alloca [8 x i8], align 1
  %31 = alloca i32, align 4
  %32 = alloca [3 x %struct.A], align 16
  %33 = alloca i32, align 4
  %34 = alloca %struct.A, align 4
  %35 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  br label %36

36:                                               ; preds = %0
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 0, i64 12, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 -1, i64 12, i1 false)
  %37 = getelementptr i8, ptr %2, i32 1
  store i8 0, ptr %37, align 1
  %38 = getelementptr i8, ptr %2, i32 2
  store i8 0, ptr %38, align 2
  %39 = getelementptr i8, ptr %2, i32 3
  store i8 0, ptr %39, align 1
  %40 = getelementptr i8, ptr %2, i32 10
  store i8 0, ptr %40, align 2
  %41 = getelementptr i8, ptr %2, i32 11
  store i8 0, ptr %41, align 1
  %42 = getelementptr inbounds [12 x i8], ptr %3, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %42, ptr align 4 %2, i64 12, i1 false)
  %43 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1)
  store i32 0, ptr %4, align 4
  br label %44

44:                                               ; preds = %55, %36
  %45 = load i32, ptr %4, align 4
  %46 = zext i32 %45 to i64
  %47 = icmp ult i64 %46, 12
  br i1 %47, label %48, label %58

48:                                               ; preds = %44
  %49 = load i32, ptr %4, align 4
  %50 = zext i32 %49 to i64
  %51 = getelementptr inbounds nuw [12 x i8], ptr %3, i64 0, i64 %50
  %52 = load i8, ptr %51, align 1
  %53 = zext i8 %52 to i32
  %54 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %53)
  br label %55

55:                                               ; preds = %48
  %56 = load i32, ptr %4, align 4
  %57 = add i32 %56, 1
  store i32 %57, ptr %4, align 4
  br label %44, !llvm.loop !6

58:                                               ; preds = %44
  %59 = call i32 @puts(ptr noundef @.str.3)
  br label %60

60:                                               ; preds = %58
  br label %61

61:                                               ; preds = %60
  call void @llvm.memset.p0.i64(ptr align 4 %5, i8 0, i64 4, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %5, i8 -1, i64 4, i1 false)
  %62 = getelementptr i8, ptr %5, i32 0
  %63 = load i8, ptr %62, align 4
  %64 = and i8 %63, -15
  store i8 %64, ptr %62, align 4
  %65 = getelementptr i8, ptr %5, i32 0
  %66 = load i8, ptr %65, align 4
  %67 = and i8 %66, 31
  store i8 %67, ptr %65, align 4
  %68 = getelementptr i8, ptr %5, i32 1
  store i8 0, ptr %68, align 1
  %69 = getelementptr i8, ptr %5, i32 2
  store i8 0, ptr %69, align 2
  %70 = getelementptr i8, ptr %5, i32 3
  store i8 0, ptr %70, align 1
  %71 = getelementptr inbounds [4 x i8], ptr %6, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %71, ptr align 4 %5, i64 4, i1 false)
  %72 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4)
  store i32 0, ptr %7, align 4
  br label %73

73:                                               ; preds = %84, %61
  %74 = load i32, ptr %7, align 4
  %75 = zext i32 %74 to i64
  %76 = icmp ult i64 %75, 4
  br i1 %76, label %77, label %87

77:                                               ; preds = %73
  %78 = load i32, ptr %7, align 4
  %79 = zext i32 %78 to i64
  %80 = getelementptr inbounds nuw [4 x i8], ptr %6, i64 0, i64 %79
  %81 = load i8, ptr %80, align 1
  %82 = zext i8 %81 to i32
  %83 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %82)
  br label %84

84:                                               ; preds = %77
  %85 = load i32, ptr %7, align 4
  %86 = add i32 %85, 1
  store i32 %86, ptr %7, align 4
  br label %73, !llvm.loop !8

87:                                               ; preds = %73
  %88 = call i32 @puts(ptr noundef @.str.3)
  br label %89

89:                                               ; preds = %87
  br label %90

90:                                               ; preds = %89
  call void @llvm.memset.p0.i64(ptr align 4 %8, i8 0, i64 4, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %8, i8 -1, i64 4, i1 false)
  %91 = getelementptr i8, ptr %8, i32 0
  %92 = load i8, ptr %91, align 4
  %93 = and i8 %92, -25
  store i8 %93, ptr %91, align 4
  %94 = getelementptr i8, ptr %8, i32 1
  %95 = load i8, ptr %94, align 1
  %96 = and i8 %95, 1
  store i8 %96, ptr %94, align 1
  %97 = getelementptr i8, ptr %8, i32 3
  store i8 0, ptr %97, align 1
  %98 = getelementptr inbounds [4 x i8], ptr %9, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %98, ptr align 4 %8, i64 4, i1 false)
  %99 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5)
  store i32 0, ptr %10, align 4
  br label %100

100:                                              ; preds = %111, %90
  %101 = load i32, ptr %10, align 4
  %102 = zext i32 %101 to i64
  %103 = icmp ult i64 %102, 4
  br i1 %103, label %104, label %114

104:                                              ; preds = %100
  %105 = load i32, ptr %10, align 4
  %106 = zext i32 %105 to i64
  %107 = getelementptr inbounds nuw [4 x i8], ptr %9, i64 0, i64 %106
  %108 = load i8, ptr %107, align 1
  %109 = zext i8 %108 to i32
  %110 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %109)
  br label %111

111:                                              ; preds = %104
  %112 = load i32, ptr %10, align 4
  %113 = add i32 %112, 1
  store i32 %113, ptr %10, align 4
  br label %100, !llvm.loop !9

114:                                              ; preds = %100
  %115 = call i32 @puts(ptr noundef @.str.3)
  br label %116

116:                                              ; preds = %114
  br label %117

117:                                              ; preds = %116
  call void @llvm.memset.p0.i64(ptr align 4 %11, i8 0, i64 8, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %11, i8 -1, i64 8, i1 false)
  %118 = getelementptr i8, ptr %11, i32 2
  store i8 0, ptr %118, align 2
  %119 = getelementptr i8, ptr %11, i32 3
  store i8 0, ptr %119, align 1
  %120 = getelementptr inbounds [8 x i8], ptr %12, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %120, ptr align 4 %11, i64 8, i1 false)
  %121 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6)
  store i32 0, ptr %13, align 4
  br label %122

122:                                              ; preds = %133, %117
  %123 = load i32, ptr %13, align 4
  %124 = zext i32 %123 to i64
  %125 = icmp ult i64 %124, 8
  br i1 %125, label %126, label %136

126:                                              ; preds = %122
  %127 = load i32, ptr %13, align 4
  %128 = zext i32 %127 to i64
  %129 = getelementptr inbounds nuw [8 x i8], ptr %12, i64 0, i64 %128
  %130 = load i8, ptr %129, align 1
  %131 = zext i8 %130 to i32
  %132 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %131)
  br label %133

133:                                              ; preds = %126
  %134 = load i32, ptr %13, align 4
  %135 = add i32 %134, 1
  store i32 %135, ptr %13, align 4
  br label %122, !llvm.loop !10

136:                                              ; preds = %122
  %137 = call i32 @puts(ptr noundef @.str.3)
  br label %138

138:                                              ; preds = %136
  br label %139

139:                                              ; preds = %138
  call void @llvm.memset.p0.i64(ptr align 4 %14, i8 0, i64 36, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %14, i8 -1, i64 36, i1 false)
  %140 = getelementptr i8, ptr %14, i32 1
  store i8 0, ptr %140, align 1
  %141 = getelementptr i8, ptr %14, i32 2
  store i8 0, ptr %141, align 2
  %142 = getelementptr i8, ptr %14, i32 3
  store i8 0, ptr %142, align 1
  %143 = getelementptr i8, ptr %14, i32 10
  store i8 0, ptr %143, align 2
  %144 = getelementptr i8, ptr %14, i32 11
  store i8 0, ptr %144, align 1
  %145 = getelementptr i8, ptr %14, i32 13
  store i8 0, ptr %145, align 1
  %146 = getelementptr i8, ptr %14, i32 14
  store i8 0, ptr %146, align 2
  %147 = getelementptr i8, ptr %14, i32 15
  store i8 0, ptr %147, align 1
  %148 = getelementptr i8, ptr %14, i32 22
  store i8 0, ptr %148, align 2
  %149 = getelementptr i8, ptr %14, i32 23
  store i8 0, ptr %149, align 1
  %150 = getelementptr i8, ptr %14, i32 26
  store i8 0, ptr %150, align 2
  %151 = getelementptr i8, ptr %14, i32 27
  store i8 0, ptr %151, align 1
  %152 = getelementptr i8, ptr %14, i32 33
  store i8 0, ptr %152, align 1
  %153 = getelementptr i8, ptr %14, i32 34
  store i8 0, ptr %153, align 2
  %154 = getelementptr i8, ptr %14, i32 35
  store i8 0, ptr %154, align 1
  %155 = getelementptr inbounds [36 x i8], ptr %15, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %155, ptr align 4 %14, i64 36, i1 false)
  %156 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7)
  store i32 0, ptr %16, align 4
  br label %157

157:                                              ; preds = %168, %139
  %158 = load i32, ptr %16, align 4
  %159 = zext i32 %158 to i64
  %160 = icmp ult i64 %159, 36
  br i1 %160, label %161, label %171

161:                                              ; preds = %157
  %162 = load i32, ptr %16, align 4
  %163 = zext i32 %162 to i64
  %164 = getelementptr inbounds nuw [36 x i8], ptr %15, i64 0, i64 %163
  %165 = load i8, ptr %164, align 1
  %166 = zext i8 %165 to i32
  %167 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %166)
  br label %168

168:                                              ; preds = %161
  %169 = load i32, ptr %16, align 4
  %170 = add i32 %169, 1
  store i32 %170, ptr %16, align 4
  br label %157, !llvm.loop !11

171:                                              ; preds = %157
  %172 = call i32 @puts(ptr noundef @.str.3)
  br label %173

173:                                              ; preds = %171
  br label %174

174:                                              ; preds = %173
  call void @llvm.memset.p0.i64(ptr align 8 %17, i8 0, i64 24, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %17, i8 -1, i64 24, i1 false)
  %175 = getelementptr i8, ptr %17, i32 1
  store i8 0, ptr %175, align 1
  %176 = getelementptr i8, ptr %17, i32 2
  store i8 0, ptr %176, align 2
  %177 = getelementptr i8, ptr %17, i32 3
  store i8 0, ptr %177, align 1
  %178 = getelementptr i8, ptr %17, i32 9
  store i8 0, ptr %178, align 1
  %179 = getelementptr i8, ptr %17, i32 10
  store i8 0, ptr %179, align 2
  %180 = getelementptr i8, ptr %17, i32 11
  store i8 0, ptr %180, align 1
  %181 = getelementptr i8, ptr %17, i32 12
  store i8 0, ptr %181, align 4
  %182 = getelementptr i8, ptr %17, i32 13
  store i8 0, ptr %182, align 1
  %183 = getelementptr i8, ptr %17, i32 14
  store i8 0, ptr %183, align 2
  %184 = getelementptr i8, ptr %17, i32 15
  store i8 0, ptr %184, align 1
  %185 = getelementptr inbounds [24 x i8], ptr %18, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %185, ptr align 8 %17, i64 24, i1 false)
  %186 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8)
  store i32 0, ptr %19, align 4
  br label %187

187:                                              ; preds = %198, %174
  %188 = load i32, ptr %19, align 4
  %189 = zext i32 %188 to i64
  %190 = icmp ult i64 %189, 24
  br i1 %190, label %191, label %201

191:                                              ; preds = %187
  %192 = load i32, ptr %19, align 4
  %193 = zext i32 %192 to i64
  %194 = getelementptr inbounds nuw [24 x i8], ptr %18, i64 0, i64 %193
  %195 = load i8, ptr %194, align 1
  %196 = zext i8 %195 to i32
  %197 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %196)
  br label %198

198:                                              ; preds = %191
  %199 = load i32, ptr %19, align 4
  %200 = add i32 %199, 1
  store i32 %200, ptr %19, align 4
  br label %187, !llvm.loop !12

201:                                              ; preds = %187
  %202 = call i32 @puts(ptr noundef @.str.3)
  br label %203

203:                                              ; preds = %201
  br label %204

204:                                              ; preds = %203
  call void @llvm.memset.p0.i64(ptr align 1 %20, i8 0, i64 2, i1 false)
  call void @llvm.memset.p0.i64(ptr align 1 %20, i8 -1, i64 2, i1 false)
  %205 = getelementptr i8, ptr %20, i32 0
  %206 = load i8, ptr %205, align 1
  %207 = and i8 %206, 15
  store i8 %207, ptr %205, align 1
  %208 = getelementptr i8, ptr %20, i32 1
  %209 = load i8, ptr %208, align 1
  %210 = and i8 %209, 3
  store i8 %210, ptr %208, align 1
  %211 = getelementptr inbounds [2 x i8], ptr %21, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %211, ptr align 1 %20, i64 2, i1 false)
  %212 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9)
  store i32 0, ptr %22, align 4
  br label %213

213:                                              ; preds = %224, %204
  %214 = load i32, ptr %22, align 4
  %215 = zext i32 %214 to i64
  %216 = icmp ult i64 %215, 2
  br i1 %216, label %217, label %227

217:                                              ; preds = %213
  %218 = load i32, ptr %22, align 4
  %219 = zext i32 %218 to i64
  %220 = getelementptr inbounds nuw [2 x i8], ptr %21, i64 0, i64 %219
  %221 = load i8, ptr %220, align 1
  %222 = zext i8 %221 to i32
  %223 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %222)
  br label %224

224:                                              ; preds = %217
  %225 = load i32, ptr %22, align 4
  %226 = add i32 %225, 1
  store i32 %226, ptr %22, align 4
  br label %213, !llvm.loop !13

227:                                              ; preds = %213
  %228 = call i32 @puts(ptr noundef @.str.3)
  br label %229

229:                                              ; preds = %227
  br label %230

230:                                              ; preds = %229
  store i32 0, ptr %23, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %23, i8 -1, i64 4, i1 false)
  %231 = getelementptr inbounds [4 x i8], ptr %24, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %231, ptr align 4 %23, i64 4, i1 false)
  %232 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10)
  store i32 0, ptr %25, align 4
  br label %233

233:                                              ; preds = %244, %230
  %234 = load i32, ptr %25, align 4
  %235 = zext i32 %234 to i64
  %236 = icmp ult i64 %235, 4
  br i1 %236, label %237, label %247

237:                                              ; preds = %233
  %238 = load i32, ptr %25, align 4
  %239 = zext i32 %238 to i64
  %240 = getelementptr inbounds nuw [4 x i8], ptr %24, i64 0, i64 %239
  %241 = load i8, ptr %240, align 1
  %242 = zext i8 %241 to i32
  %243 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %242)
  br label %244

244:                                              ; preds = %237
  %245 = load i32, ptr %25, align 4
  %246 = add i32 %245, 1
  store i32 %246, ptr %25, align 4
  br label %233, !llvm.loop !14

247:                                              ; preds = %233
  %248 = call i32 @puts(ptr noundef @.str.3)
  br label %249

249:                                              ; preds = %247
  br label %250

250:                                              ; preds = %249
  store i8 0, ptr %26, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %26, i8 -1, i64 1, i1 false)
  %251 = getelementptr inbounds [1 x i8], ptr %27, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %251, ptr align 1 %26, i64 1, i1 false)
  %252 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11)
  store i32 0, ptr %28, align 4
  br label %253

253:                                              ; preds = %264, %250
  %254 = load i32, ptr %28, align 4
  %255 = zext i32 %254 to i64
  %256 = icmp ult i64 %255, 1
  br i1 %256, label %257, label %267

257:                                              ; preds = %253
  %258 = load i32, ptr %28, align 4
  %259 = zext i32 %258 to i64
  %260 = getelementptr inbounds nuw [1 x i8], ptr %27, i64 0, i64 %259
  %261 = load i8, ptr %260, align 1
  %262 = zext i8 %261 to i32
  %263 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %262)
  br label %264

264:                                              ; preds = %257
  %265 = load i32, ptr %28, align 4
  %266 = add i32 %265, 1
  store i32 %266, ptr %28, align 4
  br label %253, !llvm.loop !15

267:                                              ; preds = %253
  %268 = call i32 @puts(ptr noundef @.str.3)
  br label %269

269:                                              ; preds = %267
  br label %270

270:                                              ; preds = %269
  store ptr null, ptr %29, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %29, i8 -1, i64 8, i1 false)
  %271 = getelementptr inbounds [8 x i8], ptr %30, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %271, ptr align 8 %29, i64 8, i1 false)
  %272 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12)
  store i32 0, ptr %31, align 4
  br label %273

273:                                              ; preds = %284, %270
  %274 = load i32, ptr %31, align 4
  %275 = zext i32 %274 to i64
  %276 = icmp ult i64 %275, 8
  br i1 %276, label %277, label %287

277:                                              ; preds = %273
  %278 = load i32, ptr %31, align 4
  %279 = zext i32 %278 to i64
  %280 = getelementptr inbounds nuw [8 x i8], ptr %30, i64 0, i64 %279
  %281 = load i8, ptr %280, align 1
  %282 = zext i8 %281 to i32
  %283 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %282)
  br label %284

284:                                              ; preds = %277
  %285 = load i32, ptr %31, align 4
  %286 = add i32 %285, 1
  store i32 %286, ptr %31, align 4
  br label %273, !llvm.loop !16

287:                                              ; preds = %273
  %288 = call i32 @puts(ptr noundef @.str.3)
  br label %289

289:                                              ; preds = %287
  %290 = getelementptr inbounds [3 x %struct.A], ptr %32, i64 0, i64 0
  call void @llvm.memset.p0.i64(ptr align 16 %290, i8 -85, i64 36, i1 false)
  %291 = getelementptr i8, ptr %32, i32 1
  store i8 0, ptr %291, align 1
  %292 = getelementptr i8, ptr %32, i32 2
  store i8 0, ptr %292, align 2
  %293 = getelementptr i8, ptr %32, i32 3
  store i8 0, ptr %293, align 1
  %294 = getelementptr i8, ptr %32, i32 10
  store i8 0, ptr %294, align 2
  %295 = getelementptr i8, ptr %32, i32 11
  store i8 0, ptr %295, align 1
  %296 = getelementptr i8, ptr %32, i32 13
  store i8 0, ptr %296, align 1
  %297 = getelementptr i8, ptr %32, i32 14
  store i8 0, ptr %297, align 2
  %298 = getelementptr i8, ptr %32, i32 15
  store i8 0, ptr %298, align 1
  %299 = getelementptr i8, ptr %32, i32 22
  store i8 0, ptr %299, align 2
  %300 = getelementptr i8, ptr %32, i32 23
  store i8 0, ptr %300, align 1
  %301 = getelementptr i8, ptr %32, i32 25
  store i8 0, ptr %301, align 1
  %302 = getelementptr i8, ptr %32, i32 26
  store i8 0, ptr %302, align 2
  %303 = getelementptr i8, ptr %32, i32 27
  store i8 0, ptr %303, align 1
  %304 = getelementptr i8, ptr %32, i32 34
  store i8 0, ptr %304, align 2
  %305 = getelementptr i8, ptr %32, i32 35
  store i8 0, ptr %305, align 1
  store i32 0, ptr %33, align 4
  br label %306

306:                                              ; preds = %318, %289
  %307 = load i32, ptr %33, align 4
  %308 = zext i32 %307 to i64
  %309 = icmp ult i64 %308, 36
  br i1 %309, label %310, label %321

310:                                              ; preds = %306
  %311 = getelementptr inbounds [3 x %struct.A], ptr %32, i64 0, i64 0
  %312 = load i32, ptr %33, align 4
  %313 = zext i32 %312 to i64
  %314 = getelementptr inbounds nuw i8, ptr %311, i64 %313
  %315 = load i8, ptr %314, align 1
  %316 = zext i8 %315 to i32
  %317 = call i32 (ptr, ...) @printf(ptr noundef @.str.13, i32 noundef %316)
  br label %318

318:                                              ; preds = %310
  %319 = load i32, ptr %33, align 4
  %320 = add i32 %319, 1
  store i32 %320, ptr %33, align 4
  br label %306, !llvm.loop !17

321:                                              ; preds = %306
  %322 = call i32 @puts(ptr noundef @.str.3)
  call void @llvm.memset.p0.i64(ptr align 4 %34, i8 -1, i64 12, i1 false)
  store ptr %34, ptr %35, align 8
  %323 = load ptr, ptr %35, align 8
  %324 = getelementptr inbounds nuw %struct.A, ptr %323, i32 1
  store ptr %324, ptr %35, align 8
  %325 = getelementptr i8, ptr %323, i32 1
  store i8 0, ptr %325, align 1
  %326 = getelementptr i8, ptr %323, i32 2
  store i8 0, ptr %326, align 2
  %327 = getelementptr i8, ptr %323, i32 3
  store i8 0, ptr %327, align 1
  %328 = getelementptr i8, ptr %323, i32 10
  store i8 0, ptr %328, align 2
  %329 = getelementptr i8, ptr %323, i32 11
  store i8 0, ptr %329, align 1
  %330 = load ptr, ptr %35, align 8
  %331 = ptrtoint ptr %330 to i64
  %332 = ptrtoint ptr %34 to i64
  %333 = sub i64 %331, %332
  %334 = sdiv exact i64 %333, 12
  %335 = trunc i64 %334 to i32
  %336 = getelementptr inbounds i8, ptr %34, i64 1
  %337 = load i8, ptr %336, align 1
  %338 = zext i8 %337 to i32
  %339 = call i32 (ptr, ...) @printf(ptr noundef @.str.14, i32 noundef %335, i32 noundef %338)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

declare i32 @printf(ptr noundef, ...) #3

declare i32 @puts(ptr noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
