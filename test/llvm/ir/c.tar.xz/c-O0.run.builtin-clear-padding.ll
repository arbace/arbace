; ModuleID = 'test/c/run/builtin-clear-padding.c'
source_filename = "test/c/run/builtin-clear-padding.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i8, i32, i16 }
%struct.B = type { i8, [3 x i8] }
%struct.C = type { i16, i8 }
%union.U = type { %struct.anon }
%struct.anon = type { i8, i32 }
%struct.D = type { [2 x %struct.A], %union.U, i8 }
%struct.E = type { i8, %struct.anon.0, double }
%struct.anon.0 = type { i32, i8 }
%struct.F = type { i8, i8 }

@.str = private unnamed_addr constant [5 x i8] c"%-8s\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"struct A\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c" %02x\00", align 1
@.str.3 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@.str.4 = private unnamed_addr constant [36 x i8] c"ff 00 00 00 ff ff ff ff ff ff 00 00\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"struct B\00", align 1
@.str.6 = private unnamed_addr constant [12 x i8] c"11 00 00 00\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"struct C\00", align 1
@.str.8 = private unnamed_addr constant [12 x i8] c"e7 01 ff 00\00", align 1
@.str.9 = private unnamed_addr constant [8 x i8] c"union U\00", align 1
@.str.10 = private unnamed_addr constant [24 x i8] c"ff ff 00 00 ff ff ff ff\00", align 1
@.str.11 = private unnamed_addr constant [9 x i8] c"struct D\00", align 1
@.str.12 = private unnamed_addr constant [108 x i8] c"ff 00 00 00 ff ff ff ff ff ff 00 00 ff 00 00 00 ff ff ff ff ff ff 00 00 ff ff 00 00 ff ff ff ff ff 00 00 00\00", align 1
@.str.13 = private unnamed_addr constant [9 x i8] c"struct E\00", align 1
@.str.14 = private unnamed_addr constant [72 x i8] c"ff 00 00 00 ff ff ff ff ff 00 00 00 00 00 00 00 ff ff ff ff ff ff ff ff\00", align 1
@.str.15 = private unnamed_addr constant [9 x i8] c"struct F\00", align 1
@.str.16 = private unnamed_addr constant [6 x i8] c"0f 03\00", align 1
@.str.17 = private unnamed_addr constant [4 x i8] c"int\00", align 1
@.str.18 = private unnamed_addr constant [12 x i8] c"ff ff ff ff\00", align 1
@.str.19 = private unnamed_addr constant [6 x i8] c"_Bool\00", align 1
@.str.20 = private unnamed_addr constant [3 x i8] c"ff\00", align 1
@.str.21 = private unnamed_addr constant [7 x i8] c"char *\00", align 1
@.str.22 = private unnamed_addr constant [24 x i8] c"ff ff ff ff ff ff ff ff\00", align 1
@.str.23 = private unnamed_addr constant [5 x i8] c"%02x\00", align 1
@main.e = internal constant [12 x i8] c"\AB\00\00\00\AB\AB\AB\AB\AB\AB\00\00", align 1
@fails = internal global i32 0, align 4
@.str.24 = private unnamed_addr constant [9 x i8] c"%d %02x\0A\00", align 1
@stderr = external constant ptr, align 8
@.str.25 = private unnamed_addr constant [18 x i8] c"FAIL %s, want %s\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.A, align 4
  %3 = alloca [12 x i8], align 1
  %4 = alloca [37 x i8], align 16
  %5 = alloca i32, align 4
  %6 = alloca %struct.B, align 4
  %7 = alloca [4 x i8], align 1
  %8 = alloca [13 x i8], align 1
  %9 = alloca i32, align 4
  %10 = alloca %struct.C, align 4
  %11 = alloca [4 x i8], align 1
  %12 = alloca [13 x i8], align 1
  %13 = alloca i32, align 4
  %14 = alloca %union.U, align 4
  %15 = alloca [8 x i8], align 1
  %16 = alloca [25 x i8], align 16
  %17 = alloca i32, align 4
  %18 = alloca %struct.D, align 4
  %19 = alloca [36 x i8], align 16
  %20 = alloca [109 x i8], align 16
  %21 = alloca i32, align 4
  %22 = alloca %struct.E, align 8
  %23 = alloca [24 x i8], align 16
  %24 = alloca [73 x i8], align 16
  %25 = alloca i32, align 4
  %26 = alloca %struct.F, align 1
  %27 = alloca [2 x i8], align 1
  %28 = alloca [7 x i8], align 1
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca [4 x i8], align 1
  %32 = alloca [13 x i8], align 1
  %33 = alloca i32, align 4
  %34 = alloca i8, align 1
  %35 = alloca [1 x i8], align 1
  %36 = alloca [4 x i8], align 1
  %37 = alloca i32, align 4
  %38 = alloca ptr, align 8
  %39 = alloca [8 x i8], align 1
  %40 = alloca [25 x i8], align 16
  %41 = alloca i32, align 4
  %42 = alloca [3 x %struct.A], align 16
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca %struct.A, align 4
  %46 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  br label %47

47:                                               ; preds = %0
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 0, i64 12, i1 false)
  %48 = getelementptr inbounds [37 x i8], ptr %4, i64 0, i64 0
  store i8 0, ptr %48, align 16
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 -1, i64 12, i1 false)
  %49 = getelementptr i8, ptr %2, i32 1
  store i8 0, ptr %49, align 1
  %50 = getelementptr i8, ptr %2, i32 2
  store i8 0, ptr %50, align 2
  %51 = getelementptr i8, ptr %2, i32 3
  store i8 0, ptr %51, align 1
  %52 = getelementptr i8, ptr %2, i32 10
  store i8 0, ptr %52, align 2
  %53 = getelementptr i8, ptr %2, i32 11
  store i8 0, ptr %53, align 1
  %54 = getelementptr inbounds [12 x i8], ptr %3, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %54, ptr align 4 %2, i64 12, i1 false)
  %55 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1)
  store i32 0, ptr %5, align 4
  br label %56

56:                                               ; preds = %78, %47
  %57 = load i32, ptr %5, align 4
  %58 = zext i32 %57 to i64
  %59 = icmp ult i64 %58, 12
  br i1 %59, label %60, label %81

60:                                               ; preds = %56
  %61 = load i32, ptr %5, align 4
  %62 = zext i32 %61 to i64
  %63 = getelementptr inbounds nuw [12 x i8], ptr %3, i64 0, i64 %62
  %64 = load i8, ptr %63, align 1
  %65 = zext i8 %64 to i32
  %66 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %65)
  %67 = getelementptr inbounds [37 x i8], ptr %4, i64 0, i64 0
  %68 = load i32, ptr %5, align 4
  %69 = mul i32 3, %68
  %70 = zext i32 %69 to i64
  %71 = getelementptr inbounds nuw i8, ptr %67, i64 %70
  %72 = load i32, ptr %5, align 4
  %73 = zext i32 %72 to i64
  %74 = getelementptr inbounds nuw [12 x i8], ptr %3, i64 0, i64 %73
  %75 = load i8, ptr %74, align 1
  %76 = zext i8 %75 to i32
  %77 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %71, ptr noundef @.str.2, i32 noundef %76) #5
  br label %78

78:                                               ; preds = %60
  %79 = load i32, ptr %5, align 4
  %80 = add i32 %79, 1
  store i32 %80, ptr %5, align 4
  br label %56, !llvm.loop !6

81:                                               ; preds = %56
  %82 = call i32 @puts(ptr noundef @.str.3)
  %83 = getelementptr inbounds [37 x i8], ptr %4, i64 0, i64 0
  %84 = getelementptr inbounds i8, ptr %83, i64 1
  call void @held(ptr noundef %84, ptr noundef @.str.4)
  br label %85

85:                                               ; preds = %81
  br label %86

86:                                               ; preds = %85
  call void @llvm.memset.p0.i64(ptr align 4 %6, i8 0, i64 4, i1 false)
  %87 = getelementptr inbounds [13 x i8], ptr %8, i64 0, i64 0
  store i8 0, ptr %87, align 1
  call void @llvm.memset.p0.i64(ptr align 4 %6, i8 -1, i64 4, i1 false)
  %88 = getelementptr i8, ptr %6, i32 0
  %89 = load i8, ptr %88, align 4
  %90 = and i8 %89, -15
  store i8 %90, ptr %88, align 4
  %91 = getelementptr i8, ptr %6, i32 0
  %92 = load i8, ptr %91, align 4
  %93 = and i8 %92, 31
  store i8 %93, ptr %91, align 4
  %94 = getelementptr i8, ptr %6, i32 1
  store i8 0, ptr %94, align 1
  %95 = getelementptr i8, ptr %6, i32 2
  store i8 0, ptr %95, align 2
  %96 = getelementptr i8, ptr %6, i32 3
  store i8 0, ptr %96, align 1
  %97 = getelementptr inbounds [4 x i8], ptr %7, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %97, ptr align 4 %6, i64 4, i1 false)
  %98 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5)
  store i32 0, ptr %9, align 4
  br label %99

99:                                               ; preds = %121, %86
  %100 = load i32, ptr %9, align 4
  %101 = zext i32 %100 to i64
  %102 = icmp ult i64 %101, 4
  br i1 %102, label %103, label %124

103:                                              ; preds = %99
  %104 = load i32, ptr %9, align 4
  %105 = zext i32 %104 to i64
  %106 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 0, i64 %105
  %107 = load i8, ptr %106, align 1
  %108 = zext i8 %107 to i32
  %109 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %108)
  %110 = getelementptr inbounds [13 x i8], ptr %8, i64 0, i64 0
  %111 = load i32, ptr %9, align 4
  %112 = mul i32 3, %111
  %113 = zext i32 %112 to i64
  %114 = getelementptr inbounds nuw i8, ptr %110, i64 %113
  %115 = load i32, ptr %9, align 4
  %116 = zext i32 %115 to i64
  %117 = getelementptr inbounds nuw [4 x i8], ptr %7, i64 0, i64 %116
  %118 = load i8, ptr %117, align 1
  %119 = zext i8 %118 to i32
  %120 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %114, ptr noundef @.str.2, i32 noundef %119) #5
  br label %121

121:                                              ; preds = %103
  %122 = load i32, ptr %9, align 4
  %123 = add i32 %122, 1
  store i32 %123, ptr %9, align 4
  br label %99, !llvm.loop !8

124:                                              ; preds = %99
  %125 = call i32 @puts(ptr noundef @.str.3)
  %126 = getelementptr inbounds [13 x i8], ptr %8, i64 0, i64 0
  %127 = getelementptr inbounds i8, ptr %126, i64 1
  call void @held(ptr noundef %127, ptr noundef @.str.6)
  br label %128

128:                                              ; preds = %124
  br label %129

129:                                              ; preds = %128
  call void @llvm.memset.p0.i64(ptr align 4 %10, i8 0, i64 4, i1 false)
  %130 = getelementptr inbounds [13 x i8], ptr %12, i64 0, i64 0
  store i8 0, ptr %130, align 1
  call void @llvm.memset.p0.i64(ptr align 4 %10, i8 -1, i64 4, i1 false)
  %131 = getelementptr i8, ptr %10, i32 0
  %132 = load i8, ptr %131, align 4
  %133 = and i8 %132, -25
  store i8 %133, ptr %131, align 4
  %134 = getelementptr i8, ptr %10, i32 1
  %135 = load i8, ptr %134, align 1
  %136 = and i8 %135, 1
  store i8 %136, ptr %134, align 1
  %137 = getelementptr i8, ptr %10, i32 3
  store i8 0, ptr %137, align 1
  %138 = getelementptr inbounds [4 x i8], ptr %11, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %138, ptr align 4 %10, i64 4, i1 false)
  %139 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7)
  store i32 0, ptr %13, align 4
  br label %140

140:                                              ; preds = %162, %129
  %141 = load i32, ptr %13, align 4
  %142 = zext i32 %141 to i64
  %143 = icmp ult i64 %142, 4
  br i1 %143, label %144, label %165

144:                                              ; preds = %140
  %145 = load i32, ptr %13, align 4
  %146 = zext i32 %145 to i64
  %147 = getelementptr inbounds nuw [4 x i8], ptr %11, i64 0, i64 %146
  %148 = load i8, ptr %147, align 1
  %149 = zext i8 %148 to i32
  %150 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %149)
  %151 = getelementptr inbounds [13 x i8], ptr %12, i64 0, i64 0
  %152 = load i32, ptr %13, align 4
  %153 = mul i32 3, %152
  %154 = zext i32 %153 to i64
  %155 = getelementptr inbounds nuw i8, ptr %151, i64 %154
  %156 = load i32, ptr %13, align 4
  %157 = zext i32 %156 to i64
  %158 = getelementptr inbounds nuw [4 x i8], ptr %11, i64 0, i64 %157
  %159 = load i8, ptr %158, align 1
  %160 = zext i8 %159 to i32
  %161 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %155, ptr noundef @.str.2, i32 noundef %160) #5
  br label %162

162:                                              ; preds = %144
  %163 = load i32, ptr %13, align 4
  %164 = add i32 %163, 1
  store i32 %164, ptr %13, align 4
  br label %140, !llvm.loop !9

165:                                              ; preds = %140
  %166 = call i32 @puts(ptr noundef @.str.3)
  %167 = getelementptr inbounds [13 x i8], ptr %12, i64 0, i64 0
  %168 = getelementptr inbounds i8, ptr %167, i64 1
  call void @held(ptr noundef %168, ptr noundef @.str.8)
  br label %169

169:                                              ; preds = %165
  br label %170

170:                                              ; preds = %169
  call void @llvm.memset.p0.i64(ptr align 4 %14, i8 0, i64 8, i1 false)
  %171 = getelementptr inbounds [25 x i8], ptr %16, i64 0, i64 0
  store i8 0, ptr %171, align 16
  call void @llvm.memset.p0.i64(ptr align 4 %14, i8 -1, i64 8, i1 false)
  %172 = getelementptr i8, ptr %14, i32 2
  store i8 0, ptr %172, align 2
  %173 = getelementptr i8, ptr %14, i32 3
  store i8 0, ptr %173, align 1
  %174 = getelementptr inbounds [8 x i8], ptr %15, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %174, ptr align 4 %14, i64 8, i1 false)
  %175 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9)
  store i32 0, ptr %17, align 4
  br label %176

176:                                              ; preds = %198, %170
  %177 = load i32, ptr %17, align 4
  %178 = zext i32 %177 to i64
  %179 = icmp ult i64 %178, 8
  br i1 %179, label %180, label %201

180:                                              ; preds = %176
  %181 = load i32, ptr %17, align 4
  %182 = zext i32 %181 to i64
  %183 = getelementptr inbounds nuw [8 x i8], ptr %15, i64 0, i64 %182
  %184 = load i8, ptr %183, align 1
  %185 = zext i8 %184 to i32
  %186 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %185)
  %187 = getelementptr inbounds [25 x i8], ptr %16, i64 0, i64 0
  %188 = load i32, ptr %17, align 4
  %189 = mul i32 3, %188
  %190 = zext i32 %189 to i64
  %191 = getelementptr inbounds nuw i8, ptr %187, i64 %190
  %192 = load i32, ptr %17, align 4
  %193 = zext i32 %192 to i64
  %194 = getelementptr inbounds nuw [8 x i8], ptr %15, i64 0, i64 %193
  %195 = load i8, ptr %194, align 1
  %196 = zext i8 %195 to i32
  %197 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %191, ptr noundef @.str.2, i32 noundef %196) #5
  br label %198

198:                                              ; preds = %180
  %199 = load i32, ptr %17, align 4
  %200 = add i32 %199, 1
  store i32 %200, ptr %17, align 4
  br label %176, !llvm.loop !10

201:                                              ; preds = %176
  %202 = call i32 @puts(ptr noundef @.str.3)
  %203 = getelementptr inbounds [25 x i8], ptr %16, i64 0, i64 0
  %204 = getelementptr inbounds i8, ptr %203, i64 1
  call void @held(ptr noundef %204, ptr noundef @.str.10)
  br label %205

205:                                              ; preds = %201
  br label %206

206:                                              ; preds = %205
  call void @llvm.memset.p0.i64(ptr align 4 %18, i8 0, i64 36, i1 false)
  %207 = getelementptr inbounds [109 x i8], ptr %20, i64 0, i64 0
  store i8 0, ptr %207, align 16
  call void @llvm.memset.p0.i64(ptr align 4 %18, i8 -1, i64 36, i1 false)
  %208 = getelementptr i8, ptr %18, i32 1
  store i8 0, ptr %208, align 1
  %209 = getelementptr i8, ptr %18, i32 2
  store i8 0, ptr %209, align 2
  %210 = getelementptr i8, ptr %18, i32 3
  store i8 0, ptr %210, align 1
  %211 = getelementptr i8, ptr %18, i32 10
  store i8 0, ptr %211, align 2
  %212 = getelementptr i8, ptr %18, i32 11
  store i8 0, ptr %212, align 1
  %213 = getelementptr i8, ptr %18, i32 13
  store i8 0, ptr %213, align 1
  %214 = getelementptr i8, ptr %18, i32 14
  store i8 0, ptr %214, align 2
  %215 = getelementptr i8, ptr %18, i32 15
  store i8 0, ptr %215, align 1
  %216 = getelementptr i8, ptr %18, i32 22
  store i8 0, ptr %216, align 2
  %217 = getelementptr i8, ptr %18, i32 23
  store i8 0, ptr %217, align 1
  %218 = getelementptr i8, ptr %18, i32 26
  store i8 0, ptr %218, align 2
  %219 = getelementptr i8, ptr %18, i32 27
  store i8 0, ptr %219, align 1
  %220 = getelementptr i8, ptr %18, i32 33
  store i8 0, ptr %220, align 1
  %221 = getelementptr i8, ptr %18, i32 34
  store i8 0, ptr %221, align 2
  %222 = getelementptr i8, ptr %18, i32 35
  store i8 0, ptr %222, align 1
  %223 = getelementptr inbounds [36 x i8], ptr %19, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %223, ptr align 4 %18, i64 36, i1 false)
  %224 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11)
  store i32 0, ptr %21, align 4
  br label %225

225:                                              ; preds = %247, %206
  %226 = load i32, ptr %21, align 4
  %227 = zext i32 %226 to i64
  %228 = icmp ult i64 %227, 36
  br i1 %228, label %229, label %250

229:                                              ; preds = %225
  %230 = load i32, ptr %21, align 4
  %231 = zext i32 %230 to i64
  %232 = getelementptr inbounds nuw [36 x i8], ptr %19, i64 0, i64 %231
  %233 = load i8, ptr %232, align 1
  %234 = zext i8 %233 to i32
  %235 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %234)
  %236 = getelementptr inbounds [109 x i8], ptr %20, i64 0, i64 0
  %237 = load i32, ptr %21, align 4
  %238 = mul i32 3, %237
  %239 = zext i32 %238 to i64
  %240 = getelementptr inbounds nuw i8, ptr %236, i64 %239
  %241 = load i32, ptr %21, align 4
  %242 = zext i32 %241 to i64
  %243 = getelementptr inbounds nuw [36 x i8], ptr %19, i64 0, i64 %242
  %244 = load i8, ptr %243, align 1
  %245 = zext i8 %244 to i32
  %246 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %240, ptr noundef @.str.2, i32 noundef %245) #5
  br label %247

247:                                              ; preds = %229
  %248 = load i32, ptr %21, align 4
  %249 = add i32 %248, 1
  store i32 %249, ptr %21, align 4
  br label %225, !llvm.loop !11

250:                                              ; preds = %225
  %251 = call i32 @puts(ptr noundef @.str.3)
  %252 = getelementptr inbounds [109 x i8], ptr %20, i64 0, i64 0
  %253 = getelementptr inbounds i8, ptr %252, i64 1
  call void @held(ptr noundef %253, ptr noundef @.str.12)
  br label %254

254:                                              ; preds = %250
  br label %255

255:                                              ; preds = %254
  call void @llvm.memset.p0.i64(ptr align 8 %22, i8 0, i64 24, i1 false)
  %256 = getelementptr inbounds [73 x i8], ptr %24, i64 0, i64 0
  store i8 0, ptr %256, align 16
  call void @llvm.memset.p0.i64(ptr align 8 %22, i8 -1, i64 24, i1 false)
  %257 = getelementptr i8, ptr %22, i32 1
  store i8 0, ptr %257, align 1
  %258 = getelementptr i8, ptr %22, i32 2
  store i8 0, ptr %258, align 2
  %259 = getelementptr i8, ptr %22, i32 3
  store i8 0, ptr %259, align 1
  %260 = getelementptr i8, ptr %22, i32 9
  store i8 0, ptr %260, align 1
  %261 = getelementptr i8, ptr %22, i32 10
  store i8 0, ptr %261, align 2
  %262 = getelementptr i8, ptr %22, i32 11
  store i8 0, ptr %262, align 1
  %263 = getelementptr i8, ptr %22, i32 12
  store i8 0, ptr %263, align 4
  %264 = getelementptr i8, ptr %22, i32 13
  store i8 0, ptr %264, align 1
  %265 = getelementptr i8, ptr %22, i32 14
  store i8 0, ptr %265, align 2
  %266 = getelementptr i8, ptr %22, i32 15
  store i8 0, ptr %266, align 1
  %267 = getelementptr inbounds [24 x i8], ptr %23, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %267, ptr align 8 %22, i64 24, i1 false)
  %268 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13)
  store i32 0, ptr %25, align 4
  br label %269

269:                                              ; preds = %291, %255
  %270 = load i32, ptr %25, align 4
  %271 = zext i32 %270 to i64
  %272 = icmp ult i64 %271, 24
  br i1 %272, label %273, label %294

273:                                              ; preds = %269
  %274 = load i32, ptr %25, align 4
  %275 = zext i32 %274 to i64
  %276 = getelementptr inbounds nuw [24 x i8], ptr %23, i64 0, i64 %275
  %277 = load i8, ptr %276, align 1
  %278 = zext i8 %277 to i32
  %279 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %278)
  %280 = getelementptr inbounds [73 x i8], ptr %24, i64 0, i64 0
  %281 = load i32, ptr %25, align 4
  %282 = mul i32 3, %281
  %283 = zext i32 %282 to i64
  %284 = getelementptr inbounds nuw i8, ptr %280, i64 %283
  %285 = load i32, ptr %25, align 4
  %286 = zext i32 %285 to i64
  %287 = getelementptr inbounds nuw [24 x i8], ptr %23, i64 0, i64 %286
  %288 = load i8, ptr %287, align 1
  %289 = zext i8 %288 to i32
  %290 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %284, ptr noundef @.str.2, i32 noundef %289) #5
  br label %291

291:                                              ; preds = %273
  %292 = load i32, ptr %25, align 4
  %293 = add i32 %292, 1
  store i32 %293, ptr %25, align 4
  br label %269, !llvm.loop !12

294:                                              ; preds = %269
  %295 = call i32 @puts(ptr noundef @.str.3)
  %296 = getelementptr inbounds [73 x i8], ptr %24, i64 0, i64 0
  %297 = getelementptr inbounds i8, ptr %296, i64 1
  call void @held(ptr noundef %297, ptr noundef @.str.14)
  br label %298

298:                                              ; preds = %294
  br label %299

299:                                              ; preds = %298
  call void @llvm.memset.p0.i64(ptr align 1 %26, i8 0, i64 2, i1 false)
  %300 = getelementptr inbounds [7 x i8], ptr %28, i64 0, i64 0
  store i8 0, ptr %300, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %26, i8 -1, i64 2, i1 false)
  %301 = getelementptr i8, ptr %26, i32 0
  %302 = load i8, ptr %301, align 1
  %303 = and i8 %302, 15
  store i8 %303, ptr %301, align 1
  %304 = getelementptr i8, ptr %26, i32 1
  %305 = load i8, ptr %304, align 1
  %306 = and i8 %305, 3
  store i8 %306, ptr %304, align 1
  %307 = getelementptr inbounds [2 x i8], ptr %27, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %307, ptr align 1 %26, i64 2, i1 false)
  %308 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15)
  store i32 0, ptr %29, align 4
  br label %309

309:                                              ; preds = %331, %299
  %310 = load i32, ptr %29, align 4
  %311 = zext i32 %310 to i64
  %312 = icmp ult i64 %311, 2
  br i1 %312, label %313, label %334

313:                                              ; preds = %309
  %314 = load i32, ptr %29, align 4
  %315 = zext i32 %314 to i64
  %316 = getelementptr inbounds nuw [2 x i8], ptr %27, i64 0, i64 %315
  %317 = load i8, ptr %316, align 1
  %318 = zext i8 %317 to i32
  %319 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %318)
  %320 = getelementptr inbounds [7 x i8], ptr %28, i64 0, i64 0
  %321 = load i32, ptr %29, align 4
  %322 = mul i32 3, %321
  %323 = zext i32 %322 to i64
  %324 = getelementptr inbounds nuw i8, ptr %320, i64 %323
  %325 = load i32, ptr %29, align 4
  %326 = zext i32 %325 to i64
  %327 = getelementptr inbounds nuw [2 x i8], ptr %27, i64 0, i64 %326
  %328 = load i8, ptr %327, align 1
  %329 = zext i8 %328 to i32
  %330 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %324, ptr noundef @.str.2, i32 noundef %329) #5
  br label %331

331:                                              ; preds = %313
  %332 = load i32, ptr %29, align 4
  %333 = add i32 %332, 1
  store i32 %333, ptr %29, align 4
  br label %309, !llvm.loop !13

334:                                              ; preds = %309
  %335 = call i32 @puts(ptr noundef @.str.3)
  %336 = getelementptr inbounds [7 x i8], ptr %28, i64 0, i64 0
  %337 = getelementptr inbounds i8, ptr %336, i64 1
  call void @held(ptr noundef %337, ptr noundef @.str.16)
  br label %338

338:                                              ; preds = %334
  br label %339

339:                                              ; preds = %338
  store i32 0, ptr %30, align 4
  %340 = getelementptr inbounds [13 x i8], ptr %32, i64 0, i64 0
  store i8 0, ptr %340, align 1
  call void @llvm.memset.p0.i64(ptr align 4 %30, i8 -1, i64 4, i1 false)
  %341 = getelementptr inbounds [4 x i8], ptr %31, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %341, ptr align 4 %30, i64 4, i1 false)
  %342 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17)
  store i32 0, ptr %33, align 4
  br label %343

343:                                              ; preds = %365, %339
  %344 = load i32, ptr %33, align 4
  %345 = zext i32 %344 to i64
  %346 = icmp ult i64 %345, 4
  br i1 %346, label %347, label %368

347:                                              ; preds = %343
  %348 = load i32, ptr %33, align 4
  %349 = zext i32 %348 to i64
  %350 = getelementptr inbounds nuw [4 x i8], ptr %31, i64 0, i64 %349
  %351 = load i8, ptr %350, align 1
  %352 = zext i8 %351 to i32
  %353 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %352)
  %354 = getelementptr inbounds [13 x i8], ptr %32, i64 0, i64 0
  %355 = load i32, ptr %33, align 4
  %356 = mul i32 3, %355
  %357 = zext i32 %356 to i64
  %358 = getelementptr inbounds nuw i8, ptr %354, i64 %357
  %359 = load i32, ptr %33, align 4
  %360 = zext i32 %359 to i64
  %361 = getelementptr inbounds nuw [4 x i8], ptr %31, i64 0, i64 %360
  %362 = load i8, ptr %361, align 1
  %363 = zext i8 %362 to i32
  %364 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %358, ptr noundef @.str.2, i32 noundef %363) #5
  br label %365

365:                                              ; preds = %347
  %366 = load i32, ptr %33, align 4
  %367 = add i32 %366, 1
  store i32 %367, ptr %33, align 4
  br label %343, !llvm.loop !14

368:                                              ; preds = %343
  %369 = call i32 @puts(ptr noundef @.str.3)
  %370 = getelementptr inbounds [13 x i8], ptr %32, i64 0, i64 0
  %371 = getelementptr inbounds i8, ptr %370, i64 1
  call void @held(ptr noundef %371, ptr noundef @.str.18)
  br label %372

372:                                              ; preds = %368
  br label %373

373:                                              ; preds = %372
  store i8 0, ptr %34, align 1
  %374 = getelementptr inbounds [4 x i8], ptr %36, i64 0, i64 0
  store i8 0, ptr %374, align 1
  call void @llvm.memset.p0.i64(ptr align 1 %34, i8 -1, i64 1, i1 false)
  %375 = getelementptr inbounds [1 x i8], ptr %35, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %375, ptr align 1 %34, i64 1, i1 false)
  %376 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.19)
  store i32 0, ptr %37, align 4
  br label %377

377:                                              ; preds = %399, %373
  %378 = load i32, ptr %37, align 4
  %379 = zext i32 %378 to i64
  %380 = icmp ult i64 %379, 1
  br i1 %380, label %381, label %402

381:                                              ; preds = %377
  %382 = load i32, ptr %37, align 4
  %383 = zext i32 %382 to i64
  %384 = getelementptr inbounds nuw [1 x i8], ptr %35, i64 0, i64 %383
  %385 = load i8, ptr %384, align 1
  %386 = zext i8 %385 to i32
  %387 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %386)
  %388 = getelementptr inbounds [4 x i8], ptr %36, i64 0, i64 0
  %389 = load i32, ptr %37, align 4
  %390 = mul i32 3, %389
  %391 = zext i32 %390 to i64
  %392 = getelementptr inbounds nuw i8, ptr %388, i64 %391
  %393 = load i32, ptr %37, align 4
  %394 = zext i32 %393 to i64
  %395 = getelementptr inbounds nuw [1 x i8], ptr %35, i64 0, i64 %394
  %396 = load i8, ptr %395, align 1
  %397 = zext i8 %396 to i32
  %398 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %392, ptr noundef @.str.2, i32 noundef %397) #5
  br label %399

399:                                              ; preds = %381
  %400 = load i32, ptr %37, align 4
  %401 = add i32 %400, 1
  store i32 %401, ptr %37, align 4
  br label %377, !llvm.loop !15

402:                                              ; preds = %377
  %403 = call i32 @puts(ptr noundef @.str.3)
  %404 = getelementptr inbounds [4 x i8], ptr %36, i64 0, i64 0
  %405 = getelementptr inbounds i8, ptr %404, i64 1
  call void @held(ptr noundef %405, ptr noundef @.str.20)
  br label %406

406:                                              ; preds = %402
  br label %407

407:                                              ; preds = %406
  store ptr null, ptr %38, align 8
  %408 = getelementptr inbounds [25 x i8], ptr %40, i64 0, i64 0
  store i8 0, ptr %408, align 16
  call void @llvm.memset.p0.i64(ptr align 8 %38, i8 -1, i64 8, i1 false)
  %409 = getelementptr inbounds [8 x i8], ptr %39, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %409, ptr align 8 %38, i64 8, i1 false)
  %410 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.21)
  store i32 0, ptr %41, align 4
  br label %411

411:                                              ; preds = %433, %407
  %412 = load i32, ptr %41, align 4
  %413 = zext i32 %412 to i64
  %414 = icmp ult i64 %413, 8
  br i1 %414, label %415, label %436

415:                                              ; preds = %411
  %416 = load i32, ptr %41, align 4
  %417 = zext i32 %416 to i64
  %418 = getelementptr inbounds nuw [8 x i8], ptr %39, i64 0, i64 %417
  %419 = load i8, ptr %418, align 1
  %420 = zext i8 %419 to i32
  %421 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %420)
  %422 = getelementptr inbounds [25 x i8], ptr %40, i64 0, i64 0
  %423 = load i32, ptr %41, align 4
  %424 = mul i32 3, %423
  %425 = zext i32 %424 to i64
  %426 = getelementptr inbounds nuw i8, ptr %422, i64 %425
  %427 = load i32, ptr %41, align 4
  %428 = zext i32 %427 to i64
  %429 = getelementptr inbounds nuw [8 x i8], ptr %39, i64 0, i64 %428
  %430 = load i8, ptr %429, align 1
  %431 = zext i8 %430 to i32
  %432 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef %426, ptr noundef @.str.2, i32 noundef %431) #5
  br label %433

433:                                              ; preds = %415
  %434 = load i32, ptr %41, align 4
  %435 = add i32 %434, 1
  store i32 %435, ptr %41, align 4
  br label %411, !llvm.loop !16

436:                                              ; preds = %411
  %437 = call i32 @puts(ptr noundef @.str.3)
  %438 = getelementptr inbounds [25 x i8], ptr %40, i64 0, i64 0
  %439 = getelementptr inbounds i8, ptr %438, i64 1
  call void @held(ptr noundef %439, ptr noundef @.str.22)
  br label %440

440:                                              ; preds = %436
  %441 = getelementptr inbounds [3 x %struct.A], ptr %42, i64 0, i64 0
  call void @llvm.memset.p0.i64(ptr align 16 %441, i8 -85, i64 36, i1 false)
  %442 = getelementptr i8, ptr %42, i32 1
  store i8 0, ptr %442, align 1
  %443 = getelementptr i8, ptr %42, i32 2
  store i8 0, ptr %443, align 2
  %444 = getelementptr i8, ptr %42, i32 3
  store i8 0, ptr %444, align 1
  %445 = getelementptr i8, ptr %42, i32 10
  store i8 0, ptr %445, align 2
  %446 = getelementptr i8, ptr %42, i32 11
  store i8 0, ptr %446, align 1
  %447 = getelementptr i8, ptr %42, i32 13
  store i8 0, ptr %447, align 1
  %448 = getelementptr i8, ptr %42, i32 14
  store i8 0, ptr %448, align 2
  %449 = getelementptr i8, ptr %42, i32 15
  store i8 0, ptr %449, align 1
  %450 = getelementptr i8, ptr %42, i32 22
  store i8 0, ptr %450, align 2
  %451 = getelementptr i8, ptr %42, i32 23
  store i8 0, ptr %451, align 1
  %452 = getelementptr i8, ptr %42, i32 25
  store i8 0, ptr %452, align 1
  %453 = getelementptr i8, ptr %42, i32 26
  store i8 0, ptr %453, align 2
  %454 = getelementptr i8, ptr %42, i32 27
  store i8 0, ptr %454, align 1
  %455 = getelementptr i8, ptr %42, i32 34
  store i8 0, ptr %455, align 2
  %456 = getelementptr i8, ptr %42, i32 35
  store i8 0, ptr %456, align 1
  store i32 0, ptr %43, align 4
  br label %457

457:                                              ; preds = %469, %440
  %458 = load i32, ptr %43, align 4
  %459 = zext i32 %458 to i64
  %460 = icmp ult i64 %459, 36
  br i1 %460, label %461, label %472

461:                                              ; preds = %457
  %462 = getelementptr inbounds [3 x %struct.A], ptr %42, i64 0, i64 0
  %463 = load i32, ptr %43, align 4
  %464 = zext i32 %463 to i64
  %465 = getelementptr inbounds nuw i8, ptr %462, i64 %464
  %466 = load i8, ptr %465, align 1
  %467 = zext i8 %466 to i32
  %468 = call i32 (ptr, ...) @printf(ptr noundef @.str.23, i32 noundef %467)
  br label %469

469:                                              ; preds = %461
  %470 = load i32, ptr %43, align 4
  %471 = add i32 %470, 1
  store i32 %471, ptr %43, align 4
  br label %457, !llvm.loop !17

472:                                              ; preds = %457
  %473 = call i32 @puts(ptr noundef @.str.3)
  store i32 0, ptr %44, align 4
  br label %474

474:                                              ; preds = %496, %472
  %475 = load i32, ptr %44, align 4
  %476 = zext i32 %475 to i64
  %477 = icmp ult i64 %476, 36
  br i1 %477, label %478, label %499

478:                                              ; preds = %474
  %479 = getelementptr inbounds [3 x %struct.A], ptr %42, i64 0, i64 0
  %480 = load i32, ptr %44, align 4
  %481 = zext i32 %480 to i64
  %482 = getelementptr inbounds nuw i8, ptr %479, i64 %481
  %483 = load i8, ptr %482, align 1
  %484 = zext i8 %483 to i32
  %485 = load i32, ptr %44, align 4
  %486 = urem i32 %485, 12
  %487 = zext i32 %486 to i64
  %488 = getelementptr inbounds nuw [12 x i8], ptr @main.e, i64 0, i64 %487
  %489 = load i8, ptr %488, align 1
  %490 = zext i8 %489 to i32
  %491 = icmp ne i32 %484, %490
  br i1 %491, label %492, label %495

492:                                              ; preds = %478
  %493 = load i32, ptr @fails, align 4
  %494 = add nsw i32 %493, 1
  store i32 %494, ptr @fails, align 4
  br label %495

495:                                              ; preds = %492, %478
  br label %496

496:                                              ; preds = %495
  %497 = load i32, ptr %44, align 4
  %498 = add i32 %497, 1
  store i32 %498, ptr %44, align 4
  br label %474, !llvm.loop !18

499:                                              ; preds = %474
  call void @llvm.memset.p0.i64(ptr align 4 %45, i8 -1, i64 12, i1 false)
  store ptr %45, ptr %46, align 8
  %500 = load ptr, ptr %46, align 8
  %501 = getelementptr inbounds nuw %struct.A, ptr %500, i32 1
  store ptr %501, ptr %46, align 8
  %502 = getelementptr i8, ptr %500, i32 1
  store i8 0, ptr %502, align 1
  %503 = getelementptr i8, ptr %500, i32 2
  store i8 0, ptr %503, align 2
  %504 = getelementptr i8, ptr %500, i32 3
  store i8 0, ptr %504, align 1
  %505 = getelementptr i8, ptr %500, i32 10
  store i8 0, ptr %505, align 2
  %506 = getelementptr i8, ptr %500, i32 11
  store i8 0, ptr %506, align 1
  %507 = load ptr, ptr %46, align 8
  %508 = ptrtoint ptr %507 to i64
  %509 = ptrtoint ptr %45 to i64
  %510 = sub i64 %508, %509
  %511 = sdiv exact i64 %510, 12
  %512 = trunc i64 %511 to i32
  %513 = getelementptr inbounds i8, ptr %45, i64 1
  %514 = load i8, ptr %513, align 1
  %515 = zext i8 %514 to i32
  %516 = call i32 (ptr, ...) @printf(ptr noundef @.str.24, i32 noundef %512, i32 noundef %515)
  %517 = load ptr, ptr %46, align 8
  %518 = ptrtoint ptr %517 to i64
  %519 = ptrtoint ptr %45 to i64
  %520 = sub i64 %518, %519
  %521 = sdiv exact i64 %520, 12
  %522 = icmp ne i64 %521, 1
  br i1 %522, label %528, label %523

523:                                              ; preds = %499
  %524 = getelementptr inbounds i8, ptr %45, i64 1
  %525 = load i8, ptr %524, align 1
  %526 = zext i8 %525 to i32
  %527 = icmp ne i32 %526, 0
  br i1 %527, label %528, label %531

528:                                              ; preds = %523, %499
  %529 = load i32, ptr @fails, align 4
  %530 = add nsw i32 %529, 1
  store i32 %530, ptr @fails, align 4
  br label %531

531:                                              ; preds = %528, %523
  %532 = load i32, ptr @fails, align 4
  %533 = icmp ne i32 %532, 0
  %534 = zext i1 %533 to i64
  %535 = select i1 %533, i32 1, i32 0
  ret i32 %535
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

declare i32 @printf(ptr noundef, ...) #3

; Function Attrs: nounwind
declare i32 @sprintf(ptr noundef, ptr noundef, ...) #4

declare i32 @puts(ptr noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @held(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load ptr, ptr %4, align 8
  %7 = call i32 @strcmp(ptr noundef %5, ptr noundef %6) #5
  %8 = icmp ne i32 %7, 0
  br i1 %8, label %9, label %16

9:                                                ; preds = %2
  %10 = load ptr, ptr @stderr, align 8
  %11 = load ptr, ptr %3, align 8
  %12 = load ptr, ptr %4, align 8
  %13 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %10, ptr noundef @.str.25, ptr noundef %11, ptr noundef %12) #5
  %14 = load i32, ptr @fails, align 4
  %15 = add nsw i32 %14, 1
  store i32 %15, ptr @fails, align 4
  br label %16

16:                                               ; preds = %9, %2
  ret void
}

; Function Attrs: nounwind
declare i32 @strcmp(ptr noundef, ptr noundef) #4

; Function Attrs: nounwind
declare i32 @fprintf(ptr noundef, ptr noundef, ...) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.5"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
