; ModuleID = 'test/c/synth/expr-conversions.c'
source_filename = "test/c/synth/expr-conversions.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"uc + 10\00", align 1
@.str.2 = private unnamed_addr constant [7 x i8] c"sc * 2\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"us + 1\00", align 1
@.str.4 = private unnamed_addr constant [38 x i8] c"_Generic(uc + uc, int: 1, default: 0)\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"ll < u\00", align 1
@.str.6 = private unnamed_addr constant [10 x i8] c"(int)2.99\00", align 1
@.str.7 = private unnamed_addr constant [11 x i8] c"(int)-2.99\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"(unsigned)-1\00", align 1
@.str.10 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.11 = private unnamed_addr constant [23 x i8] c"(unsigned long long)ll\00", align 1
@.str.12 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.13 = private unnamed_addr constant [21 x i8] c"(double)(1ull << 53)\00", align 1
@.str.14 = private unnamed_addr constant [14 x i8] c"(int)(char)65\00", align 1
@.str.15 = private unnamed_addr constant [42 x i8] c"_Generic(1 + 1u, unsigned: 1, default: 0)\00", align 1
@.str.16 = private unnamed_addr constant [44 x i8] c"_Generic(1 + 1ll, long long: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  %3 = alloca i8, align 1
  %4 = alloca i16, align 2
  %5 = alloca i64, align 8
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i8 -6, ptr %2, align 1
  store i8 -6, ptr %3, align 1
  store i16 -1, ptr %4, align 2
  store i64 -1, ptr %5, align 8
  store i32 3, ptr %6, align 4
  %7 = load i8, ptr %2, align 1
  %8 = zext i8 %7 to i32
  %9 = add nsw i32 %8, 10
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %9)
  %11 = load i8, ptr %3, align 1
  %12 = sext i8 %11 to i32
  %13 = mul nsw i32 %12, 2
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %13)
  %15 = load i16, ptr %4, align 2
  %16 = zext i16 %15 to i32
  %17 = add nsw i32 %16, 1
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %17)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 1)
  %20 = load i64, ptr %5, align 8
  %21 = load i32, ptr %6, align 4
  %22 = zext i32 %21 to i64
  %23 = icmp slt i64 %20, %22
  %24 = zext i1 %23 to i32
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %24)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 2)
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef -2)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.8, ptr noundef @.str.9, i32 noundef -1)
  %29 = load i64, ptr %5, align 8
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str.10, ptr noundef @.str.11, i64 noundef %29)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.12, ptr noundef @.str.13, double noundef f0x4340000000000000)
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef 65)
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 1)
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
