; ModuleID = 'test/c/synth/lib-math-builtins.c'
source_filename = "test/c/synth/lib-math-builtins.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"log2(2.75)\00", align 1
@.str.2 = private unnamed_addr constant [21 x i8] c"__builtin_log2(2.75)\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"exp2(3.5)\00", align 1
@.str.4 = private unnamed_addr constant [20 x i8] c"__builtin_exp2(3.5)\00", align 1
@.str.5 = private unnamed_addr constant [30 x i8] c"(double)__builtin_log2f(8.0f)\00", align 1
@.str.6 = private unnamed_addr constant [30 x i8] c"(double)__builtin_exp2f(3.5f)\00", align 1
@.str.7 = private unnamed_addr constant [31 x i8] c"(double)__builtin_log2l(16.0L)\00", align 1
@.str.8 = private unnamed_addr constant [22 x i8] c"__builtin_trunc(-2.5)\00", align 1
@.str.9 = private unnamed_addr constant [21 x i8] c"__builtin_round(2.5)\00", align 1
@.str.10 = private unnamed_addr constant [20 x i8] c"__builtin_rint(2.5)\00", align 1
@.str.11 = private unnamed_addr constant [25 x i8] c"__builtin_nearbyint(3.5)\00", align 1
@.str.12 = private unnamed_addr constant [21 x i8] c"__builtin_cbrt(27.0)\00", align 1
@.str.13 = private unnamed_addr constant [26 x i8] c"__builtin_fmin(1.5, -2.0)\00", align 1
@.str.14 = private unnamed_addr constant [26 x i8] c"__builtin_fmax(1.5, -2.0)\00", align 1
@.str.15 = private unnamed_addr constant [26 x i8] c"__builtin_hypot(3.0, 4.0)\00", align 1
@.str.16 = private unnamed_addr constant [25 x i8] c"__builtin_fdim(5.0, 2.0)\00", align 1
@.str.17 = private unnamed_addr constant [29 x i8] c"__builtin_fma(2.0, 3.0, 1.0)\00", align 1
@.str.18 = private unnamed_addr constant [41 x i8] c"(double)__builtin_fmaf(2.0f, 3.0f, 0.5f)\00", align 1
@.str.19 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.20 = private unnamed_addr constant [22 x i8] c"__builtin_ilogb(40.0)\00", align 1
@.str.21 = private unnamed_addr constant [10 x i8] c"%s = %ld\0A\00", align 1
@.str.22 = private unnamed_addr constant [22 x i8] c"__builtin_lround(2.5)\00", align 1
@.str.23 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.24 = private unnamed_addr constant [23 x i8] c"__builtin_llrint(-3.5)\00", align 1
@.str.25 = private unnamed_addr constant [25 x i8] c"__builtin_scalbn(1.5, 3)\00", align 1
@.str.26 = private unnamed_addr constant [30 x i8] c"__builtin_remainder(7.0, 2.0)\00", align 1
@.str.27 = private unnamed_addr constant [21 x i8] c"__builtin_logb(40.0)\00", align 1
@.str.28 = private unnamed_addr constant [32 x i8] c"fmin(2.0, 3.0) + fmax(2.0, 3.0)\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, double noundef f0x3FF759D4F80CBA84)
  %2 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.2, double noundef f0x3FF759D4F80CBA84)
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.3, double noundef f0x4026A09E667F3BCD)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.4, double noundef f0x4026A09E667F3BCD)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.5, double noundef 3.000000e+00)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.6, double noundef f0x4026A09E60000000)
  %7 = tail call x86_fp80 @llvm.log2.f80(x86_fp80 1.600000e+01)
  %8 = fptrunc x86_fp80 %7 to double
  %9 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.7, double noundef %8)
  %10 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.8, double noundef -2.000000e+00)
  %11 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.9, double noundef 3.000000e+00)
  %12 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.10, double noundef 2.000000e+00)
  %13 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.11, double noundef 4.000000e+00)
  %14 = tail call double @cbrt(double noundef 2.700000e+01) #4
  %15 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.12, double noundef %14)
  %16 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.13, double noundef -2.000000e+00)
  %17 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.14, double noundef 1.500000e+00)
  %18 = tail call double @hypot(double noundef 3.000000e+00, double noundef 4.000000e+00) #4
  %19 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.15, double noundef %18)
  %20 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.16, double noundef 3.000000e+00)
  %21 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.17, double noundef 7.000000e+00)
  %22 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.18, double noundef 6.500000e+00)
  %23 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.19, ptr noundef nonnull @.str.20, i32 noundef 5)
  %24 = tail call i64 @llvm.lround.i64.f64(double 2.500000e+00)
  %25 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.21, ptr noundef nonnull @.str.22, i64 noundef %24)
  %26 = tail call i64 @llvm.llrint.i64.f64(double -3.500000e+00)
  %27 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, ptr noundef nonnull @.str.24, i64 noundef %26)
  %28 = tail call double @scalbn(double noundef 1.500000e+00, i32 noundef 3) #4
  %29 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.25, double noundef %28)
  %30 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.26, double noundef -1.000000e+00)
  %31 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.27, double noundef 5.000000e+00)
  %32 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.28, double noundef 5.000000e+00)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare x86_fp80 @llvm.log2.f80(x86_fp80) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare double @cbrt(double noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare double @hypot(double noundef, double noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.lround.i64.f64(double) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.llrint.i64.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare double @scalbn(double noundef, i32 noundef) local_unnamed_addr #3

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
