; ModuleID = 'test/c/synth/lex-float-constants.c'
source_filename = "test/c/synth/lex-float-constants.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"1.5\00", align 1
@.str.2 = private unnamed_addr constant [3 x i8] c".5\00", align 1
@.str.3 = private unnamed_addr constant [3 x i8] c"5.\00", align 1
@.str.4 = private unnamed_addr constant [4 x i8] c"1e3\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"2.5E-2\00", align 1
@.str.6 = private unnamed_addr constant [7 x i8] c"1.5e+2\00", align 1
@.str.7 = private unnamed_addr constant [14 x i8] c"(double)1.25f\00", align 1
@.str.8 = private unnamed_addr constant [14 x i8] c"(double)0.75F\00", align 1
@.str.9 = private unnamed_addr constant [14 x i8] c"(double)1.25L\00", align 1
@.str.10 = private unnamed_addr constant [6 x i8] c"0x1p4\00", align 1
@.str.11 = private unnamed_addr constant [8 x i8] c"0x1.8p1\00", align 1
@.str.12 = private unnamed_addr constant [8 x i8] c"0X.8P-1\00", align 1
@.str.13 = private unnamed_addr constant [6 x i8] c"0xAp0\00", align 1
@.str.14 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.15 = private unnamed_addr constant [37 x i8] c"_Generic(1.0f, float: 1, default: 0)\00", align 1
@.str.16 = private unnamed_addr constant [37 x i8] c"_Generic(1.0, double: 1, default: 0)\00", align 1
@.str.17 = private unnamed_addr constant [43 x i8] c"_Generic(1.0l, long double: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, double noundef 1.500000e+00)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, double noundef 5.000000e-01)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, double noundef 5.000000e+00)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, double noundef 1.000000e+03)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, double noundef 2.500000e-02)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, double noundef 1.500000e+02)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, double noundef 1.250000e+00)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, double noundef 7.500000e-01)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, double noundef 1.250000e+00)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, double noundef 1.600000e+01)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, double noundef 3.000000e+00)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, double noundef 2.500000e-01)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, double noundef 1.000000e+01)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.14, ptr noundef @.str.15, i32 noundef 1)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str.14, ptr noundef @.str.16, i32 noundef 1)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str.14, ptr noundef @.str.17, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
