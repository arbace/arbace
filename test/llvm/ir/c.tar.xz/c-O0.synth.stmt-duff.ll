; ModuleID = 'test/c/synth/stmt-duff.c'
source_filename = "test/c/synth/stmt-duff.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.a = private unnamed_addr constant [7 x i32] [i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"duff(a, 7)\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"duff(a, 4)\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"duff(a, 1)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [7 x i32], align 16
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.a, i64 28, i1 false)
  %3 = getelementptr inbounds [7 x i32], ptr %2, i64 0, i64 0
  %4 = call i32 @duff(ptr noundef %3, i32 noundef 7)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %4)
  %6 = getelementptr inbounds [7 x i32], ptr %2, i64 0, i64 0
  %7 = call i32 @duff(ptr noundef %6, i32 noundef 4)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %7)
  %9 = getelementptr inbounds [7 x i32], ptr %2, i64 0, i64 0
  %10 = call i32 @duff(ptr noundef %9, i32 noundef 1)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %10)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @duff(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  %7 = load i32, ptr %4, align 4
  %8 = add nsw i32 %7, 3
  %9 = sdiv i32 %8, 4
  store i32 %9, ptr %6, align 4
  %10 = load i32, ptr %4, align 4
  %11 = srem i32 %10, 4
  switch i32 %11, label %42 [
    i32 0, label %12
    i32 3, label %19
    i32 2, label %25
    i32 1, label %31
  ]

12:                                               ; preds = %2
  br label %13

13:                                               ; preds = %37, %12
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw i32, ptr %14, i32 1
  store ptr %15, ptr %3, align 8
  %16 = load i32, ptr %14, align 4
  %17 = load i32, ptr %5, align 4
  %18 = add nsw i32 %17, %16
  store i32 %18, ptr %5, align 4
  br label %19

19:                                               ; preds = %2, %13
  %20 = load ptr, ptr %3, align 8
  %21 = getelementptr inbounds nuw i32, ptr %20, i32 1
  store ptr %21, ptr %3, align 8
  %22 = load i32, ptr %20, align 4
  %23 = load i32, ptr %5, align 4
  %24 = add nsw i32 %23, %22
  store i32 %24, ptr %5, align 4
  br label %25

25:                                               ; preds = %2, %19
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw i32, ptr %26, i32 1
  store ptr %27, ptr %3, align 8
  %28 = load i32, ptr %26, align 4
  %29 = load i32, ptr %5, align 4
  %30 = add nsw i32 %29, %28
  store i32 %30, ptr %5, align 4
  br label %31

31:                                               ; preds = %2, %25
  %32 = load ptr, ptr %3, align 8
  %33 = getelementptr inbounds nuw i32, ptr %32, i32 1
  store ptr %33, ptr %3, align 8
  %34 = load i32, ptr %32, align 4
  %35 = load i32, ptr %5, align 4
  %36 = add nsw i32 %35, %34
  store i32 %36, ptr %5, align 4
  br label %37

37:                                               ; preds = %31
  %38 = load i32, ptr %6, align 4
  %39 = add nsw i32 %38, -1
  store i32 %39, ptr %6, align 4
  %40 = icmp sgt i32 %39, 0
  br i1 %40, label %13, label %41, !llvm.loop !6

41:                                               ; preds = %37
  br label %42

42:                                               ; preds = %41, %2
  %43 = load i32, ptr %5, align 4
  ret i32 %43
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
