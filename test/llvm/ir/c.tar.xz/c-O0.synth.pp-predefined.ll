; ModuleID = 'test/c/synth/pp-predefined.c'
source_filename = "test/c/synth/pp-predefined.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"__STDC__\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"%s = %ld\0A\00", align 1
@.str.3 = private unnamed_addr constant [17 x i8] c"__STDC_VERSION__\00", align 1
@.str.4 = private unnamed_addr constant [16 x i8] c"__STDC_HOSTED__\00", align 1
@.str.5 = private unnamed_addr constant [16 x i8] c"__STDC_UTF_16__\00", align 1
@.str.6 = private unnamed_addr constant [16 x i8] c"__STDC_UTF_32__\00", align 1
@.str.7 = private unnamed_addr constant [16 x i8] c"defined_check()\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"__LINE__\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 1)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i64 noundef 202311)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 1)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 1)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 1)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 1)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 20)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
