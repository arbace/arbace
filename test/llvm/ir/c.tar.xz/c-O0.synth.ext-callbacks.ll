; ModuleID = 'test/c/synth/ext-callbacks.c'
source_filename = "test/c/synth/ext-callbacks.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.a = private unnamed_addr constant [6 x i32] [i32 5, i32 3, i32 9, i32 1, i32 7, i32 2], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"a[0]\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"a[5]\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"(int)(hit - a)\00", align 1
@.str.4 = private unnamed_addr constant [13 x i8] c"ops[0](6, 3)\00", align 1
@ops = internal constant [3 x ptr] [ptr @add, ptr @sub, ptr @mul], align 16
@.str.5 = private unnamed_addr constant [13 x i8] c"ops[1](6, 3)\00", align 1
@.str.6 = private unnamed_addr constant [13 x i8] c"ops[2](6, 3)\00", align 1
@.str.7 = private unnamed_addr constant [16 x i8] c"(*ops[2])(2, 2)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [6 x i32], align 16
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.a, i64 24, i1 false)
  %5 = getelementptr inbounds [6 x i32], ptr %2, i64 0, i64 0
  call void @qsort(ptr noundef %5, i64 noundef 6, i64 noundef 4, ptr noundef @cmp)
  store i32 7, ptr %3, align 4
  %6 = getelementptr inbounds [6 x i32], ptr %2, i64 0, i64 0
  %7 = call ptr @bsearch(ptr noundef %3, ptr noundef %6, i64 noundef 6, i64 noundef 4, ptr noundef @cmp)
  store ptr %7, ptr %4, align 8
  %8 = getelementptr inbounds [6 x i32], ptr %2, i64 0, i64 0
  %9 = load i32, ptr %8, align 16
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %9)
  %11 = getelementptr inbounds [6 x i32], ptr %2, i64 0, i64 5
  %12 = load i32, ptr %11, align 4
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %12)
  %14 = load ptr, ptr %4, align 8
  %15 = getelementptr inbounds [6 x i32], ptr %2, i64 0, i64 0
  %16 = ptrtoint ptr %14 to i64
  %17 = ptrtoint ptr %15 to i64
  %18 = sub i64 %16, %17
  %19 = sdiv exact i64 %18, 4
  %20 = trunc i64 %19 to i32
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %20)
  %22 = load ptr, ptr @ops, align 16
  %23 = call i32 %22(i32 noundef 6, i32 noundef 3)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %23)
  %25 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @ops, i64 8), align 8
  %26 = call i32 %25(i32 noundef 6, i32 noundef 3)
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %26)
  %28 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @ops, i64 16), align 16
  %29 = call i32 %28(i32 noundef 6, i32 noundef 3)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %29)
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @ops, i64 16), align 16
  %32 = call i32 %31(i32 noundef 2, i32 noundef 2)
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %32)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare void @qsort(ptr noundef, i64 noundef, i64 noundef, ptr noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @cmp(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load i32, ptr %7, align 4
  store i32 %8, ptr %5, align 4
  %9 = load ptr, ptr %4, align 8
  %10 = load i32, ptr %9, align 4
  store i32 %10, ptr %6, align 4
  %11 = load i32, ptr %5, align 4
  %12 = load i32, ptr %6, align 4
  %13 = icmp sgt i32 %11, %12
  %14 = zext i1 %13 to i32
  %15 = load i32, ptr %5, align 4
  %16 = load i32, ptr %6, align 4
  %17 = icmp slt i32 %15, %16
  %18 = zext i1 %17 to i32
  %19 = sub nsw i32 %14, %18
  ret i32 %19
}

declare ptr @bsearch(ptr noundef, ptr noundef, i64 noundef, i64 noundef, ptr noundef) #2

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @add(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = add nsw i32 %5, %6
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @sub(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = sub nsw i32 %5, %6
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @mul(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = mul nsw i32 %5, %6
  ret i32 %7
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
