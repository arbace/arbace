; ModuleID = 'test/c/synth/expr-floating.c'
source_filename = "test/c/synth/expr-floating.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [12 x i8] c"%s = %.17g\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"a + b\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"%s = %.9g\0A\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"(double)f\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"a + b == 0.3\00", align 1
@.str.6 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"1.0 / 4\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"-z\00", align 1
@.str.9 = private unnamed_addr constant [16 x i8] c"1.0 / 3 > 0.333\00", align 1
@.str.10 = private unnamed_addr constant [31 x i8] c"1e308 * 10 > 1e308 ? 1.0 : 0.0\00", align 1
@.str.11 = private unnamed_addr constant [11 x i8] c"%s = %.3f\0A\00", align 1
@.str.12 = private unnamed_addr constant [17 x i8] c"2.0 * 1.5 - 0.25\00", align 1
@.str.13 = private unnamed_addr constant [17 x i8] c"(int)(7.0 / 2.0)\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, double noundef f0x3FD3333333333334)
  %2 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, ptr noundef nonnull @.str.3, double noundef f0x3FD5555560000000)
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.5, i32 noundef 0)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.6, ptr noundef nonnull @.str.7, double noundef 2.500000e-01)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.6, ptr noundef nonnull @.str.8, double noundef -0.000000e+00)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.9, i32 noundef 1)
  %7 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.6, ptr noundef nonnull @.str.10, double noundef 1.000000e+00)
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.11, ptr noundef nonnull @.str.12, double noundef 2.750000e+00)
  %9 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.13, i32 noundef 3)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
