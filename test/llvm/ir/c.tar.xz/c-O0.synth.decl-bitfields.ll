; ModuleID = 'test/c/synth/decl-bitfields.c'
source_filename = "test/c/synth/decl-bitfields.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.bf = type { i8, [3 x i8], i8, [3 x i8] }

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"b.u3\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"b.s3\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"b.flag\00", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"b.rest\00", align 1
@.str.5 = private unnamed_addr constant [38 x i8] c"_Generic(b.flag, bool: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.bf, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 0, i64 8, i1 false)
  %3 = load i8, ptr %2, align 4
  %4 = and i8 %3, -8
  %5 = or i8 %4, 1
  store i8 %5, ptr %2, align 4
  %6 = load i8, ptr %2, align 4
  %7 = and i8 %6, -57
  %8 = or i8 %7, 24
  store i8 %8, ptr %2, align 4
  %9 = load i8, ptr %2, align 4
  %10 = shl i8 %9, 2
  %11 = ashr i8 %10, 5
  %12 = sext i8 %11 to i32
  %13 = add nsw i32 %12, 1
  %14 = sub nsw i32 %13, 8
  %15 = trunc i32 %14 to i8
  %16 = load i8, ptr %2, align 4
  %17 = and i8 %15, 7
  %18 = shl i8 %17, 3
  %19 = and i8 %16, -57
  %20 = or i8 %19, %18
  store i8 %20, ptr %2, align 4
  %21 = shl i8 %17, 5
  %22 = ashr i8 %21, 5
  %23 = sext i8 %22 to i32
  %24 = load i8, ptr %2, align 4
  %25 = and i8 %24, -65
  %26 = or i8 %25, 64
  store i8 %26, ptr %2, align 4
  %27 = getelementptr inbounds nuw %struct.bf, ptr %2, i32 0, i32 2
  %28 = load i8, ptr %27, align 4
  %29 = and i8 %28, -32
  %30 = or i8 %29, 31
  store i8 %30, ptr %27, align 4
  %31 = getelementptr inbounds nuw %struct.bf, ptr %2, i32 0, i32 2
  %32 = load i8, ptr %31, align 4
  %33 = and i8 %32, 31
  %34 = zext i8 %33 to i32
  %35 = add i32 %34, 1
  %36 = trunc i32 %35 to i8
  %37 = load i8, ptr %31, align 4
  %38 = and i8 %36, 31
  %39 = and i8 %37, -32
  %40 = or i8 %39, %38
  store i8 %40, ptr %31, align 4
  %41 = zext i8 %38 to i32
  %42 = load i8, ptr %2, align 4
  %43 = and i8 %42, 7
  %44 = zext i8 %43 to i32
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %44)
  %46 = load i8, ptr %2, align 4
  %47 = shl i8 %46, 2
  %48 = ashr i8 %47, 5
  %49 = sext i8 %48 to i32
  %50 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %49)
  %51 = load i8, ptr %2, align 4
  %52 = lshr i8 %51, 6
  %53 = and i8 %52, 1
  %54 = trunc i8 %53 to i1
  %55 = zext i1 %54 to i32
  %56 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %55)
  %57 = getelementptr inbounds nuw %struct.bf, ptr %2, i32 0, i32 2
  %58 = load i8, ptr %57, align 4
  %59 = and i8 %58, 31
  %60 = zext i8 %59 to i32
  %61 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %60)
  %62 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 1)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
