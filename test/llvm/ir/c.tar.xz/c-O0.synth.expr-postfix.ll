; ModuleID = 'test/c/synth/expr-postfix.c'
source_filename = "test/c/synth/expr-postfix.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.pt = type { i32, i32 }

@__const.main.a = private unnamed_addr constant [4 x i32] [i32 10, i32 20, i32 30, i32 40], align 16
@__const.main.p = private unnamed_addr constant %struct.pt { i32 1, i32 2 }, align 4
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"a[1]\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"2[a]\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"add(3, 4)\00", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"none()\00", align 1
@.str.5 = private unnamed_addr constant [4 x i8] c"p.x\00", align 1
@.str.6 = private unnamed_addr constant [6 x i8] c"pp->y\00", align 1
@.str.7 = private unnamed_addr constant [5 x i8] c"post\00", align 1
@.str.8 = private unnamed_addr constant [6 x i8] c"postd\00", align 1
@.str.9 = private unnamed_addr constant [2 x i8] c"i\00", align 1
@.str.10 = private unnamed_addr constant [20 x i8] c"(int[]){7, 8, 9}[2]\00", align 1
@.str.11 = private unnamed_addr constant [22 x i8] c"(struct pt){.y = 6}.y\00", align 1
@.str.12 = private unnamed_addr constant [21 x i8] c"((struct pt *)&p)->x\00", align 1
@.str.13 = private unnamed_addr constant [11 x i8] c"(&a[0])[3]\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [4 x i32], align 16
  %3 = alloca %struct.pt, align 4
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca [3 x i32], align 4
  %9 = alloca %struct.pt, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.a, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @__const.main.p, i64 8, i1 false)
  store ptr %3, ptr %4, align 8
  store i32 5, ptr %5, align 4
  %10 = load i32, ptr %5, align 4
  %11 = add nsw i32 %10, 1
  store i32 %11, ptr %5, align 4
  store i32 %10, ptr %6, align 4
  %12 = load i32, ptr %5, align 4
  %13 = add nsw i32 %12, -1
  store i32 %13, ptr %5, align 4
  store i32 %12, ptr %7, align 4
  %14 = getelementptr inbounds [4 x i32], ptr %2, i64 0, i64 1
  %15 = load i32, ptr %14, align 4
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %15)
  %17 = getelementptr inbounds [4 x i32], ptr %2, i64 0, i64 2
  %18 = load i32, ptr %17, align 8
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %18)
  %20 = call i32 @add(i32 noundef 3, i32 noundef 4)
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %20)
  %22 = call i32 @none()
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %22)
  %24 = getelementptr inbounds nuw %struct.pt, ptr %3, i32 0, i32 0
  %25 = load i32, ptr %24, align 4
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %25)
  %27 = load ptr, ptr %4, align 8
  %28 = getelementptr inbounds nuw %struct.pt, ptr %27, i32 0, i32 1
  %29 = load i32, ptr %28, align 4
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %29)
  %31 = load i32, ptr %6, align 4
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %31)
  %33 = load i32, ptr %7, align 4
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %33)
  %35 = load i32, ptr %5, align 4
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %35)
  store i32 7, ptr %8, align 4
  %37 = getelementptr inbounds i32, ptr %8, i64 1
  store i32 8, ptr %37, align 4
  %38 = getelementptr inbounds i32, ptr %8, i64 2
  store i32 9, ptr %38, align 4
  %39 = getelementptr inbounds [3 x i32], ptr %8, i64 0, i64 2
  %40 = load i32, ptr %39, align 4
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %40)
  %42 = getelementptr inbounds nuw %struct.pt, ptr %9, i32 0, i32 0
  store i32 0, ptr %42, align 4
  %43 = getelementptr inbounds nuw %struct.pt, ptr %9, i32 0, i32 1
  store i32 6, ptr %43, align 4
  %44 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 6)
  %45 = getelementptr inbounds nuw %struct.pt, ptr %3, i32 0, i32 0
  %46 = load i32, ptr %45, align 4
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef %46)
  %48 = getelementptr inbounds [4 x i32], ptr %2, i64 0, i64 0
  %49 = getelementptr inbounds i32, ptr %48, i64 3
  %50 = load i32, ptr %49, align 4
  %51 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef %50)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @add(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = add nsw i32 %5, %6
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @none() #0 {
  ret i32 4
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
