; ModuleID = 'test/c/synth/expr-shift-relational.c'
source_filename = "test/c/synth/expr-shift-relational.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"1 << 10\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"1024 >> 3\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.4 = private unnamed_addr constant [8 x i8] c"u >> 31\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"u << 1\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"1ull << 63 >> 62\00", align 1
@.str.8 = private unnamed_addr constant [6 x i8] c"3 < 4\00", align 1
@.str.9 = private unnamed_addr constant [6 x i8] c"4 < 3\00", align 1
@.str.10 = private unnamed_addr constant [6 x i8] c"3 > 2\00", align 1
@.str.11 = private unnamed_addr constant [7 x i8] c"3 <= 3\00", align 1
@.str.12 = private unnamed_addr constant [7 x i8] c"3 >= 4\00", align 1
@.str.13 = private unnamed_addr constant [14 x i8] c"&a[0] < &a[2]\00", align 1
@.str.14 = private unnamed_addr constant [15 x i8] c"&a[2] >= &a[1]\00", align 1
@.str.15 = private unnamed_addr constant [7 x i8] c"1 == 1\00", align 1
@.str.16 = private unnamed_addr constant [7 x i8] c"1 != 1\00", align 1
@.str.17 = private unnamed_addr constant [19 x i8] c"(1 < 2) == (2 < 3)\00", align 1
@.str.18 = private unnamed_addr constant [8 x i8] c"-1 < 1u\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [3 x i32], align 4
  %3 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 -2147483648, ptr %3, align 4
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 1024)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 128)
  %6 = load i32, ptr %3, align 4
  %7 = lshr i32 %6, 31
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.4, i32 noundef %7)
  %9 = load i32, ptr %3, align 4
  %10 = shl i32 %9, 1
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.5, i32 noundef %10)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.7, i64 noundef 2)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 1)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 0)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 1)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 1)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 0)
  %18 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 0
  %19 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 2
  %20 = icmp ult ptr %18, %19
  %21 = zext i1 %20 to i32
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef %21)
  %23 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 2
  %24 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 1
  %25 = icmp uge ptr %23, %24
  %26 = zext i1 %25 to i32
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef %26)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 1)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef 0)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17, i32 noundef 1)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.18, i32 noundef 0)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
