; ModuleID = 'test/c/run/ptr-sub-narrow.c'
source_filename = "test/c/run/ptr-sub-narrow.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@a = internal unnamed_addr global [300 x i32] zeroinitializer, align 16
@.str = private unnamed_addr constant [13 x i8] c"%d %d %d %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"%d %d %d\0A\00", align 1
@.str.2 = private unnamed_addr constant [4 x i8] c"%d\0A\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local range(i32 0, 2) i32 @main() local_unnamed_addr #0 {
  br label %1

1:                                                ; preds = %8, %0
  %2 = phi i64 [ 0, %0 ], [ %14, %8 ]
  %3 = phi <4 x i32> [ <i32 0, i32 1, i32 2, i32 3>, %0 ], [ %15, %8 ]
  %4 = add <4 x i32> %3, splat (i32 4)
  %5 = getelementptr inbounds nuw [4 x i8], ptr @a, i64 %2
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store <4 x i32> %3, ptr %5, align 16, !tbaa !10
  store <4 x i32> %4, ptr %6, align 16, !tbaa !10
  %7 = icmp eq i64 %2, 288
  br i1 %7, label %16, label %8

8:                                                ; preds = %1
  %9 = add <4 x i32> %3, splat (i32 8)
  %10 = add <4 x i32> %3, splat (i32 12)
  %11 = getelementptr inbounds nuw [4 x i8], ptr @a, i64 %2
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 32
  %13 = getelementptr inbounds nuw i8, ptr %11, i64 48
  store <4 x i32> %9, ptr %12, align 16, !tbaa !10
  store <4 x i32> %10, ptr %13, align 16, !tbaa !10
  %14 = add nuw nsw i64 %2, 16
  %15 = add <4 x i32> %3, splat (i32 16)
  br label %1

16:                                               ; preds = %1
  store i32 296, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1184), align 16, !tbaa !10
  store i32 297, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1188), align 4, !tbaa !10
  store i32 298, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1192), align 8, !tbaa !10
  store i32 299, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1196), align 4, !tbaa !10
  %17 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1152), align 16, !tbaa !10
  %18 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1148), align 4, !tbaa !10
  %19 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1156), align 4, !tbaa !10
  %20 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1144), align 8, !tbaa !10
  %21 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i32 noundef %17, i32 noundef %18, i32 noundef %19, i32 noundef %20)
  %22 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 552), align 8, !tbaa !10
  %23 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 60), align 4, !tbaa !10
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1136), align 16, !tbaa !10
  %25 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i32 noundef %22, i32 noundef %23, i32 noundef %24)
  %26 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 0)
  %27 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1148), align 4, !tbaa !10
  %28 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %27)
  %29 = load <4 x i32>, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1144), align 8
  %30 = freeze <4 x i32> %29
  %31 = icmp ne <4 x i32> %30, <i32 286, i32 287, i32 288, i32 289>
  %32 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 552), align 8
  %33 = freeze i32 %32
  %34 = icmp ne i32 %33, 138
  %35 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 60), align 4
  %36 = freeze i32 %35
  %37 = icmp ne i32 %36, 15
  %38 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 1136), align 16
  %39 = icmp ne i32 %38, 284
  %40 = bitcast <4 x i1> %31 to i4
  %41 = icmp ne i4 %40, 0
  %42 = or i1 %41, %34
  %43 = or i1 %42, %37
  %44 = select i1 %43, i1 true, i1 %39
  %45 = zext i1 %44 to i32
  ret i32 %45
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!7, !7, i64 0}
