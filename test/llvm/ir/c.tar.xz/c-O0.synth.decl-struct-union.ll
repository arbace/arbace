; ModuleID = 'test/c/synth/decl-struct-union.c'
source_filename = "test/c/synth/decl-struct-union.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.outer = type { i32, %struct.anon, %union.anon, %struct.inner }
%struct.anon = type { i32, i32 }
%union.anon = type { i32 }
%struct.inner = type { i32 }
%struct.node = type { i32, ptr }
%union.u = type { i32 }
%struct.flex = type { i32, [0 x i32] }

@__const.main.n2 = private unnamed_addr constant { i32, [4 x i8], ptr } { i32 2, [4 x i8] zeroinitializer, ptr null }, align 8
@__const.main.o = private unnamed_addr constant %struct.outer { i32 1, %struct.anon { i32 2, i32 3 }, %union.anon { i32 4 }, %struct.inner { i32 5 } }, align 4
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"n1.next->v\00", align 1
@.str.2 = private unnamed_addr constant [31 x i8] c"o.a + o.b + o.c + o.d + o.in.f\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"un.i\00", align 1
@.str.4 = private unnamed_addr constant [12 x i8] c"fx->data[2]\00", align 1
@.str.5 = private unnamed_addr constant [6 x i8] c"in2.f\00", align 1
@.str.6 = private unnamed_addr constant [35 x i8] c"sizeof(struct flex) == sizeof(int)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.node, align 8
  %3 = alloca %struct.node, align 8
  %4 = alloca %struct.outer, align 4
  %5 = alloca %union.u, align 4
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca %struct.inner, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 @__const.main.n2, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %struct.node, ptr %3, i32 0, i32 0
  store i32 1, ptr %9, align 8
  %10 = getelementptr i8, ptr %3, i64 4
  call void @llvm.memset.p0.i64(ptr align 4 %10, i8 0, i64 4, i1 false)
  %11 = getelementptr inbounds nuw %struct.node, ptr %3, i32 0, i32 1
  store ptr %2, ptr %11, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 4 @__const.main.o, i64 20, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %5, i8 0, i64 4, i1 false)
  %12 = getelementptr inbounds [4 x i8], ptr %5, i64 0, i64 0
  store i8 0, ptr %12, align 4
  %13 = call ptr @malloc(i64 noundef 16) #5
  store ptr %13, ptr %6, align 8
  %14 = load ptr, ptr %6, align 8
  %15 = getelementptr inbounds nuw %struct.flex, ptr %14, i32 0, i32 0
  store i32 3, ptr %15, align 4
  store i32 0, ptr %7, align 4
  br label %16

16:                                               ; preds = %28, %0
  %17 = load i32, ptr %7, align 4
  %18 = icmp slt i32 %17, 3
  br i1 %18, label %19, label %31

19:                                               ; preds = %16
  %20 = load i32, ptr %7, align 4
  %21 = load i32, ptr %7, align 4
  %22 = mul nsw i32 %20, %21
  %23 = load ptr, ptr %6, align 8
  %24 = getelementptr inbounds nuw %struct.flex, ptr %23, i32 0, i32 1
  %25 = load i32, ptr %7, align 4
  %26 = sext i32 %25 to i64
  %27 = getelementptr inbounds [0 x i32], ptr %24, i64 0, i64 %26
  store i32 %22, ptr %27, align 4
  br label %28

28:                                               ; preds = %19
  %29 = load i32, ptr %7, align 4
  %30 = add nsw i32 %29, 1
  store i32 %30, ptr %7, align 4
  br label %16, !llvm.loop !6

31:                                               ; preds = %16
  %32 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %8, ptr align 4 %32, i64 4, i1 false)
  %33 = getelementptr inbounds nuw %struct.node, ptr %3, i32 0, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr inbounds nuw %struct.node, ptr %34, i32 0, i32 0
  %36 = load i32, ptr %35, align 8
  %37 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %36)
  %38 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 0
  %39 = load i32, ptr %38, align 4
  %40 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 1
  %41 = getelementptr inbounds nuw %struct.anon, ptr %40, i32 0, i32 0
  %42 = load i32, ptr %41, align 4
  %43 = add nsw i32 %39, %42
  %44 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 1
  %45 = getelementptr inbounds nuw %struct.anon, ptr %44, i32 0, i32 1
  %46 = load i32, ptr %45, align 4
  %47 = add nsw i32 %43, %46
  %48 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 2
  %49 = load i32, ptr %48, align 4
  %50 = add nsw i32 %47, %49
  %51 = getelementptr inbounds nuw %struct.outer, ptr %4, i32 0, i32 3
  %52 = getelementptr inbounds nuw %struct.inner, ptr %51, i32 0, i32 0
  %53 = load i32, ptr %52, align 4
  %54 = add nsw i32 %50, %53
  %55 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %54)
  %56 = load i32, ptr %5, align 4
  %57 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %56)
  %58 = load ptr, ptr %6, align 8
  %59 = getelementptr inbounds nuw %struct.flex, ptr %58, i32 0, i32 1
  %60 = getelementptr inbounds [0 x i32], ptr %59, i64 0, i64 2
  %61 = load i32, ptr %60, align 4
  %62 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %61)
  %63 = getelementptr inbounds nuw %struct.inner, ptr %8, i32 0, i32 0
  %64 = load i32, ptr %63, align 4
  %65 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %64)
  %66 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 1)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: allocsize(0)
declare ptr @malloc(i64 noundef) #3

declare i32 @printf(ptr noundef, ...) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { allocsize(0) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
