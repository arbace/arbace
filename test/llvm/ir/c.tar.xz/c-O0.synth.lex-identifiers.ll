; ModuleID = 'test/c/synth/lex-identifiers.c'
source_filename = "test/c/synth/lex-identifiers.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [23 x i8] c"_x1 + __y + a_b_c + Z9\00", align 1
@_x1 = internal global i32 1, align 4
@__y = internal global i32 2, align 4
@a_b_c = internal global i32 3, align 4
@Z9 = internal global i32 4, align 4
@.str.2 = private unnamed_addr constant [6 x i8] c"\C3\A9t\C3\A9\00", align 1
@"\C3\A9t\C3\A9" = internal global i32 5, align 4
@.str.3 = private unnamed_addr constant [10 x i8] c"caf\\u00e9\00", align 1
@"caf\C3\A9" = internal global i32 6, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i32, ptr @_x1, align 4
  %3 = load i32, ptr @__y, align 4
  %4 = add nsw i32 %2, %3
  %5 = load i32, ptr @a_b_c, align 4
  %6 = add nsw i32 %4, %5
  %7 = load i32, ptr @Z9, align 4
  %8 = add nsw i32 %6, %7
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %8)
  %10 = load i32, ptr @"\C3\A9t\C3\A9", align 4
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %10)
  %12 = load i32, ptr @"caf\C3\A9", align 4
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %12)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
