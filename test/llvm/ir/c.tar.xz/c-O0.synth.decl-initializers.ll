; ModuleID = 'test/c/synth/decl-initializers.c'
source_filename = "test/c/synth/decl-initializers.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.pt = type { i32, i32 }
%struct.line = type { %struct.pt, %struct.pt, [2 x i32] }
%union.iu = type { double }

@__const.main.a = private unnamed_addr constant [5 x i32] [i32 1, i32 2, i32 0, i32 0, i32 0], align 16
@__const.main.d = private unnamed_addr constant [6 x i32] [i32 0, i32 1, i32 2, i32 0, i32 4, i32 0], align 16
@__const.main.p = private unnamed_addr constant %struct.pt { i32 1, i32 2 }, align 4
@__const.main.l = private unnamed_addr constant %struct.line { %struct.pt { i32 3, i32 4 }, %struct.pt { i32 0, i32 7 }, [2 x i32] [i32 0, i32 9] }, align 4
@__const.main.l2 = private unnamed_addr constant %struct.line { %struct.pt { i32 1, i32 2 }, %struct.pt { i32 3, i32 4 }, [2 x i32] [i32 5, i32 6] }, align 4
@__const.main.str = private unnamed_addr constant [4 x i8] c"abc\00", align 1
@__const.main.exact = private unnamed_addr constant [3 x i8] c"xyz", align 1
@__const.main.u1 = private unnamed_addr constant { i32, [4 x i8] } { i32 7, [4 x i8] zeroinitializer }, align 8
@__const.main.u2 = private unnamed_addr constant %union.iu { double 2.500000e+00 }, align 8
@__const.main.over = private unnamed_addr constant [3 x i32] [i32 2, i32 0, i32 0], align 4
@__const.main.m = private unnamed_addr constant [2 x [2 x i32]] [[2 x i32] [i32 1, i32 2], [2 x i32] [i32 3, i32 0]], align 16
@__const.main.ps = private unnamed_addr constant [3 x %struct.pt] [%struct.pt { i32 1, i32 2 }, %struct.pt zeroinitializer, %struct.pt { i32 0, i32 5 }], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"a[1] + a[4]\00", align 1
@.str.3 = private unnamed_addr constant [19 x i8] c"d[1] + d[2] + d[4]\00", align 1
@.str.4 = private unnamed_addr constant [15 x i8] c"p.x * 10 + p.y\00", align 1
@.str.5 = private unnamed_addr constant [33 x i8] c"l.a.y + l.b.y + l.tag[1] + l.b.x\00", align 1
@.str.6 = private unnamed_addr constant [10 x i8] c"l2.tag[1]\00", align 1
@.str.7 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.8 = private unnamed_addr constant [11 x i8] c"sizeof str\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"exact[2]\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"u1.i\00", align 1
@.str.11 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.12 = private unnamed_addr constant [5 x i8] c"u2.d\00", align 1
@.str.13 = private unnamed_addr constant [8 x i8] c"over[0]\00", align 1
@.str.14 = private unnamed_addr constant [18 x i8] c"m[1][0] + m[1][1]\00", align 1
@.str.15 = private unnamed_addr constant [25 x i8] c"sizeof ps / sizeof ps[0]\00", align 1
@.str.16 = private unnamed_addr constant [8 x i8] c"ps[2].y\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [5 x i32], align 16
  %4 = alloca [6 x i32], align 16
  %5 = alloca %struct.pt, align 4
  %6 = alloca %struct.line, align 4
  %7 = alloca %struct.line, align 4
  %8 = alloca [4 x i8], align 1
  %9 = alloca [3 x i8], align 1
  %10 = alloca %union.iu, align 8
  %11 = alloca %union.iu, align 8
  %12 = alloca [3 x i32], align 4
  %13 = alloca [2 x [2 x i32]], align 16
  %14 = alloca [3 x %struct.pt], align 16
  store i32 0, ptr %1, align 4
  store i32 5, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @__const.main.a, i64 20, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %4, ptr align 16 @__const.main.d, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 @__const.main.p, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @__const.main.l, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 @__const.main.l2, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %8, ptr align 1 @__const.main.str, i64 4, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %9, ptr align 1 @__const.main.exact, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 @__const.main.u1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 8 @__const.main.u2, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %12, ptr align 4 @__const.main.over, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %13, ptr align 16 @__const.main.m, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %14, ptr align 16 @__const.main.ps, i64 24, i1 false)
  %15 = load i32, ptr %2, align 4
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %15)
  %17 = getelementptr inbounds [5 x i32], ptr %3, i64 0, i64 1
  %18 = load i32, ptr %17, align 4
  %19 = getelementptr inbounds [5 x i32], ptr %3, i64 0, i64 4
  %20 = load i32, ptr %19, align 16
  %21 = add nsw i32 %18, %20
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %21)
  %23 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 1
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 2
  %26 = load i32, ptr %25, align 8
  %27 = add nsw i32 %24, %26
  %28 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 4
  %29 = load i32, ptr %28, align 16
  %30 = add nsw i32 %27, %29
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %30)
  %32 = getelementptr inbounds nuw %struct.pt, ptr %5, i32 0, i32 0
  %33 = load i32, ptr %32, align 4
  %34 = mul nsw i32 %33, 10
  %35 = getelementptr inbounds nuw %struct.pt, ptr %5, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = add nsw i32 %34, %36
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %37)
  %39 = getelementptr inbounds nuw %struct.line, ptr %6, i32 0, i32 0
  %40 = getelementptr inbounds nuw %struct.pt, ptr %39, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr inbounds nuw %struct.line, ptr %6, i32 0, i32 1
  %43 = getelementptr inbounds nuw %struct.pt, ptr %42, i32 0, i32 1
  %44 = load i32, ptr %43, align 4
  %45 = add nsw i32 %41, %44
  %46 = getelementptr inbounds nuw %struct.line, ptr %6, i32 0, i32 2
  %47 = getelementptr inbounds [2 x i32], ptr %46, i64 0, i64 1
  %48 = load i32, ptr %47, align 4
  %49 = add nsw i32 %45, %48
  %50 = getelementptr inbounds nuw %struct.line, ptr %6, i32 0, i32 1
  %51 = getelementptr inbounds nuw %struct.pt, ptr %50, i32 0, i32 0
  %52 = load i32, ptr %51, align 4
  %53 = add nsw i32 %49, %52
  %54 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %53)
  %55 = getelementptr inbounds nuw %struct.line, ptr %7, i32 0, i32 2
  %56 = getelementptr inbounds [2 x i32], ptr %55, i64 0, i64 1
  %57 = load i32, ptr %56, align 4
  %58 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %57)
  %59 = call i32 (ptr, ...) @printf(ptr noundef @.str.7, ptr noundef @.str.8, i64 noundef 4)
  %60 = getelementptr inbounds [3 x i8], ptr %9, i64 0, i64 2
  %61 = load i8, ptr %60, align 1
  %62 = sext i8 %61 to i32
  %63 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %62)
  %64 = load i32, ptr %10, align 8
  %65 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %64)
  %66 = load double, ptr %11, align 8
  %67 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.12, double noundef %66)
  %68 = getelementptr inbounds [3 x i32], ptr %12, i64 0, i64 0
  %69 = load i32, ptr %68, align 4
  %70 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef %69)
  %71 = getelementptr inbounds [2 x [2 x i32]], ptr %13, i64 0, i64 1
  %72 = getelementptr inbounds [2 x i32], ptr %71, i64 0, i64 0
  %73 = load i32, ptr %72, align 8
  %74 = getelementptr inbounds [2 x [2 x i32]], ptr %13, i64 0, i64 1
  %75 = getelementptr inbounds [2 x i32], ptr %74, i64 0, i64 1
  %76 = load i32, ptr %75, align 4
  %77 = add nsw i32 %73, %76
  %78 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef %77)
  %79 = call i32 (ptr, ...) @printf(ptr noundef @.str.7, ptr noundef @.str.15, i64 noundef 3)
  %80 = getelementptr inbounds [3 x %struct.pt], ptr %14, i64 0, i64 2
  %81 = getelementptr inbounds nuw %struct.pt, ptr %80, i32 0, i32 1
  %82 = load i32, ptr %81, align 4
  %83 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef %82)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
