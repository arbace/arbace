; ModuleID = 'test/c/run/ptr-sub-narrow.c'
source_filename = "test/c/run/ptr-sub-narrow.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@a = internal global [300 x i32] zeroinitializer, align 16
@.str = private unnamed_addr constant [13 x i8] c"%d %d %d %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"%d %d %d\0A\00", align 1
@.str.2 = private unnamed_addr constant [4 x i8] c"%d\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  %5 = alloca i16, align 2
  %6 = alloca i8, align 1
  %7 = alloca i32, align 4
  %8 = alloca i8, align 1
  %9 = alloca i16, align 2
  %10 = alloca i64, align 8
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca ptr, align 8
  %14 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  br label %15

15:                                               ; preds = %23, %0
  %16 = load i32, ptr %2, align 4
  %17 = icmp slt i32 %16, 300
  br i1 %17, label %18, label %26

18:                                               ; preds = %15
  %19 = load i32, ptr %2, align 4
  %20 = load i32, ptr %2, align 4
  %21 = sext i32 %20 to i64
  %22 = getelementptr inbounds [300 x i32], ptr @a, i64 0, i64 %21
  store i32 %19, ptr %22, align 4
  br label %23

23:                                               ; preds = %18
  %24 = load i32, ptr %2, align 4
  %25 = add nsw i32 %24, 1
  store i32 %25, ptr %2, align 4
  br label %15, !llvm.loop !6

26:                                               ; preds = %15
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 1160), ptr %3, align 8
  store i8 2, ptr %4, align 1
  store i16 3, ptr %5, align 2
  store i8 1, ptr %6, align 1
  store i32 4, ptr %7, align 4
  store i8 -128, ptr %8, align 1
  store i16 -5, ptr %9, align 2
  store i64 6, ptr %10, align 8
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 40), ptr %11, align 8
  %27 = load ptr, ptr %3, align 8
  %28 = load i8, ptr %4, align 1
  %29 = zext i8 %28 to i32
  %30 = sext i32 %29 to i64
  %31 = sub i64 0, %30
  %32 = getelementptr inbounds i32, ptr %27, i64 %31
  %33 = load i32, ptr %32, align 4
  %34 = load ptr, ptr %3, align 8
  %35 = load i16, ptr %5, align 2
  %36 = zext i16 %35 to i32
  %37 = sext i32 %36 to i64
  %38 = sub i64 0, %37
  %39 = getelementptr inbounds i32, ptr %34, i64 %38
  %40 = load i32, ptr %39, align 4
  %41 = load ptr, ptr %3, align 8
  %42 = load i8, ptr %6, align 1
  %43 = icmp ne i8 %42, 0
  %44 = zext i1 %43 to i32
  %45 = sext i32 %44 to i64
  %46 = sub i64 0, %45
  %47 = getelementptr inbounds i32, ptr %41, i64 %46
  %48 = load i32, ptr %47, align 4
  %49 = load ptr, ptr %3, align 8
  %50 = load i32, ptr %7, align 4
  %51 = zext i32 %50 to i64
  %52 = sub i64 0, %51
  %53 = getelementptr inbounds i32, ptr %49, i64 %52
  %54 = load i32, ptr %53, align 4
  %55 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %33, i32 noundef %40, i32 noundef %48, i32 noundef %54)
  %56 = load ptr, ptr %11, align 8
  %57 = load i8, ptr %8, align 1
  %58 = sext i8 %57 to i32
  %59 = sext i32 %58 to i64
  %60 = sub i64 0, %59
  %61 = getelementptr inbounds i32, ptr %56, i64 %60
  %62 = load i32, ptr %61, align 4
  %63 = load ptr, ptr %11, align 8
  %64 = load i16, ptr %9, align 2
  %65 = sext i16 %64 to i32
  %66 = sext i32 %65 to i64
  %67 = sub i64 0, %66
  %68 = getelementptr inbounds i32, ptr %63, i64 %67
  %69 = load i32, ptr %68, align 4
  %70 = load ptr, ptr %3, align 8
  %71 = load i64, ptr %10, align 8
  %72 = sub i64 0, %71
  %73 = getelementptr inbounds i32, ptr %70, i64 %72
  %74 = load i32, ptr %73, align 4
  %75 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef %62, i32 noundef %69, i32 noundef %74)
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), ptr %12, align 8
  %76 = load ptr, ptr %12, align 8
  %77 = getelementptr inbounds i8, ptr %76, i64 -4
  %78 = ptrtoint ptr %77 to i64
  %79 = sub i64 %78, ptrtoint (ptr @a to i64)
  %80 = sdiv exact i64 %79, 4
  %81 = trunc i64 %80 to i32
  %82 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %81)
  %83 = load ptr, ptr %3, align 8
  store ptr %83, ptr %13, align 8
  %84 = load i8, ptr %4, align 1
  %85 = zext i8 %84 to i32
  %86 = load ptr, ptr %13, align 8
  %87 = sext i32 %85 to i64
  %88 = sub i64 0, %87
  %89 = getelementptr inbounds i32, ptr %86, i64 %88
  store ptr %89, ptr %13, align 8
  %90 = load i8, ptr %6, align 1
  %91 = icmp ne i8 %90, 0
  %92 = zext i1 %91 to i32
  %93 = load ptr, ptr %13, align 8
  %94 = sext i32 %92 to i64
  %95 = sub i64 0, %94
  %96 = getelementptr inbounds i32, ptr %93, i64 %95
  store ptr %96, ptr %13, align 8
  %97 = load ptr, ptr %13, align 8
  %98 = load i32, ptr %97, align 4
  %99 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %98)
  %100 = load ptr, ptr %3, align 8
  %101 = load i8, ptr %4, align 1
  %102 = zext i8 %101 to i32
  %103 = sext i32 %102 to i64
  %104 = sub i64 0, %103
  %105 = getelementptr inbounds i32, ptr %100, i64 %104
  %106 = load i32, ptr %105, align 4
  %107 = icmp eq i32 %106, 288
  br i1 %107, label %108, label %172

108:                                              ; preds = %26
  %109 = load ptr, ptr %3, align 8
  %110 = load i16, ptr %5, align 2
  %111 = zext i16 %110 to i32
  %112 = sext i32 %111 to i64
  %113 = sub i64 0, %112
  %114 = getelementptr inbounds i32, ptr %109, i64 %113
  %115 = load i32, ptr %114, align 4
  %116 = icmp eq i32 %115, 287
  br i1 %116, label %117, label %172

117:                                              ; preds = %108
  %118 = load ptr, ptr %3, align 8
  %119 = load i8, ptr %6, align 1
  %120 = icmp ne i8 %119, 0
  %121 = zext i1 %120 to i32
  %122 = sext i32 %121 to i64
  %123 = sub i64 0, %122
  %124 = getelementptr inbounds i32, ptr %118, i64 %123
  %125 = load i32, ptr %124, align 4
  %126 = icmp eq i32 %125, 289
  br i1 %126, label %127, label %172

127:                                              ; preds = %117
  %128 = load ptr, ptr %3, align 8
  %129 = load i32, ptr %7, align 4
  %130 = zext i32 %129 to i64
  %131 = sub i64 0, %130
  %132 = getelementptr inbounds i32, ptr %128, i64 %131
  %133 = load i32, ptr %132, align 4
  %134 = icmp eq i32 %133, 286
  br i1 %134, label %135, label %172

135:                                              ; preds = %127
  %136 = load ptr, ptr %11, align 8
  %137 = load i8, ptr %8, align 1
  %138 = sext i8 %137 to i32
  %139 = sext i32 %138 to i64
  %140 = sub i64 0, %139
  %141 = getelementptr inbounds i32, ptr %136, i64 %140
  %142 = load i32, ptr %141, align 4
  %143 = icmp eq i32 %142, 138
  br i1 %143, label %144, label %172

144:                                              ; preds = %135
  %145 = load ptr, ptr %11, align 8
  %146 = load i16, ptr %9, align 2
  %147 = sext i16 %146 to i32
  %148 = sext i32 %147 to i64
  %149 = sub i64 0, %148
  %150 = getelementptr inbounds i32, ptr %145, i64 %149
  %151 = load i32, ptr %150, align 4
  %152 = icmp eq i32 %151, 15
  br i1 %152, label %153, label %172

153:                                              ; preds = %144
  %154 = load ptr, ptr %3, align 8
  %155 = load i64, ptr %10, align 8
  %156 = sub i64 0, %155
  %157 = getelementptr inbounds i32, ptr %154, i64 %156
  %158 = load i32, ptr %157, align 4
  %159 = icmp eq i32 %158, 284
  br i1 %159, label %160, label %172

160:                                              ; preds = %153
  %161 = load ptr, ptr %12, align 8
  %162 = getelementptr inbounds i8, ptr %161, i64 -4
  %163 = ptrtoint ptr %162 to i64
  %164 = sub i64 %163, ptrtoint (ptr @a to i64)
  %165 = sdiv exact i64 %164, 4
  %166 = trunc i64 %165 to i32
  %167 = icmp eq i32 %166, 0
  br i1 %167, label %168, label %172

168:                                              ; preds = %160
  %169 = load ptr, ptr %13, align 8
  %170 = load i32, ptr %169, align 4
  %171 = icmp eq i32 %170, 287
  br label %172

172:                                              ; preds = %168, %160, %153, %144, %135, %127, %117, %108, %26
  %173 = phi i1 [ false, %160 ], [ false, %153 ], [ false, %144 ], [ false, %135 ], [ false, %127 ], [ false, %117 ], [ false, %108 ], [ false, %26 ], [ %171, %168 ]
  %174 = zext i1 %173 to i32
  store i32 %174, ptr %14, align 4
  %175 = load i32, ptr %14, align 4
  %176 = icmp ne i32 %175, 0
  %177 = zext i1 %176 to i64
  %178 = select i1 %176, i32 0, i32 1
  ret i32 %178
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.5"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
