; ModuleID = 'test/c/run/ptr-sub-narrow.c'
source_filename = "test/c/run/ptr-sub-narrow.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@a = internal global [300 x i32] zeroinitializer, align 16
@.str = private unnamed_addr constant [13 x i8] c"%d %d %d %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"%d %d %d\0A\00", align 1
@.str.2 = private unnamed_addr constant [4 x i8] c"%d\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  %5 = alloca i16, align 2
  %6 = alloca i8, align 1
  %7 = alloca i32, align 4
  %8 = alloca i8, align 1
  %9 = alloca i16, align 2
  %10 = alloca i64, align 8
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  br label %14

14:                                               ; preds = %22, %0
  %15 = load i32, ptr %2, align 4
  %16 = icmp slt i32 %15, 300
  br i1 %16, label %17, label %25

17:                                               ; preds = %14
  %18 = load i32, ptr %2, align 4
  %19 = load i32, ptr %2, align 4
  %20 = sext i32 %19 to i64
  %21 = getelementptr inbounds [300 x i32], ptr @a, i64 0, i64 %20
  store i32 %18, ptr %21, align 4
  br label %22

22:                                               ; preds = %17
  %23 = load i32, ptr %2, align 4
  %24 = add nsw i32 %23, 1
  store i32 %24, ptr %2, align 4
  br label %14, !llvm.loop !6

25:                                               ; preds = %14
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 1160), ptr %3, align 8
  store i8 2, ptr %4, align 1
  store i16 3, ptr %5, align 2
  store i8 1, ptr %6, align 1
  store i32 4, ptr %7, align 4
  store i8 -128, ptr %8, align 1
  store i16 -5, ptr %9, align 2
  store i64 6, ptr %10, align 8
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 40), ptr %11, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = load i8, ptr %4, align 1
  %28 = zext i8 %27 to i32
  %29 = sext i32 %28 to i64
  %30 = sub i64 0, %29
  %31 = getelementptr inbounds i32, ptr %26, i64 %30
  %32 = load i32, ptr %31, align 4
  %33 = load ptr, ptr %3, align 8
  %34 = load i16, ptr %5, align 2
  %35 = zext i16 %34 to i32
  %36 = sext i32 %35 to i64
  %37 = sub i64 0, %36
  %38 = getelementptr inbounds i32, ptr %33, i64 %37
  %39 = load i32, ptr %38, align 4
  %40 = load ptr, ptr %3, align 8
  %41 = load i8, ptr %6, align 1
  %42 = icmp ne i8 %41, 0
  %43 = zext i1 %42 to i32
  %44 = sext i32 %43 to i64
  %45 = sub i64 0, %44
  %46 = getelementptr inbounds i32, ptr %40, i64 %45
  %47 = load i32, ptr %46, align 4
  %48 = load ptr, ptr %3, align 8
  %49 = load i32, ptr %7, align 4
  %50 = zext i32 %49 to i64
  %51 = sub i64 0, %50
  %52 = getelementptr inbounds i32, ptr %48, i64 %51
  %53 = load i32, ptr %52, align 4
  %54 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %32, i32 noundef %39, i32 noundef %47, i32 noundef %53)
  %55 = load ptr, ptr %11, align 8
  %56 = load i8, ptr %8, align 1
  %57 = sext i8 %56 to i32
  %58 = sext i32 %57 to i64
  %59 = sub i64 0, %58
  %60 = getelementptr inbounds i32, ptr %55, i64 %59
  %61 = load i32, ptr %60, align 4
  %62 = load ptr, ptr %11, align 8
  %63 = load i16, ptr %9, align 2
  %64 = sext i16 %63 to i32
  %65 = sext i32 %64 to i64
  %66 = sub i64 0, %65
  %67 = getelementptr inbounds i32, ptr %62, i64 %66
  %68 = load i32, ptr %67, align 4
  %69 = load ptr, ptr %3, align 8
  %70 = load i64, ptr %10, align 8
  %71 = sub i64 0, %70
  %72 = getelementptr inbounds i32, ptr %69, i64 %71
  %73 = load i32, ptr %72, align 4
  %74 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef %61, i32 noundef %68, i32 noundef %73)
  store ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), ptr %12, align 8
  %75 = load ptr, ptr %12, align 8
  %76 = getelementptr inbounds i8, ptr %75, i64 -4
  %77 = ptrtoint ptr %76 to i64
  %78 = sub i64 %77, ptrtoint (ptr @a to i64)
  %79 = sdiv exact i64 %78, 4
  %80 = trunc i64 %79 to i32
  %81 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %80)
  %82 = load ptr, ptr %3, align 8
  store ptr %82, ptr %13, align 8
  %83 = load i8, ptr %4, align 1
  %84 = zext i8 %83 to i32
  %85 = load ptr, ptr %13, align 8
  %86 = sext i32 %84 to i64
  %87 = sub i64 0, %86
  %88 = getelementptr inbounds i32, ptr %85, i64 %87
  store ptr %88, ptr %13, align 8
  %89 = load i8, ptr %6, align 1
  %90 = icmp ne i8 %89, 0
  %91 = zext i1 %90 to i32
  %92 = load ptr, ptr %13, align 8
  %93 = sext i32 %91 to i64
  %94 = sub i64 0, %93
  %95 = getelementptr inbounds i32, ptr %92, i64 %94
  store ptr %95, ptr %13, align 8
  %96 = load ptr, ptr %13, align 8
  %97 = load i32, ptr %96, align 4
  %98 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef %97)
  %99 = load ptr, ptr %3, align 8
  %100 = load i16, ptr %5, align 2
  %101 = zext i16 %100 to i32
  %102 = sext i32 %101 to i64
  %103 = sub i64 0, %102
  %104 = getelementptr inbounds i32, ptr %99, i64 %103
  %105 = load i32, ptr %104, align 4
  %106 = icmp eq i32 %105, 287
  br i1 %106, label %107, label %116

107:                                              ; preds = %25
  %108 = load ptr, ptr %11, align 8
  %109 = load i8, ptr %8, align 1
  %110 = sext i8 %109 to i32
  %111 = sext i32 %110 to i64
  %112 = sub i64 0, %111
  %113 = getelementptr inbounds i32, ptr %108, i64 %112
  %114 = load i32, ptr %113, align 4
  %115 = icmp eq i32 %114, 138
  br label %116

116:                                              ; preds = %107, %25
  %117 = phi i1 [ false, %25 ], [ %115, %107 ]
  %118 = zext i1 %117 to i64
  %119 = select i1 %117, i32 0, i32 1
  ret i32 %119
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
