; ModuleID = 'test/cpp/samples/coroutine.cpp'
source_filename = "test/cpp/samples/coroutine.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.Gen = type { %"struct.std::__n4861::coroutine_handle" }
%"struct.std::__n4861::coroutine_handle" = type { ptr }
%"struct.std::__n4861::suspend_always" = type { i8 }
%"struct.Gen::promise_type" = type { i32 }
%"struct.std::__n4861::coroutine_handle.0" = type { ptr }

$_ZN3Gen12promise_type17get_return_objectEv = comdat any

$_ZN3Gen12promise_type15initial_suspendEv = comdat any

$_ZNKSt7__n486114suspend_always11await_readyEv = comdat any

$_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv = comdat any

$_ZNKSt7__n486114suspend_always12await_resumeEv = comdat any

$_ZN3Gen12promise_type11yield_valueEi = comdat any

$_ZN3Gen12promise_type11return_voidEv = comdat any

$_ZN3Gen12promise_type13final_suspendEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_ = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev = comdat any

$_ZNSt7__n486116coroutine_handleIvE12from_addressEPv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv = comdat any

$_ZNSt7__n486116coroutine_handleIvEC2Ev = comdat any

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define dso_local ptr @_Z5counti(i32 noundef %0) #0 personality ptr @__gxx_personality_v0 {
  %2 = alloca %struct.Gen, align 8
  %3 = alloca i32, align 4, !coro.outside.frame !6
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca %"struct.std::__n4861::suspend_always", align 1
  %7 = alloca %"struct.std::__n4861::suspend_always", align 1
  %8 = alloca %"struct.std::__n4861::suspend_always", align 1
  store i32 %0, ptr %3, align 4
  br i1 true, label %11, label %9

9:                                                ; preds = %1
  %10 = phi ptr [ null, %1 ]
  br label %15

11:                                               ; preds = %1
  %12 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 32) #6
  br label %13

13:                                               ; preds = %11
  %14 = phi ptr [ %12, %11 ]
  br label %15

15:                                               ; preds = %9, %13
  %16 = phi ptr [ %10, %9 ], [ %14, %13 ]
  store ptr @_Z5counti.resume, ptr %16, align 8
  %17 = select i1 true, ptr @_Z5counti.destroy, ptr @_Z5counti.cleanup
  %18 = getelementptr inbounds i8, ptr %16, i64 8
  store ptr %17, ptr %18, align 8
  br label %19

19:                                               ; preds = %15
  %20 = getelementptr inbounds i8, ptr %16, i64 20
  %21 = getelementptr inbounds i8, ptr %16, i64 29
  %22 = getelementptr inbounds i8, ptr %16, i64 24
  %23 = getelementptr inbounds i8, ptr %16, i64 30
  %24 = getelementptr inbounds i8, ptr %16, i64 31
  %25 = getelementptr inbounds i8, ptr %16, i64 16
  br label %26

26:                                               ; preds = %19
  %27 = load i32, ptr %3, align 4
  store i32 %27, ptr %20, align 4
  %28 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %25, i32 0, i32 0
  %29 = load i32, ptr %20, align 4
  store i32 %29, ptr %28, align 4
  %30 = invoke ptr @_ZN3Gen12promise_type17get_return_objectEv(ptr noundef nonnull align 4 dereferenceable(4) %25)
          to label %31 unwind label %45

31:                                               ; preds = %26
  %32 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %33 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %32, i32 0, i32 0
  store ptr %30, ptr %33, align 8
  call void @_ZN3Gen12promise_type15initial_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %25)
  br label %34

34:                                               ; preds = %31
  %35 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %21) #7
  br i1 %35, label %49, label %36

36:                                               ; preds = %34
  %37 = getelementptr inbounds i8, ptr %16, i64 28
  store i2 0, ptr %37, align 1
  br label %38

38:                                               ; preds = %36
  call void @_Z5counti.__await_suspend_wrapper__init(ptr %21, ptr %16) #7
  br label %39

39:                                               ; preds = %38
  br label %40

40:                                               ; preds = %39
  br label %41

41:                                               ; preds = %40
  switch i8 -1, label %111 [
    i8 0, label %49
    i8 1, label %42
  ]

42:                                               ; preds = %41
  br label %43

43:                                               ; preds = %42
  %44 = phi i32 [ 2, %42 ]
  br label %52

45:                                               ; preds = %26
  %46 = landingpad { ptr, i32 }
          cleanup
  %47 = extractvalue { ptr, i32 } %46, 0
  store ptr %47, ptr %4, align 8
  %48 = extractvalue { ptr, i32 } %46, 1
  store i32 %48, ptr %5, align 4
  br label %117

49:                                               ; preds = %41, %34
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %21) #7
  br label %50

50:                                               ; preds = %49
  %51 = phi i32 [ 0, %49 ]
  br label %52

52:                                               ; preds = %50, %43
  %53 = phi i32 [ %51, %50 ], [ %44, %43 ]
  switch i32 %53, label %126 [
    i32 0, label %54
    i32 2, label %107
  ]

54:                                               ; preds = %52
  store i32 0, ptr %22, align 4
  br label %55

55:                                               ; preds = %84, %54
  %56 = load i32, ptr %22, align 4
  %57 = load i32, ptr %20, align 4
  %58 = icmp slt i32 %56, %57
  br i1 %58, label %62, label %59

59:                                               ; preds = %55
  br label %60

60:                                               ; preds = %59
  %61 = phi i32 [ 4, %59 ]
  br label %87

62:                                               ; preds = %55
  %63 = load i32, ptr %22, align 4
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %25, i32 noundef %63)
  br label %64

64:                                               ; preds = %62
  %65 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %23) #7
  br i1 %65, label %75, label %66

66:                                               ; preds = %64
  %67 = getelementptr inbounds i8, ptr %16, i64 28
  store i2 1, ptr %67, align 1
  br label %68

68:                                               ; preds = %66
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %23, ptr %16) #7
  br label %69

69:                                               ; preds = %68
  br label %70

70:                                               ; preds = %69
  br label %71

71:                                               ; preds = %70
  switch i8 -1, label %111 [
    i8 0, label %75
    i8 1, label %72
  ]

72:                                               ; preds = %71
  br label %73

73:                                               ; preds = %72
  %74 = phi i32 [ 2, %72 ]
  br label %78

75:                                               ; preds = %71, %64
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %23) #7
  br label %76

76:                                               ; preds = %75
  %77 = phi i32 [ 0, %75 ]
  br label %78

78:                                               ; preds = %76, %73
  %79 = phi i32 [ %77, %76 ], [ %74, %73 ]
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %83, label %81

81:                                               ; preds = %78
  %82 = phi i32 [ %79, %78 ]
  br label %87

83:                                               ; preds = %78
  br label %84

84:                                               ; preds = %83
  %85 = load i32, ptr %22, align 4
  %86 = add nsw i32 %85, 1
  store i32 %86, ptr %22, align 4
  br label %55, !llvm.loop !7

87:                                               ; preds = %81, %60
  %88 = phi i32 [ %82, %81 ], [ %61, %60 ]
  switch i32 %88, label %126 [
    i32 4, label %89
    i32 2, label %107
  ]

89:                                               ; preds = %87
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %25)
  br label %90

90:                                               ; preds = %89
  br label %91

91:                                               ; preds = %90
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %25) #7
  %92 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %24) #7
  br i1 %92, label %101, label %93

93:                                               ; preds = %91
  store ptr null, ptr %16, align 8
  br label %94

94:                                               ; preds = %93
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %24, ptr %16) #7
  br label %95

95:                                               ; preds = %94
  br label %96

96:                                               ; preds = %95
  br label %97

97:                                               ; preds = %96
  switch i8 -1, label %111 [
    i8 0, label %101
    i8 1, label %98
  ]

98:                                               ; preds = %97
  br label %99

99:                                               ; preds = %98
  %100 = phi i32 [ 2, %98 ]
  br label %104

101:                                              ; preds = %97, %91
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %24) #7
  br label %102

102:                                              ; preds = %101
  %103 = phi i32 [ 0, %101 ]
  br label %104

104:                                              ; preds = %102, %99
  %105 = phi i32 [ %103, %102 ], [ %100, %99 ]
  switch i32 %105, label %126 [
    i32 0, label %106
    i32 2, label %107
  ]

106:                                              ; preds = %104
  br label %107

107:                                              ; preds = %106, %104, %87, %52
  %108 = icmp ne ptr %16, null
  br i1 %108, label %109, label %110

109:                                              ; preds = %107
  call void @_ZdlPvm(ptr noundef %16, i64 noundef 32) #7
  br label %110

110:                                              ; preds = %107, %109
  br label %111

111:                                              ; preds = %110, %97, %71, %41
  br label %112

112:                                              ; preds = %111
  br label %113

113:                                              ; preds = %112
  %114 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %115 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %114, i32 0, i32 0
  %116 = load ptr, ptr %115, align 8
  ret ptr %116

117:                                              ; preds = %45
  %118 = icmp ne ptr %16, null
  br i1 %118, label %119, label %120

119:                                              ; preds = %117
  call void @_ZdlPvm(ptr noundef %16, i64 noundef 32) #7
  br label %120

120:                                              ; preds = %117, %119
  br label %121

121:                                              ; preds = %120
  %122 = load ptr, ptr %4, align 8
  %123 = load i32, ptr %5, align 4
  %124 = insertvalue { ptr, i32 } poison, ptr %122, 0
  %125 = insertvalue { ptr, i32 } %124, i32 %123, 1
  resume { ptr, i32 } %125

126:                                              ; preds = %104, %87, %52
  unreachable
}

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znwm(i64 noundef) #1

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZN3Gen12promise_type17get_return_objectEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #0 comdat align 2 {
  %2 = alloca %struct.Gen, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %6 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_(ptr noundef nonnull align 4 dereferenceable(4) %4)
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %5, i32 0, i32 0
  store ptr %6, ptr %7, align 8
  %8 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %9 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %8, i32 0, i32 0
  %10 = load ptr, ptr %9, align 8
  ret ptr %10
}

declare i32 @__gxx_personality_v0(...)

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type15initial_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret i1 false
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__init(ptr noundef nonnull %0, ptr noundef %1) #3 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0
  store ptr %9, ptr %10, align 8
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  store ptr %11, ptr %12, align 8
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  %14 = load ptr, ptr %13, align 8
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr %1) #2 comdat align 2 {
  %3 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %4 = alloca ptr, align 8
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %3, i32 0, i32 0
  store ptr %1, ptr %5, align 8
  store ptr %0, ptr %4, align 8
  %6 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %0) #2 comdat align 2 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  call void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0
  store ptr %4, ptr %5, align 8
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0
  %7 = load ptr, ptr %6, align 8
  ret ptr %7
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call noundef ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv(ptr noundef nonnull align 8 dereferenceable(8) %4) #7
  %6 = call ptr @_ZNSt7__n486116coroutine_handleIvE12from_addressEPv(ptr noundef %5) #7
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0
  store ptr %6, ptr %7, align 8
  %8 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0
  %9 = load ptr, ptr %8, align 8
  ret ptr %9
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %0, i32 noundef %1) #2 comdat align 2 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %5 = load ptr, ptr %3, align 8
  %6 = load i32, ptr %4, align 4
  %7 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %5, i32 0, i32 0
  store i32 %6, ptr %7, align 4
  ret void
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__yield(ptr noundef nonnull %0, ptr noundef %1) #3 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0
  store ptr %9, ptr %10, align 8
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  store ptr %11, ptr %12, align 8
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  %14 = load ptr, ptr %13, align 8
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__final(ptr noundef nonnull %0, ptr noundef %1) #3 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0
  store ptr %9, ptr %10, align 8
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  store ptr %11, ptr %12, align 8
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0
  %14 = load ptr, ptr %13, align 8
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7
  ret void
}

; Function Attrs: nobuiltin nounwind
declare void @_ZdlPvm(ptr noundef, i64 noundef) #4

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #5 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.Gen, align 8
  %3 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %4 = call ptr @_Z5counti(i32 noundef 3)
  %5 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %5, i32 0, i32 0
  store ptr %4, ptr %6, align 8
  store i32 0, ptr %3, align 4
  br label %7

7:                                                ; preds = %22, %0
  %8 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %9 = call noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %8) #7
  %10 = xor i1 %9, true
  br i1 %10, label %11, label %23

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  call void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv(ptr noundef nonnull align 8 dereferenceable(8) %12)
  %13 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %14 = call noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %13) #7
  br i1 %14, label %22, label %15

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  %17 = call noundef nonnull align 4 dereferenceable(4) ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv(ptr noundef nonnull align 8 dereferenceable(8) %16)
  %18 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %17, i32 0, i32 0
  %19 = load i32, ptr %18, align 4
  %20 = load i32, ptr %3, align 4
  %21 = add nsw i32 %20, %19
  store i32 %21, ptr %3, align 4
  br label %22

22:                                               ; preds = %15, %11
  br label %7, !llvm.loop !9

23:                                               ; preds = %7
  %24 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0
  call void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv(ptr noundef nonnull align 8 dereferenceable(8) %24)
  %25 = load i32, ptr %3, align 4
  ret i32 %25
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = icmp eq ptr %6, null
  ret i1 %7
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds { ptr, ptr }, ptr %5, i32 0, i32 0
  %7 = load ptr, ptr %6, align 8
  call void %7(ptr %5)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef nonnull align 4 dereferenceable(4) ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %4, i32 0, i32 0
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i32 16
  store ptr %7, ptr %3, align 8
  %8 = load ptr, ptr %3, align 8
  ret ptr %8
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds { ptr, ptr }, ptr %5, i32 0, i32 1
  %7 = load ptr, ptr %6, align 8
  call void %7(ptr %5)
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  call void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7
  %4 = load ptr, ptr %3, align 8, !nonnull !6, !align !10
  %5 = getelementptr inbounds i8, ptr %4, i32 -16
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0
  store ptr %5, ptr %6, align 8
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0
  %8 = load ptr, ptr %7, align 8
  ret ptr %8
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %0) unnamed_addr #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0
  store ptr null, ptr %4, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIvE12from_addressEPv(ptr noundef %0) #2 comdat align 2 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  call void @_ZNSt7__n486116coroutine_handleIvEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0
  store ptr %4, ptr %5, align 8
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0
  %7 = load ptr, ptr %6, align 8
  ret ptr %7
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8
  ret ptr %5
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNSt7__n486116coroutine_handleIvEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %0) unnamed_addr #2 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %3, i32 0, i32 0
  store ptr null, ptr %4, align 8
  ret void
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.resume(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4, !coro.outside.frame !6
  %5 = alloca %struct.Gen, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 20
  %7 = getelementptr inbounds i8, ptr %0, i64 29
  %8 = getelementptr inbounds i8, ptr %0, i64 24
  %9 = getelementptr inbounds i8, ptr %0, i64 30
  %10 = getelementptr inbounds i8, ptr %0, i64 31
  %11 = getelementptr inbounds i8, ptr %0, i64 16
  br label %12

12:                                               ; preds = %1
  %13 = getelementptr inbounds i8, ptr %0, i64 28
  %14 = load i2, ptr %13, align 1
  switch i2 %14, label %88 [
    i2 0, label %15
    i2 1, label %42
  ]

15:                                               ; preds = %12
  br label %16

16:                                               ; preds = %15
  br label %17

17:                                               ; preds = %16
  switch i8 0, label %85 [
    i8 0, label %21
    i8 1, label %18
  ]

18:                                               ; preds = %17
  br label %19

19:                                               ; preds = %18
  %20 = phi i32 [ 2, %18 ]
  br label %24

21:                                               ; preds = %17
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %7) #7
  br label %22

22:                                               ; preds = %21
  %23 = phi i32 [ 0, %21 ]
  br label %24

24:                                               ; preds = %22, %19
  %25 = phi i32 [ %23, %22 ], [ %20, %19 ]
  switch i32 %25, label %87 [
    i32 0, label %26
    i32 2, label %81
  ]

26:                                               ; preds = %24
  store i32 0, ptr %8, align 4
  br label %27

27:                                               ; preds = %58, %26
  %28 = load i32, ptr %8, align 4
  %29 = load i32, ptr %6, align 4
  %30 = icmp slt i32 %28, %29
  br i1 %30, label %34, label %31

31:                                               ; preds = %27
  br label %32

32:                                               ; preds = %31
  %33 = phi i32 [ 4, %31 ]
  br label %61

34:                                               ; preds = %27
  %35 = load i32, ptr %8, align 4
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %11, i32 noundef %35)
  br label %36

36:                                               ; preds = %34
  %37 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br i1 %37, label %49, label %38

38:                                               ; preds = %36
  %39 = getelementptr inbounds i8, ptr %0, i64 28
  store i2 1, ptr %39, align 1
  br label %40

40:                                               ; preds = %38
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %9, ptr %0) #7
  br label %41

41:                                               ; preds = %40
  br label %43

42:                                               ; preds = %12
  br label %43

43:                                               ; preds = %42, %41
  %44 = phi i8 [ -1, %41 ], [ 0, %42 ]
  br label %45

45:                                               ; preds = %43
  switch i8 %44, label %85 [
    i8 0, label %49
    i8 1, label %46
  ]

46:                                               ; preds = %45
  br label %47

47:                                               ; preds = %46
  %48 = phi i32 [ 2, %46 ]
  br label %52

49:                                               ; preds = %45, %36
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br label %50

50:                                               ; preds = %49
  %51 = phi i32 [ 0, %49 ]
  br label %52

52:                                               ; preds = %50, %47
  %53 = phi i32 [ %51, %50 ], [ %48, %47 ]
  %54 = icmp eq i32 %53, 0
  br i1 %54, label %57, label %55

55:                                               ; preds = %52
  %56 = phi i32 [ %53, %52 ]
  br label %61

57:                                               ; preds = %52
  br label %58

58:                                               ; preds = %57
  %59 = load i32, ptr %8, align 4
  %60 = add nsw i32 %59, 1
  store i32 %60, ptr %8, align 4
  br label %27, !llvm.loop !11

61:                                               ; preds = %55, %32
  %62 = phi i32 [ %56, %55 ], [ %33, %32 ]
  switch i32 %62, label %87 [
    i32 4, label %63
    i32 2, label %81
  ]

63:                                               ; preds = %61
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %11)
  br label %64

64:                                               ; preds = %63
  br label %65

65:                                               ; preds = %64
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %11) #7
  %66 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br i1 %66, label %75, label %67

67:                                               ; preds = %65
  store ptr null, ptr %0, align 8
  br label %68

68:                                               ; preds = %67
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %10, ptr %0) #7
  br label %69

69:                                               ; preds = %68
  br label %70

70:                                               ; preds = %69
  br label %71

71:                                               ; preds = %70
  switch i8 -1, label %85 [
    i8 0, label %75
    i8 1, label %72
  ]

72:                                               ; preds = %71
  br label %73

73:                                               ; preds = %72
  %74 = phi i32 [ 2, %72 ]
  br label %78

75:                                               ; preds = %71, %65
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br label %76

76:                                               ; preds = %75
  %77 = phi i32 [ 0, %75 ]
  br label %78

78:                                               ; preds = %76, %73
  %79 = phi i32 [ %77, %76 ], [ %74, %73 ]
  switch i32 %79, label %87 [
    i32 0, label %80
    i32 2, label %81
  ]

80:                                               ; preds = %78
  br label %81

81:                                               ; preds = %80, %78, %61, %24
  %82 = icmp ne ptr %0, null
  br i1 %82, label %83, label %84

83:                                               ; preds = %81
  call void @_ZdlPvm(ptr noundef %0, i64 noundef 32) #7
  br label %84

84:                                               ; preds = %83, %81
  br label %85

85:                                               ; preds = %84, %71, %45, %17
  br label %86

86:                                               ; preds = %85
  ret void

87:                                               ; preds = %78, %61, %24
  unreachable

88:                                               ; preds = %12
  unreachable
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.destroy(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4, !coro.outside.frame !6
  %5 = alloca %struct.Gen, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 20
  %7 = getelementptr inbounds i8, ptr %0, i64 29
  %8 = getelementptr inbounds i8, ptr %0, i64 24
  %9 = getelementptr inbounds i8, ptr %0, i64 30
  %10 = getelementptr inbounds i8, ptr %0, i64 31
  %11 = getelementptr inbounds i8, ptr %0, i64 16
  br label %12

12:                                               ; preds = %1
  %13 = getelementptr inbounds i8, ptr %0, i64 28
  %14 = load i2, ptr %13, align 1
  %15 = load ptr, ptr %0, align 8
  %16 = icmp eq ptr %15, null
  br i1 %16, label %73, label %17

17:                                               ; preds = %12
  switch i2 %14, label %93 [
    i2 0, label %18
    i2 1, label %45
  ]

18:                                               ; preds = %17
  br label %19

19:                                               ; preds = %18
  br label %20

20:                                               ; preds = %19
  switch i8 1, label %90 [
    i8 0, label %24
    i8 1, label %21
  ]

21:                                               ; preds = %20
  br label %22

22:                                               ; preds = %21
  %23 = phi i32 [ 2, %21 ]
  br label %27

24:                                               ; preds = %20
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %7) #7
  br label %25

25:                                               ; preds = %24
  %26 = phi i32 [ 0, %24 ]
  br label %27

27:                                               ; preds = %25, %22
  %28 = phi i32 [ %26, %25 ], [ %23, %22 ]
  switch i32 %28, label %92 [
    i32 0, label %29
    i32 2, label %86
  ]

29:                                               ; preds = %27
  store i32 0, ptr %8, align 4
  br label %30

30:                                               ; preds = %61, %29
  %31 = load i32, ptr %8, align 4
  %32 = load i32, ptr %6, align 4
  %33 = icmp slt i32 %31, %32
  br i1 %33, label %37, label %34

34:                                               ; preds = %30
  br label %35

35:                                               ; preds = %34
  %36 = phi i32 [ 4, %34 ]
  br label %64

37:                                               ; preds = %30
  %38 = load i32, ptr %8, align 4
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %11, i32 noundef %38)
  br label %39

39:                                               ; preds = %37
  %40 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br i1 %40, label %52, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds i8, ptr %0, i64 28
  store i2 1, ptr %42, align 1
  br label %43

43:                                               ; preds = %41
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %9, ptr %0) #7
  br label %44

44:                                               ; preds = %43
  br label %46

45:                                               ; preds = %17
  br label %46

46:                                               ; preds = %45, %44
  %47 = phi i8 [ -1, %44 ], [ 1, %45 ]
  br label %48

48:                                               ; preds = %46
  switch i8 %47, label %90 [
    i8 0, label %52
    i8 1, label %49
  ]

49:                                               ; preds = %48
  br label %50

50:                                               ; preds = %49
  %51 = phi i32 [ 2, %49 ]
  br label %55

52:                                               ; preds = %48, %39
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br label %53

53:                                               ; preds = %52
  %54 = phi i32 [ 0, %52 ]
  br label %55

55:                                               ; preds = %53, %50
  %56 = phi i32 [ %54, %53 ], [ %51, %50 ]
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %60, label %58

58:                                               ; preds = %55
  %59 = phi i32 [ %56, %55 ]
  br label %64

60:                                               ; preds = %55
  br label %61

61:                                               ; preds = %60
  %62 = load i32, ptr %8, align 4
  %63 = add nsw i32 %62, 1
  store i32 %63, ptr %8, align 4
  br label %30, !llvm.loop !12

64:                                               ; preds = %58, %35
  %65 = phi i32 [ %59, %58 ], [ %36, %35 ]
  switch i32 %65, label %92 [
    i32 4, label %66
    i32 2, label %86
  ]

66:                                               ; preds = %64
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %11)
  br label %67

67:                                               ; preds = %66
  br label %68

68:                                               ; preds = %67
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %11) #7
  %69 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br i1 %69, label %80, label %70

70:                                               ; preds = %68
  store ptr null, ptr %0, align 8
  br label %71

71:                                               ; preds = %70
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %10, ptr %0) #7
  br label %72

72:                                               ; preds = %71
  br label %74

73:                                               ; preds = %12
  br label %74

74:                                               ; preds = %73, %72
  %75 = phi i8 [ -1, %72 ], [ 1, %73 ]
  br label %76

76:                                               ; preds = %74
  switch i8 %75, label %90 [
    i8 0, label %80
    i8 1, label %77
  ]

77:                                               ; preds = %76
  br label %78

78:                                               ; preds = %77
  %79 = phi i32 [ 2, %77 ]
  br label %83

80:                                               ; preds = %76, %68
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br label %81

81:                                               ; preds = %80
  %82 = phi i32 [ 0, %80 ]
  br label %83

83:                                               ; preds = %81, %78
  %84 = phi i32 [ %82, %81 ], [ %79, %78 ]
  switch i32 %84, label %92 [
    i32 0, label %85
    i32 2, label %86
  ]

85:                                               ; preds = %83
  br label %86

86:                                               ; preds = %85, %83, %64, %27
  %87 = icmp ne ptr %0, null
  br i1 %87, label %88, label %89

88:                                               ; preds = %86
  call void @_ZdlPvm(ptr noundef %0, i64 noundef 32) #7
  br label %89

89:                                               ; preds = %88, %86
  br label %90

90:                                               ; preds = %89, %76, %48, %20
  br label %91

91:                                               ; preds = %90
  ret void

92:                                               ; preds = %83, %64, %27
  unreachable

93:                                               ; preds = %17
  unreachable
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.cleanup(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4, !coro.outside.frame !6
  %5 = alloca %struct.Gen, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 20
  %7 = getelementptr inbounds i8, ptr %0, i64 29
  %8 = getelementptr inbounds i8, ptr %0, i64 24
  %9 = getelementptr inbounds i8, ptr %0, i64 30
  %10 = getelementptr inbounds i8, ptr %0, i64 31
  %11 = getelementptr inbounds i8, ptr %0, i64 16
  br label %12

12:                                               ; preds = %1
  %13 = getelementptr inbounds i8, ptr %0, i64 28
  %14 = load i2, ptr %13, align 1
  %15 = load ptr, ptr %0, align 8
  %16 = icmp eq ptr %15, null
  br i1 %16, label %73, label %17

17:                                               ; preds = %12
  switch i2 %14, label %93 [
    i2 0, label %18
    i2 1, label %45
  ]

18:                                               ; preds = %17
  br label %19

19:                                               ; preds = %18
  br label %20

20:                                               ; preds = %19
  switch i8 1, label %90 [
    i8 0, label %24
    i8 1, label %21
  ]

21:                                               ; preds = %20
  br label %22

22:                                               ; preds = %21
  %23 = phi i32 [ 2, %21 ]
  br label %27

24:                                               ; preds = %20
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %7) #7
  br label %25

25:                                               ; preds = %24
  %26 = phi i32 [ 0, %24 ]
  br label %27

27:                                               ; preds = %25, %22
  %28 = phi i32 [ %26, %25 ], [ %23, %22 ]
  switch i32 %28, label %92 [
    i32 0, label %29
    i32 2, label %86
  ]

29:                                               ; preds = %27
  store i32 0, ptr %8, align 4
  br label %30

30:                                               ; preds = %61, %29
  %31 = load i32, ptr %8, align 4
  %32 = load i32, ptr %6, align 4
  %33 = icmp slt i32 %31, %32
  br i1 %33, label %37, label %34

34:                                               ; preds = %30
  br label %35

35:                                               ; preds = %34
  %36 = phi i32 [ 4, %34 ]
  br label %64

37:                                               ; preds = %30
  %38 = load i32, ptr %8, align 4
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %11, i32 noundef %38)
  br label %39

39:                                               ; preds = %37
  %40 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br i1 %40, label %52, label %41

41:                                               ; preds = %39
  %42 = getelementptr inbounds i8, ptr %0, i64 28
  store i2 1, ptr %42, align 1
  br label %43

43:                                               ; preds = %41
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %9, ptr %0) #7
  br label %44

44:                                               ; preds = %43
  br label %46

45:                                               ; preds = %17
  br label %46

46:                                               ; preds = %45, %44
  %47 = phi i8 [ -1, %44 ], [ 1, %45 ]
  br label %48

48:                                               ; preds = %46
  switch i8 %47, label %90 [
    i8 0, label %52
    i8 1, label %49
  ]

49:                                               ; preds = %48
  br label %50

50:                                               ; preds = %49
  %51 = phi i32 [ 2, %49 ]
  br label %55

52:                                               ; preds = %48, %39
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %9) #7
  br label %53

53:                                               ; preds = %52
  %54 = phi i32 [ 0, %52 ]
  br label %55

55:                                               ; preds = %53, %50
  %56 = phi i32 [ %54, %53 ], [ %51, %50 ]
  %57 = icmp eq i32 %56, 0
  br i1 %57, label %60, label %58

58:                                               ; preds = %55
  %59 = phi i32 [ %56, %55 ]
  br label %64

60:                                               ; preds = %55
  br label %61

61:                                               ; preds = %60
  %62 = load i32, ptr %8, align 4
  %63 = add nsw i32 %62, 1
  store i32 %63, ptr %8, align 4
  br label %30, !llvm.loop !13

64:                                               ; preds = %58, %35
  %65 = phi i32 [ %59, %58 ], [ %36, %35 ]
  switch i32 %65, label %92 [
    i32 4, label %66
    i32 2, label %86
  ]

66:                                               ; preds = %64
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %11)
  br label %67

67:                                               ; preds = %66
  br label %68

68:                                               ; preds = %67
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %11) #7
  %69 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br i1 %69, label %80, label %70

70:                                               ; preds = %68
  store ptr null, ptr %0, align 8
  br label %71

71:                                               ; preds = %70
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %10, ptr %0) #7
  br label %72

72:                                               ; preds = %71
  br label %74

73:                                               ; preds = %12
  br label %74

74:                                               ; preds = %73, %72
  %75 = phi i8 [ -1, %72 ], [ 1, %73 ]
  br label %76

76:                                               ; preds = %74
  switch i8 %75, label %90 [
    i8 0, label %80
    i8 1, label %77
  ]

77:                                               ; preds = %76
  br label %78

78:                                               ; preds = %77
  %79 = phi i32 [ 2, %77 ]
  br label %83

80:                                               ; preds = %76, %68
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7
  br label %81

81:                                               ; preds = %80
  %82 = phi i32 [ 0, %80 ]
  br label %83

83:                                               ; preds = %81, %78
  %84 = phi i32 [ %82, %81 ], [ %79, %78 ]
  switch i32 %84, label %92 [
    i32 0, label %85
    i32 2, label %86
  ]

85:                                               ; preds = %83
  br label %86

86:                                               ; preds = %85, %83, %64, %27
  %87 = icmp ne ptr null, null
  br i1 %87, label %88, label %89

88:                                               ; preds = %86
  call void @_ZdlPvm(ptr noundef null, i64 noundef 32) #7
  br label %89

89:                                               ; preds = %88, %86
  br label %90

90:                                               ; preds = %89, %76, %48, %20
  br label %91

91:                                               ; preds = %90
  ret void

92:                                               ; preds = %83, %64, %27
  unreachable

93:                                               ; preds = %17
  unreachable
}

attributes #0 = { mustprogress noinline optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nobuiltin allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { alwaysinline mustprogress sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "sample-profile-suffix-elision-policy"="selected" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nobuiltin nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { allocsize(0) }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = !{i64 4}
!11 = distinct !{!11, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
