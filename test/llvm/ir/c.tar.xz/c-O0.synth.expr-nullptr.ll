; ModuleID = 'test/c/synth/expr-nullptr.c'
source_filename = "test/c/synth/expr-nullptr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [13 x i8] c"p == nullptr\00", align 1
@.str.2 = private unnamed_addr constant [13 x i8] c"v == nullptr\00", align 1
@.str.3 = private unnamed_addr constant [14 x i8] c"fp == nullptr\00", align 1
@.str.4 = private unnamed_addr constant [13 x i8] c"q != nullptr\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"nullptr == n\00", align 1
@.str.6 = private unnamed_addr constant [10 x i8] c"n ? 1 : 0\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"!nullptr\00", align 1
@.str.8 = private unnamed_addr constant [50 x i8] c"_Generic(nullptr, typeof(nullptr): 1, default: 0)\00", align 1
@.str.9 = private unnamed_addr constant [35 x i8] c"_Generic(n, void *: 1, default: 0)\00", align 1
@.str.10 = private unnamed_addr constant [34 x i8] c"sizeof(nullptr) == sizeof(void *)\00", align 1
@.str.11 = private unnamed_addr constant [12 x i8] c"(p ? 2 : 3)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store ptr null, ptr %2, align 8
  store ptr null, ptr %3, align 8
  store ptr null, ptr %4, align 8
  store ptr null, ptr %5, align 8
  store i32 0, ptr %6, align 4
  store ptr %6, ptr %7, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = icmp eq ptr %8, null
  %10 = zext i1 %9 to i32
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %10)
  %12 = load ptr, ptr %4, align 8
  %13 = icmp eq ptr %12, null
  %14 = zext i1 %13 to i32
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %14)
  %16 = load ptr, ptr %5, align 8
  %17 = icmp eq ptr %16, null
  %18 = zext i1 %17 to i32
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %18)
  %20 = load ptr, ptr %7, align 8
  %21 = icmp ne ptr %20, null
  %22 = zext i1 %21 to i32
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %22)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 1)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 0)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 1)
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 1)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 0)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 1)
  %30 = load ptr, ptr %3, align 8
  %31 = icmp ne ptr %30, null
  %32 = zext i1 %31 to i64
  %33 = select i1 %31, i32 2, i32 3
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %33)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
