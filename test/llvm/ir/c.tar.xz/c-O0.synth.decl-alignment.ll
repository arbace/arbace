; ModuleID = 'test/c/synth/decl-alignment.c'
source_filename = "test/c/synth/decl-alignment.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@main.s256 = internal global i16 0, align 256
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [28 x i8] c"(int)((uintptr_t)&a32 % 32)\00", align 1
@a32 = internal global i32 0, align 32
@.str.2 = private unnamed_addr constant [27 x i8] c"(int)((uintptr_t)c16 % 16)\00", align 1
@c16 = internal global [4 x i8] zeroinitializer, align 16
@.str.3 = private unnamed_addr constant [24 x i8] c"alignof(struct al) >= 8\00", align 1
@.str.4 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"offsetof_i()\00", align 1
@.str.6 = private unnamed_addr constant [40 x i8] c"(int)((uintptr_t)&ad % alignof(double))\00", align 1
@ad = internal global i32 0, align 8
@.str.7 = private unnamed_addr constant [8 x i8] c"deep(4)\00", align 1
@.str.8 = private unnamed_addr constant [29 x i8] c"(int)((uintptr_t)l128 % 128)\00", align 1
@.str.9 = private unnamed_addr constant [30 x i8] c"(int)((uintptr_t)&s256 % 256)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  %3 = alloca [3 x i8], align 128
  store i32 0, ptr %1, align 4
  store i8 0, ptr %2, align 1
  %4 = load i8, ptr %2, align 1
  store i8 %4, ptr %3, align 1
  %5 = getelementptr inbounds i8, ptr %3, i64 1
  %6 = getelementptr inbounds i8, ptr %3, i64 3
  br label %7

7:                                                ; preds = %7, %0
  %8 = phi ptr [ %5, %0 ], [ %9, %7 ]
  store i8 0, ptr %8, align 1
  %9 = getelementptr inbounds i8, ptr %8, i64 1
  %10 = icmp eq ptr %9, %6
  br i1 %10, label %11, label %7

11:                                               ; preds = %7
  %12 = urem i64 ptrtoint (ptr @a32 to i64), 32
  %13 = trunc i64 %12 to i32
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %13)
  %15 = urem i64 ptrtoint (ptr @c16 to i64), 16
  %16 = trunc i64 %15 to i32
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %16)
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 1)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, i64 noundef 0)
  %20 = urem i64 ptrtoint (ptr @ad to i64), 8
  %21 = trunc i64 %20 to i32
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %21)
  %23 = call i32 @deep(i32 noundef 4)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %23)
  %25 = getelementptr inbounds [3 x i8], ptr %3, i64 0, i64 0
  %26 = ptrtoint ptr %25 to i64
  %27 = urem i64 %26, 128
  %28 = trunc i64 %27 to i32
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %28)
  %30 = urem i64 ptrtoint (ptr @main.s256 to i64), 256
  %31 = trunc i64 %30 to i32
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %31)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @deep(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i8, align 1
  %5 = alloca [3 x i32], align 64
  %6 = alloca i8, align 1
  %7 = alloca double, align 32
  store i32 %0, ptr %3, align 4
  store i8 1, ptr %4, align 1
  %8 = load i32, ptr %3, align 4
  store i32 %8, ptr %5, align 4
  %9 = getelementptr inbounds i32, ptr %5, i64 1
  %10 = load i32, ptr %3, align 4
  store i32 %10, ptr %9, align 4
  %11 = getelementptr inbounds i32, ptr %5, i64 2
  %12 = load i32, ptr %3, align 4
  store i32 %12, ptr %11, align 4
  store i8 2, ptr %6, align 1
  %13 = load i32, ptr %3, align 4
  %14 = sitofp i32 %13 to double
  store double %14, ptr %7, align 32
  %15 = getelementptr inbounds [3 x i32], ptr %5, i64 0, i64 0
  %16 = ptrtoint ptr %15 to i64
  %17 = urem i64 %16, 64
  %18 = icmp ne i64 %17, 0
  br i1 %18, label %23, label %19

19:                                               ; preds = %1
  %20 = ptrtoint ptr %7 to i64
  %21 = urem i64 %20, 32
  %22 = icmp ne i64 %21, 0
  br i1 %22, label %23, label %24

23:                                               ; preds = %19, %1
  store i32 -1000, ptr %2, align 4
  br label %43

24:                                               ; preds = %19
  %25 = load i8, ptr %4, align 1
  %26 = sext i8 %25 to i32
  %27 = load i8, ptr %6, align 1
  %28 = sext i8 %27 to i32
  %29 = add nsw i32 %26, %28
  %30 = getelementptr inbounds [3 x i32], ptr %5, i64 0, i64 2
  %31 = load i32, ptr %30, align 8
  %32 = add nsw i32 %29, %31
  %33 = load i32, ptr %3, align 4
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %35, label %39

35:                                               ; preds = %24
  %36 = load i32, ptr %3, align 4
  %37 = sub nsw i32 %36, 1
  %38 = call i32 @deep(i32 noundef %37)
  br label %40

39:                                               ; preds = %24
  br label %40

40:                                               ; preds = %39, %35
  %41 = phi i32 [ %38, %35 ], [ 0, %39 ]
  %42 = add nsw i32 %32, %41
  store i32 %42, ptr %2, align 4
  br label %43

43:                                               ; preds = %40, %23
  %44 = load i32, ptr %2, align 4
  ret i32 %44
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
