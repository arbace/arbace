; ModuleID = 'test/c/synth/decl-empty-initializer.c'
source_filename = "test/c/synth/decl-empty-initializer.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.s = type { i32, double, ptr }
%union.anon = type { i32 }

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"i\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"a[0] + a[2]\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"st.a\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.5 = private unnamed_addr constant [5 x i8] c"st.b\00", align 1
@.str.6 = private unnamed_addr constant [16 x i8] c"st.p == nullptr\00", align 1
@.str.7 = private unnamed_addr constant [5 x i8] c"un.x\00", align 1
@.str.8 = private unnamed_addr constant [12 x i8] c"v[0] + v[2]\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"p == nullptr\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"fs.a\00", align 1
@fs = internal global { i32, [4 x i8], double, ptr } zeroinitializer, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [3 x i32], align 4
  %4 = alloca %struct.s, align 8
  %5 = alloca %union.anon, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %3, i8 0, i64 12, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 24, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %5, i8 0, i64 4, i1 false)
  store i32 3, ptr %6, align 4
  %10 = load i32, ptr %6, align 4
  %11 = zext i32 %10 to i64
  %12 = call ptr @llvm.stacksave.p0()
  store ptr %12, ptr %7, align 8
  %13 = alloca i32, i64 %11, align 16
  store i64 %11, ptr %8, align 8
  %14 = mul nuw i64 %11, 4
  call void @llvm.memset.p0.i64(ptr align 16 %13, i8 0, i64 %14, i1 false)
  store ptr null, ptr %9, align 8
  %15 = load i32, ptr %2, align 4
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %15)
  %17 = getelementptr inbounds [3 x i32], ptr %3, i64 0, i64 0
  %18 = load i32, ptr %17, align 4
  %19 = getelementptr inbounds [3 x i32], ptr %3, i64 0, i64 2
  %20 = load i32, ptr %19, align 4
  %21 = add nsw i32 %18, %20
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %21)
  %23 = getelementptr inbounds nuw %struct.s, ptr %4, i32 0, i32 0
  %24 = load i32, ptr %23, align 8
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %24)
  %26 = getelementptr inbounds nuw %struct.s, ptr %4, i32 0, i32 1
  %27 = load double, ptr %26, align 8
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, double noundef %27)
  %29 = getelementptr inbounds nuw %struct.s, ptr %4, i32 0, i32 2
  %30 = load ptr, ptr %29, align 8
  %31 = icmp eq ptr %30, null
  %32 = zext i1 %31 to i32
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %32)
  %34 = load i32, ptr %5, align 4
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %34)
  %36 = getelementptr inbounds i32, ptr %13, i64 0
  %37 = load i32, ptr %36, align 16
  %38 = getelementptr inbounds i32, ptr %13, i64 2
  %39 = load i32, ptr %38, align 8
  %40 = add nsw i32 %37, %39
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %40)
  %42 = load ptr, ptr %9, align 8
  %43 = icmp eq ptr %42, null
  %44 = zext i1 %43 to i32
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %44)
  %46 = load i32, ptr @fs, align 8
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %46)
  store i32 0, ptr %1, align 4
  %48 = load ptr, ptr %7, align 8
  call void @llvm.stackrestore.p0(ptr %48)
  %49 = load i32, ptr %1, align 4
  ret i32 %49
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare ptr @llvm.stacksave.p0() #2

declare i32 @printf(ptr noundef, ...) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.stackrestore.p0(ptr) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
