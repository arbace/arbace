; ModuleID = 'test/c/synth/expr-conversions.c'
source_filename = "test/c/synth/expr-conversions.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"uc + 10\00", align 1
@.str.2 = private unnamed_addr constant [7 x i8] c"sc * 2\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"us + 1\00", align 1
@.str.4 = private unnamed_addr constant [38 x i8] c"_Generic(uc + uc, int: 1, default: 0)\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"ll < u\00", align 1
@.str.6 = private unnamed_addr constant [10 x i8] c"(int)2.99\00", align 1
@.str.7 = private unnamed_addr constant [11 x i8] c"(int)-2.99\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"(unsigned)-1\00", align 1
@.str.10 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.11 = private unnamed_addr constant [23 x i8] c"(unsigned long long)ll\00", align 1
@.str.12 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.13 = private unnamed_addr constant [21 x i8] c"(double)(1ull << 53)\00", align 1
@.str.14 = private unnamed_addr constant [14 x i8] c"(int)(char)65\00", align 1
@.str.15 = private unnamed_addr constant [42 x i8] c"_Generic(1 + 1u, unsigned: 1, default: 0)\00", align 1
@.str.16 = private unnamed_addr constant [44 x i8] c"_Generic(1 + 1ll, long long: 1, default: 0)\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, i32 noundef 260)
  %2 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.2, i32 noundef -12)
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.3, i32 noundef 65536)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.4, i32 noundef 1)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.5, i32 noundef 1)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.6, i32 noundef 2)
  %7 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.7, i32 noundef -2)
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.8, ptr noundef nonnull @.str.9, i32 noundef -1)
  %9 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.10, ptr noundef nonnull @.str.11, i64 noundef -1)
  %10 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.12, ptr noundef nonnull @.str.13, double noundef f0x4340000000000000)
  %11 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.14, i32 noundef 65)
  %12 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.15, i32 noundef 1)
  %13 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.16, i32 noundef 1)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
