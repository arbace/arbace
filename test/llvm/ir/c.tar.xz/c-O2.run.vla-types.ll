; ModuleID = 'test/c/run/vla-types.c'
source_filename = "test/c/run/vla-types.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [17 x i8] c"typedef %ld %ld\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"rows %ld\0A\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"sides %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [12 x i8] c"unnamed %d\0A\00", align 1
@.str.4 = private unnamed_addr constant [16 x i8] c"rowparam %d %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"types %ld\0A\00", align 1
@.str.6 = private unnamed_addr constant [14 x i8] c"zeroed %d %d\0A\00", align 1
@calls = internal unnamed_addr global i32 0, align 4

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [50 x i32], align 16
  %2 = alloca [50 x i32], align 16
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef 20, i64 noundef 88)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef 132)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 25)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.3, i32 noundef 23)
  %7 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, i32 noundef 5, i32 noundef 7)
  %8 = load i32, ptr @calls, align 4, !tbaa !10
  %9 = sext i32 %8 to i64
  %10 = add nsw i32 %8, 2
  store i32 %10, ptr @calls, align 4, !tbaa !10
  %11 = shl nsw i64 %9, 1
  %12 = add nsw i64 %11, 57
  %13 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.5, i64 noundef %12)
  call void @llvm.lifetime.start.p0(ptr nonnull %2)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(200) %2, i8 0, i64 200, i1 false)
  br label %14

14:                                               ; preds = %14, %0
  %15 = phi i64 [ 0, %0 ], [ %46, %14 ]
  %16 = phi i32 [ 0, %0 ], [ %45, %14 ]
  %17 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %15
  %18 = load volatile i32, ptr %17, align 4, !tbaa !10
  %19 = icmp ne i32 %18, 0
  %20 = zext i1 %19 to i32
  %21 = add nuw nsw i32 %16, %20
  %22 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %15
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 4
  %24 = load volatile i32, ptr %23, align 4, !tbaa !10
  %25 = icmp ne i32 %24, 0
  %26 = zext i1 %25 to i32
  %27 = add nuw nsw i32 %21, %26
  %28 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %15
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 8
  %30 = load volatile i32, ptr %29, align 4, !tbaa !10
  %31 = icmp ne i32 %30, 0
  %32 = zext i1 %31 to i32
  %33 = add nuw nsw i32 %27, %32
  %34 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %15
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 12
  %36 = load volatile i32, ptr %35, align 4, !tbaa !10
  %37 = icmp ne i32 %36, 0
  %38 = zext i1 %37 to i32
  %39 = add nuw nsw i32 %33, %38
  %40 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %15
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 16
  %42 = load volatile i32, ptr %41, align 4, !tbaa !10
  %43 = icmp ne i32 %42, 0
  %44 = zext i1 %43 to i32
  %45 = add nuw nsw i32 %39, %44
  %46 = add nuw nsw i64 %15, 5
  %47 = icmp eq i64 %46, 50
  br i1 %47, label %48, label %14, !llvm.loop !11

48:                                               ; preds = %14, %48
  %49 = phi i64 [ %59, %48 ], [ 0, %14 ]
  %50 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %49
  store volatile i32 -1, ptr %50, align 4, !tbaa !10
  %51 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %49
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 4
  store volatile i32 -1, ptr %52, align 4, !tbaa !10
  %53 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %49
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 8
  store volatile i32 -1, ptr %54, align 4, !tbaa !10
  %55 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %49
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 12
  store volatile i32 -1, ptr %56, align 4, !tbaa !10
  %57 = getelementptr inbounds nuw [4 x i8], ptr %2, i64 %49
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 16
  store volatile i32 -1, ptr %58, align 4, !tbaa !10
  %59 = add nuw nsw i64 %49, 5
  %60 = icmp eq i64 %59, 50
  br i1 %60, label %61, label %48, !llvm.loop !13

61:                                               ; preds = %48
  call void @llvm.lifetime.end.p0(ptr nonnull %2)
  call void @llvm.lifetime.start.p0(ptr nonnull %1)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(200) %1, i8 0, i64 200, i1 false)
  br label %62

62:                                               ; preds = %62, %61
  %63 = phi i64 [ 0, %61 ], [ %94, %62 ]
  %64 = phi i32 [ 0, %61 ], [ %93, %62 ]
  %65 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %63
  %66 = load volatile i32, ptr %65, align 4, !tbaa !10
  %67 = icmp ne i32 %66, 0
  %68 = zext i1 %67 to i32
  %69 = add nuw nsw i32 %64, %68
  %70 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %63
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 4
  %72 = load volatile i32, ptr %71, align 4, !tbaa !10
  %73 = icmp ne i32 %72, 0
  %74 = zext i1 %73 to i32
  %75 = add nuw nsw i32 %69, %74
  %76 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %63
  %77 = getelementptr inbounds nuw i8, ptr %76, i64 8
  %78 = load volatile i32, ptr %77, align 4, !tbaa !10
  %79 = icmp ne i32 %78, 0
  %80 = zext i1 %79 to i32
  %81 = add nuw nsw i32 %75, %80
  %82 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %63
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 12
  %84 = load volatile i32, ptr %83, align 4, !tbaa !10
  %85 = icmp ne i32 %84, 0
  %86 = zext i1 %85 to i32
  %87 = add nuw nsw i32 %81, %86
  %88 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %63
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 16
  %90 = load volatile i32, ptr %89, align 4, !tbaa !10
  %91 = icmp ne i32 %90, 0
  %92 = zext i1 %91 to i32
  %93 = add nuw nsw i32 %87, %92
  %94 = add nuw nsw i64 %63, 5
  %95 = icmp eq i64 %94, 50
  br i1 %95, label %96, label %62, !llvm.loop !11

96:                                               ; preds = %62, %96
  %97 = phi i64 [ %107, %96 ], [ 0, %62 ]
  %98 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %97
  store volatile i32 -1, ptr %98, align 4, !tbaa !10
  %99 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %97
  %100 = getelementptr inbounds nuw i8, ptr %99, i64 4
  store volatile i32 -1, ptr %100, align 4, !tbaa !10
  %101 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %97
  %102 = getelementptr inbounds nuw i8, ptr %101, i64 8
  store volatile i32 -1, ptr %102, align 4, !tbaa !10
  %103 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %97
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 12
  store volatile i32 -1, ptr %104, align 4, !tbaa !10
  %105 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %97
  %106 = getelementptr inbounds nuw i8, ptr %105, i64 16
  store volatile i32 -1, ptr %106, align 4, !tbaa !10
  %107 = add nuw nsw i64 %97, 5
  %108 = icmp eq i64 %107, 50
  br i1 %108, label %109, label %96, !llvm.loop !13

109:                                              ; preds = %96
  call void @llvm.lifetime.end.p0(ptr nonnull %1)
  %110 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.6, i32 noundef %45, i32 noundef %93)
  ret i32 0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!7, !7, i64 0}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
!13 = distinct !{!13, !12}
