; ModuleID = 'test/c/synth/decl-declarators.c'
source_filename = "test/c/synth/decl-declarators.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@grid = internal global [2 x [3 x i32]] [[3 x i32] [i32 1, i32 2, i32 3], [3 x i32] [i32 4, i32 5, i32 6]], align 16
@table = internal global [2 x ptr] [ptr @one, ptr @two], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"**pp\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"*arr[1]\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"row[1][2]\00", align 1
@.str.4 = private unnamed_addr constant [10 x i8] c"pick(0)()\00", align 1
@.str.5 = private unnamed_addr constant [10 x i8] c"pick(1)()\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"table[0]()\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"(*fpp)()\00", align 1
@.str.8 = private unnamed_addr constant [6 x i8] c"**cpp\00", align 1
@.str.9 = private unnamed_addr constant [16 x i8] c"(*(row + 1))[0]\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca [2 x ptr], align 16
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store i32 3, ptr %2, align 4
  store ptr %2, ptr %3, align 8
  store ptr %3, ptr %4, align 8
  store ptr %2, ptr %5, align 8
  %9 = getelementptr inbounds ptr, ptr %5, i64 1
  %10 = load ptr, ptr %3, align 8
  store ptr %10, ptr %9, align 8
  store ptr @grid, ptr %6, align 8
  store ptr getelementptr inbounds nuw (i8, ptr @table, i64 8), ptr %7, align 8
  store ptr %3, ptr %8, align 8
  %11 = load ptr, ptr %4, align 8
  %12 = load ptr, ptr %11, align 8
  %13 = load i32, ptr %12, align 4
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %13)
  %15 = getelementptr inbounds [2 x ptr], ptr %5, i64 0, i64 1
  %16 = load ptr, ptr %15, align 8
  %17 = load i32, ptr %16, align 4
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %17)
  %19 = load ptr, ptr %6, align 8
  %20 = getelementptr inbounds [3 x i32], ptr %19, i64 1
  %21 = getelementptr inbounds [3 x i32], ptr %20, i64 0, i64 2
  %22 = load i32, ptr %21, align 4
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %22)
  %24 = call ptr @pick(i32 noundef 0)
  %25 = call i32 %24()
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %25)
  %27 = call ptr @pick(i32 noundef 1)
  %28 = call i32 %27()
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %28)
  %30 = load ptr, ptr @table, align 16
  %31 = call i32 %30()
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %31)
  %33 = load ptr, ptr %7, align 8
  %34 = load ptr, ptr %33, align 8
  %35 = call i32 %34()
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %35)
  %37 = load ptr, ptr %8, align 8
  %38 = load ptr, ptr %37, align 8
  %39 = load i32, ptr %38, align 4
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %39)
  %41 = load ptr, ptr %6, align 8
  %42 = getelementptr inbounds [3 x i32], ptr %41, i64 1
  %43 = getelementptr inbounds [3 x i32], ptr %42, i64 0, i64 0
  %44 = load i32, ptr %43, align 4
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %44)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @pick(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp ne i32 %3, 0
  %5 = zext i1 %4 to i64
  %6 = select i1 %4, ptr @two, ptr @one
  ret ptr %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @one() #0 {
  ret i32 1
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @two() #0 {
  ret i32 2
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
