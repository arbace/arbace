; ModuleID = 'test/c/synth/decl-bitint.c'
source_filename = "test/c/synth/decl-bitint.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"(int)s7\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"(int)u7\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"(int)bit\00", align 1
@.str.4 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"(long long)w\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.7 = private unnamed_addr constant [24 x i8] c"(unsigned long long)big\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"(int)neg\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"(int)two\00", align 1
@.str.10 = private unnamed_addr constant [16 x i8] c"(int)(s7 + 1wb)\00", align 1
@.str.11 = private unnamed_addr constant [41 x i8] c"_Generic(1wb, _BitInt(2): 1, default: 0)\00", align 1
@.str.12 = private unnamed_addr constant [51 x i8] c"_Generic(1uwb, unsigned _BitInt(1): 1, default: 0)\00", align 1
@.str.13 = private unnamed_addr constant [54 x i8] c"_Generic(u7 + u7, unsigned _BitInt(7): 1, default: 0)\00", align 1
@.str.14 = private unnamed_addr constant [29 x i8] c"(int)(unsigned _BitInt(3))13\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i16, align 2
  %8 = alloca i8, align 1
  store i32 0, ptr %1, align 4
  store i8 63, ptr %2, align 1
  store i8 127, ptr %3, align 1
  %9 = load i8, ptr %3, align 1
  %10 = trunc i8 %9 to i7
  %11 = zext i7 %10 to i32
  %12 = add nsw i32 %11, 1
  %13 = trunc i32 %12 to i7
  %14 = zext i7 %13 to i8
  store i8 %14, ptr %3, align 1
  store i8 1, ptr %4, align 1
  store i64 34359738368, ptr %5, align 8
  store i64 -1, ptr %6, align 8
  store i16 -2048, ptr %7, align 2
  store i8 -2, ptr %8, align 1
  %15 = load i8, ptr %2, align 1
  %16 = trunc i8 %15 to i7
  %17 = sext i7 %16 to i32
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %17)
  %19 = load i8, ptr %3, align 1
  %20 = trunc i8 %19 to i7
  %21 = zext i7 %20 to i32
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %21)
  %23 = load i8, ptr %4, align 1
  %24 = icmp ne i8 %23, 0
  %25 = zext i1 %24 to i32
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %25)
  %27 = load i64, ptr %5, align 8
  %28 = trunc i64 %27 to i37
  %29 = sext i37 %28 to i64
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, i64 noundef %29)
  %31 = load i64, ptr %6, align 8
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.7, i64 noundef %31)
  %33 = load i16, ptr %7, align 2
  %34 = trunc i16 %33 to i12
  %35 = sext i12 %34 to i32
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %35)
  %37 = load i8, ptr %8, align 1
  %38 = trunc i8 %37 to i2
  %39 = sext i2 %38 to i32
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %39)
  %41 = load i8, ptr %2, align 1
  %42 = trunc i8 %41 to i7
  %43 = add nsw i7 %42, 1
  %44 = sext i7 %43 to i32
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %44)
  %46 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 1)
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 1)
  %48 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef 1)
  %49 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef 5)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
