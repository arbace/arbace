; ModuleID = 'test/c/synth/ext-functions.c'
source_filename = "test/c/synth/ext-functions.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [12 x i8] c"is_even(10)\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"is_odd(7)\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"fact(20)\00", align 1
@.str.5 = private unnamed_addr constant [10 x i8] c"ext_fn(1)\00", align 1
@.str.6 = private unnamed_addr constant [2 x i8] c"v\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @ext_fn(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 100
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  call void @out(ptr noundef %2)
  %3 = call i32 @is_even(i32 noundef 10)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %3)
  %5 = call i32 @is_odd(i32 noundef 7)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %5)
  %7 = call i64 @fact(i32 noundef 20)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.4, i64 noundef %7)
  %9 = call i32 @ext_fn(i32 noundef 1)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %9)
  %11 = load i32, ptr %2, align 4
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %11)
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @out(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  store i32 9, ptr %3, align 4
  ret void
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @is_even(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %10

6:                                                ; preds = %1
  %7 = load i32, ptr %2, align 4
  %8 = sub nsw i32 %7, 1
  %9 = call i32 @is_odd(i32 noundef %8)
  br label %10

10:                                               ; preds = %6, %5
  %11 = phi i32 [ 1, %5 ], [ %9, %6 ]
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @is_odd(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp eq i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %10

6:                                                ; preds = %1
  %7 = load i32, ptr %2, align 4
  %8 = sub nsw i32 %7, 1
  %9 = call i32 @is_even(i32 noundef %8)
  br label %10

10:                                               ; preds = %6, %5
  %11 = phi i32 [ 0, %5 ], [ %9, %6 ]
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @fact(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp sle i32 %3, 1
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  br label %13

6:                                                ; preds = %1
  %7 = load i32, ptr %2, align 4
  %8 = sext i32 %7 to i64
  %9 = load i32, ptr %2, align 4
  %10 = sub nsw i32 %9, 1
  %11 = call i64 @fact(i32 noundef %10)
  %12 = mul nsw i64 %8, %11
  br label %13

13:                                               ; preds = %6, %5
  %14 = phi i64 [ 1, %5 ], [ %12, %6 ]
  ret i64 %14
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
