; ModuleID = 'test/c/synth/decl-abstract-declarators.c'
source_filename = "test/c/synth/decl-abstract-declarators.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.a = private unnamed_addr constant [4 x i32] [i32 1, i32 2, i32 3, i32 4], align 16
@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"(*pa)[3]\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"f(4)\00", align 1
@.str.3 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.4 = private unnamed_addr constant [29 x i8] c"sizeof(int[4]) / sizeof(int)\00", align 1
@.str.5 = private unnamed_addr constant [37 x i8] c"sizeof(int (*)[4]) == sizeof(void *)\00", align 1
@.str.6 = private unnamed_addr constant [40 x i8] c"_Generic(&a, int (*)[4]: 1, default: 0)\00", align 1
@.str.7 = private unnamed_addr constant [43 x i8] c"_Generic(inc, int (*)(int): 1, default: 0)\00", align 1
@.str.8 = private unnamed_addr constant [14 x i8] c"((int *)v)[2]\00", align 1
@.str.9 = private unnamed_addr constant [55 x i8] c"_Generic((int *const *)0, int *const *: 1, default: 0)\00", align 1
@.str.10 = private unnamed_addr constant [28 x i8] c"(int){(int)sizeof(char[5])}\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [4 x i32], align 16
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.a, i64 16, i1 false)
  store ptr %2, ptr %3, align 8
  store ptr @inc, ptr %4, align 8
  store ptr %2, ptr %5, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = getelementptr inbounds [4 x i32], ptr %7, i64 0, i64 3
  %9 = load i32, ptr %8, align 4
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %9)
  %11 = load ptr, ptr %4, align 8
  %12 = call i32 %11(i32 noundef 4)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %12)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.4, i64 noundef 4)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 1)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 1)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 1)
  %18 = load ptr, ptr %5, align 8
  %19 = getelementptr inbounds i32, ptr %18, i64 2
  %20 = load i32, ptr %19, align 4
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %20)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 1)
  store i32 5, ptr %6, align 4
  %23 = load i32, ptr %6, align 4
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %23)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @inc(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 1
  ret i32 %4
}

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
