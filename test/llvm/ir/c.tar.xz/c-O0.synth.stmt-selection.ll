; ModuleID = 'test/c/synth/stmt-selection.c'
source_filename = "test/c/synth/stmt-selection.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"t\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"sign(-5)\00", align 1
@.str.3 = private unnamed_addr constant [8 x i8] c"sign(0)\00", align 1
@.str.4 = private unnamed_addr constant [8 x i8] c"sign(9)\00", align 1
@.str.5 = private unnamed_addr constant [15 x i8] c"dangling(1, 0)\00", align 1
@.str.6 = private unnamed_addr constant [15 x i8] c"dangling(0, 1)\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"fall(1)\00", align 1
@.str.8 = private unnamed_addr constant [8 x i8] c"fall(2)\00", align 1
@.str.9 = private unnamed_addr constant [8 x i8] c"fall(4)\00", align 1
@.str.10 = private unnamed_addr constant [8 x i8] c"fall(5)\00", align 1
@.str.11 = private unnamed_addr constant [13 x i8] c"nested(0, 0)\00", align 1
@.str.12 = private unnamed_addr constant [13 x i8] c"nested(0, 3)\00", align 1
@.str.13 = private unnamed_addr constant [13 x i8] c"nested(1, 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  store i32 1, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = add nsw i32 %3, 2
  store i32 %4, ptr %2, align 4
  %5 = load i32, ptr %2, align 4
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %5)
  %7 = call i32 @sign(i32 noundef -5)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %7)
  %9 = call i32 @sign(i32 noundef 0)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %9)
  %11 = call i32 @sign(i32 noundef 9)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %11)
  %13 = call i32 @dangling(i32 noundef 1, i32 noundef 0)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %13)
  %15 = call i32 @dangling(i32 noundef 0, i32 noundef 1)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %15)
  %17 = call i32 @fall(i32 noundef 1)
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %17)
  %19 = call i32 @fall(i32 noundef 2)
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %19)
  %21 = call i32 @fall(i32 noundef 4)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %21)
  %23 = call i32 @fall(i32 noundef 5)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %23)
  %25 = call i32 @nested(i32 noundef 0, i32 noundef 0)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %25)
  %27 = call i32 @nested(i32 noundef 0, i32 noundef 3)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef %27)
  %29 = call i32 @nested(i32 noundef 1, i32 noundef 0)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef %29)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @sign(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = icmp slt i32 %4, 0
  br i1 %5, label %6, label %7

6:                                                ; preds = %1
  store i32 -1, ptr %2, align 4
  br label %12

7:                                                ; preds = %1
  %8 = load i32, ptr %3, align 4
  %9 = icmp eq i32 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %7
  store i32 0, ptr %2, align 4
  br label %12

11:                                               ; preds = %7
  store i32 1, ptr %2, align 4
  br label %12

12:                                               ; preds = %11, %10, %6
  %13 = load i32, ptr %2, align 4
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @dangling(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  store i32 %0, ptr %4, align 4
  store i32 %1, ptr %5, align 4
  %6 = load i32, ptr %4, align 4
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %8, label %13

8:                                                ; preds = %2
  %9 = load i32, ptr %5, align 4
  %10 = icmp ne i32 %9, 0
  br i1 %10, label %11, label %12

11:                                               ; preds = %8
  store i32 1, ptr %3, align 4
  br label %14

12:                                               ; preds = %8
  store i32 2, ptr %3, align 4
  br label %14

13:                                               ; preds = %2
  store i32 3, ptr %3, align 4
  br label %14

14:                                               ; preds = %13, %12, %11
  %15 = load i32, ptr %3, align 4
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @fall(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  store i32 0, ptr %3, align 4
  %4 = load i32, ptr %2, align 4
  switch i32 %4, label %15 [
    i32 1, label %5
    i32 2, label %8
    i32 3, label %11
    i32 4, label %14
  ]

5:                                                ; preds = %1
  %6 = load i32, ptr %3, align 4
  %7 = add nsw i32 %6, 1
  store i32 %7, ptr %3, align 4
  br label %8

8:                                                ; preds = %1, %5
  %9 = load i32, ptr %3, align 4
  %10 = add nsw i32 %9, 2
  store i32 %10, ptr %3, align 4
  br label %11

11:                                               ; preds = %1, %8
  %12 = load i32, ptr %3, align 4
  %13 = add nsw i32 %12, 3
  store i32 %13, ptr %3, align 4
  br label %15

14:                                               ; preds = %1
  store i32 40, ptr %3, align 4
  br label %15

15:                                               ; preds = %1, %14, %11
  %16 = load i32, ptr %3, align 4
  ret i32 %16
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @nested(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  store i32 %0, ptr %4, align 4
  store i32 %1, ptr %5, align 4
  %6 = load i32, ptr %4, align 4
  switch i32 %6, label %11 [
    i32 0, label %7
  ]

7:                                                ; preds = %2
  %8 = load i32, ptr %5, align 4
  switch i32 %8, label %10 [
    i32 0, label %9
  ]

9:                                                ; preds = %7
  store i32 0, ptr %3, align 4
  br label %12

10:                                               ; preds = %7
  store i32 1, ptr %3, align 4
  br label %12

11:                                               ; preds = %2
  store i32 2, ptr %3, align 4
  br label %12

12:                                               ; preds = %11, %10, %9
  %13 = load i32, ptr %3, align 4
  ret i32 %13
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
