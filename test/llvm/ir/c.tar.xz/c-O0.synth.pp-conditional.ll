; ModuleID = 'test/c/synth/pp-conditional.c'
source_filename = "test/c/synth/pp-conditional.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"a\00", align 1
@a = internal global i32 1, align 4
@.str.2 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@b = internal global i32 2, align 4
@.str.3 = private unnamed_addr constant [2 x i8] c"c\00", align 1
@c = internal global i32 3, align 4
@.str.4 = private unnamed_addr constant [2 x i8] c"d\00", align 1
@d = internal global i32 4, align 4
@.str.5 = private unnamed_addr constant [2 x i8] c"e\00", align 1
@e = internal global i32 5, align 4
@.str.6 = private unnamed_addr constant [2 x i8] c"f\00", align 1
@f = internal global i32 6, align 4
@.str.7 = private unnamed_addr constant [2 x i8] c"g\00", align 1
@g = internal global i32 7, align 4
@.str.8 = private unnamed_addr constant [2 x i8] c"h\00", align 1
@h = internal global i32 8, align 4
@.str.9 = private unnamed_addr constant [2 x i8] c"i\00", align 1
@i = internal global i32 9, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i32, ptr @a, align 4
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %2)
  %4 = load i32, ptr @b, align 4
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %4)
  %6 = load i32, ptr @c, align 4
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %6)
  %8 = load i32, ptr @d, align 4
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %8)
  %10 = load i32, ptr @e, align 4
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %10)
  %12 = load i32, ptr @f, align 4
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %12)
  %14 = load i32, ptr @g, align 4
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %14)
  %16 = load i32, ptr @h, align 4
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %16)
  %18 = load i32, ptr @i, align 4
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %18)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
