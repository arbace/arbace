; ModuleID = 'test/c/synth/decl-bitint-wide.c'
source_filename = "test/c/synth/decl-bitint-wide.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [11 x i8] c"%s = %llx\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"part(p, 0)\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"part(p, 1)\00", align 1
@.str.3 = private unnamed_addr constant [30 x i8] c"(unsigned long long)(q >> 64)\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [6 x i8] c"n < 0\00", align 1
@.str.6 = private unnamed_addr constant [32 x i8] c"(unsigned long long)(-n >> 140)\00", align 1
@.str.7 = private unnamed_addr constant [11 x i8] c"part(d, 0)\00", align 1
@.str.8 = private unnamed_addr constant [11 x i8] c"part(d, 1)\00", align 1
@.str.9 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.10 = private unnamed_addr constant [11 x i8] c"part(m, 0)\00", align 1
@.str.11 = private unnamed_addr constant [18 x i8] c"(int)(p == a * a)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i256, align 8
  %3 = alloca i256, align 8
  %4 = alloca i128, align 8
  %5 = alloca i256, align 8
  %6 = alloca i256, align 8
  %7 = alloca i256, align 8
  %8 = alloca i256, align 8
  %9 = alloca i256, align 8
  %10 = alloca i256, align 8
  %11 = alloca i256, align 8
  %12 = alloca i256, align 8
  store i32 0, ptr %1, align 4
  store i256 18446744073709551615, ptr %2, align 8
  %13 = load i256, ptr %2, align 8
  %14 = load i256, ptr %2, align 8
  %15 = mul i256 %13, %14
  store i256 %15, ptr %3, align 8
  store i128 1267650600228229401496703205376, ptr %4, align 8
  store i256 -1427247692705959881058285969449495136382746624, ptr %5, align 8
  %16 = load i256, ptr %3, align 8
  %17 = udiv i256 %16, 65537
  store i256 %17, ptr %6, align 8
  %18 = load i256, ptr %3, align 8
  %19 = urem i256 %18, 1000000007
  store i256 %19, ptr %7, align 8
  %20 = load i256, ptr %3, align 8
  store i256 %20, ptr %8, align 8
  %21 = call i64 @part(ptr noundef byval(i256) align 8 %8, i32 noundef 0)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i64 noundef %21)
  %23 = load i256, ptr %3, align 8
  store i256 %23, ptr %9, align 8
  %24 = call i64 @part(ptr noundef byval(i256) align 8 %9, i32 noundef 1)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i64 noundef %24)
  %26 = load i128, ptr %4, align 8
  %27 = lshr i128 %26, 64
  %28 = trunc i128 %27 to i64
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i64 noundef %28)
  %30 = load i256, ptr %5, align 8
  %31 = trunc i256 %30 to i200
  %32 = icmp slt i200 %31, 0
  %33 = zext i1 %32 to i32
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef %33)
  %35 = load i256, ptr %5, align 8
  %36 = trunc i256 %35 to i200
  %37 = sub nsw i200 0, %36
  %38 = ashr i200 %37, 140
  %39 = trunc i200 %38 to i64
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i64 noundef %39)
  %41 = load i256, ptr %6, align 8
  store i256 %41, ptr %10, align 8
  %42 = call i64 @part(ptr noundef byval(i256) align 8 %10, i32 noundef 0)
  %43 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i64 noundef %42)
  %44 = load i256, ptr %6, align 8
  store i256 %44, ptr %11, align 8
  %45 = call i64 @part(ptr noundef byval(i256) align 8 %11, i32 noundef 1)
  %46 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i64 noundef %45)
  %47 = load i256, ptr %7, align 8
  store i256 %47, ptr %12, align 8
  %48 = call i64 @part(ptr noundef byval(i256) align 8 %12, i32 noundef 0)
  %49 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, i64 noundef %48)
  %50 = load i256, ptr %3, align 8
  %51 = load i256, ptr %2, align 8
  %52 = load i256, ptr %2, align 8
  %53 = mul i256 %51, %52
  %54 = icmp eq i256 %50, %53
  %55 = zext i1 %54 to i32
  %56 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.11, i32 noundef %55)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @part(ptr noundef byval(i256) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca i256, align 8
  %4 = alloca i32, align 4
  %5 = load i256, ptr %0, align 8
  store i256 %5, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %6 = load i256, ptr %3, align 8
  %7 = load i32, ptr %4, align 4
  %8 = mul nsw i32 64, %7
  %9 = zext i32 %8 to i256
  %10 = lshr i256 %6, %9
  %11 = trunc i256 %10 to i64
  ret i64 %11
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
