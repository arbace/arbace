; ModuleID = 'test/c/synth/expr-unary.c'
source_filename = "test/c/synth/expr-unary.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"pre\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"pred\00", align 1
@.str.3 = private unnamed_addr constant [3 x i8] c"*p\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"+x\00", align 1
@.str.5 = private unnamed_addr constant [3 x i8] c"-x\00", align 1
@.str.6 = private unnamed_addr constant [3 x i8] c"~x\00", align 1
@.str.7 = private unnamed_addr constant [3 x i8] c"!x\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"!0\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.10 = private unnamed_addr constant [3 x i8] c"~u\00", align 1
@.str.11 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.12 = private unnamed_addr constant [9 x i8] c"sizeof x\00", align 1
@.str.13 = private unnamed_addr constant [12 x i8] c"sizeof(int)\00", align 1
@.str.14 = private unnamed_addr constant [23 x i8] c"sizeof a / sizeof a[0]\00", align 1
@.str.15 = private unnamed_addr constant [13 x i8] c"sizeof(char)\00", align 1
@.str.16 = private unnamed_addr constant [14 x i8] c"alignof(char)\00", align 1
@.str.17 = private unnamed_addr constant [24 x i8] c"_Alignof(unsigned char)\00", align 1
@.str.18 = private unnamed_addr constant [29 x i8] c"sizeof(int[3]) / sizeof(int)\00", align 1
@.str.19 = private unnamed_addr constant [5 x i8] c"*&*p\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca [6 x i32], align 16
  %7 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 5, ptr %2, align 4
  %8 = load i32, ptr %2, align 4
  %9 = add nsw i32 %8, 1
  store i32 %9, ptr %2, align 4
  store i32 %9, ptr %3, align 4
  %10 = load i32, ptr %2, align 4
  %11 = add nsw i32 %10, -1
  store i32 %11, ptr %2, align 4
  store i32 %11, ptr %4, align 4
  store ptr %2, ptr %5, align 8
  store i32 0, ptr %7, align 4
  %12 = load i32, ptr %3, align 4
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %12)
  %14 = load i32, ptr %4, align 4
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %14)
  %16 = load ptr, ptr %5, align 8
  %17 = load i32, ptr %16, align 4
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %17)
  %19 = load i32, ptr %2, align 4
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %19)
  %21 = load i32, ptr %2, align 4
  %22 = sub nsw i32 0, %21
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %22)
  %24 = load i32, ptr %2, align 4
  %25 = xor i32 %24, -1
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %25)
  %27 = load i32, ptr %2, align 4
  %28 = icmp ne i32 %27, 0
  %29 = xor i1 %28, true
  %30 = zext i1 %29 to i32
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %30)
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 1)
  %33 = load i32, ptr %7, align 4
  %34 = xor i32 %33, -1
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, i32 noundef %34)
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.12, i64 noundef 4)
  %37 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.13, i64 noundef 4)
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.14, i64 noundef 6)
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.15, i64 noundef 1)
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.16, i64 noundef 1)
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.17, i64 noundef 1)
  %42 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.18, i64 noundef 3)
  %43 = load ptr, ptr %5, align 8
  %44 = load i32, ptr %43, align 4
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.19, i32 noundef %44)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
