; ModuleID = 'test/c/synth/pp-variadic.c'
source_filename = "test/c/synth/pp-variadic.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"COUNT()\00", align 1
@.str.2 = private unnamed_addr constant [12 x i8] c"COUNT(1, 2)\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"SUM(5)\00", align 1
@.str.4 = private unnamed_addr constant [10 x i8] c"SUM(5, 6)\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.6 = private unnamed_addr constant [15 x i8] c"SHOW(a, b,  c)\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"a, b, c\00", align 1
@.str.8 = private unnamed_addr constant [7 x i8] c"SHOW()\00", align 1
@.str.9 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"F(4)\00", align 1
@.str.11 = private unnamed_addr constant [11 x i8] c"F(4, 5, 6)\00", align 1
@.str.12 = private unnamed_addr constant [8 x i8] c"NARGS()\00", align 1
@.str.13 = private unnamed_addr constant [9 x i8] c"NARGS(a)\00", align 1
@.str.14 = private unnamed_addr constant [12 x i8] c"NARGS(a, b)\00", align 1
@.str.15 = private unnamed_addr constant [15 x i8] c"NARGS(a, b, c)\00", align 1
@.str.16 = private unnamed_addr constant [12 x i8] c"EMPTYOPT(1)\00", align 1
@x = internal global i32 5, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (i32, ...) @count_(i32 noundef 0)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %2)
  %4 = call i32 (i32, ...) @count_(i32 noundef 0, i32 noundef 1, i32 noundef 2)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %4)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 5)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 11)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.6, ptr noundef @.str.7)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.8, ptr noundef @.str.9)
  %10 = call i32 (i32, ...) @f_(i32 noundef 4)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %10)
  %12 = call i32 (i32, ...) @f_(i32 noundef 4, i32 noundef 5, i32 noundef 6)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %12)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 0)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef 1)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef 2)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 3)
  %18 = load i32, ptr @x, align 4
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef %18)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @count_(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @f_(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  ret i32 %3
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
