; ModuleID = 'test/c/synth/decl-auto.c'
source_filename = "test/c/synth/decl-auto.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [4 x i8] c"str\00", align 1
@__const.main.arr = private unnamed_addr constant [3 x i32] [i32 1, i32 2, i32 3], align 4
@main.si = internal global i32 7, align 4
@.str.1 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.2 = private unnamed_addr constant [32 x i8] c"_Generic(i, int: 1, default: 0)\00", align 1
@.str.3 = private unnamed_addr constant [35 x i8] c"_Generic(d, double: 1, default: 0)\00", align 1
@.str.4 = private unnamed_addr constant [37 x i8] c"_Generic(u, unsigned: 1, default: 0)\00", align 1
@.str.5 = private unnamed_addr constant [38 x i8] c"_Generic(l, long long: 1, default: 0)\00", align 1
@.str.6 = private unnamed_addr constant [34 x i8] c"_Generic(p, int *: 1, default: 0)\00", align 1
@.str.7 = private unnamed_addr constant [35 x i8] c"_Generic(s, char *: 1, default: 0)\00", align 1
@.str.8 = private unnamed_addr constant [32 x i8] c"_Generic(c, int: 1, default: 0)\00", align 1
@.str.9 = private unnamed_addr constant [37 x i8] c"_Generic(sum, double: 1, default: 0)\00", align 1
@.str.10 = private unnamed_addr constant [35 x i8] c"_Generic(ap, int *: 1, default: 0)\00", align 1
@.str.11 = private unnamed_addr constant [4 x i8] c"acc\00", align 1
@.str.12 = private unnamed_addr constant [3 x i8] c"si\00", align 1
@.str.13 = private unnamed_addr constant [3 x i8] c"ci\00", align 1
@.str.14 = private unnamed_addr constant [3 x i8] c"*p\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca double, align 8
  %4 = alloca i32, align 4
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i32, align 4
  %9 = alloca double, align 8
  %10 = alloca [3 x i32], align 4
  %11 = alloca ptr, align 8
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 1, ptr %2, align 4
  store double 1.500000e+00, ptr %3, align 8
  store i32 2, ptr %4, align 4
  store i64 3, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr @.str, ptr %7, align 8
  store i32 99, ptr %8, align 4
  %15 = load i32, ptr %2, align 4
  %16 = sitofp i32 %15 to double
  %17 = load double, ptr %3, align 8
  %18 = fadd double %16, %17
  store double %18, ptr %9, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %10, ptr align 4 @__const.main.arr, i64 12, i1 false)
  %19 = getelementptr inbounds [3 x i32], ptr %10, i64 0, i64 0
  store ptr %19, ptr %11, align 8
  store i32 0, ptr %12, align 4
  store i32 0, ptr %13, align 4
  br label %20

20:                                               ; preds = %31, %0
  %21 = load i32, ptr %13, align 4
  %22 = icmp slt i32 %21, 3
  br i1 %22, label %23, label %34

23:                                               ; preds = %20
  %24 = load ptr, ptr %11, align 8
  %25 = load i32, ptr %13, align 4
  %26 = sext i32 %25 to i64
  %27 = getelementptr inbounds i32, ptr %24, i64 %26
  %28 = load i32, ptr %27, align 4
  %29 = load i32, ptr %12, align 4
  %30 = add nsw i32 %29, %28
  store i32 %30, ptr %12, align 4
  br label %31

31:                                               ; preds = %23
  %32 = load i32, ptr %13, align 4
  %33 = add nsw i32 %32, 1
  store i32 %33, ptr %13, align 4
  br label %20, !llvm.loop !6

34:                                               ; preds = %20
  store i32 8, ptr %14, align 4
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.2, i32 noundef 1)
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.3, i32 noundef 1)
  %37 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.4, i32 noundef 1)
  %38 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.5, i32 noundef 1)
  %39 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.6, i32 noundef 1)
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.7, i32 noundef 1)
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.8, i32 noundef 1)
  %42 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.9, i32 noundef 1)
  %43 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.10, i32 noundef 1)
  %44 = load i32, ptr %12, align 4
  %45 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.11, i32 noundef %44)
  %46 = load i32, ptr @main.si, align 4
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.12, i32 noundef %46)
  %48 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.13, i32 noundef 8)
  %49 = load ptr, ptr %6, align 8
  %50 = load i32, ptr %49, align 4
  %51 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, ptr noundef @.str.14, i32 noundef %50)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
