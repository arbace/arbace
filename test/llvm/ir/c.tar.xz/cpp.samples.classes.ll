; ModuleID = 'test/cpp/samples/classes.cpp'
source_filename = "test/cpp/samples/classes.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%class.D = type { %struct.B.base, i32 }
%struct.B.base = type <{ ptr, i32 }>
%struct.V = type { [2 x i32] }
%struct.B = type <{ ptr, i32, [4 x i8] }>

$_ZN1DC2Ev = comdat any

$_ZN1DD2Ev = comdat any

$_ZN1DD0Ev = comdat any

$_ZN1BC2Ei = comdat any

$_ZN1BD2Ev = comdat any

$_ZN1BD0Ev = comdat any

$_ZTI1B = comdat any

$_ZTS1B = comdat any

$_ZTV1B = comdat any

@__const.main.v = private unnamed_addr constant [2 x i32] [i32 1, i32 2], align 4
@_ZTIi = external constant ptr
@_ZTV1D = dso_local constant { [5 x ptr] } { [5 x ptr] [ptr null, ptr @_ZTI1D, ptr @_ZN1DD2Ev, ptr @_ZN1DD0Ev, ptr @_ZNK1D1fEv] }, align 8
@_ZTI1D = dso_local constant { ptr, ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv120__si_class_type_infoE, i64 2), ptr @_ZTS1D, ptr @_ZTI1B }, align 8
@_ZTVN10__cxxabiv120__si_class_type_infoE = external global [0 x ptr]
@_ZTS1D = dso_local constant [3 x i8] c"1D\00", align 1
@_ZTI1B = linkonce_odr dso_local constant { ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv117__class_type_infoE, i64 2), ptr @_ZTS1B }, comdat, align 8
@_ZTVN10__cxxabiv117__class_type_infoE = external global [0 x ptr]
@_ZTS1B = linkonce_odr dso_local constant [3 x i8] c"1B\00", comdat, align 1
@_ZTV1B = linkonce_odr dso_local constant { [5 x ptr] } { [5 x ptr] [ptr null, ptr @_ZTI1B, ptr @_ZN1BD2Ev, ptr @_ZN1BD0Ev, ptr @__cxa_pure_virtual] }, comdat, align 8

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define dso_local noundef i32 @_ZNK1D1fEv(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #0 align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %class.D, ptr %3, i32 0, i32 1
  %5 = load i32, ptr %4, align 4
  ret i32 %5
}

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #1 personality ptr @__gxx_personality_v0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca [2 x i32], align 4
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca %struct.V, align 4
  store i32 0, ptr %1, align 4
  %16 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 4) #8
  store i32 3, ptr %16, align 4
  store ptr %16, ptr %2, align 8
  %17 = call noalias noundef nonnull ptr @_Znam(i64 noundef 16) #8
  store ptr %17, ptr %3, align 8
  %18 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 16) #8
  invoke void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(16) %18)
          to label %19 unwind label %43

19:                                               ; preds = %0
  store ptr %18, ptr %4, align 8
  %20 = load ptr, ptr %2, align 8
  %21 = icmp eq ptr %20, null
  br i1 %21, label %23, label %22

22:                                               ; preds = %19
  call void @_ZdlPvm(ptr noundef %20, i64 noundef 4) #9
  br label %23

23:                                               ; preds = %22, %19
  %24 = load ptr, ptr %3, align 8
  %25 = icmp eq ptr %24, null
  br i1 %25, label %27, label %26

26:                                               ; preds = %23
  call void @_ZdaPv(ptr noundef %24) #9
  br label %27

27:                                               ; preds = %26, %23
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 @__const.main.v, i64 8, i1 false)
  store ptr %7, ptr %8, align 8
  %28 = load ptr, ptr %8, align 8, !nonnull !6, !align !7
  %29 = getelementptr inbounds [2 x i32], ptr %28, i64 0, i64 0
  store ptr %29, ptr %9, align 8
  %30 = load ptr, ptr %8, align 8, !nonnull !6, !align !7
  %31 = getelementptr inbounds [2 x i32], ptr %30, i64 0, i64 0
  %32 = getelementptr inbounds i32, ptr %31, i64 2
  store ptr %32, ptr %10, align 8
  br label %33

33:                                               ; preds = %40, %27
  %34 = load ptr, ptr %9, align 8
  %35 = load ptr, ptr %10, align 8
  %36 = icmp ne ptr %34, %35
  br i1 %36, label %37, label %47

37:                                               ; preds = %33
  %38 = load ptr, ptr %9, align 8
  %39 = load i32, ptr %38, align 4
  store i32 %39, ptr %11, align 4
  br label %40

40:                                               ; preds = %37
  %41 = load ptr, ptr %9, align 8
  %42 = getelementptr inbounds nuw i32, ptr %41, i32 1
  store ptr %42, ptr %9, align 8
  br label %33

43:                                               ; preds = %0
  %44 = landingpad { ptr, i32 }
          cleanup
  %45 = extractvalue { ptr, i32 } %44, 0
  store ptr %45, ptr %5, align 8
  %46 = extractvalue { ptr, i32 } %44, 1
  store i32 %46, ptr %6, align 4
  call void @_ZdlPvm(ptr noundef %18, i64 noundef 16) #9
  br label %87

47:                                               ; preds = %33
  store i32 2, ptr %12, align 4
  %48 = load i32, ptr %12, align 4
  %49 = icmp sgt i32 %48, 1
  br i1 %49, label %50, label %51

50:                                               ; preds = %47
  store i32 1, ptr %1, align 4
  br label %85

51:                                               ; preds = %47
  br label %52

52:                                               ; preds = %51
  store i32 0, ptr %13, align 4
  br label %53

53:                                               ; preds = %57, %52
  %54 = load i32, ptr %13, align 4
  %55 = icmp slt i32 %54, 3
  br i1 %55, label %56, label %60

56:                                               ; preds = %53
  br label %57

57:                                               ; preds = %56
  %58 = load i32, ptr %13, align 4
  %59 = add nsw i32 %58, 1
  store i32 %59, ptr %13, align 4
  br label %53, !llvm.loop !8

60:                                               ; preds = %53
  %61 = getelementptr inbounds [2 x i32], ptr %7, i64 0, i64 0
  %62 = load i32, ptr %61, align 4
  switch i32 %62, label %64 [
    i32 1, label %63
    i32 2, label %63
  ]

63:                                               ; preds = %60, %60
  br label %65

64:                                               ; preds = %60
  br label %65

65:                                               ; preds = %64, %63
  %66 = call ptr @__cxa_allocate_exception(i64 4) #10
  store i32 1, ptr %66, align 16
  invoke void @__cxa_throw(ptr %66, ptr @_ZTIi, ptr null) #11
          to label %92 unwind label %67

67:                                               ; preds = %65
  %68 = landingpad { ptr, i32 }
          catch ptr @_ZTIi
          catch ptr null
  %69 = extractvalue { ptr, i32 } %68, 0
  store ptr %69, ptr %5, align 8
  %70 = extractvalue { ptr, i32 } %68, 1
  store i32 %70, ptr %6, align 4
  br label %71

71:                                               ; preds = %67
  %72 = load i32, ptr %6, align 4
  %73 = call i32 @llvm.eh.typeid.for.p0(ptr @_ZTIi) #10
  %74 = icmp eq i32 %72, %73
  br i1 %74, label %75, label %82

75:                                               ; preds = %71
  %76 = load ptr, ptr %5, align 8
  %77 = call ptr @__cxa_begin_catch(ptr %76) #10
  %78 = load i32, ptr %77, align 4
  store i32 %78, ptr %14, align 4
  call void @__cxa_end_catch() #10
  br label %79

79:                                               ; preds = %75, %82
  %80 = getelementptr inbounds nuw %struct.V, ptr %15, i32 0, i32 0
  %81 = getelementptr inbounds [2 x i32], ptr %80, i64 0, i64 0
  store i32 1, ptr %81, align 4
  store i32 0, ptr %1, align 4
  br label %85

82:                                               ; preds = %71
  %83 = load ptr, ptr %5, align 8
  %84 = call ptr @__cxa_begin_catch(ptr %83) #10
  call void @__cxa_end_catch()
  br label %79

85:                                               ; preds = %79, %50
  %86 = load i32, ptr %1, align 4
  ret i32 %86

87:                                               ; preds = %43
  %88 = load ptr, ptr %5, align 8
  %89 = load i32, ptr %6, align 4
  %90 = insertvalue { ptr, i32 } poison, ptr %88, 0
  %91 = insertvalue { ptr, i32 } %90, i32 %89, 1
  resume { ptr, i32 } %91

92:                                               ; preds = %65
  unreachable
}

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znwm(i64 noundef) #2

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znam(i64 noundef) #2

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #3 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1BC2Ei(ptr noundef nonnull align 8 dereferenceable(12) %3, i32 noundef 1)
  store ptr getelementptr inbounds inrange(-16, 24) ({ [5 x ptr] }, ptr @_ZTV1D, i32 0, i32 0, i32 2), ptr %3, align 8
  %4 = getelementptr inbounds nuw %class.D, ptr %3, i32 0, i32 1
  store i32 2, ptr %4, align 4
  ret void
}

declare i32 @__gxx_personality_v0(...)

; Function Attrs: nobuiltin nounwind
declare void @_ZdlPvm(ptr noundef, i64 noundef) #4

; Function Attrs: nobuiltin nounwind
declare void @_ZdaPv(ptr noundef) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

declare ptr @__cxa_allocate_exception(i64)

declare void @__cxa_throw(ptr, ptr, ptr)

; Function Attrs: nounwind memory(none)
declare i32 @llvm.eh.typeid.for.p0(ptr) #6

declare ptr @__cxa_begin_catch(ptr)

declare void @__cxa_end_catch()

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DD2Ev(ptr noundef nonnull align 8 dead_on_return(16) dereferenceable(16) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1BD2Ev(ptr noundef nonnull align 8 dead_on_return(12) dereferenceable(12) %3) #10
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DD0Ev(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1DD2Ev(ptr noundef nonnull align 8 dead_on_return(16) dereferenceable(16) %3) #10
  call void @_ZdlPvm(ptr noundef %3, i64 noundef 16) #9
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BC2Ei(ptr noundef nonnull align 8 dereferenceable(12) %0, i32 noundef %1) unnamed_addr #0 comdat align 2 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %5 = load ptr, ptr %3, align 8
  store ptr getelementptr inbounds inrange(-16, 24) ({ [5 x ptr] }, ptr @_ZTV1B, i32 0, i32 0, i32 2), ptr %5, align 8
  %6 = getelementptr inbounds nuw %struct.B, ptr %5, i32 0, i32 1
  %7 = load i32, ptr %4, align 4
  store i32 %7, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BD2Ev(ptr noundef nonnull align 8 dead_on_return(12) dereferenceable(12) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BD0Ev(ptr noundef nonnull align 8 dereferenceable(12) %0) unnamed_addr #0 comdat align 2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  call void @llvm.trap() #12
  unreachable
}

declare void @__cxa_pure_virtual() unnamed_addr

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #7

attributes #0 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nobuiltin allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress noinline optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nobuiltin nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind memory(none) }
attributes #7 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #8 = { builtin allocsize(0) }
attributes #9 = { builtin nounwind }
attributes #10 = { nounwind }
attributes #11 = { noreturn }
attributes #12 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{}
!7 = !{i64 4}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
