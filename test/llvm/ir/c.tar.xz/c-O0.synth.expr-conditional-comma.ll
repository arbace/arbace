; ModuleID = 'test/c/synth/expr-conditional-comma.c'
source_filename = "test/c/synth/expr-conditional-comma.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.pr = type { i32, i32 }
%union.un = type { i32 }

@.str = private unnamed_addr constant [4 x i8] c"yes\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"no\00", align 1
@__const.main.pa = private unnamed_addr constant %struct.pr { i32 1, i32 2 }, align 4
@__const.main.pb = private unnamed_addr constant %struct.pr { i32 3, i32 4 }, align 4
@__const.main.ua = private unnamed_addr constant %union.un { i32 7 }, align 4
@__const.main.ub = private unnamed_addr constant %union.un { i32 8 }, align 4
@.str.2 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [2 x i8] c"c\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"a\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@.str.6 = private unnamed_addr constant [3 x i8] c"*p\00", align 1
@.str.7 = private unnamed_addr constant [10 x i8] c"a ? b : c\00", align 1
@.str.8 = private unnamed_addr constant [18 x i8] c"0 ? 1 : 2 ? 3 : 4\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.10 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.11 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.12 = private unnamed_addr constant [12 x i8] c"1 ? 1 : 2.5\00", align 1
@.str.13 = private unnamed_addr constant [5 x i8] c"pc.x\00", align 1
@.str.14 = private unnamed_addr constant [5 x i8] c"pm.y\00", align 1
@.str.15 = private unnamed_addr constant [5 x i8] c"made\00", align 1
@made = internal global i32 0, align 4
@.str.16 = private unnamed_addr constant [20 x i8] c"(c < 0 ? pa : pb).y\00", align 1
@.str.17 = private unnamed_addr constant [5 x i8] c"uc.i\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.pr, align 4
  %8 = alloca %struct.pr, align 4
  %9 = alloca %struct.pr, align 4
  %10 = alloca %struct.pr, align 4
  %11 = alloca %union.un, align 4
  %12 = alloca %union.un, align 4
  %13 = alloca %union.un, align 4
  %14 = alloca %struct.pr, align 4
  store i32 0, ptr %1, align 4
  store i32 1, ptr %2, align 4
  store i32 2, ptr %3, align 4
  %15 = load i32, ptr %2, align 4
  %16 = add nsw i32 %15, 1
  store i32 %16, ptr %2, align 4
  %17 = load i32, ptr %3, align 4
  %18 = add nsw i32 %17, 1
  store i32 %18, ptr %3, align 4
  %19 = load i32, ptr %2, align 4
  %20 = load i32, ptr %3, align 4
  %21 = add nsw i32 %19, %20
  store i32 %21, ptr %4, align 4
  %22 = load i32, ptr %2, align 4
  %23 = icmp sgt i32 %22, 5
  br i1 %23, label %24, label %25

24:                                               ; preds = %0
  br label %26

25:                                               ; preds = %0
  br label %26

26:                                               ; preds = %25, %24
  %27 = phi ptr [ %2, %24 ], [ %3, %25 ]
  store ptr %27, ptr %5, align 8
  %28 = load i32, ptr %4, align 4
  %29 = icmp ne i32 %28, 0
  %30 = zext i1 %29 to i64
  %31 = select i1 %29, ptr @.str, ptr @.str.1
  store ptr %31, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 @__const.main.pa, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %8, ptr align 4 @__const.main.pb, i64 8, i1 false)
  %32 = load i32, ptr %4, align 4
  %33 = icmp sgt i32 %32, 4
  br i1 %33, label %34, label %35

34:                                               ; preds = %26
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %7, i64 8, i1 false)
  br label %36

35:                                               ; preds = %26
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %8, i64 8, i1 false)
  br label %36

36:                                               ; preds = %35, %34
  %37 = load i32, ptr %4, align 4
  %38 = icmp ne i32 %37, 0
  br i1 %38, label %39, label %41

39:                                               ; preds = %36
  %40 = call i64 @mk(i32 noundef 10)
  store i64 %40, ptr %10, align 4
  br label %43

41:                                               ; preds = %36
  %42 = call i64 @mk(i32 noundef 20)
  store i64 %42, ptr %10, align 4
  br label %43

43:                                               ; preds = %41, %39
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 @__const.main.ua, i64 4, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %12, ptr align 4 @__const.main.ub, i64 4, i1 false)
  %44 = load i32, ptr %4, align 4
  %45 = icmp ne i32 %44, 0
  br i1 %45, label %46, label %47

46:                                               ; preds = %43
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 %11, i64 4, i1 false)
  br label %48

47:                                               ; preds = %43
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 %12, i64 4, i1 false)
  br label %48

48:                                               ; preds = %47, %46
  %49 = load i32, ptr %4, align 4
  %50 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i32 noundef %49)
  %51 = load i32, ptr %2, align 4
  %52 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.4, i32 noundef %51)
  %53 = load i32, ptr %3, align 4
  %54 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.5, i32 noundef %53)
  %55 = load ptr, ptr %5, align 8
  %56 = load i32, ptr %55, align 4
  %57 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.6, i32 noundef %56)
  %58 = load i32, ptr %2, align 4
  %59 = icmp ne i32 %58, 0
  br i1 %59, label %60, label %62

60:                                               ; preds = %48
  %61 = load i32, ptr %3, align 4
  br label %64

62:                                               ; preds = %48
  %63 = load i32, ptr %4, align 4
  br label %64

64:                                               ; preds = %62, %60
  %65 = phi i32 [ %61, %60 ], [ %63, %62 ]
  %66 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.7, i32 noundef %65)
  %67 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.8, i32 noundef 3)
  %68 = load ptr, ptr %6, align 8
  %69 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, ptr noundef %68)
  %70 = call i32 (ptr, ...) @printf(ptr noundef @.str.11, ptr noundef @.str.12, double noundef 1.000000e+00)
  %71 = getelementptr inbounds nuw %struct.pr, ptr %9, i32 0, i32 0
  %72 = load i32, ptr %71, align 4
  %73 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.13, i32 noundef %72)
  %74 = getelementptr inbounds nuw %struct.pr, ptr %10, i32 0, i32 1
  %75 = load i32, ptr %74, align 4
  %76 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.14, i32 noundef %75)
  %77 = load i32, ptr @made, align 4
  %78 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.15, i32 noundef %77)
  %79 = load i32, ptr %4, align 4
  %80 = icmp slt i32 %79, 0
  br i1 %80, label %81, label %82

81:                                               ; preds = %64
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %7, i64 8, i1 false)
  br label %83

82:                                               ; preds = %64
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %8, i64 8, i1 false)
  br label %83

83:                                               ; preds = %82, %81
  %84 = getelementptr inbounds nuw %struct.pr, ptr %14, i32 0, i32 1
  %85 = load i32, ptr %84, align 4
  %86 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.16, i32 noundef %85)
  %87 = load i32, ptr %13, align 4
  %88 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.17, i32 noundef %87)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @mk(i32 noundef %0) #0 {
  %2 = alloca %struct.pr, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr @made, align 4
  %5 = add nsw i32 %4, 1
  store i32 %5, ptr @made, align 4
  %6 = getelementptr inbounds nuw %struct.pr, ptr %2, i32 0, i32 0
  %7 = load i32, ptr %3, align 4
  store i32 %7, ptr %6, align 4
  %8 = getelementptr inbounds nuw %struct.pr, ptr %2, i32 0, i32 1
  %9 = load i32, ptr %3, align 4
  %10 = add nsw i32 %9, 1
  store i32 %10, ptr %8, align 4
  %11 = load i64, ptr %2, align 4
  ret i64 %11
}

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
