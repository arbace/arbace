; ModuleID = 'test/c/synth/decl-atomic.c'
source_filename = "test/c/synth/decl-atomic.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"plain\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.3 = private unnamed_addr constant [22 x i8] c"(unsigned long long)b\00", align 1
@.str.4 = private unnamed_addr constant [36 x i8] c"_Generic(a + 0, int: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 1, ptr %2, align 4
  %5 = atomicrmw add ptr %2, i32 4 seq_cst, align 4
  %6 = add i32 %5, 4
  %7 = atomicrmw add ptr %2, i32 1 seq_cst, align 4
  %8 = atomicrmw add ptr %2, i32 1 seq_cst, align 4
  %9 = add i32 %8, 1
  %10 = load atomic i32, ptr %2 seq_cst, align 4
  br label %11

11:                                               ; preds = %11, %0
  %12 = phi i32 [ %10, %0 ], [ %15, %11 ]
  %13 = mul nsw i32 %12, 2
  %14 = cmpxchg ptr %2, i32 %12, i32 %13 seq_cst seq_cst, align 4
  %15 = extractvalue { i32, i1 } %14, 0
  %16 = extractvalue { i32, i1 } %14, 1
  br i1 %16, label %17, label %11

17:                                               ; preds = %11
  store i64 10, ptr %3, align 8
  %18 = atomicrmw sub ptr %3, i64 3 seq_cst, align 8
  %19 = sub i64 %18, 3
  %20 = load atomic i32, ptr %2 seq_cst, align 4
  store i32 %20, ptr %4, align 4
  %21 = load i32, ptr %4, align 4
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %21)
  %23 = load atomic i64, ptr %3 seq_cst, align 8
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i64 noundef %23)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
