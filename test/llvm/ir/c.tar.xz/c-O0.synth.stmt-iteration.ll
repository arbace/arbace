; ModuleID = 'test/c/synth/stmt-iteration.c'
source_filename = "test/c/synth/stmt-iteration.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"w\00", align 1
@.str.2 = private unnamed_addr constant [2 x i8] c"d\00", align 1
@.str.3 = private unnamed_addr constant [2 x i8] c"f\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"j\00", align 1
@.str.5 = private unnamed_addr constant [4 x i8] c"inf\00", align 1
@.str.6 = private unnamed_addr constant [5 x i8] c"skip\00", align 1
@.str.7 = private unnamed_addr constant [6 x i8] c"outer\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  store i32 0, ptr %3, align 4
  br label %15

15:                                               ; preds = %18, %0
  %16 = load i32, ptr %3, align 4
  %17 = icmp slt i32 %16, 4
  br i1 %17, label %18, label %23

18:                                               ; preds = %15
  %19 = load i32, ptr %3, align 4
  %20 = add nsw i32 %19, 1
  store i32 %20, ptr %3, align 4
  %21 = load i32, ptr %2, align 4
  %22 = add nsw i32 %21, %19
  store i32 %22, ptr %2, align 4
  br label %15, !llvm.loop !6

23:                                               ; preds = %15
  store i32 0, ptr %4, align 4
  br label %24

24:                                               ; preds = %27, %23
  %25 = load i32, ptr %4, align 4
  %26 = add nsw i32 %25, 2
  store i32 %26, ptr %4, align 4
  br label %27

27:                                               ; preds = %24
  %28 = load i32, ptr %4, align 4
  %29 = icmp slt i32 %28, 7
  br i1 %29, label %24, label %30, !llvm.loop !8

30:                                               ; preds = %27
  store i32 0, ptr %5, align 4
  store i32 0, ptr %6, align 4
  br label %31

31:                                               ; preds = %38, %30
  %32 = load i32, ptr %6, align 4
  %33 = icmp slt i32 %32, 5
  br i1 %33, label %34, label %41

34:                                               ; preds = %31
  %35 = load i32, ptr %6, align 4
  %36 = load i32, ptr %5, align 4
  %37 = add nsw i32 %36, %35
  store i32 %37, ptr %5, align 4
  br label %38

38:                                               ; preds = %34
  %39 = load i32, ptr %6, align 4
  %40 = add nsw i32 %39, 1
  store i32 %40, ptr %6, align 4
  br label %31, !llvm.loop !9

41:                                               ; preds = %31
  store i32 10, ptr %7, align 4
  br label %42

42:                                               ; preds = %46, %41
  %43 = load i32, ptr %7, align 4
  %44 = icmp sgt i32 %43, 0
  br i1 %44, label %45, label %49

45:                                               ; preds = %42
  br label %46

46:                                               ; preds = %45
  %47 = load i32, ptr %7, align 4
  %48 = sub nsw i32 %47, 3
  store i32 %48, ptr %7, align 4
  br label %42, !llvm.loop !10

49:                                               ; preds = %42
  store i32 0, ptr %8, align 4
  br label %50

50:                                               ; preds = %55, %49
  %51 = load i32, ptr %8, align 4
  %52 = add nsw i32 %51, 1
  store i32 %52, ptr %8, align 4
  %53 = icmp eq i32 %52, 6
  br i1 %53, label %54, label %55

54:                                               ; preds = %50
  br label %56

55:                                               ; preds = %50
  br label %50

56:                                               ; preds = %54
  store i32 0, ptr %9, align 4
  store i32 0, ptr %10, align 4
  store i32 10, ptr %11, align 4
  br label %57

57:                                               ; preds = %70, %56
  %58 = load i32, ptr %10, align 4
  %59 = load i32, ptr %11, align 4
  %60 = icmp slt i32 %58, %59
  br i1 %60, label %61, label %75

61:                                               ; preds = %57
  %62 = load i32, ptr %10, align 4
  %63 = srem i32 %62, 2
  %64 = icmp ne i32 %63, 0
  br i1 %64, label %65, label %66

65:                                               ; preds = %61
  br label %70

66:                                               ; preds = %61
  %67 = load i32, ptr %10, align 4
  %68 = load i32, ptr %9, align 4
  %69 = add nsw i32 %68, %67
  store i32 %69, ptr %9, align 4
  br label %70

70:                                               ; preds = %66, %65
  %71 = load i32, ptr %10, align 4
  %72 = add nsw i32 %71, 1
  store i32 %72, ptr %10, align 4
  %73 = load i32, ptr %11, align 4
  %74 = add nsw i32 %73, -1
  store i32 %74, ptr %11, align 4
  br label %57, !llvm.loop !11

75:                                               ; preds = %57
  store i32 0, ptr %12, align 4
  store i32 0, ptr %13, align 4
  br label %76

76:                                               ; preds = %95, %75
  %77 = load i32, ptr %13, align 4
  %78 = icmp slt i32 %77, 3
  br i1 %78, label %79, label %98

79:                                               ; preds = %76
  store i32 0, ptr %14, align 4
  br label %80

80:                                               ; preds = %91, %79
  %81 = load i32, ptr %14, align 4
  %82 = icmp slt i32 %81, 3
  br i1 %82, label %83, label %94

83:                                               ; preds = %80
  %84 = load i32, ptr %14, align 4
  %85 = load i32, ptr %13, align 4
  %86 = icmp sgt i32 %84, %85
  br i1 %86, label %87, label %88

87:                                               ; preds = %83
  br label %94

88:                                               ; preds = %83
  %89 = load i32, ptr %12, align 4
  %90 = add nsw i32 %89, 1
  store i32 %90, ptr %12, align 4
  br label %91

91:                                               ; preds = %88
  %92 = load i32, ptr %14, align 4
  %93 = add nsw i32 %92, 1
  store i32 %93, ptr %14, align 4
  br label %80, !llvm.loop !12

94:                                               ; preds = %87, %80
  br label %95

95:                                               ; preds = %94
  %96 = load i32, ptr %13, align 4
  %97 = add nsw i32 %96, 1
  store i32 %97, ptr %13, align 4
  br label %76, !llvm.loop !13

98:                                               ; preds = %76
  %99 = load i32, ptr %2, align 4
  %100 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %99)
  %101 = load i32, ptr %4, align 4
  %102 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %101)
  %103 = load i32, ptr %5, align 4
  %104 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %103)
  %105 = load i32, ptr %7, align 4
  %106 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %105)
  %107 = load i32, ptr %8, align 4
  %108 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %107)
  %109 = load i32, ptr %9, align 4
  %110 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %109)
  %111 = load i32, ptr %12, align 4
  %112 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %111)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
