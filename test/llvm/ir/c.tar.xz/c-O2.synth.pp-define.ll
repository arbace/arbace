; ModuleID = 'test/c/synth/pp-define.c'
source_filename = "test/c/synth/pp-define.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"TEN\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"SQ(TEN)\00", align 1
@.str.3 = private unnamed_addr constant [14 x i8] c"ADD(1, SQ(2))\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"STR(a + b)\00", align 1
@.str.6 = private unnamed_addr constant [6 x i8] c"a + b\00", align 1
@.str.7 = private unnamed_addr constant [10 x i8] c"XSTR(TEN)\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"10\00", align 1
@.str.9 = private unnamed_addr constant [11 x i8] c"CAT(TE, N)\00", align 1
@.str.10 = private unnamed_addr constant [13 x i8] c"ID() 5 EMPTY\00", align 1
@.str.11 = private unnamed_addr constant [5 x i8] c"SELF\00", align 1
@.str.12 = private unnamed_addr constant [7 x i8] c"NONE()\00", align 1
@.str.13 = private unnamed_addr constant [13 x i8] c"TWICE(SQ, 3)\00", align 1
@.str.14 = private unnamed_addr constant [5 x i8] c"gone\00", align 1
@.str.15 = private unnamed_addr constant [11 x i8] c"STR(\22q\\n\22)\00", align 1
@.str.16 = private unnamed_addr constant [6 x i8] c"\22q\\n\22\00", align 1
@.str.17 = private unnamed_addr constant [10 x i8] c"CAT(1, 2)\00", align 1

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, i32 noundef 10)
  %2 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.2, i32 noundef 100)
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.3, i32 noundef 5)
  %4 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.5, ptr noundef nonnull @.str.6)
  %5 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.7, ptr noundef nonnull @.str.8)
  %6 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.9, i32 noundef 10)
  %7 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.10, i32 noundef 5)
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.11, i32 noundef 3)
  %9 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.12, i32 noundef 7)
  %10 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.13, i32 noundef 81)
  %11 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.14, i32 noundef 1)
  %12 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, ptr noundef nonnull @.str.15, ptr noundef nonnull @.str.16)
  %13 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.17, i32 noundef 12)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
