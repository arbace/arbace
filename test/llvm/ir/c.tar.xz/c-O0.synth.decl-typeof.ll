; ModuleID = 'test/c/synth/decl-typeof.c'
source_filename = "test/c/synth/decl-typeof.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.arr = private unnamed_addr constant [3 x i32] [i32 1, i32 2, i32 3], align 4
@.str = private unnamed_addr constant [2 x i8] c"a\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@__const.main.sp = private unnamed_addr constant [2 x ptr] [ptr @.str, ptr @.str.1], align 16
@.str.2 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [3 x i8] c"t1\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"t2\00", align 1
@.str.5 = private unnamed_addr constant [42 x i8] c"_Generic(&t1, const int *: 1, default: 0)\00", align 1
@.str.6 = private unnamed_addr constant [36 x i8] c"_Generic(&t2, int *: 1, default: 0)\00", align 1
@.str.7 = private unnamed_addr constant [7 x i8] c"arr[2]\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"fp(2, 3)\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.10 = private unnamed_addr constant [6 x i8] c"sp[1]\00", align 1
@.str.11 = private unnamed_addr constant [42 x i8] c"_Generic(&plain, double *: 1, default: 0)\00", align 1
@.str.12 = private unnamed_addr constant [34 x i8] c"_Generic(f, float: 1, default: 0)\00", align 1
@.str.13 = private unnamed_addr constant [9 x i8] c"(int)b9b\00", align 1
@.str.14 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.15 = private unnamed_addr constant [34 x i8] c"sizeof(typeof(arr)) / sizeof(int)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca [3 x i32], align 4
  %6 = alloca ptr, align 8
  %7 = alloca [2 x ptr], align 16
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca float, align 4
  %11 = alloca i16, align 2
  %12 = alloca i16, align 2
  store i32 0, ptr %1, align 4
  store i32 5, ptr %2, align 4
  store i32 6, ptr %3, align 4
  store i32 7, ptr %4, align 4
  %13 = load i32, ptr %4, align 4
  %14 = add nsw i32 %13, 1
  store i32 %14, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 @__const.main.arr, i64 12, i1 false)
  store ptr @add, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %7, ptr align 16 @__const.main.sp, i64 16, i1 false)
  store volatile double 1.000000e+00, ptr %8, align 8
  store double 2.000000e+00, ptr %9, align 8
  store float 5.000000e-01, ptr %10, align 4
  store i16 3, ptr %11, align 2
  %15 = load i16, ptr %11, align 2
  %16 = trunc i16 %15 to i9
  %17 = sext i9 %16 to i32
  %18 = add nsw i32 %17, 1
  %19 = trunc i32 %18 to i9
  %20 = sext i9 %19 to i16
  store i16 %20, ptr %12, align 2
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i32 noundef 6)
  %22 = load i32, ptr %4, align 4
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.4, i32 noundef %22)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.5, i32 noundef 1)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.6, i32 noundef 1)
  %26 = getelementptr inbounds [3 x i32], ptr %5, i64 0, i64 2
  %27 = load i32, ptr %26, align 4
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.7, i32 noundef %27)
  %29 = load ptr, ptr %6, align 8
  %30 = call i32 %29(i32 noundef 2, i32 noundef 3)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.8, i32 noundef %30)
  %32 = getelementptr inbounds [2 x ptr], ptr %7, i64 0, i64 1
  %33 = load ptr, ptr %32, align 8
  %34 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, ptr noundef %33)
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.11, i32 noundef 1)
  %36 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.12, i32 noundef 1)
  %37 = load i16, ptr %12, align 2
  %38 = trunc i16 %37 to i9
  %39 = sext i9 %38 to i32
  %40 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.13, i32 noundef %39)
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str.14, ptr noundef @.str.15, i64 noundef 3)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @add(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  %6 = load i32, ptr %4, align 4
  %7 = add nsw i32 %5, %6
  ret i32 %7
}

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
