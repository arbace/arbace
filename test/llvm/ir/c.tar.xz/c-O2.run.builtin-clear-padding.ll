; ModuleID = 'test/c/run/builtin-clear-padding.c'
source_filename = "test/c/run/builtin-clear-padding.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i8, i32, i16 }
%struct.B = type { i8, [3 x i8] }
%struct.C = type { i16, i8 }
%union.U = type { %struct.anon }
%struct.anon = type { i8, i32 }
%struct.D = type { [2 x %struct.A], %union.U, i8 }
%struct.E = type { i8, %struct.anon.0, double }
%struct.anon.0 = type { i32, i8 }
%struct.F = type { i8, i8 }

@.str = private unnamed_addr constant [5 x i8] c"%-8s\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"struct A\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c" %02x\00", align 1
@.str.4 = private unnamed_addr constant [36 x i8] c"ff 00 00 00 ff ff ff ff ff ff 00 00\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"struct B\00", align 1
@.str.6 = private unnamed_addr constant [12 x i8] c"11 00 00 00\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"struct C\00", align 1
@.str.8 = private unnamed_addr constant [12 x i8] c"e7 01 ff 00\00", align 1
@.str.9 = private unnamed_addr constant [8 x i8] c"union U\00", align 1
@.str.10 = private unnamed_addr constant [24 x i8] c"ff ff 00 00 ff ff ff ff\00", align 1
@.str.11 = private unnamed_addr constant [9 x i8] c"struct D\00", align 1
@.str.12 = private unnamed_addr constant [108 x i8] c"ff 00 00 00 ff ff ff ff ff ff 00 00 ff 00 00 00 ff ff ff ff ff ff 00 00 ff ff 00 00 ff ff ff ff ff 00 00 00\00", align 1
@.str.13 = private unnamed_addr constant [9 x i8] c"struct E\00", align 1
@.str.14 = private unnamed_addr constant [72 x i8] c"ff 00 00 00 ff ff ff ff ff 00 00 00 00 00 00 00 ff ff ff ff ff ff ff ff\00", align 1
@.str.15 = private unnamed_addr constant [9 x i8] c"struct F\00", align 1
@.str.16 = private unnamed_addr constant [6 x i8] c"0f 03\00", align 1
@.str.17 = private unnamed_addr constant [4 x i8] c"int\00", align 1
@.str.18 = private unnamed_addr constant [12 x i8] c"ff ff ff ff\00", align 1
@.str.19 = private unnamed_addr constant [6 x i8] c"_Bool\00", align 1
@.str.20 = private unnamed_addr constant [3 x i8] c"ff\00", align 1
@.str.21 = private unnamed_addr constant [7 x i8] c"char *\00", align 1
@.str.22 = private unnamed_addr constant [24 x i8] c"ff ff ff ff ff ff ff ff\00", align 1
@.str.23 = private unnamed_addr constant [5 x i8] c"%02x\00", align 1
@main.e = internal unnamed_addr constant [12 x i8] c"\AB\00\00\00\AB\AB\AB\AB\AB\AB\00\00", align 1
@fails = internal unnamed_addr global i32 0, align 4
@.str.24 = private unnamed_addr constant [9 x i8] c"%d %02x\0A\00", align 1
@stderr = external local_unnamed_addr constant ptr, align 8
@.str.25 = private unnamed_addr constant [18 x i8] c"FAIL %s, want %s\0A\00", align 1

; Function Attrs: nounwind sspstrong uwtable
define dso_local range(i32 0, 2) i32 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.A, align 4
  %2 = alloca [12 x i8], align 1
  %3 = alloca [37 x i8], align 16
  %4 = alloca %struct.B, align 4
  %5 = alloca [4 x i8], align 1
  %6 = alloca [13 x i8], align 1
  %7 = alloca %struct.C, align 4
  %8 = alloca [4 x i8], align 1
  %9 = alloca [13 x i8], align 1
  %10 = alloca %union.U, align 8
  %11 = alloca [8 x i8], align 8
  %12 = alloca [25 x i8], align 16
  %13 = alloca %struct.D, align 4
  %14 = alloca [36 x i8], align 16
  %15 = alloca [109 x i8], align 16
  %16 = alloca %struct.E, align 8
  %17 = alloca [24 x i8], align 16
  %18 = alloca [73 x i8], align 16
  %19 = alloca %struct.F, align 2
  %20 = alloca [2 x i8], align 1
  %21 = alloca [7 x i8], align 1
  %22 = alloca i32, align 4
  %23 = alloca [4 x i8], align 1
  %24 = alloca [13 x i8], align 1
  %25 = alloca [4 x i8], align 1
  %26 = alloca ptr, align 8
  %27 = alloca [8 x i8], align 1
  %28 = alloca [25 x i8], align 16
  %29 = alloca [3 x %struct.A], align 16
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #7
  store i8 0, ptr %3, align 16, !tbaa !10
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %1, i8 -1, i64 12, i1 false)
  %30 = getelementptr inbounds nuw i8, ptr %1, i64 1
  store i8 0, ptr %30, align 1
  %31 = getelementptr inbounds nuw i8, ptr %1, i64 2
  store i8 0, ptr %31, align 2
  %32 = getelementptr inbounds nuw i8, ptr %1, i64 3
  store i8 0, ptr %32, align 1
  %33 = getelementptr inbounds nuw i8, ptr %1, i64 10
  store i8 0, ptr %33, align 2
  %34 = getelementptr inbounds nuw i8, ptr %1, i64 11
  store i8 0, ptr %34, align 1
  %35 = icmp ult ptr %2, %1
  %36 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %37 = icmp ugt ptr %36, %1
  %38 = select i1 %35, i1 %37, i1 false
  br i1 %38, label %44, label %39

39:                                               ; preds = %0
  %40 = icmp ult ptr %1, %2
  %41 = getelementptr inbounds nuw i8, ptr %1, i64 12
  %42 = icmp ugt ptr %41, %2
  %43 = select i1 %40, i1 %42, i1 false
  br i1 %43, label %44, label %45

44:                                               ; preds = %39, %0
  call void @llvm.trap()
  unreachable

45:                                               ; preds = %39
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(12) %2, ptr noundef nonnull align 4 dereferenceable(12) %1, i64 12, i1 false)
  %46 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1)
  %47 = load i8, ptr %2, align 1, !tbaa !10
  %48 = zext i8 %47 to i32
  %49 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %48)
  %50 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %3, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %48) #7
  %51 = getelementptr inbounds nuw i8, ptr %2, i64 1
  %52 = load i8, ptr %51, align 1, !tbaa !10
  %53 = zext i8 %52 to i32
  %54 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %53)
  %55 = getelementptr inbounds nuw i8, ptr %3, i64 3
  %56 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %55, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %53) #7
  %57 = getelementptr inbounds nuw i8, ptr %2, i64 2
  %58 = load i8, ptr %57, align 1, !tbaa !10
  %59 = zext i8 %58 to i32
  %60 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %59)
  %61 = getelementptr inbounds nuw i8, ptr %3, i64 6
  %62 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %61, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %59) #7
  %63 = getelementptr inbounds nuw i8, ptr %2, i64 3
  %64 = load i8, ptr %63, align 1, !tbaa !10
  %65 = zext i8 %64 to i32
  %66 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %65)
  %67 = getelementptr inbounds nuw i8, ptr %3, i64 9
  %68 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %67, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %65) #7
  %69 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %70 = load i8, ptr %69, align 1, !tbaa !10
  %71 = zext i8 %70 to i32
  %72 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %71)
  %73 = getelementptr inbounds nuw i8, ptr %3, i64 12
  %74 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %73, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %71) #7
  %75 = getelementptr inbounds nuw i8, ptr %2, i64 5
  %76 = load i8, ptr %75, align 1, !tbaa !10
  %77 = zext i8 %76 to i32
  %78 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %77)
  %79 = getelementptr inbounds nuw i8, ptr %3, i64 15
  %80 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %79, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %77) #7
  %81 = getelementptr inbounds nuw i8, ptr %2, i64 6
  %82 = load i8, ptr %81, align 1, !tbaa !10
  %83 = zext i8 %82 to i32
  %84 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %83)
  %85 = getelementptr inbounds nuw i8, ptr %3, i64 18
  %86 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %85, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %83) #7
  %87 = getelementptr inbounds nuw i8, ptr %2, i64 7
  %88 = load i8, ptr %87, align 1, !tbaa !10
  %89 = zext i8 %88 to i32
  %90 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %89)
  %91 = getelementptr inbounds nuw i8, ptr %3, i64 21
  %92 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %91, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %89) #7
  %93 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %94 = load i8, ptr %93, align 1, !tbaa !10
  %95 = zext i8 %94 to i32
  %96 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %95)
  %97 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %98 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %97, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %95) #7
  %99 = getelementptr inbounds nuw i8, ptr %2, i64 9
  %100 = load i8, ptr %99, align 1, !tbaa !10
  %101 = zext i8 %100 to i32
  %102 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %101)
  %103 = getelementptr inbounds nuw i8, ptr %3, i64 27
  %104 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %103, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %101) #7
  %105 = getelementptr inbounds nuw i8, ptr %2, i64 10
  %106 = load i8, ptr %105, align 1, !tbaa !10
  %107 = zext i8 %106 to i32
  %108 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %107)
  %109 = getelementptr inbounds nuw i8, ptr %3, i64 30
  %110 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %109, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %107) #7
  %111 = getelementptr inbounds nuw i8, ptr %2, i64 11
  %112 = load i8, ptr %111, align 1, !tbaa !10
  %113 = zext i8 %112 to i32
  %114 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %113)
  %115 = getelementptr inbounds nuw i8, ptr %3, i64 33
  %116 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %115, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %113) #7
  %117 = call i32 @putchar(i32 10)
  %118 = getelementptr inbounds nuw i8, ptr %3, i64 1
  %119 = call i32 @bcmp(ptr noundef nonnull dereferenceable(36) %118, ptr noundef nonnull dereferenceable(36) @.str.4, i64 36)
  %120 = icmp eq i32 %119, 0
  br i1 %120, label %126, label %121

121:                                              ; preds = %45
  %122 = load ptr, ptr @stderr, align 8, !tbaa !11
  %123 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %122, ptr noundef nonnull @.str.25, ptr noundef nonnull %118, ptr noundef nonnull @.str.4) #8
  %124 = load i32, ptr @fails, align 4, !tbaa !14
  %125 = add nsw i32 %124, 1
  store i32 %125, ptr @fails, align 4, !tbaa !14
  br label %126

126:                                              ; preds = %45, %121
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #7
  store i8 0, ptr %6, align 1, !tbaa !10
  store i32 17, ptr %4, align 4
  %127 = icmp ult ptr %5, %4
  %128 = getelementptr inbounds nuw i8, ptr %5, i64 4
  %129 = icmp ugt ptr %128, %4
  %130 = select i1 %127, i1 %129, i1 false
  br i1 %130, label %136, label %131

131:                                              ; preds = %126
  %132 = icmp ult ptr %4, %5
  %133 = getelementptr inbounds nuw i8, ptr %4, i64 4
  %134 = icmp ugt ptr %133, %5
  %135 = select i1 %132, i1 %134, i1 false
  br i1 %135, label %136, label %137

136:                                              ; preds = %131, %126
  call void @llvm.trap()
  unreachable

137:                                              ; preds = %131
  %138 = load i32, ptr %4, align 4
  %139 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.5)
  %140 = and i32 %138, 255
  %141 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %140)
  %142 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %6, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %140) #7
  %143 = lshr i32 %138, 8
  %144 = and i32 %143, 255
  %145 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %144)
  %146 = getelementptr inbounds nuw i8, ptr %6, i64 3
  %147 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %146, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %144) #7
  %148 = lshr i32 %138, 16
  %149 = and i32 %148, 255
  %150 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %149)
  %151 = getelementptr inbounds nuw i8, ptr %6, i64 6
  %152 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %151, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %149) #7
  %153 = lshr i32 %138, 24
  %154 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %153)
  %155 = getelementptr inbounds nuw i8, ptr %6, i64 9
  %156 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %155, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %153) #7
  %157 = call i32 @putchar(i32 10)
  %158 = getelementptr inbounds nuw i8, ptr %6, i64 1
  %159 = load i64, ptr %158, align 1
  %160 = xor i64 %159, 3472310704040587569
  %161 = getelementptr i8, ptr %158, i64 8
  %162 = load i32, ptr %161, align 1
  %163 = zext i32 %162 to i64
  %164 = xor i64 %163, 3158048
  %165 = or i64 %160, %164
  %166 = icmp ne i64 %165, 0
  %167 = zext i1 %166 to i32
  %168 = icmp eq i32 %167, 0
  br i1 %168, label %174, label %169

169:                                              ; preds = %137
  %170 = load ptr, ptr @stderr, align 8, !tbaa !11
  %171 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %170, ptr noundef nonnull @.str.25, ptr noundef nonnull %158, ptr noundef nonnull @.str.6) #8
  %172 = load i32, ptr @fails, align 4, !tbaa !14
  %173 = add nsw i32 %172, 1
  store i32 %173, ptr @fails, align 4, !tbaa !14
  br label %174

174:                                              ; preds = %137, %169
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #7
  store i8 0, ptr %9, align 1, !tbaa !10
  store i32 16712167, ptr %7, align 4
  %175 = icmp ult ptr %8, %7
  %176 = getelementptr inbounds nuw i8, ptr %8, i64 4
  %177 = icmp ugt ptr %176, %7
  %178 = select i1 %175, i1 %177, i1 false
  br i1 %178, label %184, label %179

179:                                              ; preds = %174
  %180 = icmp ult ptr %7, %8
  %181 = getelementptr inbounds nuw i8, ptr %7, i64 4
  %182 = icmp ugt ptr %181, %8
  %183 = select i1 %180, i1 %182, i1 false
  br i1 %183, label %184, label %185

184:                                              ; preds = %179, %174
  call void @llvm.trap()
  unreachable

185:                                              ; preds = %179
  %186 = load i32, ptr %7, align 4
  %187 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.7)
  %188 = and i32 %186, 255
  %189 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %188)
  %190 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %9, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %188) #7
  %191 = lshr i32 %186, 8
  %192 = and i32 %191, 255
  %193 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %192)
  %194 = getelementptr inbounds nuw i8, ptr %9, i64 3
  %195 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %194, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %192) #7
  %196 = lshr i32 %186, 16
  %197 = and i32 %196, 255
  %198 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %197)
  %199 = getelementptr inbounds nuw i8, ptr %9, i64 6
  %200 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %199, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %197) #7
  %201 = lshr i32 %186, 24
  %202 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %201)
  %203 = getelementptr inbounds nuw i8, ptr %9, i64 9
  %204 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %203, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %201) #7
  %205 = call i32 @putchar(i32 10)
  %206 = getelementptr inbounds nuw i8, ptr %9, i64 1
  %207 = load i64, ptr %206, align 1
  %208 = xor i64 %207, 7378620435126040421
  %209 = getelementptr i8, ptr %206, i64 8
  %210 = load i32, ptr %209, align 1
  %211 = zext i32 %210 to i64
  %212 = xor i64 %211, 3158048
  %213 = or i64 %208, %212
  %214 = icmp ne i64 %213, 0
  %215 = zext i1 %214 to i32
  %216 = icmp eq i32 %215, 0
  br i1 %216, label %222, label %217

217:                                              ; preds = %185
  %218 = load ptr, ptr @stderr, align 8, !tbaa !11
  %219 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %218, ptr noundef nonnull @.str.25, ptr noundef nonnull %206, ptr noundef nonnull @.str.8) #8
  %220 = load i32, ptr @fails, align 4, !tbaa !14
  %221 = add nsw i32 %220, 1
  store i32 %221, ptr @fails, align 4, !tbaa !14
  br label %222

222:                                              ; preds = %185, %217
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %10) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %11) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %12) #7
  store i8 0, ptr %12, align 16, !tbaa !10
  store i64 -4294901761, ptr %10, align 8
  %223 = icmp ult ptr %11, %10
  %224 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %225 = icmp ugt ptr %224, %10
  %226 = select i1 %223, i1 %225, i1 false
  br i1 %226, label %232, label %227

227:                                              ; preds = %222
  %228 = icmp ult ptr %10, %11
  %229 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %230 = icmp ugt ptr %229, %11
  %231 = select i1 %228, i1 %230, i1 false
  br i1 %231, label %232, label %233

232:                                              ; preds = %227, %222
  call void @llvm.trap()
  unreachable

233:                                              ; preds = %227
  %234 = load i64, ptr %10, align 8
  store i64 %234, ptr %11, align 8
  %235 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.9)
  %236 = trunc i64 %234 to i32
  %237 = and i32 %236, 255
  %238 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %237)
  %239 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %12, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %237) #7
  %240 = trunc i64 %234 to i32
  %241 = lshr i32 %240, 8
  %242 = and i32 %241, 255
  %243 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %242)
  %244 = getelementptr inbounds nuw i8, ptr %12, i64 3
  %245 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %244, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %242) #7
  %246 = trunc i64 %234 to i32
  %247 = lshr i32 %246, 16
  %248 = and i32 %247, 255
  %249 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %248)
  %250 = getelementptr inbounds nuw i8, ptr %12, i64 6
  %251 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %250, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %248) #7
  %252 = trunc i64 %234 to i32
  %253 = lshr i32 %252, 24
  %254 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %253)
  %255 = getelementptr inbounds nuw i8, ptr %12, i64 9
  %256 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %255, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %253) #7
  %257 = lshr i64 %234, 32
  %258 = trunc nuw i64 %257 to i32
  %259 = and i32 %258, 255
  %260 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %259)
  %261 = getelementptr inbounds nuw i8, ptr %12, i64 12
  %262 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %261, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %259) #7
  %263 = lshr i64 %234, 40
  %264 = trunc nuw nsw i64 %263 to i32
  %265 = and i32 %264, 255
  %266 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %265)
  %267 = getelementptr inbounds nuw i8, ptr %12, i64 15
  %268 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %267, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %265) #7
  %269 = lshr i64 %234, 48
  %270 = trunc nuw nsw i64 %269 to i32
  %271 = and i32 %270, 255
  %272 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %271)
  %273 = getelementptr inbounds nuw i8, ptr %12, i64 18
  %274 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %273, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %271) #7
  %275 = lshr i64 %234, 56
  %276 = trunc nuw nsw i64 %275 to i32
  %277 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %276)
  %278 = getelementptr inbounds nuw i8, ptr %12, i64 21
  %279 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %278, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %276) #7
  %280 = call i32 @putchar(i32 10)
  %281 = getelementptr inbounds nuw i8, ptr %12, i64 1
  %282 = load i128, ptr %281, align 1
  %283 = xor i128 %282, 135749485966548458466630816630373901926
  %284 = getelementptr i8, ptr %281, i64 16
  %285 = load i64, ptr %284, align 1
  %286 = zext i64 %285 to i128
  %287 = xor i128 %286, 28822736967442534
  %288 = or i128 %283, %287
  %289 = icmp ne i128 %288, 0
  %290 = zext i1 %289 to i32
  %291 = icmp eq i32 %290, 0
  br i1 %291, label %297, label %292

292:                                              ; preds = %233
  %293 = load ptr, ptr @stderr, align 8, !tbaa !11
  %294 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %293, ptr noundef nonnull @.str.25, ptr noundef nonnull %281, ptr noundef nonnull @.str.10) #8
  %295 = load i32, ptr @fails, align 4, !tbaa !14
  %296 = add nsw i32 %295, 1
  store i32 %296, ptr @fails, align 4, !tbaa !14
  br label %297

297:                                              ; preds = %233, %292
  call void @llvm.lifetime.end.p0(ptr nonnull %12) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %11) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %10) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %13) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %14) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %15) #7
  store i8 0, ptr %15, align 16, !tbaa !10
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(36) %13, i8 -1, i64 36, i1 false)
  %298 = getelementptr inbounds nuw i8, ptr %13, i64 1
  store i8 0, ptr %298, align 1
  %299 = getelementptr inbounds nuw i8, ptr %13, i64 2
  store i8 0, ptr %299, align 2
  %300 = getelementptr inbounds nuw i8, ptr %13, i64 3
  store i8 0, ptr %300, align 1
  %301 = getelementptr inbounds nuw i8, ptr %13, i64 10
  store i8 0, ptr %301, align 2
  %302 = getelementptr inbounds nuw i8, ptr %13, i64 11
  store i8 0, ptr %302, align 1
  %303 = getelementptr inbounds nuw i8, ptr %13, i64 13
  store i8 0, ptr %303, align 1
  %304 = getelementptr inbounds nuw i8, ptr %13, i64 14
  store i8 0, ptr %304, align 2
  %305 = getelementptr inbounds nuw i8, ptr %13, i64 15
  store i8 0, ptr %305, align 1
  %306 = getelementptr inbounds nuw i8, ptr %13, i64 22
  store i8 0, ptr %306, align 2
  %307 = getelementptr inbounds nuw i8, ptr %13, i64 23
  store i8 0, ptr %307, align 1
  %308 = getelementptr inbounds nuw i8, ptr %13, i64 26
  store i8 0, ptr %308, align 2
  %309 = getelementptr inbounds nuw i8, ptr %13, i64 27
  store i8 0, ptr %309, align 1
  %310 = getelementptr inbounds nuw i8, ptr %13, i64 33
  store i8 0, ptr %310, align 1
  %311 = getelementptr inbounds nuw i8, ptr %13, i64 34
  store i8 0, ptr %311, align 2
  %312 = getelementptr inbounds nuw i8, ptr %13, i64 35
  store i8 0, ptr %312, align 1
  %313 = icmp ult ptr %14, %13
  %314 = getelementptr inbounds nuw i8, ptr %14, i64 36
  %315 = icmp ugt ptr %314, %13
  %316 = select i1 %313, i1 %315, i1 false
  br i1 %316, label %322, label %317

317:                                              ; preds = %297
  %318 = icmp ult ptr %13, %14
  %319 = getelementptr inbounds nuw i8, ptr %13, i64 36
  %320 = icmp ugt ptr %319, %14
  %321 = select i1 %318, i1 %320, i1 false
  br i1 %321, label %322, label %323

322:                                              ; preds = %317, %297
  call void @llvm.trap()
  unreachable

323:                                              ; preds = %317
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(36) %14, ptr noundef nonnull align 4 dereferenceable(36) %13, i64 36, i1 false)
  %324 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.11)
  br label %352

325:                                              ; preds = %352
  %326 = call i32 @putchar(i32 10)
  %327 = getelementptr inbounds nuw i8, ptr %15, i64 1
  %328 = call i32 @bcmp(ptr noundef nonnull dereferenceable(108) %327, ptr noundef nonnull dereferenceable(108) @.str.12, i64 108)
  %329 = icmp eq i32 %328, 0
  br i1 %329, label %335, label %330

330:                                              ; preds = %325
  %331 = load ptr, ptr @stderr, align 8, !tbaa !11
  %332 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %331, ptr noundef nonnull @.str.25, ptr noundef nonnull %327, ptr noundef nonnull @.str.12) #8
  %333 = load i32, ptr @fails, align 4, !tbaa !14
  %334 = add nsw i32 %333, 1
  store i32 %334, ptr @fails, align 4, !tbaa !14
  br label %335

335:                                              ; preds = %325, %330
  call void @llvm.lifetime.end.p0(ptr nonnull %15) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %14) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %13) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %16) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %17) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %18) #7
  store i8 0, ptr %18, align 16, !tbaa !10
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %16, i8 -1, i64 24, i1 false)
  %336 = getelementptr inbounds nuw i8, ptr %16, i64 1
  store i8 0, ptr %336, align 1
  %337 = getelementptr inbounds nuw i8, ptr %16, i64 2
  store i8 0, ptr %337, align 2
  %338 = getelementptr inbounds nuw i8, ptr %16, i64 3
  store i8 0, ptr %338, align 1
  %339 = getelementptr inbounds nuw i8, ptr %16, i64 9
  %340 = icmp ult ptr %17, %16
  %341 = getelementptr inbounds nuw i8, ptr %17, i64 24
  %342 = icmp ugt ptr %341, %16
  %343 = select i1 %340, i1 %342, i1 false
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %339, i8 0, i64 7, i1 false)
  br i1 %343, label %349, label %344

344:                                              ; preds = %335
  %345 = icmp ult ptr %16, %17
  %346 = getelementptr inbounds nuw i8, ptr %16, i64 24
  %347 = icmp ugt ptr %346, %17
  %348 = select i1 %345, i1 %347, i1 false
  br i1 %348, label %349, label %350

349:                                              ; preds = %344, %335
  call void @llvm.trap()
  unreachable

350:                                              ; preds = %344
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(24) %17, ptr noundef nonnull align 8 dereferenceable(24) %16, i64 24, i1 false)
  %351 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.13)
  br label %408

352:                                              ; preds = %323, %352
  %353 = phi i64 [ 0, %323 ], [ %361, %352 ]
  %354 = getelementptr inbounds nuw i8, ptr %14, i64 %353
  %355 = load i8, ptr %354, align 1, !tbaa !10
  %356 = zext i8 %355 to i32
  %357 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %356)
  %358 = mul nuw nsw i64 %353, 3
  %359 = getelementptr inbounds nuw i8, ptr %15, i64 %358
  %360 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %359, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %356) #7
  %361 = add nuw nsw i64 %353, 1
  %362 = icmp eq i64 %361, 36
  br i1 %362, label %325, label %352, !llvm.loop !15

363:                                              ; preds = %408
  %364 = call i32 @putchar(i32 10)
  %365 = getelementptr inbounds nuw i8, ptr %18, i64 1
  %366 = call i32 @bcmp(ptr noundef nonnull dereferenceable(72) %365, ptr noundef nonnull dereferenceable(72) @.str.14, i64 72)
  %367 = icmp eq i32 %366, 0
  br i1 %367, label %373, label %368

368:                                              ; preds = %363
  %369 = load ptr, ptr @stderr, align 8, !tbaa !11
  %370 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %369, ptr noundef nonnull @.str.25, ptr noundef nonnull %365, ptr noundef nonnull @.str.14) #8
  %371 = load i32, ptr @fails, align 4, !tbaa !14
  %372 = add nsw i32 %371, 1
  store i32 %372, ptr @fails, align 4, !tbaa !14
  br label %373

373:                                              ; preds = %363, %368
  call void @llvm.lifetime.end.p0(ptr nonnull %18) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %17) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %16) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %19) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %20) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %21) #7
  store i8 0, ptr %21, align 1, !tbaa !10
  store i16 783, ptr %19, align 2
  %374 = icmp ult ptr %20, %19
  %375 = getelementptr inbounds nuw i8, ptr %20, i64 2
  %376 = icmp ugt ptr %375, %19
  %377 = select i1 %374, i1 %376, i1 false
  br i1 %377, label %383, label %378

378:                                              ; preds = %373
  %379 = icmp ult ptr %19, %20
  %380 = getelementptr inbounds nuw i8, ptr %19, i64 2
  %381 = icmp ugt ptr %380, %20
  %382 = select i1 %379, i1 %381, i1 false
  br i1 %382, label %383, label %384

383:                                              ; preds = %378, %373
  call void @llvm.trap()
  unreachable

384:                                              ; preds = %378
  %385 = load i16, ptr %19, align 2
  %386 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.15)
  %387 = and i16 %385, 255
  %388 = zext nneg i16 %387 to i32
  %389 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %388)
  %390 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %21, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %388) #7
  %391 = lshr i16 %385, 8
  %392 = zext nneg i16 %391 to i32
  %393 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %392)
  %394 = getelementptr inbounds nuw i8, ptr %21, i64 3
  %395 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %394, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %392) #7
  %396 = call i32 @putchar(i32 10)
  %397 = getelementptr inbounds nuw i8, ptr %21, i64 1
  %398 = load i32, ptr %397, align 1
  %399 = xor i32 %398, 807429680
  %400 = getelementptr i8, ptr %397, i64 4
  %401 = load i16, ptr %400, align 1
  %402 = zext i16 %401 to i32
  %403 = xor i32 %402, 51
  %404 = or i32 %399, %403
  %405 = icmp ne i32 %404, 0
  %406 = zext i1 %405 to i32
  %407 = icmp eq i32 %406, 0
  br i1 %407, label %424, label %419

408:                                              ; preds = %350, %408
  %409 = phi i64 [ 0, %350 ], [ %417, %408 ]
  %410 = getelementptr inbounds nuw i8, ptr %17, i64 %409
  %411 = load i8, ptr %410, align 1, !tbaa !10
  %412 = zext i8 %411 to i32
  %413 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %412)
  %414 = mul nuw nsw i64 %409, 3
  %415 = getelementptr inbounds nuw i8, ptr %18, i64 %414
  %416 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %415, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %412) #7
  %417 = add nuw nsw i64 %409, 1
  %418 = icmp eq i64 %417, 24
  br i1 %418, label %363, label %408, !llvm.loop !17

419:                                              ; preds = %384
  %420 = load ptr, ptr @stderr, align 8, !tbaa !11
  %421 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %420, ptr noundef nonnull @.str.25, ptr noundef nonnull %397, ptr noundef nonnull @.str.16) #8
  %422 = load i32, ptr @fails, align 4, !tbaa !14
  %423 = add nsw i32 %422, 1
  store i32 %423, ptr @fails, align 4, !tbaa !14
  br label %424

424:                                              ; preds = %384, %419
  call void @llvm.lifetime.end.p0(ptr nonnull %21) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %20) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %19) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %22) #7
  store i32 0, ptr %22, align 4, !tbaa !14
  call void @llvm.lifetime.start.p0(ptr nonnull %23) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %24) #7
  store i8 0, ptr %24, align 1, !tbaa !10
  %425 = icmp ult ptr %23, %22
  %426 = getelementptr inbounds nuw i8, ptr %23, i64 4
  %427 = icmp ugt ptr %426, %22
  %428 = select i1 %425, i1 %427, i1 false
  br i1 %428, label %434, label %429

429:                                              ; preds = %424
  %430 = icmp ult ptr %22, %23
  %431 = getelementptr inbounds nuw i8, ptr %22, i64 4
  %432 = icmp ugt ptr %431, %23
  %433 = select i1 %430, i1 %432, i1 false
  br i1 %433, label %434, label %435

434:                                              ; preds = %429, %424
  call void @llvm.trap()
  unreachable

435:                                              ; preds = %429
  %436 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.17)
  %437 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %438 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %24, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %439 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %440 = getelementptr inbounds nuw i8, ptr %24, i64 3
  %441 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %440, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %442 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %443 = getelementptr inbounds nuw i8, ptr %24, i64 6
  %444 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %443, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %445 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %446 = getelementptr inbounds nuw i8, ptr %24, i64 9
  %447 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %446, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %448 = call i32 @putchar(i32 10)
  %449 = getelementptr inbounds nuw i8, ptr %24, i64 1
  %450 = load i64, ptr %449, align 1
  %451 = xor i64 %450, 7378620663665288806
  %452 = getelementptr i8, ptr %449, i64 8
  %453 = load i32, ptr %452, align 1
  %454 = zext i32 %453 to i64
  %455 = xor i64 %454, 6710816
  %456 = or i64 %451, %455
  %457 = icmp ne i64 %456, 0
  %458 = zext i1 %457 to i32
  %459 = icmp eq i32 %458, 0
  br i1 %459, label %465, label %460

460:                                              ; preds = %435
  %461 = load ptr, ptr @stderr, align 8, !tbaa !11
  %462 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %461, ptr noundef nonnull @.str.25, ptr noundef nonnull %449, ptr noundef nonnull @.str.18) #8
  %463 = load i32, ptr @fails, align 4, !tbaa !14
  %464 = add nsw i32 %463, 1
  store i32 %464, ptr @fails, align 4, !tbaa !14
  br label %465

465:                                              ; preds = %435, %460
  call void @llvm.lifetime.end.p0(ptr nonnull %24) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %23) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %22) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %25) #7
  store i8 0, ptr %25, align 1, !tbaa !10
  %466 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.19)
  %467 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %468 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %25, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %469 = call i32 @putchar(i32 10)
  %470 = getelementptr inbounds nuw i8, ptr %25, i64 1
  %471 = load i16, ptr %470, align 1
  %472 = xor i16 %471, 26214
  %473 = getelementptr i8, ptr %470, i64 2
  %474 = load i8, ptr %473, align 1
  %475 = zext i8 %474 to i16
  %476 = or i16 %472, %475
  %477 = icmp ne i16 %476, 0
  %478 = zext i1 %477 to i32
  %479 = icmp eq i32 %478, 0
  br i1 %479, label %485, label %480

480:                                              ; preds = %465
  %481 = load ptr, ptr @stderr, align 8, !tbaa !11
  %482 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %481, ptr noundef nonnull @.str.25, ptr noundef nonnull %470, ptr noundef nonnull @.str.20) #8
  %483 = load i32, ptr @fails, align 4, !tbaa !14
  %484 = add nsw i32 %483, 1
  store i32 %484, ptr @fails, align 4, !tbaa !14
  br label %485

485:                                              ; preds = %465, %480
  call void @llvm.lifetime.end.p0(ptr nonnull %25) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %26) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %27) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %28) #7
  store i8 0, ptr %28, align 16, !tbaa !10
  %486 = icmp ult ptr %27, %26
  %487 = getelementptr inbounds nuw i8, ptr %27, i64 8
  %488 = icmp ugt ptr %487, %26
  %489 = select i1 %486, i1 %488, i1 false
  br i1 %489, label %495, label %490

490:                                              ; preds = %485
  %491 = icmp ult ptr %26, %27
  %492 = getelementptr inbounds nuw i8, ptr %26, i64 8
  %493 = icmp ugt ptr %492, %27
  %494 = select i1 %491, i1 %493, i1 false
  br i1 %494, label %495, label %496

495:                                              ; preds = %490, %485
  call void @llvm.trap()
  unreachable

496:                                              ; preds = %490
  %497 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.21)
  %498 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %499 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %28, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %500 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %501 = getelementptr inbounds nuw i8, ptr %28, i64 3
  %502 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %501, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %503 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %504 = getelementptr inbounds nuw i8, ptr %28, i64 6
  %505 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %504, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %506 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %507 = getelementptr inbounds nuw i8, ptr %28, i64 9
  %508 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %507, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %509 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %510 = getelementptr inbounds nuw i8, ptr %28, i64 12
  %511 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %510, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %512 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %513 = getelementptr inbounds nuw i8, ptr %28, i64 15
  %514 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %513, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %515 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %516 = getelementptr inbounds nuw i8, ptr %28, i64 18
  %517 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %516, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %518 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %519 = getelementptr inbounds nuw i8, ptr %28, i64 21
  %520 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef nonnull dereferenceable(1) %519, ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255) #7
  %521 = call i32 @putchar(i32 10)
  %522 = getelementptr inbounds nuw i8, ptr %28, i64 1
  %523 = load i128, ptr %522, align 1
  %524 = xor i128 %523, 135749485966613995472586391293440058982
  %525 = getelementptr i8, ptr %522, i64 16
  %526 = load i64, ptr %525, align 1
  %527 = zext i64 %526 to i128
  %528 = xor i128 %527, 28822736967442534
  %529 = or i128 %524, %528
  %530 = icmp ne i128 %529, 0
  %531 = zext i1 %530 to i32
  %532 = icmp eq i32 %531, 0
  br i1 %532, label %538, label %533

533:                                              ; preds = %496
  %534 = load ptr, ptr @stderr, align 8, !tbaa !11
  %535 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %534, ptr noundef nonnull @.str.25, ptr noundef nonnull %522, ptr noundef nonnull @.str.22) #8
  %536 = load i32, ptr @fails, align 4, !tbaa !14
  %537 = add nsw i32 %536, 1
  store i32 %537, ptr @fails, align 4, !tbaa !14
  br label %538

538:                                              ; preds = %496, %533
  call void @llvm.lifetime.end.p0(ptr nonnull %28) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %27) #7
  call void @llvm.lifetime.end.p0(ptr nonnull %26) #7
  call void @llvm.lifetime.start.p0(ptr nonnull %29) #7
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(36) %29, i8 -85, i64 36, i1 false)
  %539 = getelementptr inbounds nuw i8, ptr %29, i64 1
  store i8 0, ptr %539, align 1
  %540 = getelementptr inbounds nuw i8, ptr %29, i64 2
  store i8 0, ptr %540, align 2
  %541 = getelementptr inbounds nuw i8, ptr %29, i64 3
  store i8 0, ptr %541, align 1
  %542 = getelementptr inbounds nuw i8, ptr %29, i64 10
  store i8 0, ptr %542, align 2
  %543 = getelementptr inbounds nuw i8, ptr %29, i64 11
  store i8 0, ptr %543, align 1
  %544 = getelementptr inbounds nuw i8, ptr %29, i64 13
  store i8 0, ptr %544, align 1
  %545 = getelementptr inbounds nuw i8, ptr %29, i64 14
  store i8 0, ptr %545, align 2
  %546 = getelementptr inbounds nuw i8, ptr %29, i64 15
  store i8 0, ptr %546, align 1
  %547 = getelementptr inbounds nuw i8, ptr %29, i64 22
  store i8 0, ptr %547, align 2
  %548 = getelementptr inbounds nuw i8, ptr %29, i64 23
  store i8 0, ptr %548, align 1
  %549 = getelementptr inbounds nuw i8, ptr %29, i64 25
  store i8 0, ptr %549, align 1
  %550 = getelementptr inbounds nuw i8, ptr %29, i64 26
  store i8 0, ptr %550, align 2
  %551 = getelementptr inbounds nuw i8, ptr %29, i64 27
  store i8 0, ptr %551, align 1
  %552 = getelementptr inbounds nuw i8, ptr %29, i64 34
  store i8 0, ptr %552, align 2
  %553 = getelementptr inbounds nuw i8, ptr %29, i64 35
  store i8 0, ptr %553, align 1
  %554 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef 171)
  %555 = load i8, ptr %539, align 1, !tbaa !10
  %556 = zext i8 %555 to i32
  %557 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %556)
  %558 = load i8, ptr %540, align 2, !tbaa !10
  %559 = zext i8 %558 to i32
  %560 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %559)
  %561 = load i8, ptr %541, align 1, !tbaa !10
  %562 = zext i8 %561 to i32
  %563 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %562)
  %564 = getelementptr inbounds nuw i8, ptr %29, i64 4
  %565 = load i8, ptr %564, align 4, !tbaa !10
  %566 = zext i8 %565 to i32
  %567 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %566)
  %568 = getelementptr inbounds nuw i8, ptr %29, i64 5
  %569 = load i8, ptr %568, align 1, !tbaa !10
  %570 = zext i8 %569 to i32
  %571 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %570)
  %572 = getelementptr inbounds nuw i8, ptr %29, i64 6
  %573 = load i8, ptr %572, align 2, !tbaa !10
  %574 = zext i8 %573 to i32
  %575 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %574)
  %576 = getelementptr inbounds nuw i8, ptr %29, i64 7
  %577 = load i8, ptr %576, align 1, !tbaa !10
  %578 = zext i8 %577 to i32
  %579 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %578)
  %580 = getelementptr inbounds nuw i8, ptr %29, i64 8
  %581 = load i8, ptr %580, align 8, !tbaa !10
  %582 = zext i8 %581 to i32
  %583 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %582)
  %584 = getelementptr inbounds nuw i8, ptr %29, i64 9
  %585 = load i8, ptr %584, align 1, !tbaa !10
  %586 = zext i8 %585 to i32
  %587 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %586)
  %588 = load i8, ptr %542, align 2, !tbaa !10
  %589 = zext i8 %588 to i32
  %590 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %589)
  %591 = load i8, ptr %543, align 1, !tbaa !10
  %592 = zext i8 %591 to i32
  %593 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %592)
  %594 = getelementptr inbounds nuw i8, ptr %29, i64 12
  %595 = load i8, ptr %594, align 4, !tbaa !10
  %596 = zext i8 %595 to i32
  %597 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %596)
  %598 = load i8, ptr %544, align 1, !tbaa !10
  %599 = zext i8 %598 to i32
  %600 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %599)
  %601 = load i8, ptr %545, align 2, !tbaa !10
  %602 = zext i8 %601 to i32
  %603 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %602)
  %604 = load i8, ptr %546, align 1, !tbaa !10
  %605 = zext i8 %604 to i32
  %606 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %605)
  %607 = getelementptr inbounds nuw i8, ptr %29, i64 16
  %608 = load i8, ptr %607, align 16, !tbaa !10
  %609 = zext i8 %608 to i32
  %610 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %609)
  %611 = getelementptr inbounds nuw i8, ptr %29, i64 17
  %612 = load i8, ptr %611, align 1, !tbaa !10
  %613 = zext i8 %612 to i32
  %614 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %613)
  %615 = getelementptr inbounds nuw i8, ptr %29, i64 18
  %616 = load i8, ptr %615, align 2, !tbaa !10
  %617 = zext i8 %616 to i32
  %618 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %617)
  %619 = getelementptr inbounds nuw i8, ptr %29, i64 19
  %620 = load i8, ptr %619, align 1, !tbaa !10
  %621 = zext i8 %620 to i32
  %622 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %621)
  %623 = getelementptr inbounds nuw i8, ptr %29, i64 20
  %624 = load i8, ptr %623, align 4, !tbaa !10
  %625 = zext i8 %624 to i32
  %626 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %625)
  %627 = getelementptr inbounds nuw i8, ptr %29, i64 21
  %628 = load i8, ptr %627, align 1, !tbaa !10
  %629 = zext i8 %628 to i32
  %630 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %629)
  %631 = load i8, ptr %547, align 2, !tbaa !10
  %632 = zext i8 %631 to i32
  %633 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %632)
  %634 = load i8, ptr %548, align 1, !tbaa !10
  %635 = zext i8 %634 to i32
  %636 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %635)
  %637 = getelementptr inbounds nuw i8, ptr %29, i64 24
  %638 = load i8, ptr %637, align 8, !tbaa !10
  %639 = zext i8 %638 to i32
  %640 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %639)
  %641 = load i8, ptr %549, align 1, !tbaa !10
  %642 = zext i8 %641 to i32
  %643 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %642)
  %644 = load i8, ptr %550, align 2, !tbaa !10
  %645 = zext i8 %644 to i32
  %646 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %645)
  %647 = load i8, ptr %551, align 1, !tbaa !10
  %648 = zext i8 %647 to i32
  %649 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %648)
  %650 = getelementptr inbounds nuw i8, ptr %29, i64 28
  %651 = load i8, ptr %650, align 4, !tbaa !10
  %652 = zext i8 %651 to i32
  %653 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %652)
  %654 = getelementptr inbounds nuw i8, ptr %29, i64 29
  %655 = load i8, ptr %654, align 1, !tbaa !10
  %656 = zext i8 %655 to i32
  %657 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %656)
  %658 = getelementptr inbounds nuw i8, ptr %29, i64 30
  %659 = load i8, ptr %658, align 2, !tbaa !10
  %660 = zext i8 %659 to i32
  %661 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %660)
  %662 = getelementptr inbounds nuw i8, ptr %29, i64 31
  %663 = load i8, ptr %662, align 1, !tbaa !10
  %664 = zext i8 %663 to i32
  %665 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %664)
  %666 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %667 = load i8, ptr %666, align 16, !tbaa !10
  %668 = zext i8 %667 to i32
  %669 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %668)
  %670 = getelementptr inbounds nuw i8, ptr %29, i64 33
  %671 = load i8, ptr %670, align 1, !tbaa !10
  %672 = zext i8 %671 to i32
  %673 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %672)
  %674 = load i8, ptr %552, align 2, !tbaa !10
  %675 = zext i8 %674 to i32
  %676 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %675)
  %677 = load i8, ptr %553, align 1, !tbaa !10
  %678 = zext i8 %677 to i32
  %679 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.23, i32 noundef %678)
  %680 = call i32 @putchar(i32 10)
  %681 = load i32, ptr @fails, align 4
  br label %682

682:                                              ; preds = %708, %538
  %683 = phi i64 [ 0, %538 ], [ %710, %708 ]
  %684 = phi i32 [ %681, %538 ], [ %709, %708 ]
  %685 = getelementptr inbounds nuw i8, ptr %29, i64 %683
  %686 = load i8, ptr %685, align 2, !tbaa !10
  %687 = trunc i64 %683 to i8
  %688 = urem i8 %687, 12
  %689 = zext nneg i8 %688 to i64
  %690 = getelementptr inbounds nuw i8, ptr @main.e, i64 %689
  %691 = load i8, ptr %690, align 1, !tbaa !10
  %692 = icmp eq i8 %686, %691
  br i1 %692, label %695, label %693

693:                                              ; preds = %682
  %694 = add nsw i32 %684, 1
  store i32 %694, ptr @fails, align 4, !tbaa !14
  br label %695

695:                                              ; preds = %682, %693
  %696 = phi i32 [ %684, %682 ], [ %694, %693 ]
  %697 = or disjoint i64 %683, 1
  %698 = getelementptr inbounds nuw i8, ptr %29, i64 %697
  %699 = load i8, ptr %698, align 1, !tbaa !10
  %700 = trunc i64 %697 to i8
  %701 = urem i8 %700, 12
  %702 = zext nneg i8 %701 to i64
  %703 = getelementptr inbounds nuw i8, ptr @main.e, i64 %702
  %704 = load i8, ptr %703, align 1, !tbaa !10
  %705 = icmp eq i8 %699, %704
  br i1 %705, label %708, label %706

706:                                              ; preds = %695
  %707 = add nsw i32 %696, 1
  store i32 %707, ptr @fails, align 4, !tbaa !14
  br label %708

708:                                              ; preds = %706, %695
  %709 = phi i32 [ %696, %695 ], [ %707, %706 ]
  %710 = add nuw nsw i64 %683, 2
  %711 = icmp eq i64 %710, 36
  br i1 %711, label %712, label %682, !llvm.loop !18

712:                                              ; preds = %708
  call void @llvm.lifetime.end.p0(ptr nonnull %29) #7
  %713 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.24, i32 noundef 1, i32 noundef 0)
  %714 = load i32, ptr @fails, align 4, !tbaa !14
  %715 = icmp ne i32 %714, 0
  %716 = zext i1 %715 to i32
  ret i32 %716
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare noundef i32 @sprintf(ptr noalias noundef writeonly captures(none), ptr noundef readonly captures(none), ...) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: nofree nounwind
declare noundef i32 @fprintf(ptr noundef captures(none), ptr noundef readonly captures(none), ...) local_unnamed_addr #3

; Function Attrs: nofree nounwind
declare noundef i32 @putchar(i32 noundef) local_unnamed_addr #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #6

attributes #0 = { nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #5 = { nofree nounwind }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #7 = { nounwind }
attributes #8 = { cold nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!8, !8, i64 0}
!11 = !{!12, !12, i64 0}
!12 = !{!"p1 _ZTS8_IO_FILE", !13, i64 0}
!13 = !{!"any pointer", !8, i64 0}
!14 = !{!7, !7, i64 0}
!15 = distinct !{!15, !16}
!16 = !{!"llvm.loop.mustprogress"}
!17 = distinct !{!17, !16}
!18 = distinct !{!18, !16}
