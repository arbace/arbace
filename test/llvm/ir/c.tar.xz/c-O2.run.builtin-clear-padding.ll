; ModuleID = 'test/c/run/builtin-clear-padding.c'
source_filename = "test/c/run/builtin-clear-padding.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i8, i32, i16 }
%struct.B = type { i8, [3 x i8] }
%struct.C = type { i16, i8 }
%union.U = type { %struct.anon }
%struct.anon = type { i8, i32 }
%struct.D = type { [2 x %struct.A], %union.U, i8 }
%struct.E = type { i8, %struct.anon.0, double }
%struct.anon.0 = type { i32, i8 }
%struct.F = type { i8, i8 }

@.str = private unnamed_addr constant [5 x i8] c"%-8s\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"struct A\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c" %02x\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"struct B\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"struct C\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"union U\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"struct D\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"struct E\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"struct F\00", align 1
@.str.10 = private unnamed_addr constant [4 x i8] c"int\00", align 1
@.str.11 = private unnamed_addr constant [6 x i8] c"_Bool\00", align 1
@.str.12 = private unnamed_addr constant [7 x i8] c"char *\00", align 1
@.str.13 = private unnamed_addr constant [5 x i8] c"%02x\00", align 1
@.str.14 = private unnamed_addr constant [9 x i8] c"%d %02x\0A\00", align 1

; Function Attrs: nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.A, align 4
  %2 = alloca [12 x i8], align 1
  %3 = alloca %struct.B, align 4
  %4 = alloca [4 x i8], align 1
  %5 = alloca %struct.C, align 4
  %6 = alloca [4 x i8], align 1
  %7 = alloca %union.U, align 8
  %8 = alloca [8 x i8], align 1
  %9 = alloca %struct.D, align 4
  %10 = alloca [36 x i8], align 16
  %11 = alloca %struct.E, align 8
  %12 = alloca [24 x i8], align 16
  %13 = alloca %struct.F, align 2
  %14 = alloca [2 x i8], align 1
  %15 = alloca i32, align 4
  %16 = alloca [4 x i8], align 1
  %17 = alloca ptr, align 8
  %18 = alloca [8 x i8], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(12) %1, i8 -1, i64 12, i1 false)
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 1
  store i8 0, ptr %19, align 1
  %20 = getelementptr inbounds nuw i8, ptr %1, i64 2
  store i8 0, ptr %20, align 2
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 3
  store i8 0, ptr %21, align 1
  %22 = getelementptr inbounds nuw i8, ptr %1, i64 10
  store i8 0, ptr %22, align 2
  %23 = getelementptr inbounds nuw i8, ptr %1, i64 11
  store i8 0, ptr %23, align 1
  %24 = icmp ult ptr %2, %1
  %25 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %26 = icmp ugt ptr %25, %1
  %27 = select i1 %24, i1 %26, i1 false
  br i1 %27, label %33, label %28

28:                                               ; preds = %0
  %29 = icmp ult ptr %1, %2
  %30 = getelementptr inbounds nuw i8, ptr %1, i64 12
  %31 = icmp ugt ptr %30, %2
  %32 = select i1 %29, i1 %31, i1 false
  br i1 %32, label %33, label %34

33:                                               ; preds = %28, %0
  call void @llvm.trap()
  unreachable

34:                                               ; preds = %28
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(12) %2, ptr noundef nonnull align 4 dereferenceable(12) %1, i64 12, i1 false)
  %35 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1)
  %36 = load i8, ptr %2, align 1, !tbaa !10
  %37 = zext i8 %36 to i32
  %38 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %37)
  %39 = getelementptr inbounds nuw i8, ptr %2, i64 1
  %40 = load i8, ptr %39, align 1, !tbaa !10
  %41 = zext i8 %40 to i32
  %42 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %41)
  %43 = getelementptr inbounds nuw i8, ptr %2, i64 2
  %44 = load i8, ptr %43, align 1, !tbaa !10
  %45 = zext i8 %44 to i32
  %46 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %45)
  %47 = getelementptr inbounds nuw i8, ptr %2, i64 3
  %48 = load i8, ptr %47, align 1, !tbaa !10
  %49 = zext i8 %48 to i32
  %50 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %49)
  %51 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %52 = load i8, ptr %51, align 1, !tbaa !10
  %53 = zext i8 %52 to i32
  %54 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %53)
  %55 = getelementptr inbounds nuw i8, ptr %2, i64 5
  %56 = load i8, ptr %55, align 1, !tbaa !10
  %57 = zext i8 %56 to i32
  %58 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %57)
  %59 = getelementptr inbounds nuw i8, ptr %2, i64 6
  %60 = load i8, ptr %59, align 1, !tbaa !10
  %61 = zext i8 %60 to i32
  %62 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %61)
  %63 = getelementptr inbounds nuw i8, ptr %2, i64 7
  %64 = load i8, ptr %63, align 1, !tbaa !10
  %65 = zext i8 %64 to i32
  %66 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %65)
  %67 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %68 = load i8, ptr %67, align 1, !tbaa !10
  %69 = zext i8 %68 to i32
  %70 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %69)
  %71 = getelementptr inbounds nuw i8, ptr %2, i64 9
  %72 = load i8, ptr %71, align 1, !tbaa !10
  %73 = zext i8 %72 to i32
  %74 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %73)
  %75 = getelementptr inbounds nuw i8, ptr %2, i64 10
  %76 = load i8, ptr %75, align 1, !tbaa !10
  %77 = zext i8 %76 to i32
  %78 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %77)
  %79 = getelementptr inbounds nuw i8, ptr %2, i64 11
  %80 = load i8, ptr %79, align 1, !tbaa !10
  %81 = zext i8 %80 to i32
  %82 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %81)
  %83 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %4) #6
  store i32 17, ptr %3, align 4
  %84 = icmp ult ptr %4, %3
  %85 = getelementptr inbounds nuw i8, ptr %4, i64 4
  %86 = icmp ugt ptr %85, %3
  %87 = select i1 %84, i1 %86, i1 false
  br i1 %87, label %93, label %88

88:                                               ; preds = %34
  %89 = icmp ult ptr %3, %4
  %90 = getelementptr inbounds nuw i8, ptr %3, i64 4
  %91 = icmp ugt ptr %90, %4
  %92 = select i1 %89, i1 %91, i1 false
  br i1 %92, label %93, label %94

93:                                               ; preds = %88, %34
  call void @llvm.trap()
  unreachable

94:                                               ; preds = %88
  %95 = load i32, ptr %3, align 4
  %96 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.4)
  %97 = and i32 %95, 255
  %98 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %97)
  %99 = lshr i32 %95, 8
  %100 = and i32 %99, 255
  %101 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %100)
  %102 = lshr i32 %95, 16
  %103 = and i32 %102, 255
  %104 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %103)
  %105 = lshr i32 %95, 24
  %106 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %105)
  %107 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %4) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %3) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %6) #6
  store i32 16712167, ptr %5, align 4
  %108 = icmp ult ptr %6, %5
  %109 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %110 = icmp ugt ptr %109, %5
  %111 = select i1 %108, i1 %110, i1 false
  br i1 %111, label %117, label %112

112:                                              ; preds = %94
  %113 = icmp ult ptr %5, %6
  %114 = getelementptr inbounds nuw i8, ptr %5, i64 4
  %115 = icmp ugt ptr %114, %6
  %116 = select i1 %113, i1 %115, i1 false
  br i1 %116, label %117, label %118

117:                                              ; preds = %112, %94
  call void @llvm.trap()
  unreachable

118:                                              ; preds = %112
  %119 = load i32, ptr %5, align 4
  %120 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.5)
  %121 = and i32 %119, 255
  %122 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %121)
  %123 = lshr i32 %119, 8
  %124 = and i32 %123, 255
  %125 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %124)
  %126 = lshr i32 %119, 16
  %127 = and i32 %126, 255
  %128 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %127)
  %129 = lshr i32 %119, 24
  %130 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %129)
  %131 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %6) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %7) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %8) #6
  store i64 -4294901761, ptr %7, align 8
  %132 = icmp ult ptr %8, %7
  %133 = getelementptr inbounds nuw i8, ptr %8, i64 8
  %134 = icmp ugt ptr %133, %7
  %135 = select i1 %132, i1 %134, i1 false
  br i1 %135, label %141, label %136

136:                                              ; preds = %118
  %137 = icmp ult ptr %7, %8
  %138 = getelementptr inbounds nuw i8, ptr %7, i64 8
  %139 = icmp ugt ptr %138, %8
  %140 = select i1 %137, i1 %139, i1 false
  br i1 %140, label %141, label %142

141:                                              ; preds = %136, %118
  call void @llvm.trap()
  unreachable

142:                                              ; preds = %136
  %143 = load i64, ptr %7, align 8
  %144 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.6)
  %145 = trunc i64 %143 to i32
  %146 = and i32 %145, 255
  %147 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %146)
  %148 = trunc i64 %143 to i32
  %149 = lshr i32 %148, 8
  %150 = and i32 %149, 255
  %151 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %150)
  %152 = trunc i64 %143 to i32
  %153 = lshr i32 %152, 16
  %154 = and i32 %153, 255
  %155 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %154)
  %156 = trunc i64 %143 to i32
  %157 = lshr i32 %156, 24
  %158 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %157)
  %159 = lshr i64 %143, 32
  %160 = trunc nuw i64 %159 to i32
  %161 = and i32 %160, 255
  %162 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %161)
  %163 = lshr i64 %143, 40
  %164 = trunc nuw nsw i64 %163 to i32
  %165 = and i32 %164, 255
  %166 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %165)
  %167 = lshr i64 %143, 48
  %168 = trunc nuw nsw i64 %167 to i32
  %169 = and i32 %168, 255
  %170 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %169)
  %171 = lshr i64 %143, 56
  %172 = trunc nuw nsw i64 %171 to i32
  %173 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %172)
  %174 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %8) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %7) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %9) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %10) #6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(36) %9, i8 -1, i64 36, i1 false)
  %175 = getelementptr inbounds nuw i8, ptr %9, i64 1
  store i8 0, ptr %175, align 1
  %176 = getelementptr inbounds nuw i8, ptr %9, i64 2
  store i8 0, ptr %176, align 2
  %177 = getelementptr inbounds nuw i8, ptr %9, i64 3
  store i8 0, ptr %177, align 1
  %178 = getelementptr inbounds nuw i8, ptr %9, i64 10
  store i8 0, ptr %178, align 2
  %179 = getelementptr inbounds nuw i8, ptr %9, i64 11
  store i8 0, ptr %179, align 1
  %180 = getelementptr inbounds nuw i8, ptr %9, i64 13
  store i8 0, ptr %180, align 1
  %181 = getelementptr inbounds nuw i8, ptr %9, i64 14
  store i8 0, ptr %181, align 2
  %182 = getelementptr inbounds nuw i8, ptr %9, i64 15
  store i8 0, ptr %182, align 1
  %183 = getelementptr inbounds nuw i8, ptr %9, i64 22
  store i8 0, ptr %183, align 2
  %184 = getelementptr inbounds nuw i8, ptr %9, i64 23
  store i8 0, ptr %184, align 1
  %185 = getelementptr inbounds nuw i8, ptr %9, i64 26
  store i8 0, ptr %185, align 2
  %186 = getelementptr inbounds nuw i8, ptr %9, i64 27
  store i8 0, ptr %186, align 1
  %187 = getelementptr inbounds nuw i8, ptr %9, i64 33
  store i8 0, ptr %187, align 1
  %188 = getelementptr inbounds nuw i8, ptr %9, i64 34
  store i8 0, ptr %188, align 2
  %189 = getelementptr inbounds nuw i8, ptr %9, i64 35
  store i8 0, ptr %189, align 1
  %190 = icmp ult ptr %10, %9
  %191 = getelementptr inbounds nuw i8, ptr %10, i64 36
  %192 = icmp ugt ptr %191, %9
  %193 = select i1 %190, i1 %192, i1 false
  br i1 %193, label %199, label %194

194:                                              ; preds = %142
  %195 = icmp ult ptr %9, %10
  %196 = getelementptr inbounds nuw i8, ptr %9, i64 36
  %197 = icmp ugt ptr %196, %10
  %198 = select i1 %195, i1 %197, i1 false
  br i1 %198, label %199, label %200

199:                                              ; preds = %194, %142
  call void @llvm.trap()
  unreachable

200:                                              ; preds = %194
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(36) %10, ptr noundef nonnull align 4 dereferenceable(36) %9, i64 36, i1 false)
  %201 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.7)
  %202 = load i8, ptr %10, align 16, !tbaa !10
  %203 = zext i8 %202 to i32
  %204 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %203)
  %205 = getelementptr inbounds nuw i8, ptr %10, i64 1
  %206 = load i8, ptr %205, align 1, !tbaa !10
  %207 = zext i8 %206 to i32
  %208 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %207)
  %209 = getelementptr inbounds nuw i8, ptr %10, i64 2
  %210 = load i8, ptr %209, align 2, !tbaa !10
  %211 = zext i8 %210 to i32
  %212 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %211)
  %213 = getelementptr inbounds nuw i8, ptr %10, i64 3
  %214 = load i8, ptr %213, align 1, !tbaa !10
  %215 = zext i8 %214 to i32
  %216 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %215)
  %217 = getelementptr inbounds nuw i8, ptr %10, i64 4
  %218 = load i8, ptr %217, align 4, !tbaa !10
  %219 = zext i8 %218 to i32
  %220 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %219)
  %221 = getelementptr inbounds nuw i8, ptr %10, i64 5
  %222 = load i8, ptr %221, align 1, !tbaa !10
  %223 = zext i8 %222 to i32
  %224 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %223)
  %225 = getelementptr inbounds nuw i8, ptr %10, i64 6
  %226 = load i8, ptr %225, align 2, !tbaa !10
  %227 = zext i8 %226 to i32
  %228 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %227)
  %229 = getelementptr inbounds nuw i8, ptr %10, i64 7
  %230 = load i8, ptr %229, align 1, !tbaa !10
  %231 = zext i8 %230 to i32
  %232 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %231)
  %233 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %234 = load i8, ptr %233, align 8, !tbaa !10
  %235 = zext i8 %234 to i32
  %236 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %235)
  %237 = getelementptr inbounds nuw i8, ptr %10, i64 9
  %238 = load i8, ptr %237, align 1, !tbaa !10
  %239 = zext i8 %238 to i32
  %240 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %239)
  %241 = getelementptr inbounds nuw i8, ptr %10, i64 10
  %242 = load i8, ptr %241, align 2, !tbaa !10
  %243 = zext i8 %242 to i32
  %244 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %243)
  %245 = getelementptr inbounds nuw i8, ptr %10, i64 11
  %246 = load i8, ptr %245, align 1, !tbaa !10
  %247 = zext i8 %246 to i32
  %248 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %247)
  %249 = getelementptr inbounds nuw i8, ptr %10, i64 12
  %250 = load i8, ptr %249, align 4, !tbaa !10
  %251 = zext i8 %250 to i32
  %252 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %251)
  %253 = getelementptr inbounds nuw i8, ptr %10, i64 13
  %254 = load i8, ptr %253, align 1, !tbaa !10
  %255 = zext i8 %254 to i32
  %256 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %255)
  %257 = getelementptr inbounds nuw i8, ptr %10, i64 14
  %258 = load i8, ptr %257, align 2, !tbaa !10
  %259 = zext i8 %258 to i32
  %260 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %259)
  %261 = getelementptr inbounds nuw i8, ptr %10, i64 15
  %262 = load i8, ptr %261, align 1, !tbaa !10
  %263 = zext i8 %262 to i32
  %264 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %263)
  %265 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %266 = load i8, ptr %265, align 16, !tbaa !10
  %267 = zext i8 %266 to i32
  %268 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %267)
  %269 = getelementptr inbounds nuw i8, ptr %10, i64 17
  %270 = load i8, ptr %269, align 1, !tbaa !10
  %271 = zext i8 %270 to i32
  %272 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %271)
  %273 = getelementptr inbounds nuw i8, ptr %10, i64 18
  %274 = load i8, ptr %273, align 2, !tbaa !10
  %275 = zext i8 %274 to i32
  %276 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %275)
  %277 = getelementptr inbounds nuw i8, ptr %10, i64 19
  %278 = load i8, ptr %277, align 1, !tbaa !10
  %279 = zext i8 %278 to i32
  %280 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %279)
  %281 = getelementptr inbounds nuw i8, ptr %10, i64 20
  %282 = load i8, ptr %281, align 4, !tbaa !10
  %283 = zext i8 %282 to i32
  %284 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %283)
  %285 = getelementptr inbounds nuw i8, ptr %10, i64 21
  %286 = load i8, ptr %285, align 1, !tbaa !10
  %287 = zext i8 %286 to i32
  %288 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %287)
  %289 = getelementptr inbounds nuw i8, ptr %10, i64 22
  %290 = load i8, ptr %289, align 2, !tbaa !10
  %291 = zext i8 %290 to i32
  %292 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %291)
  %293 = getelementptr inbounds nuw i8, ptr %10, i64 23
  %294 = load i8, ptr %293, align 1, !tbaa !10
  %295 = zext i8 %294 to i32
  %296 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %295)
  %297 = getelementptr inbounds nuw i8, ptr %10, i64 24
  %298 = load i8, ptr %297, align 8, !tbaa !10
  %299 = zext i8 %298 to i32
  %300 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %299)
  %301 = getelementptr inbounds nuw i8, ptr %10, i64 25
  %302 = load i8, ptr %301, align 1, !tbaa !10
  %303 = zext i8 %302 to i32
  %304 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %303)
  %305 = getelementptr inbounds nuw i8, ptr %10, i64 26
  %306 = load i8, ptr %305, align 2, !tbaa !10
  %307 = zext i8 %306 to i32
  %308 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %307)
  %309 = getelementptr inbounds nuw i8, ptr %10, i64 27
  %310 = load i8, ptr %309, align 1, !tbaa !10
  %311 = zext i8 %310 to i32
  %312 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %311)
  %313 = getelementptr inbounds nuw i8, ptr %10, i64 28
  %314 = load i8, ptr %313, align 4, !tbaa !10
  %315 = zext i8 %314 to i32
  %316 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %315)
  %317 = getelementptr inbounds nuw i8, ptr %10, i64 29
  %318 = load i8, ptr %317, align 1, !tbaa !10
  %319 = zext i8 %318 to i32
  %320 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %319)
  %321 = getelementptr inbounds nuw i8, ptr %10, i64 30
  %322 = load i8, ptr %321, align 2, !tbaa !10
  %323 = zext i8 %322 to i32
  %324 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %323)
  %325 = getelementptr inbounds nuw i8, ptr %10, i64 31
  %326 = load i8, ptr %325, align 1, !tbaa !10
  %327 = zext i8 %326 to i32
  %328 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %327)
  %329 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %330 = load i8, ptr %329, align 16, !tbaa !10
  %331 = zext i8 %330 to i32
  %332 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %331)
  %333 = getelementptr inbounds nuw i8, ptr %10, i64 33
  %334 = load i8, ptr %333, align 1, !tbaa !10
  %335 = zext i8 %334 to i32
  %336 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %335)
  %337 = getelementptr inbounds nuw i8, ptr %10, i64 34
  %338 = load i8, ptr %337, align 2, !tbaa !10
  %339 = zext i8 %338 to i32
  %340 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %339)
  %341 = getelementptr inbounds nuw i8, ptr %10, i64 35
  %342 = load i8, ptr %341, align 1, !tbaa !10
  %343 = zext i8 %342 to i32
  %344 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %343)
  %345 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %10) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %9) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %11) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %12) #6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %11, i8 -1, i64 24, i1 false)
  %346 = getelementptr inbounds nuw i8, ptr %11, i64 1
  store i8 0, ptr %346, align 1
  %347 = getelementptr inbounds nuw i8, ptr %11, i64 2
  store i8 0, ptr %347, align 2
  %348 = getelementptr inbounds nuw i8, ptr %11, i64 3
  store i8 0, ptr %348, align 1
  %349 = getelementptr inbounds nuw i8, ptr %11, i64 9
  %350 = icmp ult ptr %12, %11
  %351 = getelementptr inbounds nuw i8, ptr %12, i64 24
  %352 = icmp ugt ptr %351, %11
  %353 = select i1 %350, i1 %352, i1 false
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %349, i8 0, i64 7, i1 false)
  br i1 %353, label %359, label %354

354:                                              ; preds = %200
  %355 = icmp ult ptr %11, %12
  %356 = getelementptr inbounds nuw i8, ptr %11, i64 24
  %357 = icmp ugt ptr %356, %12
  %358 = select i1 %355, i1 %357, i1 false
  br i1 %358, label %359, label %360

359:                                              ; preds = %354, %200
  call void @llvm.trap()
  unreachable

360:                                              ; preds = %354
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 16 dereferenceable(24) %12, ptr noundef nonnull align 8 dereferenceable(24) %11, i64 24, i1 false)
  %361 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.8)
  %362 = load i8, ptr %12, align 16, !tbaa !10
  %363 = zext i8 %362 to i32
  %364 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %363)
  %365 = getelementptr inbounds nuw i8, ptr %12, i64 1
  %366 = load i8, ptr %365, align 1, !tbaa !10
  %367 = zext i8 %366 to i32
  %368 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %367)
  %369 = getelementptr inbounds nuw i8, ptr %12, i64 2
  %370 = load i8, ptr %369, align 2, !tbaa !10
  %371 = zext i8 %370 to i32
  %372 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %371)
  %373 = getelementptr inbounds nuw i8, ptr %12, i64 3
  %374 = load i8, ptr %373, align 1, !tbaa !10
  %375 = zext i8 %374 to i32
  %376 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %375)
  %377 = getelementptr inbounds nuw i8, ptr %12, i64 4
  %378 = load i8, ptr %377, align 4, !tbaa !10
  %379 = zext i8 %378 to i32
  %380 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %379)
  %381 = getelementptr inbounds nuw i8, ptr %12, i64 5
  %382 = load i8, ptr %381, align 1, !tbaa !10
  %383 = zext i8 %382 to i32
  %384 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %383)
  %385 = getelementptr inbounds nuw i8, ptr %12, i64 6
  %386 = load i8, ptr %385, align 2, !tbaa !10
  %387 = zext i8 %386 to i32
  %388 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %387)
  %389 = getelementptr inbounds nuw i8, ptr %12, i64 7
  %390 = load i8, ptr %389, align 1, !tbaa !10
  %391 = zext i8 %390 to i32
  %392 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %391)
  %393 = getelementptr inbounds nuw i8, ptr %12, i64 8
  %394 = load i8, ptr %393, align 8, !tbaa !10
  %395 = zext i8 %394 to i32
  %396 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %395)
  %397 = getelementptr inbounds nuw i8, ptr %12, i64 9
  %398 = load i8, ptr %397, align 1, !tbaa !10
  %399 = zext i8 %398 to i32
  %400 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %399)
  %401 = getelementptr inbounds nuw i8, ptr %12, i64 10
  %402 = load i8, ptr %401, align 2, !tbaa !10
  %403 = zext i8 %402 to i32
  %404 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %403)
  %405 = getelementptr inbounds nuw i8, ptr %12, i64 11
  %406 = load i8, ptr %405, align 1, !tbaa !10
  %407 = zext i8 %406 to i32
  %408 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %407)
  %409 = getelementptr inbounds nuw i8, ptr %12, i64 12
  %410 = load i8, ptr %409, align 4, !tbaa !10
  %411 = zext i8 %410 to i32
  %412 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %411)
  %413 = getelementptr inbounds nuw i8, ptr %12, i64 13
  %414 = load i8, ptr %413, align 1, !tbaa !10
  %415 = zext i8 %414 to i32
  %416 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %415)
  %417 = getelementptr inbounds nuw i8, ptr %12, i64 14
  %418 = load i8, ptr %417, align 2, !tbaa !10
  %419 = zext i8 %418 to i32
  %420 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %419)
  %421 = getelementptr inbounds nuw i8, ptr %12, i64 15
  %422 = load i8, ptr %421, align 1, !tbaa !10
  %423 = zext i8 %422 to i32
  %424 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %423)
  %425 = getelementptr inbounds nuw i8, ptr %12, i64 16
  %426 = load i8, ptr %425, align 16, !tbaa !10
  %427 = zext i8 %426 to i32
  %428 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %427)
  %429 = getelementptr inbounds nuw i8, ptr %12, i64 17
  %430 = load i8, ptr %429, align 1, !tbaa !10
  %431 = zext i8 %430 to i32
  %432 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %431)
  %433 = getelementptr inbounds nuw i8, ptr %12, i64 18
  %434 = load i8, ptr %433, align 2, !tbaa !10
  %435 = zext i8 %434 to i32
  %436 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %435)
  %437 = getelementptr inbounds nuw i8, ptr %12, i64 19
  %438 = load i8, ptr %437, align 1, !tbaa !10
  %439 = zext i8 %438 to i32
  %440 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %439)
  %441 = getelementptr inbounds nuw i8, ptr %12, i64 20
  %442 = load i8, ptr %441, align 4, !tbaa !10
  %443 = zext i8 %442 to i32
  %444 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %443)
  %445 = getelementptr inbounds nuw i8, ptr %12, i64 21
  %446 = load i8, ptr %445, align 1, !tbaa !10
  %447 = zext i8 %446 to i32
  %448 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %447)
  %449 = getelementptr inbounds nuw i8, ptr %12, i64 22
  %450 = load i8, ptr %449, align 2, !tbaa !10
  %451 = zext i8 %450 to i32
  %452 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %451)
  %453 = getelementptr inbounds nuw i8, ptr %12, i64 23
  %454 = load i8, ptr %453, align 1, !tbaa !10
  %455 = zext i8 %454 to i32
  %456 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %455)
  %457 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %12) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %11) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %13) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %14) #6
  store i16 783, ptr %13, align 2
  %458 = icmp ult ptr %14, %13
  %459 = getelementptr inbounds nuw i8, ptr %14, i64 2
  %460 = icmp ugt ptr %459, %13
  %461 = select i1 %458, i1 %460, i1 false
  br i1 %461, label %467, label %462

462:                                              ; preds = %360
  %463 = icmp ult ptr %13, %14
  %464 = getelementptr inbounds nuw i8, ptr %13, i64 2
  %465 = icmp ugt ptr %464, %14
  %466 = select i1 %463, i1 %465, i1 false
  br i1 %466, label %467, label %468

467:                                              ; preds = %462, %360
  call void @llvm.trap()
  unreachable

468:                                              ; preds = %462
  %469 = load i16, ptr %13, align 2
  %470 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.9)
  %471 = and i16 %469, 255
  %472 = zext nneg i16 %471 to i32
  %473 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %472)
  %474 = lshr i16 %469, 8
  %475 = zext nneg i16 %474 to i32
  %476 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef %475)
  %477 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %14) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %13) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %15) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %16) #6
  %478 = icmp ult ptr %16, %15
  %479 = getelementptr inbounds nuw i8, ptr %16, i64 4
  %480 = icmp ugt ptr %479, %15
  %481 = select i1 %478, i1 %480, i1 false
  br i1 %481, label %487, label %482

482:                                              ; preds = %468
  %483 = icmp ult ptr %15, %16
  %484 = getelementptr inbounds nuw i8, ptr %15, i64 4
  %485 = icmp ugt ptr %484, %16
  %486 = select i1 %483, i1 %485, i1 false
  br i1 %486, label %487, label %488

487:                                              ; preds = %482, %468
  call void @llvm.trap()
  unreachable

488:                                              ; preds = %482
  %489 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.10)
  %490 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %491 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %492 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %493 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %494 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %16) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %15) #6
  %495 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.11)
  %496 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %497 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.start.p0(ptr nonnull %17) #6
  call void @llvm.lifetime.start.p0(ptr nonnull %18) #6
  %498 = icmp ult ptr %18, %17
  %499 = getelementptr inbounds nuw i8, ptr %18, i64 8
  %500 = icmp ugt ptr %499, %17
  %501 = select i1 %498, i1 %500, i1 false
  br i1 %501, label %507, label %502

502:                                              ; preds = %488
  %503 = icmp ult ptr %17, %18
  %504 = getelementptr inbounds nuw i8, ptr %17, i64 8
  %505 = icmp ugt ptr %504, %18
  %506 = select i1 %503, i1 %505, i1 false
  br i1 %506, label %507, label %508

507:                                              ; preds = %502, %488
  call void @llvm.trap()
  unreachable

508:                                              ; preds = %502
  %509 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.12)
  %510 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %511 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %512 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %513 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %514 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %515 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %516 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %517 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i32 noundef 255)
  %518 = call i32 @putchar(i32 10)
  call void @llvm.lifetime.end.p0(ptr nonnull %18) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %17) #6
  %519 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %520 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %521 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %522 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %523 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %524 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %525 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %526 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %527 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %528 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %529 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %530 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %531 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %532 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %533 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %534 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %535 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %536 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %537 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %538 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %539 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %540 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %541 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %542 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %543 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %544 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %545 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %546 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %547 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %548 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %549 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %550 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %551 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %552 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 171)
  %553 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %554 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.13, i32 noundef 0)
  %555 = call i32 @putchar(i32 10)
  %556 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.14, i32 noundef 1, i32 noundef 0)
  ret i32 0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: nofree nounwind
declare noundef i32 @putchar(i32 noundef) local_unnamed_addr #5

attributes #0 = { nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #5 = { nofree nounwind }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!8, !8, i64 0}
