; ModuleID = 'test/c/synth/lex-int-constants.c'
source_filename = "test/c/synth/lex-int-constants.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"42\00", align 1
@.str.2 = private unnamed_addr constant [4 x i8] c"017\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"0x1F\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"0X1f\00", align 1
@.str.5 = private unnamed_addr constant [7 x i8] c"0b1011\00", align 1
@.str.6 = private unnamed_addr constant [6 x i8] c"0B111\00", align 1
@.str.7 = private unnamed_addr constant [2 x i8] c"0\00", align 1
@.str.8 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.9 = private unnamed_addr constant [12 x i8] c"4294967295u\00", align 1
@.str.10 = private unnamed_addr constant [10 x i8] c"%s = %ld\0A\00", align 1
@.str.11 = private unnamed_addr constant [5 x i8] c"100l\00", align 1
@.str.12 = private unnamed_addr constant [5 x i8] c"100L\00", align 1
@.str.13 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.14 = private unnamed_addr constant [22 x i8] c"9223372036854775807LL\00", align 1
@.str.15 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.16 = private unnamed_addr constant [24 x i8] c"18446744073709551615ULL\00", align 1
@.str.17 = private unnamed_addr constant [10 x i8] c"%s = %lu\0A\00", align 1
@.str.18 = private unnamed_addr constant [4 x i8] c"7ul\00", align 1
@.str.19 = private unnamed_addr constant [5 x i8] c"8uLL\00", align 1
@.str.20 = private unnamed_addr constant [21 x i8] c"0x7fffffffffffffffll\00", align 1
@.str.21 = private unnamed_addr constant [50 x i8] c"_Generic(0x80000000, unsigned int: 1, default: 0)\00", align 1
@.str.22 = private unnamed_addr constant [56 x i8] c"_Generic(2147483648, long: 1, long long: 2, default: 0)\00", align 1
@.str.23 = private unnamed_addr constant [44 x i8] c"_Generic(017u, unsigned int: 1, default: 0)\00", align 1
@.str.24 = private unnamed_addr constant [52 x i8] c"_Generic(0b1ull, unsigned long long: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 42)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 15)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 31)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 31)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef 11)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef 7)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef 0)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str.8, ptr noundef @.str.9, i32 noundef -1)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str.10, ptr noundef @.str.11, i64 noundef 100)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.10, ptr noundef @.str.12, i64 noundef 100)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str.13, ptr noundef @.str.14, i64 noundef 9223372036854775807)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.15, ptr noundef @.str.16, i64 noundef -1)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.17, ptr noundef @.str.18, i64 noundef 7)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.15, ptr noundef @.str.19, i64 noundef 8)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str.13, ptr noundef @.str.20, i64 noundef 9223372036854775807)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.21, i32 noundef 1)
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.22, i32 noundef 1)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.23, i32 noundef 1)
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.24, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
