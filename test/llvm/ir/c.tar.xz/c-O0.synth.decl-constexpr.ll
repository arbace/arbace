; ModuleID = 'test/c/synth/decl-constexpr.c'
source_filename = "test/c/synth/decl-constexpr.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.pt = type { i32, i32 }

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"N\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.3 = private unnamed_addr constant [5 x i8] c"HALF\00", align 1
@.str.4 = private unnamed_addr constant [20 x i8] c"ORIGIN.x + ORIGIN.y\00", align 1
@ORIGIN = internal constant %struct.pt { i32 1, i32 2 }, align 4
@.str.5 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.6 = private unnamed_addr constant [27 x i8] c"sizeof buf / sizeof buf[0]\00", align 1
@.str.7 = private unnamed_addr constant [27 x i8] c"sizeof arr / sizeof arr[0]\00", align 1
@.str.8 = private unnamed_addr constant [4 x i8] c"yes\00", align 1
@.str.9 = private unnamed_addr constant [2 x i8] c"c\00", align 1
@.str.10 = private unnamed_addr constant [9 x i8] c"BYTES[2]\00", align 1
@BYTES = internal constant [3 x i8] c"\01\02\03", align 1
@.str.11 = private unnamed_addr constant [32 x i8] c"_Generic(N, int: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [5 x i32], align 16
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  store i32 0, ptr %1, align 4
  store i32 5, ptr %2, align 4
  store i8 1, ptr %4, align 1
  store i8 113, ptr %5, align 1
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 4)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, double noundef 5.000000e-01)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef 3)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.6, i64 noundef 8)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.7, i64 noundef 5)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef 1)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 113)
  %13 = load i8, ptr getelementptr inbounds nuw (i8, ptr @BYTES, i64 2), align 1
  %14 = zext i8 %13 to i32
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %14)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
