; ModuleID = 'test/c/synth/expr-cast.c'
source_filename = "test/c/synth/expr-cast.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [7 x i8] c"(int)d\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"(int)-d\00", align 1
@.str.3 = private unnamed_addr constant [19 x i8] c"(unsigned char)300\00", align 1
@.str.4 = private unnamed_addr constant [17 x i8] c"(signed char)200\00", align 1
@.str.5 = private unnamed_addr constant [9 x i8] c"%s = %g\0A\00", align 1
@.str.6 = private unnamed_addr constant [14 x i8] c"(double)7 / 2\00", align 1
@.str.7 = private unnamed_addr constant [9 x i8] c"%s = %u\0A\00", align 1
@.str.8 = private unnamed_addr constant [12 x i8] c"(unsigned)n\00", align 1
@.str.9 = private unnamed_addr constant [11 x i8] c"*(int *)vp\00", align 1
@.str.10 = private unnamed_addr constant [35 x i8] c"(int)(long long)1e10 == 1410065408\00", align 1
@.str.11 = private unnamed_addr constant [38 x i8] c"(double)(float)0.1 == 0.1 ? 1.0 : 0.0\00", align 1
@.str.12 = private unnamed_addr constant [10 x i8] c"(bool)0.5\00", align 1
@.str.13 = private unnamed_addr constant [8 x i8] c"(bool)2\00", align 1
@.str.14 = private unnamed_addr constant [24 x i8] c"(int)(unsigned short)-1\00", align 1
@.str.15 = private unnamed_addr constant [4 x i8] c"sb1\00", align 1
@.str.16 = private unnamed_addr constant [4 x i8] c"sb2\00", align 1
@.str.17 = private unnamed_addr constant [4 x i8] c"sb3\00", align 1
@.str.18 = private unnamed_addr constant [4 x i8] c"sb4\00", align 1
@.str.19 = private unnamed_addr constant [12 x i8] c"(bool)-0.75\00", align 1
@.str.20 = private unnamed_addr constant [16 x i8] c"(int)(bool)2.5f\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store double 3.750000e+00, ptr %2, align 8
  store i32 -7, ptr %3, align 4
  store ptr %3, ptr %4, align 8
  %5 = load double, ptr %2, align 8
  %6 = load double, ptr %2, align 8
  %7 = fptosi double %6 to i32
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %7)
  %9 = load double, ptr %2, align 8
  %10 = fneg double %9
  %11 = fptosi double %10 to i32
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %11)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 44)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef -56)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.6, double noundef 3.500000e+00)
  %16 = load i32, ptr %3, align 4
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str.7, ptr noundef @.str.8, i32 noundef %16)
  %18 = load ptr, ptr %4, align 8
  %19 = load i32, ptr %18, align 4
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %19)
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 1)
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.11, double noundef 0.000000e+00)
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 1)
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef 1)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef 65535)
  %26 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.15, i32 noundef 1)
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.16, i32 noundef 0)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17, i32 noundef 0)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.18, i32 noundef 1)
  %30 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.19, i32 noundef 1)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.20, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
