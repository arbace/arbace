; ModuleID = 'test/c/synth/lex-string-literals.c'
source_filename = "test/c/synth/lex-string-literals.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.1 = private unnamed_addr constant [10 x i8] c"\22ab\22 \22cd\22\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"abcd\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"\22tab\\tend\22\00", align 1
@.str.4 = private unnamed_addr constant [8 x i8] c"tab\09end\00", align 1
@.str.5 = private unnamed_addr constant [12 x i8] c"\22\\x41\\102C\22\00", align 1
@.str.6 = private unnamed_addr constant [4 x i8] c"ABC\00", align 1
@.str.7 = private unnamed_addr constant [12 x i8] c"\22??=??/??(\22\00", align 1
@.str.8 = private unnamed_addr constant [10 x i8] c"??=??/??(\00", align 1
@.str.9 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.10 = private unnamed_addr constant [13 x i8] c"sizeof \22abc\22\00", align 1
@.str.11 = private unnamed_addr constant [18 x i8] c"sizeof u8\22\\u00e9\22\00", align 1
@.str.12 = private unnamed_addr constant [31 x i8] c"sizeof L\22ab\22 / sizeof L\22ab\22[0]\00", align 1
@.str.13 = private unnamed_addr constant [31 x i8] c"sizeof u\22ab\22 / sizeof u\22ab\22[0]\00", align 1
@.str.14 = private unnamed_addr constant [31 x i8] c"sizeof U\22ab\22 / sizeof U\22ab\22[0]\00", align 1
@.str.15 = private unnamed_addr constant [19 x i8] c"sizeof \22a\22 \22b\22 \22c\22\00", align 1
@.str.16 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.17 = private unnamed_addr constant [14 x i8] c"u8\22\\u00e9\22[0]\00", align 1
@.str.18 = private unnamed_addr constant [3 x i8] c"\C3\A9\00", align 1
@.str.19 = private unnamed_addr constant [14 x i8] c"u8\22\\u00e9\22[1]\00", align 1
@.str.20 = private unnamed_addr constant [23 x i8] c"(int)U\22x\\U0001F600\22[1]\00", align 1
@.str.21 = private unnamed_addr constant [3 x i32] [i32 120, i32 128512, i32 0], align 4
@.str.22 = private unnamed_addr constant [49 x i8] c"_Generic(u8\22a\22[0], unsigned char: 1, default: 0)\00", align 1
@.str.23 = private unnamed_addr constant [41 x i8] c"_Generic(&\22a\22[0], char *: 1, default: 0)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, ptr noundef @.str.2)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, ptr noundef @.str.4)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, ptr noundef @.str.6)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, ptr noundef @.str.8)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, i64 noundef 4)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.11, i64 noundef 3)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.12, i64 noundef 3)
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.13, i64 noundef 3)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.14, i64 noundef 3)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.15, i64 noundef 4)
  %12 = load i8, ptr @.str.18, align 1
  %13 = zext i8 %12 to i32
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.17, i32 noundef %13)
  %15 = load i8, ptr getelementptr inbounds nuw (i8, ptr @.str.18, i64 1), align 1
  %16 = zext i8 %15 to i32
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.19, i32 noundef %16)
  %18 = load i32, ptr getelementptr inbounds nuw (i8, ptr @.str.21, i64 4), align 4
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.20, i32 noundef %18)
  %20 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.22, i32 noundef 1)
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str.16, ptr noundef @.str.23, i32 noundef 1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
