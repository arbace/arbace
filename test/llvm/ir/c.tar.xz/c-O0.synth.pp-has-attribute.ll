; ModuleID = 'test/c/synth/pp-has-attribute.c'
source_filename = "test/c/synth/pp-has-attribute.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [3 x i8] c"a0\00", align 1
@a0 = internal global i32 0, align 4
@.str.2 = private unnamed_addr constant [3 x i8] c"a1\00", align 1
@a1 = internal global i32 0, align 4
@.str.3 = private unnamed_addr constant [3 x i8] c"a2\00", align 1
@a2 = internal global i32 0, align 4
@.str.4 = private unnamed_addr constant [3 x i8] c"a3\00", align 1
@a3 = internal global i32 0, align 4
@.str.5 = private unnamed_addr constant [3 x i8] c"a4\00", align 1
@a4 = internal global i32 0, align 4
@.str.6 = private unnamed_addr constant [3 x i8] c"a5\00", align 1
@a5 = internal global i32 0, align 4
@.str.7 = private unnamed_addr constant [3 x i8] c"a6\00", align 1
@a6 = internal global i32 0, align 4
@.str.8 = private unnamed_addr constant [3 x i8] c"a7\00", align 1
@a7 = internal global i32 0, align 4
@.str.9 = private unnamed_addr constant [3 x i8] c"a8\00", align 1
@a8 = internal global i32 0, align 4
@.str.10 = private unnamed_addr constant [3 x i8] c"a9\00", align 1
@a9 = internal global i32 1, align 4
@.str.11 = private unnamed_addr constant [4 x i8] c"a10\00", align 1
@a10 = internal global i32 1, align 4
@.str.12 = private unnamed_addr constant [4 x i8] c"a11\00", align 1
@a11 = internal global i32 1, align 4
@.str.13 = private unnamed_addr constant [6 x i8] c"in_if\00", align 1
@in_if = internal global i32 1, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i32, ptr @a0, align 4
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %2)
  %4 = load i32, ptr @a1, align 4
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %4)
  %6 = load i32, ptr @a2, align 4
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef %6)
  %8 = load i32, ptr @a3, align 4
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.4, i32 noundef %8)
  %10 = load i32, ptr @a4, align 4
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.5, i32 noundef %10)
  %12 = load i32, ptr @a5, align 4
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.6, i32 noundef %12)
  %14 = load i32, ptr @a6, align 4
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.7, i32 noundef %14)
  %16 = load i32, ptr @a7, align 4
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %16)
  %18 = load i32, ptr @a8, align 4
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %18)
  %20 = load i32, ptr @a9, align 4
  %21 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef %20)
  %22 = load i32, ptr @a10, align 4
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %22)
  %24 = load i32, ptr @a11, align 4
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef %24)
  %26 = load i32, ptr @in_if, align 4
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef %26)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
