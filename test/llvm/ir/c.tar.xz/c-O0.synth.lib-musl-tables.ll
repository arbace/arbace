; ModuleID = 'test/c/synth/lib-musl-tables.c'
source_filename = "test/c/synth/lib-musl-tables.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.1 = private unnamed_addr constant [17 x i8] c"strerror(ENOENT)\00", align 1
@.str.2 = private unnamed_addr constant [17 x i8] c"strerror(ERANGE)\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"strerror(EDOM)\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.5 = private unnamed_addr constant [20 x i8] c"iswalpha(L'a') != 0\00", align 1
@.str.6 = private unnamed_addr constant [20 x i8] c"iswalpha(L'7') != 0\00", align 1
@.str.7 = private unnamed_addr constant [20 x i8] c"iswalpha(0xe9) != 0\00", align 1
@.str.8 = private unnamed_addr constant [20 x i8] c"iswpunct(L'!') != 0\00", align 1
@.str.9 = private unnamed_addr constant [20 x i8] c"iswpunct(L'a') != 0\00", align 1
@.str.10 = private unnamed_addr constant [14 x i8] c"wcwidth(L'a')\00", align 1
@.str.11 = private unnamed_addr constant [16 x i8] c"wcwidth(0x4e00)\00", align 1
@.str.12 = private unnamed_addr constant [16 x i8] c"wcwidth(0x0301)\00", align 1
@.str.13 = private unnamed_addr constant [17 x i8] c"latin1_to_utf8()\00", align 1
@.str.14 = private unnamed_addr constant [6 x i8] c"UTF-8\00", align 1
@.str.15 = private unnamed_addr constant [11 x i8] c"ISO-8859-1\00", align 1
@__const.latin1_to_utf8.in = private unnamed_addr constant [4 x i8] c"\E9t\E9\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call ptr @strerror(i32 noundef 2)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, ptr noundef %2)
  %4 = call ptr @strerror(i32 noundef 34)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, ptr noundef %4)
  %6 = call ptr @strerror(i32 noundef 33)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, ptr noundef %6)
  %8 = call i32 @iswalpha(i32 noundef 97)
  %9 = icmp ne i32 %8, 0
  %10 = zext i1 %9 to i32
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, i32 noundef %10)
  %12 = call i32 @iswalpha(i32 noundef 55)
  %13 = icmp ne i32 %12, 0
  %14 = zext i1 %13 to i32
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.6, i32 noundef %14)
  %16 = call i32 @iswalpha(i32 noundef 233)
  %17 = icmp ne i32 %16, 0
  %18 = zext i1 %17 to i32
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.7, i32 noundef %18)
  %20 = call i32 @iswpunct(i32 noundef 33)
  %21 = icmp ne i32 %20, 0
  %22 = zext i1 %21 to i32
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.8, i32 noundef %22)
  %24 = call i32 @iswpunct(i32 noundef 97)
  %25 = icmp ne i32 %24, 0
  %26 = zext i1 %25 to i32
  %27 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.9, i32 noundef %26)
  %28 = call i32 @wcwidth(i32 noundef 97)
  %29 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.10, i32 noundef %28)
  %30 = call i32 @wcwidth(i32 noundef 19968)
  %31 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.11, i32 noundef %30)
  %32 = call i32 @wcwidth(i32 noundef 769)
  %33 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.12, i32 noundef %32)
  %34 = call i32 @latin1_to_utf8()
  %35 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.13, i32 noundef %34)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

declare ptr @strerror(i32 noundef) #1

declare i32 @iswalpha(i32 noundef) #1

declare i32 @iswpunct(i32 noundef) #1

declare i32 @wcwidth(i32 noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @latin1_to_utf8() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca [4 x i8], align 1
  %4 = alloca [16 x i8], align 16
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = call ptr @iconv_open(ptr noundef @.str.14, ptr noundef @.str.15)
  store ptr %10, ptr %2, align 8
  %11 = load ptr, ptr %2, align 8
  %12 = icmp eq ptr %11, inttoptr (i64 -1 to ptr)
  br i1 %12, label %13, label %14

13:                                               ; preds = %0
  store i32 -1, ptr %1, align 4
  br label %33

14:                                               ; preds = %0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 @__const.latin1_to_utf8.in, i64 4, i1 false)
  call void @llvm.memset.p0.i64(ptr align 16 %4, i8 0, i64 16, i1 false)
  %15 = getelementptr inbounds [4 x i8], ptr %3, i64 0, i64 0
  store ptr %15, ptr %5, align 8
  %16 = getelementptr inbounds [16 x i8], ptr %4, i64 0, i64 0
  store ptr %16, ptr %6, align 8
  store i64 3, ptr %7, align 8
  store i64 15, ptr %8, align 8
  %17 = load ptr, ptr %2, align 8
  %18 = call i64 @iconv(ptr noundef %17, ptr noundef %5, ptr noundef %7, ptr noundef %6, ptr noundef %8)
  store i64 %18, ptr %9, align 8
  %19 = load ptr, ptr %2, align 8
  %20 = call i32 @iconv_close(ptr noundef %19)
  %21 = load i64, ptr %9, align 8
  %22 = icmp eq i64 %21, -1
  br i1 %22, label %23, label %24

23:                                               ; preds = %14
  br label %31

24:                                               ; preds = %14
  %25 = load ptr, ptr %6, align 8
  %26 = getelementptr inbounds [16 x i8], ptr %4, i64 0, i64 0
  %27 = ptrtoint ptr %25 to i64
  %28 = ptrtoint ptr %26 to i64
  %29 = sub i64 %27, %28
  %30 = trunc i64 %29 to i32
  br label %31

31:                                               ; preds = %24, %23
  %32 = phi i32 [ -2, %23 ], [ %30, %24 ]
  store i32 %32, ptr %1, align 4
  br label %33

33:                                               ; preds = %31, %13
  %34 = load i32, ptr %1, align 4
  ret i32 %34
}

declare ptr @iconv_open(ptr noundef, ptr noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

declare i64 @iconv(ptr noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) #1

declare i32 @iconv_close(ptr noundef) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
