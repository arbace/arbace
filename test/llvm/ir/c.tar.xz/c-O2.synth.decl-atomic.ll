; ModuleID = 'test/c/synth/decl-atomic.c'
source_filename = "test/c/synth/decl-atomic.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [6 x i8] c"plain\00", align 1
@.str.2 = private unnamed_addr constant [11 x i8] c"%s = %llu\0A\00", align 1
@.str.3 = private unnamed_addr constant [22 x i8] c"(unsigned long long)b\00", align 1
@.str.4 = private unnamed_addr constant [36 x i8] c"_Generic(a + 0, int: 1, default: 0)\00", align 1

; Function Attrs: nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca i32, align 4
  %2 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #3
  store i32 1, ptr %1, align 4, !tbaa !10
  %3 = atomicrmw add ptr %1, i32 4 seq_cst, align 4
  %4 = atomicrmw add ptr %1, i32 1 seq_cst, align 4
  %5 = atomicrmw add ptr %1, i32 1 seq_cst, align 4
  %6 = load atomic i32, ptr %1 seq_cst, align 4, !tbaa !10
  br label %7

7:                                                ; preds = %7, %0
  %8 = phi i32 [ %6, %0 ], [ %11, %7 ]
  %9 = shl nsw i32 %8, 1
  %10 = cmpxchg ptr %1, i32 %8, i32 %9 seq_cst seq_cst, align 4
  %11 = extractvalue { i32, i1 } %10, 0
  %12 = extractvalue { i32, i1 } %10, 1
  br i1 %12, label %13, label %7

13:                                               ; preds = %7
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #3
  store i64 10, ptr %2, align 8, !tbaa !10
  %14 = atomicrmw sub ptr %2, i64 3 seq_cst, align 8
  %15 = load atomic i32, ptr %1 seq_cst, align 4, !tbaa !10
  %16 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.1, i32 noundef %15)
  %17 = load atomic i64, ptr %2 seq_cst, align 8, !tbaa !10
  %18 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, ptr noundef nonnull @.str.3, i64 noundef %17)
  %19 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, ptr noundef nonnull @.str.4, i32 noundef 1)
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #3
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #3
  ret i32 0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

attributes #0 = { nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.errno.tbaa = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.4"}
!5 = !{!6, !7, i64 0}
!6 = !{!"__libc_errno", !7, i64 0}
!7 = !{!"int", !8, i64 0}
!8 = !{!"omnipotent char", !9, i64 0}
!9 = !{!"Simple C/C++ TBAA"}
!10 = !{!8, !8, i64 0}
