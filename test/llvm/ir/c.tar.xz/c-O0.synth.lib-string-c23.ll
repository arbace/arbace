; ModuleID = 'test/c/synth/lib-string-c23.c'
source_filename = "test/c/synth/lib-string-c23.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [10 x i8] c"duplicate\00", align 1
@.str.1 = private unnamed_addr constant [7 x i8] c"abcdef\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"key=value\00", align 1
@.str.3 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"d\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"n\00", align 1
@.str.6 = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.7 = private unnamed_addr constant [10 x i8] c"strlen(n)\00", align 1
@.str.8 = private unnamed_addr constant [4 x i8] c"buf\00", align 1
@.str.9 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.10 = private unnamed_addr constant [18 x i8] c"(int)(stop - buf)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca [16 x i8], align 16
  %5 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  %6 = call ptr @strdup(ptr noundef @.str) #4
  store ptr %6, ptr %2, align 8
  %7 = call ptr @strndup(ptr noundef @.str.1, i64 noundef 3) #4
  store ptr %7, ptr %3, align 8
  call void @llvm.memset.p0.i64(ptr align 16 %4, i8 0, i64 16, i1 false)
  %8 = getelementptr inbounds [16 x i8], ptr %4, i64 0, i64 0
  %9 = call ptr @memccpy(ptr noundef %8, ptr noundef @.str.2, i32 noundef 61, i64 noundef 16)
  store ptr %9, ptr %5, align 8
  %10 = load ptr, ptr %2, align 8
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.4, ptr noundef %10)
  %12 = load ptr, ptr %3, align 8
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.5, ptr noundef %12)
  %14 = load ptr, ptr %3, align 8
  %15 = call i64 @strlen(ptr noundef %14) #4
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str.6, ptr noundef @.str.7, i64 noundef %15)
  %17 = getelementptr inbounds [16 x i8], ptr %4, i64 0, i64 0
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.8, ptr noundef %17)
  %19 = load ptr, ptr %5, align 8
  %20 = getelementptr inbounds [16 x i8], ptr %4, i64 0, i64 0
  %21 = ptrtoint ptr %19 to i64
  %22 = ptrtoint ptr %20 to i64
  %23 = sub i64 %21, %22
  %24 = trunc i64 %23 to i32
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.9, ptr noundef @.str.10, i32 noundef %24)
  ret i32 0
}

; Function Attrs: nounwind
declare ptr @strdup(ptr noundef) #1

; Function Attrs: nounwind
declare ptr @strndup(ptr noundef, i64 noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

declare ptr @memccpy(ptr noundef, ptr noundef, i32 noundef, i64 noundef) #3

declare i32 @printf(ptr noundef, ...) #3

; Function Attrs: nounwind
declare i64 @strlen(ptr noundef) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
