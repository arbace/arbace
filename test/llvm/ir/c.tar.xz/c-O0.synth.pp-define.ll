; ModuleID = 'test/c/synth/pp-define.c'
source_filename = "test/c/synth/pp-define.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"TEN\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"SQ(TEN)\00", align 1
@.str.3 = private unnamed_addr constant [14 x i8] c"ADD(1, SQ(2))\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"STR(a + b)\00", align 1
@.str.6 = private unnamed_addr constant [6 x i8] c"a + b\00", align 1
@.str.7 = private unnamed_addr constant [10 x i8] c"XSTR(TEN)\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"10\00", align 1
@.str.9 = private unnamed_addr constant [11 x i8] c"CAT(TE, N)\00", align 1
@.str.10 = private unnamed_addr constant [13 x i8] c"ID() 5 EMPTY\00", align 1
@.str.11 = private unnamed_addr constant [5 x i8] c"SELF\00", align 1
@SELF = internal global i32 3, align 4
@.str.12 = private unnamed_addr constant [7 x i8] c"NONE()\00", align 1
@.str.13 = private unnamed_addr constant [13 x i8] c"TWICE(SQ, 3)\00", align 1
@.str.14 = private unnamed_addr constant [5 x i8] c"gone\00", align 1
@gone = internal global i32 1, align 4
@.str.15 = private unnamed_addr constant [11 x i8] c"STR(\22q\\n\22)\00", align 1
@.str.16 = private unnamed_addr constant [6 x i8] c"\22q\\n\22\00", align 1
@.str.17 = private unnamed_addr constant [10 x i8] c"CAT(1, 2)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef 10)
  %3 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef 100)
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.3, i32 noundef 5)
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.5, ptr noundef @.str.6)
  %6 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.7, ptr noundef @.str.8)
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef 10)
  %8 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.10, i32 noundef 5)
  %9 = load i32, ptr @SELF, align 4
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i32 noundef %9)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.12, i32 noundef 7)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i32 noundef 81)
  %13 = load i32, ptr @gone, align 4
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.14, i32 noundef %13)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, ptr noundef @.str.15, ptr noundef @.str.16)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.17, i32 noundef 12)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
