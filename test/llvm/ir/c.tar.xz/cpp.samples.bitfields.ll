; ModuleID = 'test/cpp/samples/bitfields.cpp'
source_filename = "test/cpp/samples/bitfields.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@s24 = dso_local global { i8, i8, i8, i8 } { i8 1, i8 0, i8 0, i8 2 }, align 4
@s40 = dso_local global { i8, i8, i8, i8, i8, i8, i8, i8 } { i8 3, i8 0, i8 0, i8 0, i8 0, i8 7, i8 9, i8 undef }, align 8
@s48 = dso_local global { i8, i8, i8, i8, i8, i8, i16 } { i8 -5, i8 -1, i8 -1, i8 -1, i8 -1, i8 -1, i16 -16657 }, align 8
@s56 = dso_local global { i8, i8, i8, i8, i8, i8, i8, i8 } { i8 119, i8 102, i8 85, i8 68, i8 51, i8 34, i8 17, i8 -120 }, align 8
@p17 = dso_local global { i8, i8, i8, i8 } { i8 -1, i8 -1, i8 -85, i8 -86 }, align 4
@.str = private unnamed_addr constant [7 x i8] c"%u %u\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"%lu %u %u\0A\00", align 1
@.str.2 = private unnamed_addr constant [8 x i8] c"%ld %x\0A\00", align 1
@.str.3 = private unnamed_addr constant [8 x i8] c"%lx %x\0A\00", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"%x %x\0A\00", align 1

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #0 {
  store i24 5, ptr @s24, align 4
  %1 = load i24, ptr @s24, align 4
  %2 = zext i24 %1 to i32
  %3 = add nsw i32 %2, 16777214
  %4 = trunc i32 %3 to i24
  store i24 %4, ptr @s24, align 4
  %5 = zext i24 %4 to i32
  %6 = load i24, ptr @s24, align 4
  %7 = zext i24 %6 to i32
  %8 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s24, i64 3), align 1
  %9 = zext i8 %8 to i32
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %7, i32 noundef %9)
  store i40 -1, ptr @s40, align 8
  %11 = load i40, ptr @s40, align 8
  %12 = zext i40 %11 to i64
  %13 = add i64 %12, 2
  %14 = trunc i64 %13 to i40
  store i40 %14, ptr @s40, align 8
  %15 = zext i40 %14 to i64
  %16 = load i40, ptr @s40, align 8
  %17 = zext i40 %16 to i64
  %18 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s40, i64 5), align 1
  %19 = zext i8 %18 to i32
  %20 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s40, i64 6), align 2
  %21 = zext i8 %20 to i32
  %22 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i64 noundef %17, i32 noundef %19, i32 noundef %21)
  %23 = load i48, ptr @s48, align 8
  %24 = sext i48 %23 to i64
  %25 = sub nsw i64 %24, 1
  %26 = trunc i64 %25 to i48
  store i48 %26, ptr @s48, align 8
  %27 = sext i48 %26 to i64
  %28 = load i48, ptr @s48, align 8
  %29 = sext i48 %28 to i64
  %30 = load i16, ptr getelementptr inbounds nuw (i8, ptr @s48, i64 6), align 2
  %31 = zext i16 %30 to i32
  %32 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i64 noundef %29, i32 noundef %31)
  %33 = load i56, ptr @s56, align 8
  %34 = zext i56 %33 to i64
  %35 = xor i64 %34, 72057594037927935
  %36 = trunc i64 %35 to i56
  store i56 %36, ptr @s56, align 8
  %37 = zext i56 %36 to i64
  %38 = load i56, ptr @s56, align 8
  %39 = zext i56 %38 to i64
  %40 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s56, i64 7), align 1
  %41 = zext i8 %40 to i32
  %42 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i64 noundef %39, i32 noundef %41)
  %43 = load i32, ptr @p17, align 4
  %44 = and i32 %43, 131071
  %45 = add nsw i32 %44, 1
  %46 = load i32, ptr @p17, align 4
  %47 = and i32 %45, 131071
  %48 = and i32 %46, -131072
  %49 = or i32 %48, %47
  store i32 %49, ptr @p17, align 4
  %50 = load i32, ptr @p17, align 4
  %51 = lshr i32 %50, 17
  %52 = shl i32 %51, 1
  %53 = load i32, ptr @p17, align 4
  %54 = and i32 %52, 32767
  %55 = shl i32 %54, 17
  %56 = and i32 %53, 131071
  %57 = or i32 %56, %55
  store i32 %57, ptr @p17, align 4
  %58 = load i32, ptr @p17, align 4
  %59 = and i32 %58, 131071
  %60 = load i32, ptr @p17, align 4
  %61 = lshr i32 %60, 17
  %62 = call i32 (ptr, ...) @printf(ptr noundef @.str.4, i32 noundef %59, i32 noundef %61)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
