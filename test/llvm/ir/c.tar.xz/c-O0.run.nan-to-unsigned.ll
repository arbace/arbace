; ModuleID = 'test/c/run/nan-to-unsigned.c'
source_filename = "test/c/run/nan-to-unsigned.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [21 x i8] c"%lx %lx %lx %lx %lx\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"%x %x %lx\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca float, align 4
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  store i32 0, ptr %1, align 4
  store volatile double +qnan, ptr %2, align 8
  store volatile float +qnan, ptr %3, align 4
  store volatile double 1.000000e+30, ptr %4, align 8
  store volatile double -1.000000e+00, ptr %5, align 8
  store volatile double 9.300000e+18, ptr %6, align 8
  %7 = load volatile double, ptr %2, align 8
  %8 = fptoui double %7 to i64
  %9 = load volatile float, ptr %3, align 4
  %10 = fptoui float %9 to i64
  %11 = load volatile double, ptr %4, align 8
  %12 = fptoui double %11 to i64
  %13 = load volatile double, ptr %5, align 8
  %14 = fptoui double %13 to i64
  %15 = load volatile double, ptr %6, align 8
  %16 = fptoui double %15 to i64
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %8, i64 noundef %10, i64 noundef %12, i64 noundef %14, i64 noundef %16)
  %18 = load volatile double, ptr %2, align 8
  %19 = fptoui double %18 to i32
  %20 = load volatile float, ptr %3, align 4
  %21 = fptoui float %20 to i32
  %22 = load volatile double, ptr %2, align 8
  %23 = fptosi double %22 to i64
  %24 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef %19, i32 noundef %21, i64 noundef %23)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
