; ModuleID = 'test/c/run/nan-to-unsigned.c'
source_filename = "test/c/run/nan-to-unsigned.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [21 x i8] c"%lx %lx %lx %lx %lx\0A\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"%x %x %lx\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca float, align 4
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca [5 x i64], align 16
  %8 = alloca [2 x i32], align 4
  %9 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store volatile double +qnan, ptr %2, align 8
  store volatile float +qnan, ptr %3, align 4
  store volatile double 1.000000e+30, ptr %4, align 8
  store volatile double -1.000000e+00, ptr %5, align 8
  store volatile double 9.300000e+18, ptr %6, align 8
  %10 = load volatile double, ptr %2, align 8
  %11 = fptoui double %10 to i64
  store i64 %11, ptr %7, align 8
  %12 = getelementptr inbounds i64, ptr %7, i64 1
  %13 = load volatile float, ptr %3, align 4
  %14 = fptoui float %13 to i64
  store i64 %14, ptr %12, align 8
  %15 = getelementptr inbounds i64, ptr %7, i64 2
  %16 = load volatile double, ptr %4, align 8
  %17 = fptoui double %16 to i64
  store i64 %17, ptr %15, align 8
  %18 = getelementptr inbounds i64, ptr %7, i64 3
  %19 = load volatile double, ptr %5, align 8
  %20 = fptoui double %19 to i64
  store i64 %20, ptr %18, align 8
  %21 = getelementptr inbounds i64, ptr %7, i64 4
  %22 = load volatile double, ptr %6, align 8
  %23 = fptoui double %22 to i64
  store i64 %23, ptr %21, align 8
  %24 = load volatile double, ptr %2, align 8
  %25 = fptoui double %24 to i32
  store i32 %25, ptr %8, align 4
  %26 = getelementptr inbounds i32, ptr %8, i64 1
  %27 = load volatile float, ptr %3, align 4
  %28 = fptoui float %27 to i32
  store i32 %28, ptr %26, align 4
  %29 = load volatile double, ptr %2, align 8
  %30 = fptosi double %29 to i64
  store i64 %30, ptr %9, align 8
  %31 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 0
  %32 = load i64, ptr %31, align 16
  %33 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 1
  %34 = load i64, ptr %33, align 8
  %35 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 2
  %36 = load i64, ptr %35, align 16
  %37 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 3
  %38 = load i64, ptr %37, align 8
  %39 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 4
  %40 = load i64, ptr %39, align 16
  %41 = call i32 (ptr, ...) @printf(ptr noundef @.str, i64 noundef %32, i64 noundef %34, i64 noundef %36, i64 noundef %38, i64 noundef %40)
  %42 = getelementptr inbounds [2 x i32], ptr %8, i64 0, i64 0
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr inbounds [2 x i32], ptr %8, i64 0, i64 1
  %45 = load i32, ptr %44, align 4
  %46 = load i64, ptr %9, align 8
  %47 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef %43, i32 noundef %45, i64 noundef %46)
  %48 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 0
  %49 = load i64, ptr %48, align 16
  %50 = icmp eq i64 %49, -9223372036854775808
  br i1 %50, label %51, label %78

51:                                               ; preds = %0
  %52 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 1
  %53 = load i64, ptr %52, align 8
  %54 = icmp eq i64 %53, -9223372036854775808
  br i1 %54, label %55, label %78

55:                                               ; preds = %51
  %56 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 2
  %57 = load i64, ptr %56, align 16
  %58 = icmp eq i64 %57, 0
  br i1 %58, label %59, label %78

59:                                               ; preds = %55
  %60 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 3
  %61 = load i64, ptr %60, align 8
  %62 = icmp eq i64 %61, -1
  br i1 %62, label %63, label %78

63:                                               ; preds = %59
  %64 = getelementptr inbounds [5 x i64], ptr %7, i64 0, i64 4
  %65 = load i64, ptr %64, align 16
  %66 = icmp eq i64 %65, -9146744073709551616
  br i1 %66, label %67, label %78

67:                                               ; preds = %63
  %68 = getelementptr inbounds [2 x i32], ptr %8, i64 0, i64 0
  %69 = load i32, ptr %68, align 4
  %70 = icmp eq i32 %69, 0
  br i1 %70, label %71, label %78

71:                                               ; preds = %67
  %72 = getelementptr inbounds [2 x i32], ptr %8, i64 0, i64 1
  %73 = load i32, ptr %72, align 4
  %74 = icmp eq i32 %73, 0
  br i1 %74, label %75, label %78

75:                                               ; preds = %71
  %76 = load i64, ptr %9, align 8
  %77 = icmp eq i64 %76, -9223372036854775808
  br label %78

78:                                               ; preds = %75, %71, %67, %63, %59, %55, %51, %0
  %79 = phi i1 [ false, %71 ], [ false, %67 ], [ false, %63 ], [ false, %59 ], [ false, %55 ], [ false, %51 ], [ false, %0 ], [ %77, %75 ]
  %80 = zext i1 %79 to i64
  %81 = select i1 %79, i32 0, i32 1
  ret i32 %81
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.5"}
