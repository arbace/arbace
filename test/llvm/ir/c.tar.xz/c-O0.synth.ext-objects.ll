; ModuleID = 'test/c/synth/ext-objects.c'
source_filename = "test/c/synth/ext-objects.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"*mid\00", align 1
@mid = internal global ptr getelementptr (i8, ptr @data, i64 8), align 8
@.str.2 = private unnamed_addr constant [17 x i8] c"(int)(end - mid)\00", align 1
@end = internal global ptr getelementptr (i8, ptr @data, i64 20), align 8
@.str.3 = private unnamed_addr constant [9 x i8] c"%s = %s\0A\00", align 1
@.str.4 = private unnamed_addr constant [9 x i8] c"names[2]\00", align 1
@names = internal global [3 x ptr] [ptr @.str.10, ptr @.str.11, ptr @.str.12], align 16
@.str.5 = private unnamed_addr constant [9 x i8] c"greeting\00", align 1
@.str.6 = private unnamed_addr constant [9 x i8] c"hi there\00", align 1
@.str.7 = private unnamed_addr constant [8 x i8] c"kv[1].k\00", align 1
@.str.8 = private unnamed_addr constant [8 x i8] c"kv[1].v\00", align 1
@.str.9 = private unnamed_addr constant [13 x i8] c"fp == printf\00", align 1
@fp = internal global ptr @printf, align 8
@data = internal global [5 x i32] [i32 10, i32 20, i32 30, i32 40, i32 50], align 16
@.str.10 = private unnamed_addr constant [5 x i8] c"zero\00", align 1
@.str.11 = private unnamed_addr constant [4 x i8] c"one\00", align 1
@.str.12 = private unnamed_addr constant [4 x i8] c"two\00", align 1
@.str.13 = private unnamed_addr constant [2 x i8] c"a\00", align 1
@.str.14 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@kv = internal global [2 x { ptr, i32, [4 x i8] }] [{ ptr, i32, [4 x i8] } { ptr @.str.13, i32 1, [4 x i8] zeroinitializer }, { ptr, i32, [4 x i8] } { ptr @.str.14, i32 2, [4 x i8] zeroinitializer }], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load ptr, ptr @mid, align 8
  %3 = load i32, ptr %2, align 4
  %4 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i32 noundef %3)
  %5 = load ptr, ptr @end, align 8
  %6 = load ptr, ptr @mid, align 8
  %7 = ptrtoint ptr %5 to i64
  %8 = ptrtoint ptr %6 to i64
  %9 = sub i64 %7, %8
  %10 = sdiv exact i64 %9, 4
  %11 = trunc i64 %10 to i32
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.2, i32 noundef %11)
  %13 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @names, i64 16), align 16
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.4, ptr noundef %13)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.5, ptr noundef @.str.6)
  %16 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @kv, i64 16), align 16
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, ptr noundef @.str.7, ptr noundef %16)
  %18 = load i32, ptr getelementptr inbounds nuw (i8, ptr @kv, i64 24), align 8
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i32 noundef %18)
  %20 = load ptr, ptr @fp, align 8
  %21 = icmp eq ptr %20, @printf
  %22 = zext i1 %21 to i32
  %23 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.9, i32 noundef %22)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
