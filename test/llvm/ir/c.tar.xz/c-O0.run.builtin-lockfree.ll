; ModuleID = 'test/c/run/builtin-lockfree.c'
source_filename = "test/c/run/builtin-lockfree.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [13 x i8] c"%d %d %d %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [19 x i8] c"%d %d %d %d %d %d\0A\00", align 1
@.str.2 = private unnamed_addr constant [10 x i8] c"%d %d %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [7 x i8] c"%d %d\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  %3 = alloca i16, align 2
  %4 = alloca i32, align 4
  %5 = alloca i64, align 8
  %6 = alloca i8, align 1
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  %9 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef 1, i32 noundef 1, i32 noundef 1, i32 noundef 1)
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef 1, i32 noundef 1, i32 noundef 1, i32 noundef 1)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef 1, i32 noundef 1, i32 noundef 1, i32 noundef 1, i32 noundef 1, i32 noundef 1)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, i32 noundef 1, i32 noundef 2, i32 noundef 2)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i32 noundef 1, i32 noundef 1)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str.3, i32 noundef 1, i32 noundef 0)
  store volatile i64 1, ptr %8, align 8
  br label %15

15:                                               ; preds = %26, %0
  %16 = load volatile i64, ptr %8, align 8
  %17 = icmp ule i64 %16, 8
  br i1 %17, label %18, label %29

18:                                               ; preds = %15
  %19 = load volatile i64, ptr %8, align 8
  %20 = call zeroext i1 @__atomic_is_lock_free(i64 noundef %19, ptr noundef null)
  br i1 %20, label %21, label %24

21:                                               ; preds = %18
  %22 = load volatile i64, ptr %8, align 8
  %23 = call zeroext i1 @__atomic_is_lock_free(i64 noundef %22, ptr noundef %5)
  br i1 %23, label %25, label %24

24:                                               ; preds = %21, %18
  store i32 1, ptr %1, align 4
  br label %30

25:                                               ; preds = %21
  br label %26

26:                                               ; preds = %25
  %27 = load volatile i64, ptr %8, align 8
  %28 = mul i64 %27, 2
  store volatile i64 %28, ptr %8, align 8
  br label %15, !llvm.loop !6

29:                                               ; preds = %15
  store i32 0, ptr %1, align 4
  br label %30

30:                                               ; preds = %29, %24
  %31 = load i32, ptr %1, align 4
  ret i32 %31
}

declare i32 @printf(ptr noundef, ...) #1

declare i1 @__atomic_is_lock_free(i64, ptr)

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.5"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
