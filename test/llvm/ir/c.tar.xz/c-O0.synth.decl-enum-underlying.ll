; ModuleID = 'test/c/synth/decl-enum-underlying.c'
source_filename = "test/c/synth/decl-enum-underlying.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [10 x i8] c"%s = %zu\0A\00", align 1
@.str.1 = private unnamed_addr constant [19 x i8] c"sizeof(enum small)\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"%s = %d\0A\00", align 1
@.str.3 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.4 = private unnamed_addr constant [40 x i8] c"_Generic(S1, enum small: 1, default: 0)\00", align 1
@.str.5 = private unnamed_addr constant [11 x i8] c"%s = %lld\0A\00", align 1
@.str.6 = private unnamed_addr constant [14 x i8] c"(long long)W1\00", align 1
@.str.7 = private unnamed_addr constant [14 x i8] c"(long long)W0\00", align 1
@.str.8 = private unnamed_addr constant [18 x i8] c"sizeof(enum wide)\00", align 1
@.str.9 = private unnamed_addr constant [15 x i8] c"(long long)BIG\00", align 1
@.str.10 = private unnamed_addr constant [18 x i8] c"(long long)BIGGER\00", align 1
@.str.11 = private unnamed_addr constant [11 x i8] c"sizeof BIG\00", align 1
@.str.12 = private unnamed_addr constant [8 x i8] c"(int)F0\00", align 1
@.str.13 = private unnamed_addr constant [17 x i8] c"sizeof(enum fwd)\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i8, align 1
  store i32 0, ptr %1, align 4
  store i8 -1, ptr %2, align 1
  %3 = load i8, ptr %2, align 1
  %4 = zext i8 %3 to i32
  %5 = add nsw i32 %4, 1
  %6 = trunc i32 %5 to i8
  store i8 %6, ptr %2, align 1
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.1, i64 noundef 1)
  %8 = load i8, ptr %2, align 1
  %9 = zext i8 %8 to i32
  %10 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.3, i32 noundef %9)
  %11 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.4, i32 noundef 1)
  %12 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.6, i64 noundef 4294967296)
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.7, i64 noundef -1)
  %14 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.8, i64 noundef 8)
  %15 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.9, i64 noundef 4294967296)
  %16 = call i32 (ptr, ...) @printf(ptr noundef @.str.5, ptr noundef @.str.10, i64 noundef 4294967297)
  %17 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.11, i64 noundef 8)
  %18 = call i32 (ptr, ...) @printf(ptr noundef @.str.2, ptr noundef @.str.12, i32 noundef -3)
  %19 = call i32 (ptr, ...) @printf(ptr noundef @.str, ptr noundef @.str.13, i64 noundef 2)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
