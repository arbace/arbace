; ModuleID = '921019-2.c'
source_filename = "921019-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !10 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !15, !DIExpression(), !17)
    #dbg_declare(ptr %3, !18, !DIExpression(), !19)
  store double 5.000000e-01, ptr %3, align 8, !dbg !19
  %4 = load double, ptr %3, align 8, !dbg !20
  %5 = fdiv double %4, 2.000000e-01, !dbg !21
  store double %5, ptr %2, align 8, !dbg !22
  %6 = load double, ptr %2, align 8, !dbg !23
  %7 = load double, ptr %2, align 8, !dbg !25
  %8 = fcmp une double %6, %7, !dbg !26
  br i1 %8, label %9, label %10, !dbg !26

9:                                                ; preds = %0
  call void @abort() #3, !dbg !27
  unreachable, !dbg !27

10:                                               ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !28
  unreachable, !dbg !28
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "921019-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "40cd5ca54f9ba0126eb44965fab1bf94")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 5, type: !11, scopeLine: 6, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !14)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!14 = !{}
!15 = !DILocalVariable(name: "x", scope: !10, file: !1, line: 7, type: !16)
!16 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!17 = !DILocation(line: 7, column: 10, scope: !10)
!18 = !DILocalVariable(name: "y", scope: !10, file: !1, line: 7, type: !16)
!19 = !DILocation(line: 7, column: 12, scope: !10)
!20 = !DILocation(line: 8, column: 5, scope: !10)
!21 = !DILocation(line: 8, column: 6, scope: !10)
!22 = !DILocation(line: 8, column: 4, scope: !10)
!23 = !DILocation(line: 9, column: 6, scope: !24)
!24 = distinct !DILexicalBlock(scope: !10, file: !1, line: 9, column: 6)
!25 = !DILocation(line: 9, column: 9, scope: !24)
!26 = !DILocation(line: 9, column: 7, scope: !24)
!27 = !DILocation(line: 10, column: 5, scope: !24)
!28 = !DILocation(line: 11, column: 3, scope: !10)
