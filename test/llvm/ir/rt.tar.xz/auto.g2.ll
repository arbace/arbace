; ModuleID = 'test/cpp/samples/auto.cpp'
source_filename = "test/cpp/samples/auto.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@_ZN1n1gE = dso_local local_unnamed_addr global i32 0, align 4, !dbg !0

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef i32 @_Z1fv() local_unnamed_addr #0 !dbg !21 {
  ret i32 1, !dbg !23
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef i32 @_Z1hv() local_unnamed_addr #0 !dbg !24 {
  ret i32 2, !dbg !25
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local noundef range(i32 -2147483637, -2147483648) i32 @main() local_unnamed_addr #1 !dbg !26 {
    #dbg_value(i32 1, !28, !DIExpression(), !43)
    #dbg_value(ptr poison, !29, !DIExpression(), !43)
    #dbg_value(ptr poison, !36, !DIExpression(), !43)
    #dbg_value(i32 poison, !37, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !43)
    #dbg_value(i32 2, !37, !DIExpression(DW_OP_LLVM_fragment, 32, 32), !43)
    #dbg_value(i32 poison, !37, !DIExpression(DW_OP_LLVM_fragment, 64, 32), !43)
    #dbg_value(i32 3, !41, !DIExpression(), !43)
  %1 = load i32, ptr @_ZN1n1gE, align 4, !dbg !44, !tbaa !45
  %2 = add nsw i32 %1, 11, !dbg !46
  ret i32 %2, !dbg !47
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(read, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.dbg.cu = !{!5}
!llvm.module.flags = !{!8, !9, !10, !11, !12, !13, !14}
!llvm.ident = !{!15}
!llvm.errno.tbaa = !{!16}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "g", linkageName: "_ZN1n1gE", scope: !2, file: !3, line: 1, type: !4, isLocal: false, isDefinition: true)
!2 = !DINamespace(name: "n", scope: null)
!3 = !DIFile(filename: "test/cpp/samples/auto.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "31157ccf4de43d8c98d7d7d3fa284a78")
!4 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!5 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !6, globals: !7, splitDebugInlining: false, nameTableKind: None)
!6 = !{!4}
!7 = !{!0}
!8 = !{i32 7, !"Dwarf Version", i32 5}
!9 = !{i32 2, !"Debug Info Version", i32 3}
!10 = !{i32 4, !"probe-stack", !"inline-asm"}
!11 = !{i32 8, !"PIC Level", i32 2}
!12 = !{i32 7, !"PIE Level", i32 2}
!13 = !{i32 7, !"uwtable", i32 2}
!14 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!15 = !{!"Alpine clang version 23.1.5"}
!16 = !{!17, !18, i64 0}
!17 = !{!"__libc_errno", !18, i64 0}
!18 = !{!"int", !19, i64 0}
!19 = !{!"omnipotent char", !20, i64 0}
!20 = !{!"Simple C++ TBAA"}
!21 = distinct !DISubprogram(name: "f", linkageName: "_Z1fv", scope: !3, file: !3, line: 2, type: !22, scopeLine: 2, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !5, keyInstructions: true)
!22 = !DISubroutineType(types: !6)
!23 = !DILocation(line: 2, column: 12, scope: !21, atomGroup: 1, atomRank: 1)
!24 = distinct !DISubprogram(name: "h", linkageName: "_Z1hv", scope: !3, file: !3, line: 3, type: !22, scopeLine: 3, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !5, keyInstructions: true)
!25 = !DILocation(line: 3, column: 19, scope: !24, atomGroup: 1, atomRank: 1)
!26 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 4, type: !22, scopeLine: 4, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !5, retainedNodes: !27, keyInstructions: true)
!27 = !{!28, !29, !32, !36, !37, !41}
!28 = !DILocalVariable(name: "x", scope: !26, file: !3, line: 5, type: !4)
!29 = !DILocalVariable(name: "y", scope: !26, file: !3, line: 5, type: !30)
!30 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !31, size: 64)
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!32 = distinct !DICompositeType(tag: DW_TAG_class_type, scope: !26, file: !3, line: 5, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !33)
!33 = !{!34}
!34 = !DIDerivedType(tag: DW_TAG_member, name: "x", scope: !32, file: !3, line: 5, baseType: !35, size: 64)
!35 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !4, size: 64)
!36 = !DILocalVariable(name: "l", scope: !26, file: !3, line: 5, type: !32)
!37 = !DILocalVariable(name: "a", scope: !26, file: !3, line: 6, type: !38)
!38 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !39)
!39 = !{!40}
!40 = !DISubrange(count: 3)
!41 = !DILocalVariable(name: "u", scope: !26, file: !3, line: 7, type: !42)
!42 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!43 = !DILocation(line: 0, scope: !26)
!44 = !DILocation(line: 8, column: 26, scope: !26)
!45 = !{!18, !18, i64 0}
!46 = !DILocation(line: 8, column: 56, scope: !26, atomGroup: 7, atomRank: 2)
!47 = !DILocation(line: 8, column: 3, scope: !26, atomGroup: 7, atomRank: 1)
