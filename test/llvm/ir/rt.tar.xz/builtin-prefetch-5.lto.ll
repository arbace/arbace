; ModuleID = 'builtin-prefetch-5.c'
source_filename = "builtin-prefetch-5.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i16, i16, [8 x i8] }

@arr = dso_local global [100 x i8] zeroinitializer, align 16, !guid !0
@ptr = dso_local local_unnamed_addr global ptr @arr, align 8, !guid !1
@idx = dso_local local_unnamed_addr global i32 3, align 4, !guid !2
@s = dso_local global %struct.S zeroinitializer, align 2, !guid !3

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_ptr(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 !guid !11 {
  tail call void @llvm.prefetch.p0(ptr %0, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @llvm.prefetch.p0(ptr readonly captures(none), i32 immarg range(i32 0, 2), i32 immarg range(i32 0, 4), i32 immarg range(i32 0, 2)) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_idx(ptr nofree noundef readonly captures(none) %0, i32 noundef %1) local_unnamed_addr #0 !guid !12 {
  %3 = sext i32 %1 to i64
  %4 = getelementptr inbounds i8, ptr %0, i64 %3
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_ptr() local_unnamed_addr #2 !guid !13 {
  %1 = load ptr, ptr @ptr, align 8
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_idx() local_unnamed_addr #2 !guid !14 {
  %1 = load ptr, ptr @ptr, align 8
  %2 = load i32, ptr @idx, align 4
  %3 = sext i32 %2 to i64
  %4 = getelementptr inbounds i8, ptr %1, i64 %3
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #3 !guid !15 {
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 2), i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1)
  %1 = load ptr, ptr @ptr, align 8
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 3
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 1
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  store i32 3, ptr @idx, align 4
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1)
  store ptr %3, ptr @ptr, align 8
  store i32 2, ptr @idx, align 4
  tail call void @llvm.prefetch.p0(ptr nonnull %3, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1)
  tail call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #4

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }

!llvm.module.flags = !{!4, !5, !6, !7, !8, !9}
!llvm.ident = !{!10}

!0 = !{i64 -4572173231984228281}
!1 = !{i64 1974638705143618125}
!2 = !{i64 -3169819746481955969}
!3 = !{i64 133020994095859459}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 1, !"ThinLTO", i32 0}
!9 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!10 = !{!"Alpine clang version 23.1.5"}
!11 = !{i64 -8943267485732428195}
!12 = !{i64 -7927257742678667478}
!13 = !{i64 -2546577813634903652}
!14 = !{i64 7977078558970972024}
!15 = !{i64 -2624081020897602054}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "s", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 133020994095859459
^2 = gv: (name: "ptr", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0), refs: (^7)))) ; guid = 1974638705143618125
^3 = gv: (name: "glob_idx", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 6, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), refs: (^2, ^8)))) ; guid = 7977078558970972024
^4 = gv: (name: "arg_ptr", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 2, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 9503476587977123421
^5 = gv: (name: "arg_idx", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 4, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 10519486331030884138
^6 = gv: (name: "exit") ; guid = 11176115373368037362
^7 = gv: (name: "arr", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 13874570841725323335
^8 = gv: (name: "idx", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 15276924327227595647
^9 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 18, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 1), calls: ((callee: ^6, tail: 1)), refs: (^1, ^2, ^8)))) ; guid = 15822663052811949562
^10 = gv: (name: "glob_ptr", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 3, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), refs: (^2)))) ; guid = 15900166260074647964
^11 = flags: 8
^12 = blockcount: 0
