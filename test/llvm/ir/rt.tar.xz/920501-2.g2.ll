; ModuleID = '920501-2.c'
source_filename = "920501-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@factab = dso_local local_unnamed_addr global [10 x i64] zeroinitializer, align 16, !dbg !0

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(none) uwtable
define dso_local i64 @gcd_ll(i64 noundef %0, i64 noundef %1) local_unnamed_addr #0 !dbg !19 {
    #dbg_value(i64 %0, !23, !DIExpression(), !25)
    #dbg_value(i64 %1, !24, !DIExpression(), !25)
  %3 = icmp eq i64 %1, 0, !dbg !26
  br i1 %3, label %12, label %4, !dbg !31

4:                                                ; preds = %2, %9
  %5 = phi i64 [ %10, %9 ], [ %1, %2 ]
  %6 = phi i64 [ %7, %9 ], [ %0, %2 ]
    #dbg_value(i64 %5, !24, !DIExpression(), !25)
    #dbg_value(i64 %6, !23, !DIExpression(), !25)
  %7 = urem i64 %6, %5, !dbg !32
    #dbg_value(i64 %7, !23, !DIExpression(), !25)
  %8 = icmp eq i64 %7, 0, !dbg !33
  br i1 %8, label %12, label %9, !dbg !35

9:                                                ; preds = %4
  %10 = urem i64 %5, %7, !dbg !36
    #dbg_value(i64 %10, !24, !DIExpression(), !25)
    #dbg_value(i64 %7, !23, !DIExpression(), !25)
  %11 = icmp eq i64 %10, 0, !dbg !37
  br i1 %11, label %12, label %4, !dbg !38, !llvm.loop !39

12:                                               ; preds = %9, %4, %2
  %13 = phi i64 [ %0, %2 ], [ %5, %4 ], [ %7, %9 ], !dbg !42
  ret i64 %13, !dbg !43
}

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(none) uwtable
define dso_local i64 @powmod_ll(i64 noundef %0, i32 noundef %1, i64 noundef %2) local_unnamed_addr #0 !dbg !44 {
    #dbg_value(i64 %0, !49, !DIExpression(), !56)
    #dbg_value(i32 %1, !50, !DIExpression(), !56)
    #dbg_value(i64 %2, !51, !DIExpression(), !56)
  %4 = icmp eq i32 %1, 0, !dbg !57
  br i1 %4, label %26, label %5, !dbg !59

5:                                                ; preds = %3
  %6 = lshr i32 %1, 1, !dbg !60
    #dbg_value(i32 poison, !52, !DIExpression(), !56)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !56)
    #dbg_value(i64 %0, !53, !DIExpression(), !56)
  %7 = icmp eq i32 %6, 0, !dbg !63
  br i1 %7, label %26, label %8, !dbg !66

8:                                                ; preds = %5
  %9 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %6, i1 true), !dbg !60
    #dbg_value(!DIArgList(i32 32, i32 %9), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !56)
  %10 = sub nuw nsw i32 32, %9, !dbg !60
    #dbg_value(i32 %10, !54, !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !56)
  br label %11, !dbg !67

11:                                               ; preds = %8, %23
  %12 = phi i32 [ %14, %23 ], [ %10, %8 ]
  %13 = phi i64 [ %24, %23 ], [ %0, %8 ]
  %14 = add nsw i32 %12, -1, !dbg !56
    #dbg_value(i32 %14, !54, !DIExpression(), !56)
    #dbg_value(i64 %13, !53, !DIExpression(), !56)
  %15 = mul i64 %13, %13, !dbg !68
  %16 = urem i64 %15, %2, !dbg !70
    #dbg_value(i64 %16, !53, !DIExpression(), !56)
  %17 = shl nuw i32 1, %14, !dbg !71
  %18 = and i32 %17, %1, !dbg !73
  %19 = icmp eq i32 %18, 0, !dbg !74
  br i1 %19, label %23, label %20, !dbg !75

20:                                               ; preds = %11
  %21 = mul i64 %16, %0, !dbg !76
  %22 = urem i64 %21, %2, !dbg !77
    #dbg_value(i64 %22, !53, !DIExpression(), !56)
  br label %23, !dbg !78

23:                                               ; preds = %11, %20
  %24 = phi i64 [ %22, %20 ], [ %16, %11 ], !dbg !79
    #dbg_value(i64 %24, !53, !DIExpression(), !56)
    #dbg_value(i32 %14, !54, !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !56)
  %25 = icmp samesign ugt i32 %12, 1, !dbg !80
  br i1 %25, label %11, label %26, !dbg !81, !llvm.loop !82

26:                                               ; preds = %23, %5, %3
  %27 = phi i64 [ 1, %3 ], [ %0, %5 ], [ %24, %23 ], !dbg !56
  ret i64 %27, !dbg !85
}

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local void @facts(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) local_unnamed_addr #1 !dbg !86 {
    #dbg_value(i64 %0, !90, !DIExpression(), !105)
    #dbg_value(i32 %1, !91, !DIExpression(), !105)
    #dbg_value(i32 %2, !92, !DIExpression(), !105)
    #dbg_value(i32 %3, !93, !DIExpression(), !105)
    #dbg_value(ptr @factab, !94, !DIExpression(), !105)
    #dbg_value(i64 1, !98, !DIExpression(), !105)
  %5 = sext i32 %1 to i64, !dbg !106
    #dbg_value(i64 %5, !99, !DIExpression(), !105)
    #dbg_value(i32 1, !102, !DIExpression(), !105)
    #dbg_value(i32 0, !104, !DIExpression(), !105)
  %6 = sext i32 %2 to i64, !dbg !107
    #dbg_value(i64 %6, !96, !DIExpression(), !105)
    #dbg_value(i64 %6, !97, !DIExpression(), !105)
    #dbg_value(i32 1, !100, !DIExpression(), !105)
  %7 = icmp eq i32 %3, 0
  %8 = lshr i32 %3, 1
  %9 = icmp eq i32 %8, 0
  %10 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %8, i1 true)
  %11 = sub nuw nsw i32 32, %10
  %12 = add nsw i64 %5, 1
  br label %13, !dbg !108

13:                                               ; preds = %4, %105
  %14 = phi i32 [ 0, %4 ], [ %109, %105 ]
  %15 = phi i32 [ 1, %4 ], [ %108, %105 ]
  %16 = phi i64 [ %0, %4 ], [ %107, %105 ]
  %17 = phi i32 [ 1, %4 ], [ %110, %105 ]
  %18 = phi ptr [ @factab, %4 ], [ %106, %105 ]
  %19 = phi i64 [ 1, %4 ], [ %85, %105 ]
  %20 = phi i64 [ %6, %4 ], [ %79, %105 ]
  %21 = phi i64 [ %6, %4 ], [ %77, %105 ]
    #dbg_value(i32 %14, !104, !DIExpression(), !105)
    #dbg_value(i32 %15, !102, !DIExpression(), !105)
    #dbg_value(i64 %16, !90, !DIExpression(), !105)
    #dbg_value(i32 %17, !100, !DIExpression(), !105)
    #dbg_value(ptr %18, !94, !DIExpression(), !105)
    #dbg_value(i64 %19, !98, !DIExpression(), !105)
    #dbg_value(i64 %20, !97, !DIExpression(), !105)
    #dbg_value(i64 %21, !96, !DIExpression(), !105)
    #dbg_value(i64 %21, !49, !DIExpression(), !110)
    #dbg_value(i32 %3, !50, !DIExpression(), !110)
    #dbg_value(i64 %16, !51, !DIExpression(), !110)
  br i1 %7, label %75, label %22, !dbg !114

22:                                               ; preds = %13
    #dbg_value(i32 poison, !52, !DIExpression(), !110)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !110)
    #dbg_value(i64 %21, !53, !DIExpression(), !110)
  br i1 %9, label %55, label %23, !dbg !115

23:                                               ; preds = %22, %35
  %24 = phi i32 [ %26, %35 ], [ %11, %22 ]
  %25 = phi i64 [ %36, %35 ], [ %21, %22 ]
  %26 = add nsw i32 %24, -1, !dbg !110
    #dbg_value(i32 %26, !54, !DIExpression(), !110)
    #dbg_value(i64 %25, !53, !DIExpression(), !110)
  %27 = mul i64 %25, %25, !dbg !116
  %28 = urem i64 %27, %16, !dbg !117
    #dbg_value(i64 %28, !53, !DIExpression(), !110)
  %29 = shl nuw i32 1, %26, !dbg !118
  %30 = and i32 %29, %3, !dbg !119
  %31 = icmp eq i32 %30, 0, !dbg !120
  br i1 %31, label %35, label %32, !dbg !121

32:                                               ; preds = %23
  %33 = mul i64 %28, %21, !dbg !122
  %34 = urem i64 %33, %16, !dbg !123
    #dbg_value(i64 %34, !53, !DIExpression(), !110)
  br label %35, !dbg !124

35:                                               ; preds = %32, %23
  %36 = phi i64 [ %34, %32 ], [ %28, %23 ], !dbg !125
    #dbg_value(i64 %36, !53, !DIExpression(), !110)
    #dbg_value(i32 %26, !54, !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !110)
  %37 = icmp samesign ugt i32 %24, 1, !dbg !126
  br i1 %37, label %23, label %38, !dbg !127, !llvm.loop !128

38:                                               ; preds = %35
  %39 = add i64 %36, %5, !dbg !131
    #dbg_value(i32 poison, !52, !DIExpression(), !132)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !132)
    #dbg_value(i64 %20, !53, !DIExpression(), !132)
  br label %40, !dbg !134

40:                                               ; preds = %38, %52
  %41 = phi i32 [ %43, %52 ], [ %11, %38 ]
  %42 = phi i64 [ %53, %52 ], [ %20, %38 ]
  %43 = add nsw i32 %41, -1, !dbg !132
    #dbg_value(i32 %43, !54, !DIExpression(), !132)
    #dbg_value(i64 %42, !53, !DIExpression(), !132)
  %44 = mul i64 %42, %42, !dbg !135
  %45 = urem i64 %44, %16, !dbg !136
    #dbg_value(i64 %45, !53, !DIExpression(), !132)
  %46 = shl nuw i32 1, %43, !dbg !137
  %47 = and i32 %46, %3, !dbg !138
  %48 = icmp eq i32 %47, 0, !dbg !139
  br i1 %48, label %52, label %49, !dbg !140

49:                                               ; preds = %40
  %50 = mul i64 %45, %20, !dbg !141
  %51 = urem i64 %50, %16, !dbg !142
    #dbg_value(i64 %51, !53, !DIExpression(), !132)
  br label %52, !dbg !143

52:                                               ; preds = %49, %40
  %53 = phi i64 [ %51, %49 ], [ %45, %40 ], !dbg !144
    #dbg_value(i64 %53, !53, !DIExpression(), !132)
    #dbg_value(i32 %43, !54, !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !132)
  %54 = icmp samesign ugt i32 %41, 1, !dbg !145
  br i1 %54, label %40, label %58, !dbg !146, !llvm.loop !147

55:                                               ; preds = %22
    #dbg_value(i32 poison, !52, !DIExpression(), !132)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !132)
    #dbg_value(i64 %20, !53, !DIExpression(), !132)
  %56 = add i64 %21, %5, !dbg !150
  %57 = add i64 %20, %5, !dbg !151
    #dbg_value(i32 poison, !52, !DIExpression(), !152)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !152)
    #dbg_value(i64 %57, !53, !DIExpression(), !152)
  br label %75, !dbg !154

58:                                               ; preds = %52
  %59 = add i64 %53, %5, !dbg !155
    #dbg_value(i32 poison, !52, !DIExpression(), !152)
    #dbg_value(!DIArgList(i32 poison, i32 poison), !54, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !152)
    #dbg_value(i64 %59, !53, !DIExpression(), !152)
  br label %60, !dbg !154

60:                                               ; preds = %58, %72
  %61 = phi i32 [ %63, %72 ], [ %11, %58 ]
  %62 = phi i64 [ %73, %72 ], [ %59, %58 ]
  %63 = add nsw i32 %61, -1, !dbg !152
    #dbg_value(i32 %63, !54, !DIExpression(), !152)
    #dbg_value(i64 %62, !53, !DIExpression(), !152)
  %64 = mul i64 %62, %62, !dbg !156
  %65 = urem i64 %64, %16, !dbg !157
    #dbg_value(i64 %65, !53, !DIExpression(), !152)
  %66 = shl nuw i32 1, %63, !dbg !158
  %67 = and i32 %66, %3, !dbg !159
  %68 = icmp eq i32 %67, 0, !dbg !160
  br i1 %68, label %72, label %69, !dbg !161

69:                                               ; preds = %60
  %70 = mul i64 %65, %59, !dbg !162
  %71 = urem i64 %70, %16, !dbg !163
    #dbg_value(i64 %71, !53, !DIExpression(), !152)
  br label %72, !dbg !164

72:                                               ; preds = %69, %60
  %73 = phi i64 [ %71, %69 ], [ %65, %60 ], !dbg !165
    #dbg_value(i64 %73, !53, !DIExpression(), !152)
    #dbg_value(i32 %63, !54, !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value), !152)
  %74 = icmp samesign ugt i32 %61, 1, !dbg !166
  br i1 %74, label %60, label %75, !dbg !167, !llvm.loop !168

75:                                               ; preds = %72, %55, %13
  %76 = phi i64 [ 1, %13 ], [ %21, %55 ], [ %36, %72 ]
  %77 = phi i64 [ %12, %13 ], [ %56, %55 ], [ %39, %72 ]
  %78 = phi i64 [ 1, %13 ], [ %57, %55 ], [ %73, %72 ], !dbg !152
  %79 = add i64 %78, %5, !dbg !171
    #dbg_value(i64 %79, !97, !DIExpression(), !105)
  %80 = icmp ugt i64 %77, %79, !dbg !172
  %81 = sub i64 %76, %78, !dbg !174
  %82 = sub i64 %78, %76, !dbg !174
  %83 = select i1 %80, i64 %81, i64 %82, !dbg !174
    #dbg_value(i64 %83, !103, !DIExpression(), !105)
  %84 = mul i64 %83, %19, !dbg !175
  %85 = urem i64 %84, %16, !dbg !176
    #dbg_value(i64 %85, !98, !DIExpression(), !105)
  %86 = icmp eq i32 %17, %15, !dbg !177
  br i1 %86, label %87, label %105, !dbg !179

87:                                               ; preds = %75
  %88 = add nsw i32 %14, 1, !dbg !180
    #dbg_value(i32 %88, !104, !DIExpression(), !105)
  %89 = add nsw i32 %88, %15, !dbg !182
    #dbg_value(i32 %89, !102, !DIExpression(), !105)
    #dbg_value(i64 %85, !23, !DIExpression(), !183)
    #dbg_value(i64 %16, !24, !DIExpression(), !183)
  br label %90, !dbg !185

90:                                               ; preds = %87, %95
  %91 = phi i64 [ %96, %95 ], [ %16, %87 ]
  %92 = phi i64 [ %93, %95 ], [ %85, %87 ]
    #dbg_value(i64 %91, !24, !DIExpression(), !183)
    #dbg_value(i64 %92, !23, !DIExpression(), !183)
  %93 = urem i64 %92, %91, !dbg !186
    #dbg_value(i64 %93, !23, !DIExpression(), !183)
  %94 = icmp eq i64 %93, 0, !dbg !187
  br i1 %94, label %98, label %95, !dbg !188

95:                                               ; preds = %90
  %96 = urem i64 %91, %93, !dbg !189
    #dbg_value(i64 %96, !24, !DIExpression(), !183)
    #dbg_value(i64 %93, !23, !DIExpression(), !183)
  %97 = icmp eq i64 %96, 0, !dbg !190
  br i1 %97, label %98, label %90, !dbg !191, !llvm.loop !192

98:                                               ; preds = %90, %95
  %99 = phi i64 [ %93, %95 ], [ %91, %90 ], !dbg !195
    #dbg_value(i64 %99, !101, !DIExpression(), !105)
  %100 = icmp eq i64 %99, 1, !dbg !196
  br i1 %100, label %105, label %101, !dbg !198

101:                                              ; preds = %98
  %102 = getelementptr inbounds nuw i8, ptr %18, i64 8, !dbg !199
    #dbg_value(ptr %102, !94, !DIExpression(), !105)
  store i64 %99, ptr %18, align 8, !dbg !201
  %103 = udiv i64 %16, %99, !dbg !202
    #dbg_value(i64 %103, !90, !DIExpression(), !105)
  %104 = icmp eq i64 %103, 1, !dbg !203
  br i1 %104, label %112, label %105, !dbg !205

105:                                              ; preds = %75, %101, %98
  %106 = phi ptr [ %102, %101 ], [ %18, %98 ], [ %18, %75 ], !dbg !105
  %107 = phi i64 [ %103, %101 ], [ %16, %98 ], [ %16, %75 ]
  %108 = phi i32 [ %89, %101 ], [ %89, %98 ], [ %15, %75 ], !dbg !105
  %109 = phi i32 [ %88, %101 ], [ %88, %98 ], [ %14, %75 ], !dbg !105
    #dbg_value(i32 %109, !104, !DIExpression(), !105)
    #dbg_value(i32 %108, !102, !DIExpression(), !105)
    #dbg_value(i64 %107, !90, !DIExpression(), !105)
    #dbg_value(ptr %106, !94, !DIExpression(), !105)
  %110 = add nuw nsw i32 %17, 1, !dbg !206
    #dbg_value(i32 %110, !100, !DIExpression(), !105)
    #dbg_value(i64 %85, !98, !DIExpression(), !105)
    #dbg_value(i64 %79, !97, !DIExpression(), !105)
    #dbg_value(i64 %77, !96, !DIExpression(), !105)
  %111 = icmp eq i32 %110, 10000, !dbg !207
  br i1 %111, label %112, label %13, !dbg !208, !llvm.loop !209

112:                                              ; preds = %105, %101
  ret void, !dbg !212
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !213 {
    #dbg_value(i32 27, !220, !DIExpression(), !221)
    #dbg_value(i64 134217727, !217, !DIExpression(), !221)
    #dbg_value(i32 -1, !219, !DIExpression(), !221)
    #dbg_value(i32 3, !218, !DIExpression(), !221)
  tail call void @facts(i64 noundef 134217727, i32 noundef -1, i32 noundef 3, i32 noundef 27), !dbg !222
  %1 = load i64, ptr @factab, align 16, !dbg !223
  %2 = icmp ne i64 %1, 7, !dbg !225
  %3 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 8), align 8
  %4 = icmp ne i64 %3, 73
  %5 = select i1 %2, i1 true, i1 %4, !dbg !226
  %6 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 16), align 16
  %7 = icmp ne i64 %6, 262657
  %8 = select i1 %5, i1 true, i1 %7, !dbg !226
  br i1 %8, label %9, label %10, !dbg !226

9:                                                ; preds = %0
  tail call void @abort() #6, !dbg !227
  unreachable, !dbg !227

10:                                               ; preds = %0
  tail call void @exit(i32 noundef 0) #6, !dbg !228
  unreachable, !dbg !228
}

; Function Attrs: cold nofree noreturn nounwind
declare void @abort() local_unnamed_addr #3

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #5

attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree norecurse nosync nounwind sspstrong memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!11, !12, !13, !14, !15, !16, !17}
!llvm.ident = !{!18}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "factab", scope: !2, file: !3, line: 48, type: !8, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "920501-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "b7e9d89cc440725f54ffc347e96c79dc")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!7 = !{!0}
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 640, elements: !9)
!9 = !{!10}
!10 = !DISubrange(count: 10)
!11 = !{i32 7, !"Dwarf Version", i32 5}
!12 = !{i32 2, !"Debug Info Version", i32 3}
!13 = !{i32 4, !"probe-stack", !"inline-asm"}
!14 = !{i32 8, !"PIC Level", i32 2}
!15 = !{i32 7, !"PIE Level", i32 2}
!16 = !{i32 7, !"uwtable", i32 2}
!17 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!18 = !{!"Alpine clang version 23.1.5"}
!19 = distinct !DISubprogram(name: "gcd_ll", scope: !3, file: !3, line: 5, type: !20, scopeLine: 6, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !22, keyInstructions: true)
!20 = !DISubroutineType(types: !21)
!21 = !{!5, !6, !6}
!22 = !{!23, !24}
!23 = !DILocalVariable(name: "x", arg: 1, scope: !19, file: !3, line: 5, type: !6)
!24 = !DILocalVariable(name: "y", arg: 2, scope: !19, file: !3, line: 5, type: !6)
!25 = !DILocation(line: 0, scope: !19)
!26 = !DILocation(line: 9, column: 13, scope: !27, atomGroup: 31, atomRank: 2)
!27 = distinct !DILexicalBlock(scope: !28, file: !3, line: 9, column: 11)
!28 = distinct !DILexicalBlock(scope: !29, file: !3, line: 8, column: 5)
!29 = distinct !DILexicalBlock(scope: !30, file: !3, line: 7, column: 3)
!30 = distinct !DILexicalBlock(scope: !19, file: !3, line: 7, column: 3)
!31 = !DILocation(line: 9, column: 13, scope: !27, atomGroup: 31, atomRank: 1)
!32 = !DILocation(line: 11, column: 13, scope: !28, atomGroup: 3, atomRank: 2)
!33 = !DILocation(line: 12, column: 13, scope: !34, atomGroup: 4, atomRank: 2)
!34 = distinct !DILexicalBlock(scope: !28, file: !3, line: 12, column: 11)
!35 = !DILocation(line: 12, column: 13, scope: !34, atomGroup: 4, atomRank: 1)
!36 = !DILocation(line: 14, column: 13, scope: !28, atomGroup: 6, atomRank: 2)
!37 = !DILocation(line: 9, column: 13, scope: !27, atomGroup: 1, atomRank: 2)
!38 = !DILocation(line: 9, column: 13, scope: !27, atomGroup: 1, atomRank: 1)
!39 = distinct !{!39, !40, !41}
!40 = !DILocation(line: 7, column: 3, scope: !30)
!41 = !DILocation(line: 15, column: 5, scope: !30)
!42 = !DILocation(line: 0, scope: !28)
!43 = !DILocation(line: 16, column: 1, scope: !19, atomGroup: 8, atomRank: 1)
!44 = distinct !DISubprogram(name: "powmod_ll", scope: !3, file: !3, line: 19, type: !45, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !48, keyInstructions: true)
!45 = !DISubroutineType(types: !46)
!46 = !{!6, !6, !47, !6}
!47 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!48 = !{!49, !50, !51, !52, !53, !54}
!49 = !DILocalVariable(name: "b", arg: 1, scope: !44, file: !3, line: 19, type: !6)
!50 = !DILocalVariable(name: "e", arg: 2, scope: !44, file: !3, line: 19, type: !47)
!51 = !DILocalVariable(name: "m", arg: 3, scope: !44, file: !3, line: 19, type: !6)
!52 = !DILocalVariable(name: "t", scope: !44, file: !3, line: 21, type: !47)
!53 = !DILocalVariable(name: "pow", scope: !44, file: !3, line: 22, type: !6)
!54 = !DILocalVariable(name: "i", scope: !44, file: !3, line: 23, type: !55)
!55 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!56 = !DILocation(line: 0, scope: !44)
!57 = !DILocation(line: 25, column: 9, scope: !58, atomGroup: 1, atomRank: 2)
!58 = distinct !DILexicalBlock(scope: !44, file: !3, line: 25, column: 7)
!59 = !DILocation(line: 25, column: 9, scope: !58, atomGroup: 1, atomRank: 1)
!60 = !DILocation(line: 31, column: 7, scope: !61, atomGroup: 7, atomRank: 2)
!61 = distinct !DILexicalBlock(scope: !62, file: !3, line: 30, column: 3)
!62 = distinct !DILexicalBlock(scope: !44, file: !3, line: 30, column: 3)
!63 = !DILocation(line: 38, column: 12, scope: !64, atomGroup: 34, atomRank: 1)
!64 = distinct !DILexicalBlock(scope: !65, file: !3, line: 38, column: 3)
!65 = distinct !DILexicalBlock(scope: !44, file: !3, line: 38, column: 3)
!66 = !DILocation(line: 38, column: 3, scope: !65, atomGroup: 35, atomRank: 1)
!67 = !DILocation(line: 38, column: 3, scope: !65)
!68 = !DILocation(line: 40, column: 17, scope: !69)
!69 = distinct !DILexicalBlock(scope: !64, file: !3, line: 39, column: 5)
!70 = !DILocation(line: 40, column: 23, scope: !69, atomGroup: 14, atomRank: 2)
!71 = !DILocation(line: 41, column: 14, scope: !72)
!72 = distinct !DILexicalBlock(scope: !69, file: !3, line: 41, column: 11)
!73 = !DILocation(line: 41, column: 20, scope: !72)
!74 = !DILocation(line: 41, column: 20, scope: !72, atomGroup: 15, atomRank: 2)
!75 = !DILocation(line: 41, column: 20, scope: !72, atomGroup: 15, atomRank: 1)
!76 = !DILocation(line: 42, column: 12, scope: !72)
!77 = !DILocation(line: 42, column: 16, scope: !72, atomGroup: 16, atomRank: 2)
!78 = !DILocation(line: 42, column: 2, scope: !72)
!79 = !DILocation(line: 0, scope: !69)
!80 = !DILocation(line: 38, column: 12, scope: !64, atomGroup: 12, atomRank: 1)
!81 = !DILocation(line: 38, column: 3, scope: !65, atomGroup: 13, atomRank: 1)
!82 = distinct !{!82, !67, !83, !84}
!83 = !DILocation(line: 43, column: 5, scope: !65)
!84 = !{!"llvm.loop.mustprogress"}
!85 = !DILocation(line: 46, column: 1, scope: !44, atomGroup: 20, atomRank: 1)
!86 = distinct !DISubprogram(name: "facts", scope: !3, file: !3, line: 51, type: !87, scopeLine: 56, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !89, keyInstructions: true)
!87 = !DISubroutineType(types: !88)
!88 = !{null, !6, !55, !55, !47}
!89 = !{!90, !91, !92, !93, !94, !96, !97, !98, !99, !100, !101, !102, !103, !104}
!90 = !DILocalVariable(name: "t", arg: 1, scope: !86, file: !3, line: 52, type: !6)
!91 = !DILocalVariable(name: "a_int", arg: 2, scope: !86, file: !3, line: 53, type: !55)
!92 = !DILocalVariable(name: "x0", arg: 3, scope: !86, file: !3, line: 54, type: !55)
!93 = !DILocalVariable(name: "p", arg: 4, scope: !86, file: !3, line: 55, type: !47)
!94 = !DILocalVariable(name: "xp", scope: !86, file: !3, line: 57, type: !95)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!96 = !DILocalVariable(name: "x", scope: !86, file: !3, line: 58, type: !6)
!97 = !DILocalVariable(name: "y", scope: !86, file: !3, line: 58, type: !6)
!98 = !DILocalVariable(name: "q", scope: !86, file: !3, line: 59, type: !5)
!99 = !DILocalVariable(name: "a", scope: !86, file: !3, line: 60, type: !6)
!100 = !DILocalVariable(name: "i", scope: !86, file: !3, line: 61, type: !55)
!101 = !DILocalVariable(name: "d", scope: !86, file: !3, line: 62, type: !5)
!102 = !DILocalVariable(name: "j", scope: !86, file: !3, line: 63, type: !55)
!103 = !DILocalVariable(name: "tmp", scope: !86, file: !3, line: 64, type: !5)
!104 = !DILocalVariable(name: "jj", scope: !86, file: !3, line: 65, type: !55)
!105 = !DILocation(line: 0, scope: !86)
!106 = !DILocation(line: 60, column: 26, scope: !86, atomGroup: 3, atomRank: 2)
!107 = !DILocation(line: 67, column: 7, scope: !86, atomGroup: 6, atomRank: 2)
!108 = !DILocation(line: 70, column: 3, scope: !109, atomGroup: 41, atomRank: 1)
!109 = distinct !DILexicalBlock(scope: !86, file: !3, line: 70, column: 3)
!110 = !DILocation(line: 0, scope: !44, inlinedAt: !111)
!111 = distinct !DILocation(line: 72, column: 11, scope: !112)
!112 = distinct !DILexicalBlock(scope: !113, file: !3, line: 71, column: 5)
!113 = distinct !DILexicalBlock(scope: !109, file: !3, line: 70, column: 3)
!114 = !DILocation(line: 25, column: 9, scope: !58, inlinedAt: !111, atomGroup: 1, atomRank: 1)
!115 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !111, atomGroup: 35, atomRank: 1)
!116 = !DILocation(line: 40, column: 17, scope: !69, inlinedAt: !111)
!117 = !DILocation(line: 40, column: 23, scope: !69, inlinedAt: !111, atomGroup: 14, atomRank: 2)
!118 = !DILocation(line: 41, column: 14, scope: !72, inlinedAt: !111)
!119 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !111)
!120 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !111, atomGroup: 15, atomRank: 2)
!121 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !111, atomGroup: 15, atomRank: 1)
!122 = !DILocation(line: 42, column: 12, scope: !72, inlinedAt: !111)
!123 = !DILocation(line: 42, column: 16, scope: !72, inlinedAt: !111, atomGroup: 16, atomRank: 2)
!124 = !DILocation(line: 42, column: 2, scope: !72, inlinedAt: !111)
!125 = !DILocation(line: 0, scope: !69, inlinedAt: !111)
!126 = !DILocation(line: 38, column: 12, scope: !64, inlinedAt: !111, atomGroup: 12, atomRank: 1)
!127 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !111, atomGroup: 13, atomRank: 1)
!128 = distinct !{!128, !129, !130, !84}
!129 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !111)
!130 = !DILocation(line: 43, column: 5, scope: !65, inlinedAt: !111)
!131 = !DILocation(line: 72, column: 31, scope: !112, atomGroup: 11, atomRank: 2)
!132 = !DILocation(line: 0, scope: !44, inlinedAt: !133)
!133 = distinct !DILocation(line: 73, column: 11, scope: !112)
!134 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !133, atomGroup: 35, atomRank: 1)
!135 = !DILocation(line: 40, column: 17, scope: !69, inlinedAt: !133)
!136 = !DILocation(line: 40, column: 23, scope: !69, inlinedAt: !133, atomGroup: 14, atomRank: 2)
!137 = !DILocation(line: 41, column: 14, scope: !72, inlinedAt: !133)
!138 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !133)
!139 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !133, atomGroup: 15, atomRank: 2)
!140 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !133, atomGroup: 15, atomRank: 1)
!141 = !DILocation(line: 42, column: 12, scope: !72, inlinedAt: !133)
!142 = !DILocation(line: 42, column: 16, scope: !72, inlinedAt: !133, atomGroup: 16, atomRank: 2)
!143 = !DILocation(line: 42, column: 2, scope: !72, inlinedAt: !133)
!144 = !DILocation(line: 0, scope: !69, inlinedAt: !133)
!145 = !DILocation(line: 38, column: 12, scope: !64, inlinedAt: !133, atomGroup: 12, atomRank: 1)
!146 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !133, atomGroup: 13, atomRank: 1)
!147 = distinct !{!147, !148, !149, !84}
!148 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !133)
!149 = !DILocation(line: 43, column: 5, scope: !65, inlinedAt: !133)
!150 = !DILocation(line: 72, column: 31, scope: !112, atomGroup: 42, atomRank: 2)
!151 = !DILocation(line: 73, column: 31, scope: !112, atomGroup: 43, atomRank: 2)
!152 = !DILocation(line: 0, scope: !44, inlinedAt: !153)
!153 = distinct !DILocation(line: 74, column: 11, scope: !112)
!154 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !153, atomGroup: 35, atomRank: 1)
!155 = !DILocation(line: 73, column: 31, scope: !112, atomGroup: 12, atomRank: 2)
!156 = !DILocation(line: 40, column: 17, scope: !69, inlinedAt: !153)
!157 = !DILocation(line: 40, column: 23, scope: !69, inlinedAt: !153, atomGroup: 14, atomRank: 2)
!158 = !DILocation(line: 41, column: 14, scope: !72, inlinedAt: !153)
!159 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !153)
!160 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !153, atomGroup: 15, atomRank: 2)
!161 = !DILocation(line: 41, column: 20, scope: !72, inlinedAt: !153, atomGroup: 15, atomRank: 1)
!162 = !DILocation(line: 42, column: 12, scope: !72, inlinedAt: !153)
!163 = !DILocation(line: 42, column: 16, scope: !72, inlinedAt: !153, atomGroup: 16, atomRank: 2)
!164 = !DILocation(line: 42, column: 2, scope: !72, inlinedAt: !153)
!165 = !DILocation(line: 0, scope: !69, inlinedAt: !153)
!166 = !DILocation(line: 38, column: 12, scope: !64, inlinedAt: !153, atomGroup: 12, atomRank: 1)
!167 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !153, atomGroup: 13, atomRank: 1)
!168 = distinct !{!168, !169, !170, !84}
!169 = !DILocation(line: 38, column: 3, scope: !65, inlinedAt: !153)
!170 = !DILocation(line: 43, column: 5, scope: !65, inlinedAt: !153)
!171 = !DILocation(line: 74, column: 31, scope: !112, atomGroup: 13, atomRank: 2)
!172 = !DILocation(line: 76, column: 13, scope: !173, atomGroup: 14, atomRank: 2)
!173 = distinct !DILexicalBlock(scope: !112, file: !3, line: 76, column: 11)
!174 = !DILocation(line: 76, column: 13, scope: !173, atomGroup: 14, atomRank: 1)
!175 = !DILocation(line: 80, column: 34, scope: !112)
!176 = !DILocation(line: 80, column: 40, scope: !112, atomGroup: 17, atomRank: 2)
!177 = !DILocation(line: 82, column: 13, scope: !178, atomGroup: 18, atomRank: 2)
!178 = distinct !DILexicalBlock(scope: !112, file: !3, line: 82, column: 11)
!179 = !DILocation(line: 82, column: 13, scope: !178, atomGroup: 18, atomRank: 1)
!180 = !DILocation(line: 84, column: 7, scope: !181, atomGroup: 19, atomRank: 2)
!181 = distinct !DILexicalBlock(scope: !178, file: !3, line: 83, column: 2)
!182 = !DILocation(line: 85, column: 6, scope: !181, atomGroup: 20, atomRank: 2)
!183 = !DILocation(line: 0, scope: !19, inlinedAt: !184)
!184 = distinct !DILocation(line: 86, column: 8, scope: !181)
!185 = !DILocation(line: 9, column: 13, scope: !27, inlinedAt: !184, atomGroup: 31, atomRank: 1)
!186 = !DILocation(line: 11, column: 13, scope: !28, inlinedAt: !184, atomGroup: 3, atomRank: 2)
!187 = !DILocation(line: 12, column: 13, scope: !34, inlinedAt: !184, atomGroup: 4, atomRank: 2)
!188 = !DILocation(line: 12, column: 13, scope: !34, inlinedAt: !184, atomGroup: 4, atomRank: 1)
!189 = !DILocation(line: 14, column: 13, scope: !28, inlinedAt: !184, atomGroup: 6, atomRank: 2)
!190 = !DILocation(line: 9, column: 13, scope: !27, inlinedAt: !184, atomGroup: 1, atomRank: 2)
!191 = !DILocation(line: 9, column: 13, scope: !27, inlinedAt: !184, atomGroup: 1, atomRank: 1)
!192 = distinct !{!192, !193, !194}
!193 = !DILocation(line: 7, column: 3, scope: !30, inlinedAt: !184)
!194 = !DILocation(line: 15, column: 5, scope: !30, inlinedAt: !184)
!195 = !DILocation(line: 0, scope: !28, inlinedAt: !184)
!196 = !DILocation(line: 87, column: 10, scope: !197, atomGroup: 22, atomRank: 2)
!197 = distinct !DILexicalBlock(scope: !181, file: !3, line: 87, column: 8)
!198 = !DILocation(line: 87, column: 10, scope: !197, atomGroup: 22, atomRank: 1)
!199 = !DILocation(line: 89, column: 11, scope: !200, atomGroup: 24, atomRank: 2)
!200 = distinct !DILexicalBlock(scope: !197, file: !3, line: 88, column: 6)
!201 = !DILocation(line: 89, column: 14, scope: !200, atomGroup: 23, atomRank: 1)
!202 = !DILocation(line: 90, column: 10, scope: !200, atomGroup: 25, atomRank: 2)
!203 = !DILocation(line: 91, column: 14, scope: !204, atomGroup: 26, atomRank: 2)
!204 = distinct !DILexicalBlock(scope: !200, file: !3, line: 91, column: 12)
!205 = !DILocation(line: 91, column: 14, scope: !204, atomGroup: 26, atomRank: 1)
!206 = !DILocation(line: 70, column: 27, scope: !113, atomGroup: 28, atomRank: 2)
!207 = !DILocation(line: 70, column: 17, scope: !113, atomGroup: 9, atomRank: 1)
!208 = !DILocation(line: 70, column: 3, scope: !109, atomGroup: 10, atomRank: 1)
!209 = distinct !{!209, !210, !211, !84}
!210 = !DILocation(line: 70, column: 3, scope: !109)
!211 = !DILocation(line: 98, column: 5, scope: !109)
!212 = !DILocation(line: 99, column: 1, scope: !86, atomGroup: 30, atomRank: 1)
!213 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 102, type: !214, scopeLine: 103, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !216, keyInstructions: true)
!214 = !DISubroutineType(types: !215)
!215 = !{!55}
!216 = !{!217, !218, !219, !220}
!217 = !DILocalVariable(name: "t", scope: !213, file: !3, line: 104, type: !6)
!218 = !DILocalVariable(name: "x0", scope: !213, file: !3, line: 105, type: !47)
!219 = !DILocalVariable(name: "a", scope: !213, file: !3, line: 105, type: !47)
!220 = !DILocalVariable(name: "p", scope: !213, file: !3, line: 106, type: !47)
!221 = !DILocation(line: 0, scope: !213)
!222 = !DILocation(line: 114, column: 3, scope: !213)
!223 = !DILocation(line: 115, column: 7, scope: !224)
!224 = distinct !DILexicalBlock(scope: !213, file: !3, line: 115, column: 7)
!225 = !DILocation(line: 115, column: 17, scope: !224, atomGroup: 5, atomRank: 2)
!226 = !DILocation(line: 115, column: 22, scope: !224, atomGroup: 5, atomRank: 1)
!227 = !DILocation(line: 116, column: 5, scope: !224)
!228 = !DILocation(line: 117, column: 3, scope: !213)
