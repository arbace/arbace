; ModuleID = '20000224-1.c'
source_filename = "20000224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@loop_1 = dso_local local_unnamed_addr global i32 100, align 4, !guid !0
@loop_2 = dso_local local_unnamed_addr global i32 7, align 4, !guid !1
@flag = dso_local local_unnamed_addr global i32 0, align 4, !guid !2

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local noundef i32 @test() local_unnamed_addr #0 !guid !10 {
  %1 = load i32, ptr @loop_1, align 4
  %2 = icmp sgt i32 %1, 0
  br i1 %2, label %3, label %18

3:                                                ; preds = %0
  %4 = load i32, ptr @flag, align 4
  %5 = load i32, ptr @loop_2, align 4
  %6 = icmp slt i32 %5, 1
  br label %7

7:                                                ; preds = %3, %7
  %8 = phi i32 [ 0, %3 ], [ %14, %7 ]
  %9 = phi i32 [ %4, %3 ], [ %15, %7 ]
  %10 = and i32 %9, 1
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %11, i1 true, i1 %6
  %13 = select i1 %12, i32 0, i32 %5
  %14 = add i32 %8, %13
  %15 = add nsw i32 %9, 1
  %16 = icmp sgt i32 %1, %14
  br i1 %16, label %7, label %17, !llvm.loop !11

17:                                               ; preds = %7
  store i32 %15, ptr @flag, align 4
  br label %18

18:                                               ; preds = %17, %0
  ret i32 1
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #1 !guid !13 {
  %1 = tail call i32 @test()
  tail call void @exit(i32 noundef 0) #3
  unreachable
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #2

attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = !{i64 7793598977148951844}
!1 = !{i64 -1769417731161179400}
!2 = !{i64 4060466772873869874}
!3 = !{i32 4, !"probe-stack", !"inline-asm"}
!4 = !{i32 8, !"PIC Level", i32 2}
!5 = !{i32 7, !"PIE Level", i32 2}
!6 = !{i32 7, !"uwtable", i32 2}
!7 = !{i32 1, !"ThinLTO", i32 0}
!8 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = !{i64 8346051122425466633}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.mustprogress"}
!13 = !{i64 -2624081020897602054}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "flag", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 4060466772873869874
^2 = gv: (name: "loop_1", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 7793598977148951844
^3 = gv: (name: "test", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 20, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), refs: (^2, ^1, ^6)))) ; guid = 8346051122425466633
^4 = gv: (name: "exit") ; guid = 11176115373368037362
^5 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 3, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 1), calls: ((callee: ^3, tail: 1), (callee: ^4, tail: 1))))) ; guid = 15822663052811949562
^6 = gv: (name: "loop_2", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 16677326342548372216
^7 = flags: 8
^8 = blockcount: 0
