; ModuleID = 'test/cpp/samples/classes.cpp'
source_filename = "test/cpp/samples/classes.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

$_ZN1BD2Ev = comdat any

$_ZN1DD0Ev = comdat any

$_ZTI1B = comdat any

$_ZTS1B = comdat any

@_ZTV1D = dso_local local_unnamed_addr constant { [5 x ptr] } { [5 x ptr] [ptr null, ptr @_ZTI1D, ptr @_ZN1BD2Ev, ptr @_ZN1DD0Ev, ptr @_ZNK1D1fEv] }, align 8, !dbg !0
@_ZTI1D = dso_local constant { ptr, ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv120__si_class_type_infoE, i64 2), ptr @_ZTS1D, ptr @_ZTI1B }, align 8
@_ZTVN10__cxxabiv120__si_class_type_infoE = external global [0 x ptr]
@_ZTS1D = dso_local constant [3 x i8] c"1D\00", align 1
@_ZTI1B = linkonce_odr dso_local constant { ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv117__class_type_infoE, i64 2), ptr @_ZTS1B }, comdat, align 8
@_ZTVN10__cxxabiv117__class_type_infoE = external global [0 x ptr]
@_ZTS1B = linkonce_odr dso_local constant [3 x i8] c"1B\00", comdat, align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: read) uwtable
define dso_local noundef i32 @_ZNK1D1fEv(ptr nofree noundef nonnull readonly align 8 captures(none) dereferenceable(16) %0) unnamed_addr #0 align 2 !dbg !59 {
    #dbg_value(ptr %0, !61, !DIExpression(), !63)
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 12, !dbg !64
  %3 = load i32, ptr %2, align 4, !dbg !65, !tbaa !66
  ret i32 %3, !dbg !69
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef i32 @main() local_unnamed_addr #1 personality ptr @__gxx_personality_v0 !dbg !70 {
    #dbg_assign(i1 poison, !77, !DIExpression(), !100, ptr poison, !DIExpression(), !101)
    #dbg_value(ptr poison, !72, !DIExpression(), !101)
    #dbg_value(ptr poison, !74, !DIExpression(), !101)
  ret i32 1, !dbg !102
}

declare i32 @__gxx_personality_v0(...)

; Function Attrs: nobuiltin nounwind
declare !dbg !103 void @_ZdlPvm(ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nounwind sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BD2Ev(ptr noundef nonnull align 8 dead_on_return(12) dereferenceable(12) %0) unnamed_addr #3 comdat align 2 !dbg !107 {
    #dbg_value(ptr %0, !109, !DIExpression(), !111)
  ret void, !dbg !112
}

; Function Attrs: inlinehint mustprogress nounwind sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DD0Ev(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #4 comdat align 2 !dbg !113 {
    #dbg_value(ptr %0, !116, !DIExpression(), !117)
  tail call void @_ZdlPvm(ptr noundef nonnull %0, i64 noundef 16) #5, !dbg !118
  ret void, !dbg !119
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nobuiltin nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { inlinehint mustprogress nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { builtin nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!46, !47, !48, !49, !50, !51, !52}
!llvm.ident = !{!53}
!llvm.errno.tbaa = !{!54}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "__clang_vtable", linkageName: "_ZTV1D", scope: !2, file: !3, type: !7, isLocal: false, isDefinition: true, declaration: !30, align: 64)
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "test/cpp/samples/classes.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "afba01b0f804261eccc954aa302e4827")
!4 = !{!0, !5}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "__clang_vtable", linkageName: "_ZTV1B", scope: !2, file: !3, type: !7, isLocal: false, isDefinition: true, declaration: !8, align: 64)
!7 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!8 = !DIDerivedType(tag: DW_TAG_variable, name: "__clang_vtable", scope: !9, file: !3, baseType: !7, flags: DIFlagPrivate | DIFlagArtificial | DIFlagStaticMember)
!9 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "B", file: !3, line: 1, size: 128, flags: DIFlagTypePassByReference | DIFlagNonTrivial, elements: !10, vtableHolder: !9, identifier: "_ZTS1B")
!10 = !{!11, !17, !18, !22, !25}
!11 = !DIDerivedType(tag: DW_TAG_member, name: "_vptr$B", scope: !3, file: !3, baseType: !12, size: 64, flags: DIFlagArtificial)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "__vtbl_ptr_type", baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !9, file: !3, line: 1, baseType: !16, size: 32, offset: 64)
!18 = !DISubprogram(name: "B", linkageName: "_ZN1BC4Ei", scope: !9, file: !3, line: 1, type: !19, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!19 = !DISubroutineType(types: !20)
!20 = !{null, !21, !16}
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!22 = !DISubprogram(name: "~B", linkageName: "_ZN1BD4Ev", scope: !9, file: !3, line: 1, type: !23, scopeLine: 1, containingType: !9, virtualIndex: 0, flags: DIFlagPrototyped, spFlags: DISPFlagVirtual | DISPFlagOptimized)
!23 = !DISubroutineType(types: !24)
!24 = !{null, !21}
!25 = !DISubprogram(name: "f", linkageName: "_ZNK1B1fEv", scope: !9, file: !3, line: 1, type: !26, scopeLine: 1, containingType: !9, virtualIndex: 2, flags: DIFlagPrototyped, spFlags: DISPFlagPureVirtual | DISPFlagOptimized)
!26 = !DISubroutineType(types: !27)
!27 = !{!16, !28}
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!30 = !DIDerivedType(tag: DW_TAG_variable, name: "__clang_vtable", scope: !31, file: !3, baseType: !7, flags: DIFlagArtificial | DIFlagStaticMember)
!31 = distinct !DICompositeType(tag: DW_TAG_class_type, name: "D", file: !3, line: 2, size: 128, flags: DIFlagTypePassByReference | DIFlagNonTrivial, elements: !32, vtableHolder: !9)
!32 = !{!33, !34, !35, !37, !41}
!33 = !DIDerivedType(tag: DW_TAG_inheritance, scope: !31, baseType: !9, flags: DIFlagPublic, extraData: i32 0)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !31, file: !3, line: 2, baseType: !16, size: 32, offset: 96)
!35 = !DIDerivedType(tag: DW_TAG_variable, name: "k", scope: !31, file: !3, line: 2, baseType: !36, flags: DIFlagStaticMember, extraData: i32 3)
!36 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!37 = !DISubprogram(name: "D", linkageName: "_ZN1DC4Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagPublic | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!38 = !DISubroutineType(types: !39)
!39 = !{null, !40}
!40 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!41 = !DISubprogram(name: "f", linkageName: "_ZNK1D1fEv", scope: !31, file: !3, line: 2, type: !42, scopeLine: 2, containingType: !31, virtualIndex: 2, flags: DIFlagPublic | DIFlagPrototyped, spFlags: DISPFlagVirtual | DISPFlagOptimized)
!42 = !DISubroutineType(types: !43)
!43 = !{!16, !44}
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !31)
!46 = !{i32 7, !"Dwarf Version", i32 5}
!47 = !{i32 2, !"Debug Info Version", i32 3}
!48 = !{i32 4, !"probe-stack", !"inline-asm"}
!49 = !{i32 8, !"PIC Level", i32 2}
!50 = !{i32 7, !"PIE Level", i32 2}
!51 = !{i32 7, !"uwtable", i32 2}
!52 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!53 = !{!"Alpine clang version 23.1.5"}
!54 = !{!55, !56, i64 0}
!55 = !{!"__libc_errno", !56, i64 0}
!56 = !{!"int", !57, i64 0}
!57 = !{!"omnipotent char", !58, i64 0}
!58 = !{!"Simple C++ TBAA"}
!59 = distinct !DISubprogram(name: "f", linkageName: "_ZNK1D1fEv", scope: !31, file: !3, line: 3, type: !42, scopeLine: 3, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !41, retainedNodes: !60, keyInstructions: true)
!60 = !{!61}
!61 = !DILocalVariable(name: "this", arg: 1, scope: !59, type: !62, flags: DIFlagArtificial | DIFlagObjectPointer)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!63 = !DILocation(line: 0, scope: !59)
!64 = !DILocation(line: 3, column: 27, scope: !59)
!65 = !DILocation(line: 3, column: 27, scope: !59, atomGroup: 1, atomRank: 2)
!66 = !{!67, !56, i64 12}
!67 = !{!"_ZTS1D", !68, i64 0, !56, i64 12}
!68 = !{!"_ZTS1B", !56, i64 8}
!69 = !DILocation(line: 3, column: 20, scope: !59, atomGroup: 1, atomRank: 1)
!70 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 8, type: !14, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !71, keyInstructions: true)
!71 = !{!72, !74, !75, !77, !81, !84, !85, !86, !88, !90, !92, !93}
!72 = !DILocalVariable(name: "p", scope: !70, file: !3, line: 9, type: !73)
!73 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64)
!74 = !DILocalVariable(name: "q", scope: !70, file: !3, line: 9, type: !73)
!75 = !DILocalVariable(name: "d", scope: !70, file: !3, line: 9, type: !76)
!76 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64)
!77 = !DILocalVariable(name: "v", scope: !70, file: !3, line: 10, type: !78)
!78 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !79)
!79 = !{!80}
!80 = !DISubrange(count: 2)
!81 = !DILocalVariable(name: "__range1", scope: !82, type: !83, flags: DIFlagArtificial)
!82 = distinct !DILexicalBlock(scope: !70, file: !3, line: 11, column: 3)
!83 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !78, size: 64)
!84 = !DILocalVariable(name: "__begin1", scope: !82, type: !73, flags: DIFlagArtificial)
!85 = !DILocalVariable(name: "__end1", scope: !82, type: !73, flags: DIFlagArtificial)
!86 = !DILocalVariable(name: "x", scope: !87, file: !3, line: 11, type: !16)
!87 = distinct !DILexicalBlock(scope: !82, file: !3, line: 11, column: 3)
!88 = !DILocalVariable(name: "y", scope: !89, file: !3, line: 12, type: !16)
!89 = distinct !DILexicalBlock(scope: !70, file: !3, line: 12, column: 18)
!90 = !DILocalVariable(name: "i", scope: !91, file: !3, line: 13, type: !16)
!91 = distinct !DILexicalBlock(scope: !70, file: !3, line: 13, column: 3)
!92 = !DILocalVariable(name: "e", scope: !70, file: !3, line: 15, type: !16)
!93 = !DILocalVariable(name: "w", scope: !70, file: !3, line: 16, type: !94)
!94 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "V<int, 2>", file: !3, line: 6, size: 64, flags: DIFlagTypePassByValue, elements: !95, templateParams: !97, identifier: "_ZTS1VIiLi2EE")
!95 = !{!96}
!96 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !94, file: !3, line: 6, baseType: !78, size: 64)
!97 = !{!98, !99}
!98 = !DITemplateTypeParameter(name: "X", type: !16)
!99 = !DITemplateValueParameter(name: "N", type: !16, defaulted: true, value: i32 2)
!100 = distinct !DIAssignID()
!101 = !DILocation(line: 0, scope: !70)
!102 = !DILocation(line: 18, column: 1, scope: !70, atomGroup: 26, atomRank: 1)
!103 = !DISubprogram(name: "operator delete", linkageName: "_ZdlPvm", scope: !3, file: !3, type: !104, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!104 = !DISubroutineType(types: !105)
!105 = !{null, !7, !106}
!106 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!107 = distinct !DISubprogram(name: "~B", linkageName: "_ZN1BD2Ev", scope: !9, file: !3, line: 1, type: !23, scopeLine: 1, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !22, retainedNodes: !108, keyInstructions: true)
!108 = !{!109}
!109 = !DILocalVariable(name: "this", arg: 1, scope: !107, type: !110, flags: DIFlagArtificial | DIFlagObjectPointer)
!110 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64)
!111 = !DILocation(line: 0, scope: !107)
!112 = !DILocation(line: 1, column: 52, scope: !107, atomGroup: 1, atomRank: 1)
!113 = distinct !DISubprogram(name: "~D", linkageName: "_ZN1DD0Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagArtificial | DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !114, retainedNodes: !115, keyInstructions: true)
!114 = !DISubprogram(name: "~D", linkageName: "_ZN1DD4Ev", scope: !31, type: !38, containingType: !31, virtualIndex: 0, flags: DIFlagPublic | DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagVirtual | DISPFlagOptimized)
!115 = !{!116}
!116 = !DILocalVariable(name: "this", arg: 1, scope: !113, type: !76, flags: DIFlagArtificial | DIFlagObjectPointer)
!117 = !DILocation(line: 0, scope: !113)
!118 = !DILocation(line: 2, column: 7, scope: !113)
!119 = !DILocation(line: 2, column: 7, scope: !113, atomGroup: 1, atomRank: 1)
