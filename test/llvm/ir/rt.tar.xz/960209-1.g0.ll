; ModuleID = '960209-1.c'
source_filename = "960209-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.a_struct = type { i8 }

@yabba = dso_local global i32 1, align 4, !dbg !0
@an_array = dso_local global [5 x %struct.a_struct] zeroinitializer, align 1, !dbg !8
@a_ptr = dso_local global ptr null, align 8, !dbg !16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f(i32 noundef %0, i64 noundef %1) #0 !dbg !28 {
  %3 = alloca i32, align 4
  %4 = alloca i8, align 1
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = trunc i32 %0 to i8
  store i8 %12, ptr %4, align 1
    #dbg_declare(ptr %4, !32, !DIExpression(), !33)
  store i64 %1, ptr %5, align 8
    #dbg_declare(ptr %5, !34, !DIExpression(), !35)
    #dbg_declare(ptr %6, !36, !DIExpression(), !38)
    #dbg_declare(ptr %7, !39, !DIExpression(), !40)
    #dbg_declare(ptr %8, !41, !DIExpression(), !42)
    #dbg_declare(ptr %9, !43, !DIExpression(), !44)
    #dbg_declare(ptr %10, !45, !DIExpression(), !46)
    #dbg_declare(ptr %11, !47, !DIExpression(), !48)
  %13 = load i64, ptr %5, align 8, !dbg !49
  %14 = icmp ne i64 %13, 0, !dbg !51
  br i1 %14, label %15, label %63, !dbg !51

15:                                               ; preds = %2
  %16 = load i32, ptr @yabba, align 4, !dbg !52
  %17 = icmp ne i32 %16, 0, !dbg !52
  br i1 %17, label %18, label %19, !dbg !52

18:                                               ; preds = %15
  store i32 -1, ptr %3, align 4, !dbg !55
  br label %75, !dbg !55

19:                                               ; preds = %15
  %20 = load i64, ptr %5, align 8, !dbg !56
  %21 = udiv i64 4000000, %20, !dbg !57
  store i64 %21, ptr %11, align 8, !dbg !58
  store i64 0, ptr %6, align 8, !dbg !59
  br label %22, !dbg !61

22:                                               ; preds = %59, %19
  %23 = load i64, ptr %6, align 8, !dbg !62
  %24 = icmp slt i64 %23, 11, !dbg !64
  br i1 %24, label %25, label %62, !dbg !65

25:                                               ; preds = %22
  store i64 0, ptr %7, align 8, !dbg !66
  br label %26, !dbg !69

26:                                               ; preds = %55, %25
  %27 = load i64, ptr %7, align 8, !dbg !70
  %28 = icmp slt i64 %27, 256, !dbg !72
  br i1 %28, label %29, label %58, !dbg !73

29:                                               ; preds = %26
  %30 = load i64, ptr %8, align 8, !dbg !74
  %31 = load i64, ptr %11, align 8, !dbg !77
  %32 = sub nsw i64 %30, %31, !dbg !78
  %33 = icmp slt i64 %32, 0, !dbg !79
  br i1 %33, label %34, label %37, !dbg !80

34:                                               ; preds = %29
  %35 = load i64, ptr %11, align 8, !dbg !81
  %36 = sub nsw i64 0, %35, !dbg !82
  br label %38, !dbg !80

37:                                               ; preds = %29
  br label %38, !dbg !80

38:                                               ; preds = %37, %34
  %39 = phi i64 [ %36, %34 ], [ 0, %37 ], !dbg !80
  %40 = load i64, ptr %9, align 8, !dbg !83
  %41 = load i64, ptr %11, align 8, !dbg !84
  %42 = sub nsw i64 %40, %41, !dbg !85
  %43 = icmp slt i64 %42, 0, !dbg !86
  br i1 %43, label %44, label %47, !dbg !87

44:                                               ; preds = %38
  %45 = load i64, ptr %11, align 8, !dbg !88
  %46 = sub nsw i64 0, %45, !dbg !89
  br label %49, !dbg !87

47:                                               ; preds = %38
  %48 = load i64, ptr %9, align 8, !dbg !90
  br label %49, !dbg !87

49:                                               ; preds = %47, %44
  %50 = phi i64 [ %46, %44 ], [ %48, %47 ], !dbg !87
  %51 = icmp slt i64 %39, %50, !dbg !91
  br i1 %51, label %52, label %54, !dbg !91

52:                                               ; preds = %49
  %53 = load i64, ptr %6, align 8, !dbg !92
  store i64 %53, ptr %10, align 8, !dbg !93
  br label %54, !dbg !94

54:                                               ; preds = %52, %49
  br label %55, !dbg !95

55:                                               ; preds = %54
  %56 = load i64, ptr %7, align 8, !dbg !96
  %57 = add nsw i64 %56, 1, !dbg !96
  store i64 %57, ptr %7, align 8, !dbg !96
  br label %26, !dbg !97, !llvm.loop !98

58:                                               ; preds = %26
  br label %59, !dbg !101

59:                                               ; preds = %58
  %60 = load i64, ptr %6, align 8, !dbg !102
  %61 = add nsw i64 %60, 1, !dbg !102
  store i64 %61, ptr %6, align 8, !dbg !102
  br label %22, !dbg !103, !llvm.loop !104

62:                                               ; preds = %22
  br label %63, !dbg !106

63:                                               ; preds = %62, %2
  %64 = load i32, ptr @yabba, align 4, !dbg !107
  %65 = icmp ne i32 %64, 0, !dbg !107
  br i1 %65, label %66, label %67, !dbg !107

66:                                               ; preds = %63
  store i32 0, ptr %3, align 4, !dbg !109
  br label %75, !dbg !109

67:                                               ; preds = %63
  %68 = load i8, ptr %4, align 1, !dbg !110
  %69 = zext i8 %68 to i64, !dbg !111
  %70 = getelementptr inbounds nuw [5 x %struct.a_struct], ptr @an_array, i64 0, i64 %69, !dbg !111
  store ptr %70, ptr @a_ptr, align 8, !dbg !112
  %71 = load i64, ptr %10, align 8, !dbg !113
  %72 = trunc i64 %71 to i8, !dbg !114
  %73 = load ptr, ptr @a_ptr, align 8, !dbg !115
  %74 = getelementptr inbounds nuw %struct.a_struct, ptr %73, i32 0, i32 0, !dbg !116
  store i8 %72, ptr %74, align 1, !dbg !117
  br label %75, !dbg !118

75:                                               ; preds = %67, %66, %18
  %76 = load i32, ptr %3, align 4, !dbg !118
  ret i32 %76, !dbg !118
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !119 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @f(i32 noundef 1, i64 noundef 0), !dbg !122
  %3 = icmp ne i32 %2, 0, !dbg !124
  br i1 %3, label %4, label %5, !dbg !124

4:                                                ; preds = %0
  call void @abort() #3, !dbg !125
  unreachable, !dbg !125

5:                                                ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !126
  unreachable, !dbg !126
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "yabba", scope: !2, file: !3, line: 11, type: !19, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "960209-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "a92ca120986bf4ca8bfe2c4cd77d7b25")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !16}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "an_array", scope: !2, file: !3, line: 9, type: !10, isLocal: false, isDefinition: true)
!10 = !DICompositeType(tag: DW_TAG_array_type, baseType: !11, size: 40, elements: !14)
!11 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "a_struct", file: !3, line: 4, size: 8, elements: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "a_character", scope: !11, file: !3, line: 6, baseType: !6, size: 8)
!14 = !{!15}
!15 = !DISubrange(count: 5)
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "a_ptr", scope: !2, file: !3, line: 10, type: !18, isLocal: false, isDefinition: true)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!19 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 4, !"probe-stack", !"inline-asm"}
!23 = !{i32 8, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 2}
!26 = !{i32 7, !"frame-pointer", i32 2}
!27 = !{!"Alpine clang version 23.1.5"}
!28 = distinct !DISubprogram(name: "f", scope: !3, file: !3, line: 14, type: !29, scopeLine: 17, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !31)
!29 = !DISubroutineType(types: !30)
!30 = !{!19, !6, !5}
!31 = !{}
!32 = !DILocalVariable(name: "a", arg: 1, scope: !28, file: !3, line: 15, type: !6)
!33 = !DILocation(line: 15, column: 20, scope: !28)
!34 = !DILocalVariable(name: "b", arg: 2, scope: !28, file: !3, line: 16, type: !5)
!35 = !DILocation(line: 16, column: 20, scope: !28)
!36 = !DILocalVariable(name: "i", scope: !28, file: !3, line: 18, type: !37)
!37 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!38 = !DILocation(line: 18, column: 8, scope: !28)
!39 = !DILocalVariable(name: "j", scope: !28, file: !3, line: 18, type: !37)
!40 = !DILocation(line: 18, column: 11, scope: !28)
!41 = !DILocalVariable(name: "p", scope: !28, file: !3, line: 18, type: !37)
!42 = !DILocation(line: 18, column: 14, scope: !28)
!43 = !DILocalVariable(name: "q", scope: !28, file: !3, line: 18, type: !37)
!44 = !DILocation(line: 18, column: 17, scope: !28)
!45 = !DILocalVariable(name: "r", scope: !28, file: !3, line: 18, type: !37)
!46 = !DILocation(line: 18, column: 20, scope: !28)
!47 = !DILocalVariable(name: "s", scope: !28, file: !3, line: 18, type: !37)
!48 = !DILocation(line: 18, column: 23, scope: !28)
!49 = !DILocation(line: 20, column: 7, scope: !50)
!50 = distinct !DILexicalBlock(scope: !28, file: !3, line: 20, column: 7)
!51 = !DILocation(line: 20, column: 9, scope: !50)
!52 = !DILocation(line: 22, column: 11, scope: !53)
!53 = distinct !DILexicalBlock(scope: !54, file: !3, line: 22, column: 11)
!54 = distinct !DILexicalBlock(scope: !50, file: !3, line: 21, column: 5)
!55 = !DILocation(line: 23, column: 2, scope: !53)
!56 = !DILocation(line: 24, column: 21, scope: !54)
!57 = !DILocation(line: 24, column: 19, scope: !54)
!58 = !DILocation(line: 24, column: 9, scope: !54)
!59 = !DILocation(line: 25, column: 14, scope: !60)
!60 = distinct !DILexicalBlock(scope: !54, file: !3, line: 25, column: 7)
!61 = !DILocation(line: 25, column: 12, scope: !60)
!62 = !DILocation(line: 25, column: 19, scope: !63)
!63 = distinct !DILexicalBlock(scope: !60, file: !3, line: 25, column: 7)
!64 = !DILocation(line: 25, column: 21, scope: !63)
!65 = !DILocation(line: 25, column: 7, scope: !60)
!66 = !DILocation(line: 27, column: 11, scope: !67)
!67 = distinct !DILexicalBlock(scope: !68, file: !3, line: 27, column: 4)
!68 = distinct !DILexicalBlock(scope: !63, file: !3, line: 26, column: 2)
!69 = !DILocation(line: 27, column: 9, scope: !67)
!70 = !DILocation(line: 27, column: 16, scope: !71)
!71 = distinct !DILexicalBlock(scope: !67, file: !3, line: 27, column: 4)
!72 = !DILocation(line: 27, column: 18, scope: !71)
!73 = !DILocation(line: 27, column: 4, scope: !67)
!74 = !DILocation(line: 29, column: 14, scope: !75)
!75 = distinct !DILexicalBlock(scope: !76, file: !3, line: 29, column: 12)
!76 = distinct !DILexicalBlock(scope: !71, file: !3, line: 28, column: 6)
!77 = !DILocation(line: 29, column: 18, scope: !75)
!78 = !DILocation(line: 29, column: 16, scope: !75)
!79 = !DILocation(line: 29, column: 20, scope: !75)
!80 = !DILocation(line: 29, column: 13, scope: !75)
!81 = !DILocation(line: 29, column: 28, scope: !75)
!82 = !DILocation(line: 29, column: 27, scope: !75)
!83 = !DILocation(line: 29, column: 40, scope: !75)
!84 = !DILocation(line: 29, column: 44, scope: !75)
!85 = !DILocation(line: 29, column: 42, scope: !75)
!86 = !DILocation(line: 29, column: 46, scope: !75)
!87 = !DILocation(line: 29, column: 38, scope: !75)
!88 = !DILocation(line: 29, column: 54, scope: !75)
!89 = !DILocation(line: 29, column: 53, scope: !75)
!90 = !DILocation(line: 29, column: 58, scope: !75)
!91 = !DILocation(line: 29, column: 35, scope: !75)
!92 = !DILocation(line: 30, column: 7, scope: !75)
!93 = !DILocation(line: 30, column: 5, scope: !75)
!94 = !DILocation(line: 30, column: 3, scope: !75)
!95 = !DILocation(line: 31, column: 6, scope: !76)
!96 = !DILocation(line: 27, column: 26, scope: !71)
!97 = !DILocation(line: 27, column: 4, scope: !71)
!98 = distinct !{!98, !73, !99, !100}
!99 = !DILocation(line: 31, column: 6, scope: !67)
!100 = !{!"llvm.loop.mustprogress"}
!101 = !DILocation(line: 32, column: 2, scope: !68)
!102 = !DILocation(line: 25, column: 28, scope: !63)
!103 = !DILocation(line: 25, column: 7, scope: !63)
!104 = distinct !{!104, !65, !105, !100}
!105 = !DILocation(line: 32, column: 2, scope: !60)
!106 = !DILocation(line: 33, column: 5, scope: !54)
!107 = !DILocation(line: 35, column: 7, scope: !108)
!108 = distinct !DILexicalBlock(scope: !28, file: !3, line: 35, column: 7)
!109 = !DILocation(line: 36, column: 5, scope: !108)
!110 = !DILocation(line: 37, column: 21, scope: !28)
!111 = !DILocation(line: 37, column: 12, scope: !28)
!112 = !DILocation(line: 37, column: 9, scope: !28)
!113 = !DILocation(line: 38, column: 40, scope: !28)
!114 = !DILocation(line: 38, column: 24, scope: !28)
!115 = !DILocation(line: 38, column: 3, scope: !28)
!116 = !DILocation(line: 38, column: 10, scope: !28)
!117 = !DILocation(line: 38, column: 22, scope: !28)
!118 = !DILocation(line: 39, column: 1, scope: !28)
!119 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 42, type: !120, scopeLine: 43, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2)
!120 = !DISubroutineType(types: !121)
!121 = !{!19}
!122 = !DILocation(line: 44, column: 7, scope: !123)
!123 = distinct !DILexicalBlock(scope: !119, file: !3, line: 44, column: 7)
!124 = !DILocation(line: 44, column: 18, scope: !123)
!125 = !DILocation(line: 45, column: 5, scope: !123)
!126 = !DILocation(line: 46, column: 3, scope: !119)
