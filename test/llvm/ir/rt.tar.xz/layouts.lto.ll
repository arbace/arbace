; ModuleID = 'test/cpp/samples/layouts.cpp'
source_filename = "test/cpp/samples/layouts.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.D = type { %struct.B.base, i8, double }
%struct.B.base = type <{ ptr, i32 }>
%struct.F = type { i8, i8, [2 x i8] }
%"struct.n::G" = type { i32 }

@gd = dso_local local_unnamed_addr global %struct.D { %struct.B.base <{ ptr getelementptr inbounds inrange(-16, 8) ({ [3 x ptr] }, ptr @_ZTV1D, i32 0, i32 0, i32 2), i32 0 }>, i8 0, double 0.000000e+00 }, align 8, !guid !0
@gf = dso_local local_unnamed_addr global %struct.F zeroinitializer, align 4, !guid !1
@gg = dso_local local_unnamed_addr global %"struct.n::G" zeroinitializer, align 4, !guid !2
@_ZTV1D = available_externally constant { [3 x ptr] } { [3 x ptr] [ptr null, ptr @_ZTI1D, ptr @_ZN1D1fEv] }, align 8, !guid !3
@_ZTI1D = external constant ptr
@llvm.global_ctors = appending global [0 x { i32, ptr, ptr }] zeroinitializer, !guid !4

declare void @_ZN1D1fEv(ptr noundef nonnull align 8 dereferenceable(24)) unnamed_addr #0

attributes #0 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!5, !6, !7, !8, !9, !10}
!llvm.ident = !{!11}
!llvm.errno.tbaa = !{!12}

!0 = !{i64 -826470217918267738}
!1 = !{i64 1487312108229213157}
!2 = !{i64 4042151791449391475}
!3 = !{i64 6327234297852968556}
!4 = !{i64 2412314959268824392}
!5 = !{i32 4, !"probe-stack", !"inline-asm"}
!6 = !{i32 8, !"PIC Level", i32 2}
!7 = !{i32 7, !"PIE Level", i32 2}
!8 = !{i32 7, !"uwtable", i32 2}
!9 = !{i32 1, !"ThinLTO", i32 0}
!10 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!11 = !{!"Alpine clang version 23.1.5"}
!12 = !{!13, !14, i64 0}
!13 = !{!"__libc_errno", !14, i64 0}
!14 = !{!"int", !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "gf", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 1487312108229213157
^2 = gv: (name: "llvm.global_ctors", summaries: (variable: (module: ^0, flags: (linkage: appending, visibility: default, notEligibleToImport: 1, live: 1, dsoLocal: 0, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 0, writeonly: 0, constant: 0)))) ; guid = 2412314959268824392
^3 = gv: (name: "_ZN1D1fEv") ; guid = 3505254451475472833
^4 = gv: (name: "gg", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 4042151791449391475
^5 = gv: (name: "_ZTV1D", summaries: (variable: (module: ^0, flags: (linkage: available_externally, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 0, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 0, writeonly: 0, constant: 1), refs: (^6, ^3)))) ; guid = 6327234297852968556
^6 = gv: (name: "_ZTI1D") ; guid = 16704553516983496837
^7 = gv: (name: "gd", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0), refs: (^5)))) ; guid = 17620273855791283878
^8 = flags: 8
^9 = blockcount: 0
