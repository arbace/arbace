; ModuleID = 'loop-7.c'
source_filename = "loop-7.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(i32 noundef %0) #0 !dbg !10 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
    #dbg_declare(ptr %2, !15, !DIExpression(), !16)
    #dbg_declare(ptr %3, !17, !DIExpression(), !19)
    #dbg_declare(ptr %4, !20, !DIExpression(), !21)
  store i32 -1, ptr %4, align 4, !dbg !21
  store i32 0, ptr %3, align 4, !dbg !22
  br label %5, !dbg !24

5:                                                ; preds = %23, %1
  %6 = load i32, ptr %3, align 4, !dbg !25
  %7 = icmp slt i32 %6, 10, !dbg !27
  br i1 %7, label %8, label %11, !dbg !28

8:                                                ; preds = %5
  %9 = load i32, ptr %4, align 4, !dbg !29
  %10 = icmp slt i32 %9, 0, !dbg !30
  br label %11

11:                                               ; preds = %8, %5
  %12 = phi i1 [ false, %5 ], [ %10, %8 ], !dbg !31
  br i1 %12, label %13, label %26, !dbg !32

13:                                               ; preds = %11
  %14 = load i32, ptr %3, align 4, !dbg !33
  %15 = zext i32 %14 to i64, !dbg !36
  %16 = shl i64 1, %15, !dbg !36
  %17 = load i32, ptr %2, align 4, !dbg !37
  %18 = zext i32 %17 to i64, !dbg !37
  %19 = icmp eq i64 %16, %18, !dbg !38
  br i1 %19, label %20, label %22, !dbg !38

20:                                               ; preds = %13
  %21 = load i32, ptr %3, align 4, !dbg !39
  store i32 %21, ptr %4, align 4, !dbg !40
  br label %22, !dbg !41

22:                                               ; preds = %20, %13
  br label %23, !dbg !42

23:                                               ; preds = %22
  %24 = load i32, ptr %3, align 4, !dbg !43
  %25 = add nsw i32 %24, 1, !dbg !43
  store i32 %25, ptr %3, align 4, !dbg !43
  br label %5, !dbg !44, !llvm.loop !45

26:                                               ; preds = %11
  %27 = load i32, ptr %4, align 4, !dbg !48
  %28 = icmp slt i32 %27, 0, !dbg !50
  br i1 %28, label %29, label %30, !dbg !50

29:                                               ; preds = %26
  call void @abort() #3, !dbg !51
  unreachable, !dbg !51

30:                                               ; preds = %26
  ret void, !dbg !52
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !53 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @foo(i32 noundef 64), !dbg !56
  call void @exit(i32 noundef 0) #4, !dbg !57
  unreachable, !dbg !57
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "loop-7.c", directory: ".", checksumkind: CSK_MD5, checksum: "52ef3ec1a2bf71515971531c1ce85d1b")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "foo", scope: !1, file: !1, line: 4, type: !11, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !14)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13}
!13 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!14 = !{}
!15 = !DILocalVariable(name: "n", arg: 1, scope: !10, file: !1, line: 4, type: !13)
!16 = !DILocation(line: 4, column: 24, scope: !10)
!17 = !DILocalVariable(name: "i", scope: !10, file: !1, line: 6, type: !18)
!18 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!19 = !DILocation(line: 6, column: 7, scope: !10)
!20 = !DILocalVariable(name: "j", scope: !10, file: !1, line: 6, type: !18)
!21 = !DILocation(line: 6, column: 10, scope: !10)
!22 = !DILocation(line: 8, column: 10, scope: !23)
!23 = distinct !DILexicalBlock(scope: !10, file: !1, line: 8, column: 3)
!24 = !DILocation(line: 8, column: 8, scope: !23)
!25 = !DILocation(line: 8, column: 15, scope: !26)
!26 = distinct !DILexicalBlock(scope: !23, file: !1, line: 8, column: 3)
!27 = !DILocation(line: 8, column: 17, scope: !26)
!28 = !DILocation(line: 8, column: 22, scope: !26)
!29 = !DILocation(line: 8, column: 25, scope: !26)
!30 = !DILocation(line: 8, column: 27, scope: !26)
!31 = !DILocation(line: 0, scope: !26)
!32 = !DILocation(line: 8, column: 3, scope: !23)
!33 = !DILocation(line: 10, column: 19, scope: !34)
!34 = distinct !DILexicalBlock(scope: !35, file: !1, line: 10, column: 11)
!35 = distinct !DILexicalBlock(scope: !26, file: !1, line: 9, column: 5)
!36 = !DILocation(line: 10, column: 16, scope: !34)
!37 = !DILocation(line: 10, column: 25, scope: !34)
!38 = !DILocation(line: 10, column: 22, scope: !34)
!39 = !DILocation(line: 11, column: 6, scope: !34)
!40 = !DILocation(line: 11, column: 4, scope: !34)
!41 = !DILocation(line: 11, column: 2, scope: !34)
!42 = !DILocation(line: 12, column: 5, scope: !35)
!43 = !DILocation(line: 8, column: 33, scope: !26)
!44 = !DILocation(line: 8, column: 3, scope: !26)
!45 = distinct !{!45, !32, !46, !47}
!46 = !DILocation(line: 12, column: 5, scope: !23)
!47 = !{!"llvm.loop.mustprogress"}
!48 = !DILocation(line: 14, column: 7, scope: !49)
!49 = distinct !DILexicalBlock(scope: !10, file: !1, line: 14, column: 7)
!50 = !DILocation(line: 14, column: 9, scope: !49)
!51 = !DILocation(line: 15, column: 5, scope: !49)
!52 = !DILocation(line: 16, column: 1, scope: !10)
!53 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 19, type: !54, scopeLine: 20, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!54 = !DISubroutineType(types: !55)
!55 = !{!18}
!56 = !DILocation(line: 21, column: 3, scope: !53)
!57 = !DILocation(line: 22, column: 3, scope: !53)
