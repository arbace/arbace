; ModuleID = 'enum-3.c'
source_filename = "enum-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@q = dso_local local_unnamed_addr global ptr null, align 8, !dbg !0
@p = dso_local local_unnamed_addr global ptr null, align 8, !dbg !10

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 !dbg !22 {
  %1 = alloca i32, align 4, !DIAssignID !27
    #dbg_assign(i1 poison, !26, !DIExpression(), !27, ptr %1, !DIExpression(), !28)
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #3, !dbg !29
  store i32 -2147483648, ptr %1, align 4, !dbg !30, !DIAssignID !31
    #dbg_assign(i32 -2147483648, !26, !DIExpression(), !31, ptr %1, !DIExpression(), !28)
  store ptr %1, ptr @q, align 8, !dbg !32
  call void @exit(i32 noundef 0) #4, !dbg !33
  unreachable, !dbg !33
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #2

attributes #0 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind }
attributes #4 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!14, !15, !16, !17, !18, !19, !20}
!llvm.ident = !{!21}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !3, line: 15, type: !13, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !9, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "enum-3.c", directory: ".", checksumkind: CSK_MD5, checksum: "91b8922c3b6304ab6ab99942dbca6c66")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "e", file: !3, line: 12, baseType: !6, size: 32, elements: !7)
!6 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!7 = !{!8}
!8 = !DIEnumerator(name: "a", value: -2147483648)
!9 = !{!10, !0}
!10 = !DIGlobalVariableExpression(var: !11, expr: !DIExpression())
!11 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !3, line: 14, type: !12, isLocal: false, isDefinition: true)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!14 = !{i32 7, !"Dwarf Version", i32 5}
!15 = !{i32 2, !"Debug Info Version", i32 3}
!16 = !{i32 4, !"probe-stack", !"inline-asm"}
!17 = !{i32 8, !"PIC Level", i32 2}
!18 = !{i32 7, !"PIE Level", i32 2}
!19 = !{i32 7, !"uwtable", i32 2}
!20 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!21 = !{!"Alpine clang version 23.1.5"}
!22 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 17, type: !23, scopeLine: 18, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !25, keyInstructions: true)
!23 = !DISubroutineType(types: !24)
!24 = !{!6}
!25 = !{!26}
!26 = !DILocalVariable(name: "x", scope: !22, file: !3, line: 19, type: !5)
!27 = distinct !DIAssignID()
!28 = !DILocation(line: 0, scope: !22)
!29 = !DILocation(line: 19, column: 3, scope: !22)
!30 = !DILocation(line: 19, column: 10, scope: !22, atomGroup: 1, atomRank: 1)
!31 = distinct !DIAssignID()
!32 = !DILocation(line: 20, column: 5, scope: !22, atomGroup: 2, atomRank: 1)
!33 = !DILocation(line: 23, column: 3, scope: !22)
