; ModuleID = 'builtin-prefetch-5.c'
source_filename = "builtin-prefetch-5.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i16, i16, [8 x i8] }

@arr = dso_local global [100 x i8] zeroinitializer, align 16, !dbg !0
@ptr = dso_local global ptr @arr, align 8, !dbg !5
@idx = dso_local global i32 3, align 4, !dbg !9
@s = dso_local global %struct.S zeroinitializer, align 2, !dbg !12

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @arg_ptr(ptr noundef %0) #0 !dbg !34 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !38, !DIExpression(), !39)
  %3 = load ptr, ptr %2, align 8, !dbg !40
  call void @llvm.prefetch.p0(ptr %3, i32 0, i32 0, i32 1), !dbg !41
  ret void, !dbg !42
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @llvm.prefetch.p0(ptr readonly captures(none), i32 immarg range(i32 0, 2), i32 immarg range(i32 0, 4), i32 immarg range(i32 0, 2)) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @arg_idx(ptr noundef %0, i32 noundef %1) #0 !dbg !43 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !46, !DIExpression(), !47)
  store i32 %1, ptr %4, align 4
    #dbg_declare(ptr %4, !48, !DIExpression(), !49)
  %5 = load ptr, ptr %3, align 8, !dbg !50
  %6 = load i32, ptr %4, align 4, !dbg !51
  %7 = sext i32 %6 to i64, !dbg !50
  %8 = getelementptr inbounds i8, ptr %5, i64 %7, !dbg !50
  call void @llvm.prefetch.p0(ptr %8, i32 0, i32 0, i32 1), !dbg !52
  ret void, !dbg !53
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @glob_ptr() #0 !dbg !54 {
  %1 = load ptr, ptr @ptr, align 8, !dbg !57
  call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1), !dbg !58
  ret void, !dbg !59
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @glob_idx() #0 !dbg !60 {
  %1 = load ptr, ptr @ptr, align 8, !dbg !61
  %2 = load i32, ptr @idx, align 4, !dbg !62
  %3 = sext i32 %2 to i64, !dbg !61
  %4 = getelementptr inbounds i8, ptr %1, i64 %3, !dbg !61
  call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1), !dbg !63
  ret void, !dbg !64
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !65 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.prefetch.p0(ptr getelementptr inbounds nuw (i8, ptr @s, i64 2), i32 0, i32 0, i32 1), !dbg !68
  call void @llvm.prefetch.p0(ptr getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1), !dbg !69
  call void @arg_ptr(ptr noundef getelementptr inbounds nuw (i8, ptr @s, i64 5)), !dbg !70
  %2 = load ptr, ptr @ptr, align 8, !dbg !71
  %3 = getelementptr inbounds i8, ptr %2, i64 3, !dbg !72
  call void @arg_ptr(ptr noundef %3), !dbg !73
  %4 = load ptr, ptr @ptr, align 8, !dbg !74
  call void @arg_idx(ptr noundef %4, i32 noundef 3), !dbg !75
  %5 = load ptr, ptr @ptr, align 8, !dbg !76
  %6 = getelementptr inbounds i8, ptr %5, i64 1, !dbg !77
  call void @arg_idx(ptr noundef %6, i32 noundef 2), !dbg !78
  store i32 3, ptr @idx, align 4, !dbg !79
  call void @glob_ptr(), !dbg !80
  call void @glob_idx(), !dbg !81
  %7 = load ptr, ptr @ptr, align 8, !dbg !82
  %8 = getelementptr inbounds nuw i8, ptr %7, i32 1, !dbg !82
  store ptr %8, ptr @ptr, align 8, !dbg !82
  store i32 2, ptr @idx, align 4, !dbg !83
  call void @glob_ptr(), !dbg !84
  call void @glob_idx(), !dbg !85
  call void @exit(i32 noundef 0) #3, !dbg !86
  unreachable, !dbg !86
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!26, !27, !28, !29, !30, !31, !32}
!llvm.ident = !{!33}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "arr", scope: !2, file: !3, line: 16, type: !23, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "builtin-prefetch-5.c", directory: ".", checksumkind: CSK_MD5, checksum: "0bf5ca2f6d5bd0aab66e4f0dce7fa3af")
!4 = !{!5, !9, !12, !0}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "ptr", scope: !2, file: !3, line: 17, type: !7, isLocal: false, isDefinition: true)
!7 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !8, size: 64)
!8 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "idx", scope: !2, file: !3, line: 18, type: !11, isLocal: false, isDefinition: true)
!11 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !3, line: 14, type: !14, isLocal: false, isDefinition: true)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "S", file: !3, line: 10, size: 96, elements: !15)
!15 = !{!16, !18, !19}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !14, file: !3, line: 11, baseType: !17, size: 16)
!17 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !14, file: !3, line: 12, baseType: !17, size: 16, offset: 16)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !14, file: !3, line: 13, baseType: !20, size: 64, offset: 32)
!20 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 64, elements: !21)
!21 = !{!22}
!22 = !DISubrange(count: 8)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 800, elements: !24)
!24 = !{!25}
!25 = !DISubrange(count: 100)
!26 = !{i32 7, !"Dwarf Version", i32 5}
!27 = !{i32 2, !"Debug Info Version", i32 3}
!28 = !{i32 4, !"probe-stack", !"inline-asm"}
!29 = !{i32 8, !"PIC Level", i32 2}
!30 = !{i32 7, !"PIE Level", i32 2}
!31 = !{i32 7, !"uwtable", i32 2}
!32 = !{i32 7, !"frame-pointer", i32 2}
!33 = !{!"Alpine clang version 23.1.5"}
!34 = distinct !DISubprogram(name: "arg_ptr", scope: !3, file: !3, line: 21, type: !35, scopeLine: 22, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !37)
!35 = !DISubroutineType(types: !36)
!36 = !{null, !7}
!37 = !{}
!38 = !DILocalVariable(name: "p", arg: 1, scope: !34, file: !3, line: 21, type: !7)
!39 = !DILocation(line: 21, column: 16, scope: !34)
!40 = !DILocation(line: 23, column: 23, scope: !34)
!41 = !DILocation(line: 23, column: 3, scope: !34)
!42 = !DILocation(line: 24, column: 1, scope: !34)
!43 = distinct !DISubprogram(name: "arg_idx", scope: !3, file: !3, line: 27, type: !44, scopeLine: 28, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !37)
!44 = !DISubroutineType(types: !45)
!45 = !{null, !7, !11}
!46 = !DILocalVariable(name: "p", arg: 1, scope: !43, file: !3, line: 27, type: !7)
!47 = !DILocation(line: 27, column: 16, scope: !43)
!48 = !DILocalVariable(name: "i", arg: 2, scope: !43, file: !3, line: 27, type: !11)
!49 = !DILocation(line: 27, column: 23, scope: !43)
!50 = !DILocation(line: 29, column: 24, scope: !43)
!51 = !DILocation(line: 29, column: 26, scope: !43)
!52 = !DILocation(line: 29, column: 3, scope: !43)
!53 = !DILocation(line: 30, column: 1, scope: !43)
!54 = distinct !DISubprogram(name: "glob_ptr", scope: !3, file: !3, line: 33, type: !55, scopeLine: 34, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2)
!55 = !DISubroutineType(types: !56)
!56 = !{null}
!57 = !DILocation(line: 35, column: 23, scope: !54)
!58 = !DILocation(line: 35, column: 3, scope: !54)
!59 = !DILocation(line: 36, column: 1, scope: !54)
!60 = distinct !DISubprogram(name: "glob_idx", scope: !3, file: !3, line: 39, type: !55, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2)
!61 = !DILocation(line: 41, column: 24, scope: !60)
!62 = !DILocation(line: 41, column: 28, scope: !60)
!63 = !DILocation(line: 41, column: 3, scope: !60)
!64 = !DILocation(line: 42, column: 1, scope: !60)
!65 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 45, type: !66, scopeLine: 46, spFlags: DISPFlagDefinition, unit: !2)
!66 = !DISubroutineType(types: !67)
!67 = !{!11}
!68 = !DILocation(line: 47, column: 3, scope: !65)
!69 = !DILocation(line: 48, column: 3, scope: !65)
!70 = !DILocation(line: 50, column: 3, scope: !65)
!71 = !DILocation(line: 51, column: 12, scope: !65)
!72 = !DILocation(line: 51, column: 15, scope: !65)
!73 = !DILocation(line: 51, column: 3, scope: !65)
!74 = !DILocation(line: 52, column: 12, scope: !65)
!75 = !DILocation(line: 52, column: 3, scope: !65)
!76 = !DILocation(line: 53, column: 12, scope: !65)
!77 = !DILocation(line: 53, column: 15, scope: !65)
!78 = !DILocation(line: 53, column: 3, scope: !65)
!79 = !DILocation(line: 54, column: 7, scope: !65)
!80 = !DILocation(line: 55, column: 3, scope: !65)
!81 = !DILocation(line: 56, column: 3, scope: !65)
!82 = !DILocation(line: 57, column: 6, scope: !65)
!83 = !DILocation(line: 58, column: 7, scope: !65)
!84 = !DILocation(line: 59, column: 3, scope: !65)
!85 = !DILocation(line: 60, column: 3, scope: !65)
!86 = !DILocation(line: 61, column: 3, scope: !65)
