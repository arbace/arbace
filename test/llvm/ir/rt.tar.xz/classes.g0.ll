; ModuleID = 'test/cpp/samples/classes.cpp'
source_filename = "test/cpp/samples/classes.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%class.D = type { %struct.B.base, i32 }
%struct.B.base = type <{ ptr, i32 }>
%struct.V = type { [2 x i32] }
%struct.B = type <{ ptr, i32, [4 x i8] }>

$_ZN1DC2Ev = comdat any

$_ZN1DD2Ev = comdat any

$_ZN1DD0Ev = comdat any

$_ZN1BC2Ei = comdat any

$_ZN1BD2Ev = comdat any

$_ZN1BD0Ev = comdat any

$_ZTI1B = comdat any

$_ZTS1B = comdat any

$_ZTV1B = comdat any

@__const.main.v = private unnamed_addr constant [2 x i32] [i32 1, i32 2], align 4
@_ZTIi = external constant ptr
@_ZTV1D = dso_local constant { [5 x ptr] } { [5 x ptr] [ptr null, ptr @_ZTI1D, ptr @_ZN1DD2Ev, ptr @_ZN1DD0Ev, ptr @_ZNK1D1fEv] }, align 8, !dbg !0
@_ZTI1D = dso_local constant { ptr, ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv120__si_class_type_infoE, i64 2), ptr @_ZTS1D, ptr @_ZTI1B }, align 8
@_ZTVN10__cxxabiv120__si_class_type_infoE = external global [0 x ptr]
@_ZTS1D = dso_local constant [3 x i8] c"1D\00", align 1
@_ZTI1B = linkonce_odr dso_local constant { ptr, ptr } { ptr getelementptr inbounds (ptr, ptr @_ZTVN10__cxxabiv117__class_type_infoE, i64 2), ptr @_ZTS1B }, comdat, align 8
@_ZTVN10__cxxabiv117__class_type_infoE = external global [0 x ptr]
@_ZTS1B = linkonce_odr dso_local constant [3 x i8] c"1B\00", comdat, align 1
@_ZTV1B = linkonce_odr dso_local constant { [5 x ptr] } { [5 x ptr] [ptr null, ptr @_ZTI1B, ptr @_ZN1BD2Ev, ptr @_ZN1BD0Ev, ptr @__cxa_pure_virtual] }, comdat, align 8, !dbg !5

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define dso_local noundef i32 @_ZNK1D1fEv(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #0 align 2 !dbg !54 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !56, !DIExpression(), !58)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %class.D, ptr %3, i32 0, i32 1, !dbg !59
  %5 = load i32, ptr %4, align 4, !dbg !59
  ret i32 %5, !dbg !60
}

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #1 personality ptr @__gxx_personality_v0 !dbg !61 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca [2 x i32], align 4
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca %struct.V, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !62, !DIExpression(), !64)
  %16 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 4) #8, !dbg !65, !heapallocsite !16
  store i32 3, ptr %16, align 4, !dbg !65
  store ptr %16, ptr %2, align 8, !dbg !64
    #dbg_declare(ptr %3, !66, !DIExpression(), !67)
  %17 = call noalias noundef nonnull ptr @_Znam(i64 noundef 16) #8, !dbg !68, !heapallocsite !16
  store ptr %17, ptr %3, align 8, !dbg !67
    #dbg_declare(ptr %4, !69, !DIExpression(), !71)
  %18 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 16) #8, !dbg !72, !heapallocsite !31
  invoke void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(16) %18)
          to label %19 unwind label %43, !dbg !73

19:                                               ; preds = %0
  store ptr %18, ptr %4, align 8, !dbg !71
  %20 = load ptr, ptr %2, align 8, !dbg !74
  %21 = icmp eq ptr %20, null, !dbg !75
  br i1 %21, label %23, label %22, !dbg !75

22:                                               ; preds = %19
  call void @_ZdlPvm(ptr noundef %20, i64 noundef 4) #9, !dbg !75
  br label %23, !dbg !75

23:                                               ; preds = %22, %19
  %24 = load ptr, ptr %3, align 8, !dbg !76
  %25 = icmp eq ptr %24, null, !dbg !77
  br i1 %25, label %27, label %26, !dbg !77

26:                                               ; preds = %23
  call void @_ZdaPv(ptr noundef %24) #9, !dbg !77
  br label %27, !dbg !77

27:                                               ; preds = %26, %23
    #dbg_declare(ptr %7, !78, !DIExpression(), !82)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 @__const.main.v, i64 8, i1 false), !dbg !82
    #dbg_declare(ptr %8, !83, !DIExpression(), !86)
  store ptr %7, ptr %8, align 8, !dbg !87
    #dbg_declare(ptr %9, !88, !DIExpression(), !86)
  %28 = load ptr, ptr %8, align 8, !dbg !89, !nonnull !55, !align !90
  %29 = getelementptr inbounds [2 x i32], ptr %28, i64 0, i64 0, !dbg !89
  store ptr %29, ptr %9, align 8, !dbg !89
    #dbg_declare(ptr %10, !91, !DIExpression(), !86)
  %30 = load ptr, ptr %8, align 8, !dbg !89, !nonnull !55, !align !90
  %31 = getelementptr inbounds [2 x i32], ptr %30, i64 0, i64 0, !dbg !89
  %32 = getelementptr inbounds i32, ptr %31, i64 2, !dbg !89
  store ptr %32, ptr %10, align 8, !dbg !89
  br label %33, !dbg !89

33:                                               ; preds = %40, %27
  %34 = load ptr, ptr %9, align 8, !dbg !89
  %35 = load ptr, ptr %10, align 8, !dbg !89
  %36 = icmp ne ptr %34, %35, !dbg !89
  br i1 %36, label %37, label %47, !dbg !89

37:                                               ; preds = %33
    #dbg_declare(ptr %11, !92, !DIExpression(), !94)
  %38 = load ptr, ptr %9, align 8, !dbg !95
  %39 = load i32, ptr %38, align 4, !dbg !95
  store i32 %39, ptr %11, align 4, !dbg !94
  br label %40, !dbg !96

40:                                               ; preds = %37
  %41 = load ptr, ptr %9, align 8, !dbg !89
  %42 = getelementptr inbounds nuw i32, ptr %41, i32 1, !dbg !89
  store ptr %42, ptr %9, align 8, !dbg !89
  br label %33, !dbg !89, !llvm.loop !97

43:                                               ; preds = %0
  %44 = landingpad { ptr, i32 }
          cleanup, !dbg !99
  %45 = extractvalue { ptr, i32 } %44, 0, !dbg !99
  store ptr %45, ptr %5, align 8, !dbg !99
  %46 = extractvalue { ptr, i32 } %44, 1, !dbg !99
  store i32 %46, ptr %6, align 4, !dbg !99
  call void @_ZdlPvm(ptr noundef %18, i64 noundef 16) #9, !dbg !72
  br label %87, !dbg !72

47:                                               ; preds = %33
    #dbg_declare(ptr %12, !100, !DIExpression(), !102)
  store i32 2, ptr %12, align 4, !dbg !102
  %48 = load i32, ptr %12, align 4, !dbg !103
  %49 = icmp sgt i32 %48, 1, !dbg !104
  br i1 %49, label %50, label %51, !dbg !105

50:                                               ; preds = %47
  store i32 1, ptr %1, align 4, !dbg !106
  br label %85, !dbg !106

51:                                               ; preds = %47
  br label %52

52:                                               ; preds = %51
    #dbg_declare(ptr %13, !107, !DIExpression(), !109)
  store i32 0, ptr %13, align 4, !dbg !109
  br label %53, !dbg !110

53:                                               ; preds = %57, %52
  %54 = load i32, ptr %13, align 4, !dbg !111
  %55 = icmp slt i32 %54, 3, !dbg !113
  br i1 %55, label %56, label %60, !dbg !114

56:                                               ; preds = %53
  br label %57, !dbg !114

57:                                               ; preds = %56
  %58 = load i32, ptr %13, align 4, !dbg !115
  %59 = add nsw i32 %58, 1, !dbg !115
  store i32 %59, ptr %13, align 4, !dbg !115
  br label %53, !dbg !116, !llvm.loop !117

60:                                               ; preds = %53
  %61 = getelementptr inbounds [2 x i32], ptr %7, i64 0, i64 0, !dbg !120
  %62 = load i32, ptr %61, align 4, !dbg !120
  switch i32 %62, label %64 [
    i32 1, label %63
    i32 2, label %63
  ], !dbg !121

63:                                               ; preds = %60, %60
  br label %65, !dbg !122

64:                                               ; preds = %60
  br label %65, !dbg !124

65:                                               ; preds = %64, %63
  %66 = call ptr @__cxa_allocate_exception(i64 4) #10, !dbg !125
  store i32 1, ptr %66, align 16, !dbg !125
  invoke void @__cxa_throw(ptr %66, ptr @_ZTIi, ptr null) #11
          to label %92 unwind label %67, !dbg !125

67:                                               ; preds = %65
  %68 = landingpad { ptr, i32 }
          catch ptr @_ZTIi
          catch ptr null, !dbg !127
  %69 = extractvalue { ptr, i32 } %68, 0, !dbg !127
  store ptr %69, ptr %5, align 8, !dbg !127
  %70 = extractvalue { ptr, i32 } %68, 1, !dbg !127
  store i32 %70, ptr %6, align 4, !dbg !127
  br label %71, !dbg !127

71:                                               ; preds = %67
  %72 = load i32, ptr %6, align 4, !dbg !128
  %73 = call i32 @llvm.eh.typeid.for.p0(ptr @_ZTIi) #10, !dbg !128
  %74 = icmp eq i32 %72, %73, !dbg !128
  br i1 %74, label %75, label %82, !dbg !128

75:                                               ; preds = %71
    #dbg_declare(ptr %14, !129, !DIExpression(), !130)
  %76 = load ptr, ptr %5, align 8, !dbg !131
  %77 = call ptr @__cxa_begin_catch(ptr %76) #10, !dbg !131
  %78 = load i32, ptr %77, align 4, !dbg !131
  store i32 %78, ptr %14, align 4, !dbg !131
  call void @__cxa_end_catch() #10, !dbg !133
  br label %79, !dbg !133

79:                                               ; preds = %75, %82
    #dbg_declare(ptr %15, !135, !DIExpression(), !142)
  %80 = getelementptr inbounds nuw %struct.V, ptr %15, i32 0, i32 0, !dbg !143
  %81 = getelementptr inbounds [2 x i32], ptr %80, i64 0, i64 0, !dbg !144
  store i32 1, ptr %81, align 4, !dbg !145
  store i32 0, ptr %1, align 4, !dbg !146
  br label %85, !dbg !146

82:                                               ; preds = %71
  %83 = load ptr, ptr %5, align 8, !dbg !128
  %84 = call ptr @__cxa_begin_catch(ptr %83) #10, !dbg !128
  call void @__cxa_end_catch(), !dbg !131
  br label %79, !dbg !131

85:                                               ; preds = %79, %50
  %86 = load i32, ptr %1, align 4, !dbg !99
  ret i32 %86, !dbg !99

87:                                               ; preds = %43
  %88 = load ptr, ptr %5, align 8, !dbg !72
  %89 = load i32, ptr %6, align 4, !dbg !72
  %90 = insertvalue { ptr, i32 } poison, ptr %88, 0, !dbg !72
  %91 = insertvalue { ptr, i32 } %90, i32 %89, 1, !dbg !72
  resume { ptr, i32 } %91, !dbg !72

92:                                               ; preds = %65
  unreachable
}

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znwm(i64 noundef) #2

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znam(i64 noundef) #2

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #3 comdat align 2 !dbg !147 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !148, !DIExpression(), !149)
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1BC2Ei(ptr noundef nonnull align 8 dereferenceable(12) %3, i32 noundef 1), !dbg !150
  store ptr getelementptr inbounds inrange(-16, 24) ({ [5 x ptr] }, ptr @_ZTV1D, i32 0, i32 0, i32 2), ptr %3, align 8, !dbg !151
  %4 = getelementptr inbounds nuw %class.D, ptr %3, i32 0, i32 1, !dbg !152
  store i32 2, ptr %4, align 4, !dbg !152
  ret void, !dbg !153
}

declare i32 @__gxx_personality_v0(...)

; Function Attrs: nobuiltin nounwind
declare void @_ZdlPvm(ptr noundef, i64 noundef) #4

; Function Attrs: nobuiltin nounwind
declare void @_ZdaPv(ptr noundef) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

declare ptr @__cxa_allocate_exception(i64)

declare void @__cxa_throw(ptr, ptr, ptr)

; Function Attrs: nounwind memory(none)
declare i32 @llvm.eh.typeid.for.p0(ptr) #6

declare ptr @__cxa_begin_catch(ptr)

declare void @__cxa_end_catch()

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DD2Ev(ptr noundef nonnull align 8 dead_on_return(16) dereferenceable(16) %0) unnamed_addr #0 comdat align 2 !dbg !154 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !156, !DIExpression(), !157)
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1BD2Ev(ptr noundef nonnull align 8 dead_on_return(12) dereferenceable(12) %3) #10, !dbg !158
  ret void, !dbg !160
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DD0Ev(ptr noundef nonnull align 8 dereferenceable(16) %0) unnamed_addr #0 comdat align 2 !dbg !161 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !162, !DIExpression(), !163)
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1DD2Ev(ptr noundef nonnull align 8 dead_on_return(16) dereferenceable(16) %3) #10, !dbg !164
  call void @_ZdlPvm(ptr noundef %3, i64 noundef 16) #9, !dbg !164
  ret void, !dbg !164
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BC2Ei(ptr noundef nonnull align 8 dereferenceable(12) %0, i32 noundef %1) unnamed_addr #0 comdat align 2 !dbg !165 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !166, !DIExpression(), !168)
  store i32 %1, ptr %4, align 4
    #dbg_declare(ptr %4, !169, !DIExpression(), !170)
  %5 = load ptr, ptr %3, align 8
  store ptr getelementptr inbounds inrange(-16, 24) ({ [5 x ptr] }, ptr @_ZTV1B, i32 0, i32 0, i32 2), ptr %5, align 8, !dbg !171
  %6 = getelementptr inbounds nuw %struct.B, ptr %5, i32 0, i32 1, !dbg !172
  %7 = load i32, ptr %4, align 4, !dbg !173
  store i32 %7, ptr %6, align 8, !dbg !172
  ret void, !dbg !174
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BD2Ev(ptr noundef nonnull align 8 dead_on_return(12) dereferenceable(12) %0) unnamed_addr #0 comdat align 2 !dbg !175 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !176, !DIExpression(), !177)
  %3 = load ptr, ptr %2, align 8
  ret void, !dbg !178
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BD0Ev(ptr noundef nonnull align 8 dereferenceable(12) %0) unnamed_addr #0 comdat align 2 !dbg !179 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !180, !DIExpression(), !181)
  %3 = load ptr, ptr %2, align 8
  call void @llvm.trap() #12, !dbg !182
  unreachable, !dbg !182
}

declare void @__cxa_pure_virtual() unnamed_addr

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #7

attributes #0 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nobuiltin allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress noinline optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nobuiltin nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind memory(none) }
attributes #7 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #8 = { builtin allocsize(0) }
attributes #9 = { builtin nounwind }
attributes #10 = { nounwind }
attributes #11 = { noreturn }
attributes #12 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!46, !47, !48, !49, !50, !51, !52}
!llvm.ident = !{!53}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "__clang_vtable", linkageName: "_ZTV1D", scope: !2, file: !3, type: !7, isLocal: false, isDefinition: true, declaration: !30, align: 64)
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "test/cpp/samples/classes.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "afba01b0f804261eccc954aa302e4827")
!4 = !{!0, !5}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "__clang_vtable", linkageName: "_ZTV1B", scope: !2, file: !3, type: !7, isLocal: false, isDefinition: true, declaration: !8, align: 64)
!7 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!8 = !DIDerivedType(tag: DW_TAG_variable, name: "__clang_vtable", scope: !9, file: !3, baseType: !7, flags: DIFlagPrivate | DIFlagArtificial | DIFlagStaticMember)
!9 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "B", file: !3, line: 1, size: 128, flags: DIFlagTypePassByReference | DIFlagNonTrivial, elements: !10, vtableHolder: !9, identifier: "_ZTS1B")
!10 = !{!11, !17, !18, !22, !25}
!11 = !DIDerivedType(tag: DW_TAG_member, name: "_vptr$B", scope: !3, file: !3, baseType: !12, size: 64, flags: DIFlagArtificial)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "__vtbl_ptr_type", baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !9, file: !3, line: 1, baseType: !16, size: 32, offset: 64)
!18 = !DISubprogram(name: "B", linkageName: "_ZN1BC4Ei", scope: !9, file: !3, line: 1, type: !19, scopeLine: 1, flags: DIFlagPrototyped, spFlags: 0)
!19 = !DISubroutineType(types: !20)
!20 = !{null, !21, !16}
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!22 = !DISubprogram(name: "~B", linkageName: "_ZN1BD4Ev", scope: !9, file: !3, line: 1, type: !23, scopeLine: 1, containingType: !9, virtualIndex: 0, flags: DIFlagPrototyped, spFlags: DISPFlagVirtual)
!23 = !DISubroutineType(types: !24)
!24 = !{null, !21}
!25 = !DISubprogram(name: "f", linkageName: "_ZNK1B1fEv", scope: !9, file: !3, line: 1, type: !26, scopeLine: 1, containingType: !9, virtualIndex: 2, flags: DIFlagPrototyped, spFlags: DISPFlagPureVirtual)
!26 = !DISubroutineType(types: !27)
!27 = !{!16, !28}
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!30 = !DIDerivedType(tag: DW_TAG_variable, name: "__clang_vtable", scope: !31, file: !3, baseType: !7, flags: DIFlagArtificial | DIFlagStaticMember)
!31 = distinct !DICompositeType(tag: DW_TAG_class_type, name: "D", file: !3, line: 2, size: 128, flags: DIFlagTypePassByReference | DIFlagNonTrivial, elements: !32, vtableHolder: !9)
!32 = !{!33, !34, !35, !37, !41}
!33 = !DIDerivedType(tag: DW_TAG_inheritance, scope: !31, baseType: !9, flags: DIFlagPublic, extraData: i32 0)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !31, file: !3, line: 2, baseType: !16, size: 32, offset: 96)
!35 = !DIDerivedType(tag: DW_TAG_variable, name: "k", scope: !31, file: !3, line: 2, baseType: !36, flags: DIFlagStaticMember, extraData: i32 3)
!36 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!37 = !DISubprogram(name: "D", linkageName: "_ZN1DC4Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagPublic | DIFlagPrototyped, spFlags: 0)
!38 = !DISubroutineType(types: !39)
!39 = !{null, !40}
!40 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!41 = !DISubprogram(name: "f", linkageName: "_ZNK1D1fEv", scope: !31, file: !3, line: 2, type: !42, scopeLine: 2, containingType: !31, virtualIndex: 2, flags: DIFlagPublic | DIFlagPrototyped, spFlags: DISPFlagVirtual)
!42 = !DISubroutineType(types: !43)
!43 = !{!16, !44}
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !31)
!46 = !{i32 7, !"Dwarf Version", i32 5}
!47 = !{i32 2, !"Debug Info Version", i32 3}
!48 = !{i32 4, !"probe-stack", !"inline-asm"}
!49 = !{i32 8, !"PIC Level", i32 2}
!50 = !{i32 7, !"PIE Level", i32 2}
!51 = !{i32 7, !"uwtable", i32 2}
!52 = !{i32 7, !"frame-pointer", i32 2}
!53 = !{!"Alpine clang version 23.1.5"}
!54 = distinct !DISubprogram(name: "f", linkageName: "_ZNK1D1fEv", scope: !31, file: !3, line: 3, type: !42, scopeLine: 3, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !41, retainedNodes: !55)
!55 = !{}
!56 = !DILocalVariable(name: "this", arg: 1, scope: !54, type: !57, flags: DIFlagArtificial | DIFlagObjectPointer)
!57 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!58 = !DILocation(line: 0, scope: !54)
!59 = !DILocation(line: 3, column: 27, scope: !54)
!60 = !DILocation(line: 3, column: 20, scope: !54)
!61 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 8, type: !14, scopeLine: 8, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!62 = !DILocalVariable(name: "p", scope: !61, file: !3, line: 9, type: !63)
!63 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64)
!64 = !DILocation(line: 9, column: 8, scope: !61)
!65 = !DILocation(line: 9, column: 12, scope: !61)
!66 = !DILocalVariable(name: "q", scope: !61, file: !3, line: 9, type: !63)
!67 = !DILocation(line: 9, column: 29, scope: !61)
!68 = !DILocation(line: 9, column: 33, scope: !61)
!69 = !DILocalVariable(name: "d", scope: !61, file: !3, line: 9, type: !70)
!70 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64)
!71 = !DILocation(line: 9, column: 48, scope: !61)
!72 = !DILocation(line: 9, column: 52, scope: !61)
!73 = !DILocation(line: 9, column: 56, scope: !61)
!74 = !DILocation(line: 9, column: 66, scope: !61)
!75 = !DILocation(line: 9, column: 59, scope: !61)
!76 = !DILocation(line: 9, column: 78, scope: !61)
!77 = !DILocation(line: 9, column: 69, scope: !61)
!78 = !DILocalVariable(name: "v", scope: !61, file: !3, line: 10, type: !79)
!79 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !80)
!80 = !{!81}
!81 = !DISubrange(count: 2)
!82 = !DILocation(line: 10, column: 7, scope: !61)
!83 = !DILocalVariable(name: "__range1", scope: !84, type: !85, flags: DIFlagArtificial)
!84 = distinct !DILexicalBlock(scope: !61, file: !3, line: 11, column: 3)
!85 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !79, size: 64)
!86 = !DILocation(line: 0, scope: !84)
!87 = !DILocation(line: 11, column: 16, scope: !84)
!88 = !DILocalVariable(name: "__begin1", scope: !84, type: !63, flags: DIFlagArtificial)
!89 = !DILocation(line: 11, column: 14, scope: !84)
!90 = !{i64 4}
!91 = !DILocalVariable(name: "__end1", scope: !84, type: !63, flags: DIFlagArtificial)
!92 = !DILocalVariable(name: "x", scope: !93, file: !3, line: 11, type: !16)
!93 = distinct !DILexicalBlock(scope: !84, file: !3, line: 11, column: 3)
!94 = !DILocation(line: 11, column: 12, scope: !93)
!95 = !DILocation(line: 11, column: 14, scope: !93)
!96 = !DILocation(line: 11, column: 3, scope: !84)
!97 = distinct !{!97, !96, !98}
!98 = !DILocation(line: 11, column: 30, scope: !84)
!99 = !DILocation(line: 18, column: 1, scope: !61)
!100 = !DILocalVariable(name: "y", scope: !101, file: !3, line: 12, type: !16)
!101 = distinct !DILexicalBlock(scope: !61, file: !3, line: 12, column: 18)
!102 = !DILocation(line: 12, column: 11, scope: !101)
!103 = !DILocation(line: 12, column: 18, scope: !101)
!104 = !DILocation(line: 12, column: 20, scope: !101)
!105 = !DILocation(line: 12, column: 7, scope: !101)
!106 = !DILocation(line: 12, column: 25, scope: !101)
!107 = !DILocalVariable(name: "i", scope: !108, file: !3, line: 13, type: !16)
!108 = distinct !DILexicalBlock(scope: !61, file: !3, line: 13, column: 3)
!109 = !DILocation(line: 13, column: 12, scope: !108)
!110 = !DILocation(line: 13, column: 8, scope: !108)
!111 = !DILocation(line: 13, column: 19, scope: !112)
!112 = distinct !DILexicalBlock(scope: !108, file: !3, line: 13, column: 3)
!113 = !DILocation(line: 13, column: 21, scope: !112)
!114 = !DILocation(line: 13, column: 3, scope: !108)
!115 = !DILocation(line: 13, column: 26, scope: !112)
!116 = !DILocation(line: 13, column: 3, scope: !112)
!117 = distinct !{!117, !114, !118, !119}
!118 = !DILocation(line: 13, column: 31, scope: !108)
!119 = !{!"llvm.loop.mustprogress"}
!120 = !DILocation(line: 14, column: 11, scope: !61)
!121 = !DILocation(line: 14, column: 3, scope: !61)
!122 = !DILocation(line: 14, column: 35, scope: !123)
!123 = distinct !DILexicalBlock(scope: !61, file: !3, line: 14, column: 17)
!124 = !DILocation(line: 14, column: 53, scope: !123)
!125 = !DILocation(line: 15, column: 9, scope: !126)
!126 = distinct !DILexicalBlock(scope: !61, file: !3, line: 15, column: 7)
!127 = !DILocation(line: 18, column: 1, scope: !126)
!128 = !DILocation(line: 15, column: 18, scope: !126)
!129 = !DILocalVariable(name: "e", scope: !61, file: !3, line: 15, type: !16)
!130 = !DILocation(line: 15, column: 31, scope: !61)
!131 = !DILocation(line: 15, column: 52, scope: !132)
!132 = distinct !DILexicalBlock(scope: !61, file: !3, line: 15, column: 50)
!133 = !DILocation(line: 15, column: 36, scope: !134)
!134 = distinct !DILexicalBlock(scope: !61, file: !3, line: 15, column: 34)
!135 = !DILocalVariable(name: "w", scope: !61, file: !3, line: 16, type: !136)
!136 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "V<int, 2>", file: !3, line: 6, size: 64, flags: DIFlagTypePassByValue, elements: !137, templateParams: !139, identifier: "_ZTS1VIiLi2EE")
!137 = !{!138}
!138 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !136, file: !3, line: 6, baseType: !79, size: 64)
!139 = !{!140, !141}
!140 = !DITemplateTypeParameter(name: "X", type: !16)
!141 = !DITemplateValueParameter(name: "N", type: !16, defaulted: true, value: i32 2)
!142 = !DILocation(line: 16, column: 10, scope: !61)
!143 = !DILocation(line: 16, column: 15, scope: !61)
!144 = !DILocation(line: 16, column: 13, scope: !61)
!145 = !DILocation(line: 16, column: 20, scope: !61)
!146 = !DILocation(line: 17, column: 3, scope: !61)
!147 = distinct !DISubprogram(name: "D", linkageName: "_ZN1DC2Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !37, retainedNodes: !55)
!148 = !DILocalVariable(name: "this", arg: 1, scope: !147, type: !70, flags: DIFlagArtificial | DIFlagObjectPointer)
!149 = !DILocation(line: 0, scope: !147)
!150 = !DILocation(line: 2, column: 36, scope: !147)
!151 = !DILocation(line: 2, column: 47, scope: !147)
!152 = !DILocation(line: 2, column: 42, scope: !147)
!153 = !DILocation(line: 2, column: 48, scope: !147)
!154 = distinct !DISubprogram(name: "~D", linkageName: "_ZN1DD2Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !155, retainedNodes: !55)
!155 = !DISubprogram(name: "~D", linkageName: "_ZN1DD4Ev", scope: !31, type: !38, containingType: !31, virtualIndex: 0, flags: DIFlagPublic | DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagVirtual)
!156 = !DILocalVariable(name: "this", arg: 1, scope: !154, type: !70, flags: DIFlagArtificial | DIFlagObjectPointer)
!157 = !DILocation(line: 0, scope: !154)
!158 = !DILocation(line: 2, column: 7, scope: !159)
!159 = distinct !DILexicalBlock(scope: !154, file: !3, line: 2, column: 7)
!160 = !DILocation(line: 2, column: 7, scope: !154)
!161 = distinct !DISubprogram(name: "~D", linkageName: "_ZN1DD0Ev", scope: !31, file: !3, line: 2, type: !38, scopeLine: 2, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !155, retainedNodes: !55)
!162 = !DILocalVariable(name: "this", arg: 1, scope: !161, type: !70, flags: DIFlagArtificial | DIFlagObjectPointer)
!163 = !DILocation(line: 0, scope: !161)
!164 = !DILocation(line: 2, column: 7, scope: !161)
!165 = distinct !DISubprogram(name: "B", linkageName: "_ZN1BC2Ei", scope: !9, file: !3, line: 1, type: !19, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !18, retainedNodes: !55)
!166 = !DILocalVariable(name: "this", arg: 1, scope: !165, type: !167, flags: DIFlagArtificial | DIFlagObjectPointer)
!167 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !9, size: 64)
!168 = !DILocation(line: 0, scope: !165)
!169 = !DILocalVariable(name: "x", arg: 2, scope: !165, file: !3, line: 1, type: !16)
!170 = !DILocation(line: 1, column: 25, scope: !165)
!171 = !DILocation(line: 1, column: 35, scope: !165)
!172 = !DILocation(line: 1, column: 30, scope: !165)
!173 = !DILocation(line: 1, column: 32, scope: !165)
!174 = !DILocation(line: 1, column: 36, scope: !165)
!175 = distinct !DISubprogram(name: "~B", linkageName: "_ZN1BD2Ev", scope: !9, file: !3, line: 1, type: !23, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !22, retainedNodes: !55)
!176 = !DILocalVariable(name: "this", arg: 1, scope: !175, type: !167, flags: DIFlagArtificial | DIFlagObjectPointer)
!177 = !DILocation(line: 0, scope: !175)
!178 = !DILocation(line: 1, column: 52, scope: !175)
!179 = distinct !DISubprogram(name: "~B", linkageName: "_ZN1BD0Ev", scope: !9, file: !3, line: 1, type: !23, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !22, retainedNodes: !55)
!180 = !DILocalVariable(name: "this", arg: 1, scope: !179, type: !167, flags: DIFlagArtificial | DIFlagObjectPointer)
!181 = !DILocation(line: 0, scope: !179)
!182 = !DILocation(line: 1, column: 51, scope: !179)
