; ModuleID = '20000224-1.c'
source_filename = "20000224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@loop_1 = dso_local global i32 100, align 4, !dbg !0
@loop_2 = dso_local global i32 7, align 4, !dbg !5
@flag = dso_local global i32 0, align 4, !dbg !8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test() #0 !dbg !18 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
    #dbg_declare(ptr %1, !22, !DIExpression(), !23)
    #dbg_declare(ptr %2, !24, !DIExpression(), !25)
  store i32 0, ptr %2, align 4, !dbg !25
  br label %3, !dbg !26

3:                                                ; preds = %23, %0
  %4 = load i32, ptr @loop_1, align 4, !dbg !27
  %5 = load i32, ptr %2, align 4, !dbg !28
  %6 = icmp sgt i32 %4, %5, !dbg !29
  br i1 %6, label %7, label %26, !dbg !26

7:                                                ; preds = %3
  %8 = load i32, ptr @flag, align 4, !dbg !30
  %9 = and i32 %8, 1, !dbg !33
  %10 = icmp ne i32 %9, 0, !dbg !33
  br i1 %10, label %11, label %23, !dbg !33

11:                                               ; preds = %7
  store i32 0, ptr %1, align 4, !dbg !34
  br label %12, !dbg !37

12:                                               ; preds = %19, %11
  %13 = load i32, ptr %1, align 4, !dbg !38
  %14 = load i32, ptr @loop_2, align 4, !dbg !40
  %15 = icmp slt i32 %13, %14, !dbg !41
  br i1 %15, label %16, label %22, !dbg !42

16:                                               ; preds = %12
  %17 = load i32, ptr %2, align 4, !dbg !43
  %18 = add nsw i32 %17, 1, !dbg !43
  store i32 %18, ptr %2, align 4, !dbg !43
  br label %19, !dbg !45

19:                                               ; preds = %16
  %20 = load i32, ptr %1, align 4, !dbg !46
  %21 = add nsw i32 %20, 1, !dbg !46
  store i32 %21, ptr %1, align 4, !dbg !46
  br label %12, !dbg !47, !llvm.loop !48

22:                                               ; preds = %12
  br label %23, !dbg !51

23:                                               ; preds = %22, %7
  %24 = load i32, ptr @flag, align 4, !dbg !52
  %25 = add nsw i32 %24, 1, !dbg !52
  store i32 %25, ptr @flag, align 4, !dbg !52
  br label %3, !dbg !26, !llvm.loop !53

26:                                               ; preds = %3
  ret i32 1, !dbg !55
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !56 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @test(), !dbg !57
  %3 = icmp ne i32 %2, 1, !dbg !59
  br i1 %3, label %4, label %5, !dbg !59

4:                                                ; preds = %0
  call void @abort() #3, !dbg !60
  unreachable, !dbg !60

5:                                                ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !61
  unreachable, !dbg !61
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!10, !11, !12, !13, !14, !15, !16}
!llvm.ident = !{!17}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "loop_1", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20000224-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "2e314f0d8f183be101e54623318ad2a9")
!4 = !{!0, !5, !8}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "loop_2", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!7 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "flag", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!10 = !{i32 7, !"Dwarf Version", i32 5}
!11 = !{i32 2, !"Debug Info Version", i32 3}
!12 = !{i32 4, !"probe-stack", !"inline-asm"}
!13 = !{i32 8, !"PIC Level", i32 2}
!14 = !{i32 7, !"PIE Level", i32 2}
!15 = !{i32 7, !"uwtable", i32 2}
!16 = !{i32 7, !"frame-pointer", i32 2}
!17 = !{!"Alpine clang version 23.1.5"}
!18 = distinct !DISubprogram(name: "test", scope: !3, file: !3, line: 8, type: !19, scopeLine: 9, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !21)
!19 = !DISubroutineType(types: !20)
!20 = !{!7}
!21 = !{}
!22 = !DILocalVariable(name: "i", scope: !18, file: !3, line: 10, type: !7)
!23 = !DILocation(line: 10, column: 9, scope: !18)
!24 = !DILocalVariable(name: "counter", scope: !18, file: !3, line: 11, type: !7)
!25 = !DILocation(line: 11, column: 9, scope: !18)
!26 = !DILocation(line: 13, column: 5, scope: !18)
!27 = !DILocation(line: 13, column: 12, scope: !18)
!28 = !DILocation(line: 13, column: 21, scope: !18)
!29 = !DILocation(line: 13, column: 19, scope: !18)
!30 = !DILocation(line: 14, column: 13, scope: !31)
!31 = distinct !DILexicalBlock(scope: !32, file: !3, line: 14, column: 13)
!32 = distinct !DILexicalBlock(scope: !18, file: !3, line: 13, column: 30)
!33 = !DILocation(line: 14, column: 18, scope: !31)
!34 = !DILocation(line: 15, column: 20, scope: !35)
!35 = distinct !DILexicalBlock(scope: !36, file: !3, line: 15, column: 13)
!36 = distinct !DILexicalBlock(scope: !31, file: !3, line: 14, column: 23)
!37 = !DILocation(line: 15, column: 18, scope: !35)
!38 = !DILocation(line: 15, column: 25, scope: !39)
!39 = distinct !DILexicalBlock(scope: !35, file: !3, line: 15, column: 13)
!40 = !DILocation(line: 15, column: 29, scope: !39)
!41 = !DILocation(line: 15, column: 27, scope: !39)
!42 = !DILocation(line: 15, column: 13, scope: !35)
!43 = !DILocation(line: 16, column: 24, scope: !44)
!44 = distinct !DILexicalBlock(scope: !39, file: !3, line: 15, column: 42)
!45 = !DILocation(line: 17, column: 13, scope: !44)
!46 = !DILocation(line: 15, column: 38, scope: !39)
!47 = !DILocation(line: 15, column: 13, scope: !39)
!48 = distinct !{!48, !42, !49, !50}
!49 = !DILocation(line: 17, column: 13, scope: !35)
!50 = !{!"llvm.loop.mustprogress"}
!51 = !DILocation(line: 18, column: 9, scope: !36)
!52 = !DILocation(line: 19, column: 13, scope: !32)
!53 = distinct !{!53, !26, !54, !50}
!54 = !DILocation(line: 20, column: 5, scope: !18)
!55 = !DILocation(line: 21, column: 5, scope: !18)
!56 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 24, type: !19, scopeLine: 25, spFlags: DISPFlagDefinition, unit: !2)
!57 = !DILocation(line: 26, column: 9, scope: !58)
!58 = distinct !DILexicalBlock(scope: !56, file: !3, line: 26, column: 9)
!59 = !DILocation(line: 26, column: 17, scope: !58)
!60 = !DILocation(line: 27, column: 7, scope: !58)
!61 = !DILocation(line: 29, column: 5, scope: !56)
