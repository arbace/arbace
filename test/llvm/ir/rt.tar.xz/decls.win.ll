; ModuleID = 'test/cpp/samples/decls.cpp'
source_filename = "test/cpp/samples/decls.cpp"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"

%struct.S2 = type { i32, i32 }

@"?s@A@@2HA" = dso_local local_unnamed_addr global i32 0, align 4
@"?z@c@b@a@@3HA" = dso_local local_unnamed_addr global i32 0, align 4
@"?fp@@3P6AXH@ZEA" = dso_local local_unnamed_addr global ptr null, align 8
@"?p@@3PEADEA" = dso_local local_unnamed_addr global ptr null, align 8
@"?s2@@3US2@@A" = dso_local local_unnamed_addr global %struct.S2 zeroinitializer, align 8
@"?ps2@@3PEAUS2@@EA" = dso_local local_unnamed_addr global ptr null, align 8
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_decls.cpp, ptr null }]

; Function Attrs: nobuiltin allocsize(0)
declare dso_local noundef nonnull ptr @"??_U@YAPEAX_K@Z"(i64 noundef) local_unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local noundef range(i32 1, -2147483648) i32 @"?g@@YAHH@Z"(i32 noundef %0) local_unnamed_addr #1 {
  %2 = tail call i32 @llvm.smax.i32(i32 %0, i32 1)
  ret i32 %2
}

; Function Attrs: uwtable
define internal void @_GLOBAL__sub_I_decls.cpp() #2 {
  %1 = tail call noalias noundef nonnull dereferenceable(3) ptr @"??_U@YAPEAX_K@Z"(i64 noundef 3) #4
  store i8 1, ptr %1, align 1
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 1
  store i8 2, ptr %2, align 1
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 2
  store i8 3, ptr %3, align 1
  store ptr %1, ptr @"?p@@3PEADEA", align 8
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #3

attributes #0 = { nobuiltin allocsize(0) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { builtin allocsize(0) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "test/cpp/samples\\decls.cpp", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
