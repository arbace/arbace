; ModuleID = 'test/cpp/samples/auto.cpp'
source_filename = "test/cpp/samples/auto.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%class.anon = type { ptr }

$_ZN1n2idIiEET_S1_ = comdat any

@_ZN1n1gE = dso_local global i32 0, align 4, !dbg !0
@__const.main.a = private unnamed_addr constant [3 x i32] [i32 1, i32 2, i32 3], align 4

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define dso_local noundef i32 @_Z1fv() #0 !dbg !16 {
  ret i32 1, !dbg !18
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define dso_local noundef i32 @_Z1hv() #0 !dbg !19 {
  ret i32 2, !dbg !20
}

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #1 !dbg !21 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca %class.anon, align 8
  %5 = alloca [3 x i32], align 4
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !27, !DIExpression(), !28)
  store i32 1, ptr %2, align 4, !dbg !28
    #dbg_declare(ptr %3, !29, !DIExpression(), !32)
  store ptr %2, ptr %3, align 8, !dbg !32
    #dbg_declare(ptr %4, !33, !DIExpression(), !34)
  %7 = getelementptr inbounds nuw %class.anon, ptr %4, i32 0, i32 0, !dbg !35
  store ptr %2, ptr %7, align 8, !dbg !35
    #dbg_declare(ptr %5, !36, !DIExpression(), !40)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 @__const.main.a, i64 12, i1 false), !dbg !40
    #dbg_declare(ptr %6, !41, !DIExpression(), !43)
  store i32 3, ptr %6, align 4, !dbg !43
  %8 = load i32, ptr %2, align 4, !dbg !44
  %9 = call noundef i32 @_ZN1n2idIiEET_S1_(i32 noundef %8), !dbg !45
  %10 = load i32, ptr @_ZN1n1gE, align 4, !dbg !46
  %11 = add nsw i32 %9, %10, !dbg !47
  %12 = call noundef i32 @"_ZZ4mainENK3$_0clEi"(ptr noundef nonnull align 8 dereferenceable(8) %4, i32 noundef 2), !dbg !48
  %13 = add nsw i32 %11, %12, !dbg !49
  %14 = getelementptr inbounds [3 x i32], ptr %5, i64 0, i64 1, !dbg !50
  %15 = load i32, ptr %14, align 4, !dbg !50
  %16 = add nsw i32 %13, %15, !dbg !51
  %17 = load i32, ptr %6, align 4, !dbg !52
  %18 = add nsw i32 %16, %17, !dbg !53
  %19 = add nsw i32 %18, 2, !dbg !54
  ret i32 %19, !dbg !55
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef i32 @_ZN1n2idIiEET_S1_(i32 noundef %0) #0 comdat !dbg !56 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
    #dbg_declare(ptr %2, !62, !DIExpression(), !63)
  %3 = load i32, ptr %2, align 4, !dbg !64
  ret i32 %3, !dbg !65
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define internal noundef i32 @"_ZZ4mainENK3$_0clEi"(ptr noundef nonnull align 8 dereferenceable(8) %0, i32 noundef %1) #0 align 2 !dbg !66 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !72, !DIExpression(), !74)
  store i32 %1, ptr %4, align 4
    #dbg_declare(ptr %4, !75, !DIExpression(), !76)
  %5 = load ptr, ptr %3, align 8
  %6 = load i32, ptr %4, align 4, !dbg !77
  %7 = getelementptr inbounds nuw %class.anon, ptr %5, i32 0, i32 0, !dbg !78
  %8 = load ptr, ptr %7, align 8, !dbg !78, !nonnull !59, !align !79
  %9 = load i32, ptr %8, align 4, !dbg !78
  %10 = add nsw i32 %6, %9, !dbg !80
  ret i32 %10, !dbg !81
}

attributes #0 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.dbg.cu = !{!5}
!llvm.module.flags = !{!8, !9, !10, !11, !12, !13, !14}
!llvm.ident = !{!15}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "g", linkageName: "_ZN1n1gE", scope: !2, file: !3, line: 1, type: !4, isLocal: false, isDefinition: true)
!2 = !DINamespace(name: "n", scope: null)
!3 = !DIFile(filename: "test/cpp/samples/auto.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "31157ccf4de43d8c98d7d7d3fa284a78")
!4 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!5 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !6, globals: !7, splitDebugInlining: false, nameTableKind: None)
!6 = !{!4}
!7 = !{!0}
!8 = !{i32 7, !"Dwarf Version", i32 5}
!9 = !{i32 2, !"Debug Info Version", i32 3}
!10 = !{i32 4, !"probe-stack", !"inline-asm"}
!11 = !{i32 8, !"PIC Level", i32 2}
!12 = !{i32 7, !"PIE Level", i32 2}
!13 = !{i32 7, !"uwtable", i32 2}
!14 = !{i32 7, !"frame-pointer", i32 2}
!15 = !{!"Alpine clang version 23.1.5"}
!16 = distinct !DISubprogram(name: "f", linkageName: "_Z1fv", scope: !3, file: !3, line: 2, type: !17, scopeLine: 2, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !5)
!17 = !DISubroutineType(types: !6)
!18 = !DILocation(line: 2, column: 12, scope: !16)
!19 = distinct !DISubprogram(name: "h", linkageName: "_Z1hv", scope: !3, file: !3, line: 3, type: !17, scopeLine: 3, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !5)
!20 = !DILocation(line: 3, column: 19, scope: !19)
!21 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 4, type: !17, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !5, retainedNodes: !22)
!22 = !{!23}
!23 = distinct !DICompositeType(tag: DW_TAG_class_type, scope: !21, file: !3, line: 5, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !24)
!24 = !{!25}
!25 = !DIDerivedType(tag: DW_TAG_member, name: "x", scope: !23, file: !3, line: 5, baseType: !26, size: 64)
!26 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !4, size: 64)
!27 = !DILocalVariable(name: "x", scope: !21, file: !3, line: 5, type: !4)
!28 = !DILocation(line: 5, column: 8, scope: !21)
!29 = !DILocalVariable(name: "y", scope: !21, file: !3, line: 5, type: !30)
!30 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !31, size: 64)
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !4)
!32 = !DILocation(line: 5, column: 27, scope: !21)
!33 = !DILocalVariable(name: "l", scope: !21, file: !3, line: 5, type: !23)
!34 = !DILocation(line: 5, column: 39, scope: !21)
!35 = !DILocation(line: 5, column: 43, scope: !21)
!36 = !DILocalVariable(name: "a", scope: !21, file: !3, line: 6, type: !37)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !4, size: 96, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 3)
!40 = !DILocation(line: 6, column: 7, scope: !21)
!41 = !DILocalVariable(name: "u", scope: !21, file: !3, line: 7, type: !42)
!42 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!43 = !DILocation(line: 7, column: 12, scope: !21)
!44 = !DILocation(line: 8, column: 21, scope: !21)
!45 = !DILocation(line: 8, column: 10, scope: !21)
!46 = !DILocation(line: 8, column: 26, scope: !21)
!47 = !DILocation(line: 8, column: 24, scope: !21)
!48 = !DILocation(line: 8, column: 35, scope: !21)
!49 = !DILocation(line: 8, column: 33, scope: !21)
!50 = !DILocation(line: 8, column: 42, scope: !21)
!51 = !DILocation(line: 8, column: 40, scope: !21)
!52 = !DILocation(line: 8, column: 54, scope: !21)
!53 = !DILocation(line: 8, column: 47, scope: !21)
!54 = !DILocation(line: 8, column: 56, scope: !21)
!55 = !DILocation(line: 8, column: 3, scope: !21)
!56 = distinct !DISubprogram(name: "id<int>", linkageName: "_ZN1n2idIiEET_S1_", scope: !2, file: !3, line: 1, type: !57, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !5, templateParams: !60, retainedNodes: !59)
!57 = !DISubroutineType(types: !58)
!58 = !{!4, !4}
!59 = !{}
!60 = !{!61}
!61 = !DITemplateTypeParameter(name: "T", type: !4)
!62 = !DILocalVariable(name: "x", arg: 1, scope: !56, file: !3, line: 1, type: !4)
!63 = !DILocation(line: 1, column: 47, scope: !56)
!64 = !DILocation(line: 1, column: 59, scope: !56)
!65 = !DILocation(line: 1, column: 52, scope: !56)
!66 = distinct !DISubprogram(name: "operator()", linkageName: "_ZZ4mainENK3$_0clEi", scope: !23, file: !3, line: 5, type: !67, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !5, declaration: !71, retainedNodes: !59)
!67 = !DISubroutineType(types: !68)
!68 = !{!4, !69, !4}
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !70, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!70 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !23)
!71 = !DISubprogram(name: "operator()", scope: !23, file: !3, line: 5, type: !67, scopeLine: 5, flags: DIFlagPublic | DIFlagPrototyped, spFlags: DISPFlagLocalToUnit)
!72 = !DILocalVariable(name: "this", arg: 1, scope: !66, type: !73, flags: DIFlagArtificial | DIFlagObjectPointer)
!73 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !70, size: 64)
!74 = !DILocation(line: 0, scope: !66)
!75 = !DILocalVariable(name: "a", arg: 2, scope: !66, file: !3, line: 5, type: !4)
!76 = !DILocation(line: 5, column: 51, scope: !66)
!77 = !DILocation(line: 5, column: 63, scope: !66)
!78 = !DILocation(line: 5, column: 67, scope: !66)
!79 = !{i64 4}
!80 = !DILocation(line: 5, column: 65, scope: !66)
!81 = !DILocation(line: 5, column: 56, scope: !66)
