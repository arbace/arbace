; ModuleID = 'test/cpp/samples/bitfields.cpp'
source_filename = "test/cpp/samples/bitfields.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@s24 = dso_local local_unnamed_addr global { i8, i8, i8, i8 } { i8 1, i8 0, i8 0, i8 2 }, align 4, !guid !0
@s40 = dso_local local_unnamed_addr global { i8, i8, i8, i8, i8, i8, i8, i8 } { i8 3, i8 0, i8 0, i8 0, i8 0, i8 7, i8 9, i8 undef }, align 8, !guid !1
@s48 = dso_local local_unnamed_addr global { i8, i8, i8, i8, i8, i8, i16 } { i8 -5, i8 -1, i8 -1, i8 -1, i8 -1, i8 -1, i16 -16657 }, align 8, !guid !2
@s56 = dso_local local_unnamed_addr global { i8, i8, i8, i8, i8, i8, i8, i8 } { i8 119, i8 102, i8 85, i8 68, i8 51, i8 34, i8 17, i8 -120 }, align 8, !guid !3
@p17 = dso_local local_unnamed_addr global { i8, i8, i8, i8 } { i8 -1, i8 -1, i8 -85, i8 -86 }, align 4, !guid !4
@.str = private unnamed_addr constant [7 x i8] c"%u %u\0A\00", align 1, !guid !5
@.str.1 = private unnamed_addr constant [11 x i8] c"%lu %u %u\0A\00", align 1, !guid !6
@.str.2 = private unnamed_addr constant [8 x i8] c"%ld %x\0A\00", align 1, !guid !7
@.str.3 = private unnamed_addr constant [8 x i8] c"%lx %x\0A\00", align 1, !guid !8
@.str.4 = private unnamed_addr constant [7 x i8] c"%x %x\0A\00", align 1, !guid !9

; Function Attrs: mustprogress nofree norecurse nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 !guid !22 {
  store i24 3, ptr @s24, align 4
  %1 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s24, i64 3), align 1, !tbaa !23
  %2 = zext i8 %1 to i32
  %3 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i32 noundef 3, i32 noundef %2)
  store i40 1, ptr @s40, align 8
  %4 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s40, i64 5), align 1, !tbaa !25
  %5 = zext i8 %4 to i32
  %6 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s40, i64 6), align 2, !tbaa !28
  %7 = zext i8 %6 to i32
  %8 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.1, i64 noundef 1, i32 noundef %5, i32 noundef %7)
  %9 = load i48, ptr @s48, align 8
  %10 = zext i48 %9 to i64
  %11 = add nuw nsw i64 %10, 281474976710655
  %12 = trunc i64 %11 to i48
  store i48 %12, ptr @s48, align 8
  %13 = shl i64 %11, 16
  %14 = ashr exact i64 %13, 16
  %15 = load i16, ptr getelementptr inbounds nuw (i8, ptr @s48, i64 6), align 2, !tbaa !29
  %16 = zext i16 %15 to i32
  %17 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.2, i64 noundef %14, i32 noundef %16)
  %18 = load i56, ptr @s56, align 8
  %19 = xor i56 %18, -1
  store i56 %19, ptr @s56, align 8
  %20 = zext i56 %19 to i64
  %21 = load i8, ptr getelementptr inbounds nuw (i8, ptr @s56, i64 7), align 1, !tbaa !32
  %22 = zext i8 %21 to i32
  %23 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.3, i64 noundef %20, i32 noundef %22)
  %24 = load i32, ptr @p17, align 4
  %25 = add i32 %24, 1
  %26 = and i32 %25, 131071
  %27 = shl i32 %24, 1
  %28 = and i32 %27, -262144
  %29 = or disjoint i32 %26, %28
  store i32 %29, ptr @p17, align 4
  %30 = lshr exact i32 %28, 17
  %31 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.4, i32 noundef %26, i32 noundef %30)
  ret i32 0
}

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr noundef readonly captures(none), ...) local_unnamed_addr #1

attributes #0 = { mustprogress nofree norecurse nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!10, !11, !12, !13, !14, !15}
!llvm.ident = !{!16}
!llvm.errno.tbaa = !{!17}

!0 = !{i64 -6586799915858859000}
!1 = !{i64 5377604683177109612}
!2 = !{i64 6942281729397202227}
!3 = !{i64 -2555339609845208205}
!4 = !{i64 7628613166556784105}
!5 = !{i64 3604526700853815567}
!6 = !{i64 6432553245440001676}
!7 = !{i64 -8911528519332270806}
!8 = !{i64 4838278686201176805}
!9 = !{i64 1639023161944011637}
!10 = !{i32 4, !"probe-stack", !"inline-asm"}
!11 = !{i32 8, !"PIC Level", i32 2}
!12 = !{i32 7, !"PIE Level", i32 2}
!13 = !{i32 7, !"uwtable", i32 2}
!14 = !{i32 1, !"ThinLTO", i32 0}
!15 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!16 = !{!"Alpine clang version 23.1.5"}
!17 = !{!18, !19, i64 0}
!18 = !{!"__libc_errno", !19, i64 0}
!19 = !{!"int", !20, i64 0}
!20 = !{!"omnipotent char", !21, i64 0}
!21 = !{!"Simple C++ TBAA"}
!22 = !{i64 -2624081020897602054}
!23 = !{!24, !20, i64 3}
!24 = !{!"_ZTS3S24", !19, i64 0, !20, i64 3}
!25 = !{!26, !20, i64 5}
!26 = !{!"_ZTS3S40", !27, i64 0, !20, i64 5, !20, i64 6}
!27 = !{!"long", !20, i64 0}
!28 = !{!26, !20, i64 6}
!29 = !{!30, !31, i64 6}
!30 = !{!"_ZTS3S48", !27, i64 0, !31, i64 6}
!31 = !{!"short", !20, i64 0}
!32 = !{!33, !20, i64 7}
!33 = !{!"_ZTS3S56", !27, i64 0, !20, i64 7}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: ".str.4", summaries: (variable: (module: ^0, flags: (linkage: private, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 1639023161944011637
^2 = gv: (name: ".str", summaries: (variable: (module: ^0, flags: (linkage: private, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 3604526700853815567
^3 = gv: (name: ".str.3", summaries: (variable: (module: ^0, flags: (linkage: private, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 4838278686201176805
^4 = gv: (name: "s40", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 5377604683177109612
^5 = gv: (name: ".str.1", summaries: (variable: (module: ^0, flags: (linkage: private, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 6432553245440001676
^6 = gv: (name: "s48", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 6942281729397202227
^7 = gv: (name: "printf") ; guid = 7383291119112528047
^8 = gv: (name: "p17", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 7628613166556784105
^9 = gv: (name: ".str.2", summaries: (variable: (module: ^0, flags: (linkage: private, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 0, constant: 1)))) ; guid = 9535215554377280810
^10 = gv: (name: "s24", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 11859944157850692616
^11 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 37, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), calls: ((callee: ^7, tail: 1)), refs: (^10, ^2, ^4, ^5, ^6, ^9, ^12, ^3, ^8, ^1)))) ; guid = 15822663052811949562
^12 = gv: (name: "s56", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 15891404463864343411
^13 = flags: 8
^14 = blockcount: 0
