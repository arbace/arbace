; ModuleID = 'builtin-prefetch-5.c'
source_filename = "builtin-prefetch-5.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"

%struct.S = type { i16, i16, [8 x i8] }

@arr = dso_local global [100 x i8] zeroinitializer, align 16
@ptr = dso_local local_unnamed_addr global ptr @arr, align 8
@idx = dso_local local_unnamed_addr global i32 3, align 4
@s = dso_local global %struct.S zeroinitializer, align 8

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_ptr(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 {
  tail call void @llvm.prefetch.p0(ptr %0, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @llvm.prefetch.p0(ptr readonly captures(none), i32 immarg range(i32 0, 2), i32 immarg range(i32 0, 4), i32 immarg range(i32 0, 2)) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_idx(ptr nofree noundef readonly captures(none) %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = sext i32 %1 to i64
  %4 = getelementptr inbounds i8, ptr %0, i64 %3
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_ptr() local_unnamed_addr #2 {
  %1 = load ptr, ptr @ptr, align 8
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_idx() local_unnamed_addr #2 {
  %1 = load ptr, ptr @ptr, align 8
  %2 = load i32, ptr @idx, align 4
  %3 = sext i32 %2 to i64
  %4 = getelementptr inbounds i8, ptr %1, i64 %3
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1)
  ret void
}

; Function Attrs: nofree noreturn nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #3 {
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 2), i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1)
  %1 = load ptr, ptr @ptr, align 8
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 3
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 1
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1)
  store i32 3, ptr @idx, align 4
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1)
  store ptr %3, ptr @ptr, align 8
  store i32 2, ptr @idx, align 4
  tail call void @llvm.prefetch.p0(ptr nonnull %3, i32 0, i32 0, i32 1)
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1)
  tail call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nofree noreturn
declare dso_local void @exit(i32 noundef) local_unnamed_addr #4

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "builtin-prefetch-5.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
