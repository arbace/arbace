; ModuleID = '931110-2.c'
source_filename = "931110-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@main.a = internal global [2 x i32] [i32 3, i32 4], align 4, !dbg !0

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !2 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !20, !DIExpression(), !22)
    #dbg_declare(ptr %3, !23, !DIExpression(), !24)
  store ptr @main.a, ptr %2, align 8, !dbg !25
  %4 = load ptr, ptr %2, align 8, !dbg !26
  %5 = getelementptr inbounds nuw i32, ptr %4, i32 1, !dbg !26
  store ptr %5, ptr %2, align 8, !dbg !26
  %6 = load i32, ptr %4, align 4, !dbg !27
  %7 = srem i32 %6, 8, !dbg !28
  store i32 %7, ptr %3, align 4, !dbg !29
  %8 = load i32, ptr %3, align 4, !dbg !30
  %9 = icmp ne i32 %8, 3, !dbg !32
  br i1 %9, label %10, label %11, !dbg !32

10:                                               ; preds = %0
  call void @abort() #3, !dbg !33
  unreachable, !dbg !33

11:                                               ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !34
  unreachable, !dbg !34
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!7}
!llvm.module.flags = !{!12, !13, !14, !15, !16, !17, !18}
!llvm.ident = !{!19}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "a", scope: !2, file: !3, line: 7, type: !9, isLocal: true, isDefinition: true)
!2 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 5, type: !4, scopeLine: 6, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !8)
!3 = !DIFile(filename: "931110-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "e84249671cb40c7a6d9c84c5af81b793")
!4 = !DISubroutineType(types: !5)
!5 = !{!6}
!6 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!7 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!8 = !{!0}
!9 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 64, elements: !10)
!10 = !{!11}
!11 = !DISubrange(count: 2)
!12 = !{i32 7, !"Dwarf Version", i32 5}
!13 = !{i32 2, !"Debug Info Version", i32 3}
!14 = !{i32 4, !"probe-stack", !"inline-asm"}
!15 = !{i32 8, !"PIC Level", i32 2}
!16 = !{i32 7, !"PIE Level", i32 2}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{i32 7, !"frame-pointer", i32 2}
!19 = !{!"Alpine clang version 23.1.5"}
!20 = !DILocalVariable(name: "b", scope: !2, file: !3, line: 8, type: !21)
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!22 = !DILocation(line: 8, column: 17, scope: !2)
!23 = !DILocalVariable(name: "c", scope: !2, file: !3, line: 9, type: !6)
!24 = !DILocation(line: 9, column: 7, scope: !2)
!25 = !DILocation(line: 11, column: 5, scope: !2)
!26 = !DILocation(line: 12, column: 9, scope: !2)
!27 = !DILocation(line: 12, column: 7, scope: !2)
!28 = !DILocation(line: 12, column: 12, scope: !2)
!29 = !DILocation(line: 12, column: 5, scope: !2)
!30 = !DILocation(line: 13, column: 7, scope: !31)
!31 = distinct !DILexicalBlock(scope: !2, file: !3, line: 13, column: 7)
!32 = !DILocation(line: 13, column: 9, scope: !31)
!33 = !DILocation(line: 14, column: 5, scope: !31)
!34 = !DILocation(line: 15, column: 3, scope: !2)
