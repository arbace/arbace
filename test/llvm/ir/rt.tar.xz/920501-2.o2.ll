; ModuleID = '920501-2.c'
source_filename = "920501-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@factab = dso_local local_unnamed_addr global [10 x i64] zeroinitializer, align 16

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(none) uwtable
define dso_local i64 @gcd_ll(i64 noundef %0, i64 noundef %1) local_unnamed_addr #0 {
  %3 = icmp eq i64 %1, 0
  br i1 %3, label %12, label %4

4:                                                ; preds = %2, %9
  %5 = phi i64 [ %10, %9 ], [ %1, %2 ]
  %6 = phi i64 [ %7, %9 ], [ %0, %2 ]
  %7 = urem i64 %6, %5
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %12, label %9

9:                                                ; preds = %4
  %10 = urem i64 %5, %7
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %4

12:                                               ; preds = %9, %4, %2
  %13 = phi i64 [ %0, %2 ], [ %5, %4 ], [ %7, %9 ]
  ret i64 %13
}

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(none) uwtable
define dso_local i64 @powmod_ll(i64 noundef %0, i32 noundef %1, i64 noundef %2) local_unnamed_addr #0 {
  %4 = icmp eq i32 %1, 0
  br i1 %4, label %26, label %5

5:                                                ; preds = %3
  %6 = lshr i32 %1, 1
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %26, label %8

8:                                                ; preds = %5
  %9 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %6, i1 true)
  %10 = sub nuw nsw i32 32, %9
  br label %11

11:                                               ; preds = %8, %23
  %12 = phi i32 [ %14, %23 ], [ %10, %8 ]
  %13 = phi i64 [ %24, %23 ], [ %0, %8 ]
  %14 = add nsw i32 %12, -1
  %15 = mul i64 %13, %13
  %16 = urem i64 %15, %2
  %17 = shl nuw i32 1, %14
  %18 = and i32 %17, %1
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %23, label %20

20:                                               ; preds = %11
  %21 = mul i64 %16, %0
  %22 = urem i64 %21, %2
  br label %23

23:                                               ; preds = %11, %20
  %24 = phi i64 [ %22, %20 ], [ %16, %11 ]
  %25 = icmp samesign ugt i32 %12, 1
  br i1 %25, label %11, label %26, !llvm.loop !5

26:                                               ; preds = %23, %5, %3
  %27 = phi i64 [ 1, %3 ], [ %0, %5 ], [ %24, %23 ]
  ret i64 %27
}

; Function Attrs: nofree norecurse nosync nounwind sspstrong memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local void @facts(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) local_unnamed_addr #1 {
  %5 = sext i32 %1 to i64
  %6 = sext i32 %2 to i64
  %7 = icmp eq i32 %3, 0
  %8 = lshr i32 %3, 1
  %9 = icmp eq i32 %8, 0
  %10 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %8, i1 true)
  %11 = sub nuw nsw i32 32, %10
  %12 = add nsw i64 %5, 1
  br label %13

13:                                               ; preds = %4, %105
  %14 = phi i32 [ 0, %4 ], [ %109, %105 ]
  %15 = phi i32 [ 1, %4 ], [ %108, %105 ]
  %16 = phi i64 [ %0, %4 ], [ %107, %105 ]
  %17 = phi i32 [ 1, %4 ], [ %110, %105 ]
  %18 = phi ptr [ @factab, %4 ], [ %106, %105 ]
  %19 = phi i64 [ 1, %4 ], [ %85, %105 ]
  %20 = phi i64 [ %6, %4 ], [ %79, %105 ]
  %21 = phi i64 [ %6, %4 ], [ %77, %105 ]
  br i1 %7, label %75, label %22

22:                                               ; preds = %13
  br i1 %9, label %55, label %23

23:                                               ; preds = %22, %35
  %24 = phi i32 [ %26, %35 ], [ %11, %22 ]
  %25 = phi i64 [ %36, %35 ], [ %21, %22 ]
  %26 = add nsw i32 %24, -1
  %27 = mul i64 %25, %25
  %28 = urem i64 %27, %16
  %29 = shl nuw i32 1, %26
  %30 = and i32 %29, %3
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %35, label %32

32:                                               ; preds = %23
  %33 = mul i64 %28, %21
  %34 = urem i64 %33, %16
  br label %35

35:                                               ; preds = %32, %23
  %36 = phi i64 [ %34, %32 ], [ %28, %23 ]
  %37 = icmp samesign ugt i32 %24, 1
  br i1 %37, label %23, label %38, !llvm.loop !5

38:                                               ; preds = %35
  %39 = add i64 %36, %5
  br label %40

40:                                               ; preds = %38, %52
  %41 = phi i32 [ %43, %52 ], [ %11, %38 ]
  %42 = phi i64 [ %53, %52 ], [ %20, %38 ]
  %43 = add nsw i32 %41, -1
  %44 = mul i64 %42, %42
  %45 = urem i64 %44, %16
  %46 = shl nuw i32 1, %43
  %47 = and i32 %46, %3
  %48 = icmp eq i32 %47, 0
  br i1 %48, label %52, label %49

49:                                               ; preds = %40
  %50 = mul i64 %45, %20
  %51 = urem i64 %50, %16
  br label %52

52:                                               ; preds = %49, %40
  %53 = phi i64 [ %51, %49 ], [ %45, %40 ]
  %54 = icmp samesign ugt i32 %41, 1
  br i1 %54, label %40, label %58, !llvm.loop !5

55:                                               ; preds = %22
  %56 = add i64 %21, %5
  %57 = add i64 %20, %5
  br label %75

58:                                               ; preds = %52
  %59 = add i64 %53, %5
  br label %60

60:                                               ; preds = %58, %72
  %61 = phi i32 [ %63, %72 ], [ %11, %58 ]
  %62 = phi i64 [ %73, %72 ], [ %59, %58 ]
  %63 = add nsw i32 %61, -1
  %64 = mul i64 %62, %62
  %65 = urem i64 %64, %16
  %66 = shl nuw i32 1, %63
  %67 = and i32 %66, %3
  %68 = icmp eq i32 %67, 0
  br i1 %68, label %72, label %69

69:                                               ; preds = %60
  %70 = mul i64 %65, %59
  %71 = urem i64 %70, %16
  br label %72

72:                                               ; preds = %69, %60
  %73 = phi i64 [ %71, %69 ], [ %65, %60 ]
  %74 = icmp samesign ugt i32 %61, 1
  br i1 %74, label %60, label %75, !llvm.loop !5

75:                                               ; preds = %72, %55, %13
  %76 = phi i64 [ 1, %13 ], [ %21, %55 ], [ %36, %72 ]
  %77 = phi i64 [ %12, %13 ], [ %56, %55 ], [ %39, %72 ]
  %78 = phi i64 [ 1, %13 ], [ %57, %55 ], [ %73, %72 ]
  %79 = add i64 %78, %5
  %80 = icmp ugt i64 %77, %79
  %81 = sub i64 %76, %78
  %82 = sub i64 %78, %76
  %83 = select i1 %80, i64 %81, i64 %82
  %84 = mul i64 %83, %19
  %85 = urem i64 %84, %16
  %86 = icmp eq i32 %17, %15
  br i1 %86, label %87, label %105

87:                                               ; preds = %75
  %88 = add nsw i32 %14, 1
  %89 = add nsw i32 %88, %15
  br label %90

90:                                               ; preds = %87, %95
  %91 = phi i64 [ %96, %95 ], [ %16, %87 ]
  %92 = phi i64 [ %93, %95 ], [ %85, %87 ]
  %93 = urem i64 %92, %91
  %94 = icmp eq i64 %93, 0
  br i1 %94, label %98, label %95

95:                                               ; preds = %90
  %96 = urem i64 %91, %93
  %97 = icmp eq i64 %96, 0
  br i1 %97, label %98, label %90

98:                                               ; preds = %90, %95
  %99 = phi i64 [ %93, %95 ], [ %91, %90 ]
  %100 = icmp eq i64 %99, 1
  br i1 %100, label %105, label %101

101:                                              ; preds = %98
  %102 = getelementptr inbounds nuw i8, ptr %18, i64 8
  store i64 %99, ptr %18, align 8
  %103 = udiv i64 %16, %99
  %104 = icmp eq i64 %103, 1
  br i1 %104, label %112, label %105

105:                                              ; preds = %75, %101, %98
  %106 = phi ptr [ %102, %101 ], [ %18, %98 ], [ %18, %75 ]
  %107 = phi i64 [ %103, %101 ], [ %16, %98 ], [ %16, %75 ]
  %108 = phi i32 [ %89, %101 ], [ %89, %98 ], [ %15, %75 ]
  %109 = phi i32 [ %88, %101 ], [ %88, %98 ], [ %14, %75 ]
  %110 = add nuw nsw i32 %17, 1
  %111 = icmp eq i32 %110, 10000
  br i1 %111, label %112, label %13, !llvm.loop !7

112:                                              ; preds = %105, %101
  ret void
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  tail call void @facts(i64 noundef 134217727, i32 noundef -1, i32 noundef 3, i32 noundef 27)
  %1 = load i64, ptr @factab, align 16
  %2 = icmp ne i64 %1, 7
  %3 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 8), align 8
  %4 = icmp ne i64 %3, 73
  %5 = select i1 %2, i1 true, i1 %4
  %6 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 16), align 16
  %7 = icmp ne i64 %6, 262657
  %8 = select i1 %5, i1 true, i1 %7
  br i1 %8, label %9, label %10

9:                                                ; preds = %0
  tail call void @abort() #6
  unreachable

10:                                               ; preds = %0
  tail call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: cold nofree noreturn nounwind
declare void @abort() local_unnamed_addr #3

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #5

attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree norecurse nosync nounwind sspstrong memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
!5 = distinct !{!5, !6}
!6 = !{!"llvm.loop.mustprogress"}
!7 = distinct !{!7, !6}
