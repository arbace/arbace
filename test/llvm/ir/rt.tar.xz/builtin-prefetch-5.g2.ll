; ModuleID = 'builtin-prefetch-5.c'
source_filename = "builtin-prefetch-5.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i16, i16, [8 x i8] }

@arr = dso_local global [100 x i8] zeroinitializer, align 16, !dbg !0
@ptr = dso_local local_unnamed_addr global ptr @arr, align 8, !dbg !5
@idx = dso_local local_unnamed_addr global i32 3, align 4, !dbg !9
@s = dso_local global %struct.S zeroinitializer, align 2, !dbg !12

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_ptr(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !34 {
    #dbg_value(ptr %0, !38, !DIExpression(), !39)
  tail call void @llvm.prefetch.p0(ptr %0, i32 0, i32 0, i32 1), !dbg !40
  ret void, !dbg !41
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @llvm.prefetch.p0(ptr readonly captures(none), i32 immarg range(i32 0, 2), i32 immarg range(i32 0, 4), i32 immarg range(i32 0, 2)) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define dso_local void @arg_idx(ptr nofree noundef readonly captures(none) %0, i32 noundef %1) local_unnamed_addr #0 !dbg !42 {
    #dbg_value(ptr %0, !46, !DIExpression(), !48)
    #dbg_value(i32 %1, !47, !DIExpression(), !48)
  %3 = sext i32 %1 to i64, !dbg !49
  %4 = getelementptr inbounds i8, ptr %0, i64 %3, !dbg !49
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1), !dbg !50
  ret void, !dbg !51
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_ptr() local_unnamed_addr #2 !dbg !52 {
  %1 = load ptr, ptr @ptr, align 8, !dbg !55
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1), !dbg !56
  ret void, !dbg !57
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable
define dso_local void @glob_idx() local_unnamed_addr #2 !dbg !58 {
  %1 = load ptr, ptr @ptr, align 8, !dbg !59
  %2 = load i32, ptr @idx, align 4, !dbg !60
  %3 = sext i32 %2 to i64, !dbg !59
  %4 = getelementptr inbounds i8, ptr %1, i64 %3, !dbg !59
  tail call void @llvm.prefetch.p0(ptr %4, i32 0, i32 0, i32 1), !dbg !61
  ret void, !dbg !62
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #3 !dbg !63 {
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 2), i32 0, i32 0, i32 1), !dbg !66
  tail call void @llvm.prefetch.p0(ptr nonnull getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1), !dbg !67
    #dbg_value(ptr getelementptr inbounds nuw (i8, ptr @s, i64 5), !38, !DIExpression(), !68)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly getelementptr inbounds nuw (i8, ptr @s, i64 5), i32 0, i32 0, i32 1), !dbg !70
  %1 = load ptr, ptr @ptr, align 8, !dbg !71
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 3, !dbg !72
    #dbg_value(ptr %2, !38, !DIExpression(), !73)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1), !dbg !75
    #dbg_value(ptr %1, !46, !DIExpression(), !76)
    #dbg_value(i32 3, !47, !DIExpression(), !76)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1), !dbg !78
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 1, !dbg !79
    #dbg_value(ptr %3, !46, !DIExpression(), !80)
    #dbg_value(i32 2, !47, !DIExpression(), !80)
  tail call void @llvm.prefetch.p0(ptr nonnull readonly %2, i32 0, i32 0, i32 1), !dbg !82
  store i32 3, ptr @idx, align 4, !dbg !83
  tail call void @llvm.prefetch.p0(ptr %1, i32 0, i32 0, i32 1), !dbg !84
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1), !dbg !86
  store ptr %3, ptr @ptr, align 8, !dbg !88
  store i32 2, ptr @idx, align 4, !dbg !89
  tail call void @llvm.prefetch.p0(ptr nonnull %3, i32 0, i32 0, i32 1), !dbg !90
  tail call void @llvm.prefetch.p0(ptr nonnull %2, i32 0, i32 0, i32 1), !dbg !92
  tail call void @exit(i32 noundef 0) #5, !dbg !94
  unreachable, !dbg !94
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #4

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!26, !27, !28, !29, !30, !31, !32}
!llvm.ident = !{!33}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "arr", scope: !2, file: !3, line: 16, type: !23, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "builtin-prefetch-5.c", directory: ".", checksumkind: CSK_MD5, checksum: "0bf5ca2f6d5bd0aab66e4f0dce7fa3af")
!4 = !{!5, !9, !12, !0}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "ptr", scope: !2, file: !3, line: 17, type: !7, isLocal: false, isDefinition: true)
!7 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !8, size: 64)
!8 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "idx", scope: !2, file: !3, line: 18, type: !11, isLocal: false, isDefinition: true)
!11 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !3, line: 14, type: !14, isLocal: false, isDefinition: true)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "S", file: !3, line: 10, size: 96, elements: !15)
!15 = !{!16, !18, !19}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !14, file: !3, line: 11, baseType: !17, size: 16)
!17 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !14, file: !3, line: 12, baseType: !17, size: 16, offset: 16)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !14, file: !3, line: 13, baseType: !20, size: 64, offset: 32)
!20 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 64, elements: !21)
!21 = !{!22}
!22 = !DISubrange(count: 8)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 800, elements: !24)
!24 = !{!25}
!25 = !DISubrange(count: 100)
!26 = !{i32 7, !"Dwarf Version", i32 5}
!27 = !{i32 2, !"Debug Info Version", i32 3}
!28 = !{i32 4, !"probe-stack", !"inline-asm"}
!29 = !{i32 8, !"PIC Level", i32 2}
!30 = !{i32 7, !"PIE Level", i32 2}
!31 = !{i32 7, !"uwtable", i32 2}
!32 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!33 = !{!"Alpine clang version 23.1.5"}
!34 = distinct !DISubprogram(name: "arg_ptr", scope: !3, file: !3, line: 21, type: !35, scopeLine: 22, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !37, keyInstructions: true)
!35 = !DISubroutineType(types: !36)
!36 = !{null, !7}
!37 = !{!38}
!38 = !DILocalVariable(name: "p", arg: 1, scope: !34, file: !3, line: 21, type: !7)
!39 = !DILocation(line: 0, scope: !34)
!40 = !DILocation(line: 23, column: 3, scope: !34)
!41 = !DILocation(line: 24, column: 1, scope: !34, atomGroup: 1, atomRank: 1)
!42 = distinct !DISubprogram(name: "arg_idx", scope: !3, file: !3, line: 27, type: !43, scopeLine: 28, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !45, keyInstructions: true)
!43 = !DISubroutineType(types: !44)
!44 = !{null, !7, !11}
!45 = !{!46, !47}
!46 = !DILocalVariable(name: "p", arg: 1, scope: !42, file: !3, line: 27, type: !7)
!47 = !DILocalVariable(name: "i", arg: 2, scope: !42, file: !3, line: 27, type: !11)
!48 = !DILocation(line: 0, scope: !42)
!49 = !DILocation(line: 29, column: 24, scope: !42)
!50 = !DILocation(line: 29, column: 3, scope: !42)
!51 = !DILocation(line: 30, column: 1, scope: !42, atomGroup: 1, atomRank: 1)
!52 = distinct !DISubprogram(name: "glob_ptr", scope: !3, file: !3, line: 33, type: !53, scopeLine: 34, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!53 = !DISubroutineType(types: !54)
!54 = !{null}
!55 = !DILocation(line: 35, column: 23, scope: !52)
!56 = !DILocation(line: 35, column: 3, scope: !52)
!57 = !DILocation(line: 36, column: 1, scope: !52, atomGroup: 1, atomRank: 1)
!58 = distinct !DISubprogram(name: "glob_idx", scope: !3, file: !3, line: 39, type: !53, scopeLine: 40, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!59 = !DILocation(line: 41, column: 24, scope: !58)
!60 = !DILocation(line: 41, column: 28, scope: !58)
!61 = !DILocation(line: 41, column: 3, scope: !58)
!62 = !DILocation(line: 42, column: 1, scope: !58, atomGroup: 1, atomRank: 1)
!63 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 45, type: !64, scopeLine: 46, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!64 = !DISubroutineType(types: !65)
!65 = !{!11}
!66 = !DILocation(line: 47, column: 3, scope: !63)
!67 = !DILocation(line: 48, column: 3, scope: !63)
!68 = !DILocation(line: 0, scope: !34, inlinedAt: !69)
!69 = distinct !DILocation(line: 50, column: 3, scope: !63)
!70 = !DILocation(line: 23, column: 3, scope: !34, inlinedAt: !69)
!71 = !DILocation(line: 51, column: 12, scope: !63)
!72 = !DILocation(line: 51, column: 15, scope: !63)
!73 = !DILocation(line: 0, scope: !34, inlinedAt: !74)
!74 = distinct !DILocation(line: 51, column: 3, scope: !63)
!75 = !DILocation(line: 23, column: 3, scope: !34, inlinedAt: !74)
!76 = !DILocation(line: 0, scope: !42, inlinedAt: !77)
!77 = distinct !DILocation(line: 52, column: 3, scope: !63)
!78 = !DILocation(line: 29, column: 3, scope: !42, inlinedAt: !77)
!79 = !DILocation(line: 53, column: 15, scope: !63)
!80 = !DILocation(line: 0, scope: !42, inlinedAt: !81)
!81 = distinct !DILocation(line: 53, column: 3, scope: !63)
!82 = !DILocation(line: 29, column: 3, scope: !42, inlinedAt: !81)
!83 = !DILocation(line: 54, column: 7, scope: !63, atomGroup: 1, atomRank: 1)
!84 = !DILocation(line: 35, column: 3, scope: !52, inlinedAt: !85)
!85 = distinct !DILocation(line: 55, column: 3, scope: !63)
!86 = !DILocation(line: 41, column: 3, scope: !58, inlinedAt: !87)
!87 = distinct !DILocation(line: 56, column: 3, scope: !63)
!88 = !DILocation(line: 57, column: 6, scope: !63, atomGroup: 2, atomRank: 1)
!89 = !DILocation(line: 58, column: 7, scope: !63, atomGroup: 3, atomRank: 1)
!90 = !DILocation(line: 35, column: 3, scope: !52, inlinedAt: !91)
!91 = distinct !DILocation(line: 59, column: 3, scope: !63)
!92 = !DILocation(line: 41, column: 3, scope: !58, inlinedAt: !93)
!93 = distinct !DILocation(line: 60, column: 3, scope: !63)
!94 = !DILocation(line: 61, column: 3, scope: !63)
