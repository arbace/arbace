; ModuleID = 'enum-3.c'
source_filename = "enum-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@q = dso_local global ptr null, align 8, !dbg !0
@p = dso_local global ptr null, align 8, !dbg !10

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !22 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !26, !DIExpression(), !27)
  store i32 -2147483648, ptr %2, align 4, !dbg !27
  store ptr %2, ptr @q, align 8, !dbg !28
  %3 = load ptr, ptr @q, align 8, !dbg !29
  %4 = load i32, ptr %3, align 4, !dbg !31
  %5 = icmp sgt i32 %4, 0, !dbg !32
  br i1 %5, label %6, label %7, !dbg !32

6:                                                ; preds = %0
  call void @abort() #3, !dbg !33
  unreachable, !dbg !33

7:                                                ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !34
  unreachable, !dbg !34
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!14, !15, !16, !17, !18, !19, !20}
!llvm.ident = !{!21}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !3, line: 15, type: !13, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !9, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "enum-3.c", directory: ".", checksumkind: CSK_MD5, checksum: "91b8922c3b6304ab6ab99942dbca6c66")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "e", file: !3, line: 12, baseType: !6, size: 32, elements: !7)
!6 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!7 = !{!8}
!8 = !DIEnumerator(name: "a", value: -2147483648)
!9 = !{!10, !0}
!10 = !DIGlobalVariableExpression(var: !11, expr: !DIExpression())
!11 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !3, line: 14, type: !12, isLocal: false, isDefinition: true)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!14 = !{i32 7, !"Dwarf Version", i32 5}
!15 = !{i32 2, !"Debug Info Version", i32 3}
!16 = !{i32 4, !"probe-stack", !"inline-asm"}
!17 = !{i32 8, !"PIC Level", i32 2}
!18 = !{i32 7, !"PIE Level", i32 2}
!19 = !{i32 7, !"uwtable", i32 2}
!20 = !{i32 7, !"frame-pointer", i32 2}
!21 = !{!"Alpine clang version 23.1.5"}
!22 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 17, type: !23, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !25)
!23 = !DISubroutineType(types: !24)
!24 = !{!6}
!25 = !{}
!26 = !DILocalVariable(name: "x", scope: !22, file: !3, line: 19, type: !5)
!27 = !DILocation(line: 19, column: 10, scope: !22)
!28 = !DILocation(line: 20, column: 5, scope: !22)
!29 = !DILocation(line: 21, column: 13, scope: !30)
!30 = distinct !DILexicalBlock(scope: !22, file: !3, line: 21, column: 7)
!31 = !DILocation(line: 21, column: 7, scope: !30)
!32 = !DILocation(line: 21, column: 20, scope: !30)
!33 = !DILocation(line: 22, column: 5, scope: !30)
!34 = !DILocation(line: 23, column: 3, scope: !22)
