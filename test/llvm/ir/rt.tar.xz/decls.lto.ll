; ModuleID = 'test/cpp/samples/decls.cpp'
source_filename = "test/cpp/samples/decls.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S2 = type { i32, i32 }

@_ZN1A1sE = dso_local local_unnamed_addr global i32 0, align 4, !guid !0
@_ZN1a1b1c1zE = dso_local local_unnamed_addr global i32 0, align 4, !guid !1
@fp = dso_local local_unnamed_addr global ptr null, align 8, !guid !2
@p = dso_local local_unnamed_addr global ptr null, align 8, !guid !3
@s2 = dso_local local_unnamed_addr global %struct.S2 zeroinitializer, align 4, !guid !4
@ps2 = dso_local local_unnamed_addr global ptr null, align 8, !guid !5
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_decls.cpp, ptr null }], !guid !6

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znam(i64 noundef) local_unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef range(i32 1, -2147483648) i32 @_Z1gi(i32 noundef %0) local_unnamed_addr #1 !guid !19 {
  %2 = tail call i32 @llvm.smax.i32(i32 %0, i32 1)
  ret i32 %2
}

; Function Attrs: sspstrong uwtable
define internal void @_GLOBAL__sub_I_decls.cpp() #2 section ".text.startup" !guid !20 {
  %1 = tail call noalias noundef nonnull dereferenceable(3) ptr @_Znam(i64 noundef 3) #4
  store i8 1, ptr %1, align 1, !tbaa !21
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 1
  store i8 2, ptr %2, align 1, !tbaa !21
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 2
  store i8 3, ptr %3, align 1, !tbaa !21
  store ptr %1, ptr @p, align 8, !tbaa !22
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #3

attributes #0 = { nobuiltin allocsize(0) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { builtin allocsize(0) }

!llvm.module.flags = !{!7, !8, !9, !10, !11, !12}
!llvm.ident = !{!13}
!llvm.errno.tbaa = !{!14}

!0 = !{i64 4190043858551444936}
!1 = !{i64 -203781284137274047}
!2 = !{i64 -3154509998333073914}
!3 = !{i64 -8054666941605050493}
!4 = !{i64 -2652992381237212678}
!5 = !{i64 5687347818708306644}
!6 = !{i64 2412314959268824392}
!7 = !{i32 4, !"probe-stack", !"inline-asm"}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"PIE Level", i32 2}
!10 = !{i32 7, !"uwtable", i32 2}
!11 = !{i32 1, !"ThinLTO", i32 0}
!12 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!13 = !{!"Alpine clang version 23.1.5"}
!14 = !{!15, !16, i64 0}
!15 = !{!"__libc_errno", !16, i64 0}
!16 = !{!"int", !17, i64 0}
!17 = !{!"omnipotent char", !18, i64 0}
!18 = !{!"Simple C++ TBAA"}
!19 = !{i64 5460364941162528111}
!20 = !{i64 -6872137086214421923}
!21 = !{!17, !17, i64 0}
!22 = !{!23, !23, i64 0}
!23 = !{!"p1 omnipotent char", !24, i64 0}
!24 = !{!"any pointer", !17, i64 0}

^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "llvm.global_ctors", summaries: (variable: (module: ^0, flags: (linkage: appending, visibility: default, notEligibleToImport: 1, live: 1, dsoLocal: 0, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 0, writeonly: 0, constant: 0), refs: (^6)))) ; guid = 2412314959268824392
^2 = gv: (name: "_ZN1A1sE", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 4190043858551444936
^3 = gv: (name: "_Z1gi", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 2, funcFlags: (readNone: 1, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0)))) ; guid = 5460364941162528111
^4 = gv: (name: "ps2", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 5687347818708306644
^5 = gv: (name: "p", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 10392077132104501123
^6 = gv: (name: "_GLOBAL__sub_I_decls.cpp", summaries: (function: (module: ^0, flags: (linkage: internal, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 8, calls: ((callee: ^10, tail: 1)), refs: (^5)))) ; guid = 11574606987495129693
^7 = gv: (name: "fp", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 15292234075376477702
^8 = gv: (name: "s2", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 15793751692472338938
^9 = gv: (name: "_ZN1a1b1c1zE", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0)))) ; guid = 18242962789572277569
^10 = gv: (name: "_Znam") ; guid = 18423971256537370017
^11 = flags: 8
^12 = blockcount: 0
