; ModuleID = 'test/cpp/samples/layouts.cpp'
source_filename = "test/cpp/samples/layouts.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.D = type { %struct.B.base, i8, double }
%struct.B.base = type <{ ptr, i32 }>
%struct.F = type { i8, i8, [2 x i8] }
%"struct.n::G" = type { i32 }

$_ZN1DC2Ev = comdat any

$_ZN1BC2Ev = comdat any

@gd = dso_local global %struct.D zeroinitializer, align 8, !dbg !0
@gf = dso_local global %struct.F zeroinitializer, align 4, !dbg !5
@gg = dso_local global %"struct.n::G" zeroinitializer, align 4, !dbg !14
@_ZTV1D = external constant { [3 x ptr] }, align 8
@_ZTV1B = external constant { [3 x ptr] }, align 8
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_layouts.cpp, ptr null }]

; Function Attrs: noinline sspstrong uwtable
define internal void @__cxx_global_var_init() #0 section ".text.startup" !dbg !32 {
  call void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(24) @gd) #2, !dbg !35
  ret void, !dbg !35
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1DC2Ev(ptr noundef nonnull align 8 dereferenceable(24) %0) unnamed_addr #1 comdat align 2 !dbg !36 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !42, !DIExpression(), !44)
  %3 = load ptr, ptr %2, align 8
  call void @_ZN1BC2Ev(ptr noundef nonnull align 8 dereferenceable(12) %3) #2, !dbg !45
  store ptr getelementptr inbounds inrange(-16, 8) ({ [3 x ptr] }, ptr @_ZTV1D, i32 0, i32 0, i32 2), ptr %3, align 8, !dbg !45
  ret void, !dbg !45
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN1BC2Ev(ptr noundef nonnull align 8 dereferenceable(12) %0) unnamed_addr #1 comdat align 2 !dbg !46 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !52, !DIExpression(), !54)
  %3 = load ptr, ptr %2, align 8
  store ptr getelementptr inbounds inrange(-16, 8) ({ [3 x ptr] }, ptr @_ZTV1B, i32 0, i32 0, i32 2), ptr %3, align 8, !dbg !55
  ret void, !dbg !55
}

; Function Attrs: noinline sspstrong uwtable
define internal void @_GLOBAL__sub_I_layouts.cpp() #0 section ".text.startup" !dbg !56 {
  call void @__cxx_global_var_init(), !dbg !58
  ret void
}

attributes #0 = { noinline sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!24, !25, !26, !27, !28, !29, !30}
!llvm.ident = !{!31}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "gd", scope: !2, file: !3, line: 5, type: !23, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "test/cpp/samples/layouts.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "4e48fa8e9848807a6414af6595fe80c6")
!4 = !{!0, !5, !14}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "gf", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!7 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "F", file: !3, line: 3, size: 32, flags: DIFlagTypePassByValue, elements: !8, identifier: "_ZTS1F")
!8 = !{!9, !11, !12}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !7, file: !3, line: 3, baseType: !10, size: 3, flags: DIFlagBitField, extraData: i64 0)
!10 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !7, file: !3, line: 3, baseType: !10, size: 5, offset: 3, flags: DIFlagBitField, extraData: i64 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !7, file: !3, line: 3, baseType: !13, size: 8, offset: 8)
!13 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!14 = !DIGlobalVariableExpression(var: !15, expr: !DIExpression())
!15 = distinct !DIGlobalVariable(name: "gg", scope: !2, file: !3, line: 5, type: !16, isLocal: false, isDefinition: true)
!16 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "G<int>", scope: !17, file: !3, line: 4, size: 32, flags: DIFlagTypePassByValue, elements: !18, templateParams: !21, identifier: "_ZTSN1n1GIiEE")
!17 = !DINamespace(name: "n", scope: null)
!18 = !{!19}
!19 = !DIDerivedType(tag: DW_TAG_member, name: "x", scope: !16, file: !3, line: 4, baseType: !20, size: 32)
!20 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!21 = !{!22}
!22 = !DITemplateTypeParameter(name: "T", type: !20)
!23 = !DICompositeType(tag: DW_TAG_structure_type, name: "D", file: !3, line: 2, size: 192, flags: DIFlagFwdDecl | DIFlagNonTrivial)
!24 = !{i32 7, !"Dwarf Version", i32 5}
!25 = !{i32 2, !"Debug Info Version", i32 3}
!26 = !{i32 4, !"probe-stack", !"inline-asm"}
!27 = !{i32 8, !"PIC Level", i32 2}
!28 = !{i32 7, !"PIE Level", i32 2}
!29 = !{i32 7, !"uwtable", i32 2}
!30 = !{i32 7, !"frame-pointer", i32 2}
!31 = !{!"Alpine clang version 23.1.5"}
!32 = distinct !DISubprogram(name: "__cxx_global_var_init", scope: !3, file: !3, type: !33, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2)
!33 = !DISubroutineType(types: !34)
!34 = !{null}
!35 = !DILocation(line: 5, column: 3, scope: !32)
!36 = distinct !DISubprogram(name: "D", linkageName: "_ZN1DC2Ev", scope: !23, file: !3, line: 2, type: !37, scopeLine: 2, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !40, retainedNodes: !41)
!37 = !DISubroutineType(types: !38)
!38 = !{null, !39}
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !23, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!40 = !DISubprogram(name: "D", linkageName: "_ZN1DC4Ev", scope: !23, type: !37, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: 0)
!41 = !{}
!42 = !DILocalVariable(name: "this", arg: 1, scope: !36, type: !43, flags: DIFlagArtificial | DIFlagObjectPointer)
!43 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !23, size: 64)
!44 = !DILocation(line: 0, scope: !36)
!45 = !DILocation(line: 2, column: 8, scope: !36)
!46 = distinct !DISubprogram(name: "B", linkageName: "_ZN1BC2Ev", scope: !47, file: !3, line: 1, type: !48, scopeLine: 1, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, declaration: !51, retainedNodes: !41)
!47 = !DICompositeType(tag: DW_TAG_structure_type, name: "B", file: !3, line: 1, size: 128, flags: DIFlagFwdDecl | DIFlagNonTrivial)
!48 = !DISubroutineType(types: !49)
!49 = !{null, !50}
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !47, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!51 = !DISubprogram(name: "B", linkageName: "_ZN1BC4Ev", scope: !47, type: !48, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: 0)
!52 = !DILocalVariable(name: "this", arg: 1, scope: !46, type: !53, flags: DIFlagArtificial | DIFlagObjectPointer)
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !47, size: 64)
!54 = !DILocation(line: 0, scope: !46)
!55 = !DILocation(line: 1, column: 8, scope: !46)
!56 = distinct !DISubprogram(linkageName: "_GLOBAL__sub_I_layouts.cpp", scope: !3, file: !3, type: !57, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2)
!57 = !DISubroutineType(types: !41)
!58 = !DILocation(line: 0, scope: !56)
