; MUTANT: hoistr invalid Verifier: Instruction does not dominate all uses!
source_filename = "20030109-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.X = type { i32, i32, [0 x i32] }
@x = dso_local local_unnamed_addr global %struct.X { i32 0, i32 40, [0 x i32] zeroinitializer }, align 4
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = icmp eq i32 %2, 40
  %2 = load i32, ptr getelementptr inbounds nuw (i8, ptr @x, i64 4), align 4
  br i1 %1, label %4, label %3

3:
  tail call void @abort() #2
  unreachable

4:
  ret i32 0
}

declare void @abort() local_unnamed_addr #1
attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
