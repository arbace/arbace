; MUTANT: noterm invalid LLParser: expected instruction opcode
source_filename = "20030914-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.s = type { [18 x i32] }
@gs = dso_local local_unnamed_addr global %struct.s zeroinitializer, align 4, !dbg !0
define dso_local noundef i32 @f(ptr nofree noundef readnone byval(%struct.s) align 8 captures(none) %0, i32 noundef returned %1, ...) local_unnamed_addr #0 !dbg !20 {
    #dbg_declare(ptr %0, !24, !DIExpression(), !26)
    #dbg_value(i32 %1, !25, !DIExpression(), !27)
  ret i32 %1, !dbg !28
}

define dso_local noundef i32 @main() local_unnamed_addr #1 !dbg !29 {
  tail call void @exit(i32 noundef 0) #3, !dbg !32
}

declare void @exit(i32 noundef) local_unnamed_addr #2
attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!12, !13, !14, !15, !16, !17, !18}
!llvm.ident = !{!19}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "gs", scope: !2, file: !3, line: 16, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20030914-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "459da48339e5ed0882427df53d0786c3")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "s", file: !3, line: 9, size: 576, elements: !6)
!6 = !{!7}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "i", scope: !5, file: !3, line: 9, baseType: !8, size: 576)
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 576, elements: !10)
!9 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!10 = !{!11}
!11 = !DISubrange(count: 18)
!12 = !{i32 7, !"Dwarf Version", i32 5}
!13 = !{i32 2, !"Debug Info Version", i32 3}
!14 = !{i32 4, !"probe-stack", !"inline-asm"}
!15 = !{i32 8, !"PIC Level", i32 2}
!16 = !{i32 7, !"PIE Level", i32 2}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!19 = !{!"Alpine clang version 23.1.5"}
!20 = distinct !DISubprogram(name: "f", scope: !3, file: !3, line: 11, type: !21, scopeLine: 12, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !23, keyInstructions: true)
!21 = !DISubroutineType(types: !22)
!22 = !{!9, !5, !9, null}
!23 = !{!24, !25}
!24 = !DILocalVariable(name: "pa", arg: 1, scope: !20, file: !3, line: 11, type: !5)
!25 = !DILocalVariable(name: "pb", arg: 2, scope: !20, file: !3, line: 11, type: !9)
!26 = !DILocation(line: 11, column: 17, scope: !20)
!27 = !DILocation(line: 0, scope: !20)
!28 = !DILocation(line: 13, column: 3, scope: !20, atomGroup: 1, atomRank: 1)
!29 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 18, type: !30, scopeLine: 19, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!30 = !DISubroutineType(types: !31)
!31 = !{!9}
!32 = !DILocation(line: 23, column: 3, scope: !29)
