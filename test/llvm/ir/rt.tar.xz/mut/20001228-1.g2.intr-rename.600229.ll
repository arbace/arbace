; MUTANT: intr-rename invalid Verifier: intrinsic return type (overload type 0) expected any fp or fp vector, but got void
source_filename = "20001228-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local noundef i32 @foo1() local_unnamed_addr #0 !dbg !10 {
    #dbg_value(i8 1, !24, !DIExpression(DW_OP_LLVM_fragment, 0, 8), !25)
    #dbg_value(i24 0, !24, !DIExpression(DW_OP_LLVM_fragment, 8, 24), !25)
  ret i32 1, !dbg !26
}

declare void @llvm.lifetime.start.p0(ptr captures(none)) #1
declare void @llvm.sqrt.f64(ptr captures(none)) #1
define dso_local range(i32 -128, 128) i32 @foo2() local_unnamed_addr #2 !dbg !27 {
  %1 = alloca i32, align 4, !DIAssignID !35
    #dbg_assign(i1 poison, !33, !DIExpression(), !35, ptr %1, !DIExpression(), !36)
  call void @llvm.lifetime.start.p0(ptr nonnull %1), !dbg !37
  store volatile i32 1, ptr %1, align 4, !dbg !38, !DIAssignID !39
    #dbg_assign(i32 1, !33, !DIExpression(), !39, ptr %1, !DIExpression(), !36)
  %2 = load volatile i8, ptr %1, align 4, !dbg !40
  %3 = sext i8 %2 to i32, !dbg !41
  call void @llvm.sqrt.f64(ptr nonnull %1), !dbg !42
  ret i32 %3, !dbg !43
}

define dso_local noundef i32 @main() local_unnamed_addr #3 !dbg !44 {
  %1 = alloca i32, align 4, !DIAssignID !45
    #dbg_assign(i1 poison, !33, !DIExpression(), !45, ptr %1, !DIExpression(), !46)
  call void @llvm.lifetime.start.p0(ptr nonnull %1), !dbg !49
  store volatile i32 1, ptr %1, align 4, !dbg !50, !DIAssignID !51
    #dbg_assign(i32 1, !33, !DIExpression(), !51, ptr %1, !DIExpression(), !46)
  %2 = load volatile i8, ptr %1, align 4, !dbg !52
  call void @llvm.sqrt.f64(ptr nonnull %1), !dbg !53
  %3 = icmp eq i8 %2, 1, !dbg !54
  br i1 %3, label %5, label %4, !dbg !55

4:
  tail call void @abort() #6, !dbg !56
  unreachable, !dbg !56

5:
  tail call void @exit(i32 noundef 0) #6, !dbg !57
  unreachable, !dbg !57
}

declare void @abort() local_unnamed_addr #4
declare void @exit(i32 noundef) local_unnamed_addr #5
attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind sspstrong memory(inaccessiblemem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20001228-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "12ac9f0cc94c44dd65dd57e14e7ed2bb")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "foo1", scope: !1, file: !1, line: 4, type: !11, scopeLine: 5, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !14, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!14 = !{!15, !24}
!15 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !10, file: !1, line: 6, size: 32, elements: !16)
!16 = !{!17, !22}
!17 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !15, file: !1, line: 7, baseType: !18, size: 32)
!18 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 32, elements: !20)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!20 = !{!21}
!21 = !DISubrange(count: 4)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !15, file: !1, line: 8, baseType: !23, size: 32)
!23 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!24 = !DILocalVariable(name: "u", scope: !10, file: !1, line: 9, type: !15)
!25 = !DILocation(line: 0, scope: !10)
!26 = !DILocation(line: 12, column: 3, scope: !10, atomGroup: 3, atomRank: 1)
!27 = distinct !DISubprogram(name: "foo2", scope: !1, file: !1, line: 15, type: !11, scopeLine: 16, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !28, keyInstructions: true)
!28 = !{!29, !33}
!29 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !27, file: !1, line: 17, size: 32, elements: !30)
!30 = !{!31, !32}
!31 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !29, file: !1, line: 18, baseType: !18, size: 32)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !29, file: !1, line: 19, baseType: !23, size: 32)
!33 = !DILocalVariable(name: "u", scope: !27, file: !1, line: 20, type: !34)
!34 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !29)
!35 = distinct !DIAssignID()
!36 = !DILocation(line: 0, scope: !27)
!37 = !DILocation(line: 17, column: 3, scope: !27)
!38 = !DILocation(line: 22, column: 7, scope: !27, atomGroup: 1, atomRank: 1)
!39 = distinct !DIAssignID()
!40 = !DILocation(line: 23, column: 10, scope: !27, atomGroup: 3, atomRank: 3)
!41 = !DILocation(line: 23, column: 10, scope: !27, atomGroup: 3, atomRank: 2)
!42 = !DILocation(line: 24, column: 1, scope: !27)
!43 = !DILocation(line: 23, column: 3, scope: !27, atomGroup: 3, atomRank: 1)
!44 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 26, type: !11, scopeLine: 27, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!45 = distinct !DIAssignID()
!46 = !DILocation(line: 0, scope: !27, inlinedAt: !47)
!47 = distinct !DILocation(line: 28, column: 17, scope: !48)
!48 = distinct !DILexicalBlock(scope: !44, file: !1, line: 28, column: 7)
!49 = !DILocation(line: 17, column: 3, scope: !27, inlinedAt: !47)
!50 = !DILocation(line: 22, column: 7, scope: !27, inlinedAt: !47, atomGroup: 1, atomRank: 1)
!51 = distinct !DIAssignID()
!52 = !DILocation(line: 23, column: 10, scope: !27, inlinedAt: !47, atomGroup: 3, atomRank: 3)
!53 = !DILocation(line: 24, column: 1, scope: !27, inlinedAt: !47)
!54 = !DILocation(line: 28, column: 14, scope: !48, atomGroup: 1, atomRank: 2)
!55 = !DILocation(line: 28, column: 14, scope: !48, atomGroup: 1, atomRank: 1)
!56 = !DILocation(line: 29, column: 5, scope: !48)
!57 = !DILocation(line: 30, column: 3, scope: !44)
