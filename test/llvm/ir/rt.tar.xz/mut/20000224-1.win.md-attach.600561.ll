; MUTANT: md-attach invalid Verifier: Wrong number of operands
source_filename = "20000224-1.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"
@loop_1 = dso_local local_unnamed_addr global i32 100, align 4
@loop_2 = dso_local local_unnamed_addr global i32 7, align 4
@flag = dso_local local_unnamed_addr global i32 0, align 4
define dso_local noundef i32 @test() local_unnamed_addr #0 {
  %1 = load i32, ptr @loop_1, align 4
  %2 = icmp sgt i32 %1, 0
  br i1 %2, label %3, label %18

3:
  %4 = load i32, ptr @flag, align 4
  %5 = load i32, ptr @loop_2, align 4
  %6 = icmp slt i32 %5, 1
  br label %7

7:
  %8 = phi i32 [ 0, %3 ], [ %14, %7 ]
  %9 = phi i32 [ %4, %3 ], [ %15, %7 ]
  %10 = and i32 %9, 1
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %11, i1 true, i1 %6, !prof !9
  %13 = select i1 %12, i32 0, i32 %5
  %14 = add i32 %8, %13
  %15 = add i32 %9, 1
  %16 = icmp sgt i32 %1, %14
  br i1 %16, label %7, label %17, !llvm.loop !7

17:
  store i32 %15, ptr @flag, align 4
  br label %18

18:
  ret i32 1
}

define dso_local noundef i32 @main() local_unnamed_addr #1 {
  %1 = tail call i32 @test()
  tail call void @exit(i32 noundef 0) #3
  unreachable
}

declare dso_local void @exit(i32 noundef) local_unnamed_addr #2
attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20000224-1.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!"branch_weights", i32 1}
