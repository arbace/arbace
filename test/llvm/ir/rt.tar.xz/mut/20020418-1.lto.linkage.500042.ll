; MUTANT: linkage invalid LLParser: invalid linkage for function declaration
source_filename = "20020418-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local void @gcc_crash(ptr nofree noundef captures(none) %0) local_unnamed_addr #0 !guid !7 {
  %2 = load i32, ptr %0, align 4
  %3 = icmp slt i32 %2, 52
  br i1 %3, label %6, label %4, !prof !8

4:
  %5 = icmp samesign ugt i32 %2, 60
  br label %7

6:
  tail call void @llvm.trap()
  unreachable

7:
  %8 = phi i32 [ %9, %7 ], [ %2, %4 ]
  %9 = add nuw nsw i32 %8, 1
  br i1 %5, label %7, label %10

10:
  store i32 %9, ptr %0, align 4
  ret void
}

declare internal void @llvm.trap() #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !guid !9 {
  tail call void @exit(i32 noundef 0) #4
  unreachable
}

declare void @exit(i32 noundef) local_unnamed_addr #3
attributes #0 = { nounwind sspstrong memory(argmem: readwrite, inaccessiblemem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 1, !"ThinLTO", i32 0}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = !{i64 -6441051707095393607}
!8 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!9 = !{i64 -2624081020897602054}
^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "exit")
^2 = gv: (name: "gcc_crash", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 12, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0))))
^3 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 2, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 1), calls: ((callee: ^1, tail: 1)))))
^4 = flags: 8
^5 = blockcount: 0
