; MUTANT: hoistr invalid Verifier: Instruction does not dominate all uses!
source_filename = "920501-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@factab = dso_local global [10 x i64] zeroinitializer, align 16, !dbg !0
define dso_local i64 @gcd_ll(i64 noundef %0, i64 noundef %1) #0 !dbg !19 {
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  store i64 %0, ptr %4, align 8
    #dbg_declare(ptr %4, !23, !DIExpression(), !24)
  store i64 %1, ptr %5, align 8
    #dbg_declare(ptr %5, !25, !DIExpression(), !26)
  br label %6, !dbg !27

6:
  %7 = load i64, ptr %5, align 8, !dbg !28
  %8 = icmp eq i64 %7, 0, !dbg !33
  br i1 %8, label %9, label %11, !dbg !33

9:
  %10 = load i64, ptr %4, align 8, !dbg !34
  store i64 %10, ptr %3, align 8, !dbg !35
  br label %23, !dbg !35

11:
  %12 = load i64, ptr %4, align 8, !dbg !36
  %13 = load i64, ptr %5, align 8, !dbg !37
  %14 = urem i64 %12, %13, !dbg !38
  store i64 %14, ptr %4, align 8, !dbg !39
  %15 = load i64, ptr %4, align 8, !dbg !40
  %16 = icmp eq i64 %15, 0, !dbg !42
  br i1 %16, label %17, label %19, !dbg !42

17:
  %18 = load i64, ptr %5, align 8, !dbg !43
  store i64 %18, ptr %3, align 8, !dbg !44
  br label %23, !dbg !44

19:
  %20 = load i64, ptr %5, align 8, !dbg !45
  %21 = load i64, ptr %4, align 8, !dbg !46
  %22 = urem i64 %20, %21, !dbg !47
  store i64 %22, ptr %5, align 8, !dbg !48
  br label %6, !dbg !49, !llvm.loop !50

23:
  %24 = load i64, ptr %3, align 8, !dbg !53
  ret i64 %24, !dbg !53
}

define dso_local i64 @powmod_ll(i64 noundef %0, i32 noundef %1, i64 noundef %2) #0 !dbg !54 {
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i32, align 4
  %7 = alloca i64, align 8
  %8 = alloca i32, align 4
  %9 = alloca i64, align 8
  %10 = alloca i32, align 4
  store i64 %0, ptr %5, align 8
    #dbg_declare(ptr %5, !58, !DIExpression(), !59)
  store i32 %1, ptr %6, align 4
    #dbg_declare(ptr %6, !60, !DIExpression(), !61)
  store i64 %2, ptr %7, align 8
    #dbg_declare(ptr %7, !62, !DIExpression(), !63)
    #dbg_declare(ptr %8, !64, !DIExpression(), !65)
    #dbg_declare(ptr %9, !66, !DIExpression(), !67)
    #dbg_declare(ptr %10, !68, !DIExpression(), !70)
  %11 = load i32, ptr %6, align 4, !dbg !71
  %12 = icmp eq i32 %11, 0, !dbg !73
  br i1 %12, label %13, label %14, !dbg !73

13:
  store i64 1, ptr %4, align 8, !dbg !74
  br label %55, !dbg !74

14:
  %15 = load i32, ptr %6, align 4, !dbg !75
  store i32 %15, ptr %8, align 4, !dbg !76
  store i32 0, ptr %10, align 4, !dbg !77
  br label %16, !dbg !79

16:
  %17 = load i32, ptr %8, align 4, !dbg !80
  %18 = icmp ne i32 %17, 0, !dbg !82
  br i1 %18, label %19, label %25, !dbg !83

19:
  %20 = load i32, ptr %8, align 4, !dbg !84
  %21 = lshr i32 %20, 1, !dbg !84
  store i32 %21, ptr %8, align 4, !dbg !84
  br label %22, !dbg !85

22:
  %23 = load i32, ptr %10, align 4, !dbg !86
  %24 = add nsw i32 %23, 1, !dbg !86
  store i32 %24, ptr %10, align 4, !dbg !86
  br label %16, !dbg !87, !llvm.loop !88

25:
  %26 = load i64, ptr %5, align 8, !dbg !91
  store i64 %26, ptr %9, align 8, !dbg !92
  %27 = load i32, ptr %10, align 4, !dbg !93
  %28 = sub nsw i32 %27, 2, !dbg !93
  store i32 %28, ptr %10, align 4, !dbg !93
  br label %29, !dbg !94

29:
  %30 = load i32, ptr %10, align 4, !dbg !95
  %31 = icmp sge i32 %30, 0, !dbg !98
  br i1 %31, label %32, label %53, !dbg !99

32:
  %33 = load i64, ptr %9, align 8, !dbg !100
  %34 = load i64, ptr %9, align 8, !dbg !102
  %35 = mul i64 %33, %34, !dbg !103
  %36 = load i64, ptr %7, align 8, !dbg !104
  %37 = urem i64 %35, %36, !dbg !105
  store i64 %37, ptr %9, align 8, !dbg !106
  %38 = load i32, ptr %10, align 4, !dbg !107
  %39 = shl i32 1, %38, !dbg !109
  %40 = load i32, ptr %6, align 4, !dbg !110
  %41 = and i32 %39, %40, !dbg !111
  %42 = icmp ne i32 %41, 0, !dbg !111
  br i1 %42, label %43, label %49, !dbg !111

43:
  %44 = load i64, ptr %9, align 8, !dbg !112
  %45 = load i64, ptr %5, align 8, !dbg !113
  %46 = mul i64 %44, %45, !dbg !114
  %47 = load i64, ptr %7, align 8, !dbg !115
  %48 = urem i64 %46, %47, !dbg !116
  store i64 %48, ptr %9, align 8, !dbg !117
  br label %49, !dbg !118

49:
  br label %50, !dbg !119

50:
  %51 = load i32, ptr %10, align 4, !dbg !120
  %52 = add nsw i32 %51, -1, !dbg !120
  store i32 %52, ptr %10, align 4, !dbg !120
  br label %29, !dbg !121, !llvm.loop !122

53:
  %54 = load i64, ptr %9, align 8, !dbg !124
  store i64 %54, ptr %4, align 8, !dbg !125
  br label %55, !dbg !125

55:
  %56 = load i64, ptr %4, align 8, !dbg !126
  ret i64 %56, !dbg !126
}

define dso_local void @facts(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) #0 !dbg !127 {
  %5 = alloca i64, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca ptr, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i32, align 4
  %17 = alloca i64, align 8
  %18 = alloca i32, align 4
  store i64 %0, ptr %5, align 8
    #dbg_declare(ptr %5, !130, !DIExpression(), !131)
  store i32 %1, ptr %6, align 4
    #dbg_declare(ptr %6, !132, !DIExpression(), !133)
  store i32 %2, ptr %7, align 4
    #dbg_declare(ptr %7, !134, !DIExpression(), !135)
  store i32 %3, ptr %8, align 4
    #dbg_declare(ptr %8, !136, !DIExpression(), !137)
    #dbg_declare(ptr %9, !138, !DIExpression(), !140)
  store ptr @factab, ptr %9, align 8, !dbg !140
    #dbg_declare(ptr %10, !141, !DIExpression(), !142)
    #dbg_declare(ptr %11, !143, !DIExpression(), !144)
    #dbg_declare(ptr %12, !145, !DIExpression(), !146)
  store i64 1, ptr %12, align 8, !dbg !146
    #dbg_declare(ptr %13, !147, !DIExpression(), !148)
  %19 = load i32, ptr %6, align 4, !dbg !149
  %20 = sext i32 %19 to i64, !dbg !149
  store i64 %20, ptr %13, align 8, !dbg !148
    #dbg_declare(ptr %14, !150, !DIExpression(), !151)
    #dbg_declare(ptr %15, !152, !DIExpression(), !153)
    #dbg_declare(ptr %16, !154, !DIExpression(), !155)
  store i32 1, ptr %16, align 4, !dbg !155
    #dbg_declare(ptr %17, !156, !DIExpression(), !157)
    #dbg_declare(ptr %18, !158, !DIExpression(), !159)
  store i32 0, ptr %18, align 4, !dbg !159
  %21 = load i32, ptr %7, align 4, !dbg !160
  %22 = sext i32 %21 to i64, !dbg !160
  store i64 %22, ptr %10, align 8, !dbg !161
  %23 = load i32, ptr %7, align 4, !dbg !162
  %24 = sext i32 %23 to i64, !dbg !162
  store i64 %24, ptr %11, align 8, !dbg !163
  store i32 1, ptr %14, align 4, !dbg !164
  br label %25, !dbg !166

25:
  %26 = load i32, ptr %14, align 4, !dbg !167
  %27 = icmp slt i32 %26, 10000, !dbg !169
  br i1 %27, label %28, label %94, !dbg !170

28:
  %29 = load i64, ptr %10, align 8, !dbg !171
  %30 = load i32, ptr %8, align 4, !dbg !173
  %31 = load i64, ptr %5, align 8, !dbg !174
  %32 = call i64 @powmod_ll(i64 noundef %29, i32 noundef %30, i64 noundef %31), !dbg !175
  %33 = load i64, ptr %13, align 8, !dbg !176
  %34 = add i64 %32, %33, !dbg !177
  store i64 %34, ptr %10, align 8, !dbg !178
  %35 = load i64, ptr %11, align 8, !dbg !179
  %36 = load i32, ptr %8, align 4, !dbg !180
  %37 = load i64, ptr %5, align 8, !dbg !181
  %38 = call i64 @powmod_ll(i64 noundef %35, i32 noundef %36, i64 noundef %37), !dbg !182
  %39 = load i64, ptr %13, align 8, !dbg !183
  %40 = add i64 %38, %39, !dbg !184
  store i64 %40, ptr %11, align 8, !dbg !185
  %41 = load i64, ptr %11, align 8, !dbg !186
  %42 = load i32, ptr %8, align 4, !dbg !187
  %43 = load i64, ptr %5, align 8, !dbg !188
  %44 = call i64 @powmod_ll(i64 noundef %41, i32 noundef %42, i64 noundef %43), !dbg !189
  %45 = load i64, ptr %13, align 8, !dbg !190
  %46 = add i64 %44, %45, !dbg !191
  store i64 %46, ptr %11, align 8, !dbg !192
  %47 = load i64, ptr %10, align 8, !dbg !193
  %48 = load i64, ptr %11, align 8, !dbg !195
  %49 = icmp ugt i64 %47, %48, !dbg !196
  br i1 %49, label %50, label %54, !dbg !196

50:
  %51 = load i64, ptr %10, align 8, !dbg !197
  %52 = load i64, ptr %11, align 8, !dbg !198
  %53 = sub i64 %51, %52, !dbg !199
  store i64 %53, ptr %17, align 8, !dbg !200
  br label %58, !dbg !201

54:
  %55 = load i64, ptr %11, align 8, !dbg !202
  %56 = load i64, ptr %10, align 8, !dbg !203
  %57 = sub i64 %55, %56, !dbg !204
  store i64 %57, ptr %17, align 8, !dbg !205
  br label %58

58:
  %59 = load i64, ptr %12, align 8, !dbg !206
  %60 = load i64, ptr %17, align 8, !dbg !207
  %61 = mul i64 %59, %60, !dbg !208
  %62 = load i64, ptr %5, align 8, !dbg !209
  %63 = urem i64 %61, %62, !dbg !210
  store i64 %63, ptr %12, align 8, !dbg !211
  %64 = load i32, ptr %14, align 4, !dbg !212
  %65 = load i32, ptr %16, align 4, !dbg !214
  %66 = icmp eq i32 %64, %65, !dbg !215
  br i1 %66, label %67, label %90, !dbg !215

67:
  %68 = load i32, ptr %18, align 4, !dbg !216
  %69 = add nsw i32 %68, 1, !dbg !216
  store i32 %69, ptr %18, align 4, !dbg !216
  %70 = load i32, ptr %18, align 4, !dbg !218
  %71 = load i32, ptr %16, align 4, !dbg !219
  %72 = add nsw i32 %71, %70, !dbg !219
  store i32 %72, ptr %16, align 4, !dbg !219
  %73 = load i64, ptr %12, align 8, !dbg !220
  %74 = load i64, ptr %5, align 8, !dbg !221
  %75 = call i64 @gcd_ll(i64 noundef %73, i64 noundef %74), !dbg !222
  store i64 %75, ptr %15, align 8, !dbg !223
  %76 = load i64, ptr %15, align 8, !dbg !224
  %77 = icmp ne i64 %76, 1, !dbg !226
  br i1 %77, label %78, label %89, !dbg !226

78:
  %79 = load i64, ptr %15, align 8, !dbg !227
  %80 = load ptr, ptr %9, align 8, !dbg !229
  %81 = getelementptr inbounds nuw i64, ptr %80, i32 1, !dbg !229
  store ptr %81, ptr %9, align 8, !dbg !229
  store i64 %79, ptr %80, align 8, !dbg !230
  %82 = load i64, ptr %15, align 8, !dbg !231
  %83 = load i64, ptr %5, align 8, !dbg !232
  %84 = udiv i64 %83, %82, !dbg !232
  store i64 %84, ptr %5, align 8, !dbg !232
  %85 = load i64, ptr %5, align 8, !dbg !233
  %86 = icmp eq i64 %85, 1, !dbg !235
  br i1 %86, label %87, label %88, !dbg !235

87:
  br label %94, !dbg !236

88:
  br label %89, !dbg !238

89:
  br label %90, !dbg !239

90:
  br label %91, !dbg !240

91:
  %92 = load i32, ptr %14, align 4, !dbg !241
  %93 = add nsw i32 %92, 1, !dbg !241
  store i32 %93, ptr %14, align 4, !dbg !241
  br label %25, !dbg !242, !llvm.loop !243

94:
  ret void, !dbg !245
}

define dso_local i32 @main() #0 !dbg !246 {
  %1 = alloca i32, align 4
  %2 = alloca i64, align 8
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = load i32, ptr %6, align 4, !dbg !258
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !249, !DIExpression(), !250)
    #dbg_declare(ptr %3, !251, !DIExpression(), !252)
    #dbg_declare(ptr %4, !253, !DIExpression(), !254)
    #dbg_declare(ptr %6, !255, !DIExpression(), !256)
  store i32 27, ptr %6, align 4, !dbg !257
  %7 = zext i32 %5 to i64, !dbg !259
  %8 = shl i64 1, %7, !dbg !259
  %9 = sub i64 %8, 1, !dbg !260
  store i64 %9, ptr %2, align 8, !dbg !261
  store i32 -1, ptr %4, align 4, !dbg !262
  store i32 3, ptr %3, align 4, !dbg !263
  %10 = load i64, ptr %2, align 8, !dbg !264
  %11 = load i32, ptr %4, align 4, !dbg !265
  %12 = load i32, ptr %3, align 4, !dbg !266
  %13 = load i32, ptr %6, align 4, !dbg !267
  call void @facts(i64 noundef %10, i32 noundef %11, i32 noundef %12, i32 noundef %13), !dbg !268
  %14 = load i64, ptr @factab, align 16, !dbg !269
  %15 = icmp ne i64 %14, 7, !dbg !271
  br i1 %15, label %22, label %16, !dbg !272

16:
  %17 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 8), align 8, !dbg !273
  %18 = icmp ne i64 %17, 73, !dbg !274
  br i1 %18, label %22, label %19, !dbg !275

19:
  %20 = load i64, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 16), align 16, !dbg !276
  %21 = icmp ne i64 %20, 262657, !dbg !277
  br i1 %21, label %22, label %23, !dbg !275

22:
  call void @abort() #3, !dbg !278
  unreachable, !dbg !278

23:
  call void @exit(i32 noundef 0) #4, !dbg !279
  unreachable, !dbg !279
}

declare void @abort() #1
declare void @exit(i32 noundef) #2
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!11, !12, !13, !14, !15, !16, !17}
!llvm.ident = !{!18}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "factab", scope: !2, file: !3, line: 48, type: !8, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "920501-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "b7e9d89cc440725f54ffc347e96c79dc")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!7 = !{!0}
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 640, elements: !9)
!9 = !{!10}
!10 = !DISubrange(count: 10)
!11 = !{i32 7, !"Dwarf Version", i32 5}
!12 = !{i32 2, !"Debug Info Version", i32 3}
!13 = !{i32 4, !"probe-stack", !"inline-asm"}
!14 = !{i32 8, !"PIC Level", i32 2}
!15 = !{i32 7, !"PIE Level", i32 2}
!16 = !{i32 7, !"uwtable", i32 2}
!17 = !{i32 7, !"frame-pointer", i32 2}
!18 = !{!"Alpine clang version 23.1.5"}
!19 = distinct !DISubprogram(name: "gcd_ll", scope: !3, file: !3, line: 5, type: !20, scopeLine: 6, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !22)
!20 = !DISubroutineType(types: !21)
!21 = !{!5, !6, !6}
!22 = !{}
!23 = !DILocalVariable(name: "x", arg: 1, scope: !19, file: !3, line: 5, type: !6)
!24 = !DILocation(line: 5, column: 28, scope: !19)
!25 = !DILocalVariable(name: "y", arg: 2, scope: !19, file: !3, line: 5, type: !6)
!26 = !DILocation(line: 5, column: 50, scope: !19)
!27 = !DILocation(line: 7, column: 3, scope: !19)
!28 = !DILocation(line: 9, column: 11, scope: !29)
!29 = distinct !DILexicalBlock(scope: !30, file: !3, line: 9, column: 11)
!30 = distinct !DILexicalBlock(scope: !31, file: !3, line: 8, column: 5)
!31 = distinct !DILexicalBlock(scope: !32, file: !3, line: 7, column: 3)
!32 = distinct !DILexicalBlock(scope: !19, file: !3, line: 7, column: 3)
!33 = !DILocation(line: 9, column: 13, scope: !29)
!34 = !DILocation(line: 10, column: 25, scope: !29)
!35 = !DILocation(line: 10, column: 2, scope: !29)
!36 = !DILocation(line: 11, column: 11, scope: !30)
!37 = !DILocation(line: 11, column: 15, scope: !30)
!38 = !DILocation(line: 11, column: 13, scope: !30)
!39 = !DILocation(line: 11, column: 9, scope: !30)
!40 = !DILocation(line: 12, column: 11, scope: !41)
!41 = distinct !DILexicalBlock(scope: !30, file: !3, line: 12, column: 11)
!42 = !DILocation(line: 12, column: 13, scope: !41)
!43 = !DILocation(line: 13, column: 25, scope: !41)
!44 = !DILocation(line: 13, column: 2, scope: !41)
!45 = !DILocation(line: 14, column: 11, scope: !30)
!46 = !DILocation(line: 14, column: 15, scope: !30)
!47 = !DILocation(line: 14, column: 13, scope: !30)
!48 = !DILocation(line: 14, column: 9, scope: !30)
!49 = !DILocation(line: 7, column: 3, scope: !31)
!50 = distinct !{!50, !51, !52}
!51 = !DILocation(line: 7, column: 3, scope: !32)
!52 = !DILocation(line: 15, column: 5, scope: !32)
!53 = !DILocation(line: 16, column: 1, scope: !19)
!54 = distinct !DISubprogram(name: "powmod_ll", scope: !3, file: !3, line: 19, type: !55, scopeLine: 20, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !22)
!55 = !DISubroutineType(types: !56)
!56 = !{!6, !6, !57, !6}
!57 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!58 = !DILocalVariable(name: "b", arg: 1, scope: !54, file: !3, line: 19, type: !6)
!59 = !DILocation(line: 19, column: 31, scope: !54)
!60 = !DILocalVariable(name: "e", arg: 2, scope: !54, file: !3, line: 19, type: !57)
!61 = !DILocation(line: 19, column: 43, scope: !54)
!62 = !DILocalVariable(name: "m", arg: 3, scope: !54, file: !3, line: 19, type: !6)
!63 = !DILocation(line: 19, column: 65, scope: !54)
!64 = !DILocalVariable(name: "t", scope: !54, file: !3, line: 21, type: !57)
!65 = !DILocation(line: 21, column: 12, scope: !54)
!66 = !DILocalVariable(name: "pow", scope: !54, file: !3, line: 22, type: !6)
!67 = !DILocation(line: 22, column: 22, scope: !54)
!68 = !DILocalVariable(name: "i", scope: !54, file: !3, line: 23, type: !69)
!69 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!70 = !DILocation(line: 23, column: 7, scope: !54)
!71 = !DILocation(line: 25, column: 7, scope: !72)
!72 = distinct !DILexicalBlock(scope: !54, file: !3, line: 25, column: 7)
!73 = !DILocation(line: 25, column: 9, scope: !72)
!74 = !DILocation(line: 26, column: 5, scope: !72)
!75 = !DILocation(line: 29, column: 7, scope: !54)
!76 = !DILocation(line: 29, column: 5, scope: !54)
!77 = !DILocation(line: 30, column: 10, scope: !78)
!78 = distinct !DILexicalBlock(scope: !54, file: !3, line: 30, column: 3)
!79 = !DILocation(line: 30, column: 8, scope: !78)
!80 = !DILocation(line: 30, column: 15, scope: !81)
!81 = distinct !DILexicalBlock(scope: !78, file: !3, line: 30, column: 3)
!82 = !DILocation(line: 30, column: 17, scope: !81)
!83 = !DILocation(line: 30, column: 3, scope: !78)
!84 = !DILocation(line: 31, column: 7, scope: !81)
!85 = !DILocation(line: 31, column: 5, scope: !81)
!86 = !DILocation(line: 30, column: 24, scope: !81)
!87 = !DILocation(line: 30, column: 3, scope: !81)
!88 = distinct !{!88, !83, !89, !90}
!89 = !DILocation(line: 31, column: 11, scope: !78)
!90 = !{!"llvm.loop.mustprogress"}
!91 = !DILocation(line: 35, column: 9, scope: !54)
!92 = !DILocation(line: 35, column: 7, scope: !54)
!93 = !DILocation(line: 36, column: 5, scope: !54)
!94 = !DILocation(line: 38, column: 3, scope: !54)
!95 = !DILocation(line: 38, column: 10, scope: !96)
!96 = distinct !DILexicalBlock(scope: !97, file: !3, line: 38, column: 3)
!97 = distinct !DILexicalBlock(scope: !54, file: !3, line: 38, column: 3)
!98 = !DILocation(line: 38, column: 12, scope: !96)
!99 = !DILocation(line: 38, column: 3, scope: !97)
!100 = !DILocation(line: 40, column: 13, scope: !101)
!101 = distinct !DILexicalBlock(scope: !96, file: !3, line: 39, column: 5)
!102 = !DILocation(line: 40, column: 19, scope: !101)
!103 = !DILocation(line: 40, column: 17, scope: !101)
!104 = !DILocation(line: 40, column: 25, scope: !101)
!105 = !DILocation(line: 40, column: 23, scope: !101)
!106 = !DILocation(line: 40, column: 11, scope: !101)
!107 = !DILocation(line: 41, column: 17, scope: !108)
!108 = distinct !DILexicalBlock(scope: !101, file: !3, line: 41, column: 11)
!109 = !DILocation(line: 41, column: 14, scope: !108)
!110 = !DILocation(line: 41, column: 22, scope: !108)
!111 = !DILocation(line: 41, column: 20, scope: !108)
!112 = !DILocation(line: 42, column: 8, scope: !108)
!113 = !DILocation(line: 42, column: 14, scope: !108)
!114 = !DILocation(line: 42, column: 12, scope: !108)
!115 = !DILocation(line: 42, column: 18, scope: !108)
!116 = !DILocation(line: 42, column: 16, scope: !108)
!117 = !DILocation(line: 42, column: 6, scope: !108)
!118 = !DILocation(line: 42, column: 2, scope: !108)
!119 = !DILocation(line: 43, column: 5, scope: !101)
!120 = !DILocation(line: 38, column: 19, scope: !96)
!121 = !DILocation(line: 38, column: 3, scope: !96)
!122 = distinct !{!122, !99, !123, !90}
!123 = !DILocation(line: 43, column: 5, scope: !97)
!124 = !DILocation(line: 45, column: 10, scope: !54)
!125 = !DILocation(line: 45, column: 3, scope: !54)
!126 = !DILocation(line: 46, column: 1, scope: !54)
!127 = distinct !DISubprogram(name: "facts", scope: !3, file: !3, line: 51, type: !128, scopeLine: 56, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !22)
!128 = !DISubroutineType(types: !129)
!129 = !{null, !6, !69, !69, !57}
!130 = !DILocalVariable(name: "t", arg: 1, scope: !127, file: !3, line: 52, type: !6)
!131 = !DILocation(line: 52, column: 25, scope: !127)
!132 = !DILocalVariable(name: "a_int", arg: 2, scope: !127, file: !3, line: 53, type: !69)
!133 = !DILocation(line: 53, column: 10, scope: !127)
!134 = !DILocalVariable(name: "x0", arg: 3, scope: !127, file: !3, line: 54, type: !69)
!135 = !DILocation(line: 54, column: 10, scope: !127)
!136 = !DILocalVariable(name: "p", arg: 4, scope: !127, file: !3, line: 55, type: !57)
!137 = !DILocation(line: 55, column: 15, scope: !127)
!138 = !DILocalVariable(name: "xp", scope: !127, file: !3, line: 57, type: !139)
!139 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!140 = !DILocation(line: 57, column: 18, scope: !127)
!141 = !DILocalVariable(name: "x", scope: !127, file: !3, line: 58, type: !6)
!142 = !DILocation(line: 58, column: 22, scope: !127)
!143 = !DILocalVariable(name: "y", scope: !127, file: !3, line: 58, type: !6)
!144 = !DILocation(line: 58, column: 25, scope: !127)
!145 = !DILocalVariable(name: "q", scope: !127, file: !3, line: 59, type: !5)
!146 = !DILocation(line: 59, column: 17, scope: !127)
!147 = !DILocalVariable(name: "a", scope: !127, file: !3, line: 60, type: !6)
!148 = !DILocation(line: 60, column: 22, scope: !127)
!149 = !DILocation(line: 60, column: 26, scope: !127)
!150 = !DILocalVariable(name: "i", scope: !127, file: !3, line: 61, type: !69)
!151 = !DILocation(line: 61, column: 7, scope: !127)
!152 = !DILocalVariable(name: "d", scope: !127, file: !3, line: 62, type: !5)
!153 = !DILocation(line: 62, column: 17, scope: !127)
!154 = !DILocalVariable(name: "j", scope: !127, file: !3, line: 63, type: !69)
!155 = !DILocation(line: 63, column: 7, scope: !127)
!156 = !DILocalVariable(name: "tmp", scope: !127, file: !3, line: 64, type: !5)
!157 = !DILocation(line: 64, column: 17, scope: !127)
!158 = !DILocalVariable(name: "jj", scope: !127, file: !3, line: 65, type: !69)
!159 = !DILocation(line: 65, column: 7, scope: !127)
!160 = !DILocation(line: 67, column: 7, scope: !127)
!161 = !DILocation(line: 67, column: 5, scope: !127)
!162 = !DILocation(line: 68, column: 7, scope: !127)
!163 = !DILocation(line: 68, column: 5, scope: !127)
!164 = !DILocation(line: 70, column: 10, scope: !165)
!165 = distinct !DILexicalBlock(scope: !127, file: !3, line: 70, column: 3)
!166 = !DILocation(line: 70, column: 8, scope: !165)
!167 = !DILocation(line: 70, column: 15, scope: !168)
!168 = distinct !DILexicalBlock(scope: !165, file: !3, line: 70, column: 3)
!169 = !DILocation(line: 70, column: 17, scope: !168)
!170 = !DILocation(line: 70, column: 3, scope: !165)
!171 = !DILocation(line: 72, column: 22, scope: !172)
!172 = distinct !DILexicalBlock(scope: !168, file: !3, line: 71, column: 5)
!173 = !DILocation(line: 72, column: 25, scope: !172)
!174 = !DILocation(line: 72, column: 28, scope: !172)
!175 = !DILocation(line: 72, column: 11, scope: !172)
!176 = !DILocation(line: 72, column: 33, scope: !172)
!177 = !DILocation(line: 72, column: 31, scope: !172)
!178 = !DILocation(line: 72, column: 9, scope: !172)
!179 = !DILocation(line: 73, column: 22, scope: !172)
!180 = !DILocation(line: 73, column: 25, scope: !172)
!181 = !DILocation(line: 73, column: 28, scope: !172)
!182 = !DILocation(line: 73, column: 11, scope: !172)
!183 = !DILocation(line: 73, column: 33, scope: !172)
!184 = !DILocation(line: 73, column: 31, scope: !172)
!185 = !DILocation(line: 73, column: 9, scope: !172)
!186 = !DILocation(line: 74, column: 22, scope: !172)
!187 = !DILocation(line: 74, column: 25, scope: !172)
!188 = !DILocation(line: 74, column: 28, scope: !172)
!189 = !DILocation(line: 74, column: 11, scope: !172)
!190 = !DILocation(line: 74, column: 33, scope: !172)
!191 = !DILocation(line: 74, column: 31, scope: !172)
!192 = !DILocation(line: 74, column: 9, scope: !172)
!193 = !DILocation(line: 76, column: 11, scope: !194)
!194 = distinct !DILexicalBlock(scope: !172, file: !3, line: 76, column: 11)
!195 = !DILocation(line: 76, column: 15, scope: !194)
!196 = !DILocation(line: 76, column: 13, scope: !194)
!197 = !DILocation(line: 77, column: 8, scope: !194)
!198 = !DILocation(line: 77, column: 12, scope: !194)
!199 = !DILocation(line: 77, column: 10, scope: !194)
!200 = !DILocation(line: 77, column: 6, scope: !194)
!201 = !DILocation(line: 77, column: 2, scope: !194)
!202 = !DILocation(line: 79, column: 8, scope: !194)
!203 = !DILocation(line: 79, column: 12, scope: !194)
!204 = !DILocation(line: 79, column: 10, scope: !194)
!205 = !DILocation(line: 79, column: 6, scope: !194)
!206 = !DILocation(line: 80, column: 32, scope: !172)
!207 = !DILocation(line: 80, column: 36, scope: !172)
!208 = !DILocation(line: 80, column: 34, scope: !172)
!209 = !DILocation(line: 80, column: 42, scope: !172)
!210 = !DILocation(line: 80, column: 40, scope: !172)
!211 = !DILocation(line: 80, column: 9, scope: !172)
!212 = !DILocation(line: 82, column: 11, scope: !213)
!213 = distinct !DILexicalBlock(scope: !172, file: !3, line: 82, column: 11)
!214 = !DILocation(line: 82, column: 16, scope: !213)
!215 = !DILocation(line: 82, column: 13, scope: !213)
!216 = !DILocation(line: 84, column: 7, scope: !217)
!217 = distinct !DILexicalBlock(scope: !213, file: !3, line: 83, column: 2)
!218 = !DILocation(line: 85, column: 9, scope: !217)
!219 = !DILocation(line: 85, column: 6, scope: !217)
!220 = !DILocation(line: 86, column: 16, scope: !217)
!221 = !DILocation(line: 86, column: 19, scope: !217)
!222 = !DILocation(line: 86, column: 8, scope: !217)
!223 = !DILocation(line: 86, column: 6, scope: !217)
!224 = !DILocation(line: 87, column: 8, scope: !225)
!225 = distinct !DILexicalBlock(scope: !217, file: !3, line: 87, column: 8)
!226 = !DILocation(line: 87, column: 10, scope: !225)
!227 = !DILocation(line: 89, column: 16, scope: !228)
!228 = distinct !DILexicalBlock(scope: !225, file: !3, line: 88, column: 6)
!229 = !DILocation(line: 89, column: 11, scope: !228)
!230 = !DILocation(line: 89, column: 14, scope: !228)
!231 = !DILocation(line: 90, column: 13, scope: !228)
!232 = !DILocation(line: 90, column: 10, scope: !228)
!233 = !DILocation(line: 91, column: 12, scope: !234)
!234 = distinct !DILexicalBlock(scope: !228, file: !3, line: 91, column: 12)
!235 = !DILocation(line: 91, column: 14, scope: !234)
!236 = !DILocation(line: 93, column: 5, scope: !237)
!237 = distinct !DILexicalBlock(scope: !234, file: !3, line: 92, column: 3)
!238 = !DILocation(line: 96, column: 6, scope: !228)
!239 = !DILocation(line: 97, column: 2, scope: !217)
!240 = !DILocation(line: 98, column: 5, scope: !172)
!241 = !DILocation(line: 70, column: 27, scope: !168)
!242 = !DILocation(line: 70, column: 3, scope: !168)
!243 = distinct !{!243, !170, !244, !90}
!244 = !DILocation(line: 98, column: 5, scope: !165)
!245 = !DILocation(line: 99, column: 1, scope: !127)
!246 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 102, type: !247, scopeLine: 103, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !22)
!247 = !DISubroutineType(types: !248)
!248 = !{!69}
!249 = !DILocalVariable(name: "t", scope: !246, file: !3, line: 104, type: !6)
!250 = !DILocation(line: 104, column: 22, scope: !246)
!251 = !DILocalVariable(name: "x0", scope: !246, file: !3, line: 105, type: !57)
!252 = !DILocation(line: 105, column: 12, scope: !246)
!253 = !DILocalVariable(name: "a", scope: !246, file: !3, line: 105, type: !57)
!254 = !DILocation(line: 105, column: 16, scope: !246)
!255 = !DILocalVariable(name: "p", scope: !246, file: !3, line: 106, type: !57)
!256 = !DILocation(line: 106, column: 12, scope: !246)
!257 = !DILocation(line: 108, column: 5, scope: !246)
!258 = !DILocation(line: 109, column: 16, scope: !246)
!259 = !DILocation(line: 109, column: 13, scope: !246)
!260 = !DILocation(line: 109, column: 19, scope: !246)
!261 = !DILocation(line: 109, column: 5, scope: !246)
!262 = !DILocation(line: 111, column: 5, scope: !246)
!263 = !DILocation(line: 112, column: 6, scope: !246)
!264 = !DILocation(line: 114, column: 10, scope: !246)
!265 = !DILocation(line: 114, column: 13, scope: !246)
!266 = !DILocation(line: 114, column: 16, scope: !246)
!267 = !DILocation(line: 114, column: 20, scope: !246)
!268 = !DILocation(line: 114, column: 3, scope: !246)
!269 = !DILocation(line: 115, column: 7, scope: !270)
!270 = distinct !DILexicalBlock(scope: !246, file: !3, line: 115, column: 7)
!271 = !DILocation(line: 115, column: 17, scope: !270)
!272 = !DILocation(line: 115, column: 22, scope: !270)
!273 = !DILocation(line: 115, column: 25, scope: !270)
!274 = !DILocation(line: 115, column: 35, scope: !270)
!275 = !DILocation(line: 115, column: 41, scope: !270)
!276 = !DILocation(line: 115, column: 44, scope: !270)
!277 = !DILocation(line: 115, column: 54, scope: !270)
!278 = !DILocation(line: 116, column: 5, scope: !270)
!279 = !DILocation(line: 117, column: 3, scope: !246)
