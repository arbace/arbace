; MUTANT: attr-returned invalid Verifier: Incompatible argument and return types for 'returned' attribute
source_filename = "20050224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@a = dso_local local_unnamed_addr global i64 3221225472, align 8, !dbg !0
@b = dso_local local_unnamed_addr global i64 3489660928, align 8, !dbg !5
@c = dso_local local_unnamed_addr global i64 3223042392, align 8, !dbg !8
@d = dso_local local_unnamed_addr global i64 3223732224, align 8, !dbg !10
@e = dso_local local_unnamed_addr global i64 3223879680, align 8, !dbg !12
@f = dso_local local_unnamed_addr global i64 3224191864, align 8, !dbg !14
define dso_local void @foo(i32 noundef %0, i32 returned noundef %1, i32 noundef %2) local_unnamed_addr #0 !dbg !24 {
    #dbg_value(i32 %0, !29, !DIExpression(), !32)
    #dbg_value(i32 %1, !30, !DIExpression(), !32)
    #dbg_value(i32 %2, !31, !DIExpression(), !32)
  %4 = icmp ne i32 %0, 245, !dbg !33
  %5 = icmp ne i32 %1, 36
  %6 = or i1 %4, %5, !dbg !35
  %7 = icmp ne i32 %2, 444
  %8 = or i1 %6, %7, !dbg !35
  br i1 %8, label %9, label %10, !dbg !35

9:
  tail call void @abort() #2, !dbg !36
  unreachable, !dbg !36

10:
  ret void, !dbg !37
}

declare void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #0 !dbg !38 {
    #dbg_value(i32 0, !43, !DIExpression(), !46)
    #dbg_value(i32 0, !44, !DIExpression(), !46)
    #dbg_value(i32 0, !45, !DIExpression(), !46)
  %1 = load i64, ptr @a, align 8, !dbg !47
    #dbg_value(i64 %1, !42, !DIExpression(), !46)
  %2 = load i64, ptr @b, align 8
  %3 = icmp ult i64 %1, %2, !dbg !49
  br i1 %3, label %4, label %39, !dbg !51

4:
  %5 = load i64, ptr @c, align 8
  %6 = load i64, ptr @d, align 8
  %7 = load i64, ptr @e, align 8
  %8 = load i64, ptr @f, align 8
  br label %9, !dbg !51

9:
  %10 = phi i32 [ 0, %4 ], [ %30, %27 ]
  %11 = phi i32 [ 0, %4 ], [ %29, %27 ]
  %12 = phi i32 [ 0, %4 ], [ %28, %27 ]
  %13 = phi i64 [ %1, %4 ], [ %31, %27 ]
    #dbg_value(i32 %10, !45, !DIExpression(), !46)
    #dbg_value(i32 %11, !44, !DIExpression(), !46)
    #dbg_value(i32 %12, !43, !DIExpression(), !46)
    #dbg_value(i64 %13, !42, !DIExpression(), !46)
  %14 = icmp ult i64 %13, %5, !dbg !52
  br i1 %14, label %15, label %17, !dbg !54

15:
  %16 = add nsw i32 %12, 1, !dbg !55
    #dbg_value(i32 %16, !43, !DIExpression(), !46)
  br label %27, !dbg !56

17:
  %18 = icmp uge i64 %13, %6, !dbg !57
  %19 = icmp ult i64 %13, %7
  %20 = select i1 %18, i1 %19, i1 false, !dbg !59
  br i1 %20, label %21, label %23, !dbg !59

21:
  %22 = add nsw i32 %10, 1, !dbg !60
    #dbg_value(i32 %22, !45, !DIExpression(), !46)
  br label %27, !dbg !61

23:
  %24 = icmp ult i64 %13, %8, !dbg !62
  %25 = zext i1 %24 to i32, !dbg !64
  %26 = add nsw i32 %11, %25, !dbg !64
  br label %27, !dbg !64

27:
  %28 = phi i32 [ %16, %15 ], [ %12, %21 ], [ %12, %23 ], !dbg !46
  %29 = phi i32 [ %11, %15 ], [ %11, %21 ], [ %26, %23 ], !dbg !46
  %30 = phi i32 [ %10, %15 ], [ %22, %21 ], [ %10, %23 ], !dbg !46
    #dbg_value(i32 %30, !45, !DIExpression(), !46)
    #dbg_value(i32 %29, !44, !DIExpression(), !46)
    #dbg_value(i32 %28, !43, !DIExpression(), !46)
  %31 = add i64 %13, 4096, !dbg !65
    #dbg_value(i64 %31, !42, !DIExpression(), !46)
  %32 = icmp ult i64 %31, %2, !dbg !66
  br i1 %32, label %9, label %33, !dbg !67, !llvm.loop !68

33:
  %34 = icmp ne i32 %29, 245, !dbg !72
  %35 = icmp ne i32 %30, 36
  %36 = or i1 %34, %35, !dbg !72
  %37 = icmp ne i32 %28, 444
  %38 = or i1 %37, %36, !dbg !72
    #dbg_value(i1 poison, !29, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_signed, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_stack_value), !74)
    #dbg_value(i1 poison, !30, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_signed, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_stack_value), !74)
    #dbg_value(i1 poison, !31, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_signed, DW_OP_LLVM_convert, 32, DW_ATE_signed, DW_OP_stack_value), !74)
  br i1 %38, label %39, label %40, !dbg !75

39:
  tail call void @abort() #2, !dbg !76
  unreachable, !dbg !76

40:
  ret i32 0, !dbg !77
}

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!16, !17, !18, !19, !20, !21, !22}
!llvm.ident = !{!23}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "a", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20050224-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "6c8199c0ffd341030bef718b580100e9")
!4 = !{!0, !5, !8, !10, !12, !14}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "b", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!7 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "c", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!10 = !DIGlobalVariableExpression(var: !11, expr: !DIExpression())
!11 = distinct !DIGlobalVariable(name: "d", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(name: "e", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!14 = !DIGlobalVariableExpression(var: !15, expr: !DIExpression())
!15 = distinct !DIGlobalVariable(name: "f", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!16 = !{i32 7, !"Dwarf Version", i32 5}
!17 = !{i32 2, !"Debug Info Version", i32 3}
!18 = !{i32 4, !"probe-stack", !"inline-asm"}
!19 = !{i32 8, !"PIC Level", i32 2}
!20 = !{i32 7, !"PIE Level", i32 2}
!21 = !{i32 7, !"uwtable", i32 2}
!22 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!23 = !{!"Alpine clang version 23.1.5"}
!24 = distinct !DISubprogram(name: "foo", scope: !3, file: !3, line: 9, type: !25, scopeLine: 10, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !28, keyInstructions: true)
!25 = !DISubroutineType(types: !26)
!26 = !{null, !27, !27, !27}
!27 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!28 = !{!29, !30, !31}
!29 = !DILocalVariable(name: "x", arg: 1, scope: !24, file: !3, line: 9, type: !27)
!30 = !DILocalVariable(name: "y", arg: 2, scope: !24, file: !3, line: 9, type: !27)
!31 = !DILocalVariable(name: "z", arg: 3, scope: !24, file: !3, line: 9, type: !27)
!32 = !DILocation(line: 0, scope: !24)
!33 = !DILocation(line: 11, column: 9, scope: !34, atomGroup: 1, atomRank: 2)
!34 = distinct !DILexicalBlock(scope: !24, file: !3, line: 11, column: 7)
!35 = !DILocation(line: 11, column: 16, scope: !34, atomGroup: 1, atomRank: 1)
!36 = !DILocation(line: 12, column: 5, scope: !34)
!37 = !DILocation(line: 13, column: 1, scope: !24, atomGroup: 4, atomRank: 1)
!38 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 16, type: !39, scopeLine: 17, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !41, keyInstructions: true)
!39 = !DISubroutineType(types: !40)
!40 = !{!27}
!41 = !{!42, !43, !44, !45}
!42 = !DILocalVariable(name: "g", scope: !38, file: !3, line: 18, type: !7)
!43 = !DILocalVariable(name: "h", scope: !38, file: !3, line: 19, type: !27)
!44 = !DILocalVariable(name: "i", scope: !38, file: !3, line: 19, type: !27)
!45 = !DILocalVariable(name: "j", scope: !38, file: !3, line: 19, type: !27)
!46 = !DILocation(line: 0, scope: !38)
!47 = !DILocation(line: 24, column: 12, scope: !48, atomGroup: 4, atomRank: 2)
!48 = distinct !DILexicalBlock(scope: !38, file: !3, line: 24, column: 3)
!49 = !DILocation(line: 24, column: 17, scope: !50, atomGroup: 18, atomRank: 1)
!50 = distinct !DILexicalBlock(scope: !48, file: !3, line: 24, column: 3)
!51 = !DILocation(line: 24, column: 3, scope: !48, atomGroup: 19, atomRank: 1)
!52 = !DILocation(line: 25, column: 11, scope: !53, atomGroup: 7, atomRank: 2)
!53 = distinct !DILexicalBlock(scope: !50, file: !3, line: 25, column: 9)
!54 = !DILocation(line: 25, column: 11, scope: !53, atomGroup: 7, atomRank: 1)
!55 = !DILocation(line: 26, column: 8, scope: !53, atomGroup: 8, atomRank: 2)
!56 = !DILocation(line: 26, column: 7, scope: !53)
!57 = !DILocation(line: 27, column: 16, scope: !58, atomGroup: 9, atomRank: 2)
!58 = distinct !DILexicalBlock(scope: !53, file: !3, line: 27, column: 14)
!59 = !DILocation(line: 27, column: 21, scope: !58, atomGroup: 9, atomRank: 1)
!60 = !DILocation(line: 28, column: 8, scope: !58, atomGroup: 11, atomRank: 2)
!61 = !DILocation(line: 28, column: 7, scope: !58)
!62 = !DILocation(line: 29, column: 16, scope: !63, atomGroup: 12, atomRank: 2)
!63 = distinct !DILexicalBlock(scope: !58, file: !3, line: 29, column: 14)
!64 = !DILocation(line: 29, column: 16, scope: !63, atomGroup: 12, atomRank: 1)
!65 = !DILocation(line: 24, column: 24, scope: !50, atomGroup: 14, atomRank: 2)
!66 = !DILocation(line: 24, column: 17, scope: !50, atomGroup: 5, atomRank: 1)
!67 = !DILocation(line: 24, column: 3, scope: !48, atomGroup: 6, atomRank: 1)
!68 = distinct !{!68, !69, !70, !71}
!69 = !DILocation(line: 24, column: 3, scope: !48)
!70 = !DILocation(line: 30, column: 8, scope: !48)
!71 = !{!"llvm.loop.mustprogress"}
!72 = !DILocation(line: 11, column: 9, scope: !34, inlinedAt: !73, atomGroup: 1, atomRank: 2)
!73 = distinct !DILocation(line: 31, column: 3, scope: !38)
!74 = !DILocation(line: 0, scope: !24, inlinedAt: !73)
!75 = !DILocation(line: 11, column: 16, scope: !34, inlinedAt: !73, atomGroup: 1, atomRank: 1)
!76 = !DILocation(line: 12, column: 5, scope: !34, inlinedAt: !73)
!77 = !DILocation(line: 32, column: 3, scope: !38, atomGroup: 17, atomRank: 1)
