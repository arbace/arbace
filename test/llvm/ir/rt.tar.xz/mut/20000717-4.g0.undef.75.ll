; MUTANT: undef invalid LLParser: use of undefined value '%nosuch.value'
source_filename = "20000717-4.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.anon = type { i32, [4 x %struct.slot] }
%struct.slot = type { [6 x i32] }
@s = dso_local global %struct.anon zeroinitializer, align 4, !dbg !0
define dso_local i32 @x() #0 !dbg !27 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
    #dbg_declare(ptr %1, !31, !DIExpression(), !32)
  store i32 0, ptr %1, align 4, !dbg !32
    #dbg_declare(ptr %2, !33, !DIExpression(), !34)
  %3 = load i32, ptr %1, align 4, !dbg !35
  %4 = icmp ne i32 %3, 0, !dbg !36
  %5 = xor i1 %4, true, !dbg !36
  %6 = zext i1 %5 to i32, !dbg !36
  %7 = sext i32 %6 to i64, !dbg !37
  %8 = getelementptr inbounds [6 x i32], ptr getelementptr inbounds nuw (i8, ptr @s, i64 4), i64 0, i64 %7, !dbg !37
  %9 = load i32, ptr %8, align 4, !dbg !37
  store i32 %9, ptr %2, align 4, !dbg !34
  %10 = load i32, ptr %2, align 4, !dbg !38
  ret i32 %nosuch.value, !dbg !39
}

define dso_local i32 @main() #0 !dbg !40 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  ret i32 0, !dbg !41
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!19, !20, !21, !22, !23, !24, !25}
!llvm.ident = !{!26}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !3, line: 12, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20000717-4.c", directory: ".", checksumkind: CSK_MD5, checksum: "a832eba401a23e8896dad75d3fa464b3")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 4, size: 800, elements: !6)
!6 = !{!7, !9}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "offset", scope: !5, file: !3, line: 6, baseType: !8, size: 32)
!8 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!9 = !DIDerivedType(tag: DW_TAG_member, name: "slot", scope: !5, file: !3, line: 11, baseType: !10, size: 768, offset: 32)
!10 = !DICompositeType(tag: DW_TAG_array_type, baseType: !11, size: 768, elements: !17)
!11 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "slot", file: !3, line: 7, size: 192, elements: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "field", scope: !11, file: !3, line: 9, baseType: !14, size: 192)
!14 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 192, elements: !15)
!15 = !{!16}
!16 = !DISubrange(count: 6)
!17 = !{!18}
!18 = !DISubrange(count: 4)
!19 = !{i32 7, !"Dwarf Version", i32 5}
!20 = !{i32 2, !"Debug Info Version", i32 3}
!21 = !{i32 4, !"probe-stack", !"inline-asm"}
!22 = !{i32 8, !"PIC Level", i32 2}
!23 = !{i32 7, !"PIE Level", i32 2}
!24 = !{i32 7, !"uwtable", i32 2}
!25 = !{i32 7, !"frame-pointer", i32 2}
!26 = !{!"Alpine clang version 23.1.5"}
!27 = distinct !DISubprogram(name: "x", scope: !3, file: !3, line: 15, type: !28, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !30)
!28 = !DISubroutineType(types: !29)
!29 = !{!8}
!30 = !{}
!31 = !DILocalVariable(name: "toggle", scope: !27, file: !3, line: 17, type: !8)
!32 = !DILocation(line: 17, column: 7, scope: !27)
!33 = !DILocalVariable(name: "r", scope: !27, file: !3, line: 18, type: !8)
!34 = !DILocation(line: 18, column: 7, scope: !27)
!35 = !DILocation(line: 18, column: 28, scope: !27)
!36 = !DILocation(line: 18, column: 27, scope: !27)
!37 = !DILocation(line: 18, column: 11, scope: !27)
!38 = !DILocation(line: 19, column: 10, scope: !27)
!39 = !DILocation(line: 19, column: 3, scope: !27)
!40 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 23, type: !28, scopeLine: 24, spFlags: DISPFlagDefinition, unit: !2)
!41 = !DILocation(line: 25, column: 3, scope: !40)
