; MUTANT: intr-arg valid
source_filename = "20030914-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.s = type { [18 x i32] }
@gs = dso_local global %struct.s zeroinitializer, align 4, !dbg !0
define dso_local i32 @f(ptr noundef byval(%struct.s) align 8 %0, i32 noundef %1, ...) #0 !dbg !20 {
  %3 = alloca i32, align 4
    #dbg_declare(ptr %0, !24, !DIExpression(), !25)
  store i32 %1, ptr %3, align 4
    #dbg_declare(ptr %3, !26, !DIExpression(), !27)
  %4 = load i32, ptr %3, align 4, !dbg !28
  ret i32 %4, !dbg !29
}

define dso_local i32 @main() #0 !dbg !30 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.s, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 undef, ptr align 4 @gs, i64 72, i1 false), !dbg !33
  %3 = call i32 (ptr, i32, ...) @f(ptr noundef byval(%struct.s) align 8 %2, i32 noundef 4660), !dbg !33
  %4 = icmp ne i32 %3, 4660, !dbg !35
  br i1 %4, label %5, label %6, !dbg !35

5:
  call void @abort() #4, !dbg !36
  unreachable, !dbg !36

6:
  call void @exit(i32 noundef 0) #5, !dbg !37
  unreachable, !dbg !37
}

declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1
declare void @abort() #2
declare void @exit(i32 noundef) #3
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!12, !13, !14, !15, !16, !17, !18}
!llvm.ident = !{!19}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "gs", scope: !2, file: !3, line: 16, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20030914-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "459da48339e5ed0882427df53d0786c3")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "s", file: !3, line: 9, size: 576, elements: !6)
!6 = !{!7}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "i", scope: !5, file: !3, line: 9, baseType: !8, size: 576)
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 576, elements: !10)
!9 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!10 = !{!11}
!11 = !DISubrange(count: 18)
!12 = !{i32 7, !"Dwarf Version", i32 5}
!13 = !{i32 2, !"Debug Info Version", i32 3}
!14 = !{i32 4, !"probe-stack", !"inline-asm"}
!15 = !{i32 8, !"PIC Level", i32 2}
!16 = !{i32 7, !"PIE Level", i32 2}
!17 = !{i32 7, !"uwtable", i32 2}
!18 = !{i32 7, !"frame-pointer", i32 2}
!19 = !{!"Alpine clang version 23.1.5"}
!20 = distinct !DISubprogram(name: "f", scope: !3, file: !3, line: 11, type: !21, scopeLine: 12, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !23)
!21 = !DISubroutineType(types: !22)
!22 = !{!9, !5, !9, null}
!23 = !{}
!24 = !DILocalVariable(name: "pa", arg: 1, scope: !20, file: !3, line: 11, type: !5)
!25 = !DILocation(line: 11, column: 17, scope: !20)
!26 = !DILocalVariable(name: "pb", arg: 2, scope: !20, file: !3, line: 11, type: !9)
!27 = !DILocation(line: 11, column: 25, scope: !20)
!28 = !DILocation(line: 13, column: 10, scope: !20)
!29 = !DILocation(line: 13, column: 3, scope: !20)
!30 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 18, type: !31, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !2)
!31 = !DISubroutineType(types: !32)
!32 = !{!9}
!33 = !DILocation(line: 20, column: 7, scope: !34)
!34 = distinct !DILexicalBlock(scope: !30, file: !3, line: 20, column: 7)
!35 = !DILocation(line: 20, column: 22, scope: !34)
!36 = !DILocation(line: 21, column: 5, scope: !34)
!37 = !DILocation(line: 23, column: 3, scope: !30)
