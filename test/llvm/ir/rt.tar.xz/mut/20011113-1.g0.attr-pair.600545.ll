; MUTANT: attr-pair valid
source_filename = "20011113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.U = type { [3 x i64] }
%struct.t = type { i32, [4 x i64] }
@t = dso_local global { i8, i8, i8, i8, [4 x i8], [4 x i64] } { i8 26, i8 0, i8 0, i8 0, [4 x i8] zeroinitializer, [4 x i64] [i64 0, i64 21, i64 22, i64 23] }, align 8, !dbg !0
define dso_local ptr @foo(ptr noundef %0) #0 !dbg !24 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !30, !DIExpression(), !31)
    #dbg_declare(ptr %3, !32, !DIExpression(), !40)
    #dbg_declare(ptr %4, !41, !DIExpression(), !42)
  %5 = load ptr, ptr %2, align 8, !dbg !43
  %6 = getelementptr inbounds nuw %struct.t, ptr %5, i32 0, i32 1, !dbg !44
  %7 = getelementptr inbounds [4 x i64], ptr %6, i64 0, i64 1, !dbg !43
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %7, i64 24, i1 false), !dbg !45
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 24, i1 false), !dbg !46
  %8 = load ptr, ptr %2, align 8, !dbg !47
  %9 = load i32, ptr %8, align 8, !dbg !48
  %10 = lshr i32 %9, 16, !dbg !48
  %11 = and i32 %10, 255, !dbg !48
  %12 = call ptr @bar(ptr noundef byval(%struct.U) align 8 %3, i32 noundef %11), !dbg !49
  ret ptr %12, !dbg !50
}

declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1 optnone noinline optdebug
define dso_local ptr @bar(ptr noundef byval(%struct.U) align 8 %0, i32 noundef %1) #0 !dbg !51 {
  %3 = alloca i32, align 4
    #dbg_declare(ptr %0, !54, !DIExpression(), !55)
  store i32 %1, ptr %3, align 4
    #dbg_declare(ptr %3, !56, !DIExpression(), !57)
  %4 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0, !dbg !58
  %5 = getelementptr inbounds [3 x i64], ptr %4, i64 0, i64 0, !dbg !60
  %6 = load i64, ptr %5, align 8, !dbg !60
  %7 = icmp ne i64 %6, 21, !dbg !61
  br i1 %7, label %18, label %8, !dbg !62

8:
  %9 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0, !dbg !63
  %10 = getelementptr inbounds [3 x i64], ptr %9, i64 0, i64 1, !dbg !64
  %11 = load i64, ptr %10, align 8, !dbg !64
  %12 = icmp ne i64 %11, 22, !dbg !65
  br i1 %12, label %18, label %13, !dbg !66

13:
  %14 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0, !dbg !67
  %15 = getelementptr inbounds [3 x i64], ptr %14, i64 0, i64 2, !dbg !68
  %16 = load i64, ptr %15, align 8, !dbg !68
  %17 = icmp ne i64 %16, 23, !dbg !69
  br i1 %17, label %18, label %19, !dbg !66

18:
  call void @abort() #4, !dbg !70
  unreachable, !dbg !70

19:
  ret ptr null, !dbg !71
}

define dso_local ptr @baz(ptr noundef %0) #0 !dbg !72 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !73, !DIExpression(), !74)
    #dbg_declare(ptr %3, !75, !DIExpression(), !76)
    #dbg_declare(ptr %4, !77, !DIExpression(), !78)
  %5 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0, !dbg !79
  %6 = getelementptr inbounds [3 x i64], ptr %5, i64 0, i64 0, !dbg !80
  store i64 4886718345, ptr %6, align 8, !dbg !81
  %7 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0, !dbg !82
  %8 = getelementptr inbounds [3 x i64], ptr %7, i64 0, i64 1, !dbg !83
  store i64 68414056839, ptr %8, align 8, !dbg !84
  %9 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0, !dbg !85
  %10 = getelementptr inbounds [3 x i64], ptr %9, i64 0, i64 2, !dbg !86
  store i64 46118400291, ptr %10, align 8, !dbg !87
  %11 = load ptr, ptr %2, align 8, !dbg !88
  %12 = getelementptr inbounds nuw %struct.t, ptr %11, i32 0, i32 1, !dbg !89
  %13 = getelementptr inbounds [4 x i64], ptr %12, i64 0, i64 1, !dbg !88
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %13, i64 24, i1 false), !dbg !90
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 24, i1 false), !dbg !91
  %14 = load ptr, ptr %2, align 8, !dbg !92
  %15 = load i32, ptr %14, align 8, !dbg !93
  %16 = lshr i32 %15, 16, !dbg !93
  %17 = and i32 %16, 255, !dbg !93
  %18 = call ptr @bar(ptr noundef byval(%struct.U) align 8 %3, i32 noundef %17), !dbg !94
  ret ptr %18, !dbg !95
}

declare void @abort() #2
define dso_local i32 @main() #0 !dbg !96 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call ptr @baz(ptr noundef @t), !dbg !100
  %3 = call ptr @foo(ptr noundef @t), !dbg !101
  call void @exit(i32 noundef 0) #5, !dbg !102
  unreachable, !dbg !102
}

declare void @exit(i32 noundef) #3
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!16, !17, !18, !19, !20, !21, !22}
!llvm.ident = !{!23}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "t", scope: !2, file: !3, line: 48, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20011113-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "b10263dcd38b72fb4643fbb9438bad15")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "t", file: !3, line: 6, size: 320, elements: !6)
!6 = !{!7, !9, !10, !11}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !5, file: !3, line: 8, baseType: !8, size: 16, flags: DIFlagBitField, extraData: i64 0)
!8 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!9 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !5, file: !3, line: 9, baseType: !8, size: 8, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!10 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !5, file: !3, line: 10, baseType: !8, size: 8, offset: 24, flags: DIFlagBitField, extraData: i64 0)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "d", scope: !5, file: !3, line: 11, baseType: !12, size: 256, offset: 64)
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 256, elements: !14)
!13 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!14 = !{!15}
!15 = !DISubrange(count: 4)
!16 = !{i32 7, !"Dwarf Version", i32 5}
!17 = !{i32 2, !"Debug Info Version", i32 3}
!18 = !{i32 4, !"probe-stack", !"inline-asm"}
!19 = !{i32 8, !"PIC Level", i32 2}
!20 = !{i32 7, !"PIE Level", i32 2}
!21 = !{i32 7, !"uwtable", i32 2}
!22 = !{i32 7, !"frame-pointer", i32 2}
!23 = !{!"Alpine clang version 23.1.5"}
!24 = distinct !DISubprogram(name: "foo", scope: !3, file: !3, line: 20, type: !25, scopeLine: 21, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !29)
!25 = !DISubroutineType(types: !26)
!26 = !{!27, !27}
!27 = !DIDerivedType(tag: DW_TAG_typedef, name: "T", file: !3, line: 12, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!29 = !{}
!30 = !DILocalVariable(name: "x", arg: 1, scope: !24, file: !3, line: 20, type: !27)
!31 = !DILocation(line: 20, column: 10, scope: !24)
!32 = !DILocalVariable(name: "d", scope: !24, file: !3, line: 22, type: !33)
!33 = !DIDerivedType(tag: DW_TAG_typedef, name: "U", file: !3, line: 16, baseType: !34)
!34 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 14, size: 192, elements: !35)
!35 = !{!36}
!36 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !34, file: !3, line: 15, baseType: !37, size: 192)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 192, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 3)
!40 = !DILocation(line: 22, column: 5, scope: !24)
!41 = !DILocalVariable(name: "u", scope: !24, file: !3, line: 22, type: !33)
!42 = !DILocation(line: 22, column: 8, scope: !24)
!43 = !DILocation(line: 24, column: 16, scope: !24)
!44 = !DILocation(line: 24, column: 19, scope: !24)
!45 = !DILocation(line: 24, column: 3, scope: !24)
!46 = !DILocation(line: 25, column: 7, scope: !24)
!47 = !DILocation(line: 26, column: 18, scope: !24)
!48 = !DILocation(line: 26, column: 21, scope: !24)
!49 = !DILocation(line: 26, column: 10, scope: !24)
!50 = !DILocation(line: 26, column: 3, scope: !24)
!51 = distinct !DISubprogram(name: "bar", scope: !3, file: !3, line: 41, type: !52, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !29)
!52 = !DISubroutineType(types: !53)
!53 = !{!27, !33, !8}
!54 = !DILocalVariable(name: "d", arg: 1, scope: !51, file: !3, line: 41, type: !33)
!55 = !DILocation(line: 41, column: 10, scope: !51)
!56 = !DILocalVariable(name: "m", arg: 2, scope: !51, file: !3, line: 41, type: !8)
!57 = !DILocation(line: 41, column: 26, scope: !51)
!58 = !DILocation(line: 43, column: 9, scope: !59)
!59 = distinct !DILexicalBlock(scope: !51, file: !3, line: 43, column: 7)
!60 = !DILocation(line: 43, column: 7, scope: !59)
!61 = !DILocation(line: 43, column: 14, scope: !59)
!62 = !DILocation(line: 43, column: 20, scope: !59)
!63 = !DILocation(line: 43, column: 25, scope: !59)
!64 = !DILocation(line: 43, column: 23, scope: !59)
!65 = !DILocation(line: 43, column: 30, scope: !59)
!66 = !DILocation(line: 43, column: 36, scope: !59)
!67 = !DILocation(line: 43, column: 41, scope: !59)
!68 = !DILocation(line: 43, column: 39, scope: !59)
!69 = !DILocation(line: 43, column: 46, scope: !59)
!70 = !DILocation(line: 44, column: 5, scope: !59)
!71 = !DILocation(line: 45, column: 3, scope: !51)
!72 = distinct !DISubprogram(name: "baz", scope: !3, file: !3, line: 29, type: !25, scopeLine: 30, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !29)
!73 = !DILocalVariable(name: "x", arg: 1, scope: !72, file: !3, line: 29, type: !27)
!74 = !DILocation(line: 29, column: 10, scope: !72)
!75 = !DILocalVariable(name: "d", scope: !72, file: !3, line: 31, type: !33)
!76 = !DILocation(line: 31, column: 5, scope: !72)
!77 = !DILocalVariable(name: "u", scope: !72, file: !3, line: 31, type: !33)
!78 = !DILocation(line: 31, column: 8, scope: !72)
!79 = !DILocation(line: 33, column: 5, scope: !72)
!80 = !DILocation(line: 33, column: 3, scope: !72)
!81 = !DILocation(line: 33, column: 10, scope: !72)
!82 = !DILocation(line: 34, column: 5, scope: !72)
!83 = !DILocation(line: 34, column: 3, scope: !72)
!84 = !DILocation(line: 34, column: 10, scope: !72)
!85 = !DILocation(line: 35, column: 5, scope: !72)
!86 = !DILocation(line: 35, column: 3, scope: !72)
!87 = !DILocation(line: 35, column: 10, scope: !72)
!88 = !DILocation(line: 36, column: 16, scope: !72)
!89 = !DILocation(line: 36, column: 19, scope: !72)
!90 = !DILocation(line: 36, column: 3, scope: !72)
!91 = !DILocation(line: 37, column: 7, scope: !72)
!92 = !DILocation(line: 38, column: 18, scope: !72)
!93 = !DILocation(line: 38, column: 21, scope: !72)
!94 = !DILocation(line: 38, column: 10, scope: !72)
!95 = !DILocation(line: 38, column: 3, scope: !72)
!96 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 50, type: !97, scopeLine: 51, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2)
!97 = !DISubroutineType(types: !98)
!98 = !{!99}
!99 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!100 = !DILocation(line: 52, column: 3, scope: !96)
!101 = !DILocation(line: 53, column: 3, scope: !96)
!102 = !DILocation(line: 54, column: 3, scope: !96)
