; MUTANT: hoist valid
source_filename = "20050224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@a = dso_local global i64 3221225472, align 8, !dbg !0
@b = dso_local global i64 3489660928, align 8, !dbg !5
@c = dso_local global i64 3223042392, align 8, !dbg !8
@d = dso_local global i64 3223732224, align 8, !dbg !10
@e = dso_local global i64 3223879680, align 8, !dbg !12
@f = dso_local global i64 3224191864, align 8, !dbg !14
define dso_local void @foo(i32 noundef %0, i32 noundef %1, i32 noundef %2) #0 !dbg !24 {
    #dbg_declare(ptr %4, !29, !DIExpression(), !30)
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, ptr %4, align 4
  store i32 %1, ptr %5, align 4
    #dbg_declare(ptr %5, !31, !DIExpression(), !32)
  store i32 %2, ptr %6, align 4
    #dbg_declare(ptr %6, !33, !DIExpression(), !34)
  %7 = load i32, ptr %4, align 4, !dbg !35
  %8 = icmp ne i32 %7, 245, !dbg !37
  br i1 %8, label %15, label %9, !dbg !38

9:
  %10 = load i32, ptr %5, align 4, !dbg !39
  %11 = icmp ne i32 %10, 36, !dbg !40
  br i1 %11, label %15, label %12, !dbg !41

12:
  %13 = load i32, ptr %6, align 4, !dbg !42
  %14 = icmp ne i32 %13, 444, !dbg !43
  br i1 %14, label %15, label %16, !dbg !41

15:
  call void @abort() #2, !dbg !44
  unreachable, !dbg !44

16:
  ret void, !dbg !45
}

declare void @abort() #1
define dso_local i32 @main() #0 !dbg !46 {
  %1 = alloca i32, align 4
  %2 = alloca i64, align 8
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !49, !DIExpression(), !50)
    #dbg_declare(ptr %3, !51, !DIExpression(), !52)
  store i32 0, ptr %3, align 4, !dbg !52
    #dbg_declare(ptr %4, !53, !DIExpression(), !54)
  store i32 0, ptr %4, align 4, !dbg !54
    #dbg_declare(ptr %5, !55, !DIExpression(), !56)
  store i32 0, ptr %5, align 4, !dbg !56
  %6 = load i64, ptr @a, align 8, !dbg !57
  store i64 %6, ptr %2, align 8, !dbg !59
  br label %7, !dbg !60

7:
  %8 = load i64, ptr %2, align 8, !dbg !61
  %9 = load i64, ptr @b, align 8, !dbg !63
  %10 = icmp ult i64 %8, %9, !dbg !64
  br i1 %10, label %11, label %42, !dbg !65

11:
  %12 = load i64, ptr %2, align 8, !dbg !66
  %13 = load i64, ptr @c, align 8, !dbg !68
  %14 = icmp ult i64 %12, %13, !dbg !69
  br i1 %14, label %15, label %18, !dbg !69

15:
  %16 = load i32, ptr %3, align 4, !dbg !70
  %17 = add nsw i32 %16, 1, !dbg !70
  store i32 %17, ptr %3, align 4, !dbg !70
  br label %38, !dbg !71

18:
  %19 = load i64, ptr %2, align 8, !dbg !72
  %20 = load i64, ptr @d, align 8, !dbg !74
  %21 = icmp uge i64 %19, %20, !dbg !75
  br i1 %21, label %22, label %29, !dbg !76

22:
  %23 = load i64, ptr %2, align 8, !dbg !77
  %24 = load i64, ptr @e, align 8, !dbg !78
  %25 = icmp ult i64 %23, %24, !dbg !79
  br i1 %25, label %26, label %29, !dbg !76

26:
  %27 = load i32, ptr %5, align 4, !dbg !80
  %28 = add nsw i32 %27, 1, !dbg !80
  store i32 %28, ptr %5, align 4, !dbg !80
  br label %37, !dbg !81

29:
  %30 = load i64, ptr %2, align 8, !dbg !82
  %31 = load i64, ptr @f, align 8, !dbg !84
  %32 = icmp ult i64 %30, %31, !dbg !85
  br i1 %32, label %33, label %36, !dbg !85

33:
  %34 = load i32, ptr %4, align 4, !dbg !86
  %35 = add nsw i32 %34, 1, !dbg !86
  store i32 %35, ptr %4, align 4, !dbg !86
  br label %36, !dbg !87

36:
  br label %37

37:
  br label %38

38:
  br label %39, !dbg !68

39:
  %40 = load i64, ptr %2, align 8, !dbg !88
  %41 = add i64 %40, 4096, !dbg !88
  store i64 %41, ptr %2, align 8, !dbg !88
  br label %7, !dbg !89, !llvm.loop !90

42:
  %43 = load i32, ptr %4, align 4, !dbg !93
  %44 = load i32, ptr %5, align 4, !dbg !94
  %45 = load i32, ptr %3, align 4, !dbg !95
  call void @foo(i32 noundef %43, i32 noundef %44, i32 noundef %45), !dbg !96
  ret i32 0, !dbg !97
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!16, !17, !18, !19, !20, !21, !22}
!llvm.ident = !{!23}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "a", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20050224-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "6c8199c0ffd341030bef718b580100e9")
!4 = !{!0, !5, !8, !10, !12, !14}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "b", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!7 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "c", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!10 = !DIGlobalVariableExpression(var: !11, expr: !DIExpression())
!11 = distinct !DIGlobalVariable(name: "d", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!12 = !DIGlobalVariableExpression(var: !13, expr: !DIExpression())
!13 = distinct !DIGlobalVariable(name: "e", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!14 = !DIGlobalVariableExpression(var: !15, expr: !DIExpression())
!15 = distinct !DIGlobalVariable(name: "f", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!16 = !{i32 7, !"Dwarf Version", i32 5}
!17 = !{i32 2, !"Debug Info Version", i32 3}
!18 = !{i32 4, !"probe-stack", !"inline-asm"}
!19 = !{i32 8, !"PIC Level", i32 2}
!20 = !{i32 7, !"PIE Level", i32 2}
!21 = !{i32 7, !"uwtable", i32 2}
!22 = !{i32 7, !"frame-pointer", i32 2}
!23 = !{!"Alpine clang version 23.1.5"}
!24 = distinct !DISubprogram(name: "foo", scope: !3, file: !3, line: 9, type: !25, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !28)
!25 = !DISubroutineType(types: !26)
!26 = !{null, !27, !27, !27}
!27 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!28 = !{}
!29 = !DILocalVariable(name: "x", arg: 1, scope: !24, file: !3, line: 9, type: !27)
!30 = !DILocation(line: 9, column: 10, scope: !24)
!31 = !DILocalVariable(name: "y", arg: 2, scope: !24, file: !3, line: 9, type: !27)
!32 = !DILocation(line: 9, column: 17, scope: !24)
!33 = !DILocalVariable(name: "z", arg: 3, scope: !24, file: !3, line: 9, type: !27)
!34 = !DILocation(line: 9, column: 24, scope: !24)
!35 = !DILocation(line: 11, column: 7, scope: !36)
!36 = distinct !DILexicalBlock(scope: !24, file: !3, line: 11, column: 7)
!37 = !DILocation(line: 11, column: 9, scope: !36)
!38 = !DILocation(line: 11, column: 16, scope: !36)
!39 = !DILocation(line: 11, column: 19, scope: !36)
!40 = !DILocation(line: 11, column: 21, scope: !36)
!41 = !DILocation(line: 11, column: 27, scope: !36)
!42 = !DILocation(line: 11, column: 30, scope: !36)
!43 = !DILocation(line: 11, column: 32, scope: !36)
!44 = !DILocation(line: 12, column: 5, scope: !36)
!45 = !DILocation(line: 13, column: 1, scope: !24)
!46 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 16, type: !47, scopeLine: 17, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !28)
!47 = !DISubroutineType(types: !48)
!48 = !{!27}
!49 = !DILocalVariable(name: "g", scope: !46, file: !3, line: 18, type: !7)
!50 = !DILocation(line: 18, column: 17, scope: !46)
!51 = !DILocalVariable(name: "h", scope: !46, file: !3, line: 19, type: !27)
!52 = !DILocation(line: 19, column: 7, scope: !46)
!53 = !DILocalVariable(name: "i", scope: !46, file: !3, line: 19, type: !27)
!54 = !DILocation(line: 19, column: 14, scope: !46)
!55 = !DILocalVariable(name: "j", scope: !46, file: !3, line: 19, type: !27)
!56 = !DILocation(line: 19, column: 21, scope: !46)
!57 = !DILocation(line: 24, column: 12, scope: !58)
!58 = distinct !DILexicalBlock(scope: !46, file: !3, line: 24, column: 3)
!59 = !DILocation(line: 24, column: 10, scope: !58)
!60 = !DILocation(line: 24, column: 8, scope: !58)
!61 = !DILocation(line: 24, column: 15, scope: !62)
!62 = distinct !DILexicalBlock(scope: !58, file: !3, line: 24, column: 3)
!63 = !DILocation(line: 24, column: 19, scope: !62)
!64 = !DILocation(line: 24, column: 17, scope: !62)
!65 = !DILocation(line: 24, column: 3, scope: !58)
!66 = !DILocation(line: 25, column: 9, scope: !67)
!67 = distinct !DILexicalBlock(scope: !62, file: !3, line: 25, column: 9)
!68 = !DILocation(line: 25, column: 13, scope: !67)
!69 = !DILocation(line: 25, column: 11, scope: !67)
!70 = !DILocation(line: 26, column: 8, scope: !67)
!71 = !DILocation(line: 26, column: 7, scope: !67)
!72 = !DILocation(line: 27, column: 14, scope: !73)
!73 = distinct !DILexicalBlock(scope: !67, file: !3, line: 27, column: 14)
!74 = !DILocation(line: 27, column: 19, scope: !73)
!75 = !DILocation(line: 27, column: 16, scope: !73)
!76 = !DILocation(line: 27, column: 21, scope: !73)
!77 = !DILocation(line: 27, column: 24, scope: !73)
!78 = !DILocation(line: 27, column: 28, scope: !73)
!79 = !DILocation(line: 27, column: 26, scope: !73)
!80 = !DILocation(line: 28, column: 8, scope: !73)
!81 = !DILocation(line: 28, column: 7, scope: !73)
!82 = !DILocation(line: 29, column: 14, scope: !83)
!83 = distinct !DILexicalBlock(scope: !73, file: !3, line: 29, column: 14)
!84 = !DILocation(line: 29, column: 18, scope: !83)
!85 = !DILocation(line: 29, column: 16, scope: !83)
!86 = !DILocation(line: 30, column: 8, scope: !83)
!87 = !DILocation(line: 30, column: 7, scope: !83)
!88 = !DILocation(line: 24, column: 24, scope: !62)
!89 = !DILocation(line: 24, column: 3, scope: !62)
!90 = distinct !{!90, !65, !91, !92}
!91 = !DILocation(line: 30, column: 8, scope: !58)
!92 = !{!"llvm.loop.mustprogress"}
!93 = !DILocation(line: 31, column: 8, scope: !46)
!94 = !DILocation(line: 31, column: 11, scope: !46)
!95 = !DILocation(line: 31, column: 14, scope: !46)
!96 = !DILocation(line: 31, column: 3, scope: !46)
!97 = !DILocation(line: 32, column: 3, scope: !46)
