; MUTANT: phimover invalid Verifier: PHI nodes not grouped at top of basic block!
source_filename = "20090113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local void @msum_i4(ptr nofree noundef readonly captures(none) %0, ptr nofree noundef readonly captures(none) %1, ptr nofree noundef readonly captures(none) %2) local_unnamed_addr #0 !dbg !10 {
  %4 = alloca [7 x i32], align 16, !DIAssignID !49
    #dbg_assign(i1 poison, !39, !DIExpression(), !49, ptr %4, !DIExpression(), !50)
  %5 = alloca [7 x i32], align 16, !DIAssignID !51
    #dbg_assign(i1 poison, !41, !DIExpression(), !51, ptr %5, !DIExpression(), !50)
    #dbg_value(ptr %0, !36, !DIExpression(), !50)
    #dbg_value(ptr %1, !37, !DIExpression(), !50)
    #dbg_value(ptr %2, !38, !DIExpression(), !50)
  call void @llvm.lifetime.start.p0(ptr nonnull %4), !dbg !52
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #6, !dbg !53
  %6 = load i32, ptr %2, align 4, !dbg !54
  %7 = add nsw i32 %6, -1, !dbg !55
    #dbg_value(i32 %7, !44, !DIExpression(), !50)
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 12, !dbg !56
  %9 = sext i32 %7 to i64, !dbg !57
  %10 = getelementptr inbounds [12 x i8], ptr %8, i64 %9, !dbg !57
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 8, !dbg !58
  %12 = load i32, ptr %11, align 4, !dbg !58
  %13 = add i32 %12, 1, !dbg !59
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 4, !dbg !60
  %15 = load i32, ptr %14, align 4, !dbg !60
  %16 = sub i32 %13, %15, !dbg !61
    #dbg_value(i32 %16, !46, !DIExpression(), !50)
    #dbg_value(i32 0, !45, !DIExpression(), !50)
  %17 = icmp sgt i32 %6, 1, !dbg !62
  br i1 %17, label %18, label %64, !dbg !65

18:
  %19 = zext nneg i32 %7 to i64, !dbg !66
  %20 = shl nuw nsw i64 %19, 2, !dbg !66
  call void @llvm.memset.p0.i64(ptr nonnull align 16 %4, i8 0, i64 %20, i1 false), !dbg !67
  %21 = and i64 %19, 1, !dbg !66
  %22 = icmp eq i32 %7, 1, !dbg !66
  br i1 %22, label %50, label %23, !dbg !66

23:
  %24 = and i64 %19, 2147483646, !dbg !66
  br label %25, !dbg !66

25:
  %26 = phi i64 [ 0, %23 ], [ %45, %25 ]
  %27 = phi i64 [ 0, %23 ], [ %46, %25 ]
    #dbg_value(i64 %26, !45, !DIExpression(), !50)
  %28 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %26, !dbg !69
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 8, !dbg !70
  %30 = load i32, ptr %29, align 4, !dbg !70
  %31 = add nsw i32 %30, 1, !dbg !71
  %32 = getelementptr inbounds nuw i8, ptr %28, i64 4, !dbg !72
  %33 = load i32, ptr %32, align 4, !dbg !72
  %34 = sub i32 %31, %33, !dbg !73
  %35 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %26, !dbg !74
  store i32 %34, ptr %35, align 8, !dbg !75
  %36 = or disjoint i64 %26, 1, !dbg !76
    #dbg_value(i64 %36, !45, !DIExpression(), !50)
  %37 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %36, !dbg !69
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 8, !dbg !70
  %39 = load i32, ptr %38, align 4, !dbg !70
  %40 = add nsw i32 %39, 1, !dbg !71
  %41 = getelementptr inbounds nuw i8, ptr %37, i64 4, !dbg !72
  %42 = load i32, ptr %41, align 4, !dbg !72
  %43 = sub i32 %40, %42, !dbg !77
  %44 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %36, !dbg !74
  store i32 %43, ptr %44, align 4, !dbg !78
  %45 = add nuw nsw i64 %26, 2, !dbg !79
    #dbg_value(i64 %45, !45, !DIExpression(), !50)
  %46 = add i64 %27, 2, !dbg !80
  %47 = icmp eq i64 %46, %24, !dbg !80
  br i1 %47, label %48, label %25, !dbg !80, !llvm.loop !81

48:
  %49 = icmp eq i64 %21, 0, !dbg !66
  br i1 %49, label %61, label %50, !dbg !66

50:
  %51 = phi i64 [ 0, %18 ], [ %45, %48 ]
  %52 = trunc i32 %7 to i1, !dbg !84
  tail call void @llvm.assume(i1 %52), !dbg !84
    #dbg_value(i64 %51, !45, !DIExpression(), !50)
  %53 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %51, !dbg !69
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 8, !dbg !70
  %55 = load i32, ptr %54, align 4, !dbg !70
  %56 = add nsw i32 %55, 1, !dbg !71
  %57 = getelementptr inbounds nuw i8, ptr %53, i64 4, !dbg !72
  %58 = load i32, ptr %57, align 4, !dbg !72
  %59 = sub i32 %56, %58, !dbg !85
  %60 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %51, !dbg !74
  store i32 %59, ptr %60, align 4, !dbg !86
    #dbg_value(i64 %51, !45, !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value), !50)
  br label %61

61:
  %62 = load i32, ptr %5, align 16
  %63 = load i32, ptr %4, align 16
  br label %64, !dbg !87

64:
  %65 = phi i32 [ %63, %61 ], [ undef, %3 ]
  %66 = phi i32 [ %62, %61 ], [ undef, %3 ]
  %67 = load ptr, ptr %0, align 8, !dbg !87
    #dbg_value(ptr %67, !42, !DIExpression(), !50)
  %68 = load ptr, ptr %1, align 8, !dbg !88
    #dbg_value(ptr %68, !43, !DIExpression(), !50)
  %69 = icmp sgt i32 %16, 0
  %70 = zext nneg i32 %16 to i64
  %71 = icmp ult i32 %16, 8
  %72 = and i64 %70, 2147483640
  %73 = trunc nuw nsw i64 %72 to i32
  %74 = shl nuw nsw i64 %72, 2
  %75 = icmp eq i64 %72, %70
  br label %76, !dbg !89

76:
  %77 = phi i32 [ %65, %64 ], [ %115, %112 ]
  %78 = phi ptr [ %68, %64 ], [ %113, %112 ], !dbg !90
  %79 = phi ptr [ %67, %64 ], [ %116, %112 ], !dbg !50
    #dbg_value(ptr %79, !42, !DIExpression(), !50)
    #dbg_value(ptr %78, !43, !DIExpression(), !50)
    #dbg_value(i32 0, !47, !DIExpression(), !91)
    #dbg_value(i32 0, !45, !DIExpression(), !50)
  br i1 %69, label %80, label %112, !dbg !92

80:
  br i1 %71, label %99, label %81, !dbg !94

81:
  %82 = getelementptr i8, ptr %78, i64 %74
  br label %83, !dbg !94

83:
  %84 = phi i64 [ 0, %81 ], [ %94, %83 ]
  %85 = phi <4 x i32> [ zeroinitializer, %81 ], [ %92, %83 ]
  %86 = phi <4 x i32> [ zeroinitializer, %81 ], [ %93, %83 ]
  %87 = shl i64 %84, 2
  %88 = getelementptr i8, ptr %78, i64 %87
  %89 = getelementptr i8, ptr %88, i64 16, !dbg !95
  %90 = load <4 x i32>, ptr %88, align 4, !dbg !95
  %91 = load <4 x i32>, ptr %89, align 4, !dbg !95
  %92 = add <4 x i32> %90, %85, !dbg !97
  %93 = add <4 x i32> %91, %86, !dbg !97
  %94 = add nuw i64 %84, 8
  %95 = icmp eq i64 %94, %72, !dbg !98
  br i1 %95, label %96, label %83, !dbg !98, !llvm.loop !99

96:
  %97 = add <4 x i32> %93, %92, !dbg !98
  %98 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %97), !dbg !98
  br i1 %75, label %112, label %99, !dbg !98

99:
  %100 = phi i32 [ 0, %80 ], [ %98, %96 ]
  %101 = phi i32 [ 0, %80 ], [ %73, %96 ]
  %102 = phi ptr [ %78, %80 ], [ %82, %96 ]
  br label %103, !dbg !98

103:
  %104 = phi i32 [ %108, %103 ], [ %100, %99 ]
  %105 = phi ptr [ %110, %103 ], [ %102, %99 ]
    #dbg_value(i32 %104, !47, !DIExpression(), !91)
    #dbg_value(i32 %107, !45, !DIExpression(), !50)
    #dbg_value(ptr %105, !43, !DIExpression(), !50)
  %106 = load i32, ptr %105, align 4, !dbg !95
  %107 = phi i32 [ %109, %103 ], [ %101, %99 ]
  %108 = add nsw i32 %106, %104, !dbg !97
    #dbg_value(i32 %108, !47, !DIExpression(), !91)
  %109 = add nuw nsw i32 %107, 1, !dbg !102
    #dbg_value(i32 %109, !45, !DIExpression(), !50)
  %110 = getelementptr inbounds nuw i8, ptr %105, i64 4, !dbg !103
    #dbg_value(ptr %110, !43, !DIExpression(), !50)
  %111 = icmp eq i32 %109, %16, !dbg !104
  br i1 %111, label %112, label %103, !dbg !98, !llvm.loop !105

112:
  %113 = phi ptr [ %78, %76 ], [ %82, %96 ], [ %110, %103 ], !dbg !50
  %114 = phi i32 [ 0, %76 ], [ %98, %96 ], [ %108, %103 ], !dbg !91
  store i32 %114, ptr %79, align 4, !dbg !106
  %115 = add nsw i32 %77, 1, !dbg !107
  store i32 %115, ptr %4, align 16, !dbg !108, !DIAssignID !109
    #dbg_assign(i32 %115, !39, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !109, ptr %4, !DIExpression(), !50)
  %116 = getelementptr inbounds nuw i8, ptr %79, i64 4, !dbg !110
    #dbg_value(ptr %116, !42, !DIExpression(), !50)
  %117 = icmp eq i32 %115, %66, !dbg !111
  br i1 %117, label %118, label %76, !dbg !112, !llvm.loop !113

118:
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #6, !dbg !115
  call void @llvm.lifetime.end.p0(ptr nonnull %4), !dbg !115
  ret void, !dbg !116
}

declare void @llvm.lifetime.start.p0(ptr captures(none)) #1
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !117 {
    #dbg_value(ptr poison, !42, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !132)
    #dbg_value(ptr poison, !42, !DIExpression(DW_OP_LLVM_fragment, 32, 32), !132)
    #dbg_value(ptr poison, !129, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !134)
    #dbg_value(ptr poison, !129, !DIExpression(DW_OP_LLVM_fragment, 32, 32), !134)
    #dbg_value(ptr poison, !130, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !134)
    #dbg_value(ptr poison, !130, !DIExpression(DW_OP_LLVM_fragment, 32, 32), !134)
    #dbg_value(ptr poison, !43, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !132)
    #dbg_value(ptr poison, !43, !DIExpression(DW_OP_LLVM_fragment, 32, 32), !132)
    #dbg_assign(i8 0, !129, !DIExpression(DW_OP_LLVM_fragment, 192, 576), !135, ptr poison, !DIExpression(), !134)
    #dbg_value(ptr undef, !129, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !134)
    #dbg_value(i32 265, !129, !DIExpression(DW_OP_LLVM_fragment, 64, 32), !134)
    #dbg_value(i32 1, !129, !DIExpression(DW_OP_LLVM_fragment, 96, 32), !134)
    #dbg_value(i32 1, !129, !DIExpression(DW_OP_LLVM_fragment, 128, 32), !134)
    #dbg_value(i32 3, !129, !DIExpression(DW_OP_LLVM_fragment, 160, 32), !134)
    #dbg_value(ptr undef, !130, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !134)
    #dbg_value(i32 266, !130, !DIExpression(DW_OP_LLVM_fragment, 64, 32), !134)
    #dbg_value(i32 poison, !130, !DIExpression(DW_OP_LLVM_fragment, 96, 32), !134)
    #dbg_value(i32 1, !130, !DIExpression(DW_OP_LLVM_fragment, 128, 32), !134)
    #dbg_value(i32 3, !130, !DIExpression(DW_OP_LLVM_fragment, 160, 32), !134)
    #dbg_value(i32 poison, !130, !DIExpression(DW_OP_LLVM_fragment, 192, 32), !134)
    #dbg_value(i32 1, !130, !DIExpression(DW_OP_LLVM_fragment, 224, 32), !134)
    #dbg_value(i32 3, !130, !DIExpression(DW_OP_LLVM_fragment, 256, 32), !134)
    #dbg_assign(i1 poison, !130, !DIExpression(DW_OP_LLVM_fragment, 288, 480), !136, ptr poison, !DIExpression(), !134)
    #dbg_value(i32 2, !131, !DIExpression(), !134)
    #dbg_value(ptr undef, !36, !DIExpression(), !132)
    #dbg_value(ptr undef, !37, !DIExpression(), !132)
    #dbg_value(ptr poison, !38, !DIExpression(), !132)
    #dbg_value(i32 1, !44, !DIExpression(), !132)
    #dbg_value(i32 3, !46, !DIExpression(), !132)
    #dbg_value(i32 3, !41, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !132)
    #dbg_value(i64 1, !45, !DIExpression(), !132)
    #dbg_value(ptr undef, !42, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(), !132)
    #dbg_value(ptr undef, !42, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(), !132)
    #dbg_value(i32 0, !47, !DIExpression(), !137)
    #dbg_value(i32 0, !45, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 1, !45, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 2, !45, !DIExpression(), !132)
    #dbg_value(!DIArgList(i32 undef, i32 undef), !121, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 32), !134)
    #dbg_assign(i32 1, !39, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !138, ptr poison, !DIExpression(), !132)
    #dbg_value(ptr undef, !42, !DIExpression(), !132)
    #dbg_value(i32 0, !47, !DIExpression(), !137)
    #dbg_value(i32 0, !45, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 1, !45, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 2, !45, !DIExpression(), !132)
    #dbg_value(!DIArgList(i32 undef, i32 undef), !121, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 32, 32), !134)
    #dbg_assign(i32 2, !39, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !138, ptr poison, !DIExpression(), !132)
    #dbg_value(ptr undef, !42, !DIExpression(), !132)
    #dbg_value(i32 0, !47, !DIExpression(), !137)
    #dbg_value(i32 0, !45, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 1, !45, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(), !132)
    #dbg_value(i32 undef, !47, !DIExpression(), !137)
    #dbg_value(i32 2, !45, !DIExpression(), !132)
    #dbg_value(!DIArgList(i32 undef, i32 undef), !47, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value), !137)
    #dbg_value(i32 3, !45, !DIExpression(), !132)
    #dbg_value(ptr undef, !43, !DIExpression(DW_OP_plus_uconst, 4, DW_OP_stack_value), !132)
    #dbg_value(!DIArgList(i32 undef, i32 undef), !121, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value, DW_OP_LLVM_fragment, 64, 32), !134)
    #dbg_assign(i32 3, !39, !DIExpression(DW_OP_LLVM_fragment, 0, 32), !138, ptr poison, !DIExpression(), !132)
    #dbg_value(ptr undef, !42, !DIExpression(DW_OP_plus_uconst, 4, DW_OP_stack_value), !132)
  ret i32 0, !dbg !139
}

declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #4
declare void @llvm.assume(i1 noundef) #5
attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(readwrite, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind sspstrong memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #6 = { nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20090113-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "76317d5bd99acd61d6284aff55e5bbda")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "msum_i4", scope: !1, file: !1, line: 14, type: !11, scopeLine: 17, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !35, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13, !13, !32}
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "gfc_array_i4", file: !1, line: 11, baseType: !16)
!16 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1, line: 7, size: 768, elements: !17)
!17 = !{!18, !21, !22}
!18 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !16, file: !1, line: 8, baseType: !19, size: 64)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "dtype", scope: !16, file: !1, line: 9, baseType: !20, size: 32, offset: 64)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "dim", scope: !16, file: !1, line: 10, baseType: !23, size: 672, offset: 96)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !24, size: 672, elements: !30)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "descriptor_dimension", file: !1, line: 6, baseType: !25)
!25 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "descriptor_dimension", file: !1, line: 1, size: 96, elements: !26)
!26 = !{!27, !28, !29}
!27 = !DIDerivedType(tag: DW_TAG_member, name: "stride", scope: !25, file: !1, line: 3, baseType: !20, size: 32)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "lbound", scope: !25, file: !1, line: 4, baseType: !20, size: 32, offset: 32)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "ubound", scope: !25, file: !1, line: 5, baseType: !20, size: 32, offset: 64)
!30 = !{!31}
!31 = !DISubrange(count: 7)
!32 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !33)
!33 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !34, size: 64)
!34 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!35 = !{!36, !37, !38, !39, !41, !42, !43, !44, !45, !46, !47}
!36 = !DILocalVariable(name: "retarray", arg: 1, scope: !10, file: !1, line: 14, type: !13)
!37 = !DILocalVariable(name: "array", arg: 2, scope: !10, file: !1, line: 15, type: !13)
!38 = !DILocalVariable(name: "pdim", arg: 3, scope: !10, file: !1, line: 16, type: !32)
!39 = !DILocalVariable(name: "count", scope: !10, file: !1, line: 18, type: !40)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 224, elements: !30)
!41 = !DILocalVariable(name: "extent", scope: !10, file: !1, line: 19, type: !40)
!42 = !DILocalVariable(name: "dest", scope: !10, file: !1, line: 20, type: !19)
!43 = !DILocalVariable(name: "base", scope: !10, file: !1, line: 21, type: !33)
!44 = !DILocalVariable(name: "dim", scope: !10, file: !1, line: 22, type: !20)
!45 = !DILocalVariable(name: "n", scope: !10, file: !1, line: 23, type: !20)
!46 = !DILocalVariable(name: "len", scope: !10, file: !1, line: 24, type: !20)
!47 = !DILocalVariable(name: "result", scope: !48, file: !1, line: 40, type: !20)
!48 = distinct !DILexicalBlock(scope: !10, file: !1, line: 39, column: 5)
!49 = distinct !DIAssignID()
!50 = !DILocation(line: 0, scope: !10)
!51 = distinct !DIAssignID()
!52 = !DILocation(line: 18, column: 3, scope: !10)
!53 = !DILocation(line: 19, column: 3, scope: !10)
!54 = !DILocation(line: 26, column: 10, scope: !10)
!55 = !DILocation(line: 26, column: 17, scope: !10, atomGroup: 1, atomRank: 2)
!56 = !DILocation(line: 27, column: 16, scope: !10)
!57 = !DILocation(line: 27, column: 9, scope: !10)
!58 = !DILocation(line: 27, column: 25, scope: !10)
!59 = !DILocation(line: 27, column: 32, scope: !10)
!60 = !DILocation(line: 27, column: 54, scope: !10)
!61 = !DILocation(line: 27, column: 36, scope: !10, atomGroup: 2, atomRank: 2)
!62 = !DILocation(line: 29, column: 17, scope: !63, atomGroup: 26, atomRank: 1)
!63 = distinct !DILexicalBlock(scope: !64, file: !1, line: 29, column: 3)
!64 = distinct !DILexicalBlock(scope: !10, file: !1, line: 29, column: 3)
!65 = !DILocation(line: 29, column: 3, scope: !64, atomGroup: 27, atomRank: 1)
!66 = !DILocation(line: 29, column: 3, scope: !64)
!67 = !DILocation(line: 32, column: 16, scope: !68, atomGroup: 7, atomRank: 1)
!68 = distinct !DILexicalBlock(scope: !63, file: !1, line: 30, column: 5)
!69 = !DILocation(line: 31, column: 19, scope: !68)
!70 = !DILocation(line: 31, column: 33, scope: !68)
!71 = !DILocation(line: 31, column: 40, scope: !68)
!72 = !DILocation(line: 31, column: 60, scope: !68)
!73 = !DILocation(line: 31, column: 44, scope: !68, atomGroup: 6, atomRank: 2)
!74 = !DILocation(line: 31, column: 7, scope: !68)
!75 = !DILocation(line: 31, column: 17, scope: !68, atomGroup: 6, atomRank: 1)
!76 = !DILocation(line: 29, column: 25, scope: !63, atomGroup: 8, atomRank: 2)
!77 = !DILocation(line: 31, column: 44, scope: !68, atomGroup: 34, atomRank: 2)
!78 = !DILocation(line: 31, column: 17, scope: !68, atomGroup: 34, atomRank: 1)
!79 = !DILocation(line: 29, column: 25, scope: !63, atomGroup: 35, atomRank: 2)
!80 = !DILocation(line: 29, column: 3, scope: !64, atomGroup: 37, atomRank: 1)
!81 = distinct !{!81, !66, !82, !83}
!82 = !DILocation(line: 33, column: 5, scope: !64)
!83 = !{!"llvm.loop.mustprogress"}
!84 = !DILocation(line: 29, column: 3, scope: !64, atomGroup: 5, atomRank: 1)
!85 = !DILocation(line: 31, column: 44, scope: !68, atomGroup: 30, atomRank: 2)
!86 = !DILocation(line: 31, column: 17, scope: !68, atomGroup: 30, atomRank: 1)
!87 = !DILocation(line: 35, column: 20, scope: !10, atomGroup: 10, atomRank: 2)
!88 = !DILocation(line: 36, column: 17, scope: !10, atomGroup: 11, atomRank: 2)
!89 = !DILocation(line: 38, column: 3, scope: !10)
!90 = !DILocation(line: 36, column: 8, scope: !10, atomGroup: 11, atomRank: 1)
!91 = !DILocation(line: 0, scope: !48)
!92 = !DILocation(line: 42, column: 7, scope: !93, atomGroup: 29, atomRank: 1)
!93 = distinct !DILexicalBlock(scope: !48, file: !1, line: 42, column: 7)
!94 = !DILocation(line: 42, column: 7, scope: !93)
!95 = !DILocation(line: 43, column: 12, scope: !96)
!96 = distinct !DILexicalBlock(scope: !93, file: !1, line: 42, column: 7)
!97 = !DILocation(line: 43, column: 9, scope: !96, atomGroup: 16, atomRank: 2)
!98 = !DILocation(line: 42, column: 7, scope: !93, atomGroup: 15, atomRank: 1)
!99 = distinct !{!99, !83, !100, !101}
!100 = !{!"llvm.loop.isvectorized", i32 1}
!101 = !{!"llvm.loop.unroll.runtime.disable"}
!102 = !DILocation(line: 42, column: 29, scope: !96, atomGroup: 17, atomRank: 2)
!103 = !DILocation(line: 42, column: 37, scope: !96, atomGroup: 18, atomRank: 2)
!104 = !DILocation(line: 42, column: 21, scope: !96, atomGroup: 14, atomRank: 1)
!105 = distinct !{!105, !83, !101, !100}
!106 = !DILocation(line: 44, column: 13, scope: !48, atomGroup: 20, atomRank: 1)
!107 = !DILocation(line: 46, column: 15, scope: !48, atomGroup: 21, atomRank: 2)
!108 = !DILocation(line: 46, column: 15, scope: !48, atomGroup: 21, atomRank: 1)
!109 = distinct !DIAssignID()
!110 = !DILocation(line: 47, column: 12, scope: !48, atomGroup: 22, atomRank: 2)
!111 = !DILocation(line: 49, column: 19, scope: !10, atomGroup: 23, atomRank: 1)
!112 = !DILocation(line: 48, column: 5, scope: !48, atomGroup: 24, atomRank: 1)
!113 = distinct !{!113, !89, !114, !83}
!114 = !DILocation(line: 49, column: 31, scope: !10)
!115 = !DILocation(line: 50, column: 1, scope: !10)
!116 = !DILocation(line: 50, column: 1, scope: !10, atomGroup: 25, atomRank: 1)
!117 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 52, type: !118, scopeLine: 53, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !120, keyInstructions: true)
!118 = !DISubroutineType(types: !119)
!119 = !{!20}
!120 = !{!121, !125, !129, !130, !131}
!121 = !DILocalVariable(name: "rdata", scope: !117, file: !1, line: 54, type: !122)
!122 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 96, elements: !123)
!123 = !{!124}
!124 = !DISubrange(count: 3)
!125 = !DILocalVariable(name: "adata", scope: !117, file: !1, line: 55, type: !126)
!126 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 288, elements: !127)
!127 = !{!128}
!128 = !DISubrange(count: 9)
!129 = !DILocalVariable(name: "retarray", scope: !117, file: !1, line: 56, type: !15)
!130 = !DILocalVariable(name: "array", scope: !117, file: !1, line: 57, type: !15)
!131 = !DILocalVariable(name: "dim", scope: !117, file: !1, line: 58, type: !20)
!132 = !DILocation(line: 0, scope: !10, inlinedAt: !133)
!133 = distinct !DILocation(line: 59, column: 3, scope: !117)
!134 = !DILocation(line: 0, scope: !117)
!135 = distinct !DIAssignID()
!136 = distinct !DIAssignID()
!137 = !DILocation(line: 0, scope: !48, inlinedAt: !133)
!138 = distinct !DIAssignID()
!139 = !DILocation(line: 60, column: 3, scope: !117, atomGroup: 5, atomRank: 1)
