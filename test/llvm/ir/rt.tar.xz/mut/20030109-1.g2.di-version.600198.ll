; MUTANT: di-version debug AutoUpgrade: ignoring debug info with an invalid version (2)
source_filename = "20030109-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.X = type { i32, i32, [0 x i32] }
@x = dso_local local_unnamed_addr global %struct.X { i32 0, i32 40, [0 x i32] zeroinitializer }, align 4, !dbg !0
define dso_local noundef i32 @main() local_unnamed_addr #0 !dbg !21 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @x, i64 4), align 4, !dbg !24
  %2 = icmp eq i32 %1, 40, !dbg !26
  br i1 %2, label %4, label %3, !dbg !27

3:
  tail call void @abort() #2, !dbg !28
  unreachable, !dbg !28

4:
  ret i32 0, !dbg !29
}

declare void @abort() local_unnamed_addr #1
attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!14, !15, !16, !17, !18, !19}
!llvm.ident = !{!20}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !3, line: 14, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20030109-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "3d6a992314cfd811aa7239e0e9d7c263")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "X", file: !3, line: 7, size: 64, elements: !6)
!6 = !{!7, !9, !10}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !5, file: !3, line: 9, baseType: !8, size: 32)
!8 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!9 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !5, file: !3, line: 10, baseType: !8, size: 32, offset: 32)
!10 = !DIDerivedType(tag: DW_TAG_member, name: "z", scope: !5, file: !3, line: 11, baseType: !11, offset: 64)
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, elements: !12)
!12 = !{!13}
!13 = !DISubrange(count: -1)
!14 = !{i32 7, !"Dwarf Version", i32 5}
!15 = !{i32 2, !"Debug Info Version", i32 2}
!16 = !{i32 4, !"probe-stack", !"inline-asm"}
!17 = !{i32 8, !"PIC Level", i32 2}
!18 = !{i32 7, !"PIE Level", i32 2}
!19 = !{i32 7, !"uwtable", i32 2}
!20 = !{!"Alpine clang version 23.1.5"}
!21 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 16, type: !22, scopeLine: 17, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!22 = !DISubroutineType(types: !23)
!23 = !{!8}
!24 = !DILocation(line: 18, column: 9, scope: !25)
!25 = distinct !DILexicalBlock(scope: !21, file: !3, line: 18, column: 7)
!26 = !DILocation(line: 18, column: 11, scope: !25, atomGroup: 1, atomRank: 2)
!27 = !DILocation(line: 18, column: 11, scope: !25, atomGroup: 1, atomRank: 1)
!28 = !DILocation(line: 19, column: 5, scope: !25)
!29 = !DILocation(line: 21, column: 3, scope: !21, atomGroup: 2, atomRank: 1)
