; MUTANT: phimover invalid Verifier: Instruction does not dominate all uses!
source_filename = "20000224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@loop_1 = dso_local local_unnamed_addr global i32 100, align 4
@loop_2 = dso_local local_unnamed_addr global i32 7, align 4
@flag = dso_local local_unnamed_addr global i32 0, align 4
define dso_local noundef i32 @test() local_unnamed_addr #0 {
  %1 = load i32, ptr @loop_1, align 4
  %2 = icmp sgt i32 %1, 0
  br i1 %2, label %3, label %18

3:
  %4 = load i32, ptr @flag, align 4
  %5 = load i32, ptr @loop_2, align 4
  %6 = icmp slt i32 %5, 1
  br label %7

7:
  %8 = phi i32 [ 0, %3 ], [ %14, %7 ]
  %9 = and i32 %10, 1
  %10 = phi i32 [ %4, %3 ], [ %15, %7 ]
  %11 = icmp eq i32 %9, 0
  %12 = select i1 %11, i1 true, i1 %6
  %13 = select i1 %12, i32 0, i32 %5
  %14 = add i32 %8, %13
  %15 = add nsw i32 %10, 1
  %16 = icmp sgt i32 %1, %14
  br i1 %16, label %7, label %17, !llvm.loop !5

17:
  store i32 %15, ptr @flag, align 4
  br label %18

18:
  ret i32 1
}

define dso_local noundef i32 @main() local_unnamed_addr #1 {
  %1 = tail call i32 @test()
  tail call void @exit(i32 noundef 0) #3
  unreachable
}

declare void @exit(i32 noundef) local_unnamed_addr #2
attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
!5 = distinct !{!5, !6}
!6 = !{!"llvm.loop.mustprogress"}
