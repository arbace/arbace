; MUTANT: attr-dup valid
source_filename = "20090113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.descriptor_dimension = type { i32, i32, i32 }
%struct.gfc_array_i4 = type { ptr, i32, [7 x %struct.descriptor_dimension] }
@constinit = private constant [7 x %struct.descriptor_dimension] [%struct.descriptor_dimension { i32 1, i32 1, i32 3 }, %struct.descriptor_dimension { i32 3, i32 1, i32 3 }, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer], align 4
define dso_local void @msum_i4(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 !dbg !10 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca [7 x i32], align 16
  %8 = alloca [7 x i32], align 16
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  store ptr %0, ptr %4, align 8
    #dbg_declare(ptr %4, !36, !DIExpression(), !37)
  store ptr %1, ptr %5, align 8
    #dbg_declare(ptr %5, !38, !DIExpression(), !39)
  store ptr %2, ptr %6, align 8
    #dbg_declare(ptr %6, !40, !DIExpression(), !41)
    #dbg_declare(ptr %7, !42, !DIExpression(), !44)
    #dbg_declare(ptr %8, !45, !DIExpression(), !46)
    #dbg_declare(ptr %9, !47, !DIExpression(), !48)
    #dbg_declare(ptr %10, !49, !DIExpression(), !50)
    #dbg_declare(ptr %11, !51, !DIExpression(), !52)
    #dbg_declare(ptr %12, !53, !DIExpression(), !54)
    #dbg_declare(ptr %13, !55, !DIExpression(), !56)
  %15 = load ptr, ptr %6, align 8, !dbg !57
  %16 = load i32, ptr %15, align 4, !dbg !58
  %17 = sub nsw i32 %16, 1, !dbg !59
  store i32 %17, ptr %11, align 4, !dbg !60
  %18 = load ptr, ptr %5, align 8, !dbg !61
  %19 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %18, i32 0, i32 2, !dbg !62
  %20 = load i32, ptr %11, align 4, !dbg !63
  %21 = sext i32 %20 to i64, !dbg !61
  %22 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %19, i64 0, i64 %21, !dbg !61
  %23 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %22, i32 0, i32 2, !dbg !64
  %24 = load i32, ptr %23, align 4, !dbg !64
  %25 = add nsw i32 %24, 1, !dbg !65
  %26 = load ptr, ptr %5, align 8, !dbg !66
  %27 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %26, i32 0, i32 2, !dbg !67
  %28 = load i32, ptr %11, align 4, !dbg !68
  %29 = sext i32 %28 to i64, !dbg !66
  %30 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %27, i64 0, i64 %29, !dbg !66
  %31 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %30, i32 0, i32 1, !dbg !69
  %32 = load i32, ptr %31, align 4, !dbg !69
  %33 = sub nsw i32 %25, %32, !dbg !70
  store i32 %33, ptr %13, align 4, !dbg !71
  store i32 0, ptr %12, align 4, !dbg !72
  br label %34, !dbg !74

34:
  %35 = load i32, ptr %12, align 4, !dbg !75
  %36 = load i32, ptr %11, align 4, !dbg !77
  %37 = icmp slt i32 %35, %36, !dbg !78
  br i1 %37, label %38, label %64, !dbg !79

38:
  %39 = load ptr, ptr %5, align 8, !dbg !80
  %40 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %39, i32 0, i32 2, !dbg !82
  %41 = load i32, ptr %12, align 4, !dbg !83
  %42 = sext i32 %41 to i64, !dbg !80
  %43 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %40, i64 0, i64 %42, !dbg !80
  %44 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %43, i32 0, i32 2, !dbg !84
  %45 = load i32, ptr %44, align 4, !dbg !84
  %46 = add nsw i32 %45, 1, !dbg !85
  %47 = load ptr, ptr %5, align 8, !dbg !86
  %48 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %47, i32 0, i32 2, !dbg !87
  %49 = load i32, ptr %12, align 4, !dbg !88
  %50 = sext i32 %49 to i64, !dbg !86
  %51 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %48, i64 0, i64 %50, !dbg !86
  %52 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %51, i32 0, i32 1, !dbg !89
  %53 = load i32, ptr %52, align 4, !dbg !89
  %54 = sub nsw i32 %46, %53, !dbg !90
  %55 = load i32, ptr %12, align 4, !dbg !91
  %56 = sext i32 %55 to i64, !dbg !92
  %57 = getelementptr inbounds [7 x i32], ptr %8, i64 0, i64 %56, !dbg !92
  store i32 %54, ptr %57, align 4, !dbg !93
  %58 = load i32, ptr %12, align 4, !dbg !94
  %59 = sext i32 %58 to i64, !dbg !95
  %60 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 %59, !dbg !95
  store i32 0, ptr %60, align 4, !dbg !96
  br label %61, !dbg !97

61:
  %62 = load i32, ptr %12, align 4, !dbg !98
  %63 = add nsw i32 %62, 1, !dbg !98
  store i32 %63, ptr %12, align 4, !dbg !98
  br label %34, !dbg !99, !llvm.loop !100

64:
  %65 = load ptr, ptr %4, align 8, !dbg !103
  %66 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %65, i32 0, i32 0, !dbg !104
  %67 = load ptr, ptr %66, align 8, !dbg !104
  store ptr %67, ptr %9, align 8, !dbg !105
  %68 = load ptr, ptr %5, align 8, !dbg !106
  %69 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %68, i32 0, i32 0, !dbg !107
  %70 = load ptr, ptr %69, align 8, !dbg !107
  store ptr %70, ptr %10, align 8, !dbg !108
  br label %71, !dbg !109

71:
    #dbg_declare(ptr %14, !110, !DIExpression(), !112)
  store i32 0, ptr %14, align 4, !dbg !112
  store i32 0, ptr %12, align 4, !dbg !113
  br label %72, !dbg !115

72:
  %73 = load i32, ptr %12, align 4, !dbg !116
  %74 = load i32, ptr %13, align 4, !dbg !118
  %75 = icmp slt i32 %73, %74, !dbg !119
  br i1 %75, label %76, label %86, !dbg !120

76:
  %77 = load ptr, ptr %10, align 8, !dbg !121
  %78 = load i32, ptr %77, align 4, !dbg !122
  %79 = load i32, ptr %14, align 4, !dbg !123
  %80 = add nsw i32 %79, %78, !dbg !123
  store i32 %80, ptr %14, align 4, !dbg !123
  br label %81, !dbg !124

81:
  %82 = load i32, ptr %12, align 4, !dbg !125
  %83 = add nsw i32 %82, 1, !dbg !125
  store i32 %83, ptr %12, align 4, !dbg !125
  %84 = load ptr, ptr %10, align 8, !dbg !126
  %85 = getelementptr inbounds nuw i32, ptr %84, i32 1, !dbg !126
  store ptr %85, ptr %10, align 8, !dbg !126
  br label %72, !dbg !127, !llvm.loop !128

86:
  %87 = load i32, ptr %14, align 4, !dbg !130
  %88 = load ptr, ptr %9, align 8, !dbg !131
  store i32 %87, ptr %88, align 4, !dbg !132
  %89 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 0, !dbg !133
  %90 = load i32, ptr %89, align 16, !dbg !134
  %91 = add nsw i32 %90, 1, !dbg !134
  store i32 %91, ptr %89, align 16, !dbg !134
  %92 = load ptr, ptr %9, align 8, !dbg !135
  %93 = getelementptr inbounds i32, ptr %92, i64 1, !dbg !135
  store ptr %93, ptr %9, align 8, !dbg !135
  br label %94, !dbg !136

94:
  %95 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 0, !dbg !137
  %96 = load i32, ptr %95, align 16, !dbg !137
  %97 = getelementptr inbounds [7 x i32], ptr %8, i64 0, i64 0, !dbg !138
  %98 = load i32, ptr %97, align 16, !dbg !138
  %99 = icmp ne i32 %96, %98, !dbg !139
  br i1 %99, label %71, label %100, !dbg !136, !llvm.loop !140

100:
  ret void, !dbg !142
}

define dso_local i32 @main() #0 !dbg !143 {
  %1 = alloca i32, align 4
  %2 = alloca [3 x i32], align 4
  %3 = alloca [9 x i32], align 16
  %4 = alloca %struct.gfc_array_i4, align 8
  %5 = alloca %struct.gfc_array_i4, align 8
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !146, !DIExpression(), !150)
    #dbg_declare(ptr %3, !151, !DIExpression(), !155)
    #dbg_declare(ptr %4, !156, !DIExpression(), !157)
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 96, i1 false), !dbg !157
  %7 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 0, !dbg !158
  %8 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 0, !dbg !159
  store ptr %8, ptr %7, align 8, !dbg !158
  %9 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 1, !dbg !158
  store i32 265, ptr %9, align 8, !dbg !158
  %10 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 2, !dbg !158
  %11 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 0, !dbg !160
  store i32 1, ptr %11, align 4, !dbg !160
  %12 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 1, !dbg !160
  store i32 1, ptr %12, align 4, !dbg !160
  %13 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 2, !dbg !160
  store i32 3, ptr %13, align 4, !dbg !160
    #dbg_declare(ptr %5, !161, !DIExpression(), !162)
  %14 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 0, !dbg !163
  %15 = getelementptr inbounds [9 x i32], ptr %3, i64 0, i64 0, !dbg !164
  store ptr %15, ptr %14, align 8, !dbg !163
  %16 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 1, !dbg !163
  store i32 266, ptr %16, align 8, !dbg !163
  %17 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 2, !dbg !163
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %17, ptr align 4 @constinit, i64 84, i1 false), !dbg !165
    #dbg_declare(ptr %6, !166, !DIExpression(), !167)
  store i32 2, ptr %6, align 4, !dbg !167
  call void @msum_i4(ptr noundef %4, ptr noundef %5, ptr noundef %6), !dbg !168
  ret i32 0, !dbg !169
}

declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1
declare void @llvm.memcpy.p0.p0.i64(ptr nest noalias writeonly captures(none), ptr nest noalias readonly captures(none), i64, i1 immarg) #2
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20090113-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "76317d5bd99acd61d6284aff55e5bbda")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "msum_i4", scope: !1, file: !1, line: 14, type: !11, scopeLine: 17, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !35)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13, !13, !32}
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "gfc_array_i4", file: !1, line: 11, baseType: !16)
!16 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !1, line: 7, size: 768, elements: !17)
!17 = !{!18, !21, !22}
!18 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !16, file: !1, line: 8, baseType: !19, size: 64)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "dtype", scope: !16, file: !1, line: 9, baseType: !20, size: 32, offset: 64)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "dim", scope: !16, file: !1, line: 10, baseType: !23, size: 672, offset: 96)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !24, size: 672, elements: !30)
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "descriptor_dimension", file: !1, line: 6, baseType: !25)
!25 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "descriptor_dimension", file: !1, line: 1, size: 96, elements: !26)
!26 = !{!27, !28, !29}
!27 = !DIDerivedType(tag: DW_TAG_member, name: "stride", scope: !25, file: !1, line: 3, baseType: !20, size: 32)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "lbound", scope: !25, file: !1, line: 4, baseType: !20, size: 32, offset: 32)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "ubound", scope: !25, file: !1, line: 5, baseType: !20, size: 32, offset: 64)
!30 = !{!31}
!31 = !DISubrange(count: 7)
!32 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !33)
!33 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !34, size: 64)
!34 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!35 = !{}
!36 = !DILocalVariable(name: "retarray", arg: 1, scope: !10, file: !1, line: 14, type: !13)
!37 = !DILocation(line: 14, column: 31, scope: !10)
!38 = !DILocalVariable(name: "array", arg: 2, scope: !10, file: !1, line: 15, type: !13)
!39 = !DILocation(line: 15, column: 24, scope: !10)
!40 = !DILocalVariable(name: "pdim", arg: 3, scope: !10, file: !1, line: 16, type: !32)
!41 = !DILocation(line: 16, column: 21, scope: !10)
!42 = !DILocalVariable(name: "count", scope: !10, file: !1, line: 18, type: !43)
!43 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 224, elements: !30)
!44 = !DILocation(line: 18, column: 7, scope: !10)
!45 = !DILocalVariable(name: "extent", scope: !10, file: !1, line: 19, type: !43)
!46 = !DILocation(line: 19, column: 7, scope: !10)
!47 = !DILocalVariable(name: "dest", scope: !10, file: !1, line: 20, type: !19)
!48 = !DILocation(line: 20, column: 9, scope: !10)
!49 = !DILocalVariable(name: "base", scope: !10, file: !1, line: 21, type: !33)
!50 = !DILocation(line: 21, column: 15, scope: !10)
!51 = !DILocalVariable(name: "dim", scope: !10, file: !1, line: 22, type: !20)
!52 = !DILocation(line: 22, column: 7, scope: !10)
!53 = !DILocalVariable(name: "n", scope: !10, file: !1, line: 23, type: !20)
!54 = !DILocation(line: 23, column: 7, scope: !10)
!55 = !DILocalVariable(name: "len", scope: !10, file: !1, line: 24, type: !20)
!56 = !DILocation(line: 24, column: 7, scope: !10)
!57 = !DILocation(line: 26, column: 11, scope: !10)
!58 = !DILocation(line: 26, column: 10, scope: !10)
!59 = !DILocation(line: 26, column: 17, scope: !10)
!60 = !DILocation(line: 26, column: 7, scope: !10)
!61 = !DILocation(line: 27, column: 9, scope: !10)
!62 = !DILocation(line: 27, column: 16, scope: !10)
!63 = !DILocation(line: 27, column: 20, scope: !10)
!64 = !DILocation(line: 27, column: 25, scope: !10)
!65 = !DILocation(line: 27, column: 32, scope: !10)
!66 = !DILocation(line: 27, column: 38, scope: !10)
!67 = !DILocation(line: 27, column: 45, scope: !10)
!68 = !DILocation(line: 27, column: 49, scope: !10)
!69 = !DILocation(line: 27, column: 54, scope: !10)
!70 = !DILocation(line: 27, column: 36, scope: !10)
!71 = !DILocation(line: 27, column: 7, scope: !10)
!72 = !DILocation(line: 29, column: 10, scope: !73)
!73 = distinct !DILexicalBlock(scope: !10, file: !1, line: 29, column: 3)
!74 = !DILocation(line: 29, column: 8, scope: !73)
!75 = !DILocation(line: 29, column: 15, scope: !76)
!76 = distinct !DILexicalBlock(scope: !73, file: !1, line: 29, column: 3)
!77 = !DILocation(line: 29, column: 19, scope: !76)
!78 = !DILocation(line: 29, column: 17, scope: !76)
!79 = !DILocation(line: 29, column: 3, scope: !73)
!80 = !DILocation(line: 31, column: 19, scope: !81)
!81 = distinct !DILexicalBlock(scope: !76, file: !1, line: 30, column: 5)
!82 = !DILocation(line: 31, column: 26, scope: !81)
!83 = !DILocation(line: 31, column: 30, scope: !81)
!84 = !DILocation(line: 31, column: 33, scope: !81)
!85 = !DILocation(line: 31, column: 40, scope: !81)
!86 = !DILocation(line: 31, column: 46, scope: !81)
!87 = !DILocation(line: 31, column: 53, scope: !81)
!88 = !DILocation(line: 31, column: 57, scope: !81)
!89 = !DILocation(line: 31, column: 60, scope: !81)
!90 = !DILocation(line: 31, column: 44, scope: !81)
!91 = !DILocation(line: 31, column: 14, scope: !81)
!92 = !DILocation(line: 31, column: 7, scope: !81)
!93 = !DILocation(line: 31, column: 17, scope: !81)
!94 = !DILocation(line: 32, column: 13, scope: !81)
!95 = !DILocation(line: 32, column: 7, scope: !81)
!96 = !DILocation(line: 32, column: 16, scope: !81)
!97 = !DILocation(line: 33, column: 5, scope: !81)
!98 = !DILocation(line: 29, column: 25, scope: !76)
!99 = !DILocation(line: 29, column: 3, scope: !76)
!100 = distinct !{!100, !79, !101, !102}
!101 = !DILocation(line: 33, column: 5, scope: !73)
!102 = !{!"llvm.loop.mustprogress"}
!103 = !DILocation(line: 35, column: 10, scope: !10)
!104 = !DILocation(line: 35, column: 20, scope: !10)
!105 = !DILocation(line: 35, column: 8, scope: !10)
!106 = !DILocation(line: 36, column: 10, scope: !10)
!107 = !DILocation(line: 36, column: 17, scope: !10)
!108 = !DILocation(line: 36, column: 8, scope: !10)
!109 = !DILocation(line: 38, column: 3, scope: !10)
!110 = !DILocalVariable(name: "result", scope: !111, file: !1, line: 40, type: !20)
!111 = distinct !DILexicalBlock(scope: !10, file: !1, line: 39, column: 5)
!112 = !DILocation(line: 40, column: 11, scope: !111)
!113 = !DILocation(line: 42, column: 14, scope: !114)
!114 = distinct !DILexicalBlock(scope: !111, file: !1, line: 42, column: 7)
!115 = !DILocation(line: 42, column: 12, scope: !114)
!116 = !DILocation(line: 42, column: 19, scope: !117)
!117 = distinct !DILexicalBlock(scope: !114, file: !1, line: 42, column: 7)
!118 = !DILocation(line: 42, column: 23, scope: !117)
!119 = !DILocation(line: 42, column: 21, scope: !117)
!120 = !DILocation(line: 42, column: 7, scope: !114)
!121 = !DILocation(line: 43, column: 13, scope: !117)
!122 = !DILocation(line: 43, column: 12, scope: !117)
!123 = !DILocation(line: 43, column: 9, scope: !117)
!124 = !DILocation(line: 43, column: 2, scope: !117)
!125 = !DILocation(line: 42, column: 29, scope: !117)
!126 = !DILocation(line: 42, column: 37, scope: !117)
!127 = !DILocation(line: 42, column: 7, scope: !117)
!128 = distinct !{!128, !120, !129, !102}
!129 = !DILocation(line: 43, column: 13, scope: !114)
!130 = !DILocation(line: 44, column: 15, scope: !111)
!131 = !DILocation(line: 44, column: 8, scope: !111)
!132 = !DILocation(line: 44, column: 13, scope: !111)
!133 = !DILocation(line: 46, column: 7, scope: !111)
!134 = !DILocation(line: 46, column: 15, scope: !111)
!135 = !DILocation(line: 47, column: 12, scope: !111)
!136 = !DILocation(line: 48, column: 5, scope: !111)
!137 = !DILocation(line: 49, column: 10, scope: !10)
!138 = !DILocation(line: 49, column: 22, scope: !10)
!139 = !DILocation(line: 49, column: 19, scope: !10)
!140 = distinct !{!140, !109, !141, !102}
!141 = !DILocation(line: 49, column: 31, scope: !10)
!142 = !DILocation(line: 50, column: 1, scope: !10)
!143 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 52, type: !144, scopeLine: 53, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !35)
!144 = !DISubroutineType(types: !145)
!145 = !{!20}
!146 = !DILocalVariable(name: "rdata", scope: !143, file: !1, line: 54, type: !147)
!147 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 96, elements: !148)
!148 = !{!149}
!149 = !DISubrange(count: 3)
!150 = !DILocation(line: 54, column: 7, scope: !143)
!151 = !DILocalVariable(name: "adata", scope: !143, file: !1, line: 55, type: !152)
!152 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 288, elements: !153)
!153 = !{!154}
!154 = !DISubrange(count: 9)
!155 = !DILocation(line: 55, column: 7, scope: !143)
!156 = !DILocalVariable(name: "retarray", scope: !143, file: !1, line: 56, type: !15)
!157 = !DILocation(line: 56, column: 16, scope: !143)
!158 = !DILocation(line: 56, column: 27, scope: !143)
!159 = !DILocation(line: 56, column: 29, scope: !143)
!160 = !DILocation(line: 56, column: 43, scope: !143)
!161 = !DILocalVariable(name: "array", scope: !143, file: !1, line: 57, type: !15)
!162 = !DILocation(line: 57, column: 16, scope: !143)
!163 = !DILocation(line: 57, column: 24, scope: !143)
!164 = !DILocation(line: 57, column: 26, scope: !143)
!165 = !DILocation(line: 57, column: 38, scope: !143)
!166 = !DILocalVariable(name: "dim", scope: !143, file: !1, line: 58, type: !20)
!167 = !DILocation(line: 58, column: 7, scope: !143)
!168 = !DILocation(line: 59, column: 3, scope: !143)
!169 = !DILocation(line: 60, column: 3, scope: !143)
