; MUTANT: di-record debug Verifier: invalid #dbg record variable
source_filename = "20020418-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.foo = type { i32 }
define dso_local void @gcc_crash(ptr noundef %0) #0 !dbg !10 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !17, !DIExpression(), !20)
  %3 = load ptr, ptr %2, align 8, !dbg !21
  %4 = getelementptr inbounds nuw %struct.foo, ptr %3, i32 0, i32 0, !dbg !23
  %5 = load i32, ptr %4, align 4, !dbg !23
  %6 = icmp slt i32 %5, 52, !dbg !24
  %7 = zext i1 %6 to i32, !dbg !24
  %8 = sext i32 %7 to i64, !dbg !21
  %9 = icmp ne i64 %8, 0, !dbg !25
  br i1 %9, label %10, label %11, !dbg !25

10:
  call void @llvm.trap(), !dbg !26
  br label %11, !dbg !26

11:
  br label %12, !dbg !27

12:
    #dbg_label(!28, !29)
  %13 = load ptr, ptr %2, align 8, !dbg !30
  %14 = getelementptr inbounds nuw %struct.foo, ptr %13, i32 0, i32 0, !dbg !31
  %15 = load i32, ptr %14, align 4, !dbg !32
  %16 = add nsw i32 %15, 1, !dbg !32
  store i32 %16, ptr %14, align 4, !dbg !32
  %17 = load ptr, ptr %2, align 8, !dbg !33
  %18 = getelementptr inbounds nuw %struct.foo, ptr %17, i32 0, i32 0, !dbg !35
  %19 = load i32, ptr %18, align 4, !dbg !35
  %20 = icmp sge i32 %19, 62, !dbg !36
  br i1 %20, label %21, label %22, !dbg !36

21:
  br label %12, !dbg !37

22:
  ret void, !dbg !38
}

declare void @llvm.trap() #1
define dso_local i32 @main() #0 !dbg !39 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.foo, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !42, !DIExpression(), !43)
  %3 = getelementptr inbounds nuw %struct.foo, ptr %2, i32 0, i32 0, !dbg !44
  store i32 53, ptr %3, align 4, !dbg !45
  call void @gcc_crash(ptr noundef %2), !dbg !46
  call void @exit(i32 noundef 0) #3, !dbg !47
  unreachable, !dbg !47
}

declare void @exit(i32 noundef) #2
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20020418-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "7c58b6e71b5d8bdfcaddad22ed6bd60d")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "gcc_crash", scope: !1, file: !1, line: 8, type: !11, scopeLine: 9, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !18)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13}
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "foo", file: !1, line: 6, size: 32, elements: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !14, file: !1, line: 6, baseType: !17, size: 32)
!17 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!18 = !{}
!19 = !DILocalVariable(name: "p", arg: 1, scope: !10, file: !1, line: 8, type: !13)
!20 = !DILocation(line: 8, column: 28, scope: !10)
!21 = !DILocation(line: 10, column: 23, scope: !22)
!22 = distinct !DILexicalBlock(scope: !10, file: !1, line: 10, column: 6)
!23 = !DILocation(line: 10, column: 26, scope: !22)
!24 = !DILocation(line: 10, column: 28, scope: !22)
!25 = !DILocation(line: 10, column: 6, scope: !22)
!26 = !DILocation(line: 11, column: 3, scope: !22)
!27 = !DILocation(line: 10, column: 35, scope: !22)
!28 = !DILabel(scope: !10, name: "top", file: !1, line: 12, column: 2)
!29 = !DILocation(line: 12, column: 2, scope: !10)
!30 = !DILocation(line: 13, column: 2, scope: !10)
!31 = !DILocation(line: 13, column: 5, scope: !10)
!32 = !DILocation(line: 13, column: 6, scope: !10)
!33 = !DILocation(line: 14, column: 6, scope: !34)
!34 = distinct !DILexicalBlock(scope: !10, file: !1, line: 14, column: 6)
!35 = !DILocation(line: 14, column: 9, scope: !34)
!36 = !DILocation(line: 14, column: 11, scope: !34)
!37 = !DILocation(line: 15, column: 3, scope: !34)
!38 = !DILocation(line: 16, column: 1, scope: !10)
!39 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 18, type: !40, scopeLine: 19, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !18)
!40 = !DISubroutineType(types: !41)
!41 = !{!17}
!42 = !DILocalVariable(name: "x", scope: !39, file: !1, line: 20, type: !14)
!43 = !DILocation(line: 20, column: 13, scope: !39)
!44 = !DILocation(line: 22, column: 4, scope: !39)
!45 = !DILocation(line: 22, column: 6, scope: !39)
!46 = !DILocation(line: 23, column: 2, scope: !39)
!47 = !DILocation(line: 25, column: 2, scope: !39)
