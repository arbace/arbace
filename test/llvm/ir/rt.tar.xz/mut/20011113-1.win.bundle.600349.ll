; MUTANT: bundle valid
source_filename = "20011113-1.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"
@t = dso_local global { i8, i8, i8, i8, [4 x i32] } { i8 26, i8 0, i8 0, i8 0, [4 x i32] [i32 0, i32 21, i32 22, i32 23] }, align 8
define dso_local noalias noundef ptr @foo(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i32, ptr %2, align 4
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %7 = load i32, ptr %6, align 4
  %8 = icmp eq i32 %3, 21
  %9 = icmp eq i32 %5, 22
  %10 = select i1 %8, i1 %9, i1 false
  %11 = icmp eq i32 %7, 23
  %12 = select i1 %10, i1 %11, i1 false
  br i1 %12, label %14, label %13

13:
  tail call void @abort() #4 [ "foo"(i32 1) ]
  unreachable

14:
  ret ptr null
}

define dso_local noalias noundef ptr @bar(ptr nofree noundef readonly align 4 captures(none) dead_on_return %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = load i32, ptr %0, align 4
  %4 = icmp eq i32 %3, 21
  br i1 %4, label %5, label %13

5:
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 4
  %7 = load i32, ptr %6, align 4
  %8 = icmp eq i32 %7, 22
  br i1 %8, label %9, label %13

9:
  %10 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 23
  br i1 %12, label %14, label %13

13:
  tail call void @abort() #4
  unreachable

14:
  ret ptr null
}

define dso_local noalias noundef ptr @baz(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i32, ptr %2, align 4
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 12
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %7 = load i32, ptr %6, align 4
  %8 = icmp eq i32 %3, 21
  %9 = icmp eq i32 %5, 22
  %10 = select i1 %8, i1 %9, i1 false
  %11 = icmp eq i32 %7, 23
  %12 = select i1 %10, i1 %11, i1 false
  br i1 %12, label %14, label %13

13:
  tail call void @abort() #4
  unreachable

14:
  ret ptr null
}

declare dso_local void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  %1 = tail call ptr @baz(ptr noundef nonnull @t)
  %2 = tail call ptr @foo(ptr noundef nonnull @t)
  tail call void @exit(i32 noundef 0) #4
  unreachable
}

declare dso_local void @exit(i32 noundef) local_unnamed_addr #3
attributes #0 = { nofree nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20011113-1.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
