; MUTANT: noterm invalid LLParser: expected instruction opcode
source_filename = "20090113-1.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"
define dso_local void @msum_i4(ptr nofree noundef readonly captures(none) %0, ptr nofree noundef readonly captures(none) %1, ptr nofree noundef readonly captures(none) %2) local_unnamed_addr #0 {
  %4 = alloca [7 x i32], align 4
  %5 = alloca [7 x i32], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %4)
  call void @llvm.lifetime.start.p0(ptr nonnull %5) #6
  %6 = load i32, ptr %2, align 4
  %7 = add i32 %6, -1
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 12
  %9 = sext i32 %7 to i64
  %10 = getelementptr inbounds [12 x i8], ptr %8, i64 %9
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %12 = load i32, ptr %11, align 4
  %13 = add i32 %12, 1
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 4
  %15 = load i32, ptr %14, align 4
  %16 = sub i32 %13, %15
  %17 = icmp sgt i32 %7, 0
  br i1 %17, label %18, label %64

18:
  %19 = zext nneg i32 %7 to i64
  %20 = shl nuw nsw i64 %19, 2
  call void @llvm.memset.p0.i64(ptr nonnull align 4 %4, i8 0, i64 %20, i1 false)
  %21 = and i64 %19, 1
  %22 = icmp eq i32 %7, 1
  br i1 %22, label %50, label %23

23:
  %24 = and i64 %19, 2147483646
  br label %25

25:
  %26 = phi i64 [ 0, %23 ], [ %45, %25 ]
  %27 = phi i64 [ 0, %23 ], [ %46, %25 ]
  %28 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %26
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 8
  %30 = load i32, ptr %29, align 4
  %31 = add i32 %30, 1
  %32 = getelementptr inbounds nuw i8, ptr %28, i64 4
  %33 = load i32, ptr %32, align 4
  %34 = sub i32 %31, %33
  %35 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %26
  store i32 %34, ptr %35, align 4
  %36 = or disjoint i64 %26, 1
  %37 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %36
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 8
  %39 = load i32, ptr %38, align 4
  %40 = add i32 %39, 1
  %41 = getelementptr inbounds nuw i8, ptr %37, i64 4
  %42 = load i32, ptr %41, align 4
  %43 = sub i32 %40, %42
  %44 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %36
  store i32 %43, ptr %44, align 4
  %45 = add nuw nsw i64 %26, 2
  %46 = add i64 %27, 2
  %47 = icmp eq i64 %46, %24
  br i1 %47, label %48, label %25, !llvm.loop !7

48:
  %49 = icmp eq i64 %21, 0
  br i1 %49, label %61, label %50

50:
  %51 = phi i64 [ 0, %18 ], [ %45, %48 ]
  %52 = trunc i32 %7 to i1
  tail call void @llvm.assume(i1 %52)
  %53 = getelementptr inbounds nuw [12 x i8], ptr %8, i64 %51
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 8
  %55 = load i32, ptr %54, align 4
  %56 = add i32 %55, 1
  %57 = getelementptr inbounds nuw i8, ptr %53, i64 4
  %58 = load i32, ptr %57, align 4
  %59 = sub i32 %56, %58
  %60 = getelementptr inbounds nuw [4 x i8], ptr %5, i64 %51
  store i32 %59, ptr %60, align 4
  br label %61

61:
  %62 = load i32, ptr %5, align 4
  %63 = load i32, ptr %4, align 4

64:
  %65 = phi i32 [ %63, %61 ], [ undef, %3 ]
  %66 = phi i32 [ %62, %61 ], [ undef, %3 ]
  %67 = load ptr, ptr %0, align 8
  %68 = load ptr, ptr %1, align 8
  %69 = icmp sgt i32 %16, 0
  %70 = zext nneg i32 %16 to i64
  %71 = icmp ult i32 %16, 8
  %72 = and i64 %70, 2147483640
  %73 = trunc nuw nsw i64 %72 to i32
  %74 = shl nuw nsw i64 %72, 2
  %75 = icmp eq i64 %72, %70
  br label %76

76:
  %77 = phi i32 [ %65, %64 ], [ %115, %112 ]
  %78 = phi ptr [ %68, %64 ], [ %113, %112 ]
  %79 = phi ptr [ %67, %64 ], [ %116, %112 ]
  br i1 %69, label %80, label %112

80:
  br i1 %71, label %99, label %81

81:
  %82 = getelementptr i8, ptr %78, i64 %74
  br label %83

83:
  %84 = phi i64 [ 0, %81 ], [ %94, %83 ]
  %85 = phi <4 x i32> [ zeroinitializer, %81 ], [ %92, %83 ]
  %86 = phi <4 x i32> [ zeroinitializer, %81 ], [ %93, %83 ]
  %87 = shl i64 %84, 2
  %88 = getelementptr i8, ptr %78, i64 %87
  %89 = getelementptr i8, ptr %88, i64 16
  %90 = load <4 x i32>, ptr %88, align 4
  %91 = load <4 x i32>, ptr %89, align 4
  %92 = add <4 x i32> %90, %85
  %93 = add <4 x i32> %91, %86
  %94 = add nuw i64 %84, 8
  %95 = icmp eq i64 %94, %72
  br i1 %95, label %96, label %83, !llvm.loop !9

96:
  %97 = add <4 x i32> %93, %92
  %98 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %97)
  br i1 %75, label %112, label %99

99:
  %100 = phi i32 [ 0, %80 ], [ %98, %96 ]
  %101 = phi i32 [ 0, %80 ], [ %73, %96 ]
  %102 = phi ptr [ %78, %80 ], [ %82, %96 ]
  br label %103

103:
  %104 = phi i32 [ %108, %103 ], [ %100, %99 ]
  %105 = phi i32 [ %109, %103 ], [ %101, %99 ]
  %106 = phi ptr [ %110, %103 ], [ %102, %99 ]
  %107 = load i32, ptr %106, align 4
  %108 = add i32 %107, %104
  %109 = add nuw nsw i32 %105, 1
  %110 = getelementptr inbounds nuw i8, ptr %106, i64 4
  %111 = icmp eq i32 %109, %16
  br i1 %111, label %112, label %103, !llvm.loop !12

112:
  %113 = phi ptr [ %78, %76 ], [ %82, %96 ], [ %110, %103 ]
  %114 = phi i32 [ 0, %76 ], [ %98, %96 ], [ %108, %103 ]
  store i32 %114, ptr %79, align 4
  %115 = add i32 %77, 1
  store i32 %115, ptr %4, align 4
  %116 = getelementptr inbounds nuw i8, ptr %79, i64 4
  %117 = icmp eq i32 %115, %66
  br i1 %117, label %118, label %76, !llvm.loop !13

118:
  call void @llvm.lifetime.end.p0(ptr nonnull %5) #6
  call void @llvm.lifetime.end.p0(ptr nonnull %4)
  ret void
}

declare void @llvm.lifetime.start.p0(ptr captures(none)) #1
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  ret i32 0
}

declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #4
declare void @llvm.assume(i1 noundef) #5
attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nosync nounwind memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #6 = { nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20090113-1.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !8, !11, !10}
!13 = distinct !{!13, !8}
