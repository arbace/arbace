; MUTANT: di-version debug AutoUpgrade: ignoring debug info with an invalid version (7)
source_filename = "20070424-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local void @do_exit() #0 !dbg !10 {
  call void @exit(i32 noundef 0) #3, !dbg !13
  unreachable, !dbg !13
}

declare void @exit(i32 noundef) #1
define dso_local void @do_abort() #0 !dbg !14 {
  call void @abort() #4, !dbg !15
  unreachable, !dbg !15
}

declare void @abort() #2
define dso_local void @foo(i32 noundef %0, i32 noundef %1) #0 !dbg !16 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
    #dbg_declare(ptr %3, !21, !DIExpression(), !22)
  store i32 %1, ptr %4, align 4
    #dbg_declare(ptr %4, !23, !DIExpression(), !24)
  %5 = load i32, ptr %3, align 4, !dbg !25
  %6 = load i32, ptr %4, align 4, !dbg !27
  %7 = icmp slt i32 %5, %6, !dbg !28
  br i1 %7, label %8, label %9, !dbg !28

8:
  br label %15, !dbg !29

9:
  call void @do_exit(), !dbg !30
  %10 = load i32, ptr %3, align 4, !dbg !31
  %11 = load i32, ptr %4, align 4, !dbg !33
  %12 = icmp ne i32 %10, %11, !dbg !34
  br i1 %12, label %13, label %14, !dbg !34

13:
  br label %15, !dbg !35

14:
  call void @do_abort(), !dbg !36
  br label %16, !dbg !37

15:
    #dbg_label(!38, !39)
  call void @do_abort(), !dbg !40
  br label %16, !dbg !41

16:
  ret void, !dbg !41
}

define dso_local i32 @main() #0 !dbg !42 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @foo(i32 noundef 1, i32 noundef 0), !dbg !45
  ret i32 0, !dbg !46
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn }
attributes #4 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20070424-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "2c73e84807d122c6366d637e4cc43eb2")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 7}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "do_exit", scope: !1, file: !1, line: 4, type: !11, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!11 = !DISubroutineType(types: !12)
!12 = !{null}
!13 = !DILocation(line: 4, column: 23, scope: !10)
!14 = distinct !DISubprogram(name: "do_abort", scope: !1, file: !1, line: 5, type: !11, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!15 = !DILocation(line: 5, column: 24, scope: !14)
!16 = distinct !DISubprogram(name: "foo", scope: !1, file: !1, line: 7, type: !17, scopeLine: 8, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !20)
!17 = !DISubroutineType(types: !18)
!18 = !{null, !19, !19}
!19 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!20 = !{}
!21 = !DILocalVariable(name: "x", arg: 1, scope: !16, file: !1, line: 7, type: !19)
!22 = !DILocation(line: 7, column: 15, scope: !16)
!23 = !DILocalVariable(name: "a", arg: 2, scope: !16, file: !1, line: 7, type: !19)
!24 = !DILocation(line: 7, column: 22, scope: !16)
!25 = !DILocation(line: 9, column: 7, scope: !26)
!26 = distinct !DILexicalBlock(scope: !16, file: !1, line: 9, column: 7)
!27 = !DILocation(line: 9, column: 11, scope: !26)
!28 = !DILocation(line: 9, column: 9, scope: !26)
!29 = !DILocation(line: 10, column: 5, scope: !26)
!30 = !DILocation(line: 11, column: 3, scope: !16)
!31 = !DILocation(line: 12, column: 7, scope: !32)
!32 = distinct !DILexicalBlock(scope: !16, file: !1, line: 12, column: 7)
!33 = !DILocation(line: 12, column: 12, scope: !32)
!34 = !DILocation(line: 12, column: 9, scope: !32)
!35 = !DILocation(line: 13, column: 5, scope: !32)
!36 = !DILocation(line: 16, column: 3, scope: !16)
!37 = !DILocation(line: 17, column: 3, scope: !16)
!38 = !DILabel(scope: !16, name: "doit", file: !1, line: 19, column: 1)
!39 = !DILocation(line: 19, column: 1, scope: !16)
!40 = !DILocation(line: 20, column: 3, scope: !16)
!41 = !DILocation(line: 21, column: 1, scope: !16)
!42 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 23, type: !43, scopeLine: 24, spFlags: DISPFlagDefinition, unit: !0)
!43 = !DISubroutineType(types: !44)
!44 = !{!19}
!45 = !DILocation(line: 25, column: 3, scope: !42)
!46 = !DILocation(line: 26, column: 3, scope: !42)
