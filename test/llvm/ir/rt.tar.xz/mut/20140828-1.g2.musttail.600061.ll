; MUTANT: musttail invalid Verifier: cannot guarantee tail call due to mismatched return types
source_filename = "20140828-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local nonnull ptr @f(ptr nofree noundef readonly captures(ret: address, provenance) %0, i32 noundef %1, ptr nofree noundef writeonly captures(none) initializes((0, 4)) %2) local_unnamed_addr #0 !dbg !10 {
    #dbg_value(ptr %0, !18, !DIExpression(), !22)
    #dbg_value(i32 %1, !19, !DIExpression(), !22)
    #dbg_value(ptr %2, !20, !DIExpression(), !22)
  %4 = load i16, ptr %0, align 2, !dbg !23
    #dbg_value(i16 %4, !21, !DIExpression(), !22)
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 2, !dbg !24
    #dbg_value(ptr %5, !18, !DIExpression(), !22)
  %6 = zext nneg i16 %4 to i32, !dbg !25
  %7 = shl i32 %1, %6, !dbg !25
    #dbg_value(i32 %7, !21, !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_stack_value), !22)
  %8 = shl i32 %7, 16, !dbg !26
  %9 = ashr exact i32 %8, 16, !dbg !26
  store i32 %9, ptr %2, align 4, !dbg !27
  ret ptr %5, !dbg !28
}

declare void @llvm.lifetime.start.p0(ptr captures(none)) #1
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !29 {
  %1 = alloca i32, align 4, !DIAssignID !38
    #dbg_assign(i1 poison, !33, !DIExpression(), !38, ptr %1, !DIExpression(), !39)
  %2 = alloca [2 x i16], align 2, !DIAssignID !40
    #dbg_assign(i1 poison, !34, !DIExpression(), !40, ptr %2, !DIExpression(), !39)
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4, !dbg !41
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4, !dbg !42
  store i16 0, ptr %2, align 2, !dbg !43, !DIAssignID !44
    #dbg_assign(i16 0, !34, !DIExpression(DW_OP_LLVM_fragment, 0, 16), !44, ptr %2, !DIExpression(), !39)
  %3 = call ptr @f(ptr noundef nonnull %2, i32 noundef 1, ptr noundef nonnull %1), !dbg !45
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 2, !dbg !47
  %5 = icmp eq ptr %3, %4, !dbg !48
  br i1 %5, label %7, label %6, !dbg !49

6:
  call void @abort() #5, !dbg !50
  unreachable, !dbg !50

7:
  %8 = load i32, ptr %1, align 4, !dbg !51
  %9 = icmp eq i32 %8, 1, !dbg !53
  br i1 %9, label %11, label %10, !dbg !54

10:
  call void @abort() #5, !dbg !55
  unreachable, !dbg !55

11:
  musttail call void @llvm.lifetime.end.p0(ptr nonnull %2) #4, !dbg !56
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4, !dbg !56
  ret i32 0, !dbg !57
}

declare void @abort() local_unnamed_addr #3
attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind }
attributes #5 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20140828-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "4f2d437fe200efe831474db8c9c46fa5")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "f", scope: !1, file: !1, line: 3, type: !11, scopeLine: 4, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !17, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{!13, !13, !15, !16}
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!17 = !{!18, !19, !20, !21}
!18 = !DILocalVariable(name: "a", arg: 1, scope: !10, file: !1, line: 3, type: !13)
!19 = !DILocalVariable(name: "b", arg: 2, scope: !10, file: !1, line: 3, type: !15)
!20 = !DILocalVariable(name: "d", arg: 3, scope: !10, file: !1, line: 3, type: !16)
!21 = !DILocalVariable(name: "c", scope: !10, file: !1, line: 5, type: !14)
!22 = !DILocation(line: 0, scope: !10)
!23 = !DILocation(line: 5, column: 13, scope: !10, atomGroup: 1, atomRank: 2)
!24 = !DILocation(line: 6, column: 4, scope: !10, atomGroup: 2, atomRank: 2)
!25 = !DILocation(line: 7, column: 9, scope: !10, atomGroup: 3, atomRank: 3)
!26 = !DILocation(line: 8, column: 8, scope: !10, atomGroup: 4, atomRank: 2)
!27 = !DILocation(line: 8, column: 6, scope: !10, atomGroup: 4, atomRank: 1)
!28 = !DILocation(line: 9, column: 3, scope: !10, atomGroup: 6, atomRank: 1)
!29 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 12, type: !30, scopeLine: 13, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !32, keyInstructions: true)
!30 = !DISubroutineType(types: !31)
!31 = !{!15}
!32 = !{!33, !34}
!33 = !DILocalVariable(name: "d", scope: !29, file: !1, line: 14, type: !15)
!34 = !DILocalVariable(name: "a", scope: !29, file: !1, line: 15, type: !35)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !14, size: 32, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 2)
!38 = distinct !DIAssignID()
!39 = !DILocation(line: 0, scope: !29)
!40 = distinct !DIAssignID()
!41 = !DILocation(line: 14, column: 3, scope: !29)
!42 = !DILocation(line: 15, column: 3, scope: !29)
!43 = !DILocation(line: 16, column: 8, scope: !29, atomGroup: 1, atomRank: 1)
!44 = distinct !DIAssignID()
!45 = !DILocation(line: 17, column: 7, scope: !46)
!46 = distinct !DILexicalBlock(scope: !29, file: !1, line: 17, column: 7)
!47 = !DILocation(line: 17, column: 23, scope: !46)
!48 = !DILocation(line: 17, column: 19, scope: !46, atomGroup: 2, atomRank: 2)
!49 = !DILocation(line: 17, column: 19, scope: !46, atomGroup: 2, atomRank: 1)
!50 = !DILocation(line: 18, column: 5, scope: !46)
!51 = !DILocation(line: 19, column: 7, scope: !52)
!52 = distinct !DILexicalBlock(scope: !29, file: !1, line: 19, column: 7)
!53 = !DILocation(line: 19, column: 9, scope: !52, atomGroup: 3, atomRank: 2)
!54 = !DILocation(line: 19, column: 9, scope: !52, atomGroup: 3, atomRank: 1)
!55 = !DILocation(line: 20, column: 5, scope: !52)
!56 = !DILocation(line: 22, column: 1, scope: !29)
!57 = !DILocation(line: 21, column: 3, scope: !29, atomGroup: 5, atomRank: 1)
