; MUTANT: noterm invalid LLParser: expected instruction opcode
source_filename = "20011113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.U = type { [3 x i64] }
@t = dso_local global { i8, i8, i8, i8, [4 x i8], [4 x i64] } { i8 26, i8 0, i8 0, i8 0, [4 x i8] zeroinitializer, [4 x i64] [i64 0, i64 21, i64 22, i64 23] }, align 8, !dbg !0
define dso_local noalias noundef ptr @foo(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !24 {
    #dbg_value(ptr %0, !30, !DIExpression(), !40)
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16, !dbg !41
  %3 = load i64, ptr %2, align 8, !dbg !42
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 24, !dbg !42
  %5 = load i64, ptr %4, align 8, !dbg !42
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32, !dbg !42
  %7 = load i64, ptr %6, align 8, !dbg !42
    #dbg_value(i64 %3, !39, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !40)
    #dbg_value(i64 %5, !39, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !40)
    #dbg_value(i64 %7, !39, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !40)
    #dbg_value(i64 %3, !31, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !40)
    #dbg_value(i64 %5, !31, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !40)
    #dbg_value(i64 %7, !31, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !40)
    #dbg_value(i64 %3, !43, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !49)
    #dbg_value(i64 %5, !43, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !49)
    #dbg_value(i64 %7, !43, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !49)
    #dbg_value(i32 poison, !48, !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value), !49)
  %8 = icmp ne i64 %3, 21, !dbg !51
  %9 = icmp ne i64 %5, 22
  %10 = select i1 %8, i1 true, i1 %9, !dbg !53
  %11 = icmp ne i64 %7, 23
  %12 = select i1 %10, i1 true, i1 %11, !dbg !53
  br i1 %12, label %13, label %14, !dbg !53

13:
  tail call void @abort() #4, !dbg !54

14:
  ret ptr null, !dbg !55
}

define dso_local noalias noundef ptr @bar(ptr nofree noundef readonly byval(%struct.U) align 8 captures(none) %0, i32 noundef %1) local_unnamed_addr #0 !dbg !44 {
    #dbg_declare(ptr %0, !43, !DIExpression(), !56)
    #dbg_value(i32 %1, !48, !DIExpression(), !57)
  %3 = load i64, ptr %0, align 8, !dbg !58
  %4 = icmp ne i64 %3, 21, !dbg !59
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp ne i64 %6, 22
  %8 = select i1 %4, i1 true, i1 %7, !dbg !60
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, 23
  %12 = select i1 %8, i1 true, i1 %11, !dbg !60
  br i1 %12, label %13, label %14, !dbg !60

13:
  tail call void @abort() #4, !dbg !61
  unreachable, !dbg !61

14:
  ret ptr null, !dbg !62
}

define dso_local noalias noundef ptr @baz(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !63 {
    #dbg_value(ptr %0, !65, !DIExpression(), !68)
    #dbg_value(i64 4886718345, !66, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !68)
    #dbg_value(i64 68414056839, !66, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !68)
    #dbg_value(i64 46118400291, !66, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !68)
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16, !dbg !69
  %3 = load i64, ptr %2, align 8, !dbg !70
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 24, !dbg !70
  %5 = load i64, ptr %4, align 8, !dbg !70
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32, !dbg !70
  %7 = load i64, ptr %6, align 8, !dbg !70
    #dbg_value(i64 %3, !67, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !68)
    #dbg_value(i64 %5, !67, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !68)
    #dbg_value(i64 %7, !67, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !68)
    #dbg_value(i64 %3, !66, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !68)
    #dbg_value(i64 %5, !66, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !68)
    #dbg_value(i64 %7, !66, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !68)
    #dbg_value(i64 %3, !43, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !71)
    #dbg_value(i64 %5, !43, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !71)
    #dbg_value(i64 %7, !43, !DIExpression(DW_OP_LLVM_fragment, 128, 64), !71)
    #dbg_value(i32 poison, !48, !DIExpression(DW_OP_constu, 16, DW_OP_shr, DW_OP_constu, 255, DW_OP_and, DW_OP_stack_value), !71)
  %8 = icmp ne i64 %3, 21, !dbg !73
  %9 = icmp ne i64 %5, 22
  %10 = select i1 %8, i1 true, i1 %9, !dbg !74
  %11 = icmp ne i64 %7, 23
  %12 = select i1 %10, i1 true, i1 %11, !dbg !74
  br i1 %12, label %13, label %14, !dbg !74

13:
  tail call void @abort() #4, !dbg !75
  unreachable, !dbg !75

14:
  ret ptr null, !dbg !76
}

declare void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !77 {
  %1 = tail call ptr @baz(ptr noundef nonnull @t), !dbg !81
  %2 = tail call ptr @foo(ptr noundef nonnull @t), !dbg !82
  tail call void @exit(i32 noundef 0) #4, !dbg !83
  unreachable, !dbg !83
}

declare void @exit(i32 noundef) local_unnamed_addr #3
attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!16, !17, !18, !19, !20, !21, !22}
!llvm.ident = !{!23}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "t", scope: !2, file: !3, line: 48, type: !5, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20011113-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "b10263dcd38b72fb4643fbb9438bad15")
!4 = !{!0}
!5 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "t", file: !3, line: 6, size: 320, elements: !6)
!6 = !{!7, !9, !10, !11}
!7 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !5, file: !3, line: 8, baseType: !8, size: 16, flags: DIFlagBitField, extraData: i64 0)
!8 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!9 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !5, file: !3, line: 9, baseType: !8, size: 8, offset: 16, flags: DIFlagBitField, extraData: i64 0)
!10 = !DIDerivedType(tag: DW_TAG_member, name: "c", scope: !5, file: !3, line: 10, baseType: !8, size: 8, offset: 24, flags: DIFlagBitField, extraData: i64 0)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "d", scope: !5, file: !3, line: 11, baseType: !12, size: 256, offset: 64)
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 256, elements: !14)
!13 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!14 = !{!15}
!15 = !DISubrange(count: 4)
!16 = !{i32 7, !"Dwarf Version", i32 5}
!17 = !{i32 2, !"Debug Info Version", i32 3}
!18 = !{i32 4, !"probe-stack", !"inline-asm"}
!19 = !{i32 8, !"PIC Level", i32 2}
!20 = !{i32 7, !"PIE Level", i32 2}
!21 = !{i32 7, !"uwtable", i32 2}
!22 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!23 = !{!"Alpine clang version 23.1.5"}
!24 = distinct !DISubprogram(name: "foo", scope: !3, file: !3, line: 20, type: !25, scopeLine: 21, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !29, keyInstructions: true)
!25 = !DISubroutineType(types: !26)
!26 = !{!27, !27}
!27 = !DIDerivedType(tag: DW_TAG_typedef, name: "T", file: !3, line: 12, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!29 = !{!30, !31, !39}
!30 = !DILocalVariable(name: "x", arg: 1, scope: !24, file: !3, line: 20, type: !27)
!31 = !DILocalVariable(name: "d", scope: !24, file: !3, line: 22, type: !32)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "U", file: !3, line: 16, baseType: !33)
!33 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !3, line: 14, size: 192, elements: !34)
!34 = !{!35}
!35 = !DIDerivedType(tag: DW_TAG_member, name: "r", scope: !33, file: !3, line: 15, baseType: !36, size: 192)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 192, elements: !37)
!37 = !{!38}
!38 = !DISubrange(count: 3)
!39 = !DILocalVariable(name: "u", scope: !24, file: !3, line: 22, type: !32)
!40 = !DILocation(line: 0, scope: !24)
!41 = !DILocation(line: 24, column: 16, scope: !24)
!42 = !DILocation(line: 24, column: 3, scope: !24, atomGroup: 1, atomRank: 1)
!43 = !DILocalVariable(name: "d", arg: 1, scope: !44, file: !3, line: 41, type: !32)
!44 = distinct !DISubprogram(name: "bar", scope: !3, file: !3, line: 41, type: !45, scopeLine: 42, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !47, keyInstructions: true)
!45 = !DISubroutineType(types: !46)
!46 = !{!27, !32, !8}
!47 = !{!43, !48}
!48 = !DILocalVariable(name: "m", arg: 2, scope: !44, file: !3, line: 41, type: !8)
!49 = !DILocation(line: 0, scope: !44, inlinedAt: !50)
!50 = distinct !DILocation(line: 26, column: 10, scope: !24)
!51 = !DILocation(line: 43, column: 14, scope: !52, inlinedAt: !50, atomGroup: 1, atomRank: 2)
!52 = distinct !DILexicalBlock(scope: !44, file: !3, line: 43, column: 7)
!53 = !DILocation(line: 43, column: 20, scope: !52, inlinedAt: !50, atomGroup: 1, atomRank: 1)
!54 = !DILocation(line: 44, column: 5, scope: !52, inlinedAt: !50)
!55 = !DILocation(line: 26, column: 3, scope: !24, atomGroup: 4, atomRank: 1)
!56 = !DILocation(line: 41, column: 10, scope: !44)
!57 = !DILocation(line: 0, scope: !44)
!58 = !DILocation(line: 43, column: 7, scope: !52)
!59 = !DILocation(line: 43, column: 14, scope: !52, atomGroup: 1, atomRank: 2)
!60 = !DILocation(line: 43, column: 20, scope: !52, atomGroup: 1, atomRank: 1)
!61 = !DILocation(line: 44, column: 5, scope: !52)
!62 = !DILocation(line: 45, column: 3, scope: !44, atomGroup: 4, atomRank: 1)
!63 = distinct !DISubprogram(name: "baz", scope: !3, file: !3, line: 29, type: !25, scopeLine: 30, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !64, keyInstructions: true)
!64 = !{!65, !66, !67}
!65 = !DILocalVariable(name: "x", arg: 1, scope: !63, file: !3, line: 29, type: !27)
!66 = !DILocalVariable(name: "d", scope: !63, file: !3, line: 31, type: !32)
!67 = !DILocalVariable(name: "u", scope: !63, file: !3, line: 31, type: !32)
!68 = !DILocation(line: 0, scope: !63)
!69 = !DILocation(line: 36, column: 16, scope: !63)
!70 = !DILocation(line: 36, column: 3, scope: !63, atomGroup: 4, atomRank: 1)
!71 = !DILocation(line: 0, scope: !44, inlinedAt: !72)
!72 = distinct !DILocation(line: 38, column: 10, scope: !63)
!73 = !DILocation(line: 43, column: 14, scope: !52, inlinedAt: !72, atomGroup: 1, atomRank: 2)
!74 = !DILocation(line: 43, column: 20, scope: !52, inlinedAt: !72, atomGroup: 1, atomRank: 1)
!75 = !DILocation(line: 44, column: 5, scope: !52, inlinedAt: !72)
!76 = !DILocation(line: 38, column: 3, scope: !63, atomGroup: 7, atomRank: 1)
!77 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 50, type: !78, scopeLine: 51, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!78 = !DISubroutineType(types: !79)
!79 = !{!80}
!80 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!81 = !DILocation(line: 52, column: 3, scope: !77)
!82 = !DILocation(line: 53, column: 3, scope: !77)
!83 = !DILocation(line: 54, column: 3, scope: !77)
