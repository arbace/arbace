; MUTANT: align invalid LLParser: alignment is not a power of two
source_filename = "20050224-1.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"
@a = dso_local local_unnamed_addr global i32 -1073741824, align 4
@b = dso_local local_unnamed_addr global i32 -805306368, align 4
@c = dso_local local_unnamed_addr global i32 -1071924904, align 4
@d = dso_local local_unnamed_addr global i32 -1071235072, align 4
@e = dso_local local_unnamed_addr global i32 -1071087616, align 4
@f = dso_local local_unnamed_addr global i32 -1070775432, align 4
define dso_local void @foo(i32 noundef %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  %4 = icmp ne i32 %0, 245
  %5 = icmp ne i32 %1, 36
  %6 = or i1 %4, %5
  %7 = icmp ne i32 %2, 444
  %8 = or i1 %6, %7
  br i1 %8, label %9, label %10

9:
  tail call void @abort() #2
  unreachable

10:
  ret void
}

declare dso_local void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = load i32, ptr @a, align 4
  %2 = load i32, ptr @b, align 4
  %3 = icmp ult i32 %1, %2
  br i1 %3, label %4, label %39

4:
  %5 = load i32, ptr @c, align 4
  %6 = load i32, ptr @d, align 3
  %7 = load i32, ptr @e, align 4
  %8 = load i32, ptr @f, align 4
  br label %9

9:
  %10 = phi i32 [ 0, %4 ], [ %30, %27 ]
  %11 = phi i32 [ 0, %4 ], [ %29, %27 ]
  %12 = phi i32 [ 0, %4 ], [ %28, %27 ]
  %13 = phi i32 [ %1, %4 ], [ %31, %27 ]
  %14 = icmp ult i32 %13, %5
  br i1 %14, label %15, label %17

15:
  %16 = add i32 %12, 1
  br label %27

17:
  %18 = icmp uge i32 %13, %6
  %19 = icmp ult i32 %13, %7
  %20 = select i1 %18, i1 %19, i1 false
  br i1 %20, label %21, label %23

21:
  %22 = add i32 %10, 1
  br label %27

23:
  %24 = icmp ult i32 %13, %8
  %25 = zext i1 %24 to i32
  %26 = add i32 %11, %25
  br label %27

27:
  %28 = phi i32 [ %16, %15 ], [ %12, %21 ], [ %12, %23 ]
  %29 = phi i32 [ %11, %15 ], [ %11, %21 ], [ %26, %23 ]
  %30 = phi i32 [ %10, %15 ], [ %22, %21 ], [ %10, %23 ]
  %31 = add i32 %13, 4096
  %32 = icmp ult i32 %31, %2
  br i1 %32, label %9, label %33, !llvm.loop !7

33:
  %34 = icmp ne i32 %29, 245
  %35 = icmp ne i32 %30, 36
  %36 = or i1 %34, %35
  %37 = icmp ne i32 %28, 444
  %38 = or i1 %37, %36
  br i1 %38, label %39, label %40

39:
  tail call void @abort() #2
  unreachable

40:
  ret i32 0
}

attributes #0 = { nofree nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20050224-1.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
