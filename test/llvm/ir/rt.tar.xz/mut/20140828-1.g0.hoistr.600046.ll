; MUTANT: hoistr invalid Verifier: Instruction does not dominate all uses!
source_filename = "20140828-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local ptr @f(ptr noundef %0, i32 noundef %1, ptr noundef %2) #0 !dbg !10 {
  %4 = load ptr, ptr %5, align 8, !dbg !28
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca i16, align 2
  store ptr %0, ptr %5, align 8
    #dbg_declare(ptr %5, !18, !DIExpression(), !19)
  store i32 %1, ptr %6, align 4
    #dbg_declare(ptr %6, !20, !DIExpression(), !21)
  store ptr %2, ptr %7, align 8
    #dbg_declare(ptr %7, !22, !DIExpression(), !23)
    #dbg_declare(ptr %8, !24, !DIExpression(), !25)
  %9 = load ptr, ptr %5, align 8, !dbg !26
  %10 = load i16, ptr %9, align 2, !dbg !27
  store i16 %10, ptr %8, align 2, !dbg !25
  %11 = getelementptr inbounds nuw i16, ptr %4, i32 1, !dbg !28
  store ptr %11, ptr %5, align 8, !dbg !28
  %12 = load i32, ptr %6, align 4, !dbg !29
  %13 = load i16, ptr %8, align 2, !dbg !30
  %14 = sext i16 %13 to i32, !dbg !30
  %15 = shl i32 %12, %14, !dbg !31
  %16 = trunc i32 %15 to i16, !dbg !29
  store i16 %16, ptr %8, align 2, !dbg !32
  %17 = load i16, ptr %8, align 2, !dbg !33
  %18 = sext i16 %17 to i32, !dbg !33
  %19 = load ptr, ptr %7, align 8, !dbg !34
  store i32 %18, ptr %19, align 4, !dbg !35
  %20 = load ptr, ptr %5, align 8, !dbg !36
  ret ptr %20, !dbg !37
}

define dso_local i32 @main() #0 !dbg !38 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [2 x i16], align 2
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !41, !DIExpression(), !42)
    #dbg_declare(ptr %3, !43, !DIExpression(), !47)
  %4 = getelementptr inbounds [2 x i16], ptr %3, i64 0, i64 0, !dbg !48
  store i16 0, ptr %4, align 2, !dbg !49
  %5 = getelementptr inbounds [2 x i16], ptr %3, i64 0, i64 0, !dbg !50
  %6 = call ptr @f(ptr noundef %5, i32 noundef 1, ptr noundef %2), !dbg !52
  %7 = getelementptr inbounds [2 x i16], ptr %3, i64 0, i64 1, !dbg !53
  %8 = icmp ne ptr %6, %7, !dbg !54
  br i1 %8, label %9, label %10, !dbg !54

9:
  call void @abort() #2, !dbg !55
  unreachable, !dbg !55

10:
  %11 = load i32, ptr %2, align 4, !dbg !56
  %12 = icmp ne i32 %11, 1, !dbg !58
  br i1 %12, label %13, label %14, !dbg !58

13:
  call void @abort() #2, !dbg !59
  unreachable, !dbg !59

14:
  ret i32 0, !dbg !60
}

declare void @abort() #1
attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20140828-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "4f2d437fe200efe831474db8c9c46fa5")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "f", scope: !1, file: !1, line: 3, type: !11, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !17)
!11 = !DISubroutineType(types: !12)
!12 = !{!13, !13, !15, !16}
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!17 = !{}
!18 = !DILocalVariable(name: "a", arg: 1, scope: !10, file: !1, line: 3, type: !13)
!19 = !DILocation(line: 3, column: 17, scope: !10)
!20 = !DILocalVariable(name: "b", arg: 2, scope: !10, file: !1, line: 3, type: !15)
!21 = !DILocation(line: 3, column: 24, scope: !10)
!22 = !DILocalVariable(name: "d", arg: 3, scope: !10, file: !1, line: 3, type: !16)
!23 = !DILocation(line: 3, column: 32, scope: !10)
!24 = !DILocalVariable(name: "c", scope: !10, file: !1, line: 5, type: !14)
!25 = !DILocation(line: 5, column: 9, scope: !10)
!26 = !DILocation(line: 5, column: 14, scope: !10)
!27 = !DILocation(line: 5, column: 13, scope: !10)
!28 = !DILocation(line: 6, column: 4, scope: !10)
!29 = !DILocation(line: 7, column: 7, scope: !10)
!30 = !DILocation(line: 7, column: 12, scope: !10)
!31 = !DILocation(line: 7, column: 9, scope: !10)
!32 = !DILocation(line: 7, column: 5, scope: !10)
!33 = !DILocation(line: 8, column: 8, scope: !10)
!34 = !DILocation(line: 8, column: 4, scope: !10)
!35 = !DILocation(line: 8, column: 6, scope: !10)
!36 = !DILocation(line: 9, column: 10, scope: !10)
!37 = !DILocation(line: 9, column: 3, scope: !10)
!38 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 12, type: !39, scopeLine: 13, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !17)
!39 = !DISubroutineType(types: !40)
!40 = !{!15}
!41 = !DILocalVariable(name: "d", scope: !38, file: !1, line: 14, type: !15)
!42 = !DILocation(line: 14, column: 7, scope: !38)
!43 = !DILocalVariable(name: "a", scope: !38, file: !1, line: 15, type: !44)
!44 = !DICompositeType(tag: DW_TAG_array_type, baseType: !14, size: 32, elements: !45)
!45 = !{!46}
!46 = !DISubrange(count: 2)
!47 = !DILocation(line: 15, column: 9, scope: !38)
!48 = !DILocation(line: 16, column: 3, scope: !38)
!49 = !DILocation(line: 16, column: 8, scope: !38)
!50 = !DILocation(line: 17, column: 9, scope: !51)
!51 = distinct !DILexicalBlock(scope: !38, file: !1, line: 17, column: 7)
!52 = !DILocation(line: 17, column: 7, scope: !51)
!53 = !DILocation(line: 17, column: 23, scope: !51)
!54 = !DILocation(line: 17, column: 19, scope: !51)
!55 = !DILocation(line: 18, column: 5, scope: !51)
!56 = !DILocation(line: 19, column: 7, scope: !57)
!57 = distinct !DILexicalBlock(scope: !38, file: !1, line: 19, column: 7)
!58 = !DILocation(line: 19, column: 9, scope: !57)
!59 = !DILocation(line: 20, column: 5, scope: !57)
!60 = !DILocation(line: 21, column: 3, scope: !38)
