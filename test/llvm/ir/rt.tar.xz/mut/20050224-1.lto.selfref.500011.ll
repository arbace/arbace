; MUTANT: selfref invalid LLParser: instruction forward referenced with type 'i32'
source_filename = "20050224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@a = dso_local local_unnamed_addr global i64 3221225472, align 8, !guid !0
@b = dso_local local_unnamed_addr global i64 3489660928, align 8, !guid !1
@c = dso_local local_unnamed_addr global i64 3223042392, align 8, !guid !2
@d = dso_local local_unnamed_addr global i64 3223732224, align 8, !guid !3
@e = dso_local local_unnamed_addr global i64 3223879680, align 8, !guid !4
@f = dso_local local_unnamed_addr global i64 3224191864, align 8, !guid !5
define dso_local void @foo(i32 noundef %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #0 !guid !13 {
  %4 = icmp ne i32 %0, 245
  %5 = icmp ne i32 %1, 36
  %6 = or i1 %4, %5
  %7 = icmp ne i32 %2, 444
  %8 = or i1 %6, %7
  br i1 %8, label %9, label %10

9:
  tail call void @abort() #2
  unreachable

10:
  ret void
}

declare void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #0 !guid !14 {
  %1 = load i64, ptr @a, align 8
  %2 = load i64, ptr @b, align 8
  %3 = icmp ult i64 %1, %2
  br i1 %3, label %4, label %39

4:
  %5 = load i64, ptr @c, align 8
  %6 = load i64, ptr @d, align 8
  %7 = load i64, ptr @e, align 8
  %8 = load i64, ptr @f, align 8
  br label %9

9:
  %10 = phi i32 [ 0, %4 ], [ %30, %27 ]
  %11 = phi i32 [ 0, %4 ], [ %29, %27 ]
  %12 = phi i32 [ 0, %4 ], [ %28, %27 ]
  %13 = phi i64 [ %1, %4 ], [ %31, %27 ]
  %14 = icmp ult i64 %13, %5
  br i1 %14, label %15, label %17

15:
  %16 = add nsw i32 %12, 1
  br label %27

17:
  %18 = icmp uge i64 %13, %6
  %19 = icmp ult i64 %13, %7
  %20 = select i1 %18, i1 %19, i1 false
  br i1 %20, label %21, label %23

21:
  %22 = add nsw i32 %10, 1
  br label %27

23:
  %24 = icmp ult i64 %13, %8
  %25 = zext i1 %24 to i32
  %26 = add nsw i32 %11, %25
  br label %27

27:
  %28 = phi i32 [ %16, %15 ], [ %12, %21 ], [ %12, %23 ]
  %29 = phi i32 [ %11, %15 ], [ %11, %21 ], [ %26, %23 ]
  %30 = phi i32 [ %10, %15 ], [ %22, %21 ], [ %10, %23 ]
  %31 = add i64 %13, 4096
  %32 = icmp ult i64 %31, %2
  br i1 %32, label %9, label %33, !llvm.loop !15

33:
  %34 = icmp ne i32 %29, 245
  %35 = icmp ne i32 %35, 36
  %36 = or i1 %34, %35
  %37 = icmp ne i32 %28, 444
  %38 = or i1 %37, %36
  br i1 %38, label %39, label %40

39:
  tail call void @abort() #2
  unreachable

40:
  ret i32 0
}

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }
!llvm.module.flags = !{!6, !7, !8, !9, !10, !11}
!llvm.ident = !{!12}
!0 = !{i64 -6289574019528802036}
!1 = !{i64 -1427730249719747694}
!2 = !{i64 4014738744300571210}
!3 = !{i64 -7709752385939146878}
!4 = !{i64 -642555945652099103}
!5 = !{i64 -3706093650706652785}
!6 = !{i32 4, !"probe-stack", !"inline-asm"}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{i32 1, !"ThinLTO", i32 0}
!11 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!12 = !{!"Alpine clang version 23.1.5"}
!13 = !{i64 6699318081062747564}
!14 = !{i64 -2624081020897602054}
!15 = distinct !{!15, !16}
!16 = !{!"llvm.loop.mustprogress"}
^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "abort")
^2 = gv: (name: "c", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^3 = gv: (name: "foo", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 9, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), calls: ((callee: ^1, tail: 1)))))
^4 = gv: (name: "d", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^5 = gv: (name: "a", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^6 = gv: (name: "f", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^7 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 42, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), calls: ((callee: ^1, tail: 1)), refs: (^5, ^8, ^2, ^4, ^9, ^6))))
^8 = gv: (name: "b", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^9 = gv: (name: "e", summaries: (variable: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), varFlags: (readonly: 1, writeonly: 1, constant: 0))))
^10 = flags: 8
^11 = blockcount: 0
