; MUTANT: hoist invalid LLParser: instruction expected to be numbered '%4' or greater
source_filename = "20020418-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local void @gcc_crash(ptr nofree noundef captures(none) %0) local_unnamed_addr #0 !dbg !10 {
    #dbg_value(ptr %0, !19, !DIExpression(), !21)
  %3 = icmp slt i32 %2, 52, !dbg !24
  %2 = load i32, ptr %0, align 4, !dbg !22
  br i1 %3, label %6, label %4, !dbg !25, !prof !26

4:
  %5 = icmp samesign ugt i32 %2, 60
  br label %7, !dbg !27

6:
  tail call void @llvm.trap(), !dbg !29
  unreachable, !dbg !29

7:
  %8 = phi i32 [ %9, %7 ], [ %2, %4 ], !dbg !30
    #dbg_label(!20, !31)
  %9 = add nuw nsw i32 %8, 1, !dbg !32
  br i1 %5, label %7, label %10, !dbg !27

10:
  store i32 %9, ptr %0, align 4, !dbg !33
  ret void, !dbg !34
}

declare void @llvm.trap() #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !35 {
    #dbg_value(i32 53, !39, !DIExpression(), !40)
    #dbg_value(i32 53, !39, !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value), !40)
  tail call void @exit(i32 noundef 0) #4, !dbg !41
  unreachable, !dbg !41
}

declare void @exit(i32 noundef) local_unnamed_addr #3
attributes #0 = { nounwind sspstrong memory(argmem: readwrite, inaccessiblemem: write) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}
!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20020418-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "7c58b6e71b5d8bdfcaddad22ed6bd60d")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "gcc_crash", scope: !1, file: !1, line: 8, type: !11, scopeLine: 9, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !18, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13}
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "foo", file: !1, line: 6, size: 32, elements: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !14, file: !1, line: 6, baseType: !17, size: 32)
!17 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!18 = !{!19, !20}
!19 = !DILocalVariable(name: "p", arg: 1, scope: !10, file: !1, line: 8, type: !13)
!20 = !DILabel(scope: !10, name: "top", file: !1, line: 12, column: 2)
!21 = !DILocation(line: 0, scope: !10)
!22 = !DILocation(line: 10, column: 26, scope: !23)
!23 = distinct !DILexicalBlock(scope: !10, file: !1, line: 10, column: 6)
!24 = !DILocation(line: 10, column: 28, scope: !23)
!25 = !DILocation(line: 10, column: 6, scope: !23, atomGroup: 1, atomRank: 1)
!26 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!27 = !DILocation(line: 14, column: 11, scope: !28, atomGroup: 3, atomRank: 1)
!28 = distinct !DILexicalBlock(scope: !10, file: !1, line: 14, column: 6)
!29 = !DILocation(line: 11, column: 3, scope: !23)
!30 = !DILocation(line: 13, column: 6, scope: !10)
!31 = !DILocation(line: 12, column: 2, scope: !10)
!32 = !DILocation(line: 13, column: 6, scope: !10, atomGroup: 2, atomRank: 2)
!33 = !DILocation(line: 13, column: 6, scope: !10, atomGroup: 2, atomRank: 1)
!34 = !DILocation(line: 16, column: 1, scope: !10, atomGroup: 5, atomRank: 1)
!35 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 18, type: !36, scopeLine: 19, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !38, keyInstructions: true)
!36 = !DISubroutineType(types: !37)
!37 = !{!17}
!38 = !{!39}
!39 = !DILocalVariable(name: "x", scope: !35, file: !1, line: 20, type: !14)
!40 = !DILocation(line: 0, scope: !35)
!41 = !DILocation(line: 25, column: 2, scope: !35)
