; MUTANT: undef invalid LLParser: use of undefined value '%nosuch.value'
source_filename = "20011113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
%struct.U = type { [3 x i64] }
@t = dso_local global { i8, i8, i8, i8, [4 x i8], [4 x i64] } { i8 26, i8 0, i8 0, i8 0, [4 x i8] zeroinitializer, [4 x i64] [i64 0, i64 21, i64 22, i64 23] }, align 8
define dso_local noalias noundef ptr @foo(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %3 = load i64, ptr %2, align 8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %7 = load i64, ptr %6, align 8
  %8 = icmp ne i64 %3, 21
  %9 = icmp ne i64 %5, 22
  %10 = select i1 %8, i1 true, i1 %9
  %11 = icmp ne i64 %7, 23
  %12 = select i1 %10, i1 true, i1 %11
  br i1 %12, label %13, label %14

13:
  tail call void @abort() #4
  unreachable

14:
  ret ptr null
}

define dso_local noalias noundef ptr @bar(ptr nofree noundef readonly byval(%struct.U) align 8 captures(none) %0, i32 noundef %1) local_unnamed_addr #0 {
  %3 = load i64, ptr %0, align 8
  %4 = icmp ne i64 %3, 21
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp ne i64 %6, 22
  %8 = select i1 %4, i1 true, i1 %7
  %9 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, 23
  %12 = select i1 %8, i1 true, i1 %11
  br i1 %12, label %13, label %14

13:
  tail call void @abort() #4
  unreachable

14:
  ret ptr null
}

define dso_local noalias noundef ptr @baz(ptr nofree noundef readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %3 = load i64, ptr %2, align 8
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds nuw i8, ptr %0, i64 32
  %7 = load i64, ptr %6, align 8
  %8 = icmp ne i64 %3, 21
  %9 = icmp ne i64 %5, 22
  %10 = select i1 %nosuch.value, i1 true, i1 %9
  %11 = icmp ne i64 %7, 23
  %12 = select i1 %10, i1 true, i1 %11
  br i1 %12, label %13, label %14

13:
  tail call void @abort() #4
  unreachable

14:
  ret ptr null
}

declare void @abort() local_unnamed_addr #1
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  %1 = tail call ptr @baz(ptr noundef nonnull @t)
  %2 = tail call ptr @foo(ptr noundef nonnull @t)
  tail call void @exit(i32 noundef 0) #4
  unreachable
}

declare void @exit(i32 noundef) local_unnamed_addr #3
attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Alpine clang version 23.1.5"}
