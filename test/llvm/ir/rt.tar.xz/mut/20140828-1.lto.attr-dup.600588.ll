; MUTANT: attr-dup invalid LLParser: functions with 'sret' argument must return void
source_filename = "20140828-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
define dso_local nonnull ptr @f(ptr sret(i32) nofree noundef readonly captures(ret: address, provenance) %0, i32 noundef %1, ptr sret(i32) nofree noundef writeonly captures(none) initializes((0, 4)) %2) local_unnamed_addr #0 !guid !7 {
  %4 = load i16, ptr %0, align 2
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %6 = zext nneg i16 %4 to i32
  %7 = shl i32 %1, %6
  %8 = shl i32 %7, 16
  %9 = ashr exact i32 %8, 16
  store i32 %9, ptr %2, align 4
  ret ptr %5
}

declare void @llvm.lifetime.start.p0(ptr captures(none)) #1
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1
define dso_local noundef i32 @main() local_unnamed_addr #2 !guid !8 {
  %1 = alloca i32, align 4
  %2 = alloca [2 x i16], align 2
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #4
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #4
  store i16 0, ptr %2, align 2
  %3 = call ptr @f(ptr noundef nonnull %2, i32 noundef 1, ptr noundef nonnull %1)
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 2
  %5 = icmp eq ptr %3, %4
  br i1 %5, label %7, label %6

6:
  call void @abort() #5
  unreachable

7:
  %8 = load i32, ptr %1, align 4
  %9 = icmp eq i32 %8, 1
  br i1 %9, label %11, label %10

10:
  call void @abort() #5
  unreachable

11:
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #4
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #4
  ret i32 0
}

declare void @abort() local_unnamed_addr #3
attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind }
attributes #5 = { noreturn nounwind }
!llvm.module.flags = !{!0, !1, !2, !3, !4, !5}
!llvm.ident = !{!6}
!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 1, !"ThinLTO", i32 0}
!5 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = !{i64 -3706093650706652785}
!8 = !{i64 -2624081020897602054}
^0 = module: (path: "[Regular LTO]", hash: (0, 0, 0, 0, 0))
^1 = gv: (name: "abort")
^2 = gv: (name: "f", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 8, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 1, returnDoesNotAlias: 0, noInline: 1, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0))))
^3 = gv: (name: "main", summaries: (function: (module: ^0, flags: (linkage: external, visibility: default, notEligibleToImport: 1, live: 0, dsoLocal: 1, canAutoHide: 0, importType: definition, noRenameOnPromotion: 0), insts: 19, funcFlags: (readNone: 0, readOnly: 0, noRecurse: 0, returnDoesNotAlias: 0, noInline: 0, alwaysInline: 0, noUnwind: 1, mayThrow: 0, hasUnknownCall: 0, mustBeUnreachable: 0), calls: ((callee: ^2), (callee: ^1)))))
^4 = flags: 8
^5 = blockcount: 0
