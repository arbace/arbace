; MUTANT: selfref invalid LLParser: instruction forward referenced with type 'i32'
source_filename = "20000224-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"
@loop_1 = dso_local local_unnamed_addr global i32 100, align 4, !dbg !0
@loop_2 = dso_local local_unnamed_addr global i32 7, align 4, !dbg !5
@flag = dso_local local_unnamed_addr global i32 0, align 4, !dbg !8
define dso_local noundef i32 @test() local_unnamed_addr #0 !dbg !18 {
    #dbg_value(i32 0, !23, !DIExpression(), !24)
  %1 = load i32, ptr @loop_1, align 4
    #dbg_value(i32 0, !23, !DIExpression(), !24)
  %2 = icmp sgt i32 %1, 0, !dbg !25
  br i1 %2, label %3, label %18, !dbg !26

3:
  %4 = load i32, ptr @flag, align 4
  %5 = load i32, ptr @loop_2, align 4
  %6 = icmp slt i32 %5, 1
  br label %7, !dbg !26

7:
  %8 = phi i32 [ 0, %3 ], [ %14, %7 ]
  %9 = phi i32 [ %4, %3 ], [ %15, %7 ]
    #dbg_value(i32 %8, !23, !DIExpression(), !24)
  %10 = and i32 %9, 1, !dbg !27
  %11 = icmp eq i32 %10, 0, !dbg !30
  %12 = select i1 %11, i1 true, i1 %6, !dbg !31
  %13 = select i1 %12, i32 0, i32 %5, !dbg !31
  %14 = add i32 %8, %13, !dbg !31
    #dbg_value(i32 %14, !23, !DIExpression(), !24)
  %15 = add nsw i32 %9, 1, !dbg !32
  %16 = icmp sgt i32 %16, %14, !dbg !33
  br i1 %16, label %7, label %17, !dbg !34, !llvm.loop !35

17:
  store i32 %15, ptr @flag, align 4, !dbg !39
  br label %18, !dbg !34

18:
  ret i32 1, !dbg !40
}

define dso_local noundef i32 @main() local_unnamed_addr #1 !dbg !41 {
  %1 = tail call i32 @test(), !dbg !42
  tail call void @exit(i32 noundef 0) #3, !dbg !44
  unreachable, !dbg !44
}

declare void @exit(i32 noundef) local_unnamed_addr #2
attributes #0 = { nofree norecurse nosync nounwind sspstrong memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!10, !11, !12, !13, !14, !15, !16}
!llvm.ident = !{!17}
!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "loop_1", scope: !2, file: !3, line: 4, type: !7, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "20000224-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "2e314f0d8f183be101e54623318ad2a9")
!4 = !{!0, !5, !8}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "loop_2", scope: !2, file: !3, line: 5, type: !7, isLocal: false, isDefinition: true)
!7 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "flag", scope: !2, file: !3, line: 6, type: !7, isLocal: false, isDefinition: true)
!10 = !{i32 7, !"Dwarf Version", i32 5}
!11 = !{i32 2, !"Debug Info Version", i32 3}
!12 = !{i32 4, !"probe-stack", !"inline-asm"}
!13 = !{i32 8, !"PIC Level", i32 2}
!14 = !{i32 7, !"PIE Level", i32 2}
!15 = !{i32 7, !"uwtable", i32 2}
!16 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!17 = !{!"Alpine clang version 23.1.5"}
!18 = distinct !DISubprogram(name: "test", scope: !3, file: !3, line: 8, type: !19, scopeLine: 9, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !21, keyInstructions: true)
!19 = !DISubroutineType(types: !20)
!20 = !{!7}
!21 = !{!22, !23}
!22 = !DILocalVariable(name: "i", scope: !18, file: !3, line: 10, type: !7)
!23 = !DILocalVariable(name: "counter", scope: !18, file: !3, line: 11, type: !7)
!24 = !DILocation(line: 0, scope: !18)
!25 = !DILocation(line: 13, column: 19, scope: !18, atomGroup: 16, atomRank: 1)
!26 = !DILocation(line: 13, column: 5, scope: !18, atomGroup: 17, atomRank: 1)
!27 = !DILocation(line: 14, column: 18, scope: !28)
!28 = distinct !DILexicalBlock(scope: !29, file: !3, line: 14, column: 13)
!29 = distinct !DILexicalBlock(scope: !18, file: !3, line: 13, column: 30)
!30 = !DILocation(line: 14, column: 18, scope: !28, atomGroup: 4, atomRank: 2)
!31 = !DILocation(line: 14, column: 18, scope: !28, atomGroup: 4, atomRank: 1)
!32 = !DILocation(line: 19, column: 13, scope: !29, atomGroup: 11, atomRank: 2)
!33 = !DILocation(line: 13, column: 19, scope: !18, atomGroup: 2, atomRank: 1)
!34 = !DILocation(line: 13, column: 5, scope: !18, atomGroup: 3, atomRank: 1)
!35 = distinct !{!35, !36, !37, !38}
!36 = !DILocation(line: 13, column: 5, scope: !18)
!37 = !DILocation(line: 20, column: 5, scope: !18)
!38 = !{!"llvm.loop.mustprogress"}
!39 = !DILocation(line: 19, column: 13, scope: !29, atomGroup: 11, atomRank: 1)
!40 = !DILocation(line: 21, column: 5, scope: !18, atomGroup: 13, atomRank: 1)
!41 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 24, type: !19, scopeLine: 25, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!42 = !DILocation(line: 26, column: 9, scope: !43)
!43 = distinct !DILexicalBlock(scope: !41, file: !3, line: 26, column: 9)
!44 = !DILocation(line: 29, column: 5, scope: !41)
