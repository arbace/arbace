; ModuleID = 'test/cpp/samples/decls.cpp'
source_filename = "test/cpp/samples/decls.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S2 = type { i32, i32 }

@_ZN1A1sE = dso_local global i32 0, align 4, !dbg !0
@_ZN1a1b1c1zE = dso_local global i32 0, align 4, !dbg !5
@fp = dso_local global ptr null, align 8, !dbg !11
@p = dso_local global ptr null, align 8, !dbg !16
@s2 = dso_local global %struct.S2 zeroinitializer, align 4, !dbg !20
@ps2 = dso_local global ptr null, align 8, !dbg !26
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_decls.cpp, ptr null }]

; Function Attrs: noinline sspstrong uwtable
define internal void @__cxx_global_var_init() #0 section ".text.startup" !dbg !41 {
  %1 = call noalias noundef nonnull ptr @_Znam(i64 noundef 3) #3, !dbg !44, !heapallocsite !19
  store i8 1, ptr %1, align 1, !dbg !44
  %2 = getelementptr inbounds i8, ptr %1, i64 1, !dbg !44
  store i8 2, ptr %2, align 1, !dbg !44
  %3 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !44
  store i8 3, ptr %3, align 1, !dbg !44
  %4 = getelementptr inbounds i8, ptr %3, i64 1, !dbg !44
  store ptr %1, ptr @p, align 8, !dbg !45
  ret void, !dbg !46
}

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znam(i64 noundef) #1

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define dso_local noundef i32 @_Z1gi(i32 noundef %0) #2 !dbg !47 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
    #dbg_declare(ptr %2, !51, !DIExpression(), !52)
    #dbg_declare(ptr %3, !53, !DIExpression(), !54)
  store i32 0, ptr %3, align 4, !dbg !54
  br label %4, !dbg !55

4:                                                ; preds = %10, %1
    #dbg_label(!56, !57)
  %5 = load i32, ptr %3, align 4, !dbg !58
  %6 = add nsw i32 %5, 1, !dbg !58
  store i32 %6, ptr %3, align 4, !dbg !58
  %7 = load i32, ptr %3, align 4, !dbg !59
  %8 = load i32, ptr %2, align 4, !dbg !61
  %9 = icmp slt i32 %7, %8, !dbg !62
  br i1 %9, label %10, label %11, !dbg !62

10:                                               ; preds = %4
  br label %4, !dbg !63

11:                                               ; preds = %4
  %12 = load i32, ptr %3, align 4, !dbg !64
  ret i32 %12, !dbg !65
}

; Function Attrs: noinline sspstrong uwtable
define internal void @_GLOBAL__sub_I_decls.cpp() #0 section ".text.startup" !dbg !66 {
  call void @__cxx_global_var_init(), !dbg !68
  ret void
}

attributes #0 = { noinline sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nobuiltin allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { builtin allocsize(0) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!33, !34, !35, !36, !37, !38, !39}
!llvm.ident = !{!40}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "s", linkageName: "_ZN1A1sE", scope: !2, file: !3, line: 3, type: !10, isLocal: false, isDefinition: true, declaration: !31)
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, imports: !29, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "test/cpp/samples/decls.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "82281835b2e509f3553bc2b481ee3e9b")
!4 = !{!0, !5, !11, !16, !20, !26}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "z", linkageName: "_ZN1a1b1c1zE", scope: !7, file: !3, line: 6, type: !10, isLocal: false, isDefinition: true)
!7 = !DINamespace(name: "c", scope: !8, exportSymbols: true)
!8 = !DINamespace(name: "b", scope: !9)
!9 = !DINamespace(name: "a", scope: null)
!10 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!11 = !DIGlobalVariableExpression(var: !12, expr: !DIExpression())
!12 = distinct !DIGlobalVariable(name: "fp", scope: !2, file: !3, line: 12, type: !13, isLocal: false, isDefinition: true)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{null, !10}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !3, line: 13, type: !18, isLocal: false, isDefinition: true)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "s2", scope: !2, file: !3, line: 16, type: !22, isLocal: false, isDefinition: true)
!22 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "S2", file: !3, line: 16, size: 64, flags: DIFlagTypePassByValue, elements: !23, identifier: "_ZTS2S2")
!23 = !{!24, !25}
!24 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !22, file: !3, line: 16, baseType: !10, size: 32)
!25 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !22, file: !3, line: 16, baseType: !10, size: 32, offset: 32)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "ps2", scope: !2, file: !3, line: 16, type: !28, isLocal: false, isDefinition: true)
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !22, size: 64)
!29 = !{!30}
!30 = !DIImportedEntity(tag: DW_TAG_imported_module, scope: !2, entity: !8, file: !3, line: 8)
!31 = !DIDerivedType(tag: DW_TAG_variable, name: "s", scope: !32, file: !3, line: 1, baseType: !10, flags: DIFlagStaticMember)
!32 = !DICompositeType(tag: DW_TAG_structure_type, name: "A", file: !3, line: 1, size: 64, flags: DIFlagFwdDecl | DIFlagNonTrivial, identifier: "_ZTS1A")
!33 = !{i32 7, !"Dwarf Version", i32 5}
!34 = !{i32 2, !"Debug Info Version", i32 3}
!35 = !{i32 4, !"probe-stack", !"inline-asm"}
!36 = !{i32 8, !"PIC Level", i32 2}
!37 = !{i32 7, !"PIE Level", i32 2}
!38 = !{i32 7, !"uwtable", i32 2}
!39 = !{i32 7, !"frame-pointer", i32 2}
!40 = !{!"Alpine clang version 23.1.5"}
!41 = distinct !DISubprogram(name: "__cxx_global_var_init", scope: !3, file: !3, type: !42, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2)
!42 = !DISubroutineType(types: !43)
!43 = !{null}
!44 = !DILocation(line: 13, column: 11, scope: !41)
!45 = !DILocation(line: 0, scope: !41)
!46 = !DILocation(line: 13, column: 27, scope: !41)
!47 = distinct !DISubprogram(name: "g", linkageName: "_Z1gi", scope: !3, file: !3, line: 14, type: !48, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !50)
!48 = !DISubroutineType(types: !49)
!49 = !{!10, !10}
!50 = !{}
!51 = !DILocalVariable(name: "n", arg: 1, scope: !47, file: !3, line: 14, type: !10)
!52 = !DILocation(line: 14, column: 11, scope: !47)
!53 = !DILocalVariable(name: "r", scope: !47, file: !3, line: 14, type: !10)
!54 = !DILocation(line: 14, column: 20, scope: !47)
!55 = !DILocation(line: 14, column: 16, scope: !47)
!56 = !DILabel(scope: !47, name: "L", file: !3, line: 14, column: 27)
!57 = !DILocation(line: 14, column: 27, scope: !47)
!58 = !DILocation(line: 14, column: 31, scope: !47)
!59 = !DILocation(line: 14, column: 39, scope: !60)
!60 = distinct !DILexicalBlock(scope: !47, file: !3, line: 14, column: 39)
!61 = !DILocation(line: 14, column: 43, scope: !60)
!62 = !DILocation(line: 14, column: 41, scope: !60)
!63 = !DILocation(line: 14, column: 46, scope: !60)
!64 = !DILocation(line: 14, column: 61, scope: !47)
!65 = !DILocation(line: 14, column: 54, scope: !47)
!66 = distinct !DISubprogram(linkageName: "_GLOBAL__sub_I_decls.cpp", scope: !3, file: !3, type: !67, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2)
!67 = !DISubroutineType(types: !50)
!68 = !DILocation(line: 0, scope: !66)
