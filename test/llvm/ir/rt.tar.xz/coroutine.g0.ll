; ModuleID = 'test/cpp/samples/coroutine.cpp'
source_filename = "test/cpp/samples/coroutine.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.Gen = type { %"struct.std::__n4861::coroutine_handle" }
%"struct.std::__n4861::coroutine_handle" = type { ptr }
%"struct.std::__n4861::suspend_always" = type { i8 }
%"struct.Gen::promise_type" = type { i32 }
%"struct.std::__n4861::coroutine_handle.0" = type { ptr }

$_ZN3Gen12promise_type17get_return_objectEv = comdat any

$_ZN3Gen12promise_type15initial_suspendEv = comdat any

$_ZNKSt7__n486114suspend_always11await_readyEv = comdat any

$_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv = comdat any

$_ZNKSt7__n486114suspend_always12await_resumeEv = comdat any

$_ZN3Gen12promise_type11yield_valueEi = comdat any

$_ZN3Gen12promise_type11return_voidEv = comdat any

$_ZN3Gen12promise_type13final_suspendEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_ = comdat any

$_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev = comdat any

$_ZNSt7__n486116coroutine_handleIvE12from_addressEPv = comdat any

$_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv = comdat any

$_ZNSt7__n486116coroutine_handleIvEC2Ev = comdat any

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define dso_local ptr @_Z5counti(i32 noundef %0) #0 personality ptr @__gxx_personality_v0 !dbg !133 {
  %2 = alloca %struct.Gen, align 8
  %3 = alloca i32, align 4, !coro.outside.frame !156
    #dbg_declare(ptr %3, !160, !DIExpression(), !161)
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca %"struct.std::__n4861::suspend_always", align 1
  %7 = alloca %"struct.std::__n4861::suspend_always", align 1
  %8 = alloca %"struct.std::__n4861::suspend_always", align 1
  store i32 %0, ptr %3, align 4
  br i1 true, label %11, label %9, !dbg !162

9:                                                ; preds = %1
  %10 = phi ptr [ null, %1 ]
  br label %15, !dbg !162

11:                                               ; preds = %1
  %12 = call noalias noundef nonnull ptr @_Znwm(i64 noundef 32) #6, !dbg !163
  br label %13, !dbg !162

13:                                               ; preds = %11
  %14 = phi ptr [ %12, %11 ]
  br label %15, !dbg !162

15:                                               ; preds = %9, %13
  %16 = phi ptr [ %10, %9 ], [ %14, %13 ], !dbg !162
    #dbg_declare(ptr %16, !164, !DIExpression(DW_OP_plus_uconst, 24), !162)
    #dbg_declare(ptr %16, !167, !DIExpression(DW_OP_plus_uconst, 16), !162)
    #dbg_declare(ptr %16, !160, !DIExpression(DW_OP_plus_uconst, 20), !162)
    #dbg_declare(ptr %16, !137, !DIExpression(), !162)
  store ptr @_Z5counti.resume, ptr %16, align 8, !dbg !168
  %17 = select i1 true, ptr @_Z5counti.destroy, ptr @_Z5counti.cleanup, !dbg !168
  %18 = getelementptr inbounds i8, ptr %16, i64 8, !dbg !168
  store ptr %17, ptr %18, align 8, !dbg !168
  br label %19, !dbg !168

19:                                               ; preds = %15
  %20 = getelementptr inbounds i8, ptr %16, i64 20, !dbg !168
  %21 = getelementptr inbounds i8, ptr %16, i64 29, !dbg !168
  %22 = getelementptr inbounds i8, ptr %16, i64 24, !dbg !168
  %23 = getelementptr inbounds i8, ptr %16, i64 30, !dbg !168
  %24 = getelementptr inbounds i8, ptr %16, i64 31, !dbg !168
  %25 = getelementptr inbounds i8, ptr %16, i64 16, !dbg !168
  br label %26, !dbg !168

26:                                               ; preds = %19
  %27 = load i32, ptr %3, align 4, !dbg !168
  store i32 %27, ptr %20, align 4, !dbg !168
  %28 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %25, i32 0, i32 0, !dbg !163
  %29 = load i32, ptr %20, align 4, !dbg !163
  store i32 %29, ptr %28, align 4, !dbg !163
  %30 = invoke ptr @_ZN3Gen12promise_type17get_return_objectEv(ptr noundef nonnull align 4 dereferenceable(4) %25)
          to label %31 unwind label %45, !dbg !163

31:                                               ; preds = %26
  %32 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !163
  %33 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %32, i32 0, i32 0, !dbg !163
  store ptr %30, ptr %33, align 8, !dbg !163
  call void @_ZN3Gen12promise_type15initial_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %25), !dbg !163
  br label %34, !dbg !163

34:                                               ; preds = %31
  %35 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %21) #7, !dbg !163
  br i1 %35, label %49, label %36, !dbg !163

36:                                               ; preds = %34
  %37 = getelementptr inbounds i8, ptr %16, i64 28, !dbg !163
  store i2 0, ptr %37, align 1, !dbg !163
  br label %38, !dbg !163

38:                                               ; preds = %36
  call void @_Z5counti.__await_suspend_wrapper__init(ptr %21, ptr %16) #7, !dbg !163
  br label %39, !dbg !163

39:                                               ; preds = %38
  br label %40, !dbg !163

40:                                               ; preds = %39
  br label %41, !dbg !163

41:                                               ; preds = %40
  switch i8 -1, label %111 [
    i8 0, label %49
    i8 1, label %42
  ], !dbg !163

42:                                               ; preds = %41
  br label %43, !dbg !163

43:                                               ; preds = %42
  %44 = phi i32 [ 2, %42 ]
  br label %52, !dbg !163

45:                                               ; preds = %26
  %46 = landingpad { ptr, i32 }
          cleanup, !dbg !169
  %47 = extractvalue { ptr, i32 } %46, 0, !dbg !169
  store ptr %47, ptr %4, align 8, !dbg !169
  %48 = extractvalue { ptr, i32 } %46, 1, !dbg !169
  store i32 %48, ptr %5, align 4, !dbg !169
  br label %117, !dbg !169

49:                                               ; preds = %41, %34
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %21) #7, !dbg !163
  br label %50, !dbg !163

50:                                               ; preds = %49
  %51 = phi i32 [ 0, %49 ]
  br label %52, !dbg !163

52:                                               ; preds = %50, %43
  %53 = phi i32 [ %51, %50 ], [ %44, %43 ]
  switch i32 %53, label %126 [
    i32 0, label %54
    i32 2, label %107
  ]

54:                                               ; preds = %52
  store i32 0, ptr %22, align 4, !dbg !170
  br label %55, !dbg !171

55:                                               ; preds = %84, %54
  %56 = load i32, ptr %22, align 4, !dbg !172
  %57 = load i32, ptr %20, align 4, !dbg !174
  %58 = icmp slt i32 %56, %57, !dbg !175
  br i1 %58, label %62, label %59, !dbg !176

59:                                               ; preds = %55
  br label %60, !dbg !176

60:                                               ; preds = %59
  %61 = phi i32 [ 4, %59 ]
  br label %87, !dbg !176

62:                                               ; preds = %55
  %63 = load i32, ptr %22, align 4, !dbg !177
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %25, i32 noundef %63), !dbg !178
  br label %64, !dbg !178

64:                                               ; preds = %62
  %65 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %23) #7, !dbg !178
  br i1 %65, label %75, label %66, !dbg !178

66:                                               ; preds = %64
  %67 = getelementptr inbounds i8, ptr %16, i64 28, !dbg !178
  store i2 1, ptr %67, align 1, !dbg !178
  br label %68, !dbg !178

68:                                               ; preds = %66
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %23, ptr %16) #7, !dbg !178
  br label %69, !dbg !178

69:                                               ; preds = %68
  br label %70, !dbg !178

70:                                               ; preds = %69
  br label %71, !dbg !178

71:                                               ; preds = %70
  switch i8 -1, label %111 [
    i8 0, label %75
    i8 1, label %72
  ], !dbg !178

72:                                               ; preds = %71
  br label %73, !dbg !178

73:                                               ; preds = %72
  %74 = phi i32 [ 2, %72 ]
  br label %78, !dbg !178

75:                                               ; preds = %71, %64
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %23) #7, !dbg !178
  br label %76, !dbg !178

76:                                               ; preds = %75
  %77 = phi i32 [ 0, %75 ]
  br label %78, !dbg !178

78:                                               ; preds = %76, %73
  %79 = phi i32 [ %77, %76 ], [ %74, %73 ]
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %83, label %81

81:                                               ; preds = %78
  %82 = phi i32 [ %79, %78 ]
  br label %87

83:                                               ; preds = %78
  br label %84, !dbg !178

84:                                               ; preds = %83
  %85 = load i32, ptr %22, align 4, !dbg !179
  %86 = add nsw i32 %85, 1, !dbg !179
  store i32 %86, ptr %22, align 4, !dbg !179
  br label %55, !dbg !180, !llvm.loop !181

87:                                               ; preds = %81, %60
  %88 = phi i32 [ %82, %81 ], [ %61, %60 ]
  switch i32 %88, label %126 [
    i32 4, label %89
    i32 2, label %107
  ]

89:                                               ; preds = %87
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %25), !dbg !163
  br label %90, !dbg !163

90:                                               ; preds = %89
  br label %91, !dbg !163

91:                                               ; preds = %90
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %25) #7, !dbg !163
  %92 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %24) #7, !dbg !163
  br i1 %92, label %101, label %93, !dbg !163

93:                                               ; preds = %91
  store ptr null, ptr %16, align 8, !dbg !163
  br label %94, !dbg !163

94:                                               ; preds = %93
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %24, ptr %16) #7, !dbg !163
  br label %95, !dbg !163

95:                                               ; preds = %94
  br label %96, !dbg !163

96:                                               ; preds = %95
  br label %97, !dbg !163

97:                                               ; preds = %96
  switch i8 -1, label %111 [
    i8 0, label %101
    i8 1, label %98
  ], !dbg !163

98:                                               ; preds = %97
  br label %99, !dbg !163

99:                                               ; preds = %98
  %100 = phi i32 [ 2, %98 ]
  br label %104, !dbg !163

101:                                              ; preds = %97, %91
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %24) #7, !dbg !163
  br label %102, !dbg !163

102:                                              ; preds = %101
  %103 = phi i32 [ 0, %101 ]
  br label %104, !dbg !163

104:                                              ; preds = %102, %99
  %105 = phi i32 [ %103, %102 ], [ %100, %99 ]
  switch i32 %105, label %126 [
    i32 0, label %106
    i32 2, label %107
  ]

106:                                              ; preds = %104
  br label %107, !dbg !163

107:                                              ; preds = %106, %104, %87, %52
  %108 = icmp ne ptr %16, null, !dbg !163
  br i1 %108, label %109, label %110, !dbg !163

109:                                              ; preds = %107
  call void @_ZdlPvm(ptr noundef %16, i64 noundef 32) #7, !dbg !163
  br label %110, !dbg !163

110:                                              ; preds = %107, %109
  br label %111, !dbg !163

111:                                              ; preds = %110, %97, %71, %41
  br label %112, !dbg !163

112:                                              ; preds = %111
  br label %113, !dbg !163

113:                                              ; preds = %112
  %114 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !163
  %115 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %114, i32 0, i32 0, !dbg !163
  %116 = load ptr, ptr %115, align 8, !dbg !163
  ret ptr %116, !dbg !163

117:                                              ; preds = %45
  %118 = icmp ne ptr %16, null, !dbg !163
  br i1 %118, label %119, label %120, !dbg !163

119:                                              ; preds = %117
  call void @_ZdlPvm(ptr noundef %16, i64 noundef 32) #7, !dbg !163
  br label %120, !dbg !163

120:                                              ; preds = %117, %119
  br label %121, !dbg !163

121:                                              ; preds = %120
  %122 = load ptr, ptr %4, align 8, !dbg !163
  %123 = load i32, ptr %5, align 4, !dbg !163
  %124 = insertvalue { ptr, i32 } poison, ptr %122, 0, !dbg !163
  %125 = insertvalue { ptr, i32 } %124, i32 %123, 1, !dbg !163
  resume { ptr, i32 } %125, !dbg !163

126:                                              ; preds = %104, %87, %52
  unreachable
}

; Function Attrs: nobuiltin allocsize(0)
declare noundef nonnull ptr @_Znwm(i64 noundef) #1

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZN3Gen12promise_type17get_return_objectEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #0 comdat align 2 !dbg !184 {
  %2 = alloca %struct.Gen, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !185, !DIExpression(), !186)
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !187
  %6 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_(ptr noundef nonnull align 4 dereferenceable(4) %4), !dbg !188
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %5, i32 0, i32 0, !dbg !188
  store ptr %6, ptr %7, align 8, !dbg !188
  %8 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !189
  %9 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %8, i32 0, i32 0, !dbg !189
  %10 = load ptr, ptr %9, align 8, !dbg !189
  ret ptr %10, !dbg !189
}

declare i32 @__gxx_personality_v0(...)

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type15initial_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 !dbg !190 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !191, !DIExpression(), !192)
  %3 = load ptr, ptr %2, align 8
  ret void, !dbg !193
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %0) #2 comdat align 2 !dbg !194 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !195, !DIExpression(), !197)
  %3 = load ptr, ptr %2, align 8
  ret i1 false, !dbg !198
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__init(ptr noundef nonnull %0, ptr noundef %1) #3 !dbg !199 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !201, !DIExpression(), !202)
  store ptr %1, ptr %4, align 8
    #dbg_declare(ptr %4, !203, !DIExpression(), !202)
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7, !dbg !204
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0, !dbg !204
  store ptr %9, ptr %10, align 8, !dbg !204
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7, !dbg !204
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !204
  store ptr %11, ptr %12, align 8, !dbg !204
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !204
  %14 = load ptr, ptr %13, align 8, !dbg !204
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7, !dbg !204
  ret void, !dbg !204
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %0, ptr %1) #2 comdat align 2 !dbg !205 {
  %3 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %4 = alloca ptr, align 8
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %3, i32 0, i32 0
  store ptr %1, ptr %5, align 8
  store ptr %0, ptr %4, align 8
    #dbg_declare(ptr %4, !206, !DIExpression(), !207)
    #dbg_declare(ptr %3, !208, !DIExpression(), !209)
  %6 = load ptr, ptr %4, align 8
  ret void, !dbg !210
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %0) #2 comdat align 2 !dbg !211 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !212, !DIExpression(), !213)
    #dbg_declare(ptr %2, !214, !DIExpression(), !215)
  call void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7, !dbg !215
  %4 = load ptr, ptr %3, align 8, !dbg !216
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0, !dbg !217
  store ptr %4, ptr %5, align 8, !dbg !218
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0, !dbg !219
  %7 = load ptr, ptr %6, align 8, !dbg !219
  ret ptr %7, !dbg !219
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 !dbg !220 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !221, !DIExpression(), !223)
  %4 = load ptr, ptr %3, align 8
  %5 = call noundef ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv(ptr noundef nonnull align 8 dereferenceable(8) %4) #7, !dbg !224
  %6 = call ptr @_ZNSt7__n486116coroutine_handleIvE12from_addressEPv(ptr noundef %5) #7, !dbg !225
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0, !dbg !225
  store ptr %6, ptr %7, align 8, !dbg !225
  %8 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0, !dbg !226
  %9 = load ptr, ptr %8, align 8, !dbg !226
  ret ptr %9, !dbg !226
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %0) #2 comdat align 2 !dbg !227 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !228, !DIExpression(), !229)
  %3 = load ptr, ptr %2, align 8
  ret void, !dbg !230
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %0, i32 noundef %1) #2 comdat align 2 !dbg !231 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !232, !DIExpression(), !233)
  store i32 %1, ptr %4, align 4
    #dbg_declare(ptr %4, !234, !DIExpression(), !235)
  %5 = load ptr, ptr %3, align 8
  %6 = load i32, ptr %4, align 4, !dbg !236
  %7 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %5, i32 0, i32 0, !dbg !237
  store i32 %6, ptr %7, align 4, !dbg !238
  ret void, !dbg !239
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__yield(ptr noundef nonnull %0, ptr noundef %1) #3 !dbg !240 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !241, !DIExpression(), !242)
  store ptr %1, ptr %4, align 8
    #dbg_declare(ptr %4, !243, !DIExpression(), !242)
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7, !dbg !244
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0, !dbg !244
  store ptr %9, ptr %10, align 8, !dbg !244
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7, !dbg !244
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !244
  store ptr %11, ptr %12, align 8, !dbg !244
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !244
  %14 = load ptr, ptr %13, align 8, !dbg !244
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7, !dbg !244
  ret void, !dbg !244
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 !dbg !245 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !246, !DIExpression(), !247)
  %3 = load ptr, ptr %2, align 8
  ret void, !dbg !248
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 !dbg !249 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !250, !DIExpression(), !251)
  %3 = load ptr, ptr %2, align 8
  ret void, !dbg !252
}

; Function Attrs: alwaysinline mustprogress sspstrong uwtable
define internal void @_Z5counti.__await_suspend_wrapper__final(ptr noundef nonnull %0, ptr noundef %1) #3 !dbg !253 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %6 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !254, !DIExpression(), !255)
  store ptr %1, ptr %4, align 8
    #dbg_declare(ptr %4, !256, !DIExpression(), !255)
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %4, align 8
  %9 = call ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv(ptr noundef %8) #7, !dbg !257
  %10 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %6, i32 0, i32 0, !dbg !257
  store ptr %9, ptr %10, align 8, !dbg !257
  %11 = call ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv(ptr noundef nonnull align 8 dereferenceable(8) %6) #7, !dbg !257
  %12 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !257
  store ptr %11, ptr %12, align 8, !dbg !257
  %13 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %5, i32 0, i32 0, !dbg !257
  %14 = load ptr, ptr %13, align 8, !dbg !257
  call void @_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE(ptr noundef nonnull align 1 dereferenceable(1) %7, ptr %14) #7, !dbg !257
  ret void, !dbg !257
}

; Function Attrs: nobuiltin nounwind
declare void @_ZdlPvm(ptr noundef, i64 noundef) #4

; Function Attrs: mustprogress noinline norecurse optnone sspstrong uwtable
define dso_local noundef i32 @main() #5 !dbg !258 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.Gen, align 8
  %3 = alloca i32, align 4
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !261, !DIExpression(), !262)
  %4 = call ptr @_Z5counti(i32 noundef 3), !dbg !263
  %5 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !263
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %5, i32 0, i32 0, !dbg !263
  store ptr %4, ptr %6, align 8, !dbg !263
    #dbg_declare(ptr %3, !264, !DIExpression(), !265)
  store i32 0, ptr %3, align 4, !dbg !265
  br label %7, !dbg !266

7:                                                ; preds = %22, %0
  %8 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !267
  %9 = call noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %8) #7, !dbg !268
  %10 = xor i1 %9, true, !dbg !269
  br i1 %10, label %11, label %23, !dbg !266

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !270
  call void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv(ptr noundef nonnull align 8 dereferenceable(8) %12), !dbg !272
  %13 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !273
  %14 = call noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %13) #7, !dbg !275
  br i1 %14, label %22, label %15, !dbg !276

15:                                               ; preds = %11
  %16 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !277
  %17 = call noundef nonnull align 4 dereferenceable(4) ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv(ptr noundef nonnull align 8 dereferenceable(8) %16), !dbg !278
  %18 = getelementptr inbounds nuw %"struct.Gen::promise_type", ptr %17, i32 0, i32 0, !dbg !279
  %19 = load i32, ptr %18, align 4, !dbg !279
  %20 = load i32, ptr %3, align 4, !dbg !280
  %21 = add nsw i32 %20, %19, !dbg !280
  store i32 %21, ptr %3, align 4, !dbg !280
  br label %22, !dbg !281

22:                                               ; preds = %15, %11
  br label %7, !dbg !266, !llvm.loop !282

23:                                               ; preds = %7
  %24 = getelementptr inbounds nuw %struct.Gen, ptr %2, i32 0, i32 0, !dbg !284
  call void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv(ptr noundef nonnull align 8 dereferenceable(8) %24), !dbg !285
  %25 = load i32, ptr %3, align 4, !dbg !286
  ret i32 %25, !dbg !287
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef zeroext i1 @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 !dbg !288 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !289, !DIExpression(), !290)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0, !dbg !291
  %5 = load ptr, ptr %4, align 8, !dbg !291
  %6 = load ptr, ptr %5, align 8, !dbg !292
  %7 = icmp eq ptr %6, null, !dbg !292
  ret i1 %7, !dbg !293
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #0 comdat align 2 !dbg !294 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !295, !DIExpression(), !296)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0, !dbg !297
  %5 = load ptr, ptr %4, align 8, !dbg !297
  %6 = getelementptr inbounds { ptr, ptr }, ptr %5, i32 0, i32 0
  %7 = load ptr, ptr %6, align 8
  call void %7(ptr %5), !dbg !298
  ret void, !dbg !299
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef nonnull align 4 dereferenceable(4) ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 !dbg !300 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !301, !DIExpression(), !302)
  %4 = load ptr, ptr %2, align 8
    #dbg_declare(ptr %3, !303, !DIExpression(), !304)
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %4, i32 0, i32 0, !dbg !305
  %6 = load ptr, ptr %5, align 8, !dbg !305
  %7 = getelementptr inbounds i8, ptr %6, i32 16, !dbg !306
  store ptr %7, ptr %3, align 8, !dbg !304
  %8 = load ptr, ptr %3, align 8, !dbg !307
  ret ptr %8, !dbg !308
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #0 comdat align 2 !dbg !309 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !310, !DIExpression(), !311)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0, !dbg !312
  %5 = load ptr, ptr %4, align 8, !dbg !312
  %6 = getelementptr inbounds { ptr, ptr }, ptr %5, i32 0, i32 1
  %7 = load ptr, ptr %6, align 8
  call void %7(ptr %5), !dbg !313
  ret void, !dbg !314
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_(ptr noundef nonnull align 4 dereferenceable(4) %0) #2 comdat align 2 !dbg !315 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !316, !DIExpression(), !317)
    #dbg_declare(ptr %2, !318, !DIExpression(), !319)
  call void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7, !dbg !319
  %4 = load ptr, ptr %3, align 8, !dbg !320, !nonnull !156, !align !321
  %5 = getelementptr inbounds i8, ptr %4, i32 -16, !dbg !322
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0, !dbg !323
  store ptr %5, ptr %6, align 8, !dbg !324
  %7 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %2, i32 0, i32 0, !dbg !325
  %8 = load ptr, ptr %7, align 8, !dbg !325
  ret ptr %8, !dbg !325
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %0) unnamed_addr #2 comdat align 2 !dbg !326 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !327, !DIExpression(), !329)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0, !dbg !330
  store ptr null, ptr %4, align 8, !dbg !330
  ret void, !dbg !331
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local ptr @_ZNSt7__n486116coroutine_handleIvE12from_addressEPv(ptr noundef %0) #2 comdat align 2 !dbg !332 {
  %2 = alloca %"struct.std::__n4861::coroutine_handle.0", align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !333, !DIExpression(), !334)
    #dbg_declare(ptr %2, !335, !DIExpression(), !336)
  call void @_ZNSt7__n486116coroutine_handleIvEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %2) #7, !dbg !336
  %4 = load ptr, ptr %3, align 8, !dbg !337
  %5 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0, !dbg !338
  store ptr %4, ptr %5, align 8, !dbg !339
  %6 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %2, i32 0, i32 0, !dbg !340
  %7 = load ptr, ptr %6, align 8, !dbg !340
  ret ptr %7, !dbg !340
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local noundef ptr @_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv(ptr noundef nonnull align 8 dereferenceable(8) %0) #2 comdat align 2 !dbg !341 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !342, !DIExpression(), !343)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle", ptr %3, i32 0, i32 0, !dbg !344
  %5 = load ptr, ptr %4, align 8, !dbg !344
  ret ptr %5, !dbg !345
}

; Function Attrs: mustprogress noinline nounwind optnone sspstrong uwtable
define linkonce_odr dso_local void @_ZNSt7__n486116coroutine_handleIvEC2Ev(ptr noundef nonnull align 8 dereferenceable(8) %0) unnamed_addr #2 comdat align 2 !dbg !346 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !347, !DIExpression(), !349)
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %"struct.std::__n4861::coroutine_handle.0", ptr %3, i32 0, i32 0, !dbg !350
  store ptr null, ptr %4, align 8, !dbg !350
  ret void, !dbg !351
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.resume(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 !dbg !352 {
  %2 = alloca ptr, align 8
    #dbg_declare(ptr %2, !355, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 24), !358)
    #dbg_declare(ptr %2, !359, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 16), !360)
    #dbg_declare(ptr %2, !361, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 20), !360)
    #dbg_declare(ptr %2, !354, !DIExpression(DW_OP_deref), !362)
  store ptr %0, ptr %2, align 8
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4, !coro.outside.frame !156
  %6 = alloca %struct.Gen, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 20, !dbg !363
  %8 = getelementptr inbounds i8, ptr %0, i64 29, !dbg !363
  %9 = getelementptr inbounds i8, ptr %0, i64 24, !dbg !363
  %10 = getelementptr inbounds i8, ptr %0, i64 30, !dbg !363
  %11 = getelementptr inbounds i8, ptr %0, i64 31, !dbg !363
  %12 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !363
  br label %13, !dbg !363

13:                                               ; preds = %1
  %14 = getelementptr inbounds i8, ptr %0, i64 28
  %15 = load i2, ptr %14, align 1
  switch i2 %15, label %89 [
    i2 0, label %16
    i2 1, label %43
  ]

16:                                               ; preds = %13
    #dbg_label(!364, !365)
  br label %17, !dbg !365

17:                                               ; preds = %16
  br label %18, !dbg !365

18:                                               ; preds = %17
  switch i8 0, label %86 [
    i8 0, label %22
    i8 1, label %19
  ], !dbg !365

19:                                               ; preds = %18
  br label %20, !dbg !365

20:                                               ; preds = %19
  %21 = phi i32 [ 2, %19 ]
  br label %25, !dbg !365

22:                                               ; preds = %18
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %8) #7, !dbg !365
  br label %23, !dbg !365

23:                                               ; preds = %22
  %24 = phi i32 [ 0, %22 ]
  br label %25, !dbg !365

25:                                               ; preds = %23, %20
  %26 = phi i32 [ %24, %23 ], [ %21, %20 ]
  switch i32 %26, label %88 [
    i32 0, label %27
    i32 2, label %82
  ]

27:                                               ; preds = %25
  store i32 0, ptr %9, align 4, !dbg !358
  br label %28, !dbg !366

28:                                               ; preds = %59, %27
  %29 = load i32, ptr %9, align 4, !dbg !367
  %30 = load i32, ptr %7, align 4, !dbg !369
  %31 = icmp slt i32 %29, %30, !dbg !370
  br i1 %31, label %35, label %32, !dbg !371

32:                                               ; preds = %28
  br label %33, !dbg !371

33:                                               ; preds = %32
  %34 = phi i32 [ 4, %32 ]
  br label %62, !dbg !371

35:                                               ; preds = %28
  %36 = load i32, ptr %9, align 4, !dbg !372
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %12, i32 noundef %36), !dbg !373
  br label %37, !dbg !373

37:                                               ; preds = %35
  %38 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !373
  br i1 %38, label %50, label %39, !dbg !373

39:                                               ; preds = %37
  %40 = getelementptr inbounds i8, ptr %0, i64 28, !dbg !373
  store i2 1, ptr %40, align 1, !dbg !373
  br label %41, !dbg !373

41:                                               ; preds = %39
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %10, ptr %0) #7, !dbg !373
  br label %42, !dbg !373

42:                                               ; preds = %41
  br label %44, !dbg !373

43:                                               ; preds = %13
    #dbg_label(!374, !373)
  br label %44, !dbg !373

44:                                               ; preds = %43, %42
  %45 = phi i8 [ -1, %42 ], [ 0, %43 ]
  br label %46, !dbg !373

46:                                               ; preds = %44
  switch i8 %45, label %86 [
    i8 0, label %50
    i8 1, label %47
  ], !dbg !373

47:                                               ; preds = %46
  br label %48, !dbg !373

48:                                               ; preds = %47
  %49 = phi i32 [ 2, %47 ]
  br label %53, !dbg !373

50:                                               ; preds = %46, %37
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !373
  br label %51, !dbg !373

51:                                               ; preds = %50
  %52 = phi i32 [ 0, %50 ]
  br label %53, !dbg !373

53:                                               ; preds = %51, %48
  %54 = phi i32 [ %52, %51 ], [ %49, %48 ]
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %58, label %56

56:                                               ; preds = %53
  %57 = phi i32 [ %54, %53 ]
  br label %62

58:                                               ; preds = %53
  br label %59, !dbg !373

59:                                               ; preds = %58
  %60 = load i32, ptr %9, align 4, !dbg !375
  %61 = add nsw i32 %60, 1, !dbg !375
  store i32 %61, ptr %9, align 4, !dbg !375
  br label %28, !dbg !376, !llvm.loop !377

62:                                               ; preds = %56, %33
  %63 = phi i32 [ %57, %56 ], [ %34, %33 ]
  switch i32 %63, label %88 [
    i32 4, label %64
    i32 2, label %82
  ]

64:                                               ; preds = %62
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %12), !dbg !365
  br label %65, !dbg !365

65:                                               ; preds = %64
  br label %66, !dbg !365

66:                                               ; preds = %65
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %12) #7, !dbg !365
  %67 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !365
  br i1 %67, label %76, label %68, !dbg !365

68:                                               ; preds = %66
  store ptr null, ptr %0, align 8, !dbg !365
  br label %69, !dbg !365

69:                                               ; preds = %68
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %11, ptr %0) #7, !dbg !365
  br label %70, !dbg !365

70:                                               ; preds = %69
  br label %71, !dbg !365

71:                                               ; preds = %70
  br label %72, !dbg !365

72:                                               ; preds = %71
  switch i8 -1, label %86 [
    i8 0, label %76
    i8 1, label %73
  ], !dbg !365

73:                                               ; preds = %72
  br label %74, !dbg !365

74:                                               ; preds = %73
  %75 = phi i32 [ 2, %73 ]
  br label %79, !dbg !365

76:                                               ; preds = %72, %66
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !365
  br label %77, !dbg !365

77:                                               ; preds = %76
  %78 = phi i32 [ 0, %76 ]
  br label %79, !dbg !365

79:                                               ; preds = %77, %74
  %80 = phi i32 [ %78, %77 ], [ %75, %74 ]
  switch i32 %80, label %88 [
    i32 0, label %81
    i32 2, label %82
  ]

81:                                               ; preds = %79
  br label %82, !dbg !365

82:                                               ; preds = %81, %79, %62, %25
  %83 = icmp ne ptr %0, null, !dbg !365
  br i1 %83, label %84, label %85, !dbg !365

84:                                               ; preds = %82
  call void @_ZdlPvm(ptr noundef %0, i64 noundef 32) #7, !dbg !365
  br label %85, !dbg !365

85:                                               ; preds = %84, %82
  br label %86, !dbg !365

86:                                               ; preds = %85, %72, %46, %18
  br label %87, !dbg !365

87:                                               ; preds = %86
  ret void, !dbg !365

88:                                               ; preds = %79, %62, %25
  unreachable

89:                                               ; preds = %13
  unreachable, !dbg !365
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.destroy(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 !dbg !379 {
  %2 = alloca ptr, align 8
    #dbg_declare(ptr %2, !382, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 24), !385)
    #dbg_declare(ptr %2, !386, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 16), !387)
    #dbg_declare(ptr %2, !388, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 20), !387)
    #dbg_declare(ptr %2, !381, !DIExpression(DW_OP_deref), !389)
  store ptr %0, ptr %2, align 8
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4, !coro.outside.frame !156
  %6 = alloca %struct.Gen, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 20, !dbg !390
  %8 = getelementptr inbounds i8, ptr %0, i64 29, !dbg !390
  %9 = getelementptr inbounds i8, ptr %0, i64 24, !dbg !390
  %10 = getelementptr inbounds i8, ptr %0, i64 30, !dbg !390
  %11 = getelementptr inbounds i8, ptr %0, i64 31, !dbg !390
  %12 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !390
  br label %13, !dbg !390

13:                                               ; preds = %1
  %14 = getelementptr inbounds i8, ptr %0, i64 28
  %15 = load i2, ptr %14, align 1
  %16 = load ptr, ptr %0, align 8
  %17 = icmp eq ptr %16, null
  br i1 %17, label %74, label %18

18:                                               ; preds = %13
  switch i2 %15, label %94 [
    i2 0, label %19
    i2 1, label %46
  ]

19:                                               ; preds = %18
    #dbg_label(!391, !392)
  br label %20, !dbg !392

20:                                               ; preds = %19
  br label %21, !dbg !392

21:                                               ; preds = %20
  switch i8 1, label %91 [
    i8 0, label %25
    i8 1, label %22
  ], !dbg !392

22:                                               ; preds = %21
  br label %23, !dbg !392

23:                                               ; preds = %22
  %24 = phi i32 [ 2, %22 ]
  br label %28, !dbg !392

25:                                               ; preds = %21
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %8) #7, !dbg !392
  br label %26, !dbg !392

26:                                               ; preds = %25
  %27 = phi i32 [ 0, %25 ]
  br label %28, !dbg !392

28:                                               ; preds = %26, %23
  %29 = phi i32 [ %27, %26 ], [ %24, %23 ]
  switch i32 %29, label %93 [
    i32 0, label %30
    i32 2, label %87
  ]

30:                                               ; preds = %28
  store i32 0, ptr %9, align 4, !dbg !385
  br label %31, !dbg !393

31:                                               ; preds = %62, %30
  %32 = load i32, ptr %9, align 4, !dbg !394
  %33 = load i32, ptr %7, align 4, !dbg !396
  %34 = icmp slt i32 %32, %33, !dbg !397
  br i1 %34, label %38, label %35, !dbg !398

35:                                               ; preds = %31
  br label %36, !dbg !398

36:                                               ; preds = %35
  %37 = phi i32 [ 4, %35 ]
  br label %65, !dbg !398

38:                                               ; preds = %31
  %39 = load i32, ptr %9, align 4, !dbg !399
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %12, i32 noundef %39), !dbg !400
  br label %40, !dbg !400

40:                                               ; preds = %38
  %41 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !400
  br i1 %41, label %53, label %42, !dbg !400

42:                                               ; preds = %40
  %43 = getelementptr inbounds i8, ptr %0, i64 28, !dbg !400
  store i2 1, ptr %43, align 1, !dbg !400
  br label %44, !dbg !400

44:                                               ; preds = %42
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %10, ptr %0) #7, !dbg !400
  br label %45, !dbg !400

45:                                               ; preds = %44
  br label %47, !dbg !400

46:                                               ; preds = %18
    #dbg_label(!401, !400)
  br label %47, !dbg !400

47:                                               ; preds = %46, %45
  %48 = phi i8 [ -1, %45 ], [ 1, %46 ]
  br label %49, !dbg !400

49:                                               ; preds = %47
  switch i8 %48, label %91 [
    i8 0, label %53
    i8 1, label %50
  ], !dbg !400

50:                                               ; preds = %49
  br label %51, !dbg !400

51:                                               ; preds = %50
  %52 = phi i32 [ 2, %50 ]
  br label %56, !dbg !400

53:                                               ; preds = %49, %40
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !400
  br label %54, !dbg !400

54:                                               ; preds = %53
  %55 = phi i32 [ 0, %53 ]
  br label %56, !dbg !400

56:                                               ; preds = %54, %51
  %57 = phi i32 [ %55, %54 ], [ %52, %51 ]
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %61, label %59

59:                                               ; preds = %56
  %60 = phi i32 [ %57, %56 ]
  br label %65

61:                                               ; preds = %56
  br label %62, !dbg !400

62:                                               ; preds = %61
  %63 = load i32, ptr %9, align 4, !dbg !402
  %64 = add nsw i32 %63, 1, !dbg !402
  store i32 %64, ptr %9, align 4, !dbg !402
  br label %31, !dbg !403, !llvm.loop !404

65:                                               ; preds = %59, %36
  %66 = phi i32 [ %60, %59 ], [ %37, %36 ]
  switch i32 %66, label %93 [
    i32 4, label %67
    i32 2, label %87
  ]

67:                                               ; preds = %65
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %12), !dbg !392
  br label %68, !dbg !392

68:                                               ; preds = %67
  br label %69, !dbg !392

69:                                               ; preds = %68
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %12) #7, !dbg !392
  %70 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !392
  br i1 %70, label %81, label %71, !dbg !392

71:                                               ; preds = %69
  store ptr null, ptr %0, align 8, !dbg !392
  br label %72, !dbg !392

72:                                               ; preds = %71
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %11, ptr %0) #7, !dbg !392
  br label %73, !dbg !392

73:                                               ; preds = %72
  br label %75, !dbg !392

74:                                               ; preds = %13
    #dbg_label(!406, !392)
  br label %75, !dbg !392

75:                                               ; preds = %74, %73
  %76 = phi i8 [ -1, %73 ], [ 1, %74 ]
  br label %77, !dbg !392

77:                                               ; preds = %75
  switch i8 %76, label %91 [
    i8 0, label %81
    i8 1, label %78
  ], !dbg !392

78:                                               ; preds = %77
  br label %79, !dbg !392

79:                                               ; preds = %78
  %80 = phi i32 [ 2, %78 ]
  br label %84, !dbg !392

81:                                               ; preds = %77, %69
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !392
  br label %82, !dbg !392

82:                                               ; preds = %81
  %83 = phi i32 [ 0, %81 ]
  br label %84, !dbg !392

84:                                               ; preds = %82, %79
  %85 = phi i32 [ %83, %82 ], [ %80, %79 ]
  switch i32 %85, label %93 [
    i32 0, label %86
    i32 2, label %87
  ]

86:                                               ; preds = %84
  br label %87, !dbg !392

87:                                               ; preds = %86, %84, %65, %28
  %88 = icmp ne ptr %0, null, !dbg !392
  br i1 %88, label %89, label %90, !dbg !392

89:                                               ; preds = %87
  call void @_ZdlPvm(ptr noundef %0, i64 noundef 32) #7, !dbg !392
  br label %90, !dbg !392

90:                                               ; preds = %89, %87
  br label %91, !dbg !392

91:                                               ; preds = %90, %77, %49, %21
  br label %92, !dbg !392

92:                                               ; preds = %91
  ret void, !dbg !392

93:                                               ; preds = %84, %65, %28
  unreachable

94:                                               ; preds = %18
  unreachable, !dbg !392
}

; Function Attrs: mustprogress noinline optnone sspstrong uwtable
define internal void @_Z5counti.cleanup(ptr noundef nonnull align 8 dereferenceable(32) %0) #0 personality ptr @__gxx_personality_v0 !dbg !407 {
  %2 = alloca ptr, align 8
    #dbg_declare(ptr %2, !410, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 24), !413)
    #dbg_declare(ptr %2, !414, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 16), !415)
    #dbg_declare(ptr %2, !416, !DIExpression(DW_OP_deref, DW_OP_plus_uconst, 20), !415)
    #dbg_declare(ptr %2, !409, !DIExpression(DW_OP_deref), !417)
  store ptr %0, ptr %2, align 8
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4, !coro.outside.frame !156
  %6 = alloca %struct.Gen, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 20, !dbg !418
  %8 = getelementptr inbounds i8, ptr %0, i64 29, !dbg !418
  %9 = getelementptr inbounds i8, ptr %0, i64 24, !dbg !418
  %10 = getelementptr inbounds i8, ptr %0, i64 30, !dbg !418
  %11 = getelementptr inbounds i8, ptr %0, i64 31, !dbg !418
  %12 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !418
  br label %13, !dbg !418

13:                                               ; preds = %1
  %14 = getelementptr inbounds i8, ptr %0, i64 28
  %15 = load i2, ptr %14, align 1
  %16 = load ptr, ptr %0, align 8
  %17 = icmp eq ptr %16, null
  br i1 %17, label %74, label %18

18:                                               ; preds = %13
  switch i2 %15, label %94 [
    i2 0, label %19
    i2 1, label %46
  ]

19:                                               ; preds = %18
    #dbg_label(!419, !420)
  br label %20, !dbg !420

20:                                               ; preds = %19
  br label %21, !dbg !420

21:                                               ; preds = %20
  switch i8 1, label %91 [
    i8 0, label %25
    i8 1, label %22
  ], !dbg !420

22:                                               ; preds = %21
  br label %23, !dbg !420

23:                                               ; preds = %22
  %24 = phi i32 [ 2, %22 ]
  br label %28, !dbg !420

25:                                               ; preds = %21
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %8) #7, !dbg !420
  br label %26, !dbg !420

26:                                               ; preds = %25
  %27 = phi i32 [ 0, %25 ]
  br label %28, !dbg !420

28:                                               ; preds = %26, %23
  %29 = phi i32 [ %27, %26 ], [ %24, %23 ]
  switch i32 %29, label %93 [
    i32 0, label %30
    i32 2, label %87
  ]

30:                                               ; preds = %28
  store i32 0, ptr %9, align 4, !dbg !413
  br label %31, !dbg !421

31:                                               ; preds = %62, %30
  %32 = load i32, ptr %9, align 4, !dbg !422
  %33 = load i32, ptr %7, align 4, !dbg !424
  %34 = icmp slt i32 %32, %33, !dbg !425
  br i1 %34, label %38, label %35, !dbg !426

35:                                               ; preds = %31
  br label %36, !dbg !426

36:                                               ; preds = %35
  %37 = phi i32 [ 4, %35 ]
  br label %65, !dbg !426

38:                                               ; preds = %31
  %39 = load i32, ptr %9, align 4, !dbg !427
  call void @_ZN3Gen12promise_type11yield_valueEi(ptr noundef nonnull align 4 dereferenceable(4) %12, i32 noundef %39), !dbg !428
  br label %40, !dbg !428

40:                                               ; preds = %38
  %41 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !428
  br i1 %41, label %53, label %42, !dbg !428

42:                                               ; preds = %40
  %43 = getelementptr inbounds i8, ptr %0, i64 28, !dbg !428
  store i2 1, ptr %43, align 1, !dbg !428
  br label %44, !dbg !428

44:                                               ; preds = %42
  call void @_Z5counti.__await_suspend_wrapper__yield(ptr %10, ptr %0) #7, !dbg !428
  br label %45, !dbg !428

45:                                               ; preds = %44
  br label %47, !dbg !428

46:                                               ; preds = %18
    #dbg_label(!429, !428)
  br label %47, !dbg !428

47:                                               ; preds = %46, %45
  %48 = phi i8 [ -1, %45 ], [ 1, %46 ]
  br label %49, !dbg !428

49:                                               ; preds = %47
  switch i8 %48, label %91 [
    i8 0, label %53
    i8 1, label %50
  ], !dbg !428

50:                                               ; preds = %49
  br label %51, !dbg !428

51:                                               ; preds = %50
  %52 = phi i32 [ 2, %50 ]
  br label %56, !dbg !428

53:                                               ; preds = %49, %40
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %10) #7, !dbg !428
  br label %54, !dbg !428

54:                                               ; preds = %53
  %55 = phi i32 [ 0, %53 ]
  br label %56, !dbg !428

56:                                               ; preds = %54, %51
  %57 = phi i32 [ %55, %54 ], [ %52, %51 ]
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %61, label %59

59:                                               ; preds = %56
  %60 = phi i32 [ %57, %56 ]
  br label %65

61:                                               ; preds = %56
  br label %62, !dbg !428

62:                                               ; preds = %61
  %63 = load i32, ptr %9, align 4, !dbg !430
  %64 = add nsw i32 %63, 1, !dbg !430
  store i32 %64, ptr %9, align 4, !dbg !430
  br label %31, !dbg !431, !llvm.loop !432

65:                                               ; preds = %59, %36
  %66 = phi i32 [ %60, %59 ], [ %37, %36 ]
  switch i32 %66, label %93 [
    i32 4, label %67
    i32 2, label %87
  ]

67:                                               ; preds = %65
  call void @_ZN3Gen12promise_type11return_voidEv(ptr noundef nonnull align 4 dereferenceable(4) %12), !dbg !420
  br label %68, !dbg !420

68:                                               ; preds = %67
  br label %69, !dbg !420

69:                                               ; preds = %68
  call void @_ZN3Gen12promise_type13final_suspendEv(ptr noundef nonnull align 4 dereferenceable(4) %12) #7, !dbg !420
  %70 = call noundef zeroext i1 @_ZNKSt7__n486114suspend_always11await_readyEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !420
  br i1 %70, label %81, label %71, !dbg !420

71:                                               ; preds = %69
  store ptr null, ptr %0, align 8, !dbg !420
  br label %72, !dbg !420

72:                                               ; preds = %71
  call void @_Z5counti.__await_suspend_wrapper__final(ptr %11, ptr %0) #7, !dbg !420
  br label %73, !dbg !420

73:                                               ; preds = %72
  br label %75, !dbg !420

74:                                               ; preds = %13
    #dbg_label(!434, !420)
  br label %75, !dbg !420

75:                                               ; preds = %74, %73
  %76 = phi i8 [ -1, %73 ], [ 1, %74 ]
  br label %77, !dbg !420

77:                                               ; preds = %75
  switch i8 %76, label %91 [
    i8 0, label %81
    i8 1, label %78
  ], !dbg !420

78:                                               ; preds = %77
  br label %79, !dbg !420

79:                                               ; preds = %78
  %80 = phi i32 [ 2, %78 ]
  br label %84, !dbg !420

81:                                               ; preds = %77, %69
  call void @_ZNKSt7__n486114suspend_always12await_resumeEv(ptr noundef nonnull align 1 dereferenceable(1) %11) #7, !dbg !420
  br label %82, !dbg !420

82:                                               ; preds = %81
  %83 = phi i32 [ 0, %81 ]
  br label %84, !dbg !420

84:                                               ; preds = %82, %79
  %85 = phi i32 [ %83, %82 ], [ %80, %79 ]
  switch i32 %85, label %93 [
    i32 0, label %86
    i32 2, label %87
  ]

86:                                               ; preds = %84
  br label %87, !dbg !420

87:                                               ; preds = %86, %84, %65, %28
  %88 = icmp ne ptr null, null, !dbg !420
  br i1 %88, label %89, label %90, !dbg !420

89:                                               ; preds = %87
  call void @_ZdlPvm(ptr noundef null, i64 noundef 32) #7, !dbg !420
  br label %90, !dbg !420

90:                                               ; preds = %89, %87
  br label %91, !dbg !420

91:                                               ; preds = %90, %77, %49, %21
  br label %92, !dbg !420

92:                                               ; preds = %91
  ret void, !dbg !420

93:                                               ; preds = %84, %65, %28
  unreachable

94:                                               ; preds = %18
  unreachable, !dbg !420
}

attributes #0 = { mustprogress noinline optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nobuiltin allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { alwaysinline mustprogress sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "sample-profile-suffix-elision-policy"="selected" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nobuiltin nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress noinline norecurse optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { allocsize(0) }
attributes #7 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!125, !126, !127, !128, !129, !130, !131}
!llvm.ident = !{!132}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "test/cpp/samples/coroutine.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "81a5ad31eddd36b2bc49117452e7da0c")
!2 = !{!3, !122, !124, !49, !6}
!3 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "Gen", file: !1, line: 2, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !4, identifier: "_ZTS3Gen")
!4 = !{!5}
!5 = !DIDerivedType(tag: DW_TAG_member, name: "h", scope: !3, file: !1, line: 6, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "coroutine_handle<Gen::promise_type>", scope: !8, file: !7, line: 198, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !10, templateParams: !120, identifier: "_ZTSNSt7__n486116coroutine_handleIN3Gen12promise_typeEEE")
!7 = !DIFile(filename: "/usr/lib/gcc/x86_64-alpine-linux-musl/15.2.0/../../../../include/c++/15.2.0/coroutine", directory: "", checksumkind: CSK_MD5, checksum: "264518c8a6bbba954d8dfbc74162a7e2")
!8 = !DINamespace(name: "__n4861", scope: !9, exportSymbols: true)
!9 = !DINamespace(name: "std", scope: null)
!10 = !{!11, !13, !17, !23, !93, !97, !102, !105, !108, !111, !112, !115, !116, !117}
!11 = !DIDerivedType(tag: DW_TAG_member, name: "_M_fr_ptr", scope: !6, file: !7, line: 260, baseType: !12, size: 64, flags: DIFlagPrivate)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!13 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC4Ev", scope: !6, file: !7, line: 202, type: !14, scopeLine: 202, flags: DIFlagPrototyped, spFlags: 0)
!14 = !DISubroutineType(types: !15)
!15 = !{null, !16}
!16 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!17 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC4EDn", scope: !6, file: !7, line: 204, type: !18, scopeLine: 204, flags: DIFlagPrototyped, spFlags: 0)
!18 = !DISubroutineType(types: !19)
!19 = !{null, !16, !20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "nullptr_t", scope: !9, file: !21, line: 342, baseType: !22)
!21 = !DIFile(filename: "/usr/lib/gcc/x86_64-alpine-linux-musl/15.2.0/../../../../include/c++/15.2.0/x86_64-alpine-linux-musl/bits/c++config.h", directory: "", checksumkind: CSK_MD5, checksum: "5eec1bce6d97e7b076e1ef1ad2c40d8a")
!22 = !DIBasicType(tag: DW_TAG_unspecified_type, name: "decltype(nullptr)")
!23 = !DISubprogram(name: "from_promise", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_", scope: !6, file: !7, line: 207, type: !24, scopeLine: 207, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: 0)
!24 = !DISubroutineType(types: !25)
!25 = !{!6, !26}
!26 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !27, size: 64)
!27 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "promise_type", scope: !3, file: !1, line: 2, size: 32, flags: DIFlagTypePassByValue, elements: !28, identifier: "_ZTSN3Gen12promise_typeE")
!28 = !{!29, !31, !35, !85, !86, !89, !92}
!29 = !DIDerivedType(tag: DW_TAG_member, name: "v", scope: !27, file: !1, line: 2, baseType: !30, size: 32)
!30 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!31 = !DISubprogram(name: "get_return_object", linkageName: "_ZN3Gen12promise_type17get_return_objectEv", scope: !27, file: !1, line: 3, type: !32, scopeLine: 3, flags: DIFlagPrototyped, spFlags: 0)
!32 = !DISubroutineType(types: !33)
!33 = !{!3, !34}
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!35 = !DISubprogram(name: "initial_suspend", linkageName: "_ZN3Gen12promise_type15initial_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: 0)
!36 = !DISubroutineType(types: !37)
!37 = !{!38, !34}
!38 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "suspend_always", scope: !8, file: !7, line: 329, size: 8, flags: DIFlagTypePassByValue, elements: !39, identifier: "_ZTSNSt7__n486114suspend_alwaysE")
!39 = !{!40, !46, !82}
!40 = !DISubprogram(name: "await_ready", linkageName: "_ZNKSt7__n486114suspend_always11await_readyEv", scope: !38, file: !7, line: 331, type: !41, scopeLine: 331, flags: DIFlagPrototyped, spFlags: 0)
!41 = !DISubroutineType(types: !42)
!42 = !{!43, !44}
!43 = !DIBasicType(name: "bool", size: 8, encoding: DW_ATE_boolean)
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !38)
!46 = !DISubprogram(name: "await_suspend", linkageName: "_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE", scope: !38, file: !7, line: 333, type: !47, scopeLine: 333, flags: DIFlagPrototyped, spFlags: 0)
!47 = !DISubroutineType(types: !48)
!48 = !{null, !44, !49}
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "coroutine_handle<void>", scope: !8, file: !7, line: 103, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !50, templateParams: !80, identifier: "_ZTSNSt7__n486116coroutine_handleIvEE")
!50 = !{!51, !52, !56, !59, !63, !68, !71, !74, !75, !78, !79}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "_M_fr_ptr", scope: !49, file: !7, line: 147, baseType: !12, size: 64, flags: DIFlagProtected)
!52 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIvEC4Ev", scope: !49, file: !7, line: 107, type: !53, scopeLine: 107, flags: DIFlagPrototyped, spFlags: 0)
!53 = !DISubroutineType(types: !54)
!54 = !{null, !55}
!55 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!56 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIvEC4EDn", scope: !49, file: !7, line: 109, type: !57, scopeLine: 109, flags: DIFlagPrototyped, spFlags: 0)
!57 = !DISubroutineType(types: !58)
!58 = !{null, !55, !20}
!59 = !DISubprogram(name: "operator=", linkageName: "_ZNSt7__n486116coroutine_handleIvEaSEDn", scope: !49, file: !7, line: 113, type: !60, scopeLine: 113, flags: DIFlagPrototyped, spFlags: 0)
!60 = !DISubroutineType(types: !61)
!61 = !{!62, !55, !20}
!62 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !49, size: 64)
!63 = !DISubprogram(name: "address", linkageName: "_ZNKSt7__n486116coroutine_handleIvE7addressEv", scope: !49, file: !7, line: 121, type: !64, scopeLine: 121, flags: DIFlagPrototyped, spFlags: 0)
!64 = !DISubroutineType(types: !65)
!65 = !{!12, !66}
!66 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !67, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!67 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !49)
!68 = !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIvE12from_addressEPv", scope: !49, file: !7, line: 123, type: !69, scopeLine: 123, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: 0)
!69 = !DISubroutineType(types: !70)
!70 = !{!49, !12}
!71 = !DISubprogram(name: "operator bool", linkageName: "_ZNKSt7__n486116coroutine_handleIvEcvbEv", scope: !49, file: !7, line: 132, type: !72, scopeLine: 132, flags: DIFlagExplicit | DIFlagPrototyped, spFlags: 0)
!72 = !DISubroutineType(types: !73)
!73 = !{!43, !66}
!74 = !DISubprogram(name: "done", linkageName: "_ZNKSt7__n486116coroutine_handleIvE4doneEv", scope: !49, file: !7, line: 137, type: !72, scopeLine: 137, flags: DIFlagPrototyped, spFlags: 0)
!75 = !DISubprogram(name: "operator()", linkageName: "_ZNKSt7__n486116coroutine_handleIvEclEv", scope: !49, file: !7, line: 140, type: !76, scopeLine: 140, flags: DIFlagPrototyped, spFlags: 0)
!76 = !DISubroutineType(types: !77)
!77 = !{null, !66}
!78 = !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIvE6resumeEv", scope: !49, file: !7, line: 142, type: !76, scopeLine: 142, flags: DIFlagPrototyped, spFlags: 0)
!79 = !DISubprogram(name: "destroy", linkageName: "_ZNKSt7__n486116coroutine_handleIvE7destroyEv", scope: !49, file: !7, line: 144, type: !76, scopeLine: 144, flags: DIFlagPrototyped, spFlags: 0)
!80 = !{!81}
!81 = !DITemplateTypeParameter(name: "_Promise", type: null, defaulted: true)
!82 = !DISubprogram(name: "await_resume", linkageName: "_ZNKSt7__n486114suspend_always12await_resumeEv", scope: !38, file: !7, line: 335, type: !83, scopeLine: 335, flags: DIFlagPrototyped, spFlags: 0)
!83 = !DISubroutineType(types: !84)
!84 = !{null, !44}
!85 = !DISubprogram(name: "final_suspend", linkageName: "_ZN3Gen12promise_type13final_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: 0)
!86 = !DISubprogram(name: "yield_value", linkageName: "_ZN3Gen12promise_type11yield_valueEi", scope: !27, file: !1, line: 5, type: !87, scopeLine: 5, flags: DIFlagPrototyped, spFlags: 0)
!87 = !DISubroutineType(types: !88)
!88 = !{!38, !34, !30}
!89 = !DISubprogram(name: "return_void", linkageName: "_ZN3Gen12promise_type11return_voidEv", scope: !27, file: !1, line: 5, type: !90, scopeLine: 5, flags: DIFlagPrototyped, spFlags: 0)
!90 = !DISubroutineType(types: !91)
!91 = !{null, !34}
!92 = !DISubprogram(name: "unhandled_exception", linkageName: "_ZN3Gen12promise_type19unhandled_exceptionEv", scope: !27, file: !1, line: 5, type: !90, scopeLine: 5, flags: DIFlagPrototyped, spFlags: 0)
!93 = !DISubprogram(name: "operator=", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEaSEDn", scope: !6, file: !7, line: 215, type: !94, scopeLine: 215, flags: DIFlagPrototyped, spFlags: 0)
!94 = !DISubroutineType(types: !95)
!95 = !{!96, !16, !20}
!96 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !6, size: 64)
!97 = !DISubprogram(name: "address", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv", scope: !6, file: !7, line: 223, type: !98, scopeLine: 223, flags: DIFlagPrototyped, spFlags: 0)
!98 = !DISubroutineType(types: !99)
!99 = !{!12, !100}
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!101 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!102 = !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv", scope: !6, file: !7, line: 225, type: !103, scopeLine: 225, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: 0)
!103 = !DISubroutineType(types: !104)
!104 = !{!6, !12}
!105 = !DISubprogram(name: "operator coroutine_handle", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv", scope: !6, file: !7, line: 233, type: !106, scopeLine: 233, flags: DIFlagPrototyped, spFlags: 0)
!106 = !DISubroutineType(types: !107)
!107 = !{!49, !100}
!108 = !DISubprogram(name: "operator bool", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvbEv", scope: !6, file: !7, line: 237, type: !109, scopeLine: 237, flags: DIFlagExplicit | DIFlagPrototyped, spFlags: 0)
!109 = !DISubroutineType(types: !110)
!110 = !{!43, !100}
!111 = !DISubprogram(name: "done", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv", scope: !6, file: !7, line: 242, type: !109, scopeLine: 242, flags: DIFlagPrototyped, spFlags: 0)
!112 = !DISubprogram(name: "operator()", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEclEv", scope: !6, file: !7, line: 245, type: !113, scopeLine: 245, flags: DIFlagPrototyped, spFlags: 0)
!113 = !DISubroutineType(types: !114)
!114 = !{null, !100}
!115 = !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv", scope: !6, file: !7, line: 247, type: !113, scopeLine: 247, flags: DIFlagPrototyped, spFlags: 0)
!116 = !DISubprogram(name: "destroy", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv", scope: !6, file: !7, line: 249, type: !113, scopeLine: 249, flags: DIFlagPrototyped, spFlags: 0)
!117 = !DISubprogram(name: "promise", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv", scope: !6, file: !7, line: 252, type: !118, scopeLine: 252, flags: DIFlagPrototyped, spFlags: 0)
!118 = !DISubroutineType(types: !119)
!119 = !{!26, !100}
!120 = !{!121}
!121 = !DITemplateTypeParameter(name: "_Promise", type: !27)
!122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !123, size: 64)
!123 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!124 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64)
!125 = !{i32 7, !"Dwarf Version", i32 5}
!126 = !{i32 2, !"Debug Info Version", i32 3}
!127 = !{i32 4, !"probe-stack", !"inline-asm"}
!128 = !{i32 8, !"PIC Level", i32 2}
!129 = !{i32 7, !"PIE Level", i32 2}
!130 = !{i32 7, !"uwtable", i32 2}
!131 = !{i32 7, !"frame-pointer", i32 2}
!132 = !{!"Alpine clang version 23.1.5"}
!133 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti", scope: !1, file: !1, line: 7, type: !134, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !136)
!134 = !DISubroutineType(types: !135)
!135 = !{!3, !30}
!136 = !{!137}
!137 = !DILocalVariable(name: "__coro_frame", scope: !133, file: !1, line: 7, type: !138, flags: DIFlagArtificial)
!138 = !DICompositeType(tag: DW_TAG_structure_type, name: "_Z5counti.coro_frame_ty", file: !1, line: 7, size: 256, align: 64, flags: DIFlagArtificial, elements: !139)
!139 = !{!140, !141, !142, !144, !145, !150, !151, !152, !153}
!140 = !DIDerivedType(tag: DW_TAG_member, name: "__resume_fn", scope: !138, file: !1, line: 7, baseType: !12, size: 64, align: 64, flags: DIFlagArtificial)
!141 = !DIDerivedType(tag: DW_TAG_member, name: "__destroy_fn", scope: !138, file: !1, line: 7, baseType: !12, size: 64, align: 64, offset: 64, flags: DIFlagArtificial)
!142 = !DIDerivedType(tag: DW_TAG_member, name: "__coro_index", scope: !138, file: !1, line: 7, baseType: !143, size: 2, align: 8, offset: 224, flags: DIFlagArtificial)
!143 = !DIBasicType(name: "__coro_index", size: 8, encoding: DW_ATE_unsigned_char)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !138, file: !1, line: 7, baseType: !30, size: 32, align: 32, offset: 160, flags: DIFlagArtificial)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_0", scope: !138, file: !1, line: 7, baseType: !146, size: 8, align: 8, offset: 232, flags: DIFlagArtificial)
!146 = !DICompositeType(tag: DW_TAG_structure_type, name: "struct_std____n4861__suspend_always", scope: !138, file: !1, line: 7, size: 8, align: 64, flags: DIFlagArtificial, elements: !147)
!147 = !{!148}
!148 = !DIDerivedType(tag: DW_TAG_member, name: "__int_8", scope: !146, file: !1, line: 7, baseType: !149, size: 8, flags: DIFlagArtificial)
!149 = !DIBasicType(name: "__int_8", size: 8, encoding: DW_ATE_signed, flags: DIFlagArtificial)
!150 = !DIDerivedType(tag: DW_TAG_member, name: "i", scope: !138, file: !1, line: 7, baseType: !30, size: 32, align: 32, offset: 192, flags: DIFlagArtificial)
!151 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_1", scope: !138, file: !1, line: 7, baseType: !146, size: 8, align: 8, offset: 240, flags: DIFlagArtificial)
!152 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_2", scope: !138, file: !1, line: 7, baseType: !146, size: 8, align: 8, offset: 248, flags: DIFlagArtificial)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "__promise", scope: !138, file: !1, line: 7, baseType: !154, size: 32, align: 32, offset: 128, flags: DIFlagArtificial)
!154 = !DIDerivedType(tag: DW_TAG_typedef, name: "promise_type", scope: !155, file: !7, line: 91, baseType: !27)
!155 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__coroutine_traits_impl<Gen, void>", scope: !8, file: !7, line: 85, size: 8, flags: DIFlagTypePassByValue, elements: !156, templateParams: !157, identifier: "_ZTSNSt7__n486123__coroutine_traits_implI3GenvEE")
!156 = !{}
!157 = !{!158, !159}
!158 = !DITemplateTypeParameter(name: "_Result", type: !3)
!159 = !DITemplateTypeParameter(type: null, defaulted: true)
!160 = !DILocalVariable(name: "n", arg: 1, scope: !133, file: !1, line: 7, type: !30)
!161 = !DILocation(line: 7, column: 15, scope: !133)
!162 = !DILocation(line: 7, column: 17, scope: !133)
!163 = !DILocation(line: 7, column: 5, scope: !133)
!164 = !DILocalVariable(name: "i", scope: !165, file: !1, line: 7, type: !30)
!165 = distinct !DILexicalBlock(scope: !166, file: !1, line: 7, column: 19)
!166 = distinct !DILexicalBlock(scope: !133, file: !1, line: 7, column: 17)
!167 = !DILocalVariable(name: "__promise", scope: !133, type: !154, flags: DIFlagArtificial)
!168 = !DILocation(line: 7, column: 40, scope: !133)
!169 = !DILocation(line: 7, column: 52, scope: !133)
!170 = !DILocation(line: 7, column: 27, scope: !165)
!171 = !DILocation(line: 7, column: 23, scope: !165)
!172 = !DILocation(line: 7, column: 31, scope: !173)
!173 = distinct !DILexicalBlock(scope: !165, file: !1, line: 7, column: 19)
!174 = !DILocation(line: 7, column: 33, scope: !173)
!175 = !DILocation(line: 7, column: 32, scope: !173)
!176 = !DILocation(line: 7, column: 19, scope: !165)
!177 = !DILocation(line: 7, column: 49, scope: !173)
!178 = !DILocation(line: 7, column: 40, scope: !173)
!179 = !DILocation(line: 7, column: 36, scope: !173)
!180 = !DILocation(line: 7, column: 19, scope: !173)
!181 = distinct !{!181, !176, !182, !183}
!182 = !DILocation(line: 7, column: 49, scope: !165)
!183 = !{!"llvm.loop.mustprogress"}
!184 = distinct !DISubprogram(name: "get_return_object", linkageName: "_ZN3Gen12promise_type17get_return_objectEv", scope: !27, file: !1, line: 3, type: !32, scopeLine: 3, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !31, retainedNodes: !156)
!185 = !DILocalVariable(name: "this", arg: 1, scope: !184, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!186 = !DILocation(line: 0, scope: !184)
!187 = !DILocation(line: 3, column: 38, scope: !184)
!188 = !DILocation(line: 3, column: 39, scope: !184)
!189 = !DILocation(line: 3, column: 28, scope: !184)
!190 = distinct !DISubprogram(name: "initial_suspend", linkageName: "_ZN3Gen12promise_type15initial_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !35, retainedNodes: !156)
!191 = !DILocalVariable(name: "this", arg: 1, scope: !190, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!192 = !DILocation(line: 0, scope: !190)
!193 = !DILocation(line: 4, column: 41, scope: !190)
!194 = distinct !DISubprogram(name: "await_ready", linkageName: "_ZNKSt7__n486114suspend_always11await_readyEv", scope: !38, file: !7, line: 331, type: !41, scopeLine: 331, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !40, retainedNodes: !156)
!195 = !DILocalVariable(name: "this", arg: 1, scope: !194, type: !196, flags: DIFlagArtificial | DIFlagObjectPointer)
!196 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!197 = !DILocation(line: 0, scope: !194)
!198 = !DILocation(line: 331, column: 51, scope: !194)
!199 = distinct !DISubprogram(linkageName: "_Z5counti.__await_suspend_wrapper__init", scope: !1, file: !1, type: !200, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0, retainedNodes: !156)
!200 = !DISubroutineType(types: !156)
!201 = !DILocalVariable(arg: 1, scope: !199, type: !12, flags: DIFlagArtificial)
!202 = !DILocation(line: 0, scope: !199)
!203 = !DILocalVariable(arg: 2, scope: !199, type: !12, flags: DIFlagArtificial)
!204 = !DILocation(line: 7, column: 5, scope: !199)
!205 = distinct !DISubprogram(name: "await_suspend", linkageName: "_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE", scope: !38, file: !7, line: 333, type: !47, scopeLine: 333, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !46, retainedNodes: !156)
!206 = !DILocalVariable(name: "this", arg: 1, scope: !205, type: !196, flags: DIFlagArtificial | DIFlagObjectPointer)
!207 = !DILocation(line: 0, scope: !205)
!208 = !DILocalVariable(arg: 2, scope: !205, file: !7, line: 333, type: !49)
!209 = !DILocation(line: 333, column: 52, scope: !205)
!210 = !DILocation(line: 333, column: 70, scope: !205)
!211 = distinct !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv", scope: !6, file: !7, line: 225, type: !103, scopeLine: 226, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !102, retainedNodes: !156)
!212 = !DILocalVariable(name: "__a", arg: 1, scope: !211, file: !7, line: 225, type: !12)
!213 = !DILocation(line: 225, column: 60, scope: !211)
!214 = !DILocalVariable(name: "__self", scope: !211, file: !7, line: 227, type: !6)
!215 = !DILocation(line: 227, column: 19, scope: !211)
!216 = !DILocation(line: 228, column: 21, scope: !211)
!217 = !DILocation(line: 228, column: 9, scope: !211)
!218 = !DILocation(line: 228, column: 19, scope: !211)
!219 = !DILocation(line: 229, column: 2, scope: !211)
!220 = distinct !DISubprogram(name: "operator coroutine_handle", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv", scope: !6, file: !7, line: 233, type: !106, scopeLine: 234, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !105, retainedNodes: !156)
!221 = !DILocalVariable(name: "this", arg: 1, scope: !220, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!222 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64)
!223 = !DILocation(line: 0, scope: !220)
!224 = !DILocation(line: 234, column: 49, scope: !220)
!225 = !DILocation(line: 234, column: 16, scope: !220)
!226 = !DILocation(line: 234, column: 9, scope: !220)
!227 = distinct !DISubprogram(name: "await_resume", linkageName: "_ZNKSt7__n486114suspend_always12await_resumeEv", scope: !38, file: !7, line: 335, type: !83, scopeLine: 335, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !82, retainedNodes: !156)
!228 = !DILocalVariable(name: "this", arg: 1, scope: !227, type: !196, flags: DIFlagArtificial | DIFlagObjectPointer)
!229 = !DILocation(line: 0, scope: !227)
!230 = !DILocation(line: 335, column: 51, scope: !227)
!231 = distinct !DISubprogram(name: "yield_value", linkageName: "_ZN3Gen12promise_type11yield_valueEi", scope: !27, file: !1, line: 5, type: !87, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !86, retainedNodes: !156)
!232 = !DILocalVariable(name: "this", arg: 1, scope: !231, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!233 = !DILocation(line: 0, scope: !231)
!234 = !DILocalVariable(name: "x", arg: 2, scope: !231, file: !1, line: 5, type: !30)
!235 = !DILocation(line: 5, column: 39, scope: !231)
!236 = !DILocation(line: 5, column: 45, scope: !231)
!237 = !DILocation(line: 5, column: 43, scope: !231)
!238 = !DILocation(line: 5, column: 44, scope: !231)
!239 = !DILocation(line: 5, column: 48, scope: !231)
!240 = distinct !DISubprogram(linkageName: "_Z5counti.__await_suspend_wrapper__yield", scope: !1, file: !1, type: !200, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0, retainedNodes: !156)
!241 = !DILocalVariable(arg: 1, scope: !240, type: !12, flags: DIFlagArtificial)
!242 = !DILocation(line: 0, scope: !240)
!243 = !DILocalVariable(arg: 2, scope: !240, type: !12, flags: DIFlagArtificial)
!244 = !DILocation(line: 7, column: 40, scope: !240)
!245 = distinct !DISubprogram(name: "return_void", linkageName: "_ZN3Gen12promise_type11return_voidEv", scope: !27, file: !1, line: 5, type: !90, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !89, retainedNodes: !156)
!246 = !DILocalVariable(name: "this", arg: 1, scope: !245, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!247 = !DILocation(line: 0, scope: !245)
!248 = !DILocation(line: 5, column: 80, scope: !245)
!249 = distinct !DISubprogram(name: "final_suspend", linkageName: "_ZN3Gen12promise_type13final_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !85, retainedNodes: !156)
!250 = !DILocalVariable(name: "this", arg: 1, scope: !249, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!251 = !DILocation(line: 0, scope: !249)
!252 = !DILocation(line: 4, column: 98, scope: !249)
!253 = distinct !DISubprogram(linkageName: "_Z5counti.__await_suspend_wrapper__final", scope: !1, file: !1, type: !200, flags: DIFlagArtificial, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0, retainedNodes: !156)
!254 = !DILocalVariable(arg: 1, scope: !253, type: !12, flags: DIFlagArtificial)
!255 = !DILocation(line: 0, scope: !253)
!256 = !DILocalVariable(arg: 2, scope: !253, type: !12, flags: DIFlagArtificial)
!257 = !DILocation(line: 7, column: 5, scope: !253)
!258 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 8, type: !259, scopeLine: 8, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !156)
!259 = !DISubroutineType(types: !260)
!260 = !{!30}
!261 = !DILocalVariable(name: "g", scope: !258, file: !1, line: 8, type: !3)
!262 = !DILocation(line: 8, column: 17, scope: !258)
!263 = !DILocation(line: 8, column: 19, scope: !258)
!264 = !DILocalVariable(name: "s", scope: !258, file: !1, line: 8, type: !30)
!265 = !DILocation(line: 8, column: 33, scope: !258)
!266 = !DILocation(line: 8, column: 38, scope: !258)
!267 = !DILocation(line: 8, column: 47, scope: !258)
!268 = !DILocation(line: 8, column: 49, scope: !258)
!269 = !DILocation(line: 8, column: 44, scope: !258)
!270 = !DILocation(line: 8, column: 60, scope: !271)
!271 = distinct !DILexicalBlock(scope: !258, file: !1, line: 8, column: 56)
!272 = !DILocation(line: 8, column: 62, scope: !271)
!273 = !DILocation(line: 8, column: 78, scope: !274)
!274 = distinct !DILexicalBlock(scope: !271, file: !1, line: 8, column: 75)
!275 = !DILocation(line: 8, column: 80, scope: !274)
!276 = !DILocation(line: 8, column: 75, scope: !274)
!277 = !DILocation(line: 8, column: 93, scope: !274)
!278 = !DILocation(line: 8, column: 95, scope: !274)
!279 = !DILocation(line: 8, column: 105, scope: !274)
!280 = !DILocation(line: 8, column: 89, scope: !274)
!281 = !DILocation(line: 8, column: 88, scope: !274)
!282 = distinct !{!282, !266, !283, !183}
!283 = !DILocation(line: 8, column: 108, scope: !258)
!284 = !DILocation(line: 8, column: 112, scope: !258)
!285 = !DILocation(line: 8, column: 114, scope: !258)
!286 = !DILocation(line: 8, column: 132, scope: !258)
!287 = !DILocation(line: 8, column: 125, scope: !258)
!288 = distinct !DISubprogram(name: "done", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv", scope: !6, file: !7, line: 242, type: !109, scopeLine: 242, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !111, retainedNodes: !156)
!289 = !DILocalVariable(name: "this", arg: 1, scope: !288, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!290 = !DILocation(line: 0, scope: !288)
!291 = !DILocation(line: 242, column: 63, scope: !288)
!292 = !DILocation(line: 242, column: 43, scope: !288)
!293 = !DILocation(line: 242, column: 36, scope: !288)
!294 = distinct !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv", scope: !6, file: !7, line: 247, type: !113, scopeLine: 247, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !115, retainedNodes: !156)
!295 = !DILocalVariable(name: "this", arg: 1, scope: !294, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!296 = !DILocation(line: 0, scope: !294)
!297 = !DILocation(line: 247, column: 51, scope: !294)
!298 = !DILocation(line: 247, column: 29, scope: !294)
!299 = !DILocation(line: 247, column: 63, scope: !294)
!300 = distinct !DISubprogram(name: "promise", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv", scope: !6, file: !7, line: 252, type: !118, scopeLine: 253, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !117, retainedNodes: !156)
!301 = !DILocalVariable(name: "this", arg: 1, scope: !300, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!302 = !DILocation(line: 0, scope: !300)
!303 = !DILocalVariable(name: "__t", scope: !300, file: !7, line: 254, type: !12)
!304 = !DILocation(line: 254, column: 8, scope: !300)
!305 = !DILocation(line: 255, column: 30, scope: !300)
!306 = !DILocation(line: 255, column: 6, scope: !300)
!307 = !DILocation(line: 256, column: 33, scope: !300)
!308 = !DILocation(line: 256, column: 2, scope: !300)
!309 = distinct !DISubprogram(name: "destroy", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv", scope: !6, file: !7, line: 249, type: !113, scopeLine: 249, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !116, retainedNodes: !156)
!310 = !DILocalVariable(name: "this", arg: 1, scope: !309, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!311 = !DILocation(line: 0, scope: !309)
!312 = !DILocation(line: 249, column: 53, scope: !309)
!313 = !DILocation(line: 249, column: 30, scope: !309)
!314 = !DILocation(line: 249, column: 65, scope: !309)
!315 = distinct !DISubprogram(name: "from_promise", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_", scope: !6, file: !7, line: 207, type: !24, scopeLine: 208, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !23, retainedNodes: !156)
!316 = !DILocalVariable(name: "__p", arg: 1, scope: !315, file: !7, line: 207, type: !26)
!317 = !DILocation(line: 207, column: 30, scope: !315)
!318 = !DILocalVariable(name: "__self", scope: !315, file: !7, line: 209, type: !6)
!319 = !DILocation(line: 209, column: 19, scope: !315)
!320 = !DILocation(line: 211, column: 38, scope: !315)
!321 = !{i64 4}
!322 = !DILocation(line: 211, column: 6, scope: !315)
!323 = !DILocation(line: 210, column: 9, scope: !315)
!324 = !DILocation(line: 211, column: 4, scope: !315)
!325 = !DILocation(line: 212, column: 2, scope: !315)
!326 = distinct !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC2Ev", scope: !6, file: !7, line: 202, type: !14, scopeLine: 202, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !13, retainedNodes: !156)
!327 = !DILocalVariable(name: "this", arg: 1, scope: !326, type: !328, flags: DIFlagArtificial | DIFlagObjectPointer)
!328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!329 = !DILocation(line: 0, scope: !326)
!330 = !DILocation(line: 260, column: 13, scope: !326)
!331 = !DILocation(line: 202, column: 47, scope: !326)
!332 = distinct !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIvE12from_addressEPv", scope: !49, file: !7, line: 123, type: !69, scopeLine: 124, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !68, retainedNodes: !156)
!333 = !DILocalVariable(name: "__a", arg: 1, scope: !332, file: !7, line: 123, type: !12)
!334 = !DILocation(line: 123, column: 60, scope: !332)
!335 = !DILocalVariable(name: "__self", scope: !332, file: !7, line: 125, type: !49)
!336 = !DILocation(line: 125, column: 19, scope: !332)
!337 = !DILocation(line: 126, column: 21, scope: !332)
!338 = !DILocation(line: 126, column: 9, scope: !332)
!339 = !DILocation(line: 126, column: 19, scope: !332)
!340 = !DILocation(line: 127, column: 2, scope: !332)
!341 = distinct !DISubprogram(name: "address", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv", scope: !6, file: !7, line: 223, type: !98, scopeLine: 223, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !97, retainedNodes: !156)
!342 = !DILocalVariable(name: "this", arg: 1, scope: !341, type: !222, flags: DIFlagArtificial | DIFlagObjectPointer)
!343 = !DILocation(line: 0, scope: !341)
!344 = !DILocation(line: 223, column: 57, scope: !341)
!345 = !DILocation(line: 223, column: 50, scope: !341)
!346 = distinct !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIvEC2Ev", scope: !49, file: !7, line: 107, type: !53, scopeLine: 107, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, declaration: !52, retainedNodes: !156)
!347 = !DILocalVariable(name: "this", arg: 1, scope: !346, type: !348, flags: DIFlagArtificial | DIFlagObjectPointer)
!348 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!349 = !DILocation(line: 0, scope: !346)
!350 = !DILocation(line: 107, column: 47, scope: !346)
!351 = !DILocation(line: 107, column: 67, scope: !346)
!352 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti.resume", scope: !1, file: !1, line: 7, type: !134, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !353)
!353 = !{!354}
!354 = !DILocalVariable(name: "__coro_frame", scope: !352, file: !1, line: 7, type: !138, flags: DIFlagArtificial)
!355 = !DILocalVariable(name: "i", scope: !356, file: !1, line: 7, type: !30)
!356 = distinct !DILexicalBlock(scope: !357, file: !1, line: 7, column: 19)
!357 = distinct !DILexicalBlock(scope: !352, file: !1, line: 7, column: 17)
!358 = !DILocation(line: 7, column: 27, scope: !356)
!359 = !DILocalVariable(name: "__promise", scope: !352, type: !154, flags: DIFlagArtificial)
!360 = !DILocation(line: 0, scope: !352)
!361 = !DILocalVariable(name: "n", arg: 1, scope: !352, file: !1, line: 7, type: !30)
!362 = !DILocation(line: 7, column: 1, scope: !352)
!363 = !DILocation(line: 7, column: 40, scope: !352)
!364 = !DILabel(scope: !352, name: "__coro_resume_0", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 0)
!365 = !DILocation(line: 7, column: 5, scope: !352)
!366 = !DILocation(line: 7, column: 23, scope: !356)
!367 = !DILocation(line: 7, column: 31, scope: !368)
!368 = distinct !DILexicalBlock(scope: !356, file: !1, line: 7, column: 19)
!369 = !DILocation(line: 7, column: 33, scope: !368)
!370 = !DILocation(line: 7, column: 32, scope: !368)
!371 = !DILocation(line: 7, column: 19, scope: !356)
!372 = !DILocation(line: 7, column: 49, scope: !368)
!373 = !DILocation(line: 7, column: 40, scope: !368)
!374 = !DILabel(scope: !352, name: "__coro_resume_1", file: !1, line: 7, column: 40, isArtificial: true, coroSuspendIdx: 1)
!375 = !DILocation(line: 7, column: 36, scope: !368)
!376 = !DILocation(line: 7, column: 19, scope: !368)
!377 = distinct !{!377, !371, !378, !183}
!378 = !DILocation(line: 7, column: 49, scope: !356)
!379 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti.destroy", scope: !1, file: !1, line: 7, type: !134, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !380)
!380 = !{!381}
!381 = !DILocalVariable(name: "__coro_frame", scope: !379, file: !1, line: 7, type: !138, flags: DIFlagArtificial)
!382 = !DILocalVariable(name: "i", scope: !383, file: !1, line: 7, type: !30)
!383 = distinct !DILexicalBlock(scope: !384, file: !1, line: 7, column: 19)
!384 = distinct !DILexicalBlock(scope: !379, file: !1, line: 7, column: 17)
!385 = !DILocation(line: 7, column: 27, scope: !383)
!386 = !DILocalVariable(name: "__promise", scope: !379, type: !154, flags: DIFlagArtificial)
!387 = !DILocation(line: 0, scope: !379)
!388 = !DILocalVariable(name: "n", arg: 1, scope: !379, file: !1, line: 7, type: !30)
!389 = !DILocation(line: 7, column: 1, scope: !379)
!390 = !DILocation(line: 7, column: 40, scope: !379)
!391 = !DILabel(scope: !379, name: "__coro_resume_0", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 0)
!392 = !DILocation(line: 7, column: 5, scope: !379)
!393 = !DILocation(line: 7, column: 23, scope: !383)
!394 = !DILocation(line: 7, column: 31, scope: !395)
!395 = distinct !DILexicalBlock(scope: !383, file: !1, line: 7, column: 19)
!396 = !DILocation(line: 7, column: 33, scope: !395)
!397 = !DILocation(line: 7, column: 32, scope: !395)
!398 = !DILocation(line: 7, column: 19, scope: !383)
!399 = !DILocation(line: 7, column: 49, scope: !395)
!400 = !DILocation(line: 7, column: 40, scope: !395)
!401 = !DILabel(scope: !379, name: "__coro_resume_1", file: !1, line: 7, column: 40, isArtificial: true, coroSuspendIdx: 1)
!402 = !DILocation(line: 7, column: 36, scope: !395)
!403 = !DILocation(line: 7, column: 19, scope: !395)
!404 = distinct !{!404, !398, !405, !183}
!405 = !DILocation(line: 7, column: 49, scope: !383)
!406 = !DILabel(scope: !379, name: "__coro_resume_2", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 2)
!407 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti.cleanup", scope: !1, file: !1, line: 7, type: !134, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !408)
!408 = !{!409}
!409 = !DILocalVariable(name: "__coro_frame", scope: !407, file: !1, line: 7, type: !138, flags: DIFlagArtificial)
!410 = !DILocalVariable(name: "i", scope: !411, file: !1, line: 7, type: !30)
!411 = distinct !DILexicalBlock(scope: !412, file: !1, line: 7, column: 19)
!412 = distinct !DILexicalBlock(scope: !407, file: !1, line: 7, column: 17)
!413 = !DILocation(line: 7, column: 27, scope: !411)
!414 = !DILocalVariable(name: "__promise", scope: !407, type: !154, flags: DIFlagArtificial)
!415 = !DILocation(line: 0, scope: !407)
!416 = !DILocalVariable(name: "n", arg: 1, scope: !407, file: !1, line: 7, type: !30)
!417 = !DILocation(line: 7, column: 1, scope: !407)
!418 = !DILocation(line: 7, column: 40, scope: !407)
!419 = !DILabel(scope: !407, name: "__coro_resume_0", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 0)
!420 = !DILocation(line: 7, column: 5, scope: !407)
!421 = !DILocation(line: 7, column: 23, scope: !411)
!422 = !DILocation(line: 7, column: 31, scope: !423)
!423 = distinct !DILexicalBlock(scope: !411, file: !1, line: 7, column: 19)
!424 = !DILocation(line: 7, column: 33, scope: !423)
!425 = !DILocation(line: 7, column: 32, scope: !423)
!426 = !DILocation(line: 7, column: 19, scope: !411)
!427 = !DILocation(line: 7, column: 49, scope: !423)
!428 = !DILocation(line: 7, column: 40, scope: !423)
!429 = !DILabel(scope: !407, name: "__coro_resume_1", file: !1, line: 7, column: 40, isArtificial: true, coroSuspendIdx: 1)
!430 = !DILocation(line: 7, column: 36, scope: !423)
!431 = !DILocation(line: 7, column: 19, scope: !423)
!432 = distinct !{!432, !426, !433, !183}
!433 = !DILocation(line: 7, column: 49, scope: !411)
!434 = !DILabel(scope: !407, name: "__coro_resume_2", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 2)
