; ModuleID = '20001228-1.c'
source_filename = "20001228-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { i32 }
%union.anon.0 = type { i32 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo1() #0 !dbg !10 {
  %1 = alloca %union.anon, align 4
    #dbg_declare(ptr %1, !24, !DIExpression(), !25)
  store i32 1, ptr %1, align 4, !dbg !26
  %2 = getelementptr inbounds [4 x i8], ptr %1, i64 0, i64 0, !dbg !27
  %3 = load i8, ptr %2, align 4, !dbg !27
  %4 = sext i8 %3 to i32, !dbg !27
  ret i32 %4, !dbg !28
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo2() #0 !dbg !29 {
  %1 = alloca %union.anon.0, align 4
    #dbg_declare(ptr %1, !35, !DIExpression(), !37)
  store volatile i32 1, ptr %1, align 4, !dbg !38
  %2 = getelementptr inbounds [4 x i8], ptr %1, i64 0, i64 0, !dbg !39
  %3 = load volatile i8, ptr %2, align 4, !dbg !39
  %4 = sext i8 %3 to i32, !dbg !39
  ret i32 %4, !dbg !40
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !41 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @foo1(), !dbg !42
  %3 = call i32 @foo2(), !dbg !44
  %4 = icmp ne i32 %2, %3, !dbg !45
  br i1 %4, label %5, label %6, !dbg !45

5:                                                ; preds = %0
  call void @abort() #3, !dbg !46
  unreachable, !dbg !46

6:                                                ; preds = %0
  call void @exit(i32 noundef 0) #4, !dbg !47
  unreachable, !dbg !47
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20001228-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "12ac9f0cc94c44dd65dd57e14e7ed2bb")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "foo1", scope: !1, file: !1, line: 4, type: !11, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !14)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!14 = !{!15}
!15 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !10, file: !1, line: 6, size: 32, elements: !16)
!16 = !{!17, !22}
!17 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !15, file: !1, line: 7, baseType: !18, size: 32)
!18 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 32, elements: !20)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!20 = !{!21}
!21 = !DISubrange(count: 4)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !15, file: !1, line: 8, baseType: !23, size: 32)
!23 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!24 = !DILocalVariable(name: "u", scope: !10, file: !1, line: 9, type: !15)
!25 = !DILocation(line: 9, column: 5, scope: !10)
!26 = !DILocation(line: 11, column: 7, scope: !10)
!27 = !DILocation(line: 12, column: 10, scope: !10)
!28 = !DILocation(line: 12, column: 3, scope: !10)
!29 = distinct !DISubprogram(name: "foo2", scope: !1, file: !1, line: 15, type: !11, scopeLine: 16, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !30)
!30 = !{!31}
!31 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !29, file: !1, line: 17, size: 32, elements: !32)
!32 = !{!33, !34}
!33 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !31, file: !1, line: 18, baseType: !18, size: 32)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !31, file: !1, line: 19, baseType: !23, size: 32)
!35 = !DILocalVariable(name: "u", scope: !29, file: !1, line: 20, type: !36)
!36 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !31)
!37 = !DILocation(line: 20, column: 5, scope: !29)
!38 = !DILocation(line: 22, column: 7, scope: !29)
!39 = !DILocation(line: 23, column: 10, scope: !29)
!40 = !DILocation(line: 23, column: 3, scope: !29)
!41 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 26, type: !11, scopeLine: 27, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!42 = !DILocation(line: 28, column: 7, scope: !43)
!43 = distinct !DILexicalBlock(scope: !41, file: !1, line: 28, column: 7)
!44 = !DILocation(line: 28, column: 17, scope: !43)
!45 = !DILocation(line: 28, column: 14, scope: !43)
!46 = !DILocation(line: 29, column: 5, scope: !43)
!47 = !DILocation(line: 30, column: 3, scope: !41)
