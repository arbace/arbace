; ModuleID = 'alias-access-path-2.c'
source_filename = "alias-access-path-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef i32 @main(i32 noundef %0, ptr nofree noundef readnone captures(none) %1) local_unnamed_addr #0 !dbg !10 {
    #dbg_assign(i1 poison, !21, !DIExpression(), !29, ptr poison, !DIExpression(), !30)
    #dbg_value(i32 %0, !18, !DIExpression(), !30)
    #dbg_value(ptr %1, !19, !DIExpression(), !30)
    #dbg_assign(i1 poison, !21, !DIExpression(), !31, ptr poison, !DIExpression(), !30)
  ret i32 0, !dbg !32
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "alias-access-path-2.c", directory: ".", checksumkind: CSK_MD5, checksum: "3e965258a91e683ffbdb95fd5b92432e")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 2, type: !11, scopeLine: 3, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !17, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{!13, !13, !14}
!13 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64)
!16 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!17 = !{!18, !19, !20, !21, !27}
!18 = !DILocalVariable(name: "argc", arg: 1, scope: !10, file: !1, line: 2, type: !13)
!19 = !DILocalVariable(name: "argv", arg: 2, scope: !10, file: !1, line: 2, type: !14)
!20 = !DILocalVariable(name: "c", scope: !10, file: !1, line: 4, type: !13)
!21 = !DILocalVariable(name: "out", scope: !10, file: !1, line: 5, type: !22)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 24, elements: !24)
!23 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!24 = !{!25, !26}
!25 = !DISubrange(count: 3)
!26 = !DISubrange(count: 1)
!27 = !DILocalVariable(name: "i", scope: !28, file: !1, line: 7, type: !13)
!28 = distinct !DILexicalBlock(scope: !10, file: !1, line: 7, column: 3)
!29 = distinct !DIAssignID()
!30 = !DILocation(line: 0, scope: !10)
!31 = distinct !DIAssignID()
!32 = !DILocation(line: 10, column: 3, scope: !10, atomGroup: 9, atomRank: 1)
