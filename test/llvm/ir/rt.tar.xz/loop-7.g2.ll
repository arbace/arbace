; ModuleID = 'loop-7.c'
source_filename = "loop-7.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: nofree nounwind sspstrong uwtable
define dso_local void @foo(i32 noundef %0) local_unnamed_addr #0 !dbg !10 {
    #dbg_value(i32 %0, !15, !DIExpression(), !19)
    #dbg_value(i32 -1, !18, !DIExpression(), !19)
    #dbg_value(i32 0, !16, !DIExpression(), !19)
  %2 = zext i32 %0 to i64
  br label %3, !dbg !20

3:                                                ; preds = %1, %3
  %4 = phi i64 [ 0, %1 ], [ %10, %3 ]
  %5 = phi i32 [ -1, %1 ], [ %9, %3 ]
    #dbg_value(i32 %5, !18, !DIExpression(), !19)
    #dbg_value(i64 %4, !16, !DIExpression(), !19)
  %6 = shl nuw nsw i64 1, %4, !dbg !22
  %7 = icmp eq i64 %6, %2, !dbg !26
  %8 = trunc nuw nsw i64 %4 to i32, !dbg !27
  %9 = select i1 %7, i32 %8, i32 %5, !dbg !27
    #dbg_value(i32 %9, !18, !DIExpression(), !19)
  %10 = add nuw nsw i64 %4, 1, !dbg !28
    #dbg_value(i64 %10, !16, !DIExpression(), !19)
  %11 = icmp samesign ult i64 %4, 9, !dbg !29
  %12 = icmp slt i32 %9, 0, !dbg !30
  %13 = select i1 %11, i1 %12, i1 false, !dbg !30
  br i1 %13, label %3, label %14, !dbg !31, !llvm.loop !32

14:                                               ; preds = %3
  br i1 %12, label %15, label %16, !dbg !36

15:                                               ; preds = %14
  tail call void @abort() #4, !dbg !38
  unreachable, !dbg !38

16:                                               ; preds = %14
  ret void, !dbg !39
}

; Function Attrs: cold nofree noreturn nounwind
declare void @abort() local_unnamed_addr #1

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #2 !dbg !40 {
  tail call void @foo(i32 noundef 64), !dbg !43
  tail call void @exit(i32 noundef 0) #4, !dbg !44
  unreachable, !dbg !44
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #3

attributes #0 = { nofree nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "loop-7.c", directory: ".", checksumkind: CSK_MD5, checksum: "52ef3ec1a2bf71515971531c1ce85d1b")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "foo", scope: !1, file: !1, line: 4, type: !11, scopeLine: 5, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !14, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{null, !13}
!13 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!14 = !{!15, !16, !18}
!15 = !DILocalVariable(name: "n", arg: 1, scope: !10, file: !1, line: 4, type: !13)
!16 = !DILocalVariable(name: "i", scope: !10, file: !1, line: 6, type: !17)
!17 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!18 = !DILocalVariable(name: "j", scope: !10, file: !1, line: 6, type: !17)
!19 = !DILocation(line: 0, scope: !10)
!20 = !DILocation(line: 8, column: 3, scope: !21, atomGroup: 12, atomRank: 1)
!21 = distinct !DILexicalBlock(scope: !10, file: !1, line: 8, column: 3)
!22 = !DILocation(line: 10, column: 16, scope: !23)
!23 = distinct !DILexicalBlock(scope: !24, file: !1, line: 10, column: 11)
!24 = distinct !DILexicalBlock(scope: !25, file: !1, line: 9, column: 5)
!25 = distinct !DILexicalBlock(scope: !21, file: !1, line: 8, column: 3)
!26 = !DILocation(line: 10, column: 22, scope: !23, atomGroup: 5, atomRank: 2)
!27 = !DILocation(line: 10, column: 22, scope: !23, atomGroup: 5, atomRank: 1)
!28 = !DILocation(line: 8, column: 33, scope: !25, atomGroup: 7, atomRank: 2)
!29 = !DILocation(line: 8, column: 17, scope: !25, atomGroup: 3, atomRank: 2)
!30 = !DILocation(line: 8, column: 22, scope: !25, atomGroup: 3, atomRank: 1)
!31 = !DILocation(line: 8, column: 3, scope: !21, atomGroup: 4, atomRank: 1)
!32 = distinct !{!32, !33, !34, !35}
!33 = !DILocation(line: 8, column: 3, scope: !21)
!34 = !DILocation(line: 12, column: 5, scope: !21)
!35 = !{!"llvm.loop.mustprogress"}
!36 = !DILocation(line: 14, column: 9, scope: !37, atomGroup: 9, atomRank: 1)
!37 = distinct !DILexicalBlock(scope: !10, file: !1, line: 14, column: 7)
!38 = !DILocation(line: 15, column: 5, scope: !37)
!39 = !DILocation(line: 16, column: 1, scope: !10, atomGroup: 10, atomRank: 1)
!40 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 19, type: !41, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!41 = !DISubroutineType(types: !42)
!42 = !{!17}
!43 = !DILocation(line: 21, column: 3, scope: !40)
!44 = !DILocation(line: 22, column: 3, scope: !40)
