; ModuleID = '920501-2.c'
source_filename = "920501-2.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"

@factab = dso_local local_unnamed_addr global [10 x i32] zeroinitializer, align 8

; Function Attrs: nofree norecurse nosync nounwind memory(none) uwtable
define dso_local i32 @gcd_ll(i64 noundef %0, i64 noundef %1) local_unnamed_addr #0 {
  %3 = icmp eq i64 %1, 0
  br i1 %3, label %12, label %4

4:                                                ; preds = %2, %9
  %5 = phi i64 [ %7, %9 ], [ %0, %2 ]
  %6 = phi i64 [ %10, %9 ], [ %1, %2 ]
  %7 = urem i64 %5, %6
  %8 = icmp eq i64 %7, 0
  br i1 %8, label %12, label %9

9:                                                ; preds = %4
  %10 = urem i64 %6, %7
  %11 = icmp eq i64 %10, 0
  br i1 %11, label %12, label %4

12:                                               ; preds = %9, %4, %2
  %13 = phi i64 [ %0, %2 ], [ %6, %4 ], [ %7, %9 ]
  %14 = trunc i64 %13 to i32
  ret i32 %14
}

; Function Attrs: nofree norecurse nosync nounwind memory(none) uwtable
define dso_local i64 @powmod_ll(i64 noundef %0, i32 noundef %1, i64 noundef %2) local_unnamed_addr #0 {
  %4 = icmp eq i32 %1, 0
  br i1 %4, label %26, label %5

5:                                                ; preds = %3
  %6 = lshr i32 %1, 1
  %7 = icmp eq i32 %6, 0
  br i1 %7, label %26, label %8

8:                                                ; preds = %5
  %9 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %6, i1 true)
  %10 = xor i32 %9, 31
  br label %11

11:                                               ; preds = %8, %22
  %12 = phi i32 [ %24, %22 ], [ %10, %8 ]
  %13 = phi i64 [ %23, %22 ], [ %0, %8 ]
  %14 = mul i64 %13, %13
  %15 = urem i64 %14, %2
  %16 = shl nuw i32 1, %12
  %17 = and i32 %16, %1
  %18 = icmp eq i32 %17, 0
  br i1 %18, label %22, label %19

19:                                               ; preds = %11
  %20 = mul i64 %15, %0
  %21 = urem i64 %20, %2
  br label %22

22:                                               ; preds = %11, %19
  %23 = phi i64 [ %21, %19 ], [ %15, %11 ]
  %24 = add nsw i32 %12, -1
  %25 = icmp sgt i32 %12, 0
  br i1 %25, label %11, label %26, !llvm.loop !7

26:                                               ; preds = %22, %5, %3
  %27 = phi i64 [ 1, %3 ], [ %0, %5 ], [ %23, %22 ]
  ret i64 %27
}

; Function Attrs: nofree norecurse nosync nounwind memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local void @facts(i64 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) local_unnamed_addr #1 {
  %5 = sext i32 %1 to i64
  %6 = sext i32 %2 to i64
  %7 = icmp eq i32 %3, 0
  %8 = lshr i32 %3, 1
  %9 = icmp eq i32 %8, 0
  %10 = tail call range(i32 1, 33) i32 @llvm.ctlz.i32(i32 %8, i1 true)
  %11 = xor i32 %10, 31
  %12 = add nsw i64 %5, 1
  br label %13

13:                                               ; preds = %4, %110
  %14 = phi i32 [ 0, %4 ], [ %114, %110 ]
  %15 = phi i32 [ 1, %4 ], [ %113, %110 ]
  %16 = phi i64 [ %0, %4 ], [ %112, %110 ]
  %17 = phi i32 [ 1, %4 ], [ %115, %110 ]
  %18 = phi ptr [ @factab, %4 ], [ %111, %110 ]
  %19 = phi i64 [ 1, %4 ], [ %87, %110 ]
  %20 = phi i64 [ %6, %4 ], [ %79, %110 ]
  %21 = phi i64 [ %6, %4 ], [ %77, %110 ]
  br i1 %7, label %75, label %22

22:                                               ; preds = %13
  br i1 %9, label %55, label %23

23:                                               ; preds = %22, %34
  %24 = phi i32 [ %36, %34 ], [ %11, %22 ]
  %25 = phi i64 [ %35, %34 ], [ %21, %22 ]
  %26 = mul i64 %25, %25
  %27 = urem i64 %26, %16
  %28 = shl nuw i32 1, %24
  %29 = and i32 %28, %3
  %30 = icmp eq i32 %29, 0
  br i1 %30, label %34, label %31

31:                                               ; preds = %23
  %32 = mul i64 %27, %21
  %33 = urem i64 %32, %16
  br label %34

34:                                               ; preds = %31, %23
  %35 = phi i64 [ %33, %31 ], [ %27, %23 ]
  %36 = add nsw i32 %24, -1
  %37 = icmp sgt i32 %24, 0
  br i1 %37, label %23, label %38, !llvm.loop !7

38:                                               ; preds = %34
  %39 = add i64 %35, %5
  br label %40

40:                                               ; preds = %38, %51
  %41 = phi i32 [ %53, %51 ], [ %11, %38 ]
  %42 = phi i64 [ %52, %51 ], [ %20, %38 ]
  %43 = mul i64 %42, %42
  %44 = urem i64 %43, %16
  %45 = shl nuw i32 1, %41
  %46 = and i32 %45, %3
  %47 = icmp eq i32 %46, 0
  br i1 %47, label %51, label %48

48:                                               ; preds = %40
  %49 = mul i64 %44, %20
  %50 = urem i64 %49, %16
  br label %51

51:                                               ; preds = %48, %40
  %52 = phi i64 [ %50, %48 ], [ %44, %40 ]
  %53 = add nsw i32 %41, -1
  %54 = icmp sgt i32 %41, 0
  br i1 %54, label %40, label %58, !llvm.loop !7

55:                                               ; preds = %22
  %56 = add i64 %21, %5
  %57 = add i64 %20, %5
  br label %75

58:                                               ; preds = %51
  %59 = add i64 %52, %5
  br label %60

60:                                               ; preds = %58, %71
  %61 = phi i32 [ %73, %71 ], [ %11, %58 ]
  %62 = phi i64 [ %72, %71 ], [ %59, %58 ]
  %63 = mul i64 %62, %62
  %64 = urem i64 %63, %16
  %65 = shl nuw i32 1, %61
  %66 = and i32 %65, %3
  %67 = icmp eq i32 %66, 0
  br i1 %67, label %71, label %68

68:                                               ; preds = %60
  %69 = mul i64 %64, %59
  %70 = urem i64 %69, %16
  br label %71

71:                                               ; preds = %68, %60
  %72 = phi i64 [ %70, %68 ], [ %64, %60 ]
  %73 = add nsw i32 %61, -1
  %74 = icmp sgt i32 %61, 0
  br i1 %74, label %60, label %75, !llvm.loop !7

75:                                               ; preds = %71, %55, %13
  %76 = phi i64 [ 1, %13 ], [ %21, %55 ], [ %35, %71 ]
  %77 = phi i64 [ %12, %13 ], [ %56, %55 ], [ %39, %71 ]
  %78 = phi i64 [ 1, %13 ], [ %57, %55 ], [ %72, %71 ]
  %79 = add i64 %78, %5
  %80 = icmp ugt i64 %77, %79
  %81 = sub i64 %76, %78
  %82 = sub i64 %78, %76
  %83 = select i1 %80, i64 %81, i64 %82
  %84 = and i64 %19, 4294967295
  %85 = and i64 %83, 4294967295
  %86 = mul nuw i64 %85, %84
  %87 = urem i64 %86, %16
  %88 = icmp eq i32 %17, %15
  br i1 %88, label %89, label %110

89:                                               ; preds = %75
  %90 = add i32 %14, 1
  %91 = add i32 %90, %15
  %92 = and i64 %87, 4294967295
  br label %93

93:                                               ; preds = %89, %98
  %94 = phi i64 [ %96, %98 ], [ %92, %89 ]
  %95 = phi i64 [ %99, %98 ], [ %16, %89 ]
  %96 = urem i64 %94, %95
  %97 = icmp eq i64 %96, 0
  br i1 %97, label %101, label %98

98:                                               ; preds = %93
  %99 = urem i64 %95, %96
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %101, label %93

101:                                              ; preds = %93, %98
  %102 = phi i64 [ %96, %98 ], [ %95, %93 ]
  %103 = trunc i64 %102 to i32
  %104 = icmp eq i32 %103, 1
  br i1 %104, label %110, label %105

105:                                              ; preds = %101
  %106 = getelementptr inbounds nuw i8, ptr %18, i64 4
  store i32 %103, ptr %18, align 4
  %107 = and i64 %102, 4294967295
  %108 = udiv i64 %16, %107
  %109 = icmp eq i64 %108, 1
  br i1 %109, label %117, label %110

110:                                              ; preds = %75, %105, %101
  %111 = phi ptr [ %106, %105 ], [ %18, %101 ], [ %18, %75 ]
  %112 = phi i64 [ %108, %105 ], [ %16, %101 ], [ %16, %75 ]
  %113 = phi i32 [ %91, %105 ], [ %91, %101 ], [ %15, %75 ]
  %114 = phi i32 [ %90, %105 ], [ %90, %101 ], [ %14, %75 ]
  %115 = add nuw nsw i32 %17, 1
  %116 = icmp eq i32 %115, 10000
  br i1 %116, label %117, label %13, !llvm.loop !9

117:                                              ; preds = %110, %105
  ret void
}

; Function Attrs: nofree noreturn nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #2 {
  tail call void @facts(i64 noundef 134217727, i32 noundef -1, i32 noundef 3, i32 noundef 27)
  %1 = load i32, ptr @factab, align 8
  %2 = icmp ne i32 %1, 7
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 4), align 4
  %4 = icmp ne i32 %3, 73
  %5 = select i1 %2, i1 true, i1 %4
  %6 = load i32, ptr getelementptr inbounds nuw (i8, ptr @factab, i64 8), align 8
  %7 = icmp ne i32 %6, 262657
  %8 = select i1 %5, i1 true, i1 %7
  br i1 %8, label %9, label %10

9:                                                ; preds = %0
  tail call void @abort() #6
  unreachable

10:                                               ; preds = %0
  tail call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: cold nofree noreturn nounwind
declare dso_local void @abort() local_unnamed_addr #3

; Function Attrs: nofree noreturn
declare dso_local void @exit(i32 noundef) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #5

attributes #0 = { nofree norecurse nosync nounwind memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree norecurse nosync nounwind memory(write, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noreturn nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "920501-2.c", directory: ".")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"Alpine clang version 23.1.5"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
