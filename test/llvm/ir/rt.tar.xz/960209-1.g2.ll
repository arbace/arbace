; ModuleID = '960209-1.c'
source_filename = "960209-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.a_struct = type { i8 }

@yabba = dso_local local_unnamed_addr global i32 1, align 4, !dbg !0
@an_array = dso_local global [5 x %struct.a_struct] zeroinitializer, align 1, !dbg !8
@a_ptr = dso_local local_unnamed_addr global ptr null, align 8, !dbg !16

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable
define dso_local noundef i32 @f(i32 noundef %0, i64 noundef %1) local_unnamed_addr #0 !dbg !28 {
    #dbg_value(i32 %0, !32, !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !41)
    #dbg_value(i64 %1, !33, !DIExpression(), !41)
  %3 = load i32, ptr @yabba, align 4, !dbg !42
  %4 = icmp eq i32 %3, 0, !dbg !41
  br i1 %4, label %5, label %9, !dbg !41

5:                                                ; preds = %2
  %6 = and i32 %0, 255, !dbg !44
  %7 = zext nneg i32 %6 to i64, !dbg !44
  %8 = getelementptr inbounds nuw i8, ptr @an_array, i64 %7, !dbg !45
  store ptr %8, ptr @a_ptr, align 8, !dbg !46
  br label %9, !dbg !47

9:                                                ; preds = %2, %5
  %10 = icmp ne i64 %1, 0, !dbg !48
  %11 = sext i1 %10 to i32, !dbg !41
  ret i32 %11, !dbg !50
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #1 !dbg !51 {
    #dbg_value(i32 1, !32, !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !54)
    #dbg_value(i64 0, !33, !DIExpression(), !54)
  %1 = load i32, ptr @yabba, align 4, !dbg !57
  %2 = icmp eq i32 %1, 0, !dbg !54
  br i1 %2, label %3, label %4, !dbg !54

3:                                                ; preds = %0
  store ptr getelementptr inbounds nuw (i8, ptr @an_array, i64 1), ptr @a_ptr, align 8, !dbg !58
  br label %4, !dbg !59

4:                                                ; preds = %3, %0
  tail call void @exit(i32 noundef 0) #3, !dbg !60
  unreachable, !dbg !60
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #2

attributes #0 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(readwrite, argmem: none, inaccessiblemem: none, target_mem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "yabba", scope: !2, file: !3, line: 11, type: !19, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "960209-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "a92ca120986bf4ca8bfe2c4cd77d7b25")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !16}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "an_array", scope: !2, file: !3, line: 9, type: !10, isLocal: false, isDefinition: true)
!10 = !DICompositeType(tag: DW_TAG_array_type, baseType: !11, size: 40, elements: !14)
!11 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "a_struct", file: !3, line: 4, size: 8, elements: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "a_character", scope: !11, file: !3, line: 6, baseType: !6, size: 8)
!14 = !{!15}
!15 = !DISubrange(count: 5)
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "a_ptr", scope: !2, file: !3, line: 10, type: !18, isLocal: false, isDefinition: true)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!19 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 4, !"probe-stack", !"inline-asm"}
!23 = !{i32 8, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 2}
!26 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!27 = !{!"Alpine clang version 23.1.5"}
!28 = distinct !DISubprogram(name: "f", scope: !3, file: !3, line: 14, type: !29, scopeLine: 17, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !31, keyInstructions: true)
!29 = !DISubroutineType(types: !30)
!30 = !{!19, !6, !5}
!31 = !{!32, !33, !34, !36, !37, !38, !39, !40}
!32 = !DILocalVariable(name: "a", arg: 1, scope: !28, file: !3, line: 15, type: !6)
!33 = !DILocalVariable(name: "b", arg: 2, scope: !28, file: !3, line: 16, type: !5)
!34 = !DILocalVariable(name: "i", scope: !28, file: !3, line: 18, type: !35)
!35 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!36 = !DILocalVariable(name: "j", scope: !28, file: !3, line: 18, type: !35)
!37 = !DILocalVariable(name: "p", scope: !28, file: !3, line: 18, type: !35)
!38 = !DILocalVariable(name: "q", scope: !28, file: !3, line: 18, type: !35)
!39 = !DILocalVariable(name: "r", scope: !28, file: !3, line: 18, type: !35)
!40 = !DILocalVariable(name: "s", scope: !28, file: !3, line: 18, type: !35)
!41 = !DILocation(line: 0, scope: !28)
!42 = !DILocation(line: 35, column: 7, scope: !43)
!43 = distinct !DILexicalBlock(scope: !28, file: !3, line: 35, column: 7)
!44 = !DILocation(line: 37, column: 12, scope: !28)
!45 = !DILocation(line: 37, column: 12, scope: !28, atomGroup: 21, atomRank: 2)
!46 = !DILocation(line: 37, column: 9, scope: !28, atomGroup: 21, atomRank: 1)
!47 = !DILocation(line: 39, column: 1, scope: !28)
!48 = !DILocation(line: 20, column: 9, scope: !49, atomGroup: 1, atomRank: 2)
!49 = distinct !DILexicalBlock(scope: !28, file: !3, line: 20, column: 7)
!50 = !DILocation(line: 39, column: 1, scope: !28, atomGroup: 23, atomRank: 1)
!51 = distinct !DISubprogram(name: "main", scope: !3, file: !3, line: 42, type: !52, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!52 = !DISubroutineType(types: !53)
!53 = !{!19}
!54 = !DILocation(line: 0, scope: !28, inlinedAt: !55)
!55 = distinct !DILocation(line: 44, column: 7, scope: !56)
!56 = distinct !DILexicalBlock(scope: !51, file: !3, line: 44, column: 7)
!57 = !DILocation(line: 35, column: 7, scope: !43, inlinedAt: !55)
!58 = !DILocation(line: 37, column: 9, scope: !28, inlinedAt: !55, atomGroup: 21, atomRank: 1)
!59 = !DILocation(line: 39, column: 1, scope: !28, inlinedAt: !55)
!60 = !DILocation(line: 46, column: 3, scope: !51)
