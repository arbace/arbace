; ModuleID = 'test/cpp/samples/decls.cpp'
source_filename = "test/cpp/samples/decls.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S2 = type { i32, i32 }

@_ZN1A1sE = dso_local local_unnamed_addr global i32 0, align 4, !dbg !0
@_ZN1a1b1c1zE = dso_local local_unnamed_addr global i32 0, align 4, !dbg !5
@fp = dso_local local_unnamed_addr global ptr null, align 8, !dbg !11
@p = dso_local local_unnamed_addr global ptr null, align 8, !dbg !16
@s2 = dso_local local_unnamed_addr global %struct.S2 zeroinitializer, align 4, !dbg !20
@ps2 = dso_local local_unnamed_addr global ptr null, align 8, !dbg !26
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_decls.cpp, ptr null }]

; Function Attrs: nobuiltin allocsize(0)
declare !dbg !46 noundef nonnull ptr @_Znam(i64 noundef) local_unnamed_addr #0

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef range(i32 1, -2147483648) i32 @_Z1gi(i32 noundef %0) local_unnamed_addr #1 !dbg !51 {
    #dbg_value(i32 %0, !55, !DIExpression(), !58)
    #dbg_value(i32 0, !56, !DIExpression(), !58)
    #dbg_value(i32 poison, !56, !DIExpression(), !58)
  %2 = tail call i32 @llvm.smax.i32(i32 %0, i32 1), !dbg !59
  ret i32 %2, !dbg !60
}

; Function Attrs: sspstrong uwtable
define internal void @_GLOBAL__sub_I_decls.cpp() #2 section ".text.startup" !dbg !61 {
  %1 = tail call noalias noundef nonnull dereferenceable(3) ptr @_Znam(i64 noundef 3) #4, !dbg !64, !heapallocsite !19
  store i8 1, ptr %1, align 1, !dbg !64, !tbaa !69
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 1, !dbg !64
  store i8 2, ptr %2, align 1, !dbg !64, !tbaa !69
  %3 = getelementptr inbounds nuw i8, ptr %1, i64 2, !dbg !64
  store i8 3, ptr %3, align 1, !dbg !64, !tbaa !69
  store ptr %1, ptr @p, align 8, !dbg !70, !tbaa !71
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #3

attributes #0 = { nobuiltin allocsize(0) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { builtin allocsize(0) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!33, !34, !35, !36, !37, !38, !39}
!llvm.ident = !{!40}
!llvm.errno.tbaa = !{!41}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "s", linkageName: "_ZN1A1sE", scope: !2, file: !3, line: 3, type: !10, isLocal: false, isDefinition: true, declaration: !31)
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !3, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, imports: !29, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "test/cpp/samples/decls.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "82281835b2e509f3553bc2b481ee3e9b")
!4 = !{!0, !5, !11, !16, !20, !26}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "z", linkageName: "_ZN1a1b1c1zE", scope: !7, file: !3, line: 6, type: !10, isLocal: false, isDefinition: true)
!7 = !DINamespace(name: "c", scope: !8, exportSymbols: true)
!8 = !DINamespace(name: "b", scope: !9)
!9 = !DINamespace(name: "a", scope: null)
!10 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!11 = !DIGlobalVariableExpression(var: !12, expr: !DIExpression())
!12 = distinct !DIGlobalVariable(name: "fp", scope: !2, file: !3, line: 12, type: !13, isLocal: false, isDefinition: true)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{null, !10}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !3, line: 13, type: !18, isLocal: false, isDefinition: true)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "s2", scope: !2, file: !3, line: 16, type: !22, isLocal: false, isDefinition: true)
!22 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "S2", file: !3, line: 16, size: 64, flags: DIFlagTypePassByValue, elements: !23, identifier: "_ZTS2S2")
!23 = !{!24, !25}
!24 = !DIDerivedType(tag: DW_TAG_member, name: "a", scope: !22, file: !3, line: 16, baseType: !10, size: 32)
!25 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !22, file: !3, line: 16, baseType: !10, size: 32, offset: 32)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "ps2", scope: !2, file: !3, line: 16, type: !28, isLocal: false, isDefinition: true)
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !22, size: 64)
!29 = !{!30}
!30 = !DIImportedEntity(tag: DW_TAG_imported_module, scope: !2, entity: !8, file: !3, line: 8)
!31 = !DIDerivedType(tag: DW_TAG_variable, name: "s", scope: !32, file: !3, line: 1, baseType: !10, flags: DIFlagStaticMember)
!32 = !DICompositeType(tag: DW_TAG_structure_type, name: "A", file: !3, line: 1, size: 64, flags: DIFlagFwdDecl | DIFlagNonTrivial, identifier: "_ZTS1A")
!33 = !{i32 7, !"Dwarf Version", i32 5}
!34 = !{i32 2, !"Debug Info Version", i32 3}
!35 = !{i32 4, !"probe-stack", !"inline-asm"}
!36 = !{i32 8, !"PIC Level", i32 2}
!37 = !{i32 7, !"PIE Level", i32 2}
!38 = !{i32 7, !"uwtable", i32 2}
!39 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!40 = !{!"Alpine clang version 23.1.5"}
!41 = !{!42, !43, i64 0}
!42 = !{!"__libc_errno", !43, i64 0}
!43 = !{!"int", !44, i64 0}
!44 = !{!"omnipotent char", !45, i64 0}
!45 = !{!"Simple C++ TBAA"}
!46 = !DISubprogram(name: "operator new[]", linkageName: "_Znam", scope: !3, file: !3, type: !47, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!47 = !DISubroutineType(types: !48)
!48 = !{!49, !50}
!49 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!50 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!51 = distinct !DISubprogram(name: "g", linkageName: "_Z1gi", scope: !3, file: !3, line: 14, type: !52, scopeLine: 14, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !54, keyInstructions: true)
!52 = !DISubroutineType(types: !53)
!53 = !{!10, !10}
!54 = !{!55, !56, !57}
!55 = !DILocalVariable(name: "n", arg: 1, scope: !51, file: !3, line: 14, type: !10)
!56 = !DILocalVariable(name: "r", scope: !51, file: !3, line: 14, type: !10)
!57 = !DILabel(scope: !51, name: "L", file: !3, line: 14, column: 27)
!58 = !DILocation(line: 0, scope: !51)
!59 = !DILocation(line: 14, column: 16, scope: !51)
!60 = !DILocation(line: 14, column: 54, scope: !51, atomGroup: 7, atomRank: 1)
!61 = distinct !DISubprogram(linkageName: "_GLOBAL__sub_I_decls.cpp", scope: !3, file: !3, type: !62, flags: DIFlagArtificial | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!62 = !DISubroutineType(types: !63)
!63 = !{}
!64 = !DILocation(line: 13, column: 11, scope: !65, inlinedAt: !68)
!65 = distinct !DISubprogram(name: "__cxx_global_var_init", scope: !3, file: !3, type: !66, flags: DIFlagArtificial | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, keyInstructions: true)
!66 = !DISubroutineType(types: !67)
!67 = !{null}
!68 = distinct !DILocation(line: 0, scope: !61)
!69 = !{!44, !44, i64 0}
!70 = !DILocation(line: 0, scope: !65, inlinedAt: !68)
!71 = !{!72, !72, i64 0}
!72 = !{!"p1 omnipotent char", !73, i64 0}
!73 = !{!"any pointer", !44, i64 0}
