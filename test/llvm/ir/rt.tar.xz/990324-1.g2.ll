; ModuleID = '990324-1.c'
source_filename = "990324-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local void @f(i64 noundef %0) local_unnamed_addr #0 !dbg !12 {
    #dbg_value(i64 %0, !17, !DIExpression(), !18)
  %2 = trunc i64 %0 to i8, !dbg !19
  %3 = icmp slt i8 %2, 1, !dbg !21
  br i1 %3, label %4, label %5, !dbg !21

4:                                                ; preds = %1
  tail call void @abort() #3, !dbg !22
  unreachable, !dbg !22

5:                                                ; preds = %1
  tail call void @exit(i32 noundef 0) #3, !dbg !23
  unreachable, !dbg !23
}

; Function Attrs: cold nofree noreturn nounwind
declare void @abort() local_unnamed_addr #1

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #2

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 !dbg !24 {
    #dbg_value(i64 4294967041, !17, !DIExpression(), !28)
  tail call void @exit(i32 noundef 0) #3, !dbg !30
  unreachable, !dbg !30
}

attributes #0 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!4, !5, !6, !7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "990324-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "347ff3a67d16f9bbeef109e1993b120f")
!2 = !{!3}
!3 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!4 = !{i32 7, !"Dwarf Version", i32 5}
!5 = !{i32 2, !"Debug Info Version", i32 3}
!6 = !{i32 4, !"probe-stack", !"inline-asm"}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!11 = !{!"Alpine clang version 23.1.5"}
!12 = distinct !DISubprogram(name: "f", scope: !1, file: !1, line: 4, type: !13, scopeLine: 5, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !16, keyInstructions: true)
!13 = !DISubroutineType(types: !14)
!14 = !{null, !15}
!15 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!16 = !{!17}
!17 = !DILocalVariable(name: "i", arg: 1, scope: !12, file: !1, line: 4, type: !15)
!18 = !DILocation(line: 0, scope: !12)
!19 = !DILocation(line: 6, column: 7, scope: !20)
!20 = distinct !DILexicalBlock(scope: !12, file: !1, line: 6, column: 7)
!21 = !DILocation(line: 6, column: 26, scope: !20, atomGroup: 1, atomRank: 1)
!22 = !DILocation(line: 7, column: 5, scope: !20)
!23 = !DILocation(line: 9, column: 5, scope: !20)
!24 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 13, type: !25, scopeLine: 14, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!25 = !DISubroutineType(types: !26)
!26 = !{!27}
!27 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!28 = !DILocation(line: 0, scope: !12, inlinedAt: !29)
!29 = distinct !DILocation(line: 15, column: 3, scope: !24)
!30 = !DILocation(line: 9, column: 5, scope: !20, inlinedAt: !29)
