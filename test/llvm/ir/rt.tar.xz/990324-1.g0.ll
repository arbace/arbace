; ModuleID = '990324-1.c'
source_filename = "990324-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f(i64 noundef %0) #0 !dbg !12 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
    #dbg_declare(ptr %2, !17, !DIExpression(), !18)
  %3 = load i64, ptr %2, align 8, !dbg !19
  %4 = trunc i64 %3 to i8, !dbg !21
  %5 = sext i8 %4 to i32, !dbg !21
  %6 = icmp slt i32 %5, 0, !dbg !22
  br i1 %6, label %12, label %7, !dbg !23

7:                                                ; preds = %1
  %8 = load i64, ptr %2, align 8, !dbg !24
  %9 = trunc i64 %8 to i8, !dbg !25
  %10 = sext i8 %9 to i32, !dbg !25
  %11 = icmp eq i32 %10, 0, !dbg !26
  br i1 %11, label %12, label %13, !dbg !23

12:                                               ; preds = %7, %1
  call void @abort() #3, !dbg !27
  unreachable, !dbg !27

13:                                               ; preds = %7
  call void @exit(i32 noundef 0) #4, !dbg !28
  unreachable, !dbg !28
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !29 {
  call void @f(i64 noundef 4294967041), !dbg !33
  ret i32 0, !dbg !34
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!4, !5, !6, !7, !8, !9, !10}
!llvm.ident = !{!11}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "990324-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "347ff3a67d16f9bbeef109e1993b120f")
!2 = !{!3}
!3 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!4 = !{i32 7, !"Dwarf Version", i32 5}
!5 = !{i32 2, !"Debug Info Version", i32 3}
!6 = !{i32 4, !"probe-stack", !"inline-asm"}
!7 = !{i32 8, !"PIC Level", i32 2}
!8 = !{i32 7, !"PIE Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{i32 7, !"frame-pointer", i32 2}
!11 = !{!"Alpine clang version 23.1.5"}
!12 = distinct !DISubprogram(name: "f", scope: !1, file: !1, line: 4, type: !13, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !16)
!13 = !DISubroutineType(types: !14)
!14 = !{null, !15}
!15 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!16 = !{}
!17 = !DILocalVariable(name: "i", arg: 1, scope: !12, file: !1, line: 4, type: !15)
!18 = !DILocation(line: 4, column: 13, scope: !12)
!19 = !DILocation(line: 6, column: 20, scope: !20)
!20 = distinct !DILexicalBlock(scope: !12, file: !1, line: 6, column: 7)
!21 = !DILocation(line: 6, column: 7, scope: !20)
!22 = !DILocation(line: 6, column: 22, scope: !20)
!23 = !DILocation(line: 6, column: 26, scope: !20)
!24 = !DILocation(line: 6, column: 42, scope: !20)
!25 = !DILocation(line: 6, column: 29, scope: !20)
!26 = !DILocation(line: 6, column: 44, scope: !20)
!27 = !DILocation(line: 7, column: 5, scope: !20)
!28 = !DILocation(line: 9, column: 5, scope: !20)
!29 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 13, type: !30, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!30 = !DISubroutineType(types: !31)
!31 = !{!32}
!32 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!33 = !DILocation(line: 15, column: 3, scope: !29)
!34 = !DILocation(line: 16, column: 1, scope: !29)
