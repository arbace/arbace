; ModuleID = '20070424-1.c'
source_filename = "20070424-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local void @do_exit() local_unnamed_addr #0 !dbg !10 {
  tail call void @exit(i32 noundef 0) #4, !dbg !13
  unreachable, !dbg !13
}

; Function Attrs: nofree noreturn
declare void @exit(i32 noundef) local_unnamed_addr #1

; Function Attrs: cold nofree noreturn nounwind sspstrong uwtable
define dso_local void @do_abort() local_unnamed_addr #2 !dbg !14 {
  tail call void @abort() #4, !dbg !15
  unreachable, !dbg !15
}

; Function Attrs: cold nofree noreturn nounwind
declare void @abort() local_unnamed_addr #3

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local void @foo(i32 noundef %0, i32 noundef %1) local_unnamed_addr #0 !dbg !16 {
    #dbg_value(i32 %0, !21, !DIExpression(), !24)
    #dbg_value(i32 %1, !22, !DIExpression(), !24)
  %3 = icmp slt i32 %0, %1, !dbg !25
  br i1 %3, label %5, label %4, !dbg !27

4:                                                ; preds = %2
  tail call void @exit(i32 noundef 0) #4, !dbg !28
  unreachable, !dbg !28

5:                                                ; preds = %2
    #dbg_label(!23, !30)
  tail call void @abort() #4, !dbg !31
  unreachable, !dbg !31
}

; Function Attrs: nofree noreturn nounwind sspstrong uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 !dbg !33 {
    #dbg_value(i32 1, !21, !DIExpression(), !36)
    #dbg_value(i32 0, !22, !DIExpression(), !36)
  tail call void @exit(i32 noundef 0) #4, !dbg !38
  unreachable, !dbg !38
}

attributes #0 = { nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree noreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { cold nofree noreturn nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { cold nofree noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "20070424-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "2c73e84807d122c6366d637e4cc43eb2")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "do_exit", scope: !1, file: !1, line: 4, type: !11, scopeLine: 4, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!11 = !DISubroutineType(types: !12)
!12 = !{null}
!13 = !DILocation(line: 4, column: 23, scope: !10)
!14 = distinct !DISubprogram(name: "do_abort", scope: !1, file: !1, line: 5, type: !11, scopeLine: 5, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!15 = !DILocation(line: 5, column: 24, scope: !14)
!16 = distinct !DISubprogram(name: "foo", scope: !1, file: !1, line: 7, type: !17, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !20, keyInstructions: true)
!17 = !DISubroutineType(types: !18)
!18 = !{null, !19, !19}
!19 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!20 = !{!21, !22, !23}
!21 = !DILocalVariable(name: "x", arg: 1, scope: !16, file: !1, line: 7, type: !19)
!22 = !DILocalVariable(name: "a", arg: 2, scope: !16, file: !1, line: 7, type: !19)
!23 = !DILabel(scope: !16, name: "doit", file: !1, line: 19, column: 1)
!24 = !DILocation(line: 0, scope: !16)
!25 = !DILocation(line: 9, column: 9, scope: !26, atomGroup: 1, atomRank: 2)
!26 = distinct !DILexicalBlock(scope: !16, file: !1, line: 9, column: 7)
!27 = !DILocation(line: 9, column: 9, scope: !26, atomGroup: 1, atomRank: 1)
!28 = !DILocation(line: 4, column: 23, scope: !10, inlinedAt: !29)
!29 = distinct !DILocation(line: 11, column: 3, scope: !16)
!30 = !DILocation(line: 19, column: 1, scope: !16)
!31 = !DILocation(line: 5, column: 24, scope: !14, inlinedAt: !32)
!32 = distinct !DILocation(line: 20, column: 3, scope: !16)
!33 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 23, type: !34, scopeLine: 24, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, keyInstructions: true)
!34 = !DISubroutineType(types: !35)
!35 = !{!19}
!36 = !DILocation(line: 0, scope: !16, inlinedAt: !37)
!37 = distinct !DILocation(line: 25, column: 3, scope: !33)
!38 = !DILocation(line: 4, column: 23, scope: !10, inlinedAt: !39)
!39 = distinct !DILocation(line: 11, column: 3, scope: !16, inlinedAt: !37)
