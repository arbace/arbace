; ModuleID = '970217-1.c'
source_filename = "970217-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @sub(i32 noundef %0, ptr noundef %1) #0 !dbg !10 {
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  store i32 %0, ptr %3, align 4
    #dbg_declare(ptr %3, !16, !DIExpression(), !17)
  store ptr %1, ptr %4, align 8
    #dbg_declare(ptr %4, !18, !DIExpression(), !19)
  %5 = load i32, ptr %3, align 4, !dbg !20
  %6 = add nsw i32 %5, 1, !dbg !20
  store i32 %6, ptr %3, align 4, !dbg !20
  %7 = zext i32 %5 to i64
  %8 = load i32, ptr %3, align 4, !dbg !21
  ret i32 %8, !dbg !22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 !dbg !23 {
  %1 = alloca i32, align 4
  %2 = alloca [10 x i32], align 16
  store i32 0, ptr %1, align 4
    #dbg_declare(ptr %2, !26, !DIExpression(), !30)
  %3 = getelementptr inbounds [10 x i32], ptr %2, i64 0, i64 0, !dbg !31
  %4 = call i32 @sub(i32 noundef 10, ptr noundef %3), !dbg !32
  %5 = icmp ne i32 %4, 11, !dbg !33
  %6 = zext i1 %5 to i32, !dbg !33
  call void @exit(i32 noundef %6) #2, !dbg !34
  unreachable, !dbg !34
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7, !8}
!llvm.ident = !{!9}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "970217-1.c", directory: ".", checksumkind: CSK_MD5, checksum: "44cff1ab97dbb3b3a8278bd9860be919")
!2 = !{i32 7, !"Dwarf Version", i32 5}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{i32 4, !"probe-stack", !"inline-asm"}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"PIE Level", i32 2}
!7 = !{i32 7, !"uwtable", i32 2}
!8 = !{i32 7, !"frame-pointer", i32 2}
!9 = !{!"Alpine clang version 23.1.5"}
!10 = distinct !DISubprogram(name: "sub", scope: !1, file: !1, line: 4, type: !11, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !15)
!11 = !DISubroutineType(types: !12)
!12 = !{!13, !13, !14}
!13 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!15 = !{}
!16 = !DILocalVariable(name: "i", arg: 1, scope: !10, file: !1, line: 4, type: !13)
!17 = !DILocation(line: 4, column: 10, scope: !10)
!18 = !DILocalVariable(name: "array", arg: 2, scope: !10, file: !1, line: 4, type: !14)
!19 = !DILocation(line: 4, column: 17, scope: !10)
!20 = !DILocation(line: 4, column: 24, scope: !10)
!21 = !DILocation(line: 6, column: 10, scope: !10)
!22 = !DILocation(line: 6, column: 3, scope: !10)
!23 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 10, type: !24, scopeLine: 11, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0, retainedNodes: !15)
!24 = !DISubroutineType(types: !25)
!25 = !{!13}
!26 = !DILocalVariable(name: "array", scope: !23, file: !1, line: 12, type: !27)
!27 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 320, elements: !28)
!28 = !{!29}
!29 = !DISubrange(count: 10)
!30 = !DILocation(line: 12, column: 7, scope: !23)
!31 = !DILocation(line: 13, column: 18, scope: !23)
!32 = !DILocation(line: 13, column: 9, scope: !23)
!33 = !DILocation(line: 13, column: 25, scope: !23)
!34 = !DILocation(line: 13, column: 3, scope: !23)
