; ModuleID = 'test/cpp/samples/coroutine.cpp'
source_filename = "test/cpp/samples/coroutine.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: mustprogress sspstrong uwtable
define dso_local noalias noundef nonnull ptr @_Z5counti(i32 noundef %0) local_unnamed_addr #0 personality ptr @__gxx_personality_v0 !dbg !138 {
    #dbg_value(i32 %0, !142, !DIExpression(), !174)
  %2 = tail call noalias noundef nonnull dereferenceable(32) ptr @_Znwm(i64 noundef 32) #6, !dbg !175
    #dbg_declare(ptr %2, !153, !DIExpression(), !176)
  store ptr @_Z5counti.resume, ptr %2, align 8, !dbg !175
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 8, !dbg !175
  store ptr @_Z5counti.destroy, ptr %3, align 8, !dbg !175
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16, !dbg !175
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 20, !dbg !175
  store i32 %0, ptr %5, align 4, !dbg !175
  store i32 %0, ptr %4, align 8, !dbg !175, !tbaa !177, !DIAssignID !179
    #dbg_assign(ptr poison, !143, !DIExpression(DW_OP_deref), !179, ptr %4, !DIExpression(), !174)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 28, !dbg !175
  store i2 0, ptr %6, align 4, !dbg !175
  ret ptr %2, !dbg !175
}

; Function Attrs: nobuiltin allocsize(0)
declare !dbg !180 noundef nonnull ptr @_Znwm(i64 noundef) local_unnamed_addr #1

declare i32 @__gxx_personality_v0(...)

; Function Attrs: nobuiltin nounwind
declare !dbg !184 void @_ZdlPvm(ptr noundef, i64 noundef) local_unnamed_addr #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable
define dso_local noundef i32 @main() local_unnamed_addr #3 personality ptr @__gxx_personality_v0 !dbg !187 {
    #dbg_value(ptr poison, !193, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !201)
    #dbg_value(i32 3, !193, !DIExpression(DW_OP_LLVM_fragment, 160, 32), !201)
    #dbg_value(ptr undef, !191, !DIExpression(), !209)
    #dbg_value(ptr undef, !205, !DIExpression(), !210)
    #dbg_value(ptr undef, !193, !DIExpression(DW_OP_deref), !201)
    #dbg_value(i32 0, !198, !DIExpression(), !211)
    #dbg_assign(i32 0, !197, !DIExpression(), !212, ptr poison, !DIExpression(), !201)
    #dbg_value(i32 0, !192, !DIExpression(), !209)
    #dbg_value(i32 0, !192, !DIExpression(), !209)
    #dbg_value(ptr undef, !205, !DIExpression(), !210)
    #dbg_value(ptr undef, !198, !DIExpression(DW_OP_plus_uconst, 24, DW_OP_deref, DW_OP_plus_uconst, 1), !211)
    #dbg_value(ptr undef, !193, !DIExpression(DW_OP_deref), !201)
    #dbg_value(i32 1, !198, !DIExpression(), !211)
    #dbg_assign(i32 1, !197, !DIExpression(), !212, ptr poison, !DIExpression(), !201)
    #dbg_value(i32 1, !192, !DIExpression(), !209)
    #dbg_value(ptr undef, !198, !DIExpression(DW_OP_plus_uconst, 24, DW_OP_deref, DW_OP_plus_uconst, 1), !211)
    #dbg_value(i32 2, !198, !DIExpression(), !211)
    #dbg_assign(i32 2, !197, !DIExpression(), !212, ptr poison, !DIExpression(), !201)
    #dbg_value(i32 3, !192, !DIExpression(), !209)
    #dbg_value(ptr undef, !198, !DIExpression(DW_OP_plus_uconst, 24, DW_OP_deref, DW_OP_plus_uconst, 1), !211)
    #dbg_value(i32 3, !198, !DIExpression(), !211)
    #dbg_assign(i32 3, !197, !DIExpression(), !212, ptr poison, !DIExpression(), !201)
  ret i32 3, !dbg !213
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite) uwtable
define internal void @_Z5counti.resume(ptr nofree noundef nonnull align 8 captures(none) dereferenceable(32) %0) #4 personality ptr @__gxx_personality_v0 !dbg !194 {
    #dbg_value(ptr %0, !198, !DIExpression(DW_OP_plus_uconst, 24, DW_OP_deref, DW_OP_plus_uconst, 1), !214)
    #dbg_value(ptr %0, !215, !DIExpression(DW_OP_plus_uconst, 16), !219)
    #dbg_value(ptr %0, !193, !DIExpression(DW_OP_deref), !222)
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16, !dbg !223
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 28
  %4 = load i2, ptr %3, align 4
  %5 = icmp eq i2 %4, 0
  br i1 %5, label %6, label %13

6:                                                ; preds = %1
    #dbg_label(!224, !223)
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 20, !dbg !223
  %8 = load i32, ptr %7, align 4, !dbg !223, !tbaa !225
    #dbg_value(i32 0, !198, !DIExpression(), !214)
  %9 = icmp sgt i32 %8, 0, !dbg !227
  br i1 %9, label %10, label %21, !dbg !228

10:                                               ; preds = %6, %20
  %11 = phi i32 [ %18, %20 ], [ 0, %6 ]
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 24, !dbg !229
  store i32 %11, ptr %12, align 8, !dbg !229
    #dbg_value(i32 %11, !198, !DIExpression(), !214)
    #dbg_value(i32 %11, !218, !DIExpression(), !219)
  store i32 %11, ptr %2, align 8, !dbg !230, !tbaa !177, !DIAssignID !231
    #dbg_assign(i32 %11, !197, !DIExpression(), !231, ptr %2, !DIExpression(), !222)
  store i2 1, ptr %3, align 4, !dbg !229
  br label %22, !dbg !229

13:                                               ; preds = %1
  %14 = getelementptr inbounds nuw i8, ptr %0, i64 24, !dbg !229
  %15 = load i32, ptr %14, align 8, !dbg !229, !tbaa !225
  %16 = getelementptr inbounds nuw i8, ptr %0, i64 20, !dbg !229
  %17 = load i32, ptr %16, align 4, !dbg !229, !tbaa !225
  %18 = add nuw nsw i32 %15, 1, !dbg !232
  %19 = icmp eq i32 %18, %17, !dbg !227
  br i1 %19, label %21, label %20, !dbg !228, !llvm.loop !233

20:                                               ; preds = %13
  br label %10, !dbg !228, !llvm.loop !233

21:                                               ; preds = %6, %13
  store ptr null, ptr %0, align 8, !dbg !223
  br label %22, !dbg !223

22:                                               ; preds = %10, %21
  ret void, !dbg !223
}

; Function Attrs: mustprogress nounwind sspstrong uwtable
define internal void @_Z5counti.destroy(ptr nofree noundef nonnull readonly align 8 captures(address) dereferenceable(32) %0) #5 personality ptr @__gxx_personality_v0 !dbg !236 {
    #dbg_value(ptr %0, !243, !DIExpression(DW_OP_deref), !244)
  tail call void @_ZdlPvm(ptr noundef nonnull %0, i64 noundef 32) #7, !dbg !245
  ret void, !dbg !245
}

attributes #0 = { mustprogress sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nobuiltin allocsize(0) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nobuiltin nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind sspstrong willreturn memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nounwind sspstrong uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { allocsize(0) }
attributes #7 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!125, !126, !127, !128, !129, !130, !131}
!llvm.ident = !{!132}
!llvm.errno.tbaa = !{!133}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "Alpine clang version 23.1.5", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !2, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "test/cpp/samples/coroutine.cpp", directory: ".", checksumkind: CSK_MD5, checksum: "81a5ad31eddd36b2bc49117452e7da0c")
!2 = !{!3, !122, !124, !49, !6}
!3 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "Gen", file: !1, line: 2, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !4, identifier: "_ZTS3Gen")
!4 = !{!5}
!5 = !DIDerivedType(tag: DW_TAG_member, name: "h", scope: !3, file: !1, line: 6, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "coroutine_handle<Gen::promise_type>", scope: !8, file: !7, line: 198, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !10, templateParams: !120, identifier: "_ZTSNSt7__n486116coroutine_handleIN3Gen12promise_typeEEE")
!7 = !DIFile(filename: "/usr/lib/gcc/x86_64-alpine-linux-musl/15.2.0/../../../../include/c++/15.2.0/coroutine", directory: "", checksumkind: CSK_MD5, checksum: "264518c8a6bbba954d8dfbc74162a7e2")
!8 = !DINamespace(name: "__n4861", scope: !9, exportSymbols: true)
!9 = !DINamespace(name: "std", scope: null)
!10 = !{!11, !13, !17, !23, !93, !97, !102, !105, !108, !111, !112, !115, !116, !117}
!11 = !DIDerivedType(tag: DW_TAG_member, name: "_M_fr_ptr", scope: !6, file: !7, line: 260, baseType: !12, size: 64, flags: DIFlagPrivate)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!13 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC4Ev", scope: !6, file: !7, line: 202, type: !14, scopeLine: 202, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!14 = !DISubroutineType(types: !15)
!15 = !{null, !16}
!16 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!17 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEC4EDn", scope: !6, file: !7, line: 204, type: !18, scopeLine: 204, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!18 = !DISubroutineType(types: !19)
!19 = !{null, !16, !20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "nullptr_t", scope: !9, file: !21, line: 342, baseType: !22)
!21 = !DIFile(filename: "/usr/lib/gcc/x86_64-alpine-linux-musl/15.2.0/../../../../include/c++/15.2.0/x86_64-alpine-linux-musl/bits/c++config.h", directory: "", checksumkind: CSK_MD5, checksum: "5eec1bce6d97e7b076e1ef1ad2c40d8a")
!22 = !DIBasicType(tag: DW_TAG_unspecified_type, name: "decltype(nullptr)")
!23 = !DISubprogram(name: "from_promise", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_promiseERS2_", scope: !6, file: !7, line: 207, type: !24, scopeLine: 207, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: DISPFlagOptimized)
!24 = !DISubroutineType(types: !25)
!25 = !{!6, !26}
!26 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !27, size: 64)
!27 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "promise_type", scope: !3, file: !1, line: 2, size: 32, flags: DIFlagTypePassByValue, elements: !28, identifier: "_ZTSN3Gen12promise_typeE")
!28 = !{!29, !31, !35, !85, !86, !89, !92}
!29 = !DIDerivedType(tag: DW_TAG_member, name: "v", scope: !27, file: !1, line: 2, baseType: !30, size: 32)
!30 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!31 = !DISubprogram(name: "get_return_object", linkageName: "_ZN3Gen12promise_type17get_return_objectEv", scope: !27, file: !1, line: 3, type: !32, scopeLine: 3, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!32 = !DISubroutineType(types: !33)
!33 = !{!3, !34}
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!35 = !DISubprogram(name: "initial_suspend", linkageName: "_ZN3Gen12promise_type15initial_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!36 = !DISubroutineType(types: !37)
!37 = !{!38, !34}
!38 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "suspend_always", scope: !8, file: !7, line: 329, size: 8, flags: DIFlagTypePassByValue, elements: !39, identifier: "_ZTSNSt7__n486114suspend_alwaysE")
!39 = !{!40, !46, !82}
!40 = !DISubprogram(name: "await_ready", linkageName: "_ZNKSt7__n486114suspend_always11await_readyEv", scope: !38, file: !7, line: 331, type: !41, scopeLine: 331, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!41 = !DISubroutineType(types: !42)
!42 = !{!43, !44}
!43 = !DIBasicType(name: "bool", size: 8, encoding: DW_ATE_boolean)
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!45 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !38)
!46 = !DISubprogram(name: "await_suspend", linkageName: "_ZNKSt7__n486114suspend_always13await_suspendENS_16coroutine_handleIvEE", scope: !38, file: !7, line: 333, type: !47, scopeLine: 333, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!47 = !DISubroutineType(types: !48)
!48 = !{null, !44, !49}
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "coroutine_handle<void>", scope: !8, file: !7, line: 103, size: 64, flags: DIFlagTypePassByValue | DIFlagNonTrivial, elements: !50, templateParams: !80, identifier: "_ZTSNSt7__n486116coroutine_handleIvEE")
!50 = !{!51, !52, !56, !59, !63, !68, !71, !74, !75, !78, !79}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "_M_fr_ptr", scope: !49, file: !7, line: 147, baseType: !12, size: 64, flags: DIFlagProtected)
!52 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIvEC4Ev", scope: !49, file: !7, line: 107, type: !53, scopeLine: 107, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!53 = !DISubroutineType(types: !54)
!54 = !{null, !55}
!55 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!56 = !DISubprogram(name: "coroutine_handle", linkageName: "_ZNSt7__n486116coroutine_handleIvEC4EDn", scope: !49, file: !7, line: 109, type: !57, scopeLine: 109, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!57 = !DISubroutineType(types: !58)
!58 = !{null, !55, !20}
!59 = !DISubprogram(name: "operator=", linkageName: "_ZNSt7__n486116coroutine_handleIvEaSEDn", scope: !49, file: !7, line: 113, type: !60, scopeLine: 113, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!60 = !DISubroutineType(types: !61)
!61 = !{!62, !55, !20}
!62 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !49, size: 64)
!63 = !DISubprogram(name: "address", linkageName: "_ZNKSt7__n486116coroutine_handleIvE7addressEv", scope: !49, file: !7, line: 121, type: !64, scopeLine: 121, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!64 = !DISubroutineType(types: !65)
!65 = !{!12, !66}
!66 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !67, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!67 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !49)
!68 = !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIvE12from_addressEPv", scope: !49, file: !7, line: 123, type: !69, scopeLine: 123, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: DISPFlagOptimized)
!69 = !DISubroutineType(types: !70)
!70 = !{!49, !12}
!71 = !DISubprogram(name: "operator bool", linkageName: "_ZNKSt7__n486116coroutine_handleIvEcvbEv", scope: !49, file: !7, line: 132, type: !72, scopeLine: 132, flags: DIFlagExplicit | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!72 = !DISubroutineType(types: !73)
!73 = !{!43, !66}
!74 = !DISubprogram(name: "done", linkageName: "_ZNKSt7__n486116coroutine_handleIvE4doneEv", scope: !49, file: !7, line: 137, type: !72, scopeLine: 137, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!75 = !DISubprogram(name: "operator()", linkageName: "_ZNKSt7__n486116coroutine_handleIvEclEv", scope: !49, file: !7, line: 140, type: !76, scopeLine: 140, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!76 = !DISubroutineType(types: !77)
!77 = !{null, !66}
!78 = !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIvE6resumeEv", scope: !49, file: !7, line: 142, type: !76, scopeLine: 142, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!79 = !DISubprogram(name: "destroy", linkageName: "_ZNKSt7__n486116coroutine_handleIvE7destroyEv", scope: !49, file: !7, line: 144, type: !76, scopeLine: 144, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!80 = !{!81}
!81 = !DITemplateTypeParameter(name: "_Promise", type: null, defaulted: true)
!82 = !DISubprogram(name: "await_resume", linkageName: "_ZNKSt7__n486114suspend_always12await_resumeEv", scope: !38, file: !7, line: 335, type: !83, scopeLine: 335, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!83 = !DISubroutineType(types: !84)
!84 = !{null, !44}
!85 = !DISubprogram(name: "final_suspend", linkageName: "_ZN3Gen12promise_type13final_suspendEv", scope: !27, file: !1, line: 4, type: !36, scopeLine: 4, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!86 = !DISubprogram(name: "yield_value", linkageName: "_ZN3Gen12promise_type11yield_valueEi", scope: !27, file: !1, line: 5, type: !87, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!87 = !DISubroutineType(types: !88)
!88 = !{!38, !34, !30}
!89 = !DISubprogram(name: "return_void", linkageName: "_ZN3Gen12promise_type11return_voidEv", scope: !27, file: !1, line: 5, type: !90, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!90 = !DISubroutineType(types: !91)
!91 = !{null, !34}
!92 = !DISubprogram(name: "unhandled_exception", linkageName: "_ZN3Gen12promise_type19unhandled_exceptionEv", scope: !27, file: !1, line: 5, type: !90, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!93 = !DISubprogram(name: "operator=", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEEaSEDn", scope: !6, file: !7, line: 215, type: !94, scopeLine: 215, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!94 = !DISubroutineType(types: !95)
!95 = !{!96, !16, !20}
!96 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !6, size: 64)
!97 = !DISubprogram(name: "address", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7addressEv", scope: !6, file: !7, line: 223, type: !98, scopeLine: 223, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!98 = !DISubroutineType(types: !99)
!99 = !{!12, !100}
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64, flags: DIFlagArtificial | DIFlagObjectPointer)
!101 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!102 = !DISubprogram(name: "from_address", linkageName: "_ZNSt7__n486116coroutine_handleIN3Gen12promise_typeEE12from_addressEPv", scope: !6, file: !7, line: 225, type: !103, scopeLine: 225, flags: DIFlagPrototyped | DIFlagStaticMember, spFlags: DISPFlagOptimized)
!103 = !DISubroutineType(types: !104)
!104 = !{!6, !12}
!105 = !DISubprogram(name: "operator coroutine_handle", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvNS0_IvEEEv", scope: !6, file: !7, line: 233, type: !106, scopeLine: 233, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!106 = !DISubroutineType(types: !107)
!107 = !{!49, !100}
!108 = !DISubprogram(name: "operator bool", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEcvbEv", scope: !6, file: !7, line: 237, type: !109, scopeLine: 237, flags: DIFlagExplicit | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!109 = !DISubroutineType(types: !110)
!110 = !{!43, !100}
!111 = !DISubprogram(name: "done", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE4doneEv", scope: !6, file: !7, line: 242, type: !109, scopeLine: 242, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!112 = !DISubprogram(name: "operator()", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEEclEv", scope: !6, file: !7, line: 245, type: !113, scopeLine: 245, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!113 = !DISubroutineType(types: !114)
!114 = !{null, !100}
!115 = !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv", scope: !6, file: !7, line: 247, type: !113, scopeLine: 247, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!116 = !DISubprogram(name: "destroy", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7destroyEv", scope: !6, file: !7, line: 249, type: !113, scopeLine: 249, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!117 = !DISubprogram(name: "promise", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE7promiseEv", scope: !6, file: !7, line: 252, type: !118, scopeLine: 252, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!118 = !DISubroutineType(types: !119)
!119 = !{!26, !100}
!120 = !{!121}
!121 = !DITemplateTypeParameter(name: "_Promise", type: !27)
!122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !123, size: 64)
!123 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!124 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !27, size: 64)
!125 = !{i32 7, !"Dwarf Version", i32 5}
!126 = !{i32 2, !"Debug Info Version", i32 3}
!127 = !{i32 4, !"probe-stack", !"inline-asm"}
!128 = !{i32 8, !"PIC Level", i32 2}
!129 = !{i32 7, !"PIE Level", i32 2}
!130 = !{i32 7, !"uwtable", i32 2}
!131 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!132 = !{!"Alpine clang version 23.1.5"}
!133 = !{!134, !135, i64 0}
!134 = !{!"__libc_errno", !135, i64 0}
!135 = !{!"int", !136, i64 0}
!136 = !{!"omnipotent char", !137, i64 0}
!137 = !{!"Simple C++ TBAA"}
!138 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti", scope: !1, file: !1, line: 7, type: !139, scopeLine: 7, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !141)
!139 = !DISubroutineType(types: !140)
!140 = !{!3, !30}
!141 = !{!142, !143, !150, !153}
!142 = !DILocalVariable(name: "n", arg: 1, scope: !138, file: !1, line: 7, type: !30)
!143 = !DILocalVariable(name: "__promise", scope: !138, type: !144, flags: DIFlagArtificial)
!144 = !DIDerivedType(tag: DW_TAG_typedef, name: "promise_type", scope: !145, file: !7, line: 91, baseType: !27)
!145 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__coroutine_traits_impl<Gen, void>", scope: !8, file: !7, line: 85, size: 8, flags: DIFlagTypePassByValue, elements: !146, templateParams: !147, identifier: "_ZTSNSt7__n486123__coroutine_traits_implI3GenvEE")
!146 = !{}
!147 = !{!148, !149}
!148 = !DITemplateTypeParameter(name: "_Result", type: !3)
!149 = !DITemplateTypeParameter(type: null, defaulted: true)
!150 = !DILocalVariable(name: "i", scope: !151, file: !1, line: 7, type: !30)
!151 = distinct !DILexicalBlock(scope: !152, file: !1, line: 7, column: 19)
!152 = distinct !DILexicalBlock(scope: !138, file: !1, line: 7, column: 17)
!153 = !DILocalVariable(name: "__coro_frame", scope: !138, file: !1, line: 7, type: !154, flags: DIFlagArtificial)
!154 = !DICompositeType(tag: DW_TAG_structure_type, name: "_Z5counti.coro_frame_ty", file: !1, line: 7, size: 256, align: 64, flags: DIFlagArtificial, elements: !155)
!155 = !{!156, !157, !158, !160, !162, !163, !168, !169, !170}
!156 = !DIDerivedType(tag: DW_TAG_member, name: "__resume_fn", scope: !154, file: !1, line: 7, baseType: !12, size: 64, align: 64, flags: DIFlagArtificial)
!157 = !DIDerivedType(tag: DW_TAG_member, name: "__destroy_fn", scope: !154, file: !1, line: 7, baseType: !12, size: 64, align: 64, offset: 64, flags: DIFlagArtificial)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "__coro_index", scope: !154, file: !1, line: 7, baseType: !159, size: 2, align: 8, offset: 224, flags: DIFlagArtificial)
!159 = !DIBasicType(name: "__coro_index", size: 8, encoding: DW_ATE_unsigned_char)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "__int_32_0", scope: !154, file: !1, line: 7, baseType: !161, size: 32, align: 32, offset: 160, flags: DIFlagArtificial)
!161 = !DIBasicType(name: "__int_32", size: 32, encoding: DW_ATE_signed, flags: DIFlagArtificial)
!162 = !DIDerivedType(tag: DW_TAG_member, name: "__int_32_1", scope: !154, file: !1, line: 7, baseType: !161, size: 32, align: 32, offset: 192, flags: DIFlagArtificial)
!163 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_2", scope: !154, file: !1, line: 7, baseType: !164, size: 8, align: 8, offset: 232, flags: DIFlagArtificial)
!164 = !DICompositeType(tag: DW_TAG_structure_type, name: "struct_std____n4861__suspend_always", scope: !154, file: !1, line: 7, size: 8, align: 64, flags: DIFlagArtificial, elements: !165)
!165 = !{!166}
!166 = !DIDerivedType(tag: DW_TAG_member, name: "__int_8", scope: !164, file: !1, line: 7, baseType: !167, size: 8, flags: DIFlagArtificial)
!167 = !DIBasicType(name: "__int_8", size: 8, encoding: DW_ATE_signed, flags: DIFlagArtificial)
!168 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_3", scope: !154, file: !1, line: 7, baseType: !164, size: 8, align: 8, offset: 232, flags: DIFlagArtificial)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "struct_std____n4861__suspend_always_4", scope: !154, file: !1, line: 7, baseType: !164, size: 8, align: 8, offset: 232, flags: DIFlagArtificial)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "struct_Gen__promise_type_5", scope: !154, file: !1, line: 7, baseType: !171, size: 32, align: 32, offset: 128, flags: DIFlagArtificial)
!171 = !DICompositeType(tag: DW_TAG_structure_type, name: "struct_Gen__promise_type", scope: !154, file: !1, line: 7, size: 32, align: 64, flags: DIFlagArtificial, elements: !172)
!172 = !{!173}
!173 = !DIDerivedType(tag: DW_TAG_member, name: "__int_32", scope: !171, file: !1, line: 7, baseType: !161, size: 32, flags: DIFlagArtificial)
!174 = !DILocation(line: 0, scope: !138)
!175 = !DILocation(line: 7, column: 5, scope: !138)
!176 = !DILocation(line: 7, column: 17, scope: !138)
!177 = !{!178, !135, i64 0}
!178 = !{!"_ZTSN3Gen12promise_typeE", !135, i64 0}
!179 = distinct !DIAssignID()
!180 = !DISubprogram(name: "operator new", linkageName: "_Znwm", scope: !1, file: !1, type: !181, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!181 = !DISubroutineType(types: !182)
!182 = !{!12, !183}
!183 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!184 = !DISubprogram(name: "operator delete", linkageName: "_ZdlPvm", scope: !1, file: !1, type: !185, flags: DIFlagArtificial | DIFlagPrototyped, spFlags: DISPFlagOptimized)
!185 = !DISubroutineType(types: !186)
!186 = !{null, !12, !183}
!187 = distinct !DISubprogram(name: "main", scope: !1, file: !1, line: 8, type: !188, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !190, keyInstructions: true)
!188 = !DISubroutineType(types: !189)
!189 = !{!30}
!190 = !{!191, !192}
!191 = !DILocalVariable(name: "g", scope: !187, file: !1, line: 8, type: !3)
!192 = !DILocalVariable(name: "s", scope: !187, file: !1, line: 8, type: !30)
!193 = !DILocalVariable(name: "__coro_frame", scope: !194, file: !1, line: 7, type: !154, flags: DIFlagArtificial)
!194 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti.resume", scope: !1, file: !1, line: 7, type: !139, scopeLine: 7, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !195)
!195 = !{!196, !197, !198, !193}
!196 = !DILocalVariable(name: "n", arg: 1, scope: !194, file: !1, line: 7, type: !30)
!197 = !DILocalVariable(name: "__promise", scope: !194, type: !144, flags: DIFlagArtificial)
!198 = !DILocalVariable(name: "i", scope: !199, file: !1, line: 7, type: !30)
!199 = distinct !DILexicalBlock(scope: !200, file: !1, line: 7, column: 19)
!200 = distinct !DILexicalBlock(scope: !194, file: !1, line: 7, column: 17)
!201 = !DILocation(line: 0, scope: !194, inlinedAt: !202)
!202 = distinct !DILocation(line: 247, column: 29, scope: !203, inlinedAt: !207)
!203 = distinct !DISubprogram(name: "resume", linkageName: "_ZNKSt7__n486116coroutine_handleIN3Gen12promise_typeEE6resumeEv", scope: !6, file: !7, line: 247, type: !113, scopeLine: 247, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, declaration: !115, retainedNodes: !204, keyInstructions: true)
!204 = !{!205}
!205 = !DILocalVariable(name: "this", arg: 1, scope: !203, type: !206, flags: DIFlagArtificial | DIFlagObjectPointer)
!206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64)
!207 = distinct !DILocation(line: 8, column: 62, scope: !208)
!208 = distinct !DILexicalBlock(scope: !187, file: !1, line: 8, column: 56)
!209 = !DILocation(line: 0, scope: !187)
!210 = !DILocation(line: 0, scope: !203, inlinedAt: !207)
!211 = !DILocation(line: 0, scope: !199, inlinedAt: !202)
!212 = distinct !DIAssignID()
!213 = !DILocation(line: 8, column: 125, scope: !187, atomGroup: 8, atomRank: 1)
!214 = !DILocation(line: 0, scope: !199)
!215 = !DILocalVariable(name: "this", arg: 1, scope: !216, type: !124, flags: DIFlagArtificial | DIFlagObjectPointer)
!216 = distinct !DISubprogram(name: "yield_value", linkageName: "_ZN3Gen12promise_type11yield_valueEi", scope: !27, file: !1, line: 5, type: !87, scopeLine: 5, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, declaration: !86, retainedNodes: !217, keyInstructions: true)
!217 = !{!215, !218}
!218 = !DILocalVariable(name: "x", arg: 2, scope: !216, file: !1, line: 5, type: !30)
!219 = !DILocation(line: 0, scope: !216, inlinedAt: !220)
!220 = distinct !DILocation(line: 7, column: 40, scope: !221)
!221 = distinct !DILexicalBlock(scope: !199, file: !1, line: 7, column: 19)
!222 = !DILocation(line: 0, scope: !194)
!223 = !DILocation(line: 7, column: 5, scope: !194)
!224 = !DILabel(scope: !194, name: "__coro_resume_0", file: !1, line: 7, column: 5, isArtificial: true, coroSuspendIdx: 0)
!225 = !{!226, !226, i64 0}
!226 = !{!"_Z5counti.Frame Slot", !137, i64 0}
!227 = !DILocation(line: 7, column: 32, scope: !221)
!228 = !DILocation(line: 7, column: 19, scope: !199)
!229 = !DILocation(line: 7, column: 40, scope: !221)
!230 = !DILocation(line: 5, column: 44, scope: !216, inlinedAt: !220, atomGroup: 1, atomRank: 1)
!231 = distinct !DIAssignID()
!232 = !DILocation(line: 7, column: 36, scope: !221)
!233 = distinct !{!233, !228, !234, !235}
!234 = !DILocation(line: 7, column: 49, scope: !199)
!235 = !{!"llvm.loop.mustprogress"}
!236 = distinct !DISubprogram(name: "count", linkageName: "_Z5counti.destroy", scope: !1, file: !1, line: 7, type: !139, scopeLine: 7, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !237)
!237 = !{!238, !239, !240, !243}
!238 = !DILocalVariable(name: "n", arg: 1, scope: !236, file: !1, line: 7, type: !30)
!239 = !DILocalVariable(name: "__promise", scope: !236, type: !144, flags: DIFlagArtificial)
!240 = !DILocalVariable(name: "i", scope: !241, file: !1, line: 7, type: !30)
!241 = distinct !DILexicalBlock(scope: !242, file: !1, line: 7, column: 19)
!242 = distinct !DILexicalBlock(scope: !236, file: !1, line: 7, column: 17)
!243 = !DILocalVariable(name: "__coro_frame", scope: !236, file: !1, line: 7, type: !154, flags: DIFlagArtificial)
!244 = !DILocation(line: 0, scope: !236)
!245 = !DILocation(line: 7, column: 5, scope: !236)
