; ModuleID = '20041019-1.c'
source_filename = "20041019-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test_store_ccp(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %7 = load i32, ptr %2, align 4
  %8 = icmp slt i32 %7, 5
  br i1 %8, label %9, label %10

9:                                                ; preds = %1
  store ptr %4, ptr %3, align 8
  br label %16

10:                                               ; preds = %1
  %11 = load i32, ptr %2, align 4
  %12 = icmp sgt i32 %11, 8
  br i1 %12, label %13, label %14

13:                                               ; preds = %10
  store ptr %5, ptr %3, align 8
  br label %15

14:                                               ; preds = %10
  store ptr %6, ptr %3, align 8
  br label %15

15:                                               ; preds = %14, %13
  br label %16

16:                                               ; preds = %15, %9
  %17 = load ptr, ptr %3, align 8
  store i32 10, ptr %17, align 4
  store i32 3, ptr %5, align 4
  %18 = load ptr, ptr %3, align 8
  %19 = load i32, ptr %18, align 4
  %20 = add nsw i32 %19, 2
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test_store_copy_prop(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %7 = load i32, ptr %2, align 4
  %8 = icmp slt i32 %7, 5
  br i1 %8, label %9, label %10

9:                                                ; preds = %1
  store ptr %4, ptr %3, align 8
  br label %16

10:                                               ; preds = %1
  %11 = load i32, ptr %2, align 4
  %12 = icmp sgt i32 %11, 8
  br i1 %12, label %13, label %14

13:                                               ; preds = %10
  store ptr %5, ptr %3, align 8
  br label %15

14:                                               ; preds = %10
  store ptr %6, ptr %3, align 8
  br label %15

15:                                               ; preds = %14, %13
  br label %16

16:                                               ; preds = %15, %9
  %17 = load i32, ptr %2, align 4
  %18 = load ptr, ptr %3, align 8
  store i32 %17, ptr %18, align 4
  %19 = load i32, ptr %2, align 4
  %20 = add nsw i32 %19, 1
  store i32 %20, ptr %5, align 4
  %21 = load ptr, ptr %3, align 8
  %22 = load i32, ptr %21, align 4
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %3 = call i32 @test_store_ccp(i32 noundef 10)
  store i32 %3, ptr %2, align 4
  %4 = load i32, ptr %2, align 4
  %5 = icmp eq i32 %4, 12
  br i1 %5, label %6, label %7

6:                                                ; preds = %0
  call void @abort() #2
  unreachable

7:                                                ; preds = %0
  %8 = call i32 @test_store_copy_prop(i32 noundef 9)
  store i32 %8, ptr %2, align 4
  %9 = load i32, ptr %2, align 4
  %10 = icmp eq i32 %9, 9
  br i1 %10, label %11, label %12

11:                                               ; preds = %7
  call void @abort() #2
  unreachable

12:                                               ; preds = %7
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
