; ModuleID = '20000808-1.c'
source_filename = "20000808-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.Point = type { i64, i64 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @bar() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4, i64 %5, ptr noundef byval(%struct.Point) align 8 %6, ptr noundef byval(%struct.Point) align 8 %7, ptr noundef byval(%struct.Point) align 8 %8) #0 {
  %10 = alloca %struct.Point, align 8
  %11 = alloca %struct.Point, align 8
  %12 = alloca %struct.Point, align 8
  %13 = getelementptr inbounds nuw { i64, i64 }, ptr %10, i32 0, i32 0
  store i64 %0, ptr %13, align 8
  %14 = getelementptr inbounds nuw { i64, i64 }, ptr %10, i32 0, i32 1
  store i64 %1, ptr %14, align 8
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 0
  store i64 %2, ptr %15, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 1
  store i64 %3, ptr %16, align 8
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %12, i32 0, i32 0
  store i64 %4, ptr %17, align 8
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %12, i32 0, i32 1
  store i64 %5, ptr %18, align 8
  %19 = getelementptr inbounds nuw %struct.Point, ptr %10, i32 0, i32 0
  %20 = load i64, ptr %19, align 8
  %21 = icmp ne i64 %20, 0
  br i1 %21, label %66, label %22

22:                                               ; preds = %9
  %23 = getelementptr inbounds nuw %struct.Point, ptr %10, i32 0, i32 1
  %24 = load i64, ptr %23, align 8
  %25 = icmp ne i64 %24, 1
  br i1 %25, label %66, label %26

26:                                               ; preds = %22
  %27 = getelementptr inbounds nuw %struct.Point, ptr %11, i32 0, i32 0
  %28 = load i64, ptr %27, align 8
  %29 = icmp ne i64 %28, -1
  br i1 %29, label %66, label %30

30:                                               ; preds = %26
  %31 = getelementptr inbounds nuw %struct.Point, ptr %11, i32 0, i32 1
  %32 = load i64, ptr %31, align 8
  %33 = icmp ne i64 %32, 0
  br i1 %33, label %66, label %34

34:                                               ; preds = %30
  %35 = getelementptr inbounds nuw %struct.Point, ptr %12, i32 0, i32 0
  %36 = load i64, ptr %35, align 8
  %37 = icmp ne i64 %36, 1
  br i1 %37, label %66, label %38

38:                                               ; preds = %34
  %39 = getelementptr inbounds nuw %struct.Point, ptr %12, i32 0, i32 1
  %40 = load i64, ptr %39, align 8
  %41 = icmp ne i64 %40, -1
  br i1 %41, label %66, label %42

42:                                               ; preds = %38
  %43 = getelementptr inbounds nuw %struct.Point, ptr %6, i32 0, i32 0
  %44 = load i64, ptr %43, align 8
  %45 = icmp ne i64 %44, -1
  br i1 %45, label %66, label %46

46:                                               ; preds = %42
  %47 = getelementptr inbounds nuw %struct.Point, ptr %6, i32 0, i32 1
  %48 = load i64, ptr %47, align 8
  %49 = icmp ne i64 %48, 1
  br i1 %49, label %66, label %50

50:                                               ; preds = %46
  %51 = getelementptr inbounds nuw %struct.Point, ptr %7, i32 0, i32 0
  %52 = load i64, ptr %51, align 8
  %53 = icmp ne i64 %52, 0
  br i1 %53, label %66, label %54

54:                                               ; preds = %50
  %55 = getelementptr inbounds nuw %struct.Point, ptr %7, i32 0, i32 1
  %56 = load i64, ptr %55, align 8
  %57 = icmp ne i64 %56, -1
  br i1 %57, label %66, label %58

58:                                               ; preds = %54
  %59 = getelementptr inbounds nuw %struct.Point, ptr %8, i32 0, i32 0
  %60 = load i64, ptr %59, align 8
  %61 = icmp ne i64 %60, 1
  br i1 %61, label %66, label %62

62:                                               ; preds = %58
  %63 = getelementptr inbounds nuw %struct.Point, ptr %8, i32 0, i32 1
  %64 = load i64, ptr %63, align 8
  %65 = icmp ne i64 %64, 0
  br i1 %65, label %66, label %67

66:                                               ; preds = %62, %58, %54, %50, %46, %42, %38, %34, %30, %26, %22, %9
  call void @abort() #3
  unreachable

67:                                               ; preds = %62
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo() #0 {
  %1 = alloca %struct.Point, align 8
  %2 = alloca %struct.Point, align 8
  %3 = alloca %struct.Point, align 8
  %4 = alloca %struct.Point, align 8
  %5 = alloca %struct.Point, align 8
  %6 = alloca %struct.Point, align 8
  call void @bar()
  %7 = getelementptr inbounds nuw %struct.Point, ptr %1, i32 0, i32 0
  store i64 0, ptr %7, align 8
  %8 = getelementptr inbounds nuw %struct.Point, ptr %1, i32 0, i32 1
  store i64 1, ptr %8, align 8
  %9 = getelementptr inbounds nuw %struct.Point, ptr %2, i32 0, i32 0
  store i64 -1, ptr %9, align 8
  %10 = getelementptr inbounds nuw %struct.Point, ptr %2, i32 0, i32 1
  store i64 0, ptr %10, align 8
  %11 = getelementptr inbounds nuw %struct.Point, ptr %3, i32 0, i32 0
  store i64 1, ptr %11, align 8
  %12 = getelementptr inbounds nuw %struct.Point, ptr %3, i32 0, i32 1
  store i64 -1, ptr %12, align 8
  %13 = getelementptr inbounds nuw %struct.Point, ptr %4, i32 0, i32 0
  store i64 -1, ptr %13, align 8
  %14 = getelementptr inbounds nuw %struct.Point, ptr %4, i32 0, i32 1
  store i64 1, ptr %14, align 8
  %15 = getelementptr inbounds nuw %struct.Point, ptr %5, i32 0, i32 0
  store i64 0, ptr %15, align 8
  %16 = getelementptr inbounds nuw %struct.Point, ptr %5, i32 0, i32 1
  store i64 -1, ptr %16, align 8
  %17 = getelementptr inbounds nuw %struct.Point, ptr %6, i32 0, i32 0
  store i64 1, ptr %17, align 8
  %18 = getelementptr inbounds nuw %struct.Point, ptr %6, i32 0, i32 1
  store i64 0, ptr %18, align 8
  %19 = getelementptr inbounds nuw { i64, i64 }, ptr %1, i32 0, i32 0
  %20 = load i64, ptr %19, align 8
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %1, i32 0, i32 1
  %22 = load i64, ptr %21, align 8
  %23 = getelementptr inbounds nuw { i64, i64 }, ptr %2, i32 0, i32 0
  %24 = load i64, ptr %23, align 8
  %25 = getelementptr inbounds nuw { i64, i64 }, ptr %2, i32 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %28 = load i64, ptr %27, align 8
  %29 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %30 = load i64, ptr %29, align 8
  call void @f(i64 %20, i64 %22, i64 %24, i64 %26, i64 %28, i64 %30, ptr noundef byval(%struct.Point) align 8 %4, ptr noundef byval(%struct.Point) align 8 %5, ptr noundef byval(%struct.Point) align 8 %6)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @foo()
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
