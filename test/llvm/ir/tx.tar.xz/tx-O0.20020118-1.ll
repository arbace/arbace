; ModuleID = '20020118-1.c'
source_filename = "20020118-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@q = dso_local global ptr null, align 8
@n = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo() #0 {
  %1 = alloca ptr, align 8
  br label %2

2:                                                ; preds = %2, %0
  %3 = load ptr, ptr @q, align 8
  store ptr %3, ptr %1, align 8
  %4 = load ptr, ptr %1, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 2
  %6 = load i8, ptr %5, align 1
  %7 = sext i8 %6 to i32
  store volatile i32 %7, ptr @n, align 4
  %8 = load ptr, ptr @q, align 8
  store ptr %8, ptr %1, align 8
  %9 = load ptr, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 2
  %11 = load i8, ptr %10, align 1
  %12 = sext i8 %11 to i32
  store volatile i32 %12, ptr @n, align 4
  %13 = load ptr, ptr @q, align 8
  store ptr %13, ptr %1, align 8
  %14 = load ptr, ptr %1, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 2
  %16 = load i8, ptr %15, align 1
  %17 = sext i8 %16 to i32
  store volatile i32 %17, ptr @n, align 4
  %18 = load ptr, ptr @q, align 8
  store ptr %18, ptr %1, align 8
  %19 = load ptr, ptr %1, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 2
  %21 = load i8, ptr %20, align 1
  %22 = sext i8 %21 to i32
  store volatile i32 %22, ptr @n, align 4
  %23 = load ptr, ptr @q, align 8
  store ptr %23, ptr %1, align 8
  %24 = load ptr, ptr %1, align 8
  %25 = getelementptr inbounds i8, ptr %24, i64 2
  %26 = load i8, ptr %25, align 1
  %27 = sext i8 %26 to i32
  store volatile i32 %27, ptr @n, align 4
  %28 = load ptr, ptr @q, align 8
  store ptr %28, ptr %1, align 8
  %29 = load ptr, ptr %1, align 8
  %30 = getelementptr inbounds i8, ptr %29, i64 2
  %31 = load i8, ptr %30, align 1
  %32 = sext i8 %31 to i32
  store volatile i32 %32, ptr @n, align 4
  %33 = load ptr, ptr @q, align 8
  store ptr %33, ptr %1, align 8
  %34 = load ptr, ptr %1, align 8
  %35 = getelementptr inbounds i8, ptr %34, i64 2
  %36 = load i8, ptr %35, align 1
  %37 = sext i8 %36 to i32
  store volatile i32 %37, ptr @n, align 4
  %38 = load ptr, ptr @q, align 8
  store ptr %38, ptr %1, align 8
  %39 = load ptr, ptr %1, align 8
  %40 = getelementptr inbounds i8, ptr %39, i64 2
  %41 = load i8, ptr %40, align 1
  %42 = sext i8 %41 to i32
  store volatile i32 %42, ptr @n, align 4
  %43 = load ptr, ptr @q, align 8
  store ptr %43, ptr %1, align 8
  %44 = load ptr, ptr %1, align 8
  %45 = getelementptr inbounds i8, ptr %44, i64 2
  %46 = load i8, ptr %45, align 1
  %47 = sext i8 %46 to i32
  store volatile i32 %47, ptr @n, align 4
  %48 = load ptr, ptr @q, align 8
  store ptr %48, ptr %1, align 8
  %49 = load ptr, ptr %1, align 8
  %50 = getelementptr inbounds i8, ptr %49, i64 2
  %51 = load i8, ptr %50, align 1
  %52 = sext i8 %51 to i32
  store volatile i32 %52, ptr @n, align 4
  %53 = load ptr, ptr @q, align 8
  store ptr %53, ptr %1, align 8
  %54 = load ptr, ptr %1, align 8
  %55 = getelementptr inbounds i8, ptr %54, i64 2
  %56 = load i8, ptr %55, align 1
  %57 = sext i8 %56 to i32
  store volatile i32 %57, ptr @n, align 4
  br label %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @exit(i32 noundef 0) #2
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
