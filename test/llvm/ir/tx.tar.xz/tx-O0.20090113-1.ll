; ModuleID = '20090113-1.c'
source_filename = "20090113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.descriptor_dimension = type { i32, i32, i32 }
%struct.gfc_array_i4 = type { ptr, i32, [7 x %struct.descriptor_dimension] }

@constinit = private constant [7 x %struct.descriptor_dimension] [%struct.descriptor_dimension { i32 1, i32 1, i32 3 }, %struct.descriptor_dimension { i32 3, i32 1, i32 3 }, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer, %struct.descriptor_dimension zeroinitializer], align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @msum_i4(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca [7 x i32], align 16
  %8 = alloca [7 x i32], align 16
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %15 = load ptr, ptr %6, align 8
  %16 = load i32, ptr %15, align 4
  %17 = sub nsw i32 %16, 1
  store i32 %17, ptr %11, align 4
  %18 = load ptr, ptr %5, align 8
  %19 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %18, i32 0, i32 2
  %20 = load i32, ptr %11, align 4
  %21 = sext i32 %20 to i64
  %22 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %19, i64 0, i64 %21
  %23 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %22, i32 0, i32 2
  %24 = load i32, ptr %23, align 4
  %25 = add nsw i32 %24, 1
  %26 = load ptr, ptr %5, align 8
  %27 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %26, i32 0, i32 2
  %28 = load i32, ptr %11, align 4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %27, i64 0, i64 %29
  %31 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %30, i32 0, i32 1
  %32 = load i32, ptr %31, align 4
  %33 = sub nsw i32 %25, %32
  store i32 %33, ptr %13, align 4
  store i32 0, ptr %12, align 4
  br label %34

34:                                               ; preds = %61, %3
  %35 = load i32, ptr %12, align 4
  %36 = load i32, ptr %11, align 4
  %37 = icmp slt i32 %35, %36
  br i1 %37, label %38, label %64

38:                                               ; preds = %34
  %39 = load ptr, ptr %5, align 8
  %40 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %39, i32 0, i32 2
  %41 = load i32, ptr %12, align 4
  %42 = sext i32 %41 to i64
  %43 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %40, i64 0, i64 %42
  %44 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %43, i32 0, i32 2
  %45 = load i32, ptr %44, align 4
  %46 = add nsw i32 %45, 1
  %47 = load ptr, ptr %5, align 8
  %48 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %47, i32 0, i32 2
  %49 = load i32, ptr %12, align 4
  %50 = sext i32 %49 to i64
  %51 = getelementptr inbounds [7 x %struct.descriptor_dimension], ptr %48, i64 0, i64 %50
  %52 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %51, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = sub nsw i32 %46, %53
  %55 = load i32, ptr %12, align 4
  %56 = sext i32 %55 to i64
  %57 = getelementptr inbounds [7 x i32], ptr %8, i64 0, i64 %56
  store i32 %54, ptr %57, align 4
  %58 = load i32, ptr %12, align 4
  %59 = sext i32 %58 to i64
  %60 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 %59
  store i32 0, ptr %60, align 4
  br label %61

61:                                               ; preds = %38
  %62 = load i32, ptr %12, align 4
  %63 = add nsw i32 %62, 1
  store i32 %63, ptr %12, align 4
  br label %34, !llvm.loop !6

64:                                               ; preds = %34
  %65 = load ptr, ptr %4, align 8
  %66 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %65, i32 0, i32 0
  %67 = load ptr, ptr %66, align 8
  store ptr %67, ptr %9, align 8
  %68 = load ptr, ptr %5, align 8
  %69 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %68, i32 0, i32 0
  %70 = load ptr, ptr %69, align 8
  store ptr %70, ptr %10, align 8
  br label %71

71:                                               ; preds = %94, %64
  store i32 0, ptr %14, align 4
  store i32 0, ptr %12, align 4
  br label %72

72:                                               ; preds = %81, %71
  %73 = load i32, ptr %12, align 4
  %74 = load i32, ptr %13, align 4
  %75 = icmp slt i32 %73, %74
  br i1 %75, label %76, label %86

76:                                               ; preds = %72
  %77 = load ptr, ptr %10, align 8
  %78 = load i32, ptr %77, align 4
  %79 = load i32, ptr %14, align 4
  %80 = add nsw i32 %79, %78
  store i32 %80, ptr %14, align 4
  br label %81

81:                                               ; preds = %76
  %82 = load i32, ptr %12, align 4
  %83 = add nsw i32 %82, 1
  store i32 %83, ptr %12, align 4
  %84 = load ptr, ptr %10, align 8
  %85 = getelementptr inbounds nuw i32, ptr %84, i32 1
  store ptr %85, ptr %10, align 8
  br label %72, !llvm.loop !8

86:                                               ; preds = %72
  %87 = load i32, ptr %14, align 4
  %88 = load ptr, ptr %9, align 8
  store i32 %87, ptr %88, align 4
  %89 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 0
  %90 = load i32, ptr %89, align 16
  %91 = add nsw i32 %90, 1
  store i32 %91, ptr %89, align 16
  %92 = load ptr, ptr %9, align 8
  %93 = getelementptr inbounds i32, ptr %92, i64 1
  store ptr %93, ptr %9, align 8
  br label %94

94:                                               ; preds = %86
  %95 = getelementptr inbounds [7 x i32], ptr %7, i64 0, i64 0
  %96 = load i32, ptr %95, align 16
  %97 = getelementptr inbounds [7 x i32], ptr %8, i64 0, i64 0
  %98 = load i32, ptr %97, align 16
  %99 = icmp ne i32 %96, %98
  br i1 %99, label %71, label %100, !llvm.loop !9

100:                                              ; preds = %94
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [3 x i32], align 4
  %3 = alloca [9 x i32], align 16
  %4 = alloca %struct.gfc_array_i4, align 8
  %5 = alloca %struct.gfc_array_i4, align 8
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 96, i1 false)
  %7 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 0
  %8 = getelementptr inbounds [3 x i32], ptr %2, i64 0, i64 0
  store ptr %8, ptr %7, align 8
  %9 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 1
  store i32 265, ptr %9, align 8
  %10 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %4, i32 0, i32 2
  %11 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 0
  store i32 1, ptr %11, align 4
  %12 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 1
  store i32 1, ptr %12, align 4
  %13 = getelementptr inbounds nuw %struct.descriptor_dimension, ptr %10, i32 0, i32 2
  store i32 3, ptr %13, align 4
  %14 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 0
  %15 = getelementptr inbounds [9 x i32], ptr %3, i64 0, i64 0
  store ptr %15, ptr %14, align 8
  %16 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 1
  store i32 266, ptr %16, align 8
  %17 = getelementptr inbounds nuw %struct.gfc_array_i4, ptr %5, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %17, ptr align 4 @constinit, i64 84, i1 false)
  store i32 2, ptr %6, align 4
  call void @msum_i4(ptr noundef %4, ptr noundef %5, ptr noundef %6)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
