; ModuleID = '20121108-1.c'
source_filename = "20121108-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@temp = dso_local global [16 x i8] c"192.168.190.160\00", align 16
@result = dso_local global i32 -1062682976, align 4
@.str = private unnamed_addr constant [4 x i8] c"%x\0A\00", align 1
@.str.1 = private unnamed_addr constant [8 x i8] c"WORKS.\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @strtoul1(ptr noundef %0, ptr noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  %8 = load ptr, ptr %5, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 3
  %10 = load ptr, ptr %6, align 8
  store ptr %9, ptr %10, align 8
  %11 = load ptr, ptr %5, align 8
  %12 = icmp eq ptr %11, @temp
  br i1 %12, label %13, label %14

13:                                               ; preds = %3
  store i32 192, ptr %4, align 4
  br label %30

14:                                               ; preds = %3
  %15 = load ptr, ptr %5, align 8
  %16 = icmp eq ptr %15, getelementptr inbounds nuw (i8, ptr @temp, i64 4)
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  store i32 168, ptr %4, align 4
  br label %30

18:                                               ; preds = %14
  %19 = load ptr, ptr %5, align 8
  %20 = icmp eq ptr %19, getelementptr inbounds nuw (i8, ptr @temp, i64 8)
  br i1 %20, label %21, label %22

21:                                               ; preds = %18
  store i32 190, ptr %4, align 4
  br label %30

22:                                               ; preds = %18
  %23 = load ptr, ptr %5, align 8
  %24 = icmp eq ptr %23, getelementptr inbounds nuw (i8, ptr @temp, i64 12)
  br i1 %24, label %25, label %26

25:                                               ; preds = %22
  store i32 160, ptr %4, align 4
  br label %30

26:                                               ; preds = %22
  br label %27

27:                                               ; preds = %26
  br label %28

28:                                               ; preds = %27
  br label %29

29:                                               ; preds = %28
  call void @abort() #3
  unreachable

30:                                               ; preds = %25, %21, %17, %13
  %31 = load i32, ptr %4, align 4
  ret i32 %31
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @string_to_ip(ptr noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = icmp eq ptr %8, null
  br i1 %9, label %10, label %11

10:                                               ; preds = %1
  store i32 0, ptr %2, align 4
  br label %50

11:                                               ; preds = %1
  store i32 0, ptr %4, align 4
  store i32 0, ptr %6, align 4
  br label %12

12:                                               ; preds = %45, %11
  %13 = load i32, ptr %6, align 4
  %14 = icmp slt i32 %13, 4
  br i1 %14, label %15, label %48

15:                                               ; preds = %12
  %16 = load ptr, ptr %3, align 8
  %17 = icmp ne ptr %16, null
  br i1 %17, label %18, label %21

18:                                               ; preds = %15
  %19 = load ptr, ptr %3, align 8
  %20 = call i32 @strtoul1(ptr noundef %19, ptr noundef %5, i32 noundef 10)
  br label %22

21:                                               ; preds = %15
  br label %22

22:                                               ; preds = %21, %18
  %23 = phi i32 [ %20, %18 ], [ 0, %21 ]
  store i32 %23, ptr %7, align 4
  %24 = load i32, ptr %4, align 4
  %25 = shl i32 %24, 8
  store i32 %25, ptr %4, align 4
  %26 = load i32, ptr %7, align 4
  %27 = and i32 %26, 255
  %28 = load i32, ptr %4, align 4
  %29 = or i32 %28, %27
  store i32 %29, ptr %4, align 4
  %30 = load ptr, ptr %3, align 8
  %31 = icmp ne ptr %30, null
  br i1 %31, label %32, label %44

32:                                               ; preds = %22
  %33 = load ptr, ptr %5, align 8
  %34 = load i8, ptr %33, align 1
  %35 = sext i8 %34 to i32
  %36 = icmp ne i32 %35, 0
  br i1 %36, label %37, label %40

37:                                               ; preds = %32
  %38 = load ptr, ptr %5, align 8
  %39 = getelementptr inbounds i8, ptr %38, i64 1
  br label %42

40:                                               ; preds = %32
  %41 = load ptr, ptr %5, align 8
  br label %42

42:                                               ; preds = %40, %37
  %43 = phi ptr [ %39, %37 ], [ %41, %40 ]
  store ptr %43, ptr %3, align 8
  br label %44

44:                                               ; preds = %42, %22
  br label %45

45:                                               ; preds = %44
  %46 = load i32, ptr %6, align 4
  %47 = add nsw i32 %46, 1
  store i32 %47, ptr %6, align 4
  br label %12, !llvm.loop !6

48:                                               ; preds = %12
  %49 = load i32, ptr %4, align 4
  store i32 %49, ptr %2, align 4
  br label %50

50:                                               ; preds = %48, %10
  %51 = load i32, ptr %2, align 4
  ret i32 %51
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %3 = call i32 @string_to_ip(ptr noundef @temp)
  store i32 %3, ptr %2, align 4
  %4 = load i32, ptr %2, align 4
  %5 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %4)
  %6 = load i32, ptr @result, align 4
  %7 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %6)
  %8 = load i32, ptr %2, align 4
  %9 = load i32, ptr @result, align 4
  %10 = icmp ne i32 %8, %9
  br i1 %10, label %11, label %12

11:                                               ; preds = %0
  call void @abort() #3
  unreachable

12:                                               ; preds = %0
  %13 = call i32 (ptr, ...) @printf(ptr noundef @.str.1)
  ret i32 0
}

declare i32 @printf(ptr noundef, ...) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
