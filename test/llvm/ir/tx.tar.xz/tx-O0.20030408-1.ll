; ModuleID = '20030408-1.c'
source_filename = "20030408-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.foo = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }

@__const.test1.X = private unnamed_addr constant [8 x i8] c"ABCDEFGH", align 1
@__const.test2.X = private unnamed_addr constant [10 x i8] c"ABCDE\00\00\00\00\00", align 1
@__const.test3.X = private unnamed_addr constant %struct.foo { i8 65, i8 0, i8 67, i8 0, i8 69, i8 0, i8 71, i8 0, i8 73, i8 0 }, align 1
@__const.test4.X = private unnamed_addr constant %struct.foo { i8 0, i8 66, i8 0, i8 68, i8 0, i8 70, i8 0, i8 72, i8 0, i8 74 }, align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test1() #0 {
  %1 = alloca [8 x i8], align 1
  %2 = alloca [8 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 @__const.test1.X, i64 8, i1 false)
  %3 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 0
  %4 = getelementptr inbounds [8 x i8], ptr %1, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 %4, i64 8, i1 false)
  %5 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 0
  %6 = load i8, ptr %5, align 1
  %7 = sext i8 %6 to i32
  %8 = icmp ne i32 %7, 65
  br i1 %8, label %44, label %9

9:                                                ; preds = %0
  %10 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 1
  %11 = load i8, ptr %10, align 1
  %12 = sext i8 %11 to i32
  %13 = icmp ne i32 %12, 66
  br i1 %13, label %44, label %14

14:                                               ; preds = %9
  %15 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 2
  %16 = load i8, ptr %15, align 1
  %17 = sext i8 %16 to i32
  %18 = icmp ne i32 %17, 67
  br i1 %18, label %44, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 3
  %21 = load i8, ptr %20, align 1
  %22 = sext i8 %21 to i32
  %23 = icmp ne i32 %22, 68
  br i1 %23, label %44, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 4
  %26 = load i8, ptr %25, align 1
  %27 = sext i8 %26 to i32
  %28 = icmp ne i32 %27, 69
  br i1 %28, label %44, label %29

29:                                               ; preds = %24
  %30 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 5
  %31 = load i8, ptr %30, align 1
  %32 = sext i8 %31 to i32
  %33 = icmp ne i32 %32, 70
  br i1 %33, label %44, label %34

34:                                               ; preds = %29
  %35 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 6
  %36 = load i8, ptr %35, align 1
  %37 = sext i8 %36 to i32
  %38 = icmp ne i32 %37, 71
  br i1 %38, label %44, label %39

39:                                               ; preds = %34
  %40 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 7
  %41 = load i8, ptr %40, align 1
  %42 = sext i8 %41 to i32
  %43 = icmp ne i32 %42, 72
  br i1 %43, label %44, label %45

44:                                               ; preds = %39, %34, %29, %24, %19, %14, %9, %0
  call void @abort() #3
  unreachable

45:                                               ; preds = %39
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test2() #0 {
  %1 = alloca [10 x i8], align 1
  %2 = alloca [10 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 @__const.test2.X, i64 10, i1 false)
  %3 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  %4 = getelementptr inbounds [10 x i8], ptr %1, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 %4, i64 10, i1 false)
  %5 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  %6 = load i8, ptr %5, align 1
  %7 = sext i8 %6 to i32
  %8 = icmp ne i32 %7, 65
  br i1 %8, label %54, label %9

9:                                                ; preds = %0
  %10 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 1
  %11 = load i8, ptr %10, align 1
  %12 = sext i8 %11 to i32
  %13 = icmp ne i32 %12, 66
  br i1 %13, label %54, label %14

14:                                               ; preds = %9
  %15 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 2
  %16 = load i8, ptr %15, align 1
  %17 = sext i8 %16 to i32
  %18 = icmp ne i32 %17, 67
  br i1 %18, label %54, label %19

19:                                               ; preds = %14
  %20 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 3
  %21 = load i8, ptr %20, align 1
  %22 = sext i8 %21 to i32
  %23 = icmp ne i32 %22, 68
  br i1 %23, label %54, label %24

24:                                               ; preds = %19
  %25 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 4
  %26 = load i8, ptr %25, align 1
  %27 = sext i8 %26 to i32
  %28 = icmp ne i32 %27, 69
  br i1 %28, label %54, label %29

29:                                               ; preds = %24
  %30 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 5
  %31 = load i8, ptr %30, align 1
  %32 = sext i8 %31 to i32
  %33 = icmp ne i32 %32, 0
  br i1 %33, label %54, label %34

34:                                               ; preds = %29
  %35 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 6
  %36 = load i8, ptr %35, align 1
  %37 = sext i8 %36 to i32
  %38 = icmp ne i32 %37, 0
  br i1 %38, label %54, label %39

39:                                               ; preds = %34
  %40 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 7
  %41 = load i8, ptr %40, align 1
  %42 = sext i8 %41 to i32
  %43 = icmp ne i32 %42, 0
  br i1 %43, label %54, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 8
  %46 = load i8, ptr %45, align 1
  %47 = sext i8 %46 to i32
  %48 = icmp ne i32 %47, 0
  br i1 %48, label %54, label %49

49:                                               ; preds = %44
  %50 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 9
  %51 = load i8, ptr %50, align 1
  %52 = sext i8 %51 to i32
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %54, label %55

54:                                               ; preds = %49, %44, %39, %34, %29, %24, %19, %14, %9, %0
  call void @abort() #3
  unreachable

55:                                               ; preds = %49
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test3() #0 {
  %1 = alloca %struct.foo, align 1
  %2 = alloca [10 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 @__const.test3.X, i64 10, i1 false)
  %3 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 %1, i64 10, i1 false)
  %4 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  %5 = load i8, ptr %4, align 1
  %6 = sext i8 %5 to i32
  %7 = icmp ne i32 %6, 65
  br i1 %7, label %53, label %8

8:                                                ; preds = %0
  %9 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = sext i8 %10 to i32
  %12 = icmp ne i32 %11, 0
  br i1 %12, label %53, label %13

13:                                               ; preds = %8
  %14 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 2
  %15 = load i8, ptr %14, align 1
  %16 = sext i8 %15 to i32
  %17 = icmp ne i32 %16, 67
  br i1 %17, label %53, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 3
  %20 = load i8, ptr %19, align 1
  %21 = sext i8 %20 to i32
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %53, label %23

23:                                               ; preds = %18
  %24 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 4
  %25 = load i8, ptr %24, align 1
  %26 = sext i8 %25 to i32
  %27 = icmp ne i32 %26, 69
  br i1 %27, label %53, label %28

28:                                               ; preds = %23
  %29 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 5
  %30 = load i8, ptr %29, align 1
  %31 = sext i8 %30 to i32
  %32 = icmp ne i32 %31, 0
  br i1 %32, label %53, label %33

33:                                               ; preds = %28
  %34 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 6
  %35 = load i8, ptr %34, align 1
  %36 = sext i8 %35 to i32
  %37 = icmp ne i32 %36, 71
  br i1 %37, label %53, label %38

38:                                               ; preds = %33
  %39 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 7
  %40 = load i8, ptr %39, align 1
  %41 = sext i8 %40 to i32
  %42 = icmp ne i32 %41, 0
  br i1 %42, label %53, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 8
  %45 = load i8, ptr %44, align 1
  %46 = sext i8 %45 to i32
  %47 = icmp ne i32 %46, 73
  br i1 %47, label %53, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 9
  %50 = load i8, ptr %49, align 1
  %51 = sext i8 %50 to i32
  %52 = icmp ne i32 %51, 0
  br i1 %52, label %53, label %54

53:                                               ; preds = %48, %43, %38, %33, %28, %23, %18, %13, %8, %0
  call void @abort() #3
  unreachable

54:                                               ; preds = %48
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test4() #0 {
  %1 = alloca %struct.foo, align 1
  %2 = alloca [10 x i8], align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 @__const.test4.X, i64 10, i1 false)
  %3 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %3, ptr align 1 %1, i64 10, i1 false)
  %4 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 0
  %5 = load i8, ptr %4, align 1
  %6 = sext i8 %5 to i32
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %53, label %8

8:                                                ; preds = %0
  %9 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 1
  %10 = load i8, ptr %9, align 1
  %11 = sext i8 %10 to i32
  %12 = icmp ne i32 %11, 66
  br i1 %12, label %53, label %13

13:                                               ; preds = %8
  %14 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 2
  %15 = load i8, ptr %14, align 1
  %16 = sext i8 %15 to i32
  %17 = icmp ne i32 %16, 0
  br i1 %17, label %53, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 3
  %20 = load i8, ptr %19, align 1
  %21 = sext i8 %20 to i32
  %22 = icmp ne i32 %21, 68
  br i1 %22, label %53, label %23

23:                                               ; preds = %18
  %24 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 4
  %25 = load i8, ptr %24, align 1
  %26 = sext i8 %25 to i32
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %53, label %28

28:                                               ; preds = %23
  %29 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 5
  %30 = load i8, ptr %29, align 1
  %31 = sext i8 %30 to i32
  %32 = icmp ne i32 %31, 70
  br i1 %32, label %53, label %33

33:                                               ; preds = %28
  %34 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 6
  %35 = load i8, ptr %34, align 1
  %36 = sext i8 %35 to i32
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %53, label %38

38:                                               ; preds = %33
  %39 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 7
  %40 = load i8, ptr %39, align 1
  %41 = sext i8 %40 to i32
  %42 = icmp ne i32 %41, 72
  br i1 %42, label %53, label %43

43:                                               ; preds = %38
  %44 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 8
  %45 = load i8, ptr %44, align 1
  %46 = sext i8 %45 to i32
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %53, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds [10 x i8], ptr %2, i64 0, i64 9
  %50 = load i8, ptr %49, align 1
  %51 = sext i8 %50 to i32
  %52 = icmp ne i32 %51, 74
  br i1 %52, label %53, label %54

53:                                               ; preds = %48, %43, %38, %33, %28, %23, %18, %13, %8, %0
  call void @abort() #3
  unreachable

54:                                               ; preds = %48
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @test1()
  %3 = call i32 @test2()
  %4 = call i32 @test3()
  %5 = call i32 @test4()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
