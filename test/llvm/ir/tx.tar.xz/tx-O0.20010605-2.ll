; ModuleID = '20010605-2.c'
source_filename = "20010605-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca { double, double }, align 8
  %3 = alloca { float, float }, align 4
  %4 = alloca { x86_fp80, x86_fp80 }, align 16
  %5 = alloca { double, double }, align 8
  %6 = alloca { float, float }, align 4
  %7 = alloca { x86_fp80, x86_fp80 }, align 16
  store i32 0, ptr %1, align 4
  %8 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  store double 1.000000e+00, ptr %8, align 8
  %9 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  store double 2.000000e+00, ptr %9, align 8
  %10 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 0
  %11 = load double, ptr %10, align 8
  %12 = getelementptr inbounds nuw { double, double }, ptr %2, i32 0, i32 1
  %13 = load double, ptr %12, align 8
  %14 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 0
  %15 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 1
  store double %11, ptr %14, align 8
  store double %13, ptr %15, align 8
  %16 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 0
  %17 = load double, ptr %16, align 8
  %18 = getelementptr inbounds nuw { double, double }, ptr %5, i32 0, i32 1
  %19 = load double, ptr %18, align 8
  call void @foo(double noundef %17, double noundef %19)
  %20 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 0
  store float 3.000000e+00, ptr %20, align 4
  %21 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 1
  store float 4.000000e+00, ptr %21, align 4
  %22 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 0
  %23 = load float, ptr %22, align 4
  %24 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 1
  %25 = load float, ptr %24, align 4
  %26 = getelementptr inbounds nuw { float, float }, ptr %6, i32 0, i32 0
  %27 = getelementptr inbounds nuw { float, float }, ptr %6, i32 0, i32 1
  store float %23, ptr %26, align 4
  store float %25, ptr %27, align 4
  %28 = load <2 x float>, ptr %6, align 4
  call void @bar(<2 x float> noundef %28)
  %29 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %4, i32 0, i32 0
  store x86_fp80 5.000000e+00, ptr %29, align 16
  %30 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %4, i32 0, i32 1
  store x86_fp80 6.000000e+00, ptr %30, align 16
  %31 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %4, i32 0, i32 0
  %32 = load x86_fp80, ptr %31, align 16
  %33 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %4, i32 0, i32 1
  %34 = load x86_fp80, ptr %33, align 16
  %35 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %7, i32 0, i32 0
  %36 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %7, i32 0, i32 1
  store x86_fp80 %32, ptr %35, align 16
  store x86_fp80 %34, ptr %36, align 16
  call void @baz(ptr noundef byval({ x86_fp80, x86_fp80 }) align 16 %7)
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(double noundef %0, double noundef %1) #2 {
  %3 = alloca { double, double }, align 8
  %4 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  store double %0, ptr %4, align 8
  %5 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  store double %1, ptr %5, align 8
  %6 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %7 = load double, ptr %6, align 8
  %8 = fcmp une double %7, 1.000000e+00
  br i1 %8, label %13, label %9

9:                                                ; preds = %2
  %10 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  %11 = load double, ptr %10, align 8
  %12 = fcmp une double %11, 2.000000e+00
  br i1 %12, label %13, label %14

13:                                               ; preds = %9, %2
  call void @abort() #5
  unreachable

14:                                               ; preds = %9
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @bar(<2 x float> noundef %0) #0 {
  %2 = alloca { float, float }, align 4
  store <2 x float> %0, ptr %2, align 4
  %3 = getelementptr inbounds nuw { float, float }, ptr %2, i32 0, i32 0
  %4 = load float, ptr %3, align 4
  %5 = fcmp une float %4, 3.000000e+00
  br i1 %5, label %10, label %6

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw { float, float }, ptr %2, i32 0, i32 1
  %8 = load float, ptr %7, align 4
  %9 = fcmp une float %8, 4.000000e+00
  br i1 %9, label %10, label %11

10:                                               ; preds = %6, %1
  call void @abort() #5
  unreachable

11:                                               ; preds = %6
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @baz(ptr noundef byval({ x86_fp80, x86_fp80 }) align 16 %0) #2 {
  %2 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %0, i32 0, i32 0
  %3 = load x86_fp80, ptr %2, align 16
  %4 = fcmp une x86_fp80 %3, 5.000000e+00
  br i1 %4, label %9, label %5

5:                                                ; preds = %1
  %6 = getelementptr inbounds nuw { x86_fp80, x86_fp80 }, ptr %0, i32 0, i32 1
  %7 = load x86_fp80, ptr %6, align 16
  %8 = fcmp une x86_fp80 %7, 6.000000e+00
  br i1 %8, label %9, label %10

9:                                                ; preds = %5, %1
  call void @abort() #5
  unreachable

10:                                               ; preds = %5
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="64" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn }
attributes #5 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
