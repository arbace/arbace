; ModuleID = '920411-1.c'
source_filename = "920411-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @f(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %5, align 8
  store ptr %6, ptr %7, align 8
  store i64 0, ptr %4, align 8
  br label %8

8:                                                ; preds = %30, %1
  %9 = load i64, ptr %4, align 8
  %10 = icmp slt i64 %9, 1
  br i1 %10, label %11, label %33

11:                                               ; preds = %8
  store i64 0, ptr %3, align 8
  br label %12

12:                                               ; preds = %23, %11
  %13 = load i64, ptr %3, align 8
  %14 = icmp ult i64 %13, 8
  br i1 %14, label %15, label %26

15:                                               ; preds = %12
  %16 = load ptr, ptr %2, align 8
  %17 = load i64, ptr %3, align 8
  %18 = getelementptr inbounds i8, ptr %16, i64 %17
  %19 = load i8, ptr %18, align 1
  %20 = load ptr, ptr %7, align 8
  %21 = load i64, ptr %3, align 8
  %22 = getelementptr inbounds i8, ptr %20, i64 %21
  store i8 %19, ptr %22, align 1
  br label %23

23:                                               ; preds = %15
  %24 = load i64, ptr %3, align 8
  %25 = add nsw i64 %24, 1
  store i64 %25, ptr %3, align 8
  br label %12, !llvm.loop !6

26:                                               ; preds = %12
  %27 = load i64, ptr %6, align 8
  %28 = load i64, ptr %5, align 8
  %29 = add nsw i64 %28, %27
  store i64 %29, ptr %5, align 8
  br label %30

30:                                               ; preds = %26
  %31 = load i64, ptr %4, align 8
  %32 = add nsw i64 %31, 1
  store i64 %32, ptr %4, align 8
  br label %8, !llvm.loop !8

33:                                               ; preds = %8
  %34 = load i64, ptr %5, align 8
  ret i64 %34
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [8 x i8], align 1
  store i32 0, ptr %1, align 4
  store i32 8, ptr %2, align 4
  br label %4

4:                                                ; preds = %8, %0
  %5 = load i32, ptr %2, align 4
  %6 = add nsw i32 %5, -1
  store i32 %6, ptr %2, align 4
  %7 = icmp sge i32 %6, 0
  br i1 %7, label %8, label %12

8:                                                ; preds = %4
  %9 = load i32, ptr %2, align 4
  %10 = sext i32 %9 to i64
  %11 = getelementptr inbounds [8 x i8], ptr %3, i64 0, i64 %10
  store i8 32, ptr %11, align 1
  br label %4, !llvm.loop !9

12:                                               ; preds = %4
  %13 = getelementptr inbounds [8 x i8], ptr %3, i64 0, i64 0
  %14 = call i64 @f(ptr noundef %13)
  %15 = icmp ne i64 %14, 2314885530818453536
  br i1 %15, label %16, label %17

16:                                               ; preds = %12
  call void @abort() #3
  unreachable

17:                                               ; preds = %12
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
