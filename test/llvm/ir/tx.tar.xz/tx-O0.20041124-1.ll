; ModuleID = '20041124-1.c'
source_filename = "20041124-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.s = type { { i16, i16 } }

@gs = dso_local global %struct.s { { i16, i16 } { i16 100, i16 200 } }, align 2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo() #0 {
  %1 = alloca %struct.s, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %1, ptr align 2 @gs, i64 4, i1 false)
  %2 = getelementptr inbounds nuw %struct.s, ptr %1, i32 0, i32 0
  %3 = load i32, ptr %2, align 2
  ret i32 %3
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.s, align 2
  store i32 0, ptr %1, align 4
  %3 = call i32 @foo()
  %4 = getelementptr inbounds nuw %struct.s, ptr %2, i32 0, i32 0
  store i32 %3, ptr %4, align 2
  %5 = getelementptr inbounds nuw %struct.s, ptr %2, i32 0, i32 0
  %6 = getelementptr inbounds nuw { i16, i16 }, ptr %5, i32 0, i32 0
  %7 = load i16, ptr %6, align 2
  %8 = getelementptr inbounds nuw { i16, i16 }, ptr %5, i32 0, i32 1
  %9 = load i16, ptr %8, align 2
  %10 = load i16, ptr @gs, align 2
  %11 = load i16, ptr getelementptr inbounds nuw (i8, ptr @gs, i64 2), align 2
  %12 = icmp ne i16 %7, %10
  %13 = icmp ne i16 %9, %11
  %14 = or i1 %12, %13
  br i1 %14, label %15, label %16

15:                                               ; preds = %0
  call void @abort() #4
  unreachable

16:                                               ; preds = %0
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
