; ModuleID = '20060905-1.c'
source_filename = "20060905-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@s = dso_local global [256 x [3 x i8]] zeroinitializer, align 16
@g = dso_local global i8 0, align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @foo()
  %3 = icmp ne i32 %2, 128
  br i1 %3, label %4, label %5

4:                                                ; preds = %0
  call void @abort() #2
  unreachable

5:                                                ; preds = %0
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @foo() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %2, align 4
  store i32 0, ptr %1, align 4
  br label %3

3:                                                ; preds = %22, %0
  %4 = load i32, ptr %1, align 4
  %5 = icmp slt i32 %4, 256
  br i1 %5, label %6, label %25

6:                                                ; preds = %3
  %7 = load i32, ptr %1, align 4
  %8 = icmp sge i32 %7, 128
  br i1 %8, label %9, label %21

9:                                                ; preds = %6
  %10 = load i32, ptr %1, align 4
  %11 = icmp slt i32 %10, 256
  br i1 %11, label %12, label %21

12:                                               ; preds = %9
  %13 = load i32, ptr %1, align 4
  %14 = sub nsw i32 %13, 128
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds [256 x [3 x i8]], ptr @s, i64 0, i64 %15
  %17 = getelementptr inbounds [3 x i8], ptr %16, i64 0, i64 0
  %18 = load volatile i8, ptr %17, align 1
  call void @dummy(i8 noundef signext %18)
  %19 = load i32, ptr %2, align 4
  %20 = add nsw i32 %19, 1
  store i32 %20, ptr %2, align 4
  br label %21

21:                                               ; preds = %12, %9, %6
  br label %22

22:                                               ; preds = %21
  %23 = load i32, ptr %1, align 4
  %24 = add nsw i32 %23, 1
  store i32 %24, ptr %1, align 4
  br label %3, !llvm.loop !6

25:                                               ; preds = %3
  %26 = load i32, ptr %2, align 4
  ret i32 %26
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @dummy(i8 noundef signext %0) #0 {
  %2 = alloca i8, align 1
  store i8 %0, ptr %2, align 1
  %3 = load i8, ptr %2, align 1
  store i8 %3, ptr @g, align 1
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
