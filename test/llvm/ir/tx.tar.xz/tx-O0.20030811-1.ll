; ModuleID = '20030811-1.c'
source_filename = "20030811-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@i0 = dso_local global [0 x i32] zeroinitializer, align 4
@i1 = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @vararg(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test1() #0 {
  %1 = alloca i32, align 4
  %2 = call ptr @llvm.returnaddress.p0(i32 0)
  %3 = ptrtoint ptr %2 to i64
  %4 = trunc i64 %3 to i32
  store i32 %4, ptr %1, align 4
  %5 = load i32, ptr %1, align 4
  call void (i32, ...) @vararg(i32 noundef 0, i32 noundef %5)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.returnaddress.p0(i32 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test2() #0 {
  %1 = call ptr @llvm.returnaddress.p0(i32 0)
  %2 = ptrtoint ptr %1 to i64
  %3 = trunc i64 %2 to i32
  store i32 %3, ptr @i0, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test3() #0 {
  %1 = call ptr @llvm.returnaddress.p0(i32 0)
  %2 = ptrtoint ptr %1 to i64
  %3 = trunc i64 %2 to i32
  store i32 %3, ptr @i1, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test4() #0 {
  %1 = alloca i64, align 8
  %2 = call ptr @llvm.returnaddress.p0(i32 0)
  %3 = ptrtoint ptr %2 to i64
  store volatile i64 %3, ptr %1, align 8
  %4 = load volatile i64, ptr %1, align 8
  %5 = trunc i64 %4 to i32
  store i32 %5, ptr @i0, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
