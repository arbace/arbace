; ModuleID = '20031201-1.c'
source_filename = "20031201-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.s1 = type { i32 }
%struct.s2 = type { i32 }
%struct.io = type { %struct.s1, %struct.s2 }

@i = internal global ptr null, align 8
@test_t1 = internal global i64 0, align 8
@m = internal global i32 1, align 4
@test_length = internal global i32 2, align 4
@test_t0 = internal global i64 0, align 8
@d = internal global i32 1, align 4
@f0.washere = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f1(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca %struct.s1, align 4
  %6 = alloca %struct.s2, align 4
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  store i32 0, ptr %3, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %5, i8 0, i64 4, i1 false)
  call void @llvm.memset.p0.i64(ptr align 4 %6, i8 0, i64 4, i1 false)
  %9 = load ptr, ptr %2, align 8
  store ptr %9, ptr @i, align 8
  %10 = load i32, ptr %6, align 4
  %11 = and i32 %10, -65536
  %12 = or i32 %11, 32
  store i32 %12, ptr %6, align 4
  %13 = load i32, ptr %5, align 4
  %14 = and i32 %13, -65536
  %15 = or i32 %14, 32
  store i32 %15, ptr %5, align 4
  %16 = load ptr, ptr @i, align 8
  %17 = getelementptr inbounds nuw %struct.io, ptr %16, i32 0, i32 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %17, ptr align 4 %5, i64 4, i1 false)
  %18 = load ptr, ptr @i, align 8
  %19 = getelementptr inbounds nuw %struct.io, ptr %18, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %19, ptr align 4 %6, i64 4, i1 false)
  br label %20

20:                                               ; preds = %21, %1
  call void @f0()
  br label %21

21:                                               ; preds = %20
  %22 = load i64, ptr @test_t1, align 8
  %23 = icmp ne i64 %22, 0
  br i1 %23, label %20, label %24, !llvm.loop !6

24:                                               ; preds = %21
  %25 = load i32, ptr %6, align 4
  %26 = and i32 %25, -65536
  %27 = or i32 %26, 8
  store i32 %27, ptr %6, align 4
  %28 = load i32, ptr %5, align 4
  %29 = and i32 %28, -65536
  %30 = or i32 %29, 8
  store i32 %30, ptr %5, align 4
  %31 = load ptr, ptr @i, align 8
  %32 = getelementptr inbounds nuw %struct.io, ptr %31, i32 0, i32 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %32, ptr align 4 %5, i64 4, i1 false)
  %33 = load ptr, ptr @i, align 8
  %34 = getelementptr inbounds nuw %struct.io, ptr %33, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %34, ptr align 4 %6, i64 4, i1 false)
  call void @test()
  %35 = load i32, ptr @m, align 4
  %36 = icmp ne i32 %35, 0
  br i1 %36, label %37, label %51

37:                                               ; preds = %24
  %38 = load i32, ptr @test_length, align 4
  %39 = mul nsw i32 2170, %38
  %40 = sext i32 %39 to i64
  store i64 %40, ptr %7, align 8
  %41 = load i64, ptr @test_t1, align 8
  %42 = load i64, ptr @test_t0, align 8
  %43 = sub i64 %41, %42
  store i64 %43, ptr %4, align 8
  %44 = load i64, ptr %4, align 8
  %45 = load i64, ptr %7, align 8
  %46 = sub i64 %44, %45
  %47 = and i64 %46, 2147483647
  %48 = icmp ugt i64 %47, 1000
  br i1 %48, label %49, label %50

49:                                               ; preds = %37
  call void @f0()
  br label %50

50:                                               ; preds = %49, %37
  br label %51

51:                                               ; preds = %50, %24
  %52 = load i32, ptr @d, align 4
  %53 = icmp ne i32 %52, 0
  br i1 %53, label %54, label %68

54:                                               ; preds = %51
  %55 = load i32, ptr @test_length, align 4
  %56 = mul nsw i32 2170, %55
  %57 = sext i32 %56 to i64
  store i64 %57, ptr %8, align 8
  %58 = load i64, ptr @test_t1, align 8
  %59 = load i64, ptr @test_t0, align 8
  %60 = sub i64 %58, %59
  store i64 %60, ptr %4, align 8
  %61 = load i64, ptr %4, align 8
  %62 = load i64, ptr %8, align 8
  %63 = sub i64 %61, %62
  %64 = and i64 %63, 2147483647
  %65 = icmp ugt i64 %64, 1000
  br i1 %65, label %66, label %67

66:                                               ; preds = %54
  call void @f0()
  br label %67

67:                                               ; preds = %66, %54
  br label %68

68:                                               ; preds = %67, %51
  %69 = load i32, ptr %3, align 4
  %70 = icmp ne i32 %69, 0
  %71 = zext i1 %70 to i64
  %72 = select i1 %70, i32 1, i32 0
  ret i32 %72
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f0() #0 {
  %1 = alloca ptr, align 8
  %2 = load ptr, ptr @i, align 8
  store ptr %2, ptr %1, align 8
  %3 = load i32, ptr @f0.washere, align 4
  %4 = add nsw i32 %3, 1
  store i32 %4, ptr @f0.washere, align 4
  %5 = icmp ne i32 %3, 0
  br i1 %5, label %18, label %6

6:                                                ; preds = %0
  %7 = load ptr, ptr %1, align 8
  %8 = getelementptr inbounds nuw %struct.io, ptr %7, i32 0, i32 0
  %9 = load i32, ptr %8, align 4
  %10 = and i32 %9, 65535
  %11 = icmp ne i32 %10, 32
  br i1 %11, label %18, label %12

12:                                               ; preds = %6
  %13 = load ptr, ptr %1, align 8
  %14 = getelementptr inbounds nuw %struct.io, ptr %13, i32 0, i32 1
  %15 = load i32, ptr %14, align 4
  %16 = and i32 %15, 65535
  %17 = icmp ne i32 %16, 32
  br i1 %17, label %18, label %19

18:                                               ; preds = %12, %6, %0
  call void @abort() #5
  unreachable

19:                                               ; preds = %12
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test() #0 {
  %1 = alloca ptr, align 8
  %2 = load ptr, ptr @i, align 8
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  %4 = getelementptr inbounds nuw %struct.io, ptr %3, i32 0, i32 0
  %5 = load i32, ptr %4, align 4
  %6 = and i32 %5, 65535
  %7 = icmp ne i32 %6, 8
  br i1 %7, label %14, label %8

8:                                                ; preds = %0
  %9 = load ptr, ptr %1, align 8
  %10 = getelementptr inbounds nuw %struct.io, ptr %9, i32 0, i32 1
  %11 = load i32, ptr %10, align 4
  %12 = and i32 %11, 65535
  %13 = icmp ne i32 %12, 8
  br i1 %13, label %14, label %15

14:                                               ; preds = %8, %0
  call void @abort() #5
  unreachable

15:                                               ; preds = %8
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.io, align 4
  store i32 0, ptr %1, align 4
  %3 = call i32 @f1(ptr noundef %2)
  call void @abort() #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: noreturn
declare void @exit(i32 noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
