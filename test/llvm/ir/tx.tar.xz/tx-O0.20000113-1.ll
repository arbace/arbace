; ModuleID = '20000113-1.c'
source_filename = "20000113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.x = type { i8, [3 x i8] }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foobar(i32 noundef %0, i32 noundef %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca %struct.x, align 4
  %8 = alloca %struct.x, align 4
  %9 = alloca ptr, align 8
  store i32 %0, ptr %4, align 4
  store i32 %1, ptr %5, align 4
  store i32 %2, ptr %6, align 4
  store i8 0, ptr %7, align 4
  %10 = load i32, ptr %4, align 4
  %11 = trunc i32 %10 to i8
  %12 = load i8, ptr %7, align 4
  %13 = and i8 %11, 1
  %14 = and i8 %12, -2
  %15 = or i8 %14, %13
  store i8 %15, ptr %7, align 4
  %16 = load i32, ptr %5, align 4
  %17 = trunc i32 %16 to i8
  %18 = load i8, ptr %7, align 4
  %19 = and i8 %17, 3
  %20 = shl i8 %19, 1
  %21 = and i8 %18, -7
  %22 = or i8 %21, %20
  store i8 %22, ptr %7, align 4
  %23 = load i32, ptr %6, align 4
  %24 = trunc i32 %23 to i8
  %25 = load i8, ptr %7, align 4
  %26 = and i8 %24, 7
  %27 = shl i8 %26, 3
  %28 = and i8 %25, -57
  %29 = or i8 %28, %27
  store i8 %29, ptr %7, align 4
  %30 = getelementptr i8, ptr %7, i64 1
  call void @llvm.memset.p0.i64(ptr align 1 %30, i8 0, i64 3, i1 false)
  store i8 0, ptr %8, align 4
  %31 = load i32, ptr %4, align 4
  %32 = trunc i32 %31 to i8
  %33 = load i8, ptr %8, align 4
  %34 = and i8 %32, 1
  %35 = and i8 %33, -2
  %36 = or i8 %35, %34
  store i8 %36, ptr %8, align 4
  %37 = load i32, ptr %5, align 4
  %38 = trunc i32 %37 to i8
  %39 = load i8, ptr %8, align 4
  %40 = and i8 %38, 3
  %41 = shl i8 %40, 1
  %42 = and i8 %39, -7
  %43 = or i8 %42, %41
  store i8 %43, ptr %8, align 4
  %44 = load i32, ptr %6, align 4
  %45 = trunc i32 %44 to i8
  %46 = load i8, ptr %8, align 4
  %47 = and i8 %45, 7
  %48 = shl i8 %47, 3
  %49 = and i8 %46, -57
  %50 = or i8 %49, %48
  store i8 %50, ptr %8, align 4
  %51 = getelementptr i8, ptr %8, i64 1
  call void @llvm.memset.p0.i64(ptr align 1 %51, i8 0, i64 3, i1 false)
  store ptr %8, ptr %9, align 8
  %52 = load i8, ptr %7, align 4
  %53 = lshr i8 %52, 1
  %54 = and i8 %53, 3
  %55 = zext i8 %54 to i32
  %56 = load i8, ptr %7, align 4
  %57 = and i8 %56, 1
  %58 = zext i8 %57 to i32
  %59 = sub nsw i32 %55, %58
  %60 = load ptr, ptr %9, align 8
  %61 = load i8, ptr %60, align 4
  %62 = lshr i8 %61, 1
  %63 = and i8 %62, 3
  %64 = zext i8 %63 to i32
  %65 = mul nsw i32 %59, %64
  %66 = load ptr, ptr %9, align 8
  %67 = load i8, ptr %66, align 4
  %68 = lshr i8 %67, 3
  %69 = and i8 %68, 7
  %70 = zext i8 %69 to i32
  %71 = add nsw i32 %70, %65
  %72 = trunc i32 %71 to i8
  %73 = load i8, ptr %66, align 4
  %74 = and i8 %72, 7
  %75 = shl i8 %74, 3
  %76 = and i8 %73, -57
  %77 = or i8 %76, %75
  store i8 %77, ptr %66, align 4
  %78 = zext i8 %74 to i32
  %79 = load i8, ptr %7, align 4
  %80 = and i8 %79, 1
  %81 = zext i8 %80 to i32
  %82 = icmp ne i32 %81, 1
  br i1 %82, label %90, label %83

83:                                               ; preds = %3
  %84 = load ptr, ptr %9, align 8
  %85 = load i8, ptr %84, align 4
  %86 = lshr i8 %85, 3
  %87 = and i8 %86, 7
  %88 = zext i8 %87 to i32
  %89 = icmp ne i32 %88, 5
  br i1 %89, label %90, label %91

90:                                               ; preds = %83, %3
  call void @abort() #4
  unreachable

91:                                               ; preds = %83
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = call i32 @foobar(i32 noundef 1, i32 noundef 2, i32 noundef 3)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
