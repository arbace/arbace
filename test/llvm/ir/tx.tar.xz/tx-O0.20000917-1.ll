; ModuleID = '20000917-1.c'
source_filename = "20000917-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.int3 = type { i32, i32, i32 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i32 } @one() #0 {
  %1 = alloca %struct.int3, align 4
  %2 = alloca { i64, i32 }, align 8
  %3 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 0
  store i32 1, ptr %3, align 4
  %4 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 1
  store i32 1, ptr %4, align 4
  %5 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 2
  store i32 1, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 4 %1, i64 12, i1 false)
  %6 = load { i64, i32 }, ptr %2, align 8
  ret { i64, i32 } %6
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i32 } @zero() #0 {
  %1 = alloca %struct.int3, align 4
  %2 = alloca { i64, i32 }, align 8
  %3 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 0
  store i32 0, ptr %3, align 4
  %4 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 1
  store i32 0, ptr %4, align 4
  %5 = getelementptr inbounds nuw %struct.int3, ptr %1, i32 0, i32 2
  store i32 0, ptr %5, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 4 %1, i64 12, i1 false)
  %6 = load { i64, i32 }, ptr %2, align 8
  ret { i64, i32 } %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.int3, align 4
  %3 = alloca ptr, align 8
  %4 = alloca %struct.int3, align 4
  %5 = alloca { i64, i32 }, align 8
  %6 = alloca ptr, align 8
  %7 = alloca %struct.int3, align 4
  %8 = alloca { i64, i32 }, align 8
  store i32 0, ptr %1, align 4
  %9 = call { i64, i32 } @one()
  store { i64, i32 } %9, ptr %5, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 8 %5, i64 12, i1 false)
  store ptr %2, ptr %6, align 8
  %10 = load ptr, ptr %6, align 8
  store ptr %10, ptr %3, align 8
  %11 = load ptr, ptr %3, align 8
  %12 = call { i64, i32 } @zero()
  store { i64, i32 } %12, ptr %8, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 8 %8, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %7, i64 12, i1 false)
  %13 = getelementptr inbounds nuw %struct.int3, ptr %2, i32 0, i32 0
  %14 = load i32, ptr %13, align 4
  %15 = icmp ne i32 %14, 0
  br i1 %15, label %16, label %25

16:                                               ; preds = %0
  %17 = getelementptr inbounds nuw %struct.int3, ptr %2, i32 0, i32 1
  %18 = load i32, ptr %17, align 4
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %20, label %25

20:                                               ; preds = %16
  %21 = getelementptr inbounds nuw %struct.int3, ptr %2, i32 0, i32 2
  %22 = load i32, ptr %21, align 4
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %24, label %25

24:                                               ; preds = %20
  call void @abort() #4
  unreachable

25:                                               ; preds = %20, %16, %0
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
