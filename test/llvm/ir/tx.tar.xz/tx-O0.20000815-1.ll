; ModuleID = '20000815-1.c'
source_filename = "20000815-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.table_elt = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i8, i8, i8, i8 }
%struct.write_data = type { i8, [3 x i8] }

@table = internal global [32 x ptr] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @invalidate_memory(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = load i8, ptr %8, align 4
  %10 = shl i8 %9, 4
  %11 = ashr i8 %10, 7
  %12 = sext i8 %11 to i32
  store i32 %12, ptr %6, align 4
  %13 = load ptr, ptr %2, align 8
  %14 = load i8, ptr %13, align 4
  %15 = shl i8 %14, 5
  %16 = ashr i8 %15, 7
  %17 = sext i8 %16 to i32
  store i32 %17, ptr %7, align 4
  store i32 0, ptr %3, align 4
  br label %18

18:                                               ; preds = %63, %1
  %19 = load i32, ptr %3, align 4
  %20 = icmp slt i32 %19, 31
  br i1 %20, label %21, label %66

21:                                               ; preds = %18
  %22 = load i32, ptr %3, align 4
  %23 = sext i32 %22 to i64
  %24 = getelementptr inbounds [32 x ptr], ptr @table, i64 0, i64 %23
  %25 = load ptr, ptr %24, align 8
  store ptr %25, ptr %4, align 8
  br label %26

26:                                               ; preds = %60, %21
  %27 = load ptr, ptr %4, align 8
  %28 = icmp ne ptr %27, null
  br i1 %28, label %29, label %62

29:                                               ; preds = %26
  %30 = load ptr, ptr %4, align 8
  %31 = getelementptr inbounds nuw %struct.table_elt, ptr %30, i32 0, i32 1
  %32 = load ptr, ptr %31, align 8
  store ptr %32, ptr %5, align 8
  %33 = load ptr, ptr %4, align 8
  %34 = getelementptr inbounds nuw %struct.table_elt, ptr %33, i32 0, i32 9
  %35 = load i8, ptr %34, align 8
  %36 = sext i8 %35 to i32
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %38, label %59

38:                                               ; preds = %29
  %39 = load i32, ptr %6, align 4
  %40 = icmp ne i32 %39, 0
  br i1 %40, label %56, label %41

41:                                               ; preds = %38
  %42 = load i32, ptr %7, align 4
  %43 = icmp ne i32 %42, 0
  br i1 %43, label %44, label %50

44:                                               ; preds = %41
  %45 = load ptr, ptr %4, align 8
  %46 = getelementptr inbounds nuw %struct.table_elt, ptr %45, i32 0, i32 10
  %47 = load i8, ptr %46, align 1
  %48 = sext i8 %47 to i32
  %49 = icmp ne i32 %48, 0
  br i1 %49, label %56, label %50

50:                                               ; preds = %44, %41
  %51 = load ptr, ptr %4, align 8
  %52 = getelementptr inbounds nuw %struct.table_elt, ptr %51, i32 0, i32 0
  %53 = load ptr, ptr %52, align 8
  %54 = call i32 @cse_rtx_addr_varies_p(ptr noundef %53)
  %55 = icmp ne i32 %54, 0
  br i1 %55, label %56, label %59

56:                                               ; preds = %50, %44, %38
  %57 = load ptr, ptr %4, align 8
  %58 = load i32, ptr %3, align 4
  call void @remove_from_table(ptr noundef %57, i32 noundef %58)
  br label %59

59:                                               ; preds = %56, %50, %29
  br label %60

60:                                               ; preds = %59
  %61 = load ptr, ptr %5, align 8
  store ptr %61, ptr %4, align 8
  br label %26, !llvm.loop !6

62:                                               ; preds = %26
  br label %63

63:                                               ; preds = %62
  %64 = load i32, ptr %3, align 4
  %65 = add nsw i32 %64, 1
  store i32 %65, ptr %3, align 4
  br label %18, !llvm.loop !8

66:                                               ; preds = %18
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @cse_rtx_addr_varies_p(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @remove_from_table(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  call void @abort() #3
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.write_data, align 4
  %3 = alloca %struct.table_elt, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %3, i8 0, i64 72, i1 false)
  %4 = getelementptr inbounds nuw %struct.table_elt, ptr %3, i32 0, i32 9
  store i8 1, ptr %4, align 8
  store ptr %3, ptr @table, align 16
  call void @llvm.memset.p0.i64(ptr align 4 %2, i8 0, i64 4, i1 false)
  %5 = load i8, ptr %2, align 4
  %6 = and i8 %5, -3
  %7 = or i8 %6, 2
  store i8 %7, ptr %2, align 4
  %8 = load i8, ptr %2, align 4
  %9 = and i8 %8, -5
  %10 = or i8 %9, 4
  store i8 %10, ptr %2, align 4
  call void @invalidate_memory(ptr noundef %2)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
