; ModuleID = '20131127-1.c'
source_filename = "20131127-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S0 = type <{ i32, i32, i32, i16 }>

@a = dso_local global i16 1, align 2
@b = dso_local global %struct.S0 <{ i32 1, i32 0, i32 0, i16 0 }>, align 1
@c = dso_local global %struct.S0 zeroinitializer, align 1
@d = dso_local global %struct.S0 zeroinitializer, align 1
@e = dso_local global %struct.S0 zeroinitializer, align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i48 } @fn1() #0 {
  %1 = alloca %struct.S0, align 1
  %2 = alloca { i64, i48 }, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 @c, i64 14, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 1 %1, i64 14, i1 false)
  %3 = load { i64, i48 }, ptr %2, align 8
  ret { i64, i48 } %3
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @fn2() #0 {
  %1 = alloca %struct.S0, align 1
  %2 = alloca { i64, i48 }, align 8
  %3 = call { i64, i48 } @fn1()
  store { i64, i48 } %3, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 8 %2, i64 14, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 @b, ptr align 1 %1, i64 14, i1 false)
  store i16 0, ptr @a, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 @d, ptr align 1 @e, i64 14, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @fn2()
  %2 = load i16, ptr @a, align 2
  %3 = sext i16 %2 to i32
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %0
  call void @abort() #3
  unreachable

6:                                                ; preds = %0
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
