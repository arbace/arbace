; ModuleID = '20071120-1.c'
source_filename = "20071120-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.ggc_root_tab = type { ptr }
%struct.VEC_deferred_access_gc = type { %struct.VEC_deferred_access_base }
%struct.VEC_deferred_access_base = type { i32, [1 x %struct.deferred_access] }
%struct.deferred_access = type { ptr, i32 }

@deferred_access_no_check = internal global i32 0, align 4
@gt_pch_rs_gt_cp_semantics_h = dso_local constant [1 x %struct.ggc_root_tab] [%struct.ggc_root_tab { ptr @deferred_access_no_check }], align 8
@deferred_access_stack = internal global ptr null, align 8

; Function Attrs: noinline noreturn nounwind optnone sspstrong uwtable
define dso_local void @vec_assert_fail() #0 {
  call void @abort() #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @perform_access_checks(ptr noundef %0) #2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void @abort() #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @pop_to_parent_deferring_access_checks() #2 {
  %1 = alloca ptr, align 8
  %2 = alloca ptr, align 8
  %3 = load i32, ptr @deferred_access_no_check, align 4
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %5, label %8

5:                                                ; preds = %0
  %6 = load i32, ptr @deferred_access_no_check, align 4
  %7 = add i32 %6, -1
  store i32 %7, ptr @deferred_access_no_check, align 4
  br label %44

8:                                                ; preds = %0
  %9 = load ptr, ptr @deferred_access_stack, align 8
  %10 = icmp ne ptr %9, null
  br i1 %10, label %11, label %14

11:                                               ; preds = %8
  %12 = load ptr, ptr @deferred_access_stack, align 8
  %13 = getelementptr inbounds nuw %struct.VEC_deferred_access_gc, ptr %12, i32 0, i32 0
  br label %15

14:                                               ; preds = %8
  br label %15

15:                                               ; preds = %14, %11
  %16 = phi ptr [ %13, %11 ], [ null, %14 ]
  %17 = call ptr @VEC_deferred_access_base_last(ptr noundef %16)
  %18 = getelementptr inbounds nuw %struct.deferred_access, ptr %17, i32 0, i32 0
  %19 = load ptr, ptr %18, align 8
  store ptr %19, ptr %1, align 8
  %20 = load ptr, ptr @deferred_access_stack, align 8
  %21 = icmp ne ptr %20, null
  br i1 %21, label %22, label %25

22:                                               ; preds = %15
  %23 = load ptr, ptr @deferred_access_stack, align 8
  %24 = getelementptr inbounds nuw %struct.VEC_deferred_access_gc, ptr %23, i32 0, i32 0
  br label %26

25:                                               ; preds = %15
  br label %26

26:                                               ; preds = %25, %22
  %27 = phi ptr [ %24, %22 ], [ null, %25 ]
  call void @VEC_deferred_access_base_pop(ptr noundef %27)
  %28 = load ptr, ptr @deferred_access_stack, align 8
  %29 = icmp ne ptr %28, null
  br i1 %29, label %30, label %33

30:                                               ; preds = %26
  %31 = load ptr, ptr @deferred_access_stack, align 8
  %32 = getelementptr inbounds nuw %struct.VEC_deferred_access_gc, ptr %31, i32 0, i32 0
  br label %34

33:                                               ; preds = %26
  br label %34

34:                                               ; preds = %33, %30
  %35 = phi ptr [ %32, %30 ], [ null, %33 ]
  %36 = call ptr @VEC_deferred_access_base_last(ptr noundef %35)
  store ptr %36, ptr %2, align 8
  %37 = load ptr, ptr %2, align 8
  %38 = getelementptr inbounds nuw %struct.deferred_access, ptr %37, i32 0, i32 1
  %39 = load i32, ptr %38, align 8
  %40 = icmp eq i32 %39, 0
  br i1 %40, label %41, label %43

41:                                               ; preds = %34
  %42 = load ptr, ptr %1, align 8
  call void @perform_access_checks(ptr noundef %42)
  br label %43

43:                                               ; preds = %41, %34
  br label %44

44:                                               ; preds = %43, %5
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @VEC_deferred_access_base_last(ptr noundef %0) #2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %11

5:                                                ; preds = %1
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %6, i32 0, i32 0
  %8 = load i32, ptr %7, align 8
  %9 = icmp ne i32 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %5
  br label %13

11:                                               ; preds = %5, %1
  call void @vec_assert_fail() #5
  unreachable

12:                                               ; No predecessors!
  br label %13

13:                                               ; preds = %12, %10
  %14 = phi i32 [ 0, %10 ], [ 0, %12 ]
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %15, i32 0, i32 1
  %17 = load ptr, ptr %2, align 8
  %18 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %17, i32 0, i32 0
  %19 = load i32, ptr %18, align 8
  %20 = sub i32 %19, 1
  %21 = zext i32 %20 to i64
  %22 = getelementptr inbounds nuw [1 x %struct.deferred_access], ptr %16, i64 0, i64 %21
  ret ptr %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @VEC_deferred_access_base_pop(ptr noundef %0) #2 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %3, i32 0, i32 0
  %5 = load i32, ptr %4, align 8
  %6 = icmp ne i32 %5, 0
  br i1 %6, label %7, label %8

7:                                                ; preds = %1
  br label %10

8:                                                ; preds = %1
  call void @vec_assert_fail() #5
  unreachable

9:                                                ; No predecessors!
  br label %10

10:                                               ; preds = %9, %7
  %11 = phi i32 [ 0, %7 ], [ 0, %9 ]
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %12, i32 0, i32 0
  %14 = load i32, ptr %13, align 8
  %15 = add i32 %14, -1
  store i32 %15, ptr %13, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #2 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call ptr @malloc(i64 noundef 152) #6
  store ptr %2, ptr @deferred_access_stack, align 8
  %3 = load ptr, ptr @deferred_access_stack, align 8
  %4 = getelementptr inbounds nuw %struct.VEC_deferred_access_gc, ptr %3, i32 0, i32 0
  %5 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %4, i32 0, i32 0
  store i32 2, ptr %5, align 8
  %6 = load ptr, ptr @deferred_access_stack, align 8
  %7 = getelementptr inbounds nuw %struct.VEC_deferred_access_gc, ptr %6, i32 0, i32 0
  %8 = getelementptr inbounds nuw %struct.VEC_deferred_access_base, ptr %7, i32 0, i32 1
  %9 = getelementptr inbounds [1 x %struct.deferred_access], ptr %8, i64 0, i64 0
  %10 = getelementptr inbounds nuw %struct.deferred_access, ptr %9, i32 0, i32 1
  store i32 1, ptr %10, align 8
  call void @pop_to_parent_deferring_access_checks()
  ret i32 0
}

; Function Attrs: nounwind
declare ptr @malloc(i64 noundef) #3

attributes #0 = { noinline noreturn nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
