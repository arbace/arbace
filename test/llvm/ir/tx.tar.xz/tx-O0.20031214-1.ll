; ModuleID = '20031214-1.c'
source_filename = "20031214-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.anon = type { double, [2 x i32] }

@g = dso_local global %struct.anon { double 0.000000e+00, [2 x i32] [i32 1, i32 2] }, align 8
@k = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @b(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  br label %3

3:                                                ; preds = %22, %0
  %4 = load i32, ptr %2, align 4
  %5 = icmp slt i32 %4, 2
  br i1 %5, label %6, label %25

6:                                                ; preds = %3
  %7 = load i32, ptr @k, align 4
  %8 = load i32, ptr %2, align 4
  %9 = sext i32 %8 to i64
  %10 = getelementptr inbounds [2 x i32], ptr getelementptr inbounds nuw (i8, ptr @g, i64 8), i64 0, i64 %9
  %11 = load i32, ptr %10, align 4
  %12 = icmp sgt i32 %7, %11
  br i1 %12, label %13, label %15

13:                                               ; preds = %6
  %14 = load i32, ptr @k, align 4
  br label %20

15:                                               ; preds = %6
  %16 = load i32, ptr %2, align 4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds [2 x i32], ptr getelementptr inbounds nuw (i8, ptr @g, i64 8), i64 0, i64 %17
  %19 = load i32, ptr %18, align 4
  br label %20

20:                                               ; preds = %15, %13
  %21 = phi i32 [ %14, %13 ], [ %19, %15 ]
  store i32 %21, ptr @k, align 4
  br label %22

22:                                               ; preds = %20
  %23 = load i32, ptr %2, align 4
  %24 = add nsw i32 %23, 1
  store i32 %24, ptr %2, align 4
  br label %3, !llvm.loop !6

25:                                               ; preds = %3
  %26 = load i32, ptr @k, align 4
  %27 = add nsw i32 %26, 1
  store i32 %27, ptr @k, align 4
  call void @b(ptr noundef %2)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
