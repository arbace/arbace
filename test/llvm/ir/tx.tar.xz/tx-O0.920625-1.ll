; ModuleID = '920625-1.c'
source_filename = "920625-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.point = type { double, double }
%struct.ipoint = type { i32, i32 }
%struct.__va_list_tag = type { i32, i32, ptr, ptr }

@pts = dso_local global [4 x %struct.point] [%struct.point { double 1.000000e+00, double 2.000000e+00 }, %struct.point { double 3.000000e+00, double 4.000000e+00 }, %struct.point { double 5.000000e+00, double 6.000000e+00 }, %struct.point { double 7.000000e+00, double 8.000000e+00 }], align 16
@ipts = dso_local global [4 x %struct.ipoint] [%struct.ipoint { i32 1, i32 2 }, %struct.ipoint { i32 3, i32 4 }, %struct.ipoint { i32 5, i32 6 }, %struct.ipoint { i32 7, i32 8 }], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load double, ptr @pts, align 16
  %3 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 8), align 8
  %4 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 16), align 16
  %5 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 24), align 8
  %6 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 32), align 16
  %7 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 40), align 8
  %8 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 48), align 16
  %9 = load double, ptr getelementptr inbounds nuw (i8, ptr @pts, i64 56), align 8
  %10 = call i32 (i32, ...) @va1(i32 noundef 4, double %2, double %3, double %4, double %5, double %6, double %7, double %8, double %9)
  %11 = load i64, ptr @ipts, align 16
  %12 = load i64, ptr getelementptr inbounds nuw (i8, ptr @ipts, i64 8), align 8
  %13 = load i64, ptr getelementptr inbounds nuw (i8, ptr @ipts, i64 16), align 16
  %14 = load i64, ptr getelementptr inbounds nuw (i8, ptr @ipts, i64 24), align 8
  %15 = call i32 (i32, ...) @va2(i32 noundef 4, i64 %11, i64 %12, i64 %13, i64 %14)
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @va1(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  %5 = alloca i32, align 4
  %6 = alloca %struct.point, align 8
  %7 = alloca %struct.point, align 8
  store i32 %0, ptr %3, align 4
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_start.p0(ptr %8)
  store i32 0, ptr %5, align 4
  br label %9

9:                                                ; preds = %53, %1
  %10 = load i32, ptr %5, align 4
  %11 = load i32, ptr %3, align 4
  %12 = icmp slt i32 %10, %11
  br i1 %12, label %13, label %56

13:                                               ; preds = %9
  %14 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  %15 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %14, i32 0, i32 1
  %16 = load i32, ptr %15, align 4
  %17 = icmp ule i32 %16, 144
  br i1 %17, label %18, label %28

18:                                               ; preds = %13
  %19 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %14, i32 0, i32 3
  %20 = load ptr, ptr %19, align 16
  %21 = getelementptr i8, ptr %20, i32 %16
  %22 = getelementptr inbounds i8, ptr %21, i64 16
  %23 = load double, ptr %21, align 16
  %24 = getelementptr inbounds nuw { double, double }, ptr %7, i32 0, i32 0
  store double %23, ptr %24, align 8
  %25 = load double, ptr %22, align 16
  %26 = getelementptr inbounds nuw { double, double }, ptr %7, i32 0, i32 1
  store double %25, ptr %26, align 8
  %27 = add i32 %16, 32
  store i32 %27, ptr %15, align 4
  br label %32

28:                                               ; preds = %13
  %29 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %14, i32 0, i32 2
  %30 = load ptr, ptr %29, align 8
  %31 = getelementptr i8, ptr %30, i32 16
  store ptr %31, ptr %29, align 8
  br label %32

32:                                               ; preds = %28, %18
  %33 = phi ptr [ %7, %18 ], [ %30, %28 ]
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %33, i64 16, i1 false)
  %34 = load i32, ptr %5, align 4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds [4 x %struct.point], ptr @pts, i64 0, i64 %35
  %37 = getelementptr inbounds nuw %struct.point, ptr %36, i32 0, i32 0
  %38 = load double, ptr %37, align 16
  %39 = getelementptr inbounds nuw %struct.point, ptr %6, i32 0, i32 0
  %40 = load double, ptr %39, align 8
  %41 = fcmp une double %38, %40
  br i1 %41, label %51, label %42

42:                                               ; preds = %32
  %43 = load i32, ptr %5, align 4
  %44 = sext i32 %43 to i64
  %45 = getelementptr inbounds [4 x %struct.point], ptr @pts, i64 0, i64 %44
  %46 = getelementptr inbounds nuw %struct.point, ptr %45, i32 0, i32 1
  %47 = load double, ptr %46, align 8
  %48 = getelementptr inbounds nuw %struct.point, ptr %6, i32 0, i32 1
  %49 = load double, ptr %48, align 8
  %50 = fcmp une double %47, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %42, %32
  call void @abort() #6
  unreachable

52:                                               ; preds = %42
  br label %53

53:                                               ; preds = %52
  %54 = load i32, ptr %5, align 4
  %55 = add nsw i32 %54, 1
  store i32 %55, ptr %5, align 4
  br label %9, !llvm.loop !6

56:                                               ; preds = %9
  %57 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_end.p0(ptr %57)
  %58 = load i32, ptr %2, align 4
  ret i32 %58
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @va2(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  %5 = alloca i32, align 4
  %6 = alloca %struct.ipoint, align 4
  store i32 %0, ptr %3, align 4
  %7 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_start.p0(ptr %7)
  store i32 0, ptr %5, align 4
  br label %8

8:                                                ; preds = %47, %1
  %9 = load i32, ptr %5, align 4
  %10 = load i32, ptr %3, align 4
  %11 = icmp slt i32 %9, %10
  br i1 %11, label %12, label %50

12:                                               ; preds = %8
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  %14 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %13, i32 0, i32 0
  %15 = load i32, ptr %14, align 16
  %16 = icmp ule i32 %15, 40
  br i1 %16, label %17, label %22

17:                                               ; preds = %12
  %18 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %13, i32 0, i32 3
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %19, i32 %15
  %21 = add i32 %15, 8
  store i32 %21, ptr %14, align 16
  br label %26

22:                                               ; preds = %12
  %23 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %13, i32 0, i32 2
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i8, ptr %24, i32 8
  store ptr %25, ptr %23, align 8
  br label %26

26:                                               ; preds = %22, %17
  %27 = phi ptr [ %20, %17 ], [ %24, %22 ]
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 %27, i64 8, i1 false)
  %28 = load i32, ptr %5, align 4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds [4 x %struct.ipoint], ptr @ipts, i64 0, i64 %29
  %31 = getelementptr inbounds nuw %struct.ipoint, ptr %30, i32 0, i32 0
  %32 = load i32, ptr %31, align 8
  %33 = getelementptr inbounds nuw %struct.ipoint, ptr %6, i32 0, i32 0
  %34 = load i32, ptr %33, align 4
  %35 = icmp ne i32 %32, %34
  br i1 %35, label %45, label %36

36:                                               ; preds = %26
  %37 = load i32, ptr %5, align 4
  %38 = sext i32 %37 to i64
  %39 = getelementptr inbounds [4 x %struct.ipoint], ptr @ipts, i64 0, i64 %38
  %40 = getelementptr inbounds nuw %struct.ipoint, ptr %39, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr inbounds nuw %struct.ipoint, ptr %6, i32 0, i32 1
  %43 = load i32, ptr %42, align 4
  %44 = icmp ne i32 %41, %43
  br i1 %44, label %45, label %46

45:                                               ; preds = %36, %26
  call void @abort() #6
  unreachable

46:                                               ; preds = %36
  br label %47

47:                                               ; preds = %46
  %48 = load i32, ptr %5, align 4
  %49 = add nsw i32 %48, 1
  store i32 %49, ptr %5, align 4
  br label %8, !llvm.loop !8

50:                                               ; preds = %8
  %51 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_end.p0(ptr %51)
  %52 = load i32, ptr %2, align 4
  ret i32 %52
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; Function Attrs: noreturn nounwind
declare void @abort() #4

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn }
attributes #6 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
