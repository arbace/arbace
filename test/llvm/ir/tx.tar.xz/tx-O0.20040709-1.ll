; ModuleID = '20040709-1.c'
source_filename = "20040709-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i32 }
%struct.B = type { i32, i32 }
%struct.C = type { i32, i32 }
%struct.D = type { i64 }
%struct.E = type { i64, i64 }
%struct.F = type { i64, i64 }
%struct.G = type { i32, i64 }
%struct.H = type { i32, i64 }
%struct.I = type { i16, i64 }
%struct.J = type { i16, i16 }
%struct.K = type { i32 }
%struct.L = type { i32, i32 }
%struct.M = type { i32, i32 }
%struct.N = type { i64 }
%struct.O = type { i64, i64 }
%struct.P = type { i64, i64 }
%struct.Q = type { i32, i64 }
%struct.R = type { i32, i64 }
%struct.S = type { i16, i64 }
%struct.T = type { i16, i16 }
%struct.U = type { i16, i64 }
%struct.V = type { i16, i16 }
%struct.W = type { x86_fp80, i32 }
%struct.X = type { i32, x86_fp80 }
%struct.Y = type { i32, x86_fp80 }
%struct.Z = type { x86_fp80, i32 }

@myrnd.s = internal global i32 1388815473, align 4
@sA = dso_local global %struct.A zeroinitializer, align 4
@sB = dso_local global %struct.B zeroinitializer, align 4
@sC = dso_local global %struct.C zeroinitializer, align 4
@sD = dso_local global %struct.D zeroinitializer, align 8
@sE = dso_local global %struct.E zeroinitializer, align 8
@sF = dso_local global %struct.F zeroinitializer, align 8
@sG = dso_local global %struct.G zeroinitializer, align 8
@sH = dso_local global %struct.H zeroinitializer, align 8
@sI = dso_local global %struct.I zeroinitializer, align 8
@sJ = dso_local global %struct.J zeroinitializer, align 2
@sK = dso_local global %struct.K zeroinitializer, align 4
@sL = dso_local global %struct.L zeroinitializer, align 4
@sM = dso_local global %struct.M zeroinitializer, align 4
@sN = dso_local global %struct.N zeroinitializer, align 8
@sO = dso_local global %struct.O zeroinitializer, align 8
@sP = dso_local global %struct.P zeroinitializer, align 8
@sQ = dso_local global %struct.Q zeroinitializer, align 8
@sR = dso_local global %struct.R zeroinitializer, align 8
@sS = dso_local global %struct.S zeroinitializer, align 8
@sT = dso_local global %struct.T zeroinitializer, align 2
@sU = dso_local global %struct.U zeroinitializer, align 8
@sV = dso_local global %struct.V zeroinitializer, align 2
@sW = dso_local global %struct.W zeroinitializer, align 16
@sX = dso_local global %struct.X zeroinitializer, align 16
@sY = dso_local global %struct.Y zeroinitializer, align 16
@sZ = dso_local global %struct.Z zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @myrnd() #0 {
  %1 = load i32, ptr @myrnd.s, align 4
  %2 = mul i32 %1, 1103515245
  store i32 %2, ptr @myrnd.s, align 4
  %3 = load i32, ptr @myrnd.s, align 4
  %4 = add i32 %3, 12345
  store i32 %4, ptr @myrnd.s, align 4
  %5 = load i32, ptr @myrnd.s, align 4
  %6 = udiv i32 %5, 65536
  %7 = urem i32 %6, 2048
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retmeA(i32 %0) #0 {
  %2 = alloca %struct.A, align 4
  %3 = alloca %struct.A, align 4
  %4 = getelementptr inbounds nuw %struct.A, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 4, i1 false)
  %5 = getelementptr inbounds nuw %struct.A, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1A(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.A, align 4
  %4 = alloca %struct.A, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sA, i64 4, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 4
  %7 = lshr i32 %6, 17
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 4
  %10 = and i32 %8, 32767
  %11 = shl i32 %10, 17
  %12 = and i32 %9, 131071
  %13 = or i32 %12, %11
  store i32 %13, ptr %3, align 4
  %14 = getelementptr inbounds nuw %struct.A, ptr %3, i32 0, i32 0
  %15 = load i32, ptr %14, align 4
  %16 = call i32 @retmeA(i32 %15)
  %17 = getelementptr inbounds nuw %struct.A, ptr %4, i32 0, i32 0
  store i32 %16, ptr %17, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 4, i1 false)
  %18 = load i32, ptr %3, align 4
  %19 = lshr i32 %18, 17
  ret i32 %19
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2A(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.A, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sA, i64 4, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 4
  %6 = lshr i32 %5, 17
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 4
  %9 = and i32 %7, 32767
  %10 = shl i32 %9, 17
  %11 = and i32 %8, 131071
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 4
  %13 = load i32, ptr %3, align 4
  %14 = lshr i32 %13, 17
  %15 = srem i32 %14, 15
  %16 = load i32, ptr %3, align 4
  %17 = and i32 %15, 32767
  %18 = shl i32 %17, 17
  %19 = and i32 %16, 131071
  %20 = or i32 %19, %18
  store i32 %20, ptr %3, align 4
  %21 = load i32, ptr %3, align 4
  %22 = lshr i32 %21, 17
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitA() #0 {
  %1 = load i32, ptr @sA, align 4
  %2 = lshr i32 %1, 17
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3A(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sA, align 4
  %5 = lshr i32 %4, 17
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sA, align 4
  %8 = and i32 %6, 32767
  %9 = shl i32 %8, 17
  %10 = and i32 %7, 131071
  %11 = or i32 %10, %9
  store i32 %11, ptr @sA, align 4
  %12 = call i32 @retitA()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testA() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.A, align 4
  %7 = alloca ptr, align 8
  store ptr @sA, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 4
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !6

20:                                               ; preds = %8
  %21 = load i32, ptr @sA, align 4
  %22 = and i32 %21, 131071
  %23 = or i32 %22, -131072
  store i32 %23, ptr @sA, align 4
  %24 = load i32, ptr @sA, align 4
  %25 = lshr i32 %24, 17
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sA, align 4
  %30 = and i32 %28, 32767
  %31 = shl i32 %30, 17
  %32 = and i32 %29, 131071
  %33 = or i32 %32, %31
  store i32 %33, ptr @sA, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sA, i64 4, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1A(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = load i32, ptr %6, align 4
  %37 = and i32 %36, 63
  %38 = load i32, ptr @sA, align 4
  %39 = and i32 %38, 63
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %71, label %41

41:                                               ; preds = %20
  %42 = load i32, ptr %6, align 4
  %43 = lshr i32 %42, 7
  %44 = and i32 %43, 1023
  %45 = load i32, ptr @sA, align 4
  %46 = lshr i32 %45, 7
  %47 = and i32 %46, 1023
  %48 = icmp ne i32 %44, %47
  br i1 %48, label %71, label %49

49:                                               ; preds = %41
  %50 = load i32, ptr %6, align 4
  %51 = lshr i32 %50, 17
  %52 = load i32, ptr @sA, align 4
  %53 = lshr i32 %52, 17
  %54 = icmp ne i32 %51, %53
  br i1 %54, label %71, label %55

55:                                               ; preds = %49
  %56 = load i32, ptr %6, align 4
  %57 = lshr i32 %56, 6
  %58 = and i32 %57, 1
  %59 = load i32, ptr @sA, align 4
  %60 = lshr i32 %59, 6
  %61 = and i32 %60, 1
  %62 = icmp ne i32 %58, %61
  br i1 %62, label %71, label %63

63:                                               ; preds = %55
  %64 = load i32, ptr %3, align 4
  %65 = load i32, ptr %4, align 4
  %66 = add i32 %64, %65
  %67 = load i32, ptr %2, align 4
  %68 = and i32 %66, %67
  %69 = load i32, ptr %5, align 4
  %70 = icmp ne i32 %68, %69
  br i1 %70, label %71, label %72

71:                                               ; preds = %63, %55, %49, %41, %20
  call void @abort() #4
  unreachable

72:                                               ; preds = %63
  %73 = call i32 @myrnd()
  store i32 %73, ptr %3, align 4
  %74 = call i32 @myrnd()
  store i32 %74, ptr %4, align 4
  %75 = load i32, ptr %3, align 4
  %76 = load i32, ptr @sA, align 4
  %77 = and i32 %75, 32767
  %78 = shl i32 %77, 17
  %79 = and i32 %76, 131071
  %80 = or i32 %79, %78
  store i32 %80, ptr @sA, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sA, i64 4, i1 false)
  %81 = load i32, ptr %4, align 4
  %82 = call i32 @fn2A(i32 noundef %81)
  store i32 %82, ptr %5, align 4
  %83 = load i32, ptr %6, align 4
  %84 = and i32 %83, 63
  %85 = load i32, ptr @sA, align 4
  %86 = and i32 %85, 63
  %87 = icmp ne i32 %84, %86
  br i1 %87, label %121, label %88

88:                                               ; preds = %72
  %89 = load i32, ptr %6, align 4
  %90 = lshr i32 %89, 7
  %91 = and i32 %90, 1023
  %92 = load i32, ptr @sA, align 4
  %93 = lshr i32 %92, 7
  %94 = and i32 %93, 1023
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %121, label %96

96:                                               ; preds = %88
  %97 = load i32, ptr %6, align 4
  %98 = lshr i32 %97, 17
  %99 = load i32, ptr @sA, align 4
  %100 = lshr i32 %99, 17
  %101 = icmp ne i32 %98, %100
  br i1 %101, label %121, label %102

102:                                              ; preds = %96
  %103 = load i32, ptr %6, align 4
  %104 = lshr i32 %103, 6
  %105 = and i32 %104, 1
  %106 = load i32, ptr @sA, align 4
  %107 = lshr i32 %106, 6
  %108 = and i32 %107, 1
  %109 = icmp ne i32 %105, %108
  br i1 %109, label %121, label %110

110:                                              ; preds = %102
  %111 = load i32, ptr %3, align 4
  %112 = load i32, ptr %4, align 4
  %113 = add i32 %111, %112
  %114 = load i32, ptr %2, align 4
  %115 = and i32 %113, %114
  %116 = urem i32 %115, 15
  %117 = load i32, ptr %2, align 4
  %118 = and i32 %116, %117
  %119 = load i32, ptr %5, align 4
  %120 = icmp ne i32 %118, %119
  br i1 %120, label %121, label %122

121:                                              ; preds = %110, %102, %96, %88, %72
  call void @abort() #4
  unreachable

122:                                              ; preds = %110
  %123 = call i32 @myrnd()
  store i32 %123, ptr %3, align 4
  %124 = call i32 @myrnd()
  store i32 %124, ptr %4, align 4
  %125 = load i32, ptr %3, align 4
  %126 = load i32, ptr @sA, align 4
  %127 = and i32 %125, 32767
  %128 = shl i32 %127, 17
  %129 = and i32 %126, 131071
  %130 = or i32 %129, %128
  store i32 %130, ptr @sA, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sA, i64 4, i1 false)
  %131 = load i32, ptr %4, align 4
  %132 = call i32 @fn3A(i32 noundef %131)
  store i32 %132, ptr %5, align 4
  %133 = load i32, ptr %6, align 4
  %134 = and i32 %133, 63
  %135 = load i32, ptr @sA, align 4
  %136 = and i32 %135, 63
  %137 = icmp ne i32 %134, %136
  br i1 %137, label %167, label %138

138:                                              ; preds = %122
  %139 = load i32, ptr %6, align 4
  %140 = lshr i32 %139, 7
  %141 = and i32 %140, 1023
  %142 = load i32, ptr @sA, align 4
  %143 = lshr i32 %142, 7
  %144 = and i32 %143, 1023
  %145 = icmp ne i32 %141, %144
  br i1 %145, label %167, label %146

146:                                              ; preds = %138
  %147 = load i32, ptr @sA, align 4
  %148 = lshr i32 %147, 17
  %149 = load i32, ptr %5, align 4
  %150 = icmp ne i32 %148, %149
  br i1 %150, label %167, label %151

151:                                              ; preds = %146
  %152 = load i32, ptr %6, align 4
  %153 = lshr i32 %152, 6
  %154 = and i32 %153, 1
  %155 = load i32, ptr @sA, align 4
  %156 = lshr i32 %155, 6
  %157 = and i32 %156, 1
  %158 = icmp ne i32 %154, %157
  br i1 %158, label %167, label %159

159:                                              ; preds = %151
  %160 = load i32, ptr %3, align 4
  %161 = load i32, ptr %4, align 4
  %162 = add i32 %160, %161
  %163 = load i32, ptr %2, align 4
  %164 = and i32 %162, %163
  %165 = load i32, ptr %5, align 4
  %166 = icmp ne i32 %164, %165
  br i1 %166, label %167, label %168

167:                                              ; preds = %159, %151, %146, %138, %122
  call void @abort() #4
  unreachable

168:                                              ; preds = %159
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeB(i64 %0) #0 {
  %2 = alloca %struct.B, align 4
  %3 = alloca %struct.B, align 4
  store i64 %0, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 8, i1 false)
  %4 = load i64, ptr %2, align 4
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1B(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.B, align 4
  %4 = alloca %struct.B, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sB, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 4
  %7 = lshr i32 %6, 17
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 4
  %10 = and i32 %8, 32767
  %11 = shl i32 %10, 17
  %12 = and i32 %9, 131071
  %13 = or i32 %12, %11
  store i32 %13, ptr %3, align 4
  %14 = load i64, ptr %3, align 4
  %15 = call i64 @retmeB(i64 %14)
  store i64 %15, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 8, i1 false)
  %16 = load i32, ptr %3, align 4
  %17 = lshr i32 %16, 17
  ret i32 %17
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2B(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.B, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sB, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 4
  %6 = lshr i32 %5, 17
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 4
  %9 = and i32 %7, 32767
  %10 = shl i32 %9, 17
  %11 = and i32 %8, 131071
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 4
  %13 = load i32, ptr %3, align 4
  %14 = lshr i32 %13, 17
  %15 = srem i32 %14, 15
  %16 = load i32, ptr %3, align 4
  %17 = and i32 %15, 32767
  %18 = shl i32 %17, 17
  %19 = and i32 %16, 131071
  %20 = or i32 %19, %18
  store i32 %20, ptr %3, align 4
  %21 = load i32, ptr %3, align 4
  %22 = lshr i32 %21, 17
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitB() #0 {
  %1 = load i32, ptr @sB, align 4
  %2 = lshr i32 %1, 17
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3B(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sB, align 4
  %5 = lshr i32 %4, 17
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sB, align 4
  %8 = and i32 %6, 32767
  %9 = shl i32 %8, 17
  %10 = and i32 %7, 131071
  %11 = or i32 %10, %9
  store i32 %11, ptr @sB, align 4
  %12 = call i32 @retitB()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testB() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.B, align 4
  %7 = alloca ptr, align 8
  store ptr @sB, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !8

20:                                               ; preds = %8
  %21 = load i32, ptr @sB, align 4
  %22 = and i32 %21, 131071
  %23 = or i32 %22, -131072
  store i32 %23, ptr @sB, align 4
  %24 = load i32, ptr @sB, align 4
  %25 = lshr i32 %24, 17
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sB, align 4
  %30 = and i32 %28, 32767
  %31 = shl i32 %30, 17
  %32 = and i32 %29, 131071
  %33 = or i32 %32, %31
  store i32 %33, ptr @sB, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sB, i64 8, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1B(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = load i32, ptr %6, align 4
  %37 = and i32 %36, 63
  %38 = load i32, ptr @sB, align 4
  %39 = and i32 %38, 63
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %68, label %41

41:                                               ; preds = %20
  %42 = load i32, ptr %6, align 4
  %43 = lshr i32 %42, 6
  %44 = and i32 %43, 2047
  %45 = load i32, ptr @sB, align 4
  %46 = lshr i32 %45, 6
  %47 = and i32 %46, 2047
  %48 = icmp ne i32 %44, %47
  br i1 %48, label %68, label %49

49:                                               ; preds = %41
  %50 = load i32, ptr %6, align 4
  %51 = lshr i32 %50, 17
  %52 = load i32, ptr @sB, align 4
  %53 = lshr i32 %52, 17
  %54 = icmp ne i32 %51, %53
  br i1 %54, label %68, label %55

55:                                               ; preds = %49
  %56 = getelementptr inbounds nuw %struct.B, ptr %6, i32 0, i32 1
  %57 = load i32, ptr %56, align 4
  %58 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sB, i64 4), align 4
  %59 = icmp ne i32 %57, %58
  br i1 %59, label %68, label %60

60:                                               ; preds = %55
  %61 = load i32, ptr %3, align 4
  %62 = load i32, ptr %4, align 4
  %63 = add i32 %61, %62
  %64 = load i32, ptr %2, align 4
  %65 = and i32 %63, %64
  %66 = load i32, ptr %5, align 4
  %67 = icmp ne i32 %65, %66
  br i1 %67, label %68, label %69

68:                                               ; preds = %60, %55, %49, %41, %20
  call void @abort() #4
  unreachable

69:                                               ; preds = %60
  %70 = call i32 @myrnd()
  store i32 %70, ptr %3, align 4
  %71 = call i32 @myrnd()
  store i32 %71, ptr %4, align 4
  %72 = load i32, ptr %3, align 4
  %73 = load i32, ptr @sB, align 4
  %74 = and i32 %72, 32767
  %75 = shl i32 %74, 17
  %76 = and i32 %73, 131071
  %77 = or i32 %76, %75
  store i32 %77, ptr @sB, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sB, i64 8, i1 false)
  %78 = load i32, ptr %4, align 4
  %79 = call i32 @fn2B(i32 noundef %78)
  store i32 %79, ptr %5, align 4
  %80 = load i32, ptr %6, align 4
  %81 = and i32 %80, 63
  %82 = load i32, ptr @sB, align 4
  %83 = and i32 %82, 63
  %84 = icmp ne i32 %81, %83
  br i1 %84, label %115, label %85

85:                                               ; preds = %69
  %86 = load i32, ptr %6, align 4
  %87 = lshr i32 %86, 6
  %88 = and i32 %87, 2047
  %89 = load i32, ptr @sB, align 4
  %90 = lshr i32 %89, 6
  %91 = and i32 %90, 2047
  %92 = icmp ne i32 %88, %91
  br i1 %92, label %115, label %93

93:                                               ; preds = %85
  %94 = load i32, ptr %6, align 4
  %95 = lshr i32 %94, 17
  %96 = load i32, ptr @sB, align 4
  %97 = lshr i32 %96, 17
  %98 = icmp ne i32 %95, %97
  br i1 %98, label %115, label %99

99:                                               ; preds = %93
  %100 = getelementptr inbounds nuw %struct.B, ptr %6, i32 0, i32 1
  %101 = load i32, ptr %100, align 4
  %102 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sB, i64 4), align 4
  %103 = icmp ne i32 %101, %102
  br i1 %103, label %115, label %104

104:                                              ; preds = %99
  %105 = load i32, ptr %3, align 4
  %106 = load i32, ptr %4, align 4
  %107 = add i32 %105, %106
  %108 = load i32, ptr %2, align 4
  %109 = and i32 %107, %108
  %110 = urem i32 %109, 15
  %111 = load i32, ptr %2, align 4
  %112 = and i32 %110, %111
  %113 = load i32, ptr %5, align 4
  %114 = icmp ne i32 %112, %113
  br i1 %114, label %115, label %116

115:                                              ; preds = %104, %99, %93, %85, %69
  call void @abort() #4
  unreachable

116:                                              ; preds = %104
  %117 = call i32 @myrnd()
  store i32 %117, ptr %3, align 4
  %118 = call i32 @myrnd()
  store i32 %118, ptr %4, align 4
  %119 = load i32, ptr %3, align 4
  %120 = load i32, ptr @sB, align 4
  %121 = and i32 %119, 32767
  %122 = shl i32 %121, 17
  %123 = and i32 %120, 131071
  %124 = or i32 %123, %122
  store i32 %124, ptr @sB, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sB, i64 8, i1 false)
  %125 = load i32, ptr %4, align 4
  %126 = call i32 @fn3B(i32 noundef %125)
  store i32 %126, ptr %5, align 4
  %127 = load i32, ptr %6, align 4
  %128 = and i32 %127, 63
  %129 = load i32, ptr @sB, align 4
  %130 = and i32 %129, 63
  %131 = icmp ne i32 %128, %130
  br i1 %131, label %158, label %132

132:                                              ; preds = %116
  %133 = load i32, ptr %6, align 4
  %134 = lshr i32 %133, 6
  %135 = and i32 %134, 2047
  %136 = load i32, ptr @sB, align 4
  %137 = lshr i32 %136, 6
  %138 = and i32 %137, 2047
  %139 = icmp ne i32 %135, %138
  br i1 %139, label %158, label %140

140:                                              ; preds = %132
  %141 = load i32, ptr @sB, align 4
  %142 = lshr i32 %141, 17
  %143 = load i32, ptr %5, align 4
  %144 = icmp ne i32 %142, %143
  br i1 %144, label %158, label %145

145:                                              ; preds = %140
  %146 = getelementptr inbounds nuw %struct.B, ptr %6, i32 0, i32 1
  %147 = load i32, ptr %146, align 4
  %148 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sB, i64 4), align 4
  %149 = icmp ne i32 %147, %148
  br i1 %149, label %158, label %150

150:                                              ; preds = %145
  %151 = load i32, ptr %3, align 4
  %152 = load i32, ptr %4, align 4
  %153 = add i32 %151, %152
  %154 = load i32, ptr %2, align 4
  %155 = and i32 %153, %154
  %156 = load i32, ptr %5, align 4
  %157 = icmp ne i32 %155, %156
  br i1 %157, label %158, label %159

158:                                              ; preds = %150, %145, %140, %132, %116
  call void @abort() #4
  unreachable

159:                                              ; preds = %150
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeC(i64 %0) #0 {
  %2 = alloca %struct.C, align 4
  %3 = alloca %struct.C, align 4
  store i64 %0, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 8, i1 false)
  %4 = load i64, ptr %2, align 4
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1C(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.C, align 4
  %4 = alloca %struct.C, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sC, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.C, ptr %3, i32 0, i32 1
  %7 = load i32, ptr %6, align 4
  %8 = lshr i32 %7, 17
  %9 = add i32 %8, %5
  %10 = load i32, ptr %6, align 4
  %11 = and i32 %9, 32767
  %12 = shl i32 %11, 17
  %13 = and i32 %10, 131071
  %14 = or i32 %13, %12
  store i32 %14, ptr %6, align 4
  %15 = load i64, ptr %3, align 4
  %16 = call i64 @retmeC(i64 %15)
  store i64 %16, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 8, i1 false)
  %17 = getelementptr inbounds nuw %struct.C, ptr %3, i32 0, i32 1
  %18 = load i32, ptr %17, align 4
  %19 = lshr i32 %18, 17
  ret i32 %19
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2C(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.C, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sC, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.C, ptr %3, i32 0, i32 1
  %6 = load i32, ptr %5, align 4
  %7 = lshr i32 %6, 17
  %8 = add i32 %7, %4
  %9 = load i32, ptr %5, align 4
  %10 = and i32 %8, 32767
  %11 = shl i32 %10, 17
  %12 = and i32 %9, 131071
  %13 = or i32 %12, %11
  store i32 %13, ptr %5, align 4
  %14 = getelementptr inbounds nuw %struct.C, ptr %3, i32 0, i32 1
  %15 = load i32, ptr %14, align 4
  %16 = lshr i32 %15, 17
  %17 = srem i32 %16, 15
  %18 = load i32, ptr %14, align 4
  %19 = and i32 %17, 32767
  %20 = shl i32 %19, 17
  %21 = and i32 %18, 131071
  %22 = or i32 %21, %20
  store i32 %22, ptr %14, align 4
  %23 = getelementptr inbounds nuw %struct.C, ptr %3, i32 0, i32 1
  %24 = load i32, ptr %23, align 4
  %25 = lshr i32 %24, 17
  ret i32 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitC() #0 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %2 = lshr i32 %1, 17
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3C(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %5 = lshr i32 %4, 17
  %6 = add i32 %5, %3
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %8 = and i32 %6, 32767
  %9 = shl i32 %8, 17
  %10 = and i32 %7, 131071
  %11 = or i32 %10, %9
  store i32 %11, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %12 = call i32 @retitC()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testC() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.C, align 4
  %7 = alloca ptr, align 8
  store ptr @sC, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !9

20:                                               ; preds = %8
  %21 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %22 = and i32 %21, 131071
  %23 = or i32 %22, -131072
  store i32 %23, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %25 = lshr i32 %24, 17
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %30 = and i32 %28, 32767
  %31 = shl i32 %30, 17
  %32 = and i32 %29, 131071
  %33 = or i32 %32, %31
  store i32 %33, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sC, i64 8, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1C(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %37 = load i32, ptr %36, align 4
  %38 = and i32 %37, 63
  %39 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %40 = and i32 %39, 63
  %41 = icmp ne i32 %38, %40
  br i1 %41, label %71, label %42

42:                                               ; preds = %20
  %43 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %44 = load i32, ptr %43, align 4
  %45 = lshr i32 %44, 6
  %46 = and i32 %45, 2047
  %47 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %48 = lshr i32 %47, 6
  %49 = and i32 %48, 2047
  %50 = icmp ne i32 %46, %49
  br i1 %50, label %71, label %51

51:                                               ; preds = %42
  %52 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = lshr i32 %53, 17
  %55 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %56 = lshr i32 %55, 17
  %57 = icmp ne i32 %54, %56
  br i1 %57, label %71, label %58

58:                                               ; preds = %51
  %59 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 0
  %60 = load i32, ptr %59, align 4
  %61 = load i32, ptr @sC, align 4
  %62 = icmp ne i32 %60, %61
  br i1 %62, label %71, label %63

63:                                               ; preds = %58
  %64 = load i32, ptr %3, align 4
  %65 = load i32, ptr %4, align 4
  %66 = add i32 %64, %65
  %67 = load i32, ptr %2, align 4
  %68 = and i32 %66, %67
  %69 = load i32, ptr %5, align 4
  %70 = icmp ne i32 %68, %69
  br i1 %70, label %71, label %72

71:                                               ; preds = %63, %58, %51, %42, %20
  call void @abort() #4
  unreachable

72:                                               ; preds = %63
  %73 = call i32 @myrnd()
  store i32 %73, ptr %3, align 4
  %74 = call i32 @myrnd()
  store i32 %74, ptr %4, align 4
  %75 = load i32, ptr %3, align 4
  %76 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %77 = and i32 %75, 32767
  %78 = shl i32 %77, 17
  %79 = and i32 %76, 131071
  %80 = or i32 %79, %78
  store i32 %80, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sC, i64 8, i1 false)
  %81 = load i32, ptr %4, align 4
  %82 = call i32 @fn2C(i32 noundef %81)
  store i32 %82, ptr %5, align 4
  %83 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %84 = load i32, ptr %83, align 4
  %85 = and i32 %84, 63
  %86 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %87 = and i32 %86, 63
  %88 = icmp ne i32 %85, %87
  br i1 %88, label %121, label %89

89:                                               ; preds = %72
  %90 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %91 = load i32, ptr %90, align 4
  %92 = lshr i32 %91, 6
  %93 = and i32 %92, 2047
  %94 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %95 = lshr i32 %94, 6
  %96 = and i32 %95, 2047
  %97 = icmp ne i32 %93, %96
  br i1 %97, label %121, label %98

98:                                               ; preds = %89
  %99 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %100 = load i32, ptr %99, align 4
  %101 = lshr i32 %100, 17
  %102 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %103 = lshr i32 %102, 17
  %104 = icmp ne i32 %101, %103
  br i1 %104, label %121, label %105

105:                                              ; preds = %98
  %106 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 0
  %107 = load i32, ptr %106, align 4
  %108 = load i32, ptr @sC, align 4
  %109 = icmp ne i32 %107, %108
  br i1 %109, label %121, label %110

110:                                              ; preds = %105
  %111 = load i32, ptr %3, align 4
  %112 = load i32, ptr %4, align 4
  %113 = add i32 %111, %112
  %114 = load i32, ptr %2, align 4
  %115 = and i32 %113, %114
  %116 = urem i32 %115, 15
  %117 = load i32, ptr %2, align 4
  %118 = and i32 %116, %117
  %119 = load i32, ptr %5, align 4
  %120 = icmp ne i32 %118, %119
  br i1 %120, label %121, label %122

121:                                              ; preds = %110, %105, %98, %89, %72
  call void @abort() #4
  unreachable

122:                                              ; preds = %110
  %123 = call i32 @myrnd()
  store i32 %123, ptr %3, align 4
  %124 = call i32 @myrnd()
  store i32 %124, ptr %4, align 4
  %125 = load i32, ptr %3, align 4
  %126 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %127 = and i32 %125, 32767
  %128 = shl i32 %127, 17
  %129 = and i32 %126, 131071
  %130 = or i32 %129, %128
  store i32 %130, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sC, i64 8, i1 false)
  %131 = load i32, ptr %4, align 4
  %132 = call i32 @fn3C(i32 noundef %131)
  store i32 %132, ptr %5, align 4
  %133 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %134 = load i32, ptr %133, align 4
  %135 = and i32 %134, 63
  %136 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %137 = and i32 %136, 63
  %138 = icmp ne i32 %135, %137
  br i1 %138, label %166, label %139

139:                                              ; preds = %122
  %140 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 1
  %141 = load i32, ptr %140, align 4
  %142 = lshr i32 %141, 6
  %143 = and i32 %142, 2047
  %144 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %145 = lshr i32 %144, 6
  %146 = and i32 %145, 2047
  %147 = icmp ne i32 %143, %146
  br i1 %147, label %166, label %148

148:                                              ; preds = %139
  %149 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sC, i64 4), align 4
  %150 = lshr i32 %149, 17
  %151 = load i32, ptr %5, align 4
  %152 = icmp ne i32 %150, %151
  br i1 %152, label %166, label %153

153:                                              ; preds = %148
  %154 = getelementptr inbounds nuw %struct.C, ptr %6, i32 0, i32 0
  %155 = load i32, ptr %154, align 4
  %156 = load i32, ptr @sC, align 4
  %157 = icmp ne i32 %155, %156
  br i1 %157, label %166, label %158

158:                                              ; preds = %153
  %159 = load i32, ptr %3, align 4
  %160 = load i32, ptr %4, align 4
  %161 = add i32 %159, %160
  %162 = load i32, ptr %2, align 4
  %163 = and i32 %161, %162
  %164 = load i32, ptr %5, align 4
  %165 = icmp ne i32 %163, %164
  br i1 %165, label %166, label %167

166:                                              ; preds = %158, %153, %148, %139, %122
  call void @abort() #4
  unreachable

167:                                              ; preds = %158
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeD(i64 %0) #0 {
  %2 = alloca %struct.D, align 8
  %3 = alloca %struct.D, align 8
  %4 = getelementptr inbounds nuw %struct.D, ptr %3, i32 0, i32 0
  store i64 %0, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %3, i64 8, i1 false)
  %5 = getelementptr inbounds nuw %struct.D, ptr %2, i32 0, i32 0
  %6 = load i64, ptr %5, align 8
  ret i64 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1D(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.D, align 8
  %4 = alloca %struct.D, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sD, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i64, ptr %3, align 8
  %7 = lshr i64 %6, 35
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %5
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %3, align 8
  %12 = and i64 %10, 536870911
  %13 = shl i64 %12, 35
  %14 = and i64 %11, 34359738367
  %15 = or i64 %14, %13
  store i64 %15, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.D, ptr %3, i32 0, i32 0
  %17 = load i64, ptr %16, align 8
  %18 = call i64 @retmeD(i64 %17)
  %19 = getelementptr inbounds nuw %struct.D, ptr %4, i32 0, i32 0
  store i64 %18, ptr %19, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 8, i1 false)
  %20 = load i64, ptr %3, align 8
  %21 = lshr i64 %20, 35
  %22 = trunc i64 %21 to i32
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2D(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.D, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sD, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i64, ptr %3, align 8
  %6 = lshr i64 %5, 35
  %7 = trunc i64 %6 to i32
  %8 = add i32 %7, %4
  %9 = zext i32 %8 to i64
  %10 = load i64, ptr %3, align 8
  %11 = and i64 %9, 536870911
  %12 = shl i64 %11, 35
  %13 = and i64 %10, 34359738367
  %14 = or i64 %13, %12
  store i64 %14, ptr %3, align 8
  %15 = load i64, ptr %3, align 8
  %16 = lshr i64 %15, 35
  %17 = trunc i64 %16 to i32
  %18 = srem i32 %17, 15
  %19 = sext i32 %18 to i64
  %20 = load i64, ptr %3, align 8
  %21 = and i64 %19, 536870911
  %22 = shl i64 %21, 35
  %23 = and i64 %20, 34359738367
  %24 = or i64 %23, %22
  store i64 %24, ptr %3, align 8
  %25 = load i64, ptr %3, align 8
  %26 = lshr i64 %25, 35
  %27 = trunc i64 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitD() #0 {
  %1 = load i64, ptr @sD, align 8
  %2 = lshr i64 %1, 35
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3D(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr @sD, align 8
  %5 = lshr i64 %4, 35
  %6 = trunc i64 %5 to i32
  %7 = add i32 %6, %3
  %8 = zext i32 %7 to i64
  %9 = load i64, ptr @sD, align 8
  %10 = and i64 %8, 536870911
  %11 = shl i64 %10, 35
  %12 = and i64 %9, 34359738367
  %13 = or i64 %12, %11
  store i64 %13, ptr @sD, align 8
  %14 = call i32 @retitD()
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testD() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.D, align 8
  %7 = alloca ptr, align 8
  store ptr @sD, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !10

20:                                               ; preds = %8
  %21 = load i64, ptr @sD, align 8
  %22 = and i64 %21, 34359738367
  %23 = or i64 %22, -34359738368
  store i64 %23, ptr @sD, align 8
  %24 = load i64, ptr @sD, align 8
  %25 = lshr i64 %24, 35
  %26 = trunc i64 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = zext i32 %29 to i64
  %31 = load i64, ptr @sD, align 8
  %32 = and i64 %30, 536870911
  %33 = shl i64 %32, 35
  %34 = and i64 %31, 34359738367
  %35 = or i64 %34, %33
  store i64 %35, ptr @sD, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sD, i64 8, i1 false)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 @fn1D(i32 noundef %36)
  store i32 %37, ptr %5, align 4
  %38 = load i64, ptr %6, align 8
  %39 = lshr i64 %38, 6
  %40 = and i64 %39, 63
  %41 = trunc i64 %40 to i32
  %42 = load i64, ptr @sD, align 8
  %43 = lshr i64 %42, 6
  %44 = and i64 %43, 63
  %45 = trunc i64 %44 to i32
  %46 = icmp ne i32 %41, %45
  br i1 %46, label %81, label %47

47:                                               ; preds = %20
  %48 = load i64, ptr %6, align 8
  %49 = lshr i64 %48, 12
  %50 = and i64 %49, 8388607
  %51 = trunc i64 %50 to i32
  %52 = load i64, ptr @sD, align 8
  %53 = lshr i64 %52, 12
  %54 = and i64 %53, 8388607
  %55 = trunc i64 %54 to i32
  %56 = icmp ne i32 %51, %55
  br i1 %56, label %81, label %57

57:                                               ; preds = %47
  %58 = load i64, ptr %6, align 8
  %59 = lshr i64 %58, 35
  %60 = trunc i64 %59 to i32
  %61 = load i64, ptr @sD, align 8
  %62 = lshr i64 %61, 35
  %63 = trunc i64 %62 to i32
  %64 = icmp ne i32 %60, %63
  br i1 %64, label %81, label %65

65:                                               ; preds = %57
  %66 = load i64, ptr %6, align 8
  %67 = and i64 %66, 63
  %68 = trunc i64 %67 to i32
  %69 = load i64, ptr @sD, align 8
  %70 = and i64 %69, 63
  %71 = trunc i64 %70 to i32
  %72 = icmp ne i32 %68, %71
  br i1 %72, label %81, label %73

73:                                               ; preds = %65
  %74 = load i32, ptr %3, align 4
  %75 = load i32, ptr %4, align 4
  %76 = add i32 %74, %75
  %77 = load i32, ptr %2, align 4
  %78 = and i32 %76, %77
  %79 = load i32, ptr %5, align 4
  %80 = icmp ne i32 %78, %79
  br i1 %80, label %81, label %82

81:                                               ; preds = %73, %65, %57, %47, %20
  call void @abort() #4
  unreachable

82:                                               ; preds = %73
  %83 = call i32 @myrnd()
  store i32 %83, ptr %3, align 4
  %84 = call i32 @myrnd()
  store i32 %84, ptr %4, align 4
  %85 = load i32, ptr %3, align 4
  %86 = zext i32 %85 to i64
  %87 = load i64, ptr @sD, align 8
  %88 = and i64 %86, 536870911
  %89 = shl i64 %88, 35
  %90 = and i64 %87, 34359738367
  %91 = or i64 %90, %89
  store i64 %91, ptr @sD, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sD, i64 8, i1 false)
  %92 = load i32, ptr %4, align 4
  %93 = call i32 @fn2D(i32 noundef %92)
  store i32 %93, ptr %5, align 4
  %94 = load i64, ptr %6, align 8
  %95 = lshr i64 %94, 6
  %96 = and i64 %95, 63
  %97 = trunc i64 %96 to i32
  %98 = load i64, ptr @sD, align 8
  %99 = lshr i64 %98, 6
  %100 = and i64 %99, 63
  %101 = trunc i64 %100 to i32
  %102 = icmp ne i32 %97, %101
  br i1 %102, label %140, label %103

103:                                              ; preds = %82
  %104 = load i64, ptr %6, align 8
  %105 = lshr i64 %104, 12
  %106 = and i64 %105, 8388607
  %107 = trunc i64 %106 to i32
  %108 = load i64, ptr @sD, align 8
  %109 = lshr i64 %108, 12
  %110 = and i64 %109, 8388607
  %111 = trunc i64 %110 to i32
  %112 = icmp ne i32 %107, %111
  br i1 %112, label %140, label %113

113:                                              ; preds = %103
  %114 = load i64, ptr %6, align 8
  %115 = lshr i64 %114, 35
  %116 = trunc i64 %115 to i32
  %117 = load i64, ptr @sD, align 8
  %118 = lshr i64 %117, 35
  %119 = trunc i64 %118 to i32
  %120 = icmp ne i32 %116, %119
  br i1 %120, label %140, label %121

121:                                              ; preds = %113
  %122 = load i64, ptr %6, align 8
  %123 = and i64 %122, 63
  %124 = trunc i64 %123 to i32
  %125 = load i64, ptr @sD, align 8
  %126 = and i64 %125, 63
  %127 = trunc i64 %126 to i32
  %128 = icmp ne i32 %124, %127
  br i1 %128, label %140, label %129

129:                                              ; preds = %121
  %130 = load i32, ptr %3, align 4
  %131 = load i32, ptr %4, align 4
  %132 = add i32 %130, %131
  %133 = load i32, ptr %2, align 4
  %134 = and i32 %132, %133
  %135 = urem i32 %134, 15
  %136 = load i32, ptr %2, align 4
  %137 = and i32 %135, %136
  %138 = load i32, ptr %5, align 4
  %139 = icmp ne i32 %137, %138
  br i1 %139, label %140, label %141

140:                                              ; preds = %129, %121, %113, %103, %82
  call void @abort() #4
  unreachable

141:                                              ; preds = %129
  %142 = call i32 @myrnd()
  store i32 %142, ptr %3, align 4
  %143 = call i32 @myrnd()
  store i32 %143, ptr %4, align 4
  %144 = load i32, ptr %3, align 4
  %145 = zext i32 %144 to i64
  %146 = load i64, ptr @sD, align 8
  %147 = and i64 %145, 536870911
  %148 = shl i64 %147, 35
  %149 = and i64 %146, 34359738367
  %150 = or i64 %149, %148
  store i64 %150, ptr @sD, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sD, i64 8, i1 false)
  %151 = load i32, ptr %4, align 4
  %152 = call i32 @fn3D(i32 noundef %151)
  store i32 %152, ptr %5, align 4
  %153 = load i64, ptr %6, align 8
  %154 = lshr i64 %153, 6
  %155 = and i64 %154, 63
  %156 = trunc i64 %155 to i32
  %157 = load i64, ptr @sD, align 8
  %158 = lshr i64 %157, 6
  %159 = and i64 %158, 63
  %160 = trunc i64 %159 to i32
  %161 = icmp ne i32 %156, %160
  br i1 %161, label %194, label %162

162:                                              ; preds = %141
  %163 = load i64, ptr %6, align 8
  %164 = lshr i64 %163, 12
  %165 = and i64 %164, 8388607
  %166 = trunc i64 %165 to i32
  %167 = load i64, ptr @sD, align 8
  %168 = lshr i64 %167, 12
  %169 = and i64 %168, 8388607
  %170 = trunc i64 %169 to i32
  %171 = icmp ne i32 %166, %170
  br i1 %171, label %194, label %172

172:                                              ; preds = %162
  %173 = load i64, ptr @sD, align 8
  %174 = lshr i64 %173, 35
  %175 = trunc i64 %174 to i32
  %176 = load i32, ptr %5, align 4
  %177 = icmp ne i32 %175, %176
  br i1 %177, label %194, label %178

178:                                              ; preds = %172
  %179 = load i64, ptr %6, align 8
  %180 = and i64 %179, 63
  %181 = trunc i64 %180 to i32
  %182 = load i64, ptr @sD, align 8
  %183 = and i64 %182, 63
  %184 = trunc i64 %183 to i32
  %185 = icmp ne i32 %181, %184
  br i1 %185, label %194, label %186

186:                                              ; preds = %178
  %187 = load i32, ptr %3, align 4
  %188 = load i32, ptr %4, align 4
  %189 = add i32 %187, %188
  %190 = load i32, ptr %2, align 4
  %191 = and i32 %189, %190
  %192 = load i32, ptr %5, align 4
  %193 = icmp ne i32 %191, %192
  br i1 %193, label %194, label %195

194:                                              ; preds = %186, %178, %172, %162, %141
  call void @abort() #4
  unreachable

195:                                              ; preds = %186
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeE(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.E, align 8
  %4 = alloca %struct.E, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1E(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.E, align 8
  %4 = alloca %struct.E, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sE, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.E, ptr %3, i32 0, i32 1
  %7 = load i64, ptr %6, align 8
  %8 = lshr i64 %7, 35
  %9 = trunc i64 %8 to i32
  %10 = add i32 %9, %5
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %6, align 8
  %13 = and i64 %11, 536870911
  %14 = shl i64 %13, 35
  %15 = and i64 %12, 34359738367
  %16 = or i64 %15, %14
  store i64 %16, ptr %6, align 8
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %18 = load i64, ptr %17, align 8
  %19 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %20 = load i64, ptr %19, align 8
  %21 = call { i64, i64 } @retmeE(i64 %18, i64 %20)
  %22 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %23 = extractvalue { i64, i64 } %21, 0
  store i64 %23, ptr %22, align 8
  %24 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %25 = extractvalue { i64, i64 } %21, 1
  store i64 %25, ptr %24, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %26 = getelementptr inbounds nuw %struct.E, ptr %3, i32 0, i32 1
  %27 = load i64, ptr %26, align 8
  %28 = lshr i64 %27, 35
  %29 = trunc i64 %28 to i32
  ret i32 %29
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2E(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.E, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sE, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.E, ptr %3, i32 0, i32 1
  %6 = load i64, ptr %5, align 8
  %7 = lshr i64 %6, 35
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %4
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %5, align 8
  %12 = and i64 %10, 536870911
  %13 = shl i64 %12, 35
  %14 = and i64 %11, 34359738367
  %15 = or i64 %14, %13
  store i64 %15, ptr %5, align 8
  %16 = getelementptr inbounds nuw %struct.E, ptr %3, i32 0, i32 1
  %17 = load i64, ptr %16, align 8
  %18 = lshr i64 %17, 35
  %19 = trunc i64 %18 to i32
  %20 = srem i32 %19, 15
  %21 = sext i32 %20 to i64
  %22 = load i64, ptr %16, align 8
  %23 = and i64 %21, 536870911
  %24 = shl i64 %23, 35
  %25 = and i64 %22, 34359738367
  %26 = or i64 %25, %24
  store i64 %26, ptr %16, align 8
  %27 = getelementptr inbounds nuw %struct.E, ptr %3, i32 0, i32 1
  %28 = load i64, ptr %27, align 8
  %29 = lshr i64 %28, 35
  %30 = trunc i64 %29 to i32
  ret i32 %30
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitE() #0 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %2 = lshr i64 %1, 35
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3E(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %5 = lshr i64 %4, 35
  %6 = trunc i64 %5 to i32
  %7 = add i32 %6, %3
  %8 = zext i32 %7 to i64
  %9 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %10 = and i64 %8, 536870911
  %11 = shl i64 %10, 35
  %12 = and i64 %9, 34359738367
  %13 = or i64 %12, %11
  store i64 %13, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %14 = call i32 @retitE()
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testE() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.E, align 8
  %7 = alloca ptr, align 8
  store ptr @sE, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !11

20:                                               ; preds = %8
  %21 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %22 = and i64 %21, 34359738367
  %23 = or i64 %22, -34359738368
  store i64 %23, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %24 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %25 = lshr i64 %24, 35
  %26 = trunc i64 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = zext i32 %29 to i64
  %31 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %32 = and i64 %30, 536870911
  %33 = shl i64 %32, 35
  %34 = and i64 %31, 34359738367
  %35 = or i64 %34, %33
  store i64 %35, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sE, i64 16, i1 false)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 @fn1E(i32 noundef %36)
  store i32 %37, ptr %5, align 4
  %38 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %39 = load i64, ptr %38, align 8
  %40 = and i64 %39, 4095
  %41 = trunc i64 %40 to i32
  %42 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %43 = and i64 %42, 4095
  %44 = trunc i64 %43 to i32
  %45 = icmp ne i32 %41, %44
  br i1 %45, label %79, label %46

46:                                               ; preds = %20
  %47 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %48 = load i64, ptr %47, align 8
  %49 = lshr i64 %48, 12
  %50 = and i64 %49, 8388607
  %51 = trunc i64 %50 to i32
  %52 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %53 = lshr i64 %52, 12
  %54 = and i64 %53, 8388607
  %55 = trunc i64 %54 to i32
  %56 = icmp ne i32 %51, %55
  br i1 %56, label %79, label %57

57:                                               ; preds = %46
  %58 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %59 = load i64, ptr %58, align 8
  %60 = lshr i64 %59, 35
  %61 = trunc i64 %60 to i32
  %62 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %63 = lshr i64 %62, 35
  %64 = trunc i64 %63 to i32
  %65 = icmp ne i32 %61, %64
  br i1 %65, label %79, label %66

66:                                               ; preds = %57
  %67 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 0
  %68 = load i64, ptr %67, align 8
  %69 = load i64, ptr @sE, align 8
  %70 = icmp ne i64 %68, %69
  br i1 %70, label %79, label %71

71:                                               ; preds = %66
  %72 = load i32, ptr %3, align 4
  %73 = load i32, ptr %4, align 4
  %74 = add i32 %72, %73
  %75 = load i32, ptr %2, align 4
  %76 = and i32 %74, %75
  %77 = load i32, ptr %5, align 4
  %78 = icmp ne i32 %76, %77
  br i1 %78, label %79, label %80

79:                                               ; preds = %71, %66, %57, %46, %20
  call void @abort() #4
  unreachable

80:                                               ; preds = %71
  %81 = call i32 @myrnd()
  store i32 %81, ptr %3, align 4
  %82 = call i32 @myrnd()
  store i32 %82, ptr %4, align 4
  %83 = load i32, ptr %3, align 4
  %84 = zext i32 %83 to i64
  %85 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %86 = and i64 %84, 536870911
  %87 = shl i64 %86, 35
  %88 = and i64 %85, 34359738367
  %89 = or i64 %88, %87
  store i64 %89, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sE, i64 16, i1 false)
  %90 = load i32, ptr %4, align 4
  %91 = call i32 @fn2E(i32 noundef %90)
  store i32 %91, ptr %5, align 4
  %92 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %93 = load i64, ptr %92, align 8
  %94 = and i64 %93, 4095
  %95 = trunc i64 %94 to i32
  %96 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %97 = and i64 %96, 4095
  %98 = trunc i64 %97 to i32
  %99 = icmp ne i32 %95, %98
  br i1 %99, label %136, label %100

100:                                              ; preds = %80
  %101 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %102 = load i64, ptr %101, align 8
  %103 = lshr i64 %102, 12
  %104 = and i64 %103, 8388607
  %105 = trunc i64 %104 to i32
  %106 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %107 = lshr i64 %106, 12
  %108 = and i64 %107, 8388607
  %109 = trunc i64 %108 to i32
  %110 = icmp ne i32 %105, %109
  br i1 %110, label %136, label %111

111:                                              ; preds = %100
  %112 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %113 = load i64, ptr %112, align 8
  %114 = lshr i64 %113, 35
  %115 = trunc i64 %114 to i32
  %116 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %117 = lshr i64 %116, 35
  %118 = trunc i64 %117 to i32
  %119 = icmp ne i32 %115, %118
  br i1 %119, label %136, label %120

120:                                              ; preds = %111
  %121 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 0
  %122 = load i64, ptr %121, align 8
  %123 = load i64, ptr @sE, align 8
  %124 = icmp ne i64 %122, %123
  br i1 %124, label %136, label %125

125:                                              ; preds = %120
  %126 = load i32, ptr %3, align 4
  %127 = load i32, ptr %4, align 4
  %128 = add i32 %126, %127
  %129 = load i32, ptr %2, align 4
  %130 = and i32 %128, %129
  %131 = urem i32 %130, 15
  %132 = load i32, ptr %2, align 4
  %133 = and i32 %131, %132
  %134 = load i32, ptr %5, align 4
  %135 = icmp ne i32 %133, %134
  br i1 %135, label %136, label %137

136:                                              ; preds = %125, %120, %111, %100, %80
  call void @abort() #4
  unreachable

137:                                              ; preds = %125
  %138 = call i32 @myrnd()
  store i32 %138, ptr %3, align 4
  %139 = call i32 @myrnd()
  store i32 %139, ptr %4, align 4
  %140 = load i32, ptr %3, align 4
  %141 = zext i32 %140 to i64
  %142 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %143 = and i64 %141, 536870911
  %144 = shl i64 %143, 35
  %145 = and i64 %142, 34359738367
  %146 = or i64 %145, %144
  store i64 %146, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sE, i64 16, i1 false)
  %147 = load i32, ptr %4, align 4
  %148 = call i32 @fn3E(i32 noundef %147)
  store i32 %148, ptr %5, align 4
  %149 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %150 = load i64, ptr %149, align 8
  %151 = and i64 %150, 4095
  %152 = trunc i64 %151 to i32
  %153 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %154 = and i64 %153, 4095
  %155 = trunc i64 %154 to i32
  %156 = icmp ne i32 %152, %155
  br i1 %156, label %187, label %157

157:                                              ; preds = %137
  %158 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 1
  %159 = load i64, ptr %158, align 8
  %160 = lshr i64 %159, 12
  %161 = and i64 %160, 8388607
  %162 = trunc i64 %161 to i32
  %163 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %164 = lshr i64 %163, 12
  %165 = and i64 %164, 8388607
  %166 = trunc i64 %165 to i32
  %167 = icmp ne i32 %162, %166
  br i1 %167, label %187, label %168

168:                                              ; preds = %157
  %169 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sE, i64 8), align 8
  %170 = lshr i64 %169, 35
  %171 = trunc i64 %170 to i32
  %172 = load i32, ptr %5, align 4
  %173 = icmp ne i32 %171, %172
  br i1 %173, label %187, label %174

174:                                              ; preds = %168
  %175 = getelementptr inbounds nuw %struct.E, ptr %6, i32 0, i32 0
  %176 = load i64, ptr %175, align 8
  %177 = load i64, ptr @sE, align 8
  %178 = icmp ne i64 %176, %177
  br i1 %178, label %187, label %179

179:                                              ; preds = %174
  %180 = load i32, ptr %3, align 4
  %181 = load i32, ptr %4, align 4
  %182 = add i32 %180, %181
  %183 = load i32, ptr %2, align 4
  %184 = and i32 %182, %183
  %185 = load i32, ptr %5, align 4
  %186 = icmp ne i32 %184, %185
  br i1 %186, label %187, label %188

187:                                              ; preds = %179, %174, %168, %157, %137
  call void @abort() #4
  unreachable

188:                                              ; preds = %179
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeF(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.F, align 8
  %4 = alloca %struct.F, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1F(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.F, align 8
  %4 = alloca %struct.F, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sF, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i64, ptr %3, align 8
  %7 = lshr i64 %6, 35
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %5
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %3, align 8
  %12 = and i64 %10, 536870911
  %13 = shl i64 %12, 35
  %14 = and i64 %11, 34359738367
  %15 = or i64 %14, %13
  store i64 %15, ptr %3, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %19 = load i64, ptr %18, align 8
  %20 = call { i64, i64 } @retmeF(i64 %17, i64 %19)
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %22 = extractvalue { i64, i64 } %20, 0
  store i64 %22, ptr %21, align 8
  %23 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %24 = extractvalue { i64, i64 } %20, 1
  store i64 %24, ptr %23, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %25 = load i64, ptr %3, align 8
  %26 = lshr i64 %25, 35
  %27 = trunc i64 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2F(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.F, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sF, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i64, ptr %3, align 8
  %6 = lshr i64 %5, 35
  %7 = trunc i64 %6 to i32
  %8 = add i32 %7, %4
  %9 = zext i32 %8 to i64
  %10 = load i64, ptr %3, align 8
  %11 = and i64 %9, 536870911
  %12 = shl i64 %11, 35
  %13 = and i64 %10, 34359738367
  %14 = or i64 %13, %12
  store i64 %14, ptr %3, align 8
  %15 = load i64, ptr %3, align 8
  %16 = lshr i64 %15, 35
  %17 = trunc i64 %16 to i32
  %18 = srem i32 %17, 15
  %19 = sext i32 %18 to i64
  %20 = load i64, ptr %3, align 8
  %21 = and i64 %19, 536870911
  %22 = shl i64 %21, 35
  %23 = and i64 %20, 34359738367
  %24 = or i64 %23, %22
  store i64 %24, ptr %3, align 8
  %25 = load i64, ptr %3, align 8
  %26 = lshr i64 %25, 35
  %27 = trunc i64 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitF() #0 {
  %1 = load i64, ptr @sF, align 8
  %2 = lshr i64 %1, 35
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3F(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr @sF, align 8
  %5 = lshr i64 %4, 35
  %6 = trunc i64 %5 to i32
  %7 = add i32 %6, %3
  %8 = zext i32 %7 to i64
  %9 = load i64, ptr @sF, align 8
  %10 = and i64 %8, 536870911
  %11 = shl i64 %10, 35
  %12 = and i64 %9, 34359738367
  %13 = or i64 %12, %11
  store i64 %13, ptr @sF, align 8
  %14 = call i32 @retitF()
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testF() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.F, align 8
  %7 = alloca ptr, align 8
  store ptr @sF, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !12

20:                                               ; preds = %8
  %21 = load i64, ptr @sF, align 8
  %22 = and i64 %21, 34359738367
  %23 = or i64 %22, -34359738368
  store i64 %23, ptr @sF, align 8
  %24 = load i64, ptr @sF, align 8
  %25 = lshr i64 %24, 35
  %26 = trunc i64 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = zext i32 %29 to i64
  %31 = load i64, ptr @sF, align 8
  %32 = and i64 %30, 536870911
  %33 = shl i64 %32, 35
  %34 = and i64 %31, 34359738367
  %35 = or i64 %34, %33
  store i64 %35, ptr @sF, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sF, i64 16, i1 false)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 @fn1F(i32 noundef %36)
  store i32 %37, ptr %5, align 4
  %38 = load i64, ptr %6, align 8
  %39 = and i64 %38, 4095
  %40 = trunc i64 %39 to i32
  %41 = load i64, ptr @sF, align 8
  %42 = and i64 %41, 4095
  %43 = trunc i64 %42 to i32
  %44 = icmp ne i32 %40, %43
  br i1 %44, label %76, label %45

45:                                               ; preds = %20
  %46 = load i64, ptr %6, align 8
  %47 = lshr i64 %46, 12
  %48 = and i64 %47, 8388607
  %49 = trunc i64 %48 to i32
  %50 = load i64, ptr @sF, align 8
  %51 = lshr i64 %50, 12
  %52 = and i64 %51, 8388607
  %53 = trunc i64 %52 to i32
  %54 = icmp ne i32 %49, %53
  br i1 %54, label %76, label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %6, align 8
  %57 = lshr i64 %56, 35
  %58 = trunc i64 %57 to i32
  %59 = load i64, ptr @sF, align 8
  %60 = lshr i64 %59, 35
  %61 = trunc i64 %60 to i32
  %62 = icmp ne i32 %58, %61
  br i1 %62, label %76, label %63

63:                                               ; preds = %55
  %64 = getelementptr inbounds nuw %struct.F, ptr %6, i32 0, i32 1
  %65 = load i64, ptr %64, align 8
  %66 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sF, i64 8), align 8
  %67 = icmp ne i64 %65, %66
  br i1 %67, label %76, label %68

68:                                               ; preds = %63
  %69 = load i32, ptr %3, align 4
  %70 = load i32, ptr %4, align 4
  %71 = add i32 %69, %70
  %72 = load i32, ptr %2, align 4
  %73 = and i32 %71, %72
  %74 = load i32, ptr %5, align 4
  %75 = icmp ne i32 %73, %74
  br i1 %75, label %76, label %77

76:                                               ; preds = %68, %63, %55, %45, %20
  call void @abort() #4
  unreachable

77:                                               ; preds = %68
  %78 = call i32 @myrnd()
  store i32 %78, ptr %3, align 4
  %79 = call i32 @myrnd()
  store i32 %79, ptr %4, align 4
  %80 = load i32, ptr %3, align 4
  %81 = zext i32 %80 to i64
  %82 = load i64, ptr @sF, align 8
  %83 = and i64 %81, 536870911
  %84 = shl i64 %83, 35
  %85 = and i64 %82, 34359738367
  %86 = or i64 %85, %84
  store i64 %86, ptr @sF, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sF, i64 16, i1 false)
  %87 = load i32, ptr %4, align 4
  %88 = call i32 @fn2F(i32 noundef %87)
  store i32 %88, ptr %5, align 4
  %89 = load i64, ptr %6, align 8
  %90 = and i64 %89, 4095
  %91 = trunc i64 %90 to i32
  %92 = load i64, ptr @sF, align 8
  %93 = and i64 %92, 4095
  %94 = trunc i64 %93 to i32
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %130, label %96

96:                                               ; preds = %77
  %97 = load i64, ptr %6, align 8
  %98 = lshr i64 %97, 12
  %99 = and i64 %98, 8388607
  %100 = trunc i64 %99 to i32
  %101 = load i64, ptr @sF, align 8
  %102 = lshr i64 %101, 12
  %103 = and i64 %102, 8388607
  %104 = trunc i64 %103 to i32
  %105 = icmp ne i32 %100, %104
  br i1 %105, label %130, label %106

106:                                              ; preds = %96
  %107 = load i64, ptr %6, align 8
  %108 = lshr i64 %107, 35
  %109 = trunc i64 %108 to i32
  %110 = load i64, ptr @sF, align 8
  %111 = lshr i64 %110, 35
  %112 = trunc i64 %111 to i32
  %113 = icmp ne i32 %109, %112
  br i1 %113, label %130, label %114

114:                                              ; preds = %106
  %115 = getelementptr inbounds nuw %struct.F, ptr %6, i32 0, i32 1
  %116 = load i64, ptr %115, align 8
  %117 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sF, i64 8), align 8
  %118 = icmp ne i64 %116, %117
  br i1 %118, label %130, label %119

119:                                              ; preds = %114
  %120 = load i32, ptr %3, align 4
  %121 = load i32, ptr %4, align 4
  %122 = add i32 %120, %121
  %123 = load i32, ptr %2, align 4
  %124 = and i32 %122, %123
  %125 = urem i32 %124, 15
  %126 = load i32, ptr %2, align 4
  %127 = and i32 %125, %126
  %128 = load i32, ptr %5, align 4
  %129 = icmp ne i32 %127, %128
  br i1 %129, label %130, label %131

130:                                              ; preds = %119, %114, %106, %96, %77
  call void @abort() #4
  unreachable

131:                                              ; preds = %119
  %132 = call i32 @myrnd()
  store i32 %132, ptr %3, align 4
  %133 = call i32 @myrnd()
  store i32 %133, ptr %4, align 4
  %134 = load i32, ptr %3, align 4
  %135 = zext i32 %134 to i64
  %136 = load i64, ptr @sF, align 8
  %137 = and i64 %135, 536870911
  %138 = shl i64 %137, 35
  %139 = and i64 %136, 34359738367
  %140 = or i64 %139, %138
  store i64 %140, ptr @sF, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sF, i64 16, i1 false)
  %141 = load i32, ptr %4, align 4
  %142 = call i32 @fn3F(i32 noundef %141)
  store i32 %142, ptr %5, align 4
  %143 = load i64, ptr %6, align 8
  %144 = and i64 %143, 4095
  %145 = trunc i64 %144 to i32
  %146 = load i64, ptr @sF, align 8
  %147 = and i64 %146, 4095
  %148 = trunc i64 %147 to i32
  %149 = icmp ne i32 %145, %148
  br i1 %149, label %179, label %150

150:                                              ; preds = %131
  %151 = load i64, ptr %6, align 8
  %152 = lshr i64 %151, 12
  %153 = and i64 %152, 8388607
  %154 = trunc i64 %153 to i32
  %155 = load i64, ptr @sF, align 8
  %156 = lshr i64 %155, 12
  %157 = and i64 %156, 8388607
  %158 = trunc i64 %157 to i32
  %159 = icmp ne i32 %154, %158
  br i1 %159, label %179, label %160

160:                                              ; preds = %150
  %161 = load i64, ptr @sF, align 8
  %162 = lshr i64 %161, 35
  %163 = trunc i64 %162 to i32
  %164 = load i32, ptr %5, align 4
  %165 = icmp ne i32 %163, %164
  br i1 %165, label %179, label %166

166:                                              ; preds = %160
  %167 = getelementptr inbounds nuw %struct.F, ptr %6, i32 0, i32 1
  %168 = load i64, ptr %167, align 8
  %169 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sF, i64 8), align 8
  %170 = icmp ne i64 %168, %169
  br i1 %170, label %179, label %171

171:                                              ; preds = %166
  %172 = load i32, ptr %3, align 4
  %173 = load i32, ptr %4, align 4
  %174 = add i32 %172, %173
  %175 = load i32, ptr %2, align 4
  %176 = and i32 %174, %175
  %177 = load i32, ptr %5, align 4
  %178 = icmp ne i32 %176, %177
  br i1 %178, label %179, label %180

179:                                              ; preds = %171, %166, %160, %150, %131
  call void @abort() #4
  unreachable

180:                                              ; preds = %171
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeG(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.G, align 8
  %4 = alloca %struct.G, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1G(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.G, align 8
  %4 = alloca %struct.G, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sG, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 8
  %7 = lshr i32 %6, 25
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 8
  %10 = and i32 %8, 127
  %11 = shl i32 %10, 25
  %12 = and i32 %9, 33554431
  %13 = or i32 %12, %11
  store i32 %13, ptr %3, align 8
  %14 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %17 = load i64, ptr %16, align 8
  %18 = call { i64, i64 } @retmeG(i64 %15, i64 %17)
  %19 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %20 = extractvalue { i64, i64 } %18, 0
  store i64 %20, ptr %19, align 8
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %22 = extractvalue { i64, i64 } %18, 1
  store i64 %22, ptr %21, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %23 = load i32, ptr %3, align 8
  %24 = lshr i32 %23, 25
  ret i32 %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2G(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.G, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sG, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 8
  %6 = lshr i32 %5, 25
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 8
  %9 = and i32 %7, 127
  %10 = shl i32 %9, 25
  %11 = and i32 %8, 33554431
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 8
  %13 = load i32, ptr %3, align 8
  %14 = lshr i32 %13, 25
  %15 = srem i32 %14, 15
  %16 = load i32, ptr %3, align 8
  %17 = and i32 %15, 127
  %18 = shl i32 %17, 25
  %19 = and i32 %16, 33554431
  %20 = or i32 %19, %18
  store i32 %20, ptr %3, align 8
  %21 = load i32, ptr %3, align 8
  %22 = lshr i32 %21, 25
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitG() #0 {
  %1 = load i32, ptr @sG, align 8
  %2 = lshr i32 %1, 25
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3G(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sG, align 8
  %5 = lshr i32 %4, 25
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sG, align 8
  %8 = and i32 %6, 127
  %9 = shl i32 %8, 25
  %10 = and i32 %7, 33554431
  %11 = or i32 %10, %9
  store i32 %11, ptr @sG, align 8
  %12 = call i32 @retitG()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testG() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.G, align 8
  %7 = alloca ptr, align 8
  store ptr @sG, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !13

20:                                               ; preds = %8
  %21 = load i32, ptr @sG, align 8
  %22 = and i32 %21, 33554431
  %23 = or i32 %22, -33554432
  store i32 %23, ptr @sG, align 8
  %24 = load i32, ptr @sG, align 8
  %25 = lshr i32 %24, 25
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sG, align 8
  %30 = and i32 %28, 127
  %31 = shl i32 %30, 25
  %32 = and i32 %29, 33554431
  %33 = or i32 %32, %31
  store i32 %33, ptr @sG, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sG, i64 16, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1G(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = load i32, ptr %6, align 8
  %37 = and i32 %36, 4095
  %38 = load i32, ptr @sG, align 8
  %39 = and i32 %38, 4095
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %68, label %41

41:                                               ; preds = %20
  %42 = load i32, ptr %6, align 8
  %43 = lshr i32 %42, 12
  %44 = and i32 %43, 8191
  %45 = load i32, ptr @sG, align 8
  %46 = lshr i32 %45, 12
  %47 = and i32 %46, 8191
  %48 = icmp ne i32 %44, %47
  br i1 %48, label %68, label %49

49:                                               ; preds = %41
  %50 = load i32, ptr %6, align 8
  %51 = lshr i32 %50, 25
  %52 = load i32, ptr @sG, align 8
  %53 = lshr i32 %52, 25
  %54 = icmp ne i32 %51, %53
  br i1 %54, label %68, label %55

55:                                               ; preds = %49
  %56 = getelementptr inbounds nuw %struct.G, ptr %6, i32 0, i32 1
  %57 = load i64, ptr %56, align 8
  %58 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sG, i64 8), align 8
  %59 = icmp ne i64 %57, %58
  br i1 %59, label %68, label %60

60:                                               ; preds = %55
  %61 = load i32, ptr %3, align 4
  %62 = load i32, ptr %4, align 4
  %63 = add i32 %61, %62
  %64 = load i32, ptr %2, align 4
  %65 = and i32 %63, %64
  %66 = load i32, ptr %5, align 4
  %67 = icmp ne i32 %65, %66
  br i1 %67, label %68, label %69

68:                                               ; preds = %60, %55, %49, %41, %20
  call void @abort() #4
  unreachable

69:                                               ; preds = %60
  %70 = call i32 @myrnd()
  store i32 %70, ptr %3, align 4
  %71 = call i32 @myrnd()
  store i32 %71, ptr %4, align 4
  %72 = load i32, ptr %3, align 4
  %73 = load i32, ptr @sG, align 8
  %74 = and i32 %72, 127
  %75 = shl i32 %74, 25
  %76 = and i32 %73, 33554431
  %77 = or i32 %76, %75
  store i32 %77, ptr @sG, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sG, i64 16, i1 false)
  %78 = load i32, ptr %4, align 4
  %79 = call i32 @fn2G(i32 noundef %78)
  store i32 %79, ptr %5, align 4
  %80 = load i32, ptr %6, align 8
  %81 = and i32 %80, 4095
  %82 = load i32, ptr @sG, align 8
  %83 = and i32 %82, 4095
  %84 = icmp ne i32 %81, %83
  br i1 %84, label %115, label %85

85:                                               ; preds = %69
  %86 = load i32, ptr %6, align 8
  %87 = lshr i32 %86, 12
  %88 = and i32 %87, 8191
  %89 = load i32, ptr @sG, align 8
  %90 = lshr i32 %89, 12
  %91 = and i32 %90, 8191
  %92 = icmp ne i32 %88, %91
  br i1 %92, label %115, label %93

93:                                               ; preds = %85
  %94 = load i32, ptr %6, align 8
  %95 = lshr i32 %94, 25
  %96 = load i32, ptr @sG, align 8
  %97 = lshr i32 %96, 25
  %98 = icmp ne i32 %95, %97
  br i1 %98, label %115, label %99

99:                                               ; preds = %93
  %100 = getelementptr inbounds nuw %struct.G, ptr %6, i32 0, i32 1
  %101 = load i64, ptr %100, align 8
  %102 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sG, i64 8), align 8
  %103 = icmp ne i64 %101, %102
  br i1 %103, label %115, label %104

104:                                              ; preds = %99
  %105 = load i32, ptr %3, align 4
  %106 = load i32, ptr %4, align 4
  %107 = add i32 %105, %106
  %108 = load i32, ptr %2, align 4
  %109 = and i32 %107, %108
  %110 = urem i32 %109, 15
  %111 = load i32, ptr %2, align 4
  %112 = and i32 %110, %111
  %113 = load i32, ptr %5, align 4
  %114 = icmp ne i32 %112, %113
  br i1 %114, label %115, label %116

115:                                              ; preds = %104, %99, %93, %85, %69
  call void @abort() #4
  unreachable

116:                                              ; preds = %104
  %117 = call i32 @myrnd()
  store i32 %117, ptr %3, align 4
  %118 = call i32 @myrnd()
  store i32 %118, ptr %4, align 4
  %119 = load i32, ptr %3, align 4
  %120 = load i32, ptr @sG, align 8
  %121 = and i32 %119, 127
  %122 = shl i32 %121, 25
  %123 = and i32 %120, 33554431
  %124 = or i32 %123, %122
  store i32 %124, ptr @sG, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sG, i64 16, i1 false)
  %125 = load i32, ptr %4, align 4
  %126 = call i32 @fn3G(i32 noundef %125)
  store i32 %126, ptr %5, align 4
  %127 = load i32, ptr %6, align 8
  %128 = and i32 %127, 4095
  %129 = load i32, ptr @sG, align 8
  %130 = and i32 %129, 4095
  %131 = icmp ne i32 %128, %130
  br i1 %131, label %158, label %132

132:                                              ; preds = %116
  %133 = load i32, ptr %6, align 8
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 8191
  %136 = load i32, ptr @sG, align 8
  %137 = lshr i32 %136, 12
  %138 = and i32 %137, 8191
  %139 = icmp ne i32 %135, %138
  br i1 %139, label %158, label %140

140:                                              ; preds = %132
  %141 = load i32, ptr @sG, align 8
  %142 = lshr i32 %141, 25
  %143 = load i32, ptr %5, align 4
  %144 = icmp ne i32 %142, %143
  br i1 %144, label %158, label %145

145:                                              ; preds = %140
  %146 = getelementptr inbounds nuw %struct.G, ptr %6, i32 0, i32 1
  %147 = load i64, ptr %146, align 8
  %148 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sG, i64 8), align 8
  %149 = icmp ne i64 %147, %148
  br i1 %149, label %158, label %150

150:                                              ; preds = %145
  %151 = load i32, ptr %3, align 4
  %152 = load i32, ptr %4, align 4
  %153 = add i32 %151, %152
  %154 = load i32, ptr %2, align 4
  %155 = and i32 %153, %154
  %156 = load i32, ptr %5, align 4
  %157 = icmp ne i32 %155, %156
  br i1 %157, label %158, label %159

158:                                              ; preds = %150, %145, %140, %132, %116
  call void @abort() #4
  unreachable

159:                                              ; preds = %150
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeH(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.H, align 8
  %4 = alloca %struct.H, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1H(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.H, align 8
  %4 = alloca %struct.H, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sH, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 8
  %7 = lshr i32 %6, 23
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 8
  %10 = and i32 %8, 511
  %11 = shl i32 %10, 23
  %12 = and i32 %9, 8388607
  %13 = or i32 %12, %11
  store i32 %13, ptr %3, align 8
  %14 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %15 = load i64, ptr %14, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %17 = load i64, ptr %16, align 8
  %18 = call { i64, i64 } @retmeH(i64 %15, i64 %17)
  %19 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %20 = extractvalue { i64, i64 } %18, 0
  store i64 %20, ptr %19, align 8
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %22 = extractvalue { i64, i64 } %18, 1
  store i64 %22, ptr %21, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %23 = load i32, ptr %3, align 8
  %24 = lshr i32 %23, 23
  ret i32 %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2H(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.H, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sH, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 8
  %6 = lshr i32 %5, 23
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 8
  %9 = and i32 %7, 511
  %10 = shl i32 %9, 23
  %11 = and i32 %8, 8388607
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 8
  %13 = load i32, ptr %3, align 8
  %14 = lshr i32 %13, 23
  %15 = srem i32 %14, 15
  %16 = load i32, ptr %3, align 8
  %17 = and i32 %15, 511
  %18 = shl i32 %17, 23
  %19 = and i32 %16, 8388607
  %20 = or i32 %19, %18
  store i32 %20, ptr %3, align 8
  %21 = load i32, ptr %3, align 8
  %22 = lshr i32 %21, 23
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitH() #0 {
  %1 = load i32, ptr @sH, align 8
  %2 = lshr i32 %1, 23
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3H(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sH, align 8
  %5 = lshr i32 %4, 23
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sH, align 8
  %8 = and i32 %6, 511
  %9 = shl i32 %8, 23
  %10 = and i32 %7, 8388607
  %11 = or i32 %10, %9
  store i32 %11, ptr @sH, align 8
  %12 = call i32 @retitH()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testH() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.H, align 8
  %7 = alloca ptr, align 8
  store ptr @sH, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !14

20:                                               ; preds = %8
  %21 = load i32, ptr @sH, align 8
  %22 = and i32 %21, 8388607
  %23 = or i32 %22, -8388608
  store i32 %23, ptr @sH, align 8
  %24 = load i32, ptr @sH, align 8
  %25 = lshr i32 %24, 23
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sH, align 8
  %30 = and i32 %28, 511
  %31 = shl i32 %30, 23
  %32 = and i32 %29, 8388607
  %33 = or i32 %32, %31
  store i32 %33, ptr @sH, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sH, i64 16, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1H(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = load i32, ptr %6, align 8
  %37 = and i32 %36, 4095
  %38 = load i32, ptr @sH, align 8
  %39 = and i32 %38, 4095
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %68, label %41

41:                                               ; preds = %20
  %42 = load i32, ptr %6, align 8
  %43 = lshr i32 %42, 12
  %44 = and i32 %43, 2047
  %45 = load i32, ptr @sH, align 8
  %46 = lshr i32 %45, 12
  %47 = and i32 %46, 2047
  %48 = icmp ne i32 %44, %47
  br i1 %48, label %68, label %49

49:                                               ; preds = %41
  %50 = load i32, ptr %6, align 8
  %51 = lshr i32 %50, 23
  %52 = load i32, ptr @sH, align 8
  %53 = lshr i32 %52, 23
  %54 = icmp ne i32 %51, %53
  br i1 %54, label %68, label %55

55:                                               ; preds = %49
  %56 = getelementptr inbounds nuw %struct.H, ptr %6, i32 0, i32 1
  %57 = load i64, ptr %56, align 8
  %58 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sH, i64 8), align 8
  %59 = icmp ne i64 %57, %58
  br i1 %59, label %68, label %60

60:                                               ; preds = %55
  %61 = load i32, ptr %3, align 4
  %62 = load i32, ptr %4, align 4
  %63 = add i32 %61, %62
  %64 = load i32, ptr %2, align 4
  %65 = and i32 %63, %64
  %66 = load i32, ptr %5, align 4
  %67 = icmp ne i32 %65, %66
  br i1 %67, label %68, label %69

68:                                               ; preds = %60, %55, %49, %41, %20
  call void @abort() #4
  unreachable

69:                                               ; preds = %60
  %70 = call i32 @myrnd()
  store i32 %70, ptr %3, align 4
  %71 = call i32 @myrnd()
  store i32 %71, ptr %4, align 4
  %72 = load i32, ptr %3, align 4
  %73 = load i32, ptr @sH, align 8
  %74 = and i32 %72, 511
  %75 = shl i32 %74, 23
  %76 = and i32 %73, 8388607
  %77 = or i32 %76, %75
  store i32 %77, ptr @sH, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sH, i64 16, i1 false)
  %78 = load i32, ptr %4, align 4
  %79 = call i32 @fn2H(i32 noundef %78)
  store i32 %79, ptr %5, align 4
  %80 = load i32, ptr %6, align 8
  %81 = and i32 %80, 4095
  %82 = load i32, ptr @sH, align 8
  %83 = and i32 %82, 4095
  %84 = icmp ne i32 %81, %83
  br i1 %84, label %115, label %85

85:                                               ; preds = %69
  %86 = load i32, ptr %6, align 8
  %87 = lshr i32 %86, 12
  %88 = and i32 %87, 2047
  %89 = load i32, ptr @sH, align 8
  %90 = lshr i32 %89, 12
  %91 = and i32 %90, 2047
  %92 = icmp ne i32 %88, %91
  br i1 %92, label %115, label %93

93:                                               ; preds = %85
  %94 = load i32, ptr %6, align 8
  %95 = lshr i32 %94, 23
  %96 = load i32, ptr @sH, align 8
  %97 = lshr i32 %96, 23
  %98 = icmp ne i32 %95, %97
  br i1 %98, label %115, label %99

99:                                               ; preds = %93
  %100 = getelementptr inbounds nuw %struct.H, ptr %6, i32 0, i32 1
  %101 = load i64, ptr %100, align 8
  %102 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sH, i64 8), align 8
  %103 = icmp ne i64 %101, %102
  br i1 %103, label %115, label %104

104:                                              ; preds = %99
  %105 = load i32, ptr %3, align 4
  %106 = load i32, ptr %4, align 4
  %107 = add i32 %105, %106
  %108 = load i32, ptr %2, align 4
  %109 = and i32 %107, %108
  %110 = urem i32 %109, 15
  %111 = load i32, ptr %2, align 4
  %112 = and i32 %110, %111
  %113 = load i32, ptr %5, align 4
  %114 = icmp ne i32 %112, %113
  br i1 %114, label %115, label %116

115:                                              ; preds = %104, %99, %93, %85, %69
  call void @abort() #4
  unreachable

116:                                              ; preds = %104
  %117 = call i32 @myrnd()
  store i32 %117, ptr %3, align 4
  %118 = call i32 @myrnd()
  store i32 %118, ptr %4, align 4
  %119 = load i32, ptr %3, align 4
  %120 = load i32, ptr @sH, align 8
  %121 = and i32 %119, 511
  %122 = shl i32 %121, 23
  %123 = and i32 %120, 8388607
  %124 = or i32 %123, %122
  store i32 %124, ptr @sH, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sH, i64 16, i1 false)
  %125 = load i32, ptr %4, align 4
  %126 = call i32 @fn3H(i32 noundef %125)
  store i32 %126, ptr %5, align 4
  %127 = load i32, ptr %6, align 8
  %128 = and i32 %127, 4095
  %129 = load i32, ptr @sH, align 8
  %130 = and i32 %129, 4095
  %131 = icmp ne i32 %128, %130
  br i1 %131, label %158, label %132

132:                                              ; preds = %116
  %133 = load i32, ptr %6, align 8
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 2047
  %136 = load i32, ptr @sH, align 8
  %137 = lshr i32 %136, 12
  %138 = and i32 %137, 2047
  %139 = icmp ne i32 %135, %138
  br i1 %139, label %158, label %140

140:                                              ; preds = %132
  %141 = load i32, ptr @sH, align 8
  %142 = lshr i32 %141, 23
  %143 = load i32, ptr %5, align 4
  %144 = icmp ne i32 %142, %143
  br i1 %144, label %158, label %145

145:                                              ; preds = %140
  %146 = getelementptr inbounds nuw %struct.H, ptr %6, i32 0, i32 1
  %147 = load i64, ptr %146, align 8
  %148 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sH, i64 8), align 8
  %149 = icmp ne i64 %147, %148
  br i1 %149, label %158, label %150

150:                                              ; preds = %145
  %151 = load i32, ptr %3, align 4
  %152 = load i32, ptr %4, align 4
  %153 = add i32 %151, %152
  %154 = load i32, ptr %2, align 4
  %155 = and i32 %153, %154
  %156 = load i32, ptr %5, align 4
  %157 = icmp ne i32 %155, %156
  br i1 %157, label %158, label %159

158:                                              ; preds = %150, %145, %140, %132, %116
  call void @abort() #4
  unreachable

159:                                              ; preds = %150
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeI(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.I, align 8
  %4 = alloca %struct.I, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1I(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.I, align 8
  %4 = alloca %struct.I, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sI, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 8
  %7 = lshr i16 %6, 7
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %5
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 8
  %12 = and i16 %10, 511
  %13 = shl i16 %12, 7
  %14 = and i16 %11, 127
  %15 = or i16 %14, %13
  store i16 %15, ptr %3, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %19 = load i64, ptr %18, align 8
  %20 = call { i64, i64 } @retmeI(i64 %17, i64 %19)
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %22 = extractvalue { i64, i64 } %20, 0
  store i64 %22, ptr %21, align 8
  %23 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %24 = extractvalue { i64, i64 } %20, 1
  store i64 %24, ptr %23, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %25 = load i16, ptr %3, align 8
  %26 = lshr i16 %25, 7
  %27 = zext i16 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2I(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.I, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sI, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 8
  %6 = lshr i16 %5, 7
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %4
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr %3, align 8
  %11 = and i16 %9, 511
  %12 = shl i16 %11, 7
  %13 = and i16 %10, 127
  %14 = or i16 %13, %12
  store i16 %14, ptr %3, align 8
  %15 = load i16, ptr %3, align 8
  %16 = lshr i16 %15, 7
  %17 = zext i16 %16 to i32
  %18 = srem i32 %17, 15
  %19 = trunc i32 %18 to i16
  %20 = load i16, ptr %3, align 8
  %21 = and i16 %19, 511
  %22 = shl i16 %21, 7
  %23 = and i16 %20, 127
  %24 = or i16 %23, %22
  store i16 %24, ptr %3, align 8
  %25 = load i16, ptr %3, align 8
  %26 = lshr i16 %25, 7
  %27 = zext i16 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitI() #0 {
  %1 = load i16, ptr @sI, align 8
  %2 = lshr i16 %1, 7
  %3 = zext i16 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3I(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sI, align 8
  %5 = lshr i16 %4, 7
  %6 = zext i16 %5 to i32
  %7 = add i32 %6, %3
  %8 = trunc i32 %7 to i16
  %9 = load i16, ptr @sI, align 8
  %10 = and i16 %8, 511
  %11 = shl i16 %10, 7
  %12 = and i16 %9, 127
  %13 = or i16 %12, %11
  store i16 %13, ptr @sI, align 8
  %14 = call i32 @retitI()
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testI() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.I, align 8
  %7 = alloca ptr, align 8
  store ptr @sI, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !15

20:                                               ; preds = %8
  %21 = load i16, ptr @sI, align 8
  %22 = and i16 %21, 127
  %23 = or i16 %22, -128
  store i16 %23, ptr @sI, align 8
  %24 = load i16, ptr @sI, align 8
  %25 = lshr i16 %24, 7
  %26 = zext i16 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = trunc i32 %29 to i16
  %31 = load i16, ptr @sI, align 8
  %32 = and i16 %30, 511
  %33 = shl i16 %32, 7
  %34 = and i16 %31, 127
  %35 = or i16 %34, %33
  store i16 %35, ptr @sI, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sI, i64 16, i1 false)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 @fn1I(i32 noundef %36)
  store i32 %37, ptr %5, align 4
  %38 = load i16, ptr %6, align 8
  %39 = and i16 %38, 1
  %40 = zext i16 %39 to i32
  %41 = load i16, ptr @sI, align 8
  %42 = and i16 %41, 1
  %43 = zext i16 %42 to i32
  %44 = icmp ne i32 %40, %43
  br i1 %44, label %76, label %45

45:                                               ; preds = %20
  %46 = load i16, ptr %6, align 8
  %47 = lshr i16 %46, 1
  %48 = and i16 %47, 63
  %49 = zext i16 %48 to i32
  %50 = load i16, ptr @sI, align 8
  %51 = lshr i16 %50, 1
  %52 = and i16 %51, 63
  %53 = zext i16 %52 to i32
  %54 = icmp ne i32 %49, %53
  br i1 %54, label %76, label %55

55:                                               ; preds = %45
  %56 = load i16, ptr %6, align 8
  %57 = lshr i16 %56, 7
  %58 = zext i16 %57 to i32
  %59 = load i16, ptr @sI, align 8
  %60 = lshr i16 %59, 7
  %61 = zext i16 %60 to i32
  %62 = icmp ne i32 %58, %61
  br i1 %62, label %76, label %63

63:                                               ; preds = %55
  %64 = getelementptr inbounds nuw %struct.I, ptr %6, i32 0, i32 1
  %65 = load i64, ptr %64, align 8
  %66 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sI, i64 8), align 8
  %67 = icmp ne i64 %65, %66
  br i1 %67, label %76, label %68

68:                                               ; preds = %63
  %69 = load i32, ptr %3, align 4
  %70 = load i32, ptr %4, align 4
  %71 = add i32 %69, %70
  %72 = load i32, ptr %2, align 4
  %73 = and i32 %71, %72
  %74 = load i32, ptr %5, align 4
  %75 = icmp ne i32 %73, %74
  br i1 %75, label %76, label %77

76:                                               ; preds = %68, %63, %55, %45, %20
  call void @abort() #4
  unreachable

77:                                               ; preds = %68
  %78 = call i32 @myrnd()
  store i32 %78, ptr %3, align 4
  %79 = call i32 @myrnd()
  store i32 %79, ptr %4, align 4
  %80 = load i32, ptr %3, align 4
  %81 = trunc i32 %80 to i16
  %82 = load i16, ptr @sI, align 8
  %83 = and i16 %81, 511
  %84 = shl i16 %83, 7
  %85 = and i16 %82, 127
  %86 = or i16 %85, %84
  store i16 %86, ptr @sI, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sI, i64 16, i1 false)
  %87 = load i32, ptr %4, align 4
  %88 = call i32 @fn2I(i32 noundef %87)
  store i32 %88, ptr %5, align 4
  %89 = load i16, ptr %6, align 8
  %90 = and i16 %89, 1
  %91 = zext i16 %90 to i32
  %92 = load i16, ptr @sI, align 8
  %93 = and i16 %92, 1
  %94 = zext i16 %93 to i32
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %130, label %96

96:                                               ; preds = %77
  %97 = load i16, ptr %6, align 8
  %98 = lshr i16 %97, 1
  %99 = and i16 %98, 63
  %100 = zext i16 %99 to i32
  %101 = load i16, ptr @sI, align 8
  %102 = lshr i16 %101, 1
  %103 = and i16 %102, 63
  %104 = zext i16 %103 to i32
  %105 = icmp ne i32 %100, %104
  br i1 %105, label %130, label %106

106:                                              ; preds = %96
  %107 = load i16, ptr %6, align 8
  %108 = lshr i16 %107, 7
  %109 = zext i16 %108 to i32
  %110 = load i16, ptr @sI, align 8
  %111 = lshr i16 %110, 7
  %112 = zext i16 %111 to i32
  %113 = icmp ne i32 %109, %112
  br i1 %113, label %130, label %114

114:                                              ; preds = %106
  %115 = getelementptr inbounds nuw %struct.I, ptr %6, i32 0, i32 1
  %116 = load i64, ptr %115, align 8
  %117 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sI, i64 8), align 8
  %118 = icmp ne i64 %116, %117
  br i1 %118, label %130, label %119

119:                                              ; preds = %114
  %120 = load i32, ptr %3, align 4
  %121 = load i32, ptr %4, align 4
  %122 = add i32 %120, %121
  %123 = load i32, ptr %2, align 4
  %124 = and i32 %122, %123
  %125 = urem i32 %124, 15
  %126 = load i32, ptr %2, align 4
  %127 = and i32 %125, %126
  %128 = load i32, ptr %5, align 4
  %129 = icmp ne i32 %127, %128
  br i1 %129, label %130, label %131

130:                                              ; preds = %119, %114, %106, %96, %77
  call void @abort() #4
  unreachable

131:                                              ; preds = %119
  %132 = call i32 @myrnd()
  store i32 %132, ptr %3, align 4
  %133 = call i32 @myrnd()
  store i32 %133, ptr %4, align 4
  %134 = load i32, ptr %3, align 4
  %135 = trunc i32 %134 to i16
  %136 = load i16, ptr @sI, align 8
  %137 = and i16 %135, 511
  %138 = shl i16 %137, 7
  %139 = and i16 %136, 127
  %140 = or i16 %139, %138
  store i16 %140, ptr @sI, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sI, i64 16, i1 false)
  %141 = load i32, ptr %4, align 4
  %142 = call i32 @fn3I(i32 noundef %141)
  store i32 %142, ptr %5, align 4
  %143 = load i16, ptr %6, align 8
  %144 = and i16 %143, 1
  %145 = zext i16 %144 to i32
  %146 = load i16, ptr @sI, align 8
  %147 = and i16 %146, 1
  %148 = zext i16 %147 to i32
  %149 = icmp ne i32 %145, %148
  br i1 %149, label %179, label %150

150:                                              ; preds = %131
  %151 = load i16, ptr %6, align 8
  %152 = lshr i16 %151, 1
  %153 = and i16 %152, 63
  %154 = zext i16 %153 to i32
  %155 = load i16, ptr @sI, align 8
  %156 = lshr i16 %155, 1
  %157 = and i16 %156, 63
  %158 = zext i16 %157 to i32
  %159 = icmp ne i32 %154, %158
  br i1 %159, label %179, label %160

160:                                              ; preds = %150
  %161 = load i16, ptr @sI, align 8
  %162 = lshr i16 %161, 7
  %163 = zext i16 %162 to i32
  %164 = load i32, ptr %5, align 4
  %165 = icmp ne i32 %163, %164
  br i1 %165, label %179, label %166

166:                                              ; preds = %160
  %167 = getelementptr inbounds nuw %struct.I, ptr %6, i32 0, i32 1
  %168 = load i64, ptr %167, align 8
  %169 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sI, i64 8), align 8
  %170 = icmp ne i64 %168, %169
  br i1 %170, label %179, label %171

171:                                              ; preds = %166
  %172 = load i32, ptr %3, align 4
  %173 = load i32, ptr %4, align 4
  %174 = add i32 %172, %173
  %175 = load i32, ptr %2, align 4
  %176 = and i32 %174, %175
  %177 = load i32, ptr %5, align 4
  %178 = icmp ne i32 %176, %177
  br i1 %178, label %179, label %180

179:                                              ; preds = %171, %166, %160, %150, %131
  call void @abort() #4
  unreachable

180:                                              ; preds = %171
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retmeJ(i32 %0) #0 {
  %2 = alloca %struct.J, align 2
  %3 = alloca %struct.J, align 2
  store i32 %0, ptr %3, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %2, ptr align 2 %3, i64 4, i1 false)
  %4 = load i32, ptr %2, align 2
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1J(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.J, align 2
  %4 = alloca %struct.J, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sJ, i64 4, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 2
  %7 = lshr i16 %6, 9
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %5
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 2
  %12 = and i16 %10, 127
  %13 = shl i16 %12, 9
  %14 = and i16 %11, 511
  %15 = or i16 %14, %13
  store i16 %15, ptr %3, align 2
  %16 = load i32, ptr %3, align 2
  %17 = call i32 @retmeJ(i32 %16)
  store i32 %17, ptr %4, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 %4, i64 4, i1 false)
  %18 = load i16, ptr %3, align 2
  %19 = lshr i16 %18, 9
  %20 = zext i16 %19 to i32
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2J(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.J, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sJ, i64 4, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 2
  %6 = lshr i16 %5, 9
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %4
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr %3, align 2
  %11 = and i16 %9, 127
  %12 = shl i16 %11, 9
  %13 = and i16 %10, 511
  %14 = or i16 %13, %12
  store i16 %14, ptr %3, align 2
  %15 = load i16, ptr %3, align 2
  %16 = lshr i16 %15, 9
  %17 = zext i16 %16 to i32
  %18 = srem i32 %17, 15
  %19 = trunc i32 %18 to i16
  %20 = load i16, ptr %3, align 2
  %21 = and i16 %19, 127
  %22 = shl i16 %21, 9
  %23 = and i16 %20, 511
  %24 = or i16 %23, %22
  store i16 %24, ptr %3, align 2
  %25 = load i16, ptr %3, align 2
  %26 = lshr i16 %25, 9
  %27 = zext i16 %26 to i32
  ret i32 %27
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitJ() #0 {
  %1 = load i16, ptr @sJ, align 2
  %2 = lshr i16 %1, 9
  %3 = zext i16 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3J(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sJ, align 2
  %5 = lshr i16 %4, 9
  %6 = zext i16 %5 to i32
  %7 = add i32 %6, %3
  %8 = trunc i32 %7 to i16
  %9 = load i16, ptr @sJ, align 2
  %10 = and i16 %8, 127
  %11 = shl i16 %10, 9
  %12 = and i16 %9, 511
  %13 = or i16 %12, %11
  store i16 %13, ptr @sJ, align 2
  %14 = call i32 @retitJ()
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testJ() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.J, align 2
  %7 = alloca ptr, align 8
  store ptr @sJ, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 4
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !16

20:                                               ; preds = %8
  %21 = load i16, ptr @sJ, align 2
  %22 = and i16 %21, 511
  %23 = or i16 %22, -512
  store i16 %23, ptr @sJ, align 2
  %24 = load i16, ptr @sJ, align 2
  %25 = lshr i16 %24, 9
  %26 = zext i16 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = trunc i32 %29 to i16
  %31 = load i16, ptr @sJ, align 2
  %32 = and i16 %30, 127
  %33 = shl i16 %32, 9
  %34 = and i16 %31, 511
  %35 = or i16 %34, %33
  store i16 %35, ptr @sJ, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sJ, i64 4, i1 false)
  %36 = load i32, ptr %4, align 4
  %37 = call i32 @fn1J(i32 noundef %36)
  store i32 %37, ptr %5, align 4
  %38 = load i16, ptr %6, align 2
  %39 = and i16 %38, 1
  %40 = zext i16 %39 to i32
  %41 = load i16, ptr @sJ, align 2
  %42 = and i16 %41, 1
  %43 = zext i16 %42 to i32
  %44 = icmp ne i32 %40, %43
  br i1 %44, label %78, label %45

45:                                               ; preds = %20
  %46 = load i16, ptr %6, align 2
  %47 = lshr i16 %46, 1
  %48 = and i16 %47, 255
  %49 = zext i16 %48 to i32
  %50 = load i16, ptr @sJ, align 2
  %51 = lshr i16 %50, 1
  %52 = and i16 %51, 255
  %53 = zext i16 %52 to i32
  %54 = icmp ne i32 %49, %53
  br i1 %54, label %78, label %55

55:                                               ; preds = %45
  %56 = load i16, ptr %6, align 2
  %57 = lshr i16 %56, 9
  %58 = zext i16 %57 to i32
  %59 = load i16, ptr @sJ, align 2
  %60 = lshr i16 %59, 9
  %61 = zext i16 %60 to i32
  %62 = icmp ne i32 %58, %61
  br i1 %62, label %78, label %63

63:                                               ; preds = %55
  %64 = getelementptr inbounds nuw %struct.J, ptr %6, i32 0, i32 1
  %65 = load i16, ptr %64, align 2
  %66 = zext i16 %65 to i32
  %67 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sJ, i64 2), align 2
  %68 = zext i16 %67 to i32
  %69 = icmp ne i32 %66, %68
  br i1 %69, label %78, label %70

70:                                               ; preds = %63
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr %4, align 4
  %73 = add i32 %71, %72
  %74 = load i32, ptr %2, align 4
  %75 = and i32 %73, %74
  %76 = load i32, ptr %5, align 4
  %77 = icmp ne i32 %75, %76
  br i1 %77, label %78, label %79

78:                                               ; preds = %70, %63, %55, %45, %20
  call void @abort() #4
  unreachable

79:                                               ; preds = %70
  %80 = call i32 @myrnd()
  store i32 %80, ptr %3, align 4
  %81 = call i32 @myrnd()
  store i32 %81, ptr %4, align 4
  %82 = load i32, ptr %3, align 4
  %83 = trunc i32 %82 to i16
  %84 = load i16, ptr @sJ, align 2
  %85 = and i16 %83, 127
  %86 = shl i16 %85, 9
  %87 = and i16 %84, 511
  %88 = or i16 %87, %86
  store i16 %88, ptr @sJ, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sJ, i64 4, i1 false)
  %89 = load i32, ptr %4, align 4
  %90 = call i32 @fn2J(i32 noundef %89)
  store i32 %90, ptr %5, align 4
  %91 = load i16, ptr %6, align 2
  %92 = and i16 %91, 1
  %93 = zext i16 %92 to i32
  %94 = load i16, ptr @sJ, align 2
  %95 = and i16 %94, 1
  %96 = zext i16 %95 to i32
  %97 = icmp ne i32 %93, %96
  br i1 %97, label %134, label %98

98:                                               ; preds = %79
  %99 = load i16, ptr %6, align 2
  %100 = lshr i16 %99, 1
  %101 = and i16 %100, 255
  %102 = zext i16 %101 to i32
  %103 = load i16, ptr @sJ, align 2
  %104 = lshr i16 %103, 1
  %105 = and i16 %104, 255
  %106 = zext i16 %105 to i32
  %107 = icmp ne i32 %102, %106
  br i1 %107, label %134, label %108

108:                                              ; preds = %98
  %109 = load i16, ptr %6, align 2
  %110 = lshr i16 %109, 9
  %111 = zext i16 %110 to i32
  %112 = load i16, ptr @sJ, align 2
  %113 = lshr i16 %112, 9
  %114 = zext i16 %113 to i32
  %115 = icmp ne i32 %111, %114
  br i1 %115, label %134, label %116

116:                                              ; preds = %108
  %117 = getelementptr inbounds nuw %struct.J, ptr %6, i32 0, i32 1
  %118 = load i16, ptr %117, align 2
  %119 = zext i16 %118 to i32
  %120 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sJ, i64 2), align 2
  %121 = zext i16 %120 to i32
  %122 = icmp ne i32 %119, %121
  br i1 %122, label %134, label %123

123:                                              ; preds = %116
  %124 = load i32, ptr %3, align 4
  %125 = load i32, ptr %4, align 4
  %126 = add i32 %124, %125
  %127 = load i32, ptr %2, align 4
  %128 = and i32 %126, %127
  %129 = urem i32 %128, 15
  %130 = load i32, ptr %2, align 4
  %131 = and i32 %129, %130
  %132 = load i32, ptr %5, align 4
  %133 = icmp ne i32 %131, %132
  br i1 %133, label %134, label %135

134:                                              ; preds = %123, %116, %108, %98, %79
  call void @abort() #4
  unreachable

135:                                              ; preds = %123
  %136 = call i32 @myrnd()
  store i32 %136, ptr %3, align 4
  %137 = call i32 @myrnd()
  store i32 %137, ptr %4, align 4
  %138 = load i32, ptr %3, align 4
  %139 = trunc i32 %138 to i16
  %140 = load i16, ptr @sJ, align 2
  %141 = and i16 %139, 127
  %142 = shl i16 %141, 9
  %143 = and i16 %140, 511
  %144 = or i16 %143, %142
  store i16 %144, ptr @sJ, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sJ, i64 4, i1 false)
  %145 = load i32, ptr %4, align 4
  %146 = call i32 @fn3J(i32 noundef %145)
  store i32 %146, ptr %5, align 4
  %147 = load i16, ptr %6, align 2
  %148 = and i16 %147, 1
  %149 = zext i16 %148 to i32
  %150 = load i16, ptr @sJ, align 2
  %151 = and i16 %150, 1
  %152 = zext i16 %151 to i32
  %153 = icmp ne i32 %149, %152
  br i1 %153, label %185, label %154

154:                                              ; preds = %135
  %155 = load i16, ptr %6, align 2
  %156 = lshr i16 %155, 1
  %157 = and i16 %156, 255
  %158 = zext i16 %157 to i32
  %159 = load i16, ptr @sJ, align 2
  %160 = lshr i16 %159, 1
  %161 = and i16 %160, 255
  %162 = zext i16 %161 to i32
  %163 = icmp ne i32 %158, %162
  br i1 %163, label %185, label %164

164:                                              ; preds = %154
  %165 = load i16, ptr @sJ, align 2
  %166 = lshr i16 %165, 9
  %167 = zext i16 %166 to i32
  %168 = load i32, ptr %5, align 4
  %169 = icmp ne i32 %167, %168
  br i1 %169, label %185, label %170

170:                                              ; preds = %164
  %171 = getelementptr inbounds nuw %struct.J, ptr %6, i32 0, i32 1
  %172 = load i16, ptr %171, align 2
  %173 = zext i16 %172 to i32
  %174 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sJ, i64 2), align 2
  %175 = zext i16 %174 to i32
  %176 = icmp ne i32 %173, %175
  br i1 %176, label %185, label %177

177:                                              ; preds = %170
  %178 = load i32, ptr %3, align 4
  %179 = load i32, ptr %4, align 4
  %180 = add i32 %178, %179
  %181 = load i32, ptr %2, align 4
  %182 = and i32 %180, %181
  %183 = load i32, ptr %5, align 4
  %184 = icmp ne i32 %182, %183
  br i1 %184, label %185, label %186

185:                                              ; preds = %177, %170, %164, %154, %135
  call void @abort() #4
  unreachable

186:                                              ; preds = %177
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retmeK(i32 %0) #0 {
  %2 = alloca %struct.K, align 4
  %3 = alloca %struct.K, align 4
  %4 = getelementptr inbounds nuw %struct.K, ptr %3, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 4, i1 false)
  %5 = getelementptr inbounds nuw %struct.K, ptr %2, i32 0, i32 0
  %6 = load i32, ptr %5, align 4
  ret i32 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1K(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.K, align 4
  %4 = alloca %struct.K, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sK, i64 4, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 4
  %7 = and i32 %6, 63
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 4
  %10 = and i32 %8, 63
  %11 = and i32 %9, -64
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 4
  %13 = getelementptr inbounds nuw %struct.K, ptr %3, i32 0, i32 0
  %14 = load i32, ptr %13, align 4
  %15 = call i32 @retmeK(i32 %14)
  %16 = getelementptr inbounds nuw %struct.K, ptr %4, i32 0, i32 0
  store i32 %15, ptr %16, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 4, i1 false)
  %17 = load i32, ptr %3, align 4
  %18 = and i32 %17, 63
  ret i32 %18
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2K(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.K, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sK, i64 4, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 4
  %6 = and i32 %5, 63
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 4
  %9 = and i32 %7, 63
  %10 = and i32 %8, -64
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 4
  %12 = load i32, ptr %3, align 4
  %13 = and i32 %12, 63
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 4
  %16 = and i32 %14, 63
  %17 = and i32 %15, -64
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 4
  %19 = load i32, ptr %3, align 4
  %20 = and i32 %19, 63
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitK() #0 {
  %1 = load i32, ptr @sK, align 4
  %2 = and i32 %1, 63
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3K(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sK, align 4
  %5 = and i32 %4, 63
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sK, align 4
  %8 = and i32 %6, 63
  %9 = and i32 %7, -64
  %10 = or i32 %9, %8
  store i32 %10, ptr @sK, align 4
  %11 = call i32 @retitK()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testK() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.K, align 4
  %7 = alloca ptr, align 8
  store ptr @sK, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 4
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !17

20:                                               ; preds = %8
  %21 = load i32, ptr @sK, align 4
  %22 = and i32 %21, -64
  %23 = or i32 %22, 63
  store i32 %23, ptr @sK, align 4
  %24 = load i32, ptr @sK, align 4
  %25 = and i32 %24, 63
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sK, align 4
  %30 = and i32 %28, 63
  %31 = and i32 %29, -64
  %32 = or i32 %31, %30
  store i32 %32, ptr @sK, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sK, i64 4, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1K(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 4
  %36 = lshr i32 %35, 17
  %37 = load i32, ptr @sK, align 4
  %38 = lshr i32 %37, 17
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %70, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 4
  %42 = lshr i32 %41, 7
  %43 = and i32 %42, 1023
  %44 = load i32, ptr @sK, align 4
  %45 = lshr i32 %44, 7
  %46 = and i32 %45, 1023
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %70, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 4
  %50 = and i32 %49, 63
  %51 = load i32, ptr @sK, align 4
  %52 = and i32 %51, 63
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %70, label %54

54:                                               ; preds = %48
  %55 = load i32, ptr %6, align 4
  %56 = lshr i32 %55, 6
  %57 = and i32 %56, 1
  %58 = load i32, ptr @sK, align 4
  %59 = lshr i32 %58, 6
  %60 = and i32 %59, 1
  %61 = icmp ne i32 %57, %60
  br i1 %61, label %70, label %62

62:                                               ; preds = %54
  %63 = load i32, ptr %3, align 4
  %64 = load i32, ptr %4, align 4
  %65 = add i32 %63, %64
  %66 = load i32, ptr %2, align 4
  %67 = and i32 %65, %66
  %68 = load i32, ptr %5, align 4
  %69 = icmp ne i32 %67, %68
  br i1 %69, label %70, label %71

70:                                               ; preds = %62, %54, %48, %40, %20
  call void @abort() #4
  unreachable

71:                                               ; preds = %62
  %72 = call i32 @myrnd()
  store i32 %72, ptr %3, align 4
  %73 = call i32 @myrnd()
  store i32 %73, ptr %4, align 4
  %74 = load i32, ptr %3, align 4
  %75 = load i32, ptr @sK, align 4
  %76 = and i32 %74, 63
  %77 = and i32 %75, -64
  %78 = or i32 %77, %76
  store i32 %78, ptr @sK, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sK, i64 4, i1 false)
  %79 = load i32, ptr %4, align 4
  %80 = call i32 @fn2K(i32 noundef %79)
  store i32 %80, ptr %5, align 4
  %81 = load i32, ptr %6, align 4
  %82 = lshr i32 %81, 17
  %83 = load i32, ptr @sK, align 4
  %84 = lshr i32 %83, 17
  %85 = icmp ne i32 %82, %84
  br i1 %85, label %119, label %86

86:                                               ; preds = %71
  %87 = load i32, ptr %6, align 4
  %88 = lshr i32 %87, 7
  %89 = and i32 %88, 1023
  %90 = load i32, ptr @sK, align 4
  %91 = lshr i32 %90, 7
  %92 = and i32 %91, 1023
  %93 = icmp ne i32 %89, %92
  br i1 %93, label %119, label %94

94:                                               ; preds = %86
  %95 = load i32, ptr %6, align 4
  %96 = and i32 %95, 63
  %97 = load i32, ptr @sK, align 4
  %98 = and i32 %97, 63
  %99 = icmp ne i32 %96, %98
  br i1 %99, label %119, label %100

100:                                              ; preds = %94
  %101 = load i32, ptr %6, align 4
  %102 = lshr i32 %101, 6
  %103 = and i32 %102, 1
  %104 = load i32, ptr @sK, align 4
  %105 = lshr i32 %104, 6
  %106 = and i32 %105, 1
  %107 = icmp ne i32 %103, %106
  br i1 %107, label %119, label %108

108:                                              ; preds = %100
  %109 = load i32, ptr %3, align 4
  %110 = load i32, ptr %4, align 4
  %111 = add i32 %109, %110
  %112 = load i32, ptr %2, align 4
  %113 = and i32 %111, %112
  %114 = urem i32 %113, 15
  %115 = load i32, ptr %2, align 4
  %116 = and i32 %114, %115
  %117 = load i32, ptr %5, align 4
  %118 = icmp ne i32 %116, %117
  br i1 %118, label %119, label %120

119:                                              ; preds = %108, %100, %94, %86, %71
  call void @abort() #4
  unreachable

120:                                              ; preds = %108
  %121 = call i32 @myrnd()
  store i32 %121, ptr %3, align 4
  %122 = call i32 @myrnd()
  store i32 %122, ptr %4, align 4
  %123 = load i32, ptr %3, align 4
  %124 = load i32, ptr @sK, align 4
  %125 = and i32 %123, 63
  %126 = and i32 %124, -64
  %127 = or i32 %126, %125
  store i32 %127, ptr @sK, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sK, i64 4, i1 false)
  %128 = load i32, ptr %4, align 4
  %129 = call i32 @fn3K(i32 noundef %128)
  store i32 %129, ptr %5, align 4
  %130 = load i32, ptr %6, align 4
  %131 = lshr i32 %130, 17
  %132 = load i32, ptr @sK, align 4
  %133 = lshr i32 %132, 17
  %134 = icmp ne i32 %131, %133
  br i1 %134, label %164, label %135

135:                                              ; preds = %120
  %136 = load i32, ptr %6, align 4
  %137 = lshr i32 %136, 7
  %138 = and i32 %137, 1023
  %139 = load i32, ptr @sK, align 4
  %140 = lshr i32 %139, 7
  %141 = and i32 %140, 1023
  %142 = icmp ne i32 %138, %141
  br i1 %142, label %164, label %143

143:                                              ; preds = %135
  %144 = load i32, ptr @sK, align 4
  %145 = and i32 %144, 63
  %146 = load i32, ptr %5, align 4
  %147 = icmp ne i32 %145, %146
  br i1 %147, label %164, label %148

148:                                              ; preds = %143
  %149 = load i32, ptr %6, align 4
  %150 = lshr i32 %149, 6
  %151 = and i32 %150, 1
  %152 = load i32, ptr @sK, align 4
  %153 = lshr i32 %152, 6
  %154 = and i32 %153, 1
  %155 = icmp ne i32 %151, %154
  br i1 %155, label %164, label %156

156:                                              ; preds = %148
  %157 = load i32, ptr %3, align 4
  %158 = load i32, ptr %4, align 4
  %159 = add i32 %157, %158
  %160 = load i32, ptr %2, align 4
  %161 = and i32 %159, %160
  %162 = load i32, ptr %5, align 4
  %163 = icmp ne i32 %161, %162
  br i1 %163, label %164, label %165

164:                                              ; preds = %156, %148, %143, %135, %120
  call void @abort() #4
  unreachable

165:                                              ; preds = %156
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeL(i64 %0) #0 {
  %2 = alloca %struct.L, align 4
  %3 = alloca %struct.L, align 4
  store i64 %0, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 8, i1 false)
  %4 = load i64, ptr %2, align 4
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1L(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.L, align 4
  %4 = alloca %struct.L, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sL, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 4
  %7 = and i32 %6, 63
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 4
  %10 = and i32 %8, 63
  %11 = and i32 %9, -64
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 4
  %13 = load i64, ptr %3, align 4
  %14 = call i64 @retmeL(i64 %13)
  store i64 %14, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 8, i1 false)
  %15 = load i32, ptr %3, align 4
  %16 = and i32 %15, 63
  ret i32 %16
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2L(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.L, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sL, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 4
  %6 = and i32 %5, 63
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 4
  %9 = and i32 %7, 63
  %10 = and i32 %8, -64
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 4
  %12 = load i32, ptr %3, align 4
  %13 = and i32 %12, 63
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 4
  %16 = and i32 %14, 63
  %17 = and i32 %15, -64
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 4
  %19 = load i32, ptr %3, align 4
  %20 = and i32 %19, 63
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitL() #0 {
  %1 = load i32, ptr @sL, align 4
  %2 = and i32 %1, 63
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3L(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sL, align 4
  %5 = and i32 %4, 63
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sL, align 4
  %8 = and i32 %6, 63
  %9 = and i32 %7, -64
  %10 = or i32 %9, %8
  store i32 %10, ptr @sL, align 4
  %11 = call i32 @retitL()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testL() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.L, align 4
  %7 = alloca ptr, align 8
  store ptr @sL, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !18

20:                                               ; preds = %8
  %21 = load i32, ptr @sL, align 4
  %22 = and i32 %21, -64
  %23 = or i32 %22, 63
  store i32 %23, ptr @sL, align 4
  %24 = load i32, ptr @sL, align 4
  %25 = and i32 %24, 63
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sL, align 4
  %30 = and i32 %28, 63
  %31 = and i32 %29, -64
  %32 = or i32 %31, %30
  store i32 %32, ptr @sL, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sL, i64 8, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1L(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 4
  %36 = lshr i32 %35, 17
  %37 = load i32, ptr @sL, align 4
  %38 = lshr i32 %37, 17
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %67, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 4
  %42 = lshr i32 %41, 6
  %43 = and i32 %42, 2047
  %44 = load i32, ptr @sL, align 4
  %45 = lshr i32 %44, 6
  %46 = and i32 %45, 2047
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %67, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 4
  %50 = and i32 %49, 63
  %51 = load i32, ptr @sL, align 4
  %52 = and i32 %51, 63
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %67, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw %struct.L, ptr %6, i32 0, i32 1
  %56 = load i32, ptr %55, align 4
  %57 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sL, i64 4), align 4
  %58 = icmp ne i32 %56, %57
  br i1 %58, label %67, label %59

59:                                               ; preds = %54
  %60 = load i32, ptr %3, align 4
  %61 = load i32, ptr %4, align 4
  %62 = add i32 %60, %61
  %63 = load i32, ptr %2, align 4
  %64 = and i32 %62, %63
  %65 = load i32, ptr %5, align 4
  %66 = icmp ne i32 %64, %65
  br i1 %66, label %67, label %68

67:                                               ; preds = %59, %54, %48, %40, %20
  call void @abort() #4
  unreachable

68:                                               ; preds = %59
  %69 = call i32 @myrnd()
  store i32 %69, ptr %3, align 4
  %70 = call i32 @myrnd()
  store i32 %70, ptr %4, align 4
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr @sL, align 4
  %73 = and i32 %71, 63
  %74 = and i32 %72, -64
  %75 = or i32 %74, %73
  store i32 %75, ptr @sL, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sL, i64 8, i1 false)
  %76 = load i32, ptr %4, align 4
  %77 = call i32 @fn2L(i32 noundef %76)
  store i32 %77, ptr %5, align 4
  %78 = load i32, ptr %6, align 4
  %79 = lshr i32 %78, 17
  %80 = load i32, ptr @sL, align 4
  %81 = lshr i32 %80, 17
  %82 = icmp ne i32 %79, %81
  br i1 %82, label %113, label %83

83:                                               ; preds = %68
  %84 = load i32, ptr %6, align 4
  %85 = lshr i32 %84, 6
  %86 = and i32 %85, 2047
  %87 = load i32, ptr @sL, align 4
  %88 = lshr i32 %87, 6
  %89 = and i32 %88, 2047
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %113, label %91

91:                                               ; preds = %83
  %92 = load i32, ptr %6, align 4
  %93 = and i32 %92, 63
  %94 = load i32, ptr @sL, align 4
  %95 = and i32 %94, 63
  %96 = icmp ne i32 %93, %95
  br i1 %96, label %113, label %97

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw %struct.L, ptr %6, i32 0, i32 1
  %99 = load i32, ptr %98, align 4
  %100 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sL, i64 4), align 4
  %101 = icmp ne i32 %99, %100
  br i1 %101, label %113, label %102

102:                                              ; preds = %97
  %103 = load i32, ptr %3, align 4
  %104 = load i32, ptr %4, align 4
  %105 = add i32 %103, %104
  %106 = load i32, ptr %2, align 4
  %107 = and i32 %105, %106
  %108 = urem i32 %107, 15
  %109 = load i32, ptr %2, align 4
  %110 = and i32 %108, %109
  %111 = load i32, ptr %5, align 4
  %112 = icmp ne i32 %110, %111
  br i1 %112, label %113, label %114

113:                                              ; preds = %102, %97, %91, %83, %68
  call void @abort() #4
  unreachable

114:                                              ; preds = %102
  %115 = call i32 @myrnd()
  store i32 %115, ptr %3, align 4
  %116 = call i32 @myrnd()
  store i32 %116, ptr %4, align 4
  %117 = load i32, ptr %3, align 4
  %118 = load i32, ptr @sL, align 4
  %119 = and i32 %117, 63
  %120 = and i32 %118, -64
  %121 = or i32 %120, %119
  store i32 %121, ptr @sL, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sL, i64 8, i1 false)
  %122 = load i32, ptr %4, align 4
  %123 = call i32 @fn3L(i32 noundef %122)
  store i32 %123, ptr %5, align 4
  %124 = load i32, ptr %6, align 4
  %125 = lshr i32 %124, 17
  %126 = load i32, ptr @sL, align 4
  %127 = lshr i32 %126, 17
  %128 = icmp ne i32 %125, %127
  br i1 %128, label %155, label %129

129:                                              ; preds = %114
  %130 = load i32, ptr %6, align 4
  %131 = lshr i32 %130, 6
  %132 = and i32 %131, 2047
  %133 = load i32, ptr @sL, align 4
  %134 = lshr i32 %133, 6
  %135 = and i32 %134, 2047
  %136 = icmp ne i32 %132, %135
  br i1 %136, label %155, label %137

137:                                              ; preds = %129
  %138 = load i32, ptr @sL, align 4
  %139 = and i32 %138, 63
  %140 = load i32, ptr %5, align 4
  %141 = icmp ne i32 %139, %140
  br i1 %141, label %155, label %142

142:                                              ; preds = %137
  %143 = getelementptr inbounds nuw %struct.L, ptr %6, i32 0, i32 1
  %144 = load i32, ptr %143, align 4
  %145 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sL, i64 4), align 4
  %146 = icmp ne i32 %144, %145
  br i1 %146, label %155, label %147

147:                                              ; preds = %142
  %148 = load i32, ptr %3, align 4
  %149 = load i32, ptr %4, align 4
  %150 = add i32 %148, %149
  %151 = load i32, ptr %2, align 4
  %152 = and i32 %150, %151
  %153 = load i32, ptr %5, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %155, label %156

155:                                              ; preds = %147, %142, %137, %129, %114
  call void @abort() #4
  unreachable

156:                                              ; preds = %147
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeM(i64 %0) #0 {
  %2 = alloca %struct.M, align 4
  %3 = alloca %struct.M, align 4
  store i64 %0, ptr %3, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %3, i64 8, i1 false)
  %4 = load i64, ptr %2, align 4
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1M(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.M, align 4
  %4 = alloca %struct.M, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sM, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.M, ptr %3, i32 0, i32 1
  %7 = load i32, ptr %6, align 4
  %8 = and i32 %7, 63
  %9 = add i32 %8, %5
  %10 = load i32, ptr %6, align 4
  %11 = and i32 %9, 63
  %12 = and i32 %10, -64
  %13 = or i32 %12, %11
  store i32 %13, ptr %6, align 4
  %14 = load i64, ptr %3, align 4
  %15 = call i64 @retmeM(i64 %14)
  store i64 %15, ptr %4, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 %4, i64 8, i1 false)
  %16 = getelementptr inbounds nuw %struct.M, ptr %3, i32 0, i32 1
  %17 = load i32, ptr %16, align 4
  %18 = and i32 %17, 63
  ret i32 %18
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2M(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.M, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @sM, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.M, ptr %3, i32 0, i32 1
  %6 = load i32, ptr %5, align 4
  %7 = and i32 %6, 63
  %8 = add i32 %7, %4
  %9 = load i32, ptr %5, align 4
  %10 = and i32 %8, 63
  %11 = and i32 %9, -64
  %12 = or i32 %11, %10
  store i32 %12, ptr %5, align 4
  %13 = getelementptr inbounds nuw %struct.M, ptr %3, i32 0, i32 1
  %14 = load i32, ptr %13, align 4
  %15 = and i32 %14, 63
  %16 = srem i32 %15, 15
  %17 = load i32, ptr %13, align 4
  %18 = and i32 %16, 63
  %19 = and i32 %17, -64
  %20 = or i32 %19, %18
  store i32 %20, ptr %13, align 4
  %21 = getelementptr inbounds nuw %struct.M, ptr %3, i32 0, i32 1
  %22 = load i32, ptr %21, align 4
  %23 = and i32 %22, 63
  ret i32 %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitM() #0 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %2 = and i32 %1, 63
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3M(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %5 = and i32 %4, 63
  %6 = add i32 %5, %3
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %8 = and i32 %6, 63
  %9 = and i32 %7, -64
  %10 = or i32 %9, %8
  store i32 %10, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %11 = call i32 @retitM()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testM() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.M, align 4
  %7 = alloca ptr, align 8
  store ptr @sM, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !19

20:                                               ; preds = %8
  %21 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %22 = and i32 %21, -64
  %23 = or i32 %22, 63
  store i32 %23, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %25 = and i32 %24, 63
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %30 = and i32 %28, 63
  %31 = and i32 %29, -64
  %32 = or i32 %31, %30
  store i32 %32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sM, i64 8, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1M(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = lshr i32 %36, 17
  %38 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %39 = lshr i32 %38, 17
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %70, label %41

41:                                               ; preds = %20
  %42 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %43 = load i32, ptr %42, align 4
  %44 = lshr i32 %43, 6
  %45 = and i32 %44, 2047
  %46 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %47 = lshr i32 %46, 6
  %48 = and i32 %47, 2047
  %49 = icmp ne i32 %45, %48
  br i1 %49, label %70, label %50

50:                                               ; preds = %41
  %51 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %52 = load i32, ptr %51, align 4
  %53 = and i32 %52, 63
  %54 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %55 = and i32 %54, 63
  %56 = icmp ne i32 %53, %55
  br i1 %56, label %70, label %57

57:                                               ; preds = %50
  %58 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 0
  %59 = load i32, ptr %58, align 4
  %60 = load i32, ptr @sM, align 4
  %61 = icmp ne i32 %59, %60
  br i1 %61, label %70, label %62

62:                                               ; preds = %57
  %63 = load i32, ptr %3, align 4
  %64 = load i32, ptr %4, align 4
  %65 = add i32 %63, %64
  %66 = load i32, ptr %2, align 4
  %67 = and i32 %65, %66
  %68 = load i32, ptr %5, align 4
  %69 = icmp ne i32 %67, %68
  br i1 %69, label %70, label %71

70:                                               ; preds = %62, %57, %50, %41, %20
  call void @abort() #4
  unreachable

71:                                               ; preds = %62
  %72 = call i32 @myrnd()
  store i32 %72, ptr %3, align 4
  %73 = call i32 @myrnd()
  store i32 %73, ptr %4, align 4
  %74 = load i32, ptr %3, align 4
  %75 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %76 = and i32 %74, 63
  %77 = and i32 %75, -64
  %78 = or i32 %77, %76
  store i32 %78, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sM, i64 8, i1 false)
  %79 = load i32, ptr %4, align 4
  %80 = call i32 @fn2M(i32 noundef %79)
  store i32 %80, ptr %5, align 4
  %81 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %82 = load i32, ptr %81, align 4
  %83 = lshr i32 %82, 17
  %84 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %85 = lshr i32 %84, 17
  %86 = icmp ne i32 %83, %85
  br i1 %86, label %119, label %87

87:                                               ; preds = %71
  %88 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %89 = load i32, ptr %88, align 4
  %90 = lshr i32 %89, 6
  %91 = and i32 %90, 2047
  %92 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %93 = lshr i32 %92, 6
  %94 = and i32 %93, 2047
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %119, label %96

96:                                               ; preds = %87
  %97 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %98 = load i32, ptr %97, align 4
  %99 = and i32 %98, 63
  %100 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %101 = and i32 %100, 63
  %102 = icmp ne i32 %99, %101
  br i1 %102, label %119, label %103

103:                                              ; preds = %96
  %104 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 0
  %105 = load i32, ptr %104, align 4
  %106 = load i32, ptr @sM, align 4
  %107 = icmp ne i32 %105, %106
  br i1 %107, label %119, label %108

108:                                              ; preds = %103
  %109 = load i32, ptr %3, align 4
  %110 = load i32, ptr %4, align 4
  %111 = add i32 %109, %110
  %112 = load i32, ptr %2, align 4
  %113 = and i32 %111, %112
  %114 = urem i32 %113, 15
  %115 = load i32, ptr %2, align 4
  %116 = and i32 %114, %115
  %117 = load i32, ptr %5, align 4
  %118 = icmp ne i32 %116, %117
  br i1 %118, label %119, label %120

119:                                              ; preds = %108, %103, %96, %87, %71
  call void @abort() #4
  unreachable

120:                                              ; preds = %108
  %121 = call i32 @myrnd()
  store i32 %121, ptr %3, align 4
  %122 = call i32 @myrnd()
  store i32 %122, ptr %4, align 4
  %123 = load i32, ptr %3, align 4
  %124 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %125 = and i32 %123, 63
  %126 = and i32 %124, -64
  %127 = or i32 %126, %125
  store i32 %127, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 @sM, i64 8, i1 false)
  %128 = load i32, ptr %4, align 4
  %129 = call i32 @fn3M(i32 noundef %128)
  store i32 %129, ptr %5, align 4
  %130 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %131 = load i32, ptr %130, align 4
  %132 = lshr i32 %131, 17
  %133 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %134 = lshr i32 %133, 17
  %135 = icmp ne i32 %132, %134
  br i1 %135, label %163, label %136

136:                                              ; preds = %120
  %137 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 1
  %138 = load i32, ptr %137, align 4
  %139 = lshr i32 %138, 6
  %140 = and i32 %139, 2047
  %141 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %142 = lshr i32 %141, 6
  %143 = and i32 %142, 2047
  %144 = icmp ne i32 %140, %143
  br i1 %144, label %163, label %145

145:                                              ; preds = %136
  %146 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sM, i64 4), align 4
  %147 = and i32 %146, 63
  %148 = load i32, ptr %5, align 4
  %149 = icmp ne i32 %147, %148
  br i1 %149, label %163, label %150

150:                                              ; preds = %145
  %151 = getelementptr inbounds nuw %struct.M, ptr %6, i32 0, i32 0
  %152 = load i32, ptr %151, align 4
  %153 = load i32, ptr @sM, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %163, label %155

155:                                              ; preds = %150
  %156 = load i32, ptr %3, align 4
  %157 = load i32, ptr %4, align 4
  %158 = add i32 %156, %157
  %159 = load i32, ptr %2, align 4
  %160 = and i32 %158, %159
  %161 = load i32, ptr %5, align 4
  %162 = icmp ne i32 %160, %161
  br i1 %162, label %163, label %164

163:                                              ; preds = %155, %150, %145, %136, %120
  call void @abort() #4
  unreachable

164:                                              ; preds = %155
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @retmeN(i64 %0) #0 {
  %2 = alloca %struct.N, align 8
  %3 = alloca %struct.N, align 8
  %4 = getelementptr inbounds nuw %struct.N, ptr %3, i32 0, i32 0
  store i64 %0, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %2, ptr align 8 %3, i64 8, i1 false)
  %5 = getelementptr inbounds nuw %struct.N, ptr %2, i32 0, i32 0
  %6 = load i64, ptr %5, align 8
  ret i64 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1N(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.N, align 8
  %4 = alloca %struct.N, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sN, i64 8, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i64, ptr %3, align 8
  %7 = lshr i64 %6, 6
  %8 = and i64 %7, 63
  %9 = trunc i64 %8 to i32
  %10 = add i32 %9, %5
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %3, align 8
  %13 = and i64 %11, 63
  %14 = shl i64 %13, 6
  %15 = and i64 %12, -4033
  %16 = or i64 %15, %14
  store i64 %16, ptr %3, align 8
  %17 = getelementptr inbounds nuw %struct.N, ptr %3, i32 0, i32 0
  %18 = load i64, ptr %17, align 8
  %19 = call i64 @retmeN(i64 %18)
  %20 = getelementptr inbounds nuw %struct.N, ptr %4, i32 0, i32 0
  store i64 %19, ptr %20, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 8, i1 false)
  %21 = load i64, ptr %3, align 8
  %22 = lshr i64 %21, 6
  %23 = and i64 %22, 63
  %24 = trunc i64 %23 to i32
  ret i32 %24
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2N(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.N, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sN, i64 8, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i64, ptr %3, align 8
  %6 = lshr i64 %5, 6
  %7 = and i64 %6, 63
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %4
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %3, align 8
  %12 = and i64 %10, 63
  %13 = shl i64 %12, 6
  %14 = and i64 %11, -4033
  %15 = or i64 %14, %13
  store i64 %15, ptr %3, align 8
  %16 = load i64, ptr %3, align 8
  %17 = lshr i64 %16, 6
  %18 = and i64 %17, 63
  %19 = trunc i64 %18 to i32
  %20 = srem i32 %19, 15
  %21 = sext i32 %20 to i64
  %22 = load i64, ptr %3, align 8
  %23 = and i64 %21, 63
  %24 = shl i64 %23, 6
  %25 = and i64 %22, -4033
  %26 = or i64 %25, %24
  store i64 %26, ptr %3, align 8
  %27 = load i64, ptr %3, align 8
  %28 = lshr i64 %27, 6
  %29 = and i64 %28, 63
  %30 = trunc i64 %29 to i32
  ret i32 %30
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitN() #0 {
  %1 = load i64, ptr @sN, align 8
  %2 = lshr i64 %1, 6
  %3 = and i64 %2, 63
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3N(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr @sN, align 8
  %5 = lshr i64 %4, 6
  %6 = and i64 %5, 63
  %7 = trunc i64 %6 to i32
  %8 = add i32 %7, %3
  %9 = zext i32 %8 to i64
  %10 = load i64, ptr @sN, align 8
  %11 = and i64 %9, 63
  %12 = shl i64 %11, 6
  %13 = and i64 %10, -4033
  %14 = or i64 %13, %12
  store i64 %14, ptr @sN, align 8
  %15 = call i32 @retitN()
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testN() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.N, align 8
  %7 = alloca ptr, align 8
  store ptr @sN, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 8
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !20

20:                                               ; preds = %8
  %21 = load i64, ptr @sN, align 8
  %22 = and i64 %21, -4033
  %23 = or i64 %22, 4032
  store i64 %23, ptr @sN, align 8
  %24 = load i64, ptr @sN, align 8
  %25 = lshr i64 %24, 6
  %26 = and i64 %25, 63
  %27 = trunc i64 %26 to i32
  store i32 %27, ptr %2, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %3, align 4
  %29 = call i32 @myrnd()
  store i32 %29, ptr %4, align 4
  %30 = load i32, ptr %3, align 4
  %31 = zext i32 %30 to i64
  %32 = load i64, ptr @sN, align 8
  %33 = and i64 %31, 63
  %34 = shl i64 %33, 6
  %35 = and i64 %32, -4033
  %36 = or i64 %35, %34
  store i64 %36, ptr @sN, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sN, i64 8, i1 false)
  %37 = load i32, ptr %4, align 4
  %38 = call i32 @fn1N(i32 noundef %37)
  store i32 %38, ptr %5, align 4
  %39 = load i64, ptr %6, align 8
  %40 = lshr i64 %39, 35
  %41 = trunc i64 %40 to i32
  %42 = load i64, ptr @sN, align 8
  %43 = lshr i64 %42, 35
  %44 = trunc i64 %43 to i32
  %45 = icmp ne i32 %41, %44
  br i1 %45, label %82, label %46

46:                                               ; preds = %20
  %47 = load i64, ptr %6, align 8
  %48 = lshr i64 %47, 12
  %49 = and i64 %48, 8388607
  %50 = trunc i64 %49 to i32
  %51 = load i64, ptr @sN, align 8
  %52 = lshr i64 %51, 12
  %53 = and i64 %52, 8388607
  %54 = trunc i64 %53 to i32
  %55 = icmp ne i32 %50, %54
  br i1 %55, label %82, label %56

56:                                               ; preds = %46
  %57 = load i64, ptr %6, align 8
  %58 = lshr i64 %57, 6
  %59 = and i64 %58, 63
  %60 = trunc i64 %59 to i32
  %61 = load i64, ptr @sN, align 8
  %62 = lshr i64 %61, 6
  %63 = and i64 %62, 63
  %64 = trunc i64 %63 to i32
  %65 = icmp ne i32 %60, %64
  br i1 %65, label %82, label %66

66:                                               ; preds = %56
  %67 = load i64, ptr %6, align 8
  %68 = and i64 %67, 63
  %69 = trunc i64 %68 to i32
  %70 = load i64, ptr @sN, align 8
  %71 = and i64 %70, 63
  %72 = trunc i64 %71 to i32
  %73 = icmp ne i32 %69, %72
  br i1 %73, label %82, label %74

74:                                               ; preds = %66
  %75 = load i32, ptr %3, align 4
  %76 = load i32, ptr %4, align 4
  %77 = add i32 %75, %76
  %78 = load i32, ptr %2, align 4
  %79 = and i32 %77, %78
  %80 = load i32, ptr %5, align 4
  %81 = icmp ne i32 %79, %80
  br i1 %81, label %82, label %83

82:                                               ; preds = %74, %66, %56, %46, %20
  call void @abort() #4
  unreachable

83:                                               ; preds = %74
  %84 = call i32 @myrnd()
  store i32 %84, ptr %3, align 4
  %85 = call i32 @myrnd()
  store i32 %85, ptr %4, align 4
  %86 = load i32, ptr %3, align 4
  %87 = zext i32 %86 to i64
  %88 = load i64, ptr @sN, align 8
  %89 = and i64 %87, 63
  %90 = shl i64 %89, 6
  %91 = and i64 %88, -4033
  %92 = or i64 %91, %90
  store i64 %92, ptr @sN, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sN, i64 8, i1 false)
  %93 = load i32, ptr %4, align 4
  %94 = call i32 @fn2N(i32 noundef %93)
  store i32 %94, ptr %5, align 4
  %95 = load i64, ptr %6, align 8
  %96 = lshr i64 %95, 35
  %97 = trunc i64 %96 to i32
  %98 = load i64, ptr @sN, align 8
  %99 = lshr i64 %98, 35
  %100 = trunc i64 %99 to i32
  %101 = icmp ne i32 %97, %100
  br i1 %101, label %141, label %102

102:                                              ; preds = %83
  %103 = load i64, ptr %6, align 8
  %104 = lshr i64 %103, 12
  %105 = and i64 %104, 8388607
  %106 = trunc i64 %105 to i32
  %107 = load i64, ptr @sN, align 8
  %108 = lshr i64 %107, 12
  %109 = and i64 %108, 8388607
  %110 = trunc i64 %109 to i32
  %111 = icmp ne i32 %106, %110
  br i1 %111, label %141, label %112

112:                                              ; preds = %102
  %113 = load i64, ptr %6, align 8
  %114 = lshr i64 %113, 6
  %115 = and i64 %114, 63
  %116 = trunc i64 %115 to i32
  %117 = load i64, ptr @sN, align 8
  %118 = lshr i64 %117, 6
  %119 = and i64 %118, 63
  %120 = trunc i64 %119 to i32
  %121 = icmp ne i32 %116, %120
  br i1 %121, label %141, label %122

122:                                              ; preds = %112
  %123 = load i64, ptr %6, align 8
  %124 = and i64 %123, 63
  %125 = trunc i64 %124 to i32
  %126 = load i64, ptr @sN, align 8
  %127 = and i64 %126, 63
  %128 = trunc i64 %127 to i32
  %129 = icmp ne i32 %125, %128
  br i1 %129, label %141, label %130

130:                                              ; preds = %122
  %131 = load i32, ptr %3, align 4
  %132 = load i32, ptr %4, align 4
  %133 = add i32 %131, %132
  %134 = load i32, ptr %2, align 4
  %135 = and i32 %133, %134
  %136 = urem i32 %135, 15
  %137 = load i32, ptr %2, align 4
  %138 = and i32 %136, %137
  %139 = load i32, ptr %5, align 4
  %140 = icmp ne i32 %138, %139
  br i1 %140, label %141, label %142

141:                                              ; preds = %130, %122, %112, %102, %83
  call void @abort() #4
  unreachable

142:                                              ; preds = %130
  %143 = call i32 @myrnd()
  store i32 %143, ptr %3, align 4
  %144 = call i32 @myrnd()
  store i32 %144, ptr %4, align 4
  %145 = load i32, ptr %3, align 4
  %146 = zext i32 %145 to i64
  %147 = load i64, ptr @sN, align 8
  %148 = and i64 %146, 63
  %149 = shl i64 %148, 6
  %150 = and i64 %147, -4033
  %151 = or i64 %150, %149
  store i64 %151, ptr @sN, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sN, i64 8, i1 false)
  %152 = load i32, ptr %4, align 4
  %153 = call i32 @fn3N(i32 noundef %152)
  store i32 %153, ptr %5, align 4
  %154 = load i64, ptr %6, align 8
  %155 = lshr i64 %154, 35
  %156 = trunc i64 %155 to i32
  %157 = load i64, ptr @sN, align 8
  %158 = lshr i64 %157, 35
  %159 = trunc i64 %158 to i32
  %160 = icmp ne i32 %156, %159
  br i1 %160, label %194, label %161

161:                                              ; preds = %142
  %162 = load i64, ptr %6, align 8
  %163 = lshr i64 %162, 12
  %164 = and i64 %163, 8388607
  %165 = trunc i64 %164 to i32
  %166 = load i64, ptr @sN, align 8
  %167 = lshr i64 %166, 12
  %168 = and i64 %167, 8388607
  %169 = trunc i64 %168 to i32
  %170 = icmp ne i32 %165, %169
  br i1 %170, label %194, label %171

171:                                              ; preds = %161
  %172 = load i64, ptr @sN, align 8
  %173 = lshr i64 %172, 6
  %174 = and i64 %173, 63
  %175 = trunc i64 %174 to i32
  %176 = load i32, ptr %5, align 4
  %177 = icmp ne i32 %175, %176
  br i1 %177, label %194, label %178

178:                                              ; preds = %171
  %179 = load i64, ptr %6, align 8
  %180 = and i64 %179, 63
  %181 = trunc i64 %180 to i32
  %182 = load i64, ptr @sN, align 8
  %183 = and i64 %182, 63
  %184 = trunc i64 %183 to i32
  %185 = icmp ne i32 %181, %184
  br i1 %185, label %194, label %186

186:                                              ; preds = %178
  %187 = load i32, ptr %3, align 4
  %188 = load i32, ptr %4, align 4
  %189 = add i32 %187, %188
  %190 = load i32, ptr %2, align 4
  %191 = and i32 %189, %190
  %192 = load i32, ptr %5, align 4
  %193 = icmp ne i32 %191, %192
  br i1 %193, label %194, label %195

194:                                              ; preds = %186, %178, %171, %161, %142
  call void @abort() #4
  unreachable

195:                                              ; preds = %186
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeO(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.O, align 8
  %4 = alloca %struct.O, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1O(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.O, align 8
  %4 = alloca %struct.O, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sO, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.O, ptr %3, i32 0, i32 1
  %7 = load i64, ptr %6, align 8
  %8 = and i64 %7, 4095
  %9 = trunc i64 %8 to i32
  %10 = add i32 %9, %5
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %6, align 8
  %13 = and i64 %11, 4095
  %14 = and i64 %12, -4096
  %15 = or i64 %14, %13
  store i64 %15, ptr %6, align 8
  %16 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %17 = load i64, ptr %16, align 8
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %19 = load i64, ptr %18, align 8
  %20 = call { i64, i64 } @retmeO(i64 %17, i64 %19)
  %21 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %22 = extractvalue { i64, i64 } %20, 0
  store i64 %22, ptr %21, align 8
  %23 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %24 = extractvalue { i64, i64 } %20, 1
  store i64 %24, ptr %23, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %25 = getelementptr inbounds nuw %struct.O, ptr %3, i32 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = and i64 %26, 4095
  %28 = trunc i64 %27 to i32
  ret i32 %28
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2O(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.O, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sO, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.O, ptr %3, i32 0, i32 1
  %6 = load i64, ptr %5, align 8
  %7 = and i64 %6, 4095
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %4
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %5, align 8
  %12 = and i64 %10, 4095
  %13 = and i64 %11, -4096
  %14 = or i64 %13, %12
  store i64 %14, ptr %5, align 8
  %15 = getelementptr inbounds nuw %struct.O, ptr %3, i32 0, i32 1
  %16 = load i64, ptr %15, align 8
  %17 = and i64 %16, 4095
  %18 = trunc i64 %17 to i32
  %19 = srem i32 %18, 15
  %20 = sext i32 %19 to i64
  %21 = load i64, ptr %15, align 8
  %22 = and i64 %20, 4095
  %23 = and i64 %21, -4096
  %24 = or i64 %23, %22
  store i64 %24, ptr %15, align 8
  %25 = getelementptr inbounds nuw %struct.O, ptr %3, i32 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = and i64 %26, 4095
  %28 = trunc i64 %27 to i32
  ret i32 %28
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitO() #0 {
  %1 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %2 = and i64 %1, 4095
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3O(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %5 = and i64 %4, 4095
  %6 = trunc i64 %5 to i32
  %7 = add i32 %6, %3
  %8 = zext i32 %7 to i64
  %9 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %10 = and i64 %8, 4095
  %11 = and i64 %9, -4096
  %12 = or i64 %11, %10
  store i64 %12, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %13 = call i32 @retitO()
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testO() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.O, align 8
  %7 = alloca ptr, align 8
  store ptr @sO, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !21

20:                                               ; preds = %8
  %21 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %22 = and i64 %21, -4096
  %23 = or i64 %22, 4095
  store i64 %23, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %24 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %25 = and i64 %24, 4095
  %26 = trunc i64 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = zext i32 %29 to i64
  %31 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %32 = and i64 %30, 4095
  %33 = and i64 %31, -4096
  %34 = or i64 %33, %32
  store i64 %34, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sO, i64 16, i1 false)
  %35 = load i32, ptr %4, align 4
  %36 = call i32 @fn1O(i32 noundef %35)
  store i32 %36, ptr %5, align 4
  %37 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %38 = load i64, ptr %37, align 8
  %39 = lshr i64 %38, 35
  %40 = trunc i64 %39 to i32
  %41 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %42 = lshr i64 %41, 35
  %43 = trunc i64 %42 to i32
  %44 = icmp ne i32 %40, %43
  br i1 %44, label %78, label %45

45:                                               ; preds = %20
  %46 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %47 = load i64, ptr %46, align 8
  %48 = lshr i64 %47, 12
  %49 = and i64 %48, 8388607
  %50 = trunc i64 %49 to i32
  %51 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %52 = lshr i64 %51, 12
  %53 = and i64 %52, 8388607
  %54 = trunc i64 %53 to i32
  %55 = icmp ne i32 %50, %54
  br i1 %55, label %78, label %56

56:                                               ; preds = %45
  %57 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %58 = load i64, ptr %57, align 8
  %59 = and i64 %58, 4095
  %60 = trunc i64 %59 to i32
  %61 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %62 = and i64 %61, 4095
  %63 = trunc i64 %62 to i32
  %64 = icmp ne i32 %60, %63
  br i1 %64, label %78, label %65

65:                                               ; preds = %56
  %66 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 0
  %67 = load i64, ptr %66, align 8
  %68 = load i64, ptr @sO, align 8
  %69 = icmp ne i64 %67, %68
  br i1 %69, label %78, label %70

70:                                               ; preds = %65
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr %4, align 4
  %73 = add i32 %71, %72
  %74 = load i32, ptr %2, align 4
  %75 = and i32 %73, %74
  %76 = load i32, ptr %5, align 4
  %77 = icmp ne i32 %75, %76
  br i1 %77, label %78, label %79

78:                                               ; preds = %70, %65, %56, %45, %20
  call void @abort() #4
  unreachable

79:                                               ; preds = %70
  %80 = call i32 @myrnd()
  store i32 %80, ptr %3, align 4
  %81 = call i32 @myrnd()
  store i32 %81, ptr %4, align 4
  %82 = load i32, ptr %3, align 4
  %83 = zext i32 %82 to i64
  %84 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %85 = and i64 %83, 4095
  %86 = and i64 %84, -4096
  %87 = or i64 %86, %85
  store i64 %87, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sO, i64 16, i1 false)
  %88 = load i32, ptr %4, align 4
  %89 = call i32 @fn2O(i32 noundef %88)
  store i32 %89, ptr %5, align 4
  %90 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %91 = load i64, ptr %90, align 8
  %92 = lshr i64 %91, 35
  %93 = trunc i64 %92 to i32
  %94 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %95 = lshr i64 %94, 35
  %96 = trunc i64 %95 to i32
  %97 = icmp ne i32 %93, %96
  br i1 %97, label %134, label %98

98:                                               ; preds = %79
  %99 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %100 = load i64, ptr %99, align 8
  %101 = lshr i64 %100, 12
  %102 = and i64 %101, 8388607
  %103 = trunc i64 %102 to i32
  %104 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %105 = lshr i64 %104, 12
  %106 = and i64 %105, 8388607
  %107 = trunc i64 %106 to i32
  %108 = icmp ne i32 %103, %107
  br i1 %108, label %134, label %109

109:                                              ; preds = %98
  %110 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %111 = load i64, ptr %110, align 8
  %112 = and i64 %111, 4095
  %113 = trunc i64 %112 to i32
  %114 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %115 = and i64 %114, 4095
  %116 = trunc i64 %115 to i32
  %117 = icmp ne i32 %113, %116
  br i1 %117, label %134, label %118

118:                                              ; preds = %109
  %119 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 0
  %120 = load i64, ptr %119, align 8
  %121 = load i64, ptr @sO, align 8
  %122 = icmp ne i64 %120, %121
  br i1 %122, label %134, label %123

123:                                              ; preds = %118
  %124 = load i32, ptr %3, align 4
  %125 = load i32, ptr %4, align 4
  %126 = add i32 %124, %125
  %127 = load i32, ptr %2, align 4
  %128 = and i32 %126, %127
  %129 = urem i32 %128, 15
  %130 = load i32, ptr %2, align 4
  %131 = and i32 %129, %130
  %132 = load i32, ptr %5, align 4
  %133 = icmp ne i32 %131, %132
  br i1 %133, label %134, label %135

134:                                              ; preds = %123, %118, %109, %98, %79
  call void @abort() #4
  unreachable

135:                                              ; preds = %123
  %136 = call i32 @myrnd()
  store i32 %136, ptr %3, align 4
  %137 = call i32 @myrnd()
  store i32 %137, ptr %4, align 4
  %138 = load i32, ptr %3, align 4
  %139 = zext i32 %138 to i64
  %140 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %141 = and i64 %139, 4095
  %142 = and i64 %140, -4096
  %143 = or i64 %142, %141
  store i64 %143, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sO, i64 16, i1 false)
  %144 = load i32, ptr %4, align 4
  %145 = call i32 @fn3O(i32 noundef %144)
  store i32 %145, ptr %5, align 4
  %146 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %147 = load i64, ptr %146, align 8
  %148 = lshr i64 %147, 35
  %149 = trunc i64 %148 to i32
  %150 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %151 = lshr i64 %150, 35
  %152 = trunc i64 %151 to i32
  %153 = icmp ne i32 %149, %152
  br i1 %153, label %184, label %154

154:                                              ; preds = %135
  %155 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 1
  %156 = load i64, ptr %155, align 8
  %157 = lshr i64 %156, 12
  %158 = and i64 %157, 8388607
  %159 = trunc i64 %158 to i32
  %160 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %161 = lshr i64 %160, 12
  %162 = and i64 %161, 8388607
  %163 = trunc i64 %162 to i32
  %164 = icmp ne i32 %159, %163
  br i1 %164, label %184, label %165

165:                                              ; preds = %154
  %166 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sO, i64 8), align 8
  %167 = and i64 %166, 4095
  %168 = trunc i64 %167 to i32
  %169 = load i32, ptr %5, align 4
  %170 = icmp ne i32 %168, %169
  br i1 %170, label %184, label %171

171:                                              ; preds = %165
  %172 = getelementptr inbounds nuw %struct.O, ptr %6, i32 0, i32 0
  %173 = load i64, ptr %172, align 8
  %174 = load i64, ptr @sO, align 8
  %175 = icmp ne i64 %173, %174
  br i1 %175, label %184, label %176

176:                                              ; preds = %171
  %177 = load i32, ptr %3, align 4
  %178 = load i32, ptr %4, align 4
  %179 = add i32 %177, %178
  %180 = load i32, ptr %2, align 4
  %181 = and i32 %179, %180
  %182 = load i32, ptr %5, align 4
  %183 = icmp ne i32 %181, %182
  br i1 %183, label %184, label %185

184:                                              ; preds = %176, %171, %165, %154, %135
  call void @abort() #4
  unreachable

185:                                              ; preds = %176
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeP(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.P, align 8
  %4 = alloca %struct.P, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1P(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.P, align 8
  %4 = alloca %struct.P, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sP, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i64, ptr %3, align 8
  %7 = and i64 %6, 4095
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, %5
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr %3, align 8
  %12 = and i64 %10, 4095
  %13 = and i64 %11, -4096
  %14 = or i64 %13, %12
  store i64 %14, ptr %3, align 8
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %16 = load i64, ptr %15, align 8
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %18 = load i64, ptr %17, align 8
  %19 = call { i64, i64 } @retmeP(i64 %16, i64 %18)
  %20 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %21 = extractvalue { i64, i64 } %19, 0
  store i64 %21, ptr %20, align 8
  %22 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %23 = extractvalue { i64, i64 } %19, 1
  store i64 %23, ptr %22, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %24 = load i64, ptr %3, align 8
  %25 = and i64 %24, 4095
  %26 = trunc i64 %25 to i32
  ret i32 %26
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2P(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.P, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sP, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i64, ptr %3, align 8
  %6 = and i64 %5, 4095
  %7 = trunc i64 %6 to i32
  %8 = add i32 %7, %4
  %9 = zext i32 %8 to i64
  %10 = load i64, ptr %3, align 8
  %11 = and i64 %9, 4095
  %12 = and i64 %10, -4096
  %13 = or i64 %12, %11
  store i64 %13, ptr %3, align 8
  %14 = load i64, ptr %3, align 8
  %15 = and i64 %14, 4095
  %16 = trunc i64 %15 to i32
  %17 = srem i32 %16, 15
  %18 = sext i32 %17 to i64
  %19 = load i64, ptr %3, align 8
  %20 = and i64 %18, 4095
  %21 = and i64 %19, -4096
  %22 = or i64 %21, %20
  store i64 %22, ptr %3, align 8
  %23 = load i64, ptr %3, align 8
  %24 = and i64 %23, 4095
  %25 = trunc i64 %24 to i32
  ret i32 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitP() #0 {
  %1 = load i64, ptr @sP, align 8
  %2 = and i64 %1, 4095
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3P(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i64, ptr @sP, align 8
  %5 = and i64 %4, 4095
  %6 = trunc i64 %5 to i32
  %7 = add i32 %6, %3
  %8 = zext i32 %7 to i64
  %9 = load i64, ptr @sP, align 8
  %10 = and i64 %8, 4095
  %11 = and i64 %9, -4096
  %12 = or i64 %11, %10
  store i64 %12, ptr @sP, align 8
  %13 = call i32 @retitP()
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testP() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.P, align 8
  %7 = alloca ptr, align 8
  store ptr @sP, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !22

20:                                               ; preds = %8
  %21 = load i64, ptr @sP, align 8
  %22 = and i64 %21, -4096
  %23 = or i64 %22, 4095
  store i64 %23, ptr @sP, align 8
  %24 = load i64, ptr @sP, align 8
  %25 = and i64 %24, 4095
  %26 = trunc i64 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = zext i32 %29 to i64
  %31 = load i64, ptr @sP, align 8
  %32 = and i64 %30, 4095
  %33 = and i64 %31, -4096
  %34 = or i64 %33, %32
  store i64 %34, ptr @sP, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sP, i64 16, i1 false)
  %35 = load i32, ptr %4, align 4
  %36 = call i32 @fn1P(i32 noundef %35)
  store i32 %36, ptr %5, align 4
  %37 = load i64, ptr %6, align 8
  %38 = lshr i64 %37, 35
  %39 = trunc i64 %38 to i32
  %40 = load i64, ptr @sP, align 8
  %41 = lshr i64 %40, 35
  %42 = trunc i64 %41 to i32
  %43 = icmp ne i32 %39, %42
  br i1 %43, label %75, label %44

44:                                               ; preds = %20
  %45 = load i64, ptr %6, align 8
  %46 = lshr i64 %45, 12
  %47 = and i64 %46, 8388607
  %48 = trunc i64 %47 to i32
  %49 = load i64, ptr @sP, align 8
  %50 = lshr i64 %49, 12
  %51 = and i64 %50, 8388607
  %52 = trunc i64 %51 to i32
  %53 = icmp ne i32 %48, %52
  br i1 %53, label %75, label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %6, align 8
  %56 = and i64 %55, 4095
  %57 = trunc i64 %56 to i32
  %58 = load i64, ptr @sP, align 8
  %59 = and i64 %58, 4095
  %60 = trunc i64 %59 to i32
  %61 = icmp ne i32 %57, %60
  br i1 %61, label %75, label %62

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw %struct.P, ptr %6, i32 0, i32 1
  %64 = load i64, ptr %63, align 8
  %65 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sP, i64 8), align 8
  %66 = icmp ne i64 %64, %65
  br i1 %66, label %75, label %67

67:                                               ; preds = %62
  %68 = load i32, ptr %3, align 4
  %69 = load i32, ptr %4, align 4
  %70 = add i32 %68, %69
  %71 = load i32, ptr %2, align 4
  %72 = and i32 %70, %71
  %73 = load i32, ptr %5, align 4
  %74 = icmp ne i32 %72, %73
  br i1 %74, label %75, label %76

75:                                               ; preds = %67, %62, %54, %44, %20
  call void @abort() #4
  unreachable

76:                                               ; preds = %67
  %77 = call i32 @myrnd()
  store i32 %77, ptr %3, align 4
  %78 = call i32 @myrnd()
  store i32 %78, ptr %4, align 4
  %79 = load i32, ptr %3, align 4
  %80 = zext i32 %79 to i64
  %81 = load i64, ptr @sP, align 8
  %82 = and i64 %80, 4095
  %83 = and i64 %81, -4096
  %84 = or i64 %83, %82
  store i64 %84, ptr @sP, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sP, i64 16, i1 false)
  %85 = load i32, ptr %4, align 4
  %86 = call i32 @fn2P(i32 noundef %85)
  store i32 %86, ptr %5, align 4
  %87 = load i64, ptr %6, align 8
  %88 = lshr i64 %87, 35
  %89 = trunc i64 %88 to i32
  %90 = load i64, ptr @sP, align 8
  %91 = lshr i64 %90, 35
  %92 = trunc i64 %91 to i32
  %93 = icmp ne i32 %89, %92
  br i1 %93, label %128, label %94

94:                                               ; preds = %76
  %95 = load i64, ptr %6, align 8
  %96 = lshr i64 %95, 12
  %97 = and i64 %96, 8388607
  %98 = trunc i64 %97 to i32
  %99 = load i64, ptr @sP, align 8
  %100 = lshr i64 %99, 12
  %101 = and i64 %100, 8388607
  %102 = trunc i64 %101 to i32
  %103 = icmp ne i32 %98, %102
  br i1 %103, label %128, label %104

104:                                              ; preds = %94
  %105 = load i64, ptr %6, align 8
  %106 = and i64 %105, 4095
  %107 = trunc i64 %106 to i32
  %108 = load i64, ptr @sP, align 8
  %109 = and i64 %108, 4095
  %110 = trunc i64 %109 to i32
  %111 = icmp ne i32 %107, %110
  br i1 %111, label %128, label %112

112:                                              ; preds = %104
  %113 = getelementptr inbounds nuw %struct.P, ptr %6, i32 0, i32 1
  %114 = load i64, ptr %113, align 8
  %115 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sP, i64 8), align 8
  %116 = icmp ne i64 %114, %115
  br i1 %116, label %128, label %117

117:                                              ; preds = %112
  %118 = load i32, ptr %3, align 4
  %119 = load i32, ptr %4, align 4
  %120 = add i32 %118, %119
  %121 = load i32, ptr %2, align 4
  %122 = and i32 %120, %121
  %123 = urem i32 %122, 15
  %124 = load i32, ptr %2, align 4
  %125 = and i32 %123, %124
  %126 = load i32, ptr %5, align 4
  %127 = icmp ne i32 %125, %126
  br i1 %127, label %128, label %129

128:                                              ; preds = %117, %112, %104, %94, %76
  call void @abort() #4
  unreachable

129:                                              ; preds = %117
  %130 = call i32 @myrnd()
  store i32 %130, ptr %3, align 4
  %131 = call i32 @myrnd()
  store i32 %131, ptr %4, align 4
  %132 = load i32, ptr %3, align 4
  %133 = zext i32 %132 to i64
  %134 = load i64, ptr @sP, align 8
  %135 = and i64 %133, 4095
  %136 = and i64 %134, -4096
  %137 = or i64 %136, %135
  store i64 %137, ptr @sP, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sP, i64 16, i1 false)
  %138 = load i32, ptr %4, align 4
  %139 = call i32 @fn3P(i32 noundef %138)
  store i32 %139, ptr %5, align 4
  %140 = load i64, ptr %6, align 8
  %141 = lshr i64 %140, 35
  %142 = trunc i64 %141 to i32
  %143 = load i64, ptr @sP, align 8
  %144 = lshr i64 %143, 35
  %145 = trunc i64 %144 to i32
  %146 = icmp ne i32 %142, %145
  br i1 %146, label %176, label %147

147:                                              ; preds = %129
  %148 = load i64, ptr %6, align 8
  %149 = lshr i64 %148, 12
  %150 = and i64 %149, 8388607
  %151 = trunc i64 %150 to i32
  %152 = load i64, ptr @sP, align 8
  %153 = lshr i64 %152, 12
  %154 = and i64 %153, 8388607
  %155 = trunc i64 %154 to i32
  %156 = icmp ne i32 %151, %155
  br i1 %156, label %176, label %157

157:                                              ; preds = %147
  %158 = load i64, ptr @sP, align 8
  %159 = and i64 %158, 4095
  %160 = trunc i64 %159 to i32
  %161 = load i32, ptr %5, align 4
  %162 = icmp ne i32 %160, %161
  br i1 %162, label %176, label %163

163:                                              ; preds = %157
  %164 = getelementptr inbounds nuw %struct.P, ptr %6, i32 0, i32 1
  %165 = load i64, ptr %164, align 8
  %166 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sP, i64 8), align 8
  %167 = icmp ne i64 %165, %166
  br i1 %167, label %176, label %168

168:                                              ; preds = %163
  %169 = load i32, ptr %3, align 4
  %170 = load i32, ptr %4, align 4
  %171 = add i32 %169, %170
  %172 = load i32, ptr %2, align 4
  %173 = and i32 %171, %172
  %174 = load i32, ptr %5, align 4
  %175 = icmp ne i32 %173, %174
  br i1 %175, label %176, label %177

176:                                              ; preds = %168, %163, %157, %147, %129
  call void @abort() #4
  unreachable

177:                                              ; preds = %168
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeQ(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.Q, align 8
  %4 = alloca %struct.Q, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1Q(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Q, align 8
  %4 = alloca %struct.Q, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sQ, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 8
  %7 = and i32 %6, 4095
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 8
  %10 = and i32 %8, 4095
  %11 = and i32 %9, -4096
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 8
  %13 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %14 = load i64, ptr %13, align 8
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %16 = load i64, ptr %15, align 8
  %17 = call { i64, i64 } @retmeQ(i64 %14, i64 %16)
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %19 = extractvalue { i64, i64 } %17, 0
  store i64 %19, ptr %18, align 8
  %20 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %21 = extractvalue { i64, i64 } %17, 1
  store i64 %21, ptr %20, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %22 = load i32, ptr %3, align 8
  %23 = and i32 %22, 4095
  ret i32 %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2Q(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Q, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sQ, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 8
  %6 = and i32 %5, 4095
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 8
  %9 = and i32 %7, 4095
  %10 = and i32 %8, -4096
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 8
  %12 = load i32, ptr %3, align 8
  %13 = and i32 %12, 4095
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 8
  %16 = and i32 %14, 4095
  %17 = and i32 %15, -4096
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 8
  %19 = load i32, ptr %3, align 8
  %20 = and i32 %19, 4095
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitQ() #0 {
  %1 = load i32, ptr @sQ, align 8
  %2 = and i32 %1, 4095
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3Q(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sQ, align 8
  %5 = and i32 %4, 4095
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sQ, align 8
  %8 = and i32 %6, 4095
  %9 = and i32 %7, -4096
  %10 = or i32 %9, %8
  store i32 %10, ptr @sQ, align 8
  %11 = call i32 @retitQ()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testQ() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.Q, align 8
  %7 = alloca ptr, align 8
  store ptr @sQ, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !23

20:                                               ; preds = %8
  %21 = load i32, ptr @sQ, align 8
  %22 = and i32 %21, -4096
  %23 = or i32 %22, 4095
  store i32 %23, ptr @sQ, align 8
  %24 = load i32, ptr @sQ, align 8
  %25 = and i32 %24, 4095
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sQ, align 8
  %30 = and i32 %28, 4095
  %31 = and i32 %29, -4096
  %32 = or i32 %31, %30
  store i32 %32, ptr @sQ, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sQ, i64 16, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1Q(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 8
  %36 = lshr i32 %35, 25
  %37 = load i32, ptr @sQ, align 8
  %38 = lshr i32 %37, 25
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %67, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 8
  %42 = lshr i32 %41, 12
  %43 = and i32 %42, 8191
  %44 = load i32, ptr @sQ, align 8
  %45 = lshr i32 %44, 12
  %46 = and i32 %45, 8191
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %67, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 8
  %50 = and i32 %49, 4095
  %51 = load i32, ptr @sQ, align 8
  %52 = and i32 %51, 4095
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %67, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw %struct.Q, ptr %6, i32 0, i32 1
  %56 = load i64, ptr %55, align 8
  %57 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sQ, i64 8), align 8
  %58 = icmp ne i64 %56, %57
  br i1 %58, label %67, label %59

59:                                               ; preds = %54
  %60 = load i32, ptr %3, align 4
  %61 = load i32, ptr %4, align 4
  %62 = add i32 %60, %61
  %63 = load i32, ptr %2, align 4
  %64 = and i32 %62, %63
  %65 = load i32, ptr %5, align 4
  %66 = icmp ne i32 %64, %65
  br i1 %66, label %67, label %68

67:                                               ; preds = %59, %54, %48, %40, %20
  call void @abort() #4
  unreachable

68:                                               ; preds = %59
  %69 = call i32 @myrnd()
  store i32 %69, ptr %3, align 4
  %70 = call i32 @myrnd()
  store i32 %70, ptr %4, align 4
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr @sQ, align 8
  %73 = and i32 %71, 4095
  %74 = and i32 %72, -4096
  %75 = or i32 %74, %73
  store i32 %75, ptr @sQ, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sQ, i64 16, i1 false)
  %76 = load i32, ptr %4, align 4
  %77 = call i32 @fn2Q(i32 noundef %76)
  store i32 %77, ptr %5, align 4
  %78 = load i32, ptr %6, align 8
  %79 = lshr i32 %78, 25
  %80 = load i32, ptr @sQ, align 8
  %81 = lshr i32 %80, 25
  %82 = icmp ne i32 %79, %81
  br i1 %82, label %113, label %83

83:                                               ; preds = %68
  %84 = load i32, ptr %6, align 8
  %85 = lshr i32 %84, 12
  %86 = and i32 %85, 8191
  %87 = load i32, ptr @sQ, align 8
  %88 = lshr i32 %87, 12
  %89 = and i32 %88, 8191
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %113, label %91

91:                                               ; preds = %83
  %92 = load i32, ptr %6, align 8
  %93 = and i32 %92, 4095
  %94 = load i32, ptr @sQ, align 8
  %95 = and i32 %94, 4095
  %96 = icmp ne i32 %93, %95
  br i1 %96, label %113, label %97

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw %struct.Q, ptr %6, i32 0, i32 1
  %99 = load i64, ptr %98, align 8
  %100 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sQ, i64 8), align 8
  %101 = icmp ne i64 %99, %100
  br i1 %101, label %113, label %102

102:                                              ; preds = %97
  %103 = load i32, ptr %3, align 4
  %104 = load i32, ptr %4, align 4
  %105 = add i32 %103, %104
  %106 = load i32, ptr %2, align 4
  %107 = and i32 %105, %106
  %108 = urem i32 %107, 15
  %109 = load i32, ptr %2, align 4
  %110 = and i32 %108, %109
  %111 = load i32, ptr %5, align 4
  %112 = icmp ne i32 %110, %111
  br i1 %112, label %113, label %114

113:                                              ; preds = %102, %97, %91, %83, %68
  call void @abort() #4
  unreachable

114:                                              ; preds = %102
  %115 = call i32 @myrnd()
  store i32 %115, ptr %3, align 4
  %116 = call i32 @myrnd()
  store i32 %116, ptr %4, align 4
  %117 = load i32, ptr %3, align 4
  %118 = load i32, ptr @sQ, align 8
  %119 = and i32 %117, 4095
  %120 = and i32 %118, -4096
  %121 = or i32 %120, %119
  store i32 %121, ptr @sQ, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sQ, i64 16, i1 false)
  %122 = load i32, ptr %4, align 4
  %123 = call i32 @fn3Q(i32 noundef %122)
  store i32 %123, ptr %5, align 4
  %124 = load i32, ptr %6, align 8
  %125 = lshr i32 %124, 25
  %126 = load i32, ptr @sQ, align 8
  %127 = lshr i32 %126, 25
  %128 = icmp ne i32 %125, %127
  br i1 %128, label %155, label %129

129:                                              ; preds = %114
  %130 = load i32, ptr %6, align 8
  %131 = lshr i32 %130, 12
  %132 = and i32 %131, 8191
  %133 = load i32, ptr @sQ, align 8
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 8191
  %136 = icmp ne i32 %132, %135
  br i1 %136, label %155, label %137

137:                                              ; preds = %129
  %138 = load i32, ptr @sQ, align 8
  %139 = and i32 %138, 4095
  %140 = load i32, ptr %5, align 4
  %141 = icmp ne i32 %139, %140
  br i1 %141, label %155, label %142

142:                                              ; preds = %137
  %143 = getelementptr inbounds nuw %struct.Q, ptr %6, i32 0, i32 1
  %144 = load i64, ptr %143, align 8
  %145 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sQ, i64 8), align 8
  %146 = icmp ne i64 %144, %145
  br i1 %146, label %155, label %147

147:                                              ; preds = %142
  %148 = load i32, ptr %3, align 4
  %149 = load i32, ptr %4, align 4
  %150 = add i32 %148, %149
  %151 = load i32, ptr %2, align 4
  %152 = and i32 %150, %151
  %153 = load i32, ptr %5, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %155, label %156

155:                                              ; preds = %147, %142, %137, %129, %114
  call void @abort() #4
  unreachable

156:                                              ; preds = %147
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeR(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.R, align 8
  %4 = alloca %struct.R, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1R(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.R, align 8
  %4 = alloca %struct.R, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sR, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 8
  %7 = and i32 %6, 4095
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 8
  %10 = and i32 %8, 4095
  %11 = and i32 %9, -4096
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 8
  %13 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %14 = load i64, ptr %13, align 8
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %16 = load i64, ptr %15, align 8
  %17 = call { i64, i64 } @retmeR(i64 %14, i64 %16)
  %18 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %19 = extractvalue { i64, i64 } %17, 0
  store i64 %19, ptr %18, align 8
  %20 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %21 = extractvalue { i64, i64 } %17, 1
  store i64 %21, ptr %20, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %22 = load i32, ptr %3, align 8
  %23 = and i32 %22, 4095
  ret i32 %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2R(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.R, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sR, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 8
  %6 = and i32 %5, 4095
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 8
  %9 = and i32 %7, 4095
  %10 = and i32 %8, -4096
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 8
  %12 = load i32, ptr %3, align 8
  %13 = and i32 %12, 4095
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 8
  %16 = and i32 %14, 4095
  %17 = and i32 %15, -4096
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 8
  %19 = load i32, ptr %3, align 8
  %20 = and i32 %19, 4095
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitR() #0 {
  %1 = load i32, ptr @sR, align 8
  %2 = and i32 %1, 4095
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3R(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sR, align 8
  %5 = and i32 %4, 4095
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sR, align 8
  %8 = and i32 %6, 4095
  %9 = and i32 %7, -4096
  %10 = or i32 %9, %8
  store i32 %10, ptr @sR, align 8
  %11 = call i32 @retitR()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testR() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.R, align 8
  %7 = alloca ptr, align 8
  store ptr @sR, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !24

20:                                               ; preds = %8
  %21 = load i32, ptr @sR, align 8
  %22 = and i32 %21, -4096
  %23 = or i32 %22, 4095
  store i32 %23, ptr @sR, align 8
  %24 = load i32, ptr @sR, align 8
  %25 = and i32 %24, 4095
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sR, align 8
  %30 = and i32 %28, 4095
  %31 = and i32 %29, -4096
  %32 = or i32 %31, %30
  store i32 %32, ptr @sR, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sR, i64 16, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1R(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 8
  %36 = lshr i32 %35, 23
  %37 = load i32, ptr @sR, align 8
  %38 = lshr i32 %37, 23
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %67, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 8
  %42 = lshr i32 %41, 12
  %43 = and i32 %42, 2047
  %44 = load i32, ptr @sR, align 8
  %45 = lshr i32 %44, 12
  %46 = and i32 %45, 2047
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %67, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 8
  %50 = and i32 %49, 4095
  %51 = load i32, ptr @sR, align 8
  %52 = and i32 %51, 4095
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %67, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw %struct.R, ptr %6, i32 0, i32 1
  %56 = load i64, ptr %55, align 8
  %57 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sR, i64 8), align 8
  %58 = icmp ne i64 %56, %57
  br i1 %58, label %67, label %59

59:                                               ; preds = %54
  %60 = load i32, ptr %3, align 4
  %61 = load i32, ptr %4, align 4
  %62 = add i32 %60, %61
  %63 = load i32, ptr %2, align 4
  %64 = and i32 %62, %63
  %65 = load i32, ptr %5, align 4
  %66 = icmp ne i32 %64, %65
  br i1 %66, label %67, label %68

67:                                               ; preds = %59, %54, %48, %40, %20
  call void @abort() #4
  unreachable

68:                                               ; preds = %59
  %69 = call i32 @myrnd()
  store i32 %69, ptr %3, align 4
  %70 = call i32 @myrnd()
  store i32 %70, ptr %4, align 4
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr @sR, align 8
  %73 = and i32 %71, 4095
  %74 = and i32 %72, -4096
  %75 = or i32 %74, %73
  store i32 %75, ptr @sR, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sR, i64 16, i1 false)
  %76 = load i32, ptr %4, align 4
  %77 = call i32 @fn2R(i32 noundef %76)
  store i32 %77, ptr %5, align 4
  %78 = load i32, ptr %6, align 8
  %79 = lshr i32 %78, 23
  %80 = load i32, ptr @sR, align 8
  %81 = lshr i32 %80, 23
  %82 = icmp ne i32 %79, %81
  br i1 %82, label %113, label %83

83:                                               ; preds = %68
  %84 = load i32, ptr %6, align 8
  %85 = lshr i32 %84, 12
  %86 = and i32 %85, 2047
  %87 = load i32, ptr @sR, align 8
  %88 = lshr i32 %87, 12
  %89 = and i32 %88, 2047
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %113, label %91

91:                                               ; preds = %83
  %92 = load i32, ptr %6, align 8
  %93 = and i32 %92, 4095
  %94 = load i32, ptr @sR, align 8
  %95 = and i32 %94, 4095
  %96 = icmp ne i32 %93, %95
  br i1 %96, label %113, label %97

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw %struct.R, ptr %6, i32 0, i32 1
  %99 = load i64, ptr %98, align 8
  %100 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sR, i64 8), align 8
  %101 = icmp ne i64 %99, %100
  br i1 %101, label %113, label %102

102:                                              ; preds = %97
  %103 = load i32, ptr %3, align 4
  %104 = load i32, ptr %4, align 4
  %105 = add i32 %103, %104
  %106 = load i32, ptr %2, align 4
  %107 = and i32 %105, %106
  %108 = urem i32 %107, 15
  %109 = load i32, ptr %2, align 4
  %110 = and i32 %108, %109
  %111 = load i32, ptr %5, align 4
  %112 = icmp ne i32 %110, %111
  br i1 %112, label %113, label %114

113:                                              ; preds = %102, %97, %91, %83, %68
  call void @abort() #4
  unreachable

114:                                              ; preds = %102
  %115 = call i32 @myrnd()
  store i32 %115, ptr %3, align 4
  %116 = call i32 @myrnd()
  store i32 %116, ptr %4, align 4
  %117 = load i32, ptr %3, align 4
  %118 = load i32, ptr @sR, align 8
  %119 = and i32 %117, 4095
  %120 = and i32 %118, -4096
  %121 = or i32 %120, %119
  store i32 %121, ptr @sR, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sR, i64 16, i1 false)
  %122 = load i32, ptr %4, align 4
  %123 = call i32 @fn3R(i32 noundef %122)
  store i32 %123, ptr %5, align 4
  %124 = load i32, ptr %6, align 8
  %125 = lshr i32 %124, 23
  %126 = load i32, ptr @sR, align 8
  %127 = lshr i32 %126, 23
  %128 = icmp ne i32 %125, %127
  br i1 %128, label %155, label %129

129:                                              ; preds = %114
  %130 = load i32, ptr %6, align 8
  %131 = lshr i32 %130, 12
  %132 = and i32 %131, 2047
  %133 = load i32, ptr @sR, align 8
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 2047
  %136 = icmp ne i32 %132, %135
  br i1 %136, label %155, label %137

137:                                              ; preds = %129
  %138 = load i32, ptr @sR, align 8
  %139 = and i32 %138, 4095
  %140 = load i32, ptr %5, align 4
  %141 = icmp ne i32 %139, %140
  br i1 %141, label %155, label %142

142:                                              ; preds = %137
  %143 = getelementptr inbounds nuw %struct.R, ptr %6, i32 0, i32 1
  %144 = load i64, ptr %143, align 8
  %145 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sR, i64 8), align 8
  %146 = icmp ne i64 %144, %145
  br i1 %146, label %155, label %147

147:                                              ; preds = %142
  %148 = load i32, ptr %3, align 4
  %149 = load i32, ptr %4, align 4
  %150 = add i32 %148, %149
  %151 = load i32, ptr %2, align 4
  %152 = and i32 %150, %151
  %153 = load i32, ptr %5, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %155, label %156

155:                                              ; preds = %147, %142, %137, %129, %114
  call void @abort() #4
  unreachable

156:                                              ; preds = %147
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeS(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.S, align 8
  %4 = alloca %struct.S, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1S(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.S, align 8
  %4 = alloca %struct.S, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sS, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 8
  %7 = and i16 %6, 1
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %5
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 8
  %12 = and i16 %10, 1
  %13 = and i16 %11, -2
  %14 = or i16 %13, %12
  store i16 %14, ptr %3, align 8
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %16 = load i64, ptr %15, align 8
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %18 = load i64, ptr %17, align 8
  %19 = call { i64, i64 } @retmeS(i64 %16, i64 %18)
  %20 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %21 = extractvalue { i64, i64 } %19, 0
  store i64 %21, ptr %20, align 8
  %22 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %23 = extractvalue { i64, i64 } %19, 1
  store i64 %23, ptr %22, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %24 = load i16, ptr %3, align 8
  %25 = and i16 %24, 1
  %26 = zext i16 %25 to i32
  ret i32 %26
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2S(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.S, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sS, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 8
  %6 = and i16 %5, 1
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %4
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr %3, align 8
  %11 = and i16 %9, 1
  %12 = and i16 %10, -2
  %13 = or i16 %12, %11
  store i16 %13, ptr %3, align 8
  %14 = load i16, ptr %3, align 8
  %15 = and i16 %14, 1
  %16 = zext i16 %15 to i32
  %17 = srem i32 %16, 15
  %18 = trunc i32 %17 to i16
  %19 = load i16, ptr %3, align 8
  %20 = and i16 %18, 1
  %21 = and i16 %19, -2
  %22 = or i16 %21, %20
  store i16 %22, ptr %3, align 8
  %23 = load i16, ptr %3, align 8
  %24 = and i16 %23, 1
  %25 = zext i16 %24 to i32
  ret i32 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitS() #0 {
  %1 = load i16, ptr @sS, align 8
  %2 = and i16 %1, 1
  %3 = zext i16 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3S(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sS, align 8
  %5 = and i16 %4, 1
  %6 = zext i16 %5 to i32
  %7 = add i32 %6, %3
  %8 = trunc i32 %7 to i16
  %9 = load i16, ptr @sS, align 8
  %10 = and i16 %8, 1
  %11 = and i16 %9, -2
  %12 = or i16 %11, %10
  store i16 %12, ptr @sS, align 8
  %13 = call i32 @retitS()
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testS() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.S, align 8
  %7 = alloca ptr, align 8
  store ptr @sS, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !25

20:                                               ; preds = %8
  %21 = load i16, ptr @sS, align 8
  %22 = and i16 %21, -2
  %23 = or i16 %22, 1
  store i16 %23, ptr @sS, align 8
  %24 = load i16, ptr @sS, align 8
  %25 = and i16 %24, 1
  %26 = zext i16 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = trunc i32 %29 to i16
  %31 = load i16, ptr @sS, align 8
  %32 = and i16 %30, 1
  %33 = and i16 %31, -2
  %34 = or i16 %33, %32
  store i16 %34, ptr @sS, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sS, i64 16, i1 false)
  %35 = load i32, ptr %4, align 4
  %36 = call i32 @fn1S(i32 noundef %35)
  store i32 %36, ptr %5, align 4
  %37 = load i16, ptr %6, align 8
  %38 = lshr i16 %37, 7
  %39 = zext i16 %38 to i32
  %40 = load i16, ptr @sS, align 8
  %41 = lshr i16 %40, 7
  %42 = zext i16 %41 to i32
  %43 = icmp ne i32 %39, %42
  br i1 %43, label %75, label %44

44:                                               ; preds = %20
  %45 = load i16, ptr %6, align 8
  %46 = lshr i16 %45, 1
  %47 = and i16 %46, 63
  %48 = zext i16 %47 to i32
  %49 = load i16, ptr @sS, align 8
  %50 = lshr i16 %49, 1
  %51 = and i16 %50, 63
  %52 = zext i16 %51 to i32
  %53 = icmp ne i32 %48, %52
  br i1 %53, label %75, label %54

54:                                               ; preds = %44
  %55 = load i16, ptr %6, align 8
  %56 = and i16 %55, 1
  %57 = zext i16 %56 to i32
  %58 = load i16, ptr @sS, align 8
  %59 = and i16 %58, 1
  %60 = zext i16 %59 to i32
  %61 = icmp ne i32 %57, %60
  br i1 %61, label %75, label %62

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw %struct.S, ptr %6, i32 0, i32 1
  %64 = load i64, ptr %63, align 8
  %65 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sS, i64 8), align 8
  %66 = icmp ne i64 %64, %65
  br i1 %66, label %75, label %67

67:                                               ; preds = %62
  %68 = load i32, ptr %3, align 4
  %69 = load i32, ptr %4, align 4
  %70 = add i32 %68, %69
  %71 = load i32, ptr %2, align 4
  %72 = and i32 %70, %71
  %73 = load i32, ptr %5, align 4
  %74 = icmp ne i32 %72, %73
  br i1 %74, label %75, label %76

75:                                               ; preds = %67, %62, %54, %44, %20
  call void @abort() #4
  unreachable

76:                                               ; preds = %67
  %77 = call i32 @myrnd()
  store i32 %77, ptr %3, align 4
  %78 = call i32 @myrnd()
  store i32 %78, ptr %4, align 4
  %79 = load i32, ptr %3, align 4
  %80 = trunc i32 %79 to i16
  %81 = load i16, ptr @sS, align 8
  %82 = and i16 %80, 1
  %83 = and i16 %81, -2
  %84 = or i16 %83, %82
  store i16 %84, ptr @sS, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sS, i64 16, i1 false)
  %85 = load i32, ptr %4, align 4
  %86 = call i32 @fn2S(i32 noundef %85)
  store i32 %86, ptr %5, align 4
  %87 = load i16, ptr %6, align 8
  %88 = lshr i16 %87, 7
  %89 = zext i16 %88 to i32
  %90 = load i16, ptr @sS, align 8
  %91 = lshr i16 %90, 7
  %92 = zext i16 %91 to i32
  %93 = icmp ne i32 %89, %92
  br i1 %93, label %128, label %94

94:                                               ; preds = %76
  %95 = load i16, ptr %6, align 8
  %96 = lshr i16 %95, 1
  %97 = and i16 %96, 63
  %98 = zext i16 %97 to i32
  %99 = load i16, ptr @sS, align 8
  %100 = lshr i16 %99, 1
  %101 = and i16 %100, 63
  %102 = zext i16 %101 to i32
  %103 = icmp ne i32 %98, %102
  br i1 %103, label %128, label %104

104:                                              ; preds = %94
  %105 = load i16, ptr %6, align 8
  %106 = and i16 %105, 1
  %107 = zext i16 %106 to i32
  %108 = load i16, ptr @sS, align 8
  %109 = and i16 %108, 1
  %110 = zext i16 %109 to i32
  %111 = icmp ne i32 %107, %110
  br i1 %111, label %128, label %112

112:                                              ; preds = %104
  %113 = getelementptr inbounds nuw %struct.S, ptr %6, i32 0, i32 1
  %114 = load i64, ptr %113, align 8
  %115 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sS, i64 8), align 8
  %116 = icmp ne i64 %114, %115
  br i1 %116, label %128, label %117

117:                                              ; preds = %112
  %118 = load i32, ptr %3, align 4
  %119 = load i32, ptr %4, align 4
  %120 = add i32 %118, %119
  %121 = load i32, ptr %2, align 4
  %122 = and i32 %120, %121
  %123 = urem i32 %122, 15
  %124 = load i32, ptr %2, align 4
  %125 = and i32 %123, %124
  %126 = load i32, ptr %5, align 4
  %127 = icmp ne i32 %125, %126
  br i1 %127, label %128, label %129

128:                                              ; preds = %117, %112, %104, %94, %76
  call void @abort() #4
  unreachable

129:                                              ; preds = %117
  %130 = call i32 @myrnd()
  store i32 %130, ptr %3, align 4
  %131 = call i32 @myrnd()
  store i32 %131, ptr %4, align 4
  %132 = load i32, ptr %3, align 4
  %133 = trunc i32 %132 to i16
  %134 = load i16, ptr @sS, align 8
  %135 = and i16 %133, 1
  %136 = and i16 %134, -2
  %137 = or i16 %136, %135
  store i16 %137, ptr @sS, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sS, i64 16, i1 false)
  %138 = load i32, ptr %4, align 4
  %139 = call i32 @fn3S(i32 noundef %138)
  store i32 %139, ptr %5, align 4
  %140 = load i16, ptr %6, align 8
  %141 = lshr i16 %140, 7
  %142 = zext i16 %141 to i32
  %143 = load i16, ptr @sS, align 8
  %144 = lshr i16 %143, 7
  %145 = zext i16 %144 to i32
  %146 = icmp ne i32 %142, %145
  br i1 %146, label %176, label %147

147:                                              ; preds = %129
  %148 = load i16, ptr %6, align 8
  %149 = lshr i16 %148, 1
  %150 = and i16 %149, 63
  %151 = zext i16 %150 to i32
  %152 = load i16, ptr @sS, align 8
  %153 = lshr i16 %152, 1
  %154 = and i16 %153, 63
  %155 = zext i16 %154 to i32
  %156 = icmp ne i32 %151, %155
  br i1 %156, label %176, label %157

157:                                              ; preds = %147
  %158 = load i16, ptr @sS, align 8
  %159 = and i16 %158, 1
  %160 = zext i16 %159 to i32
  %161 = load i32, ptr %5, align 4
  %162 = icmp ne i32 %160, %161
  br i1 %162, label %176, label %163

163:                                              ; preds = %157
  %164 = getelementptr inbounds nuw %struct.S, ptr %6, i32 0, i32 1
  %165 = load i64, ptr %164, align 8
  %166 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sS, i64 8), align 8
  %167 = icmp ne i64 %165, %166
  br i1 %167, label %176, label %168

168:                                              ; preds = %163
  %169 = load i32, ptr %3, align 4
  %170 = load i32, ptr %4, align 4
  %171 = add i32 %169, %170
  %172 = load i32, ptr %2, align 4
  %173 = and i32 %171, %172
  %174 = load i32, ptr %5, align 4
  %175 = icmp ne i32 %173, %174
  br i1 %175, label %176, label %177

176:                                              ; preds = %168, %163, %157, %147, %129
  call void @abort() #4
  unreachable

177:                                              ; preds = %168
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retmeT(i32 %0) #0 {
  %2 = alloca %struct.T, align 2
  %3 = alloca %struct.T, align 2
  store i32 %0, ptr %3, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %2, ptr align 2 %3, i64 4, i1 false)
  %4 = load i32, ptr %2, align 2
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1T(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.T, align 2
  %4 = alloca %struct.T, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sT, i64 4, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 2
  %7 = and i16 %6, 1
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %5
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 2
  %12 = and i16 %10, 1
  %13 = and i16 %11, -2
  %14 = or i16 %13, %12
  store i16 %14, ptr %3, align 2
  %15 = load i32, ptr %3, align 2
  %16 = call i32 @retmeT(i32 %15)
  store i32 %16, ptr %4, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 %4, i64 4, i1 false)
  %17 = load i16, ptr %3, align 2
  %18 = and i16 %17, 1
  %19 = zext i16 %18 to i32
  ret i32 %19
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2T(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.T, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sT, i64 4, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 2
  %6 = and i16 %5, 1
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %4
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr %3, align 2
  %11 = and i16 %9, 1
  %12 = and i16 %10, -2
  %13 = or i16 %12, %11
  store i16 %13, ptr %3, align 2
  %14 = load i16, ptr %3, align 2
  %15 = and i16 %14, 1
  %16 = zext i16 %15 to i32
  %17 = srem i32 %16, 15
  %18 = trunc i32 %17 to i16
  %19 = load i16, ptr %3, align 2
  %20 = and i16 %18, 1
  %21 = and i16 %19, -2
  %22 = or i16 %21, %20
  store i16 %22, ptr %3, align 2
  %23 = load i16, ptr %3, align 2
  %24 = and i16 %23, 1
  %25 = zext i16 %24 to i32
  ret i32 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitT() #0 {
  %1 = load i16, ptr @sT, align 2
  %2 = and i16 %1, 1
  %3 = zext i16 %2 to i32
  ret i32 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3T(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sT, align 2
  %5 = and i16 %4, 1
  %6 = zext i16 %5 to i32
  %7 = add i32 %6, %3
  %8 = trunc i32 %7 to i16
  %9 = load i16, ptr @sT, align 2
  %10 = and i16 %8, 1
  %11 = and i16 %9, -2
  %12 = or i16 %11, %10
  store i16 %12, ptr @sT, align 2
  %13 = call i32 @retitT()
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testT() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.T, align 2
  %7 = alloca ptr, align 8
  store ptr @sT, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 4
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !26

20:                                               ; preds = %8
  %21 = load i16, ptr @sT, align 2
  %22 = and i16 %21, -2
  %23 = or i16 %22, 1
  store i16 %23, ptr @sT, align 2
  %24 = load i16, ptr @sT, align 2
  %25 = and i16 %24, 1
  %26 = zext i16 %25 to i32
  store i32 %26, ptr %2, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %3, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %4, align 4
  %29 = load i32, ptr %3, align 4
  %30 = trunc i32 %29 to i16
  %31 = load i16, ptr @sT, align 2
  %32 = and i16 %30, 1
  %33 = and i16 %31, -2
  %34 = or i16 %33, %32
  store i16 %34, ptr @sT, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sT, i64 4, i1 false)
  %35 = load i32, ptr %4, align 4
  %36 = call i32 @fn1T(i32 noundef %35)
  store i32 %36, ptr %5, align 4
  %37 = load i16, ptr %6, align 2
  %38 = lshr i16 %37, 9
  %39 = zext i16 %38 to i32
  %40 = load i16, ptr @sT, align 2
  %41 = lshr i16 %40, 9
  %42 = zext i16 %41 to i32
  %43 = icmp ne i32 %39, %42
  br i1 %43, label %77, label %44

44:                                               ; preds = %20
  %45 = load i16, ptr %6, align 2
  %46 = lshr i16 %45, 1
  %47 = and i16 %46, 255
  %48 = zext i16 %47 to i32
  %49 = load i16, ptr @sT, align 2
  %50 = lshr i16 %49, 1
  %51 = and i16 %50, 255
  %52 = zext i16 %51 to i32
  %53 = icmp ne i32 %48, %52
  br i1 %53, label %77, label %54

54:                                               ; preds = %44
  %55 = load i16, ptr %6, align 2
  %56 = and i16 %55, 1
  %57 = zext i16 %56 to i32
  %58 = load i16, ptr @sT, align 2
  %59 = and i16 %58, 1
  %60 = zext i16 %59 to i32
  %61 = icmp ne i32 %57, %60
  br i1 %61, label %77, label %62

62:                                               ; preds = %54
  %63 = getelementptr inbounds nuw %struct.T, ptr %6, i32 0, i32 1
  %64 = load i16, ptr %63, align 2
  %65 = zext i16 %64 to i32
  %66 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sT, i64 2), align 2
  %67 = zext i16 %66 to i32
  %68 = icmp ne i32 %65, %67
  br i1 %68, label %77, label %69

69:                                               ; preds = %62
  %70 = load i32, ptr %3, align 4
  %71 = load i32, ptr %4, align 4
  %72 = add i32 %70, %71
  %73 = load i32, ptr %2, align 4
  %74 = and i32 %72, %73
  %75 = load i32, ptr %5, align 4
  %76 = icmp ne i32 %74, %75
  br i1 %76, label %77, label %78

77:                                               ; preds = %69, %62, %54, %44, %20
  call void @abort() #4
  unreachable

78:                                               ; preds = %69
  %79 = call i32 @myrnd()
  store i32 %79, ptr %3, align 4
  %80 = call i32 @myrnd()
  store i32 %80, ptr %4, align 4
  %81 = load i32, ptr %3, align 4
  %82 = trunc i32 %81 to i16
  %83 = load i16, ptr @sT, align 2
  %84 = and i16 %82, 1
  %85 = and i16 %83, -2
  %86 = or i16 %85, %84
  store i16 %86, ptr @sT, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sT, i64 4, i1 false)
  %87 = load i32, ptr %4, align 4
  %88 = call i32 @fn2T(i32 noundef %87)
  store i32 %88, ptr %5, align 4
  %89 = load i16, ptr %6, align 2
  %90 = lshr i16 %89, 9
  %91 = zext i16 %90 to i32
  %92 = load i16, ptr @sT, align 2
  %93 = lshr i16 %92, 9
  %94 = zext i16 %93 to i32
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %132, label %96

96:                                               ; preds = %78
  %97 = load i16, ptr %6, align 2
  %98 = lshr i16 %97, 1
  %99 = and i16 %98, 255
  %100 = zext i16 %99 to i32
  %101 = load i16, ptr @sT, align 2
  %102 = lshr i16 %101, 1
  %103 = and i16 %102, 255
  %104 = zext i16 %103 to i32
  %105 = icmp ne i32 %100, %104
  br i1 %105, label %132, label %106

106:                                              ; preds = %96
  %107 = load i16, ptr %6, align 2
  %108 = and i16 %107, 1
  %109 = zext i16 %108 to i32
  %110 = load i16, ptr @sT, align 2
  %111 = and i16 %110, 1
  %112 = zext i16 %111 to i32
  %113 = icmp ne i32 %109, %112
  br i1 %113, label %132, label %114

114:                                              ; preds = %106
  %115 = getelementptr inbounds nuw %struct.T, ptr %6, i32 0, i32 1
  %116 = load i16, ptr %115, align 2
  %117 = zext i16 %116 to i32
  %118 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sT, i64 2), align 2
  %119 = zext i16 %118 to i32
  %120 = icmp ne i32 %117, %119
  br i1 %120, label %132, label %121

121:                                              ; preds = %114
  %122 = load i32, ptr %3, align 4
  %123 = load i32, ptr %4, align 4
  %124 = add i32 %122, %123
  %125 = load i32, ptr %2, align 4
  %126 = and i32 %124, %125
  %127 = urem i32 %126, 15
  %128 = load i32, ptr %2, align 4
  %129 = and i32 %127, %128
  %130 = load i32, ptr %5, align 4
  %131 = icmp ne i32 %129, %130
  br i1 %131, label %132, label %133

132:                                              ; preds = %121, %114, %106, %96, %78
  call void @abort() #4
  unreachable

133:                                              ; preds = %121
  %134 = call i32 @myrnd()
  store i32 %134, ptr %3, align 4
  %135 = call i32 @myrnd()
  store i32 %135, ptr %4, align 4
  %136 = load i32, ptr %3, align 4
  %137 = trunc i32 %136 to i16
  %138 = load i16, ptr @sT, align 2
  %139 = and i16 %137, 1
  %140 = and i16 %138, -2
  %141 = or i16 %140, %139
  store i16 %141, ptr @sT, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sT, i64 4, i1 false)
  %142 = load i32, ptr %4, align 4
  %143 = call i32 @fn3T(i32 noundef %142)
  store i32 %143, ptr %5, align 4
  %144 = load i16, ptr %6, align 2
  %145 = lshr i16 %144, 9
  %146 = zext i16 %145 to i32
  %147 = load i16, ptr @sT, align 2
  %148 = lshr i16 %147, 9
  %149 = zext i16 %148 to i32
  %150 = icmp ne i32 %146, %149
  br i1 %150, label %182, label %151

151:                                              ; preds = %133
  %152 = load i16, ptr %6, align 2
  %153 = lshr i16 %152, 1
  %154 = and i16 %153, 255
  %155 = zext i16 %154 to i32
  %156 = load i16, ptr @sT, align 2
  %157 = lshr i16 %156, 1
  %158 = and i16 %157, 255
  %159 = zext i16 %158 to i32
  %160 = icmp ne i32 %155, %159
  br i1 %160, label %182, label %161

161:                                              ; preds = %151
  %162 = load i16, ptr @sT, align 2
  %163 = and i16 %162, 1
  %164 = zext i16 %163 to i32
  %165 = load i32, ptr %5, align 4
  %166 = icmp ne i32 %164, %165
  br i1 %166, label %182, label %167

167:                                              ; preds = %161
  %168 = getelementptr inbounds nuw %struct.T, ptr %6, i32 0, i32 1
  %169 = load i16, ptr %168, align 2
  %170 = zext i16 %169 to i32
  %171 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sT, i64 2), align 2
  %172 = zext i16 %171 to i32
  %173 = icmp ne i32 %170, %172
  br i1 %173, label %182, label %174

174:                                              ; preds = %167
  %175 = load i32, ptr %3, align 4
  %176 = load i32, ptr %4, align 4
  %177 = add i32 %175, %176
  %178 = load i32, ptr %2, align 4
  %179 = and i32 %177, %178
  %180 = load i32, ptr %5, align 4
  %181 = icmp ne i32 %179, %180
  br i1 %181, label %182, label %183

182:                                              ; preds = %174, %167, %161, %151, %133
  call void @abort() #4
  unreachable

183:                                              ; preds = %174
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @retmeU(i64 %0, i64 %1) #0 {
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  %5 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  store i64 %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  store i64 %1, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %7 = load { i64, i64 }, ptr %3, align 8
  ret { i64, i64 } %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1U(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sU, i64 16, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 8
  %7 = lshr i16 %6, 6
  %8 = and i16 %7, 1
  %9 = zext i16 %8 to i32
  %10 = add i32 %9, %5
  %11 = trunc i32 %10 to i16
  %12 = load i16, ptr %3, align 8
  %13 = and i16 %11, 1
  %14 = shl i16 %13, 6
  %15 = and i16 %12, -65
  %16 = or i16 %15, %14
  store i16 %16, ptr %3, align 8
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 0
  %18 = load i64, ptr %17, align 8
  %19 = getelementptr inbounds nuw { i64, i64 }, ptr %3, i32 0, i32 1
  %20 = load i64, ptr %19, align 8
  %21 = call { i64, i64 } @retmeU(i64 %18, i64 %20)
  %22 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 0
  %23 = extractvalue { i64, i64 } %21, 0
  store i64 %23, ptr %22, align 8
  %24 = getelementptr inbounds nuw { i64, i64 }, ptr %4, i32 0, i32 1
  %25 = extractvalue { i64, i64 } %21, 1
  store i64 %25, ptr %24, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 16, i1 false)
  %26 = load i16, ptr %3, align 8
  %27 = lshr i16 %26, 6
  %28 = and i16 %27, 1
  %29 = zext i16 %28 to i32
  ret i32 %29
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2U(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.U, align 8
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 @sU, i64 16, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 8
  %6 = lshr i16 %5, 6
  %7 = and i16 %6, 1
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %4
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 8
  %12 = and i16 %10, 1
  %13 = shl i16 %12, 6
  %14 = and i16 %11, -65
  %15 = or i16 %14, %13
  store i16 %15, ptr %3, align 8
  %16 = load i16, ptr %3, align 8
  %17 = lshr i16 %16, 6
  %18 = and i16 %17, 1
  %19 = zext i16 %18 to i32
  %20 = srem i32 %19, 15
  %21 = trunc i32 %20 to i16
  %22 = load i16, ptr %3, align 8
  %23 = and i16 %21, 1
  %24 = shl i16 %23, 6
  %25 = and i16 %22, -65
  %26 = or i16 %25, %24
  store i16 %26, ptr %3, align 8
  %27 = load i16, ptr %3, align 8
  %28 = lshr i16 %27, 6
  %29 = and i16 %28, 1
  %30 = zext i16 %29 to i32
  ret i32 %30
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitU() #0 {
  %1 = load i16, ptr @sU, align 8
  %2 = lshr i16 %1, 6
  %3 = and i16 %2, 1
  %4 = zext i16 %3 to i32
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3U(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sU, align 8
  %5 = lshr i16 %4, 6
  %6 = and i16 %5, 1
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %3
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr @sU, align 8
  %11 = and i16 %9, 1
  %12 = shl i16 %11, 6
  %13 = and i16 %10, -65
  %14 = or i16 %13, %12
  store i16 %14, ptr @sU, align 8
  %15 = call i32 @retitU()
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testU() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.U, align 8
  %7 = alloca ptr, align 8
  store ptr @sU, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 16
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !27

20:                                               ; preds = %8
  %21 = load i16, ptr @sU, align 8
  %22 = and i16 %21, -65
  %23 = or i16 %22, 64
  store i16 %23, ptr @sU, align 8
  %24 = load i16, ptr @sU, align 8
  %25 = lshr i16 %24, 6
  %26 = and i16 %25, 1
  %27 = zext i16 %26 to i32
  store i32 %27, ptr %2, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %3, align 4
  %29 = call i32 @myrnd()
  store i32 %29, ptr %4, align 4
  %30 = load i32, ptr %3, align 4
  %31 = trunc i32 %30 to i16
  %32 = load i16, ptr @sU, align 8
  %33 = and i16 %31, 1
  %34 = shl i16 %33, 6
  %35 = and i16 %32, -65
  %36 = or i16 %35, %34
  store i16 %36, ptr @sU, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sU, i64 16, i1 false)
  %37 = load i32, ptr %4, align 4
  %38 = call i32 @fn1U(i32 noundef %37)
  store i32 %38, ptr %5, align 4
  %39 = load i16, ptr %6, align 8
  %40 = lshr i16 %39, 7
  %41 = zext i16 %40 to i32
  %42 = load i16, ptr @sU, align 8
  %43 = lshr i16 %42, 7
  %44 = zext i16 %43 to i32
  %45 = icmp ne i32 %41, %44
  br i1 %45, label %77, label %46

46:                                               ; preds = %20
  %47 = load i16, ptr %6, align 8
  %48 = and i16 %47, 63
  %49 = zext i16 %48 to i32
  %50 = load i16, ptr @sU, align 8
  %51 = and i16 %50, 63
  %52 = zext i16 %51 to i32
  %53 = icmp ne i32 %49, %52
  br i1 %53, label %77, label %54

54:                                               ; preds = %46
  %55 = load i16, ptr %6, align 8
  %56 = lshr i16 %55, 6
  %57 = and i16 %56, 1
  %58 = zext i16 %57 to i32
  %59 = load i16, ptr @sU, align 8
  %60 = lshr i16 %59, 6
  %61 = and i16 %60, 1
  %62 = zext i16 %61 to i32
  %63 = icmp ne i32 %58, %62
  br i1 %63, label %77, label %64

64:                                               ; preds = %54
  %65 = getelementptr inbounds nuw %struct.U, ptr %6, i32 0, i32 1
  %66 = load i64, ptr %65, align 8
  %67 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sU, i64 8), align 8
  %68 = icmp ne i64 %66, %67
  br i1 %68, label %77, label %69

69:                                               ; preds = %64
  %70 = load i32, ptr %3, align 4
  %71 = load i32, ptr %4, align 4
  %72 = add i32 %70, %71
  %73 = load i32, ptr %2, align 4
  %74 = and i32 %72, %73
  %75 = load i32, ptr %5, align 4
  %76 = icmp ne i32 %74, %75
  br i1 %76, label %77, label %78

77:                                               ; preds = %69, %64, %54, %46, %20
  call void @abort() #4
  unreachable

78:                                               ; preds = %69
  %79 = call i32 @myrnd()
  store i32 %79, ptr %3, align 4
  %80 = call i32 @myrnd()
  store i32 %80, ptr %4, align 4
  %81 = load i32, ptr %3, align 4
  %82 = trunc i32 %81 to i16
  %83 = load i16, ptr @sU, align 8
  %84 = and i16 %82, 1
  %85 = shl i16 %84, 6
  %86 = and i16 %83, -65
  %87 = or i16 %86, %85
  store i16 %87, ptr @sU, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sU, i64 16, i1 false)
  %88 = load i32, ptr %4, align 4
  %89 = call i32 @fn2U(i32 noundef %88)
  store i32 %89, ptr %5, align 4
  %90 = load i16, ptr %6, align 8
  %91 = lshr i16 %90, 7
  %92 = zext i16 %91 to i32
  %93 = load i16, ptr @sU, align 8
  %94 = lshr i16 %93, 7
  %95 = zext i16 %94 to i32
  %96 = icmp ne i32 %92, %95
  br i1 %96, label %131, label %97

97:                                               ; preds = %78
  %98 = load i16, ptr %6, align 8
  %99 = and i16 %98, 63
  %100 = zext i16 %99 to i32
  %101 = load i16, ptr @sU, align 8
  %102 = and i16 %101, 63
  %103 = zext i16 %102 to i32
  %104 = icmp ne i32 %100, %103
  br i1 %104, label %131, label %105

105:                                              ; preds = %97
  %106 = load i16, ptr %6, align 8
  %107 = lshr i16 %106, 6
  %108 = and i16 %107, 1
  %109 = zext i16 %108 to i32
  %110 = load i16, ptr @sU, align 8
  %111 = lshr i16 %110, 6
  %112 = and i16 %111, 1
  %113 = zext i16 %112 to i32
  %114 = icmp ne i32 %109, %113
  br i1 %114, label %131, label %115

115:                                              ; preds = %105
  %116 = getelementptr inbounds nuw %struct.U, ptr %6, i32 0, i32 1
  %117 = load i64, ptr %116, align 8
  %118 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sU, i64 8), align 8
  %119 = icmp ne i64 %117, %118
  br i1 %119, label %131, label %120

120:                                              ; preds = %115
  %121 = load i32, ptr %3, align 4
  %122 = load i32, ptr %4, align 4
  %123 = add i32 %121, %122
  %124 = load i32, ptr %2, align 4
  %125 = and i32 %123, %124
  %126 = urem i32 %125, 15
  %127 = load i32, ptr %2, align 4
  %128 = and i32 %126, %127
  %129 = load i32, ptr %5, align 4
  %130 = icmp ne i32 %128, %129
  br i1 %130, label %131, label %132

131:                                              ; preds = %120, %115, %105, %97, %78
  call void @abort() #4
  unreachable

132:                                              ; preds = %120
  %133 = call i32 @myrnd()
  store i32 %133, ptr %3, align 4
  %134 = call i32 @myrnd()
  store i32 %134, ptr %4, align 4
  %135 = load i32, ptr %3, align 4
  %136 = trunc i32 %135 to i16
  %137 = load i16, ptr @sU, align 8
  %138 = and i16 %136, 1
  %139 = shl i16 %138, 6
  %140 = and i16 %137, -65
  %141 = or i16 %140, %139
  store i16 %141, ptr @sU, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 @sU, i64 16, i1 false)
  %142 = load i32, ptr %4, align 4
  %143 = call i32 @fn3U(i32 noundef %142)
  store i32 %143, ptr %5, align 4
  %144 = load i16, ptr %6, align 8
  %145 = lshr i16 %144, 7
  %146 = zext i16 %145 to i32
  %147 = load i16, ptr @sU, align 8
  %148 = lshr i16 %147, 7
  %149 = zext i16 %148 to i32
  %150 = icmp ne i32 %146, %149
  br i1 %150, label %179, label %151

151:                                              ; preds = %132
  %152 = load i16, ptr %6, align 8
  %153 = and i16 %152, 63
  %154 = zext i16 %153 to i32
  %155 = load i16, ptr @sU, align 8
  %156 = and i16 %155, 63
  %157 = zext i16 %156 to i32
  %158 = icmp ne i32 %154, %157
  br i1 %158, label %179, label %159

159:                                              ; preds = %151
  %160 = load i16, ptr @sU, align 8
  %161 = lshr i16 %160, 6
  %162 = and i16 %161, 1
  %163 = zext i16 %162 to i32
  %164 = load i32, ptr %5, align 4
  %165 = icmp ne i32 %163, %164
  br i1 %165, label %179, label %166

166:                                              ; preds = %159
  %167 = getelementptr inbounds nuw %struct.U, ptr %6, i32 0, i32 1
  %168 = load i64, ptr %167, align 8
  %169 = load i64, ptr getelementptr inbounds nuw (i8, ptr @sU, i64 8), align 8
  %170 = icmp ne i64 %168, %169
  br i1 %170, label %179, label %171

171:                                              ; preds = %166
  %172 = load i32, ptr %3, align 4
  %173 = load i32, ptr %4, align 4
  %174 = add i32 %172, %173
  %175 = load i32, ptr %2, align 4
  %176 = and i32 %174, %175
  %177 = load i32, ptr %5, align 4
  %178 = icmp ne i32 %176, %177
  br i1 %178, label %179, label %180

179:                                              ; preds = %171, %166, %159, %151, %132
  call void @abort() #4
  unreachable

180:                                              ; preds = %171
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retmeV(i32 %0) #0 {
  %2 = alloca %struct.V, align 2
  %3 = alloca %struct.V, align 2
  store i32 %0, ptr %3, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %2, ptr align 2 %3, i64 4, i1 false)
  %4 = load i32, ptr %2, align 2
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1V(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.V, align 2
  %4 = alloca %struct.V, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sV, i64 4, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i16, ptr %3, align 2
  %7 = lshr i16 %6, 8
  %8 = and i16 %7, 1
  %9 = zext i16 %8 to i32
  %10 = add i32 %9, %5
  %11 = trunc i32 %10 to i16
  %12 = load i16, ptr %3, align 2
  %13 = and i16 %11, 1
  %14 = shl i16 %13, 8
  %15 = and i16 %12, -257
  %16 = or i16 %15, %14
  store i16 %16, ptr %3, align 2
  %17 = load i32, ptr %3, align 2
  %18 = call i32 @retmeV(i32 %17)
  store i32 %18, ptr %4, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 %4, i64 4, i1 false)
  %19 = load i16, ptr %3, align 2
  %20 = lshr i16 %19, 8
  %21 = and i16 %20, 1
  %22 = zext i16 %21 to i32
  ret i32 %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2V(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.V, align 2
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @sV, i64 4, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i16, ptr %3, align 2
  %6 = lshr i16 %5, 8
  %7 = and i16 %6, 1
  %8 = zext i16 %7 to i32
  %9 = add i32 %8, %4
  %10 = trunc i32 %9 to i16
  %11 = load i16, ptr %3, align 2
  %12 = and i16 %10, 1
  %13 = shl i16 %12, 8
  %14 = and i16 %11, -257
  %15 = or i16 %14, %13
  store i16 %15, ptr %3, align 2
  %16 = load i16, ptr %3, align 2
  %17 = lshr i16 %16, 8
  %18 = and i16 %17, 1
  %19 = zext i16 %18 to i32
  %20 = srem i32 %19, 15
  %21 = trunc i32 %20 to i16
  %22 = load i16, ptr %3, align 2
  %23 = and i16 %21, 1
  %24 = shl i16 %23, 8
  %25 = and i16 %22, -257
  %26 = or i16 %25, %24
  store i16 %26, ptr %3, align 2
  %27 = load i16, ptr %3, align 2
  %28 = lshr i16 %27, 8
  %29 = and i16 %28, 1
  %30 = zext i16 %29 to i32
  ret i32 %30
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitV() #0 {
  %1 = load i16, ptr @sV, align 2
  %2 = lshr i16 %1, 8
  %3 = and i16 %2, 1
  %4 = zext i16 %3 to i32
  ret i32 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3V(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i16, ptr @sV, align 2
  %5 = lshr i16 %4, 8
  %6 = and i16 %5, 1
  %7 = zext i16 %6 to i32
  %8 = add i32 %7, %3
  %9 = trunc i32 %8 to i16
  %10 = load i16, ptr @sV, align 2
  %11 = and i16 %9, 1
  %12 = shl i16 %11, 8
  %13 = and i16 %10, -257
  %14 = or i16 %13, %12
  store i16 %14, ptr @sV, align 2
  %15 = call i32 @retitV()
  ret i32 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testV() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.V, align 2
  %7 = alloca ptr, align 8
  store ptr @sV, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 4
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !28

20:                                               ; preds = %8
  %21 = load i16, ptr @sV, align 2
  %22 = and i16 %21, -257
  %23 = or i16 %22, 256
  store i16 %23, ptr @sV, align 2
  %24 = load i16, ptr @sV, align 2
  %25 = lshr i16 %24, 8
  %26 = and i16 %25, 1
  %27 = zext i16 %26 to i32
  store i32 %27, ptr %2, align 4
  %28 = call i32 @myrnd()
  store i32 %28, ptr %3, align 4
  %29 = call i32 @myrnd()
  store i32 %29, ptr %4, align 4
  %30 = load i32, ptr %3, align 4
  %31 = trunc i32 %30 to i16
  %32 = load i16, ptr @sV, align 2
  %33 = and i16 %31, 1
  %34 = shl i16 %33, 8
  %35 = and i16 %32, -257
  %36 = or i16 %35, %34
  store i16 %36, ptr @sV, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sV, i64 4, i1 false)
  %37 = load i32, ptr %4, align 4
  %38 = call i32 @fn1V(i32 noundef %37)
  store i32 %38, ptr %5, align 4
  %39 = load i16, ptr %6, align 2
  %40 = lshr i16 %39, 9
  %41 = zext i16 %40 to i32
  %42 = load i16, ptr @sV, align 2
  %43 = lshr i16 %42, 9
  %44 = zext i16 %43 to i32
  %45 = icmp ne i32 %41, %44
  br i1 %45, label %79, label %46

46:                                               ; preds = %20
  %47 = load i16, ptr %6, align 2
  %48 = and i16 %47, 255
  %49 = zext i16 %48 to i32
  %50 = load i16, ptr @sV, align 2
  %51 = and i16 %50, 255
  %52 = zext i16 %51 to i32
  %53 = icmp ne i32 %49, %52
  br i1 %53, label %79, label %54

54:                                               ; preds = %46
  %55 = load i16, ptr %6, align 2
  %56 = lshr i16 %55, 8
  %57 = and i16 %56, 1
  %58 = zext i16 %57 to i32
  %59 = load i16, ptr @sV, align 2
  %60 = lshr i16 %59, 8
  %61 = and i16 %60, 1
  %62 = zext i16 %61 to i32
  %63 = icmp ne i32 %58, %62
  br i1 %63, label %79, label %64

64:                                               ; preds = %54
  %65 = getelementptr inbounds nuw %struct.V, ptr %6, i32 0, i32 1
  %66 = load i16, ptr %65, align 2
  %67 = zext i16 %66 to i32
  %68 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sV, i64 2), align 2
  %69 = zext i16 %68 to i32
  %70 = icmp ne i32 %67, %69
  br i1 %70, label %79, label %71

71:                                               ; preds = %64
  %72 = load i32, ptr %3, align 4
  %73 = load i32, ptr %4, align 4
  %74 = add i32 %72, %73
  %75 = load i32, ptr %2, align 4
  %76 = and i32 %74, %75
  %77 = load i32, ptr %5, align 4
  %78 = icmp ne i32 %76, %77
  br i1 %78, label %79, label %80

79:                                               ; preds = %71, %64, %54, %46, %20
  call void @abort() #4
  unreachable

80:                                               ; preds = %71
  %81 = call i32 @myrnd()
  store i32 %81, ptr %3, align 4
  %82 = call i32 @myrnd()
  store i32 %82, ptr %4, align 4
  %83 = load i32, ptr %3, align 4
  %84 = trunc i32 %83 to i16
  %85 = load i16, ptr @sV, align 2
  %86 = and i16 %84, 1
  %87 = shl i16 %86, 8
  %88 = and i16 %85, -257
  %89 = or i16 %88, %87
  store i16 %89, ptr @sV, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sV, i64 4, i1 false)
  %90 = load i32, ptr %4, align 4
  %91 = call i32 @fn2V(i32 noundef %90)
  store i32 %91, ptr %5, align 4
  %92 = load i16, ptr %6, align 2
  %93 = lshr i16 %92, 9
  %94 = zext i16 %93 to i32
  %95 = load i16, ptr @sV, align 2
  %96 = lshr i16 %95, 9
  %97 = zext i16 %96 to i32
  %98 = icmp ne i32 %94, %97
  br i1 %98, label %135, label %99

99:                                               ; preds = %80
  %100 = load i16, ptr %6, align 2
  %101 = and i16 %100, 255
  %102 = zext i16 %101 to i32
  %103 = load i16, ptr @sV, align 2
  %104 = and i16 %103, 255
  %105 = zext i16 %104 to i32
  %106 = icmp ne i32 %102, %105
  br i1 %106, label %135, label %107

107:                                              ; preds = %99
  %108 = load i16, ptr %6, align 2
  %109 = lshr i16 %108, 8
  %110 = and i16 %109, 1
  %111 = zext i16 %110 to i32
  %112 = load i16, ptr @sV, align 2
  %113 = lshr i16 %112, 8
  %114 = and i16 %113, 1
  %115 = zext i16 %114 to i32
  %116 = icmp ne i32 %111, %115
  br i1 %116, label %135, label %117

117:                                              ; preds = %107
  %118 = getelementptr inbounds nuw %struct.V, ptr %6, i32 0, i32 1
  %119 = load i16, ptr %118, align 2
  %120 = zext i16 %119 to i32
  %121 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sV, i64 2), align 2
  %122 = zext i16 %121 to i32
  %123 = icmp ne i32 %120, %122
  br i1 %123, label %135, label %124

124:                                              ; preds = %117
  %125 = load i32, ptr %3, align 4
  %126 = load i32, ptr %4, align 4
  %127 = add i32 %125, %126
  %128 = load i32, ptr %2, align 4
  %129 = and i32 %127, %128
  %130 = urem i32 %129, 15
  %131 = load i32, ptr %2, align 4
  %132 = and i32 %130, %131
  %133 = load i32, ptr %5, align 4
  %134 = icmp ne i32 %132, %133
  br i1 %134, label %135, label %136

135:                                              ; preds = %124, %117, %107, %99, %80
  call void @abort() #4
  unreachable

136:                                              ; preds = %124
  %137 = call i32 @myrnd()
  store i32 %137, ptr %3, align 4
  %138 = call i32 @myrnd()
  store i32 %138, ptr %4, align 4
  %139 = load i32, ptr %3, align 4
  %140 = trunc i32 %139 to i16
  %141 = load i16, ptr @sV, align 2
  %142 = and i16 %140, 1
  %143 = shl i16 %142, 8
  %144 = and i16 %141, -257
  %145 = or i16 %144, %143
  store i16 %145, ptr @sV, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %6, ptr align 2 @sV, i64 4, i1 false)
  %146 = load i32, ptr %4, align 4
  %147 = call i32 @fn3V(i32 noundef %146)
  store i32 %147, ptr %5, align 4
  %148 = load i16, ptr %6, align 2
  %149 = lshr i16 %148, 9
  %150 = zext i16 %149 to i32
  %151 = load i16, ptr @sV, align 2
  %152 = lshr i16 %151, 9
  %153 = zext i16 %152 to i32
  %154 = icmp ne i32 %150, %153
  br i1 %154, label %185, label %155

155:                                              ; preds = %136
  %156 = load i16, ptr %6, align 2
  %157 = and i16 %156, 255
  %158 = zext i16 %157 to i32
  %159 = load i16, ptr @sV, align 2
  %160 = and i16 %159, 255
  %161 = zext i16 %160 to i32
  %162 = icmp ne i32 %158, %161
  br i1 %162, label %185, label %163

163:                                              ; preds = %155
  %164 = load i16, ptr @sV, align 2
  %165 = lshr i16 %164, 8
  %166 = and i16 %165, 1
  %167 = zext i16 %166 to i32
  %168 = load i32, ptr %5, align 4
  %169 = icmp ne i32 %167, %168
  br i1 %169, label %185, label %170

170:                                              ; preds = %163
  %171 = getelementptr inbounds nuw %struct.V, ptr %6, i32 0, i32 1
  %172 = load i16, ptr %171, align 2
  %173 = zext i16 %172 to i32
  %174 = load i16, ptr getelementptr inbounds nuw (i8, ptr @sV, i64 2), align 2
  %175 = zext i16 %174 to i32
  %176 = icmp ne i32 %173, %175
  br i1 %176, label %185, label %177

177:                                              ; preds = %170
  %178 = load i32, ptr %3, align 4
  %179 = load i32, ptr %4, align 4
  %180 = add i32 %178, %179
  %181 = load i32, ptr %2, align 4
  %182 = and i32 %180, %181
  %183 = load i32, ptr %5, align 4
  %184 = icmp ne i32 %182, %183
  br i1 %184, label %185, label %186

185:                                              ; preds = %177, %170, %163, %155, %136
  call void @abort() #4
  unreachable

186:                                              ; preds = %177
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @retmeW(ptr dead_on_unwind noalias writable sret(%struct.W) align 16 %0, ptr noundef byval(%struct.W) align 16 %1) #0 {
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 32, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1W(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.W, align 16
  %4 = alloca %struct.W, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sW, i64 32, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.W, ptr %3, i32 0, i32 1
  %7 = load i32, ptr %6, align 16
  %8 = and i32 %7, 4095
  %9 = add i32 %8, %5
  %10 = load i32, ptr %6, align 16
  %11 = and i32 %9, 4095
  %12 = and i32 %10, -4096
  %13 = or i32 %12, %11
  store i32 %13, ptr %6, align 16
  call void @retmeW(ptr dead_on_unwind writable sret(%struct.W) align 16 %4, ptr noundef byval(%struct.W) align 16 %3)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 %4, i64 32, i1 false)
  %14 = getelementptr inbounds nuw %struct.W, ptr %3, i32 0, i32 1
  %15 = load i32, ptr %14, align 16
  %16 = and i32 %15, 4095
  ret i32 %16
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2W(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.W, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sW, i64 32, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.W, ptr %3, i32 0, i32 1
  %6 = load i32, ptr %5, align 16
  %7 = and i32 %6, 4095
  %8 = add i32 %7, %4
  %9 = load i32, ptr %5, align 16
  %10 = and i32 %8, 4095
  %11 = and i32 %9, -4096
  %12 = or i32 %11, %10
  store i32 %12, ptr %5, align 16
  %13 = getelementptr inbounds nuw %struct.W, ptr %3, i32 0, i32 1
  %14 = load i32, ptr %13, align 16
  %15 = and i32 %14, 4095
  %16 = srem i32 %15, 15
  %17 = load i32, ptr %13, align 16
  %18 = and i32 %16, 4095
  %19 = and i32 %17, -4096
  %20 = or i32 %19, %18
  store i32 %20, ptr %13, align 16
  %21 = getelementptr inbounds nuw %struct.W, ptr %3, i32 0, i32 1
  %22 = load i32, ptr %21, align 16
  %23 = and i32 %22, 4095
  ret i32 %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitW() #0 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %2 = and i32 %1, 4095
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3W(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %5 = and i32 %4, 4095
  %6 = add i32 %5, %3
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %8 = and i32 %6, 4095
  %9 = and i32 %7, -4096
  %10 = or i32 %9, %8
  store i32 %10, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %11 = call i32 @retitW()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testW() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.W, align 16
  %7 = alloca ptr, align 8
  store ptr @sW, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 32
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !29

20:                                               ; preds = %8
  store x86_fp80 5.250000e+00, ptr @sW, align 16
  %21 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %22 = and i32 %21, -4096
  %23 = or i32 %22, 4095
  store i32 %23, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %25 = and i32 %24, 4095
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %30 = and i32 %28, 4095
  %31 = and i32 %29, -4096
  %32 = or i32 %31, %30
  store i32 %32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sW, i64 32, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1W(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %36 = load i32, ptr %35, align 16
  %37 = lshr i32 %36, 25
  %38 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %39 = lshr i32 %38, 25
  %40 = icmp ne i32 %37, %39
  br i1 %40, label %70, label %41

41:                                               ; preds = %20
  %42 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %43 = load i32, ptr %42, align 16
  %44 = lshr i32 %43, 12
  %45 = and i32 %44, 8191
  %46 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %47 = lshr i32 %46, 12
  %48 = and i32 %47, 8191
  %49 = icmp ne i32 %45, %48
  br i1 %49, label %70, label %50

50:                                               ; preds = %41
  %51 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %52 = load i32, ptr %51, align 16
  %53 = and i32 %52, 4095
  %54 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %55 = and i32 %54, 4095
  %56 = icmp ne i32 %53, %55
  br i1 %56, label %70, label %57

57:                                               ; preds = %50
  %58 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 0
  %59 = load x86_fp80, ptr %58, align 16
  %60 = load x86_fp80, ptr @sW, align 16
  %61 = fcmp une x86_fp80 %59, %60
  br i1 %61, label %70, label %62

62:                                               ; preds = %57
  %63 = load i32, ptr %3, align 4
  %64 = load i32, ptr %4, align 4
  %65 = add i32 %63, %64
  %66 = load i32, ptr %2, align 4
  %67 = and i32 %65, %66
  %68 = load i32, ptr %5, align 4
  %69 = icmp ne i32 %67, %68
  br i1 %69, label %70, label %71

70:                                               ; preds = %62, %57, %50, %41, %20
  call void @abort() #4
  unreachable

71:                                               ; preds = %62
  %72 = call i32 @myrnd()
  store i32 %72, ptr %3, align 4
  %73 = call i32 @myrnd()
  store i32 %73, ptr %4, align 4
  %74 = load i32, ptr %3, align 4
  %75 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %76 = and i32 %74, 4095
  %77 = and i32 %75, -4096
  %78 = or i32 %77, %76
  store i32 %78, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sW, i64 32, i1 false)
  %79 = load i32, ptr %4, align 4
  %80 = call i32 @fn2W(i32 noundef %79)
  store i32 %80, ptr %5, align 4
  %81 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %82 = load i32, ptr %81, align 16
  %83 = lshr i32 %82, 25
  %84 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %85 = lshr i32 %84, 25
  %86 = icmp ne i32 %83, %85
  br i1 %86, label %119, label %87

87:                                               ; preds = %71
  %88 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %89 = load i32, ptr %88, align 16
  %90 = lshr i32 %89, 12
  %91 = and i32 %90, 8191
  %92 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %93 = lshr i32 %92, 12
  %94 = and i32 %93, 8191
  %95 = icmp ne i32 %91, %94
  br i1 %95, label %119, label %96

96:                                               ; preds = %87
  %97 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %98 = load i32, ptr %97, align 16
  %99 = and i32 %98, 4095
  %100 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %101 = and i32 %100, 4095
  %102 = icmp ne i32 %99, %101
  br i1 %102, label %119, label %103

103:                                              ; preds = %96
  %104 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 0
  %105 = load x86_fp80, ptr %104, align 16
  %106 = load x86_fp80, ptr @sW, align 16
  %107 = fcmp une x86_fp80 %105, %106
  br i1 %107, label %119, label %108

108:                                              ; preds = %103
  %109 = load i32, ptr %3, align 4
  %110 = load i32, ptr %4, align 4
  %111 = add i32 %109, %110
  %112 = load i32, ptr %2, align 4
  %113 = and i32 %111, %112
  %114 = urem i32 %113, 15
  %115 = load i32, ptr %2, align 4
  %116 = and i32 %114, %115
  %117 = load i32, ptr %5, align 4
  %118 = icmp ne i32 %116, %117
  br i1 %118, label %119, label %120

119:                                              ; preds = %108, %103, %96, %87, %71
  call void @abort() #4
  unreachable

120:                                              ; preds = %108
  %121 = call i32 @myrnd()
  store i32 %121, ptr %3, align 4
  %122 = call i32 @myrnd()
  store i32 %122, ptr %4, align 4
  %123 = load i32, ptr %3, align 4
  %124 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %125 = and i32 %123, 4095
  %126 = and i32 %124, -4096
  %127 = or i32 %126, %125
  store i32 %127, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sW, i64 32, i1 false)
  %128 = load i32, ptr %4, align 4
  %129 = call i32 @fn3W(i32 noundef %128)
  store i32 %129, ptr %5, align 4
  %130 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %131 = load i32, ptr %130, align 16
  %132 = lshr i32 %131, 25
  %133 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %134 = lshr i32 %133, 25
  %135 = icmp ne i32 %132, %134
  br i1 %135, label %163, label %136

136:                                              ; preds = %120
  %137 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 1
  %138 = load i32, ptr %137, align 16
  %139 = lshr i32 %138, 12
  %140 = and i32 %139, 8191
  %141 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %142 = lshr i32 %141, 12
  %143 = and i32 %142, 8191
  %144 = icmp ne i32 %140, %143
  br i1 %144, label %163, label %145

145:                                              ; preds = %136
  %146 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sW, i64 16), align 16
  %147 = and i32 %146, 4095
  %148 = load i32, ptr %5, align 4
  %149 = icmp ne i32 %147, %148
  br i1 %149, label %163, label %150

150:                                              ; preds = %145
  %151 = getelementptr inbounds nuw %struct.W, ptr %6, i32 0, i32 0
  %152 = load x86_fp80, ptr %151, align 16
  %153 = load x86_fp80, ptr @sW, align 16
  %154 = fcmp une x86_fp80 %152, %153
  br i1 %154, label %163, label %155

155:                                              ; preds = %150
  %156 = load i32, ptr %3, align 4
  %157 = load i32, ptr %4, align 4
  %158 = add i32 %156, %157
  %159 = load i32, ptr %2, align 4
  %160 = and i32 %158, %159
  %161 = load i32, ptr %5, align 4
  %162 = icmp ne i32 %160, %161
  br i1 %162, label %163, label %164

163:                                              ; preds = %155, %150, %145, %136, %120
  call void @abort() #4
  unreachable

164:                                              ; preds = %155
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @retmeX(ptr dead_on_unwind noalias writable sret(%struct.X) align 16 %0, ptr noundef byval(%struct.X) align 16 %1) #0 {
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 32, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1X(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.X, align 16
  %4 = alloca %struct.X, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sX, i64 32, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 16
  %7 = and i32 %6, 4095
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 16
  %10 = and i32 %8, 4095
  %11 = and i32 %9, -4096
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 16
  call void @retmeX(ptr dead_on_unwind writable sret(%struct.X) align 16 %4, ptr noundef byval(%struct.X) align 16 %3)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 %4, i64 32, i1 false)
  %13 = load i32, ptr %3, align 16
  %14 = and i32 %13, 4095
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2X(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.X, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sX, i64 32, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 16
  %6 = and i32 %5, 4095
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 16
  %9 = and i32 %7, 4095
  %10 = and i32 %8, -4096
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 16
  %12 = load i32, ptr %3, align 16
  %13 = and i32 %12, 4095
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 16
  %16 = and i32 %14, 4095
  %17 = and i32 %15, -4096
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 16
  %19 = load i32, ptr %3, align 16
  %20 = and i32 %19, 4095
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitX() #0 {
  %1 = load i32, ptr @sX, align 16
  %2 = and i32 %1, 4095
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3X(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sX, align 16
  %5 = and i32 %4, 4095
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sX, align 16
  %8 = and i32 %6, 4095
  %9 = and i32 %7, -4096
  %10 = or i32 %9, %8
  store i32 %10, ptr @sX, align 16
  %11 = call i32 @retitX()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testX() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.X, align 16
  %7 = alloca ptr, align 8
  store ptr @sX, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 32
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !30

20:                                               ; preds = %8
  store x86_fp80 5.250000e+00, ptr getelementptr inbounds nuw (i8, ptr @sX, i64 16), align 16
  %21 = load i32, ptr @sX, align 16
  %22 = and i32 %21, -4096
  %23 = or i32 %22, 4095
  store i32 %23, ptr @sX, align 16
  %24 = load i32, ptr @sX, align 16
  %25 = and i32 %24, 4095
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sX, align 16
  %30 = and i32 %28, 4095
  %31 = and i32 %29, -4096
  %32 = or i32 %31, %30
  store i32 %32, ptr @sX, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sX, i64 32, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1X(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 16
  %36 = lshr i32 %35, 25
  %37 = load i32, ptr @sX, align 16
  %38 = lshr i32 %37, 25
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %67, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 16
  %42 = lshr i32 %41, 12
  %43 = and i32 %42, 8191
  %44 = load i32, ptr @sX, align 16
  %45 = lshr i32 %44, 12
  %46 = and i32 %45, 8191
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %67, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 16
  %50 = and i32 %49, 4095
  %51 = load i32, ptr @sX, align 16
  %52 = and i32 %51, 4095
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %67, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw %struct.X, ptr %6, i32 0, i32 1
  %56 = load x86_fp80, ptr %55, align 16
  %57 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sX, i64 16), align 16
  %58 = fcmp une x86_fp80 %56, %57
  br i1 %58, label %67, label %59

59:                                               ; preds = %54
  %60 = load i32, ptr %3, align 4
  %61 = load i32, ptr %4, align 4
  %62 = add i32 %60, %61
  %63 = load i32, ptr %2, align 4
  %64 = and i32 %62, %63
  %65 = load i32, ptr %5, align 4
  %66 = icmp ne i32 %64, %65
  br i1 %66, label %67, label %68

67:                                               ; preds = %59, %54, %48, %40, %20
  call void @abort() #4
  unreachable

68:                                               ; preds = %59
  %69 = call i32 @myrnd()
  store i32 %69, ptr %3, align 4
  %70 = call i32 @myrnd()
  store i32 %70, ptr %4, align 4
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr @sX, align 16
  %73 = and i32 %71, 4095
  %74 = and i32 %72, -4096
  %75 = or i32 %74, %73
  store i32 %75, ptr @sX, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sX, i64 32, i1 false)
  %76 = load i32, ptr %4, align 4
  %77 = call i32 @fn2X(i32 noundef %76)
  store i32 %77, ptr %5, align 4
  %78 = load i32, ptr %6, align 16
  %79 = lshr i32 %78, 25
  %80 = load i32, ptr @sX, align 16
  %81 = lshr i32 %80, 25
  %82 = icmp ne i32 %79, %81
  br i1 %82, label %113, label %83

83:                                               ; preds = %68
  %84 = load i32, ptr %6, align 16
  %85 = lshr i32 %84, 12
  %86 = and i32 %85, 8191
  %87 = load i32, ptr @sX, align 16
  %88 = lshr i32 %87, 12
  %89 = and i32 %88, 8191
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %113, label %91

91:                                               ; preds = %83
  %92 = load i32, ptr %6, align 16
  %93 = and i32 %92, 4095
  %94 = load i32, ptr @sX, align 16
  %95 = and i32 %94, 4095
  %96 = icmp ne i32 %93, %95
  br i1 %96, label %113, label %97

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw %struct.X, ptr %6, i32 0, i32 1
  %99 = load x86_fp80, ptr %98, align 16
  %100 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sX, i64 16), align 16
  %101 = fcmp une x86_fp80 %99, %100
  br i1 %101, label %113, label %102

102:                                              ; preds = %97
  %103 = load i32, ptr %3, align 4
  %104 = load i32, ptr %4, align 4
  %105 = add i32 %103, %104
  %106 = load i32, ptr %2, align 4
  %107 = and i32 %105, %106
  %108 = urem i32 %107, 15
  %109 = load i32, ptr %2, align 4
  %110 = and i32 %108, %109
  %111 = load i32, ptr %5, align 4
  %112 = icmp ne i32 %110, %111
  br i1 %112, label %113, label %114

113:                                              ; preds = %102, %97, %91, %83, %68
  call void @abort() #4
  unreachable

114:                                              ; preds = %102
  %115 = call i32 @myrnd()
  store i32 %115, ptr %3, align 4
  %116 = call i32 @myrnd()
  store i32 %116, ptr %4, align 4
  %117 = load i32, ptr %3, align 4
  %118 = load i32, ptr @sX, align 16
  %119 = and i32 %117, 4095
  %120 = and i32 %118, -4096
  %121 = or i32 %120, %119
  store i32 %121, ptr @sX, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sX, i64 32, i1 false)
  %122 = load i32, ptr %4, align 4
  %123 = call i32 @fn3X(i32 noundef %122)
  store i32 %123, ptr %5, align 4
  %124 = load i32, ptr %6, align 16
  %125 = lshr i32 %124, 25
  %126 = load i32, ptr @sX, align 16
  %127 = lshr i32 %126, 25
  %128 = icmp ne i32 %125, %127
  br i1 %128, label %155, label %129

129:                                              ; preds = %114
  %130 = load i32, ptr %6, align 16
  %131 = lshr i32 %130, 12
  %132 = and i32 %131, 8191
  %133 = load i32, ptr @sX, align 16
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 8191
  %136 = icmp ne i32 %132, %135
  br i1 %136, label %155, label %137

137:                                              ; preds = %129
  %138 = load i32, ptr @sX, align 16
  %139 = and i32 %138, 4095
  %140 = load i32, ptr %5, align 4
  %141 = icmp ne i32 %139, %140
  br i1 %141, label %155, label %142

142:                                              ; preds = %137
  %143 = getelementptr inbounds nuw %struct.X, ptr %6, i32 0, i32 1
  %144 = load x86_fp80, ptr %143, align 16
  %145 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sX, i64 16), align 16
  %146 = fcmp une x86_fp80 %144, %145
  br i1 %146, label %155, label %147

147:                                              ; preds = %142
  %148 = load i32, ptr %3, align 4
  %149 = load i32, ptr %4, align 4
  %150 = add i32 %148, %149
  %151 = load i32, ptr %2, align 4
  %152 = and i32 %150, %151
  %153 = load i32, ptr %5, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %155, label %156

155:                                              ; preds = %147, %142, %137, %129, %114
  call void @abort() #4
  unreachable

156:                                              ; preds = %147
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @retmeY(ptr dead_on_unwind noalias writable sret(%struct.Y) align 16 %0, ptr noundef byval(%struct.Y) align 16 %1) #0 {
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 32, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1Y(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Y, align 16
  %4 = alloca %struct.Y, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sY, i64 32, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = load i32, ptr %3, align 16
  %7 = and i32 %6, 4095
  %8 = add i32 %7, %5
  %9 = load i32, ptr %3, align 16
  %10 = and i32 %8, 4095
  %11 = and i32 %9, -4096
  %12 = or i32 %11, %10
  store i32 %12, ptr %3, align 16
  call void @retmeY(ptr dead_on_unwind writable sret(%struct.Y) align 16 %4, ptr noundef byval(%struct.Y) align 16 %3)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 %4, i64 32, i1 false)
  %13 = load i32, ptr %3, align 16
  %14 = and i32 %13, 4095
  ret i32 %14
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2Y(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Y, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sY, i64 32, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = load i32, ptr %3, align 16
  %6 = and i32 %5, 4095
  %7 = add i32 %6, %4
  %8 = load i32, ptr %3, align 16
  %9 = and i32 %7, 4095
  %10 = and i32 %8, -4096
  %11 = or i32 %10, %9
  store i32 %11, ptr %3, align 16
  %12 = load i32, ptr %3, align 16
  %13 = and i32 %12, 4095
  %14 = srem i32 %13, 15
  %15 = load i32, ptr %3, align 16
  %16 = and i32 %14, 4095
  %17 = and i32 %15, -4096
  %18 = or i32 %17, %16
  store i32 %18, ptr %3, align 16
  %19 = load i32, ptr %3, align 16
  %20 = and i32 %19, 4095
  ret i32 %20
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitY() #0 {
  %1 = load i32, ptr @sY, align 16
  %2 = and i32 %1, 4095
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3Y(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr @sY, align 16
  %5 = and i32 %4, 4095
  %6 = add i32 %5, %3
  %7 = load i32, ptr @sY, align 16
  %8 = and i32 %6, 4095
  %9 = and i32 %7, -4096
  %10 = or i32 %9, %8
  store i32 %10, ptr @sY, align 16
  %11 = call i32 @retitY()
  ret i32 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testY() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.Y, align 16
  %7 = alloca ptr, align 8
  store ptr @sY, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 32
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !31

20:                                               ; preds = %8
  store x86_fp80 5.250000e+00, ptr getelementptr inbounds nuw (i8, ptr @sY, i64 16), align 16
  %21 = load i32, ptr @sY, align 16
  %22 = and i32 %21, -4096
  %23 = or i32 %22, 4095
  store i32 %23, ptr @sY, align 16
  %24 = load i32, ptr @sY, align 16
  %25 = and i32 %24, 4095
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr @sY, align 16
  %30 = and i32 %28, 4095
  %31 = and i32 %29, -4096
  %32 = or i32 %31, %30
  store i32 %32, ptr @sY, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sY, i64 32, i1 false)
  %33 = load i32, ptr %4, align 4
  %34 = call i32 @fn1Y(i32 noundef %33)
  store i32 %34, ptr %5, align 4
  %35 = load i32, ptr %6, align 16
  %36 = lshr i32 %35, 23
  %37 = load i32, ptr @sY, align 16
  %38 = lshr i32 %37, 23
  %39 = icmp ne i32 %36, %38
  br i1 %39, label %67, label %40

40:                                               ; preds = %20
  %41 = load i32, ptr %6, align 16
  %42 = lshr i32 %41, 12
  %43 = and i32 %42, 2047
  %44 = load i32, ptr @sY, align 16
  %45 = lshr i32 %44, 12
  %46 = and i32 %45, 2047
  %47 = icmp ne i32 %43, %46
  br i1 %47, label %67, label %48

48:                                               ; preds = %40
  %49 = load i32, ptr %6, align 16
  %50 = and i32 %49, 4095
  %51 = load i32, ptr @sY, align 16
  %52 = and i32 %51, 4095
  %53 = icmp ne i32 %50, %52
  br i1 %53, label %67, label %54

54:                                               ; preds = %48
  %55 = getelementptr inbounds nuw %struct.Y, ptr %6, i32 0, i32 1
  %56 = load x86_fp80, ptr %55, align 16
  %57 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sY, i64 16), align 16
  %58 = fcmp une x86_fp80 %56, %57
  br i1 %58, label %67, label %59

59:                                               ; preds = %54
  %60 = load i32, ptr %3, align 4
  %61 = load i32, ptr %4, align 4
  %62 = add i32 %60, %61
  %63 = load i32, ptr %2, align 4
  %64 = and i32 %62, %63
  %65 = load i32, ptr %5, align 4
  %66 = icmp ne i32 %64, %65
  br i1 %66, label %67, label %68

67:                                               ; preds = %59, %54, %48, %40, %20
  call void @abort() #4
  unreachable

68:                                               ; preds = %59
  %69 = call i32 @myrnd()
  store i32 %69, ptr %3, align 4
  %70 = call i32 @myrnd()
  store i32 %70, ptr %4, align 4
  %71 = load i32, ptr %3, align 4
  %72 = load i32, ptr @sY, align 16
  %73 = and i32 %71, 4095
  %74 = and i32 %72, -4096
  %75 = or i32 %74, %73
  store i32 %75, ptr @sY, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sY, i64 32, i1 false)
  %76 = load i32, ptr %4, align 4
  %77 = call i32 @fn2Y(i32 noundef %76)
  store i32 %77, ptr %5, align 4
  %78 = load i32, ptr %6, align 16
  %79 = lshr i32 %78, 23
  %80 = load i32, ptr @sY, align 16
  %81 = lshr i32 %80, 23
  %82 = icmp ne i32 %79, %81
  br i1 %82, label %113, label %83

83:                                               ; preds = %68
  %84 = load i32, ptr %6, align 16
  %85 = lshr i32 %84, 12
  %86 = and i32 %85, 2047
  %87 = load i32, ptr @sY, align 16
  %88 = lshr i32 %87, 12
  %89 = and i32 %88, 2047
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %113, label %91

91:                                               ; preds = %83
  %92 = load i32, ptr %6, align 16
  %93 = and i32 %92, 4095
  %94 = load i32, ptr @sY, align 16
  %95 = and i32 %94, 4095
  %96 = icmp ne i32 %93, %95
  br i1 %96, label %113, label %97

97:                                               ; preds = %91
  %98 = getelementptr inbounds nuw %struct.Y, ptr %6, i32 0, i32 1
  %99 = load x86_fp80, ptr %98, align 16
  %100 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sY, i64 16), align 16
  %101 = fcmp une x86_fp80 %99, %100
  br i1 %101, label %113, label %102

102:                                              ; preds = %97
  %103 = load i32, ptr %3, align 4
  %104 = load i32, ptr %4, align 4
  %105 = add i32 %103, %104
  %106 = load i32, ptr %2, align 4
  %107 = and i32 %105, %106
  %108 = urem i32 %107, 15
  %109 = load i32, ptr %2, align 4
  %110 = and i32 %108, %109
  %111 = load i32, ptr %5, align 4
  %112 = icmp ne i32 %110, %111
  br i1 %112, label %113, label %114

113:                                              ; preds = %102, %97, %91, %83, %68
  call void @abort() #4
  unreachable

114:                                              ; preds = %102
  %115 = call i32 @myrnd()
  store i32 %115, ptr %3, align 4
  %116 = call i32 @myrnd()
  store i32 %116, ptr %4, align 4
  %117 = load i32, ptr %3, align 4
  %118 = load i32, ptr @sY, align 16
  %119 = and i32 %117, 4095
  %120 = and i32 %118, -4096
  %121 = or i32 %120, %119
  store i32 %121, ptr @sY, align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sY, i64 32, i1 false)
  %122 = load i32, ptr %4, align 4
  %123 = call i32 @fn3Y(i32 noundef %122)
  store i32 %123, ptr %5, align 4
  %124 = load i32, ptr %6, align 16
  %125 = lshr i32 %124, 23
  %126 = load i32, ptr @sY, align 16
  %127 = lshr i32 %126, 23
  %128 = icmp ne i32 %125, %127
  br i1 %128, label %155, label %129

129:                                              ; preds = %114
  %130 = load i32, ptr %6, align 16
  %131 = lshr i32 %130, 12
  %132 = and i32 %131, 2047
  %133 = load i32, ptr @sY, align 16
  %134 = lshr i32 %133, 12
  %135 = and i32 %134, 2047
  %136 = icmp ne i32 %132, %135
  br i1 %136, label %155, label %137

137:                                              ; preds = %129
  %138 = load i32, ptr @sY, align 16
  %139 = and i32 %138, 4095
  %140 = load i32, ptr %5, align 4
  %141 = icmp ne i32 %139, %140
  br i1 %141, label %155, label %142

142:                                              ; preds = %137
  %143 = getelementptr inbounds nuw %struct.Y, ptr %6, i32 0, i32 1
  %144 = load x86_fp80, ptr %143, align 16
  %145 = load x86_fp80, ptr getelementptr inbounds nuw (i8, ptr @sY, i64 16), align 16
  %146 = fcmp une x86_fp80 %144, %145
  br i1 %146, label %155, label %147

147:                                              ; preds = %142
  %148 = load i32, ptr %3, align 4
  %149 = load i32, ptr %4, align 4
  %150 = add i32 %148, %149
  %151 = load i32, ptr %2, align 4
  %152 = and i32 %150, %151
  %153 = load i32, ptr %5, align 4
  %154 = icmp ne i32 %152, %153
  br i1 %154, label %155, label %156

155:                                              ; preds = %147, %142, %137, %129, %114
  call void @abort() #4
  unreachable

156:                                              ; preds = %147
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @retmeZ(ptr dead_on_unwind noalias writable sret(%struct.Z) align 16 %0, ptr noundef byval(%struct.Z) align 16 %1) #0 {
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %1, i64 32, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn1Z(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Z, align 16
  %4 = alloca %struct.Z, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sZ, i64 32, i1 false)
  %5 = load i32, ptr %2, align 4
  %6 = getelementptr inbounds nuw %struct.Z, ptr %3, i32 0, i32 1
  %7 = load i32, ptr %6, align 16
  %8 = lshr i32 %7, 20
  %9 = add i32 %8, %5
  %10 = load i32, ptr %6, align 16
  %11 = and i32 %9, 4095
  %12 = shl i32 %11, 20
  %13 = and i32 %10, 1048575
  %14 = or i32 %13, %12
  store i32 %14, ptr %6, align 16
  call void @retmeZ(ptr dead_on_unwind writable sret(%struct.Z) align 16 %4, ptr noundef byval(%struct.Z) align 16 %3)
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 %4, i64 32, i1 false)
  %15 = getelementptr inbounds nuw %struct.Z, ptr %3, i32 0, i32 1
  %16 = load i32, ptr %15, align 16
  %17 = lshr i32 %16, 20
  ret i32 %17
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn2Z(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %struct.Z, align 16
  store i32 %0, ptr %2, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %3, ptr align 16 @sZ, i64 32, i1 false)
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw %struct.Z, ptr %3, i32 0, i32 1
  %6 = load i32, ptr %5, align 16
  %7 = lshr i32 %6, 20
  %8 = add i32 %7, %4
  %9 = load i32, ptr %5, align 16
  %10 = and i32 %8, 4095
  %11 = shl i32 %10, 20
  %12 = and i32 %9, 1048575
  %13 = or i32 %12, %11
  store i32 %13, ptr %5, align 16
  %14 = getelementptr inbounds nuw %struct.Z, ptr %3, i32 0, i32 1
  %15 = load i32, ptr %14, align 16
  %16 = lshr i32 %15, 20
  %17 = srem i32 %16, 15
  %18 = load i32, ptr %14, align 16
  %19 = and i32 %17, 4095
  %20 = shl i32 %19, 20
  %21 = and i32 %18, 1048575
  %22 = or i32 %21, %20
  store i32 %22, ptr %14, align 16
  %23 = getelementptr inbounds nuw %struct.Z, ptr %3, i32 0, i32 1
  %24 = load i32, ptr %23, align 16
  %25 = lshr i32 %24, 20
  ret i32 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @retitZ() #0 {
  %1 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %2 = lshr i32 %1, 20
  ret i32 %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @fn3Z(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %5 = lshr i32 %4, 20
  %6 = add i32 %5, %3
  %7 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %8 = and i32 %6, 4095
  %9 = shl i32 %8, 20
  %10 = and i32 %7, 1048575
  %11 = or i32 %10, %9
  store i32 %11, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %12 = call i32 @retitZ()
  ret i32 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @testZ() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca %struct.Z, align 16
  %7 = alloca ptr, align 8
  store ptr @sZ, ptr %7, align 8
  store i32 0, ptr %1, align 4
  br label %8

8:                                                ; preds = %17, %0
  %9 = load i32, ptr %1, align 4
  %10 = sext i32 %9 to i64
  %11 = icmp ult i64 %10, 32
  br i1 %11, label %12, label %20

12:                                               ; preds = %8
  %13 = call i32 @myrnd()
  %14 = trunc i32 %13 to i8
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds nuw i8, ptr %15, i32 1
  store ptr %16, ptr %7, align 8
  store i8 %14, ptr %15, align 1
  br label %17

17:                                               ; preds = %12
  %18 = load i32, ptr %1, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %1, align 4
  br label %8, !llvm.loop !32

20:                                               ; preds = %8
  store x86_fp80 5.250000e+00, ptr @sZ, align 16
  %21 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %22 = and i32 %21, 1048575
  %23 = or i32 %22, -1048576
  store i32 %23, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %24 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %25 = lshr i32 %24, 20
  store i32 %25, ptr %2, align 4
  %26 = call i32 @myrnd()
  store i32 %26, ptr %3, align 4
  %27 = call i32 @myrnd()
  store i32 %27, ptr %4, align 4
  %28 = load i32, ptr %3, align 4
  %29 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %30 = and i32 %28, 4095
  %31 = shl i32 %30, 20
  %32 = and i32 %29, 1048575
  %33 = or i32 %32, %31
  store i32 %33, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sZ, i64 32, i1 false)
  %34 = load i32, ptr %4, align 4
  %35 = call i32 @fn1Z(i32 noundef %34)
  store i32 %35, ptr %5, align 4
  %36 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %37 = load i32, ptr %36, align 16
  %38 = lshr i32 %37, 13
  %39 = and i32 %38, 127
  %40 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %41 = lshr i32 %40, 13
  %42 = and i32 %41, 127
  %43 = icmp ne i32 %39, %42
  br i1 %43, label %71, label %44

44:                                               ; preds = %20
  %45 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %46 = load i32, ptr %45, align 16
  %47 = and i32 %46, 8191
  %48 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %49 = and i32 %48, 8191
  %50 = icmp ne i32 %47, %49
  br i1 %50, label %71, label %51

51:                                               ; preds = %44
  %52 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %53 = load i32, ptr %52, align 16
  %54 = lshr i32 %53, 20
  %55 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %56 = lshr i32 %55, 20
  %57 = icmp ne i32 %54, %56
  br i1 %57, label %71, label %58

58:                                               ; preds = %51
  %59 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 0
  %60 = load x86_fp80, ptr %59, align 16
  %61 = load x86_fp80, ptr @sZ, align 16
  %62 = fcmp une x86_fp80 %60, %61
  br i1 %62, label %71, label %63

63:                                               ; preds = %58
  %64 = load i32, ptr %3, align 4
  %65 = load i32, ptr %4, align 4
  %66 = add i32 %64, %65
  %67 = load i32, ptr %2, align 4
  %68 = and i32 %66, %67
  %69 = load i32, ptr %5, align 4
  %70 = icmp ne i32 %68, %69
  br i1 %70, label %71, label %72

71:                                               ; preds = %63, %58, %51, %44, %20
  call void @abort() #4
  unreachable

72:                                               ; preds = %63
  %73 = call i32 @myrnd()
  store i32 %73, ptr %3, align 4
  %74 = call i32 @myrnd()
  store i32 %74, ptr %4, align 4
  %75 = load i32, ptr %3, align 4
  %76 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %77 = and i32 %75, 4095
  %78 = shl i32 %77, 20
  %79 = and i32 %76, 1048575
  %80 = or i32 %79, %78
  store i32 %80, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sZ, i64 32, i1 false)
  %81 = load i32, ptr %4, align 4
  %82 = call i32 @fn2Z(i32 noundef %81)
  store i32 %82, ptr %5, align 4
  %83 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %84 = load i32, ptr %83, align 16
  %85 = lshr i32 %84, 13
  %86 = and i32 %85, 127
  %87 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %88 = lshr i32 %87, 13
  %89 = and i32 %88, 127
  %90 = icmp ne i32 %86, %89
  br i1 %90, label %121, label %91

91:                                               ; preds = %72
  %92 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %93 = load i32, ptr %92, align 16
  %94 = and i32 %93, 8191
  %95 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %96 = and i32 %95, 8191
  %97 = icmp ne i32 %94, %96
  br i1 %97, label %121, label %98

98:                                               ; preds = %91
  %99 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %100 = load i32, ptr %99, align 16
  %101 = lshr i32 %100, 20
  %102 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %103 = lshr i32 %102, 20
  %104 = icmp ne i32 %101, %103
  br i1 %104, label %121, label %105

105:                                              ; preds = %98
  %106 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 0
  %107 = load x86_fp80, ptr %106, align 16
  %108 = load x86_fp80, ptr @sZ, align 16
  %109 = fcmp une x86_fp80 %107, %108
  br i1 %109, label %121, label %110

110:                                              ; preds = %105
  %111 = load i32, ptr %3, align 4
  %112 = load i32, ptr %4, align 4
  %113 = add i32 %111, %112
  %114 = load i32, ptr %2, align 4
  %115 = and i32 %113, %114
  %116 = urem i32 %115, 15
  %117 = load i32, ptr %2, align 4
  %118 = and i32 %116, %117
  %119 = load i32, ptr %5, align 4
  %120 = icmp ne i32 %118, %119
  br i1 %120, label %121, label %122

121:                                              ; preds = %110, %105, %98, %91, %72
  call void @abort() #4
  unreachable

122:                                              ; preds = %110
  %123 = call i32 @myrnd()
  store i32 %123, ptr %3, align 4
  %124 = call i32 @myrnd()
  store i32 %124, ptr %4, align 4
  %125 = load i32, ptr %3, align 4
  %126 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %127 = and i32 %125, 4095
  %128 = shl i32 %127, 20
  %129 = and i32 %126, 1048575
  %130 = or i32 %129, %128
  store i32 %130, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @sZ, i64 32, i1 false)
  %131 = load i32, ptr %4, align 4
  %132 = call i32 @fn3Z(i32 noundef %131)
  store i32 %132, ptr %5, align 4
  %133 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %134 = load i32, ptr %133, align 16
  %135 = lshr i32 %134, 13
  %136 = and i32 %135, 127
  %137 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %138 = lshr i32 %137, 13
  %139 = and i32 %138, 127
  %140 = icmp ne i32 %136, %139
  br i1 %140, label %166, label %141

141:                                              ; preds = %122
  %142 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 1
  %143 = load i32, ptr %142, align 16
  %144 = and i32 %143, 8191
  %145 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %146 = and i32 %145, 8191
  %147 = icmp ne i32 %144, %146
  br i1 %147, label %166, label %148

148:                                              ; preds = %141
  %149 = load i32, ptr getelementptr inbounds nuw (i8, ptr @sZ, i64 16), align 16
  %150 = lshr i32 %149, 20
  %151 = load i32, ptr %5, align 4
  %152 = icmp ne i32 %150, %151
  br i1 %152, label %166, label %153

153:                                              ; preds = %148
  %154 = getelementptr inbounds nuw %struct.Z, ptr %6, i32 0, i32 0
  %155 = load x86_fp80, ptr %154, align 16
  %156 = load x86_fp80, ptr @sZ, align 16
  %157 = fcmp une x86_fp80 %155, %156
  br i1 %157, label %166, label %158

158:                                              ; preds = %153
  %159 = load i32, ptr %3, align 4
  %160 = load i32, ptr %4, align 4
  %161 = add i32 %159, %160
  %162 = load i32, ptr %2, align 4
  %163 = and i32 %161, %162
  %164 = load i32, ptr %5, align 4
  %165 = icmp ne i32 %163, %164
  br i1 %165, label %166, label %167

166:                                              ; preds = %158, %153, %148, %141, %122
  call void @abort() #4
  unreachable

167:                                              ; preds = %158
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @testA()
  call void @testB()
  call void @testC()
  call void @testD()
  call void @testE()
  call void @testF()
  call void @testG()
  call void @testH()
  call void @testI()
  call void @testJ()
  call void @testK()
  call void @testL()
  call void @testM()
  call void @testN()
  call void @testO()
  call void @testP()
  call void @testQ()
  call void @testR()
  call void @testS()
  call void @testT()
  call void @testU()
  call void @testV()
  call void @testW()
  call void @testX()
  call void @testY()
  call void @testZ()
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = distinct !{!19, !7}
!20 = distinct !{!20, !7}
!21 = distinct !{!21, !7}
!22 = distinct !{!22, !7}
!23 = distinct !{!23, !7}
!24 = distinct !{!24, !7}
!25 = distinct !{!25, !7}
!26 = distinct !{!26, !7}
!27 = distinct !{!27, !7}
!28 = distinct !{!28, !7}
!29 = distinct !{!29, !7}
!30 = distinct !{!30, !7}
!31 = distinct !{!31, !7}
!32 = distinct !{!32, !7}
