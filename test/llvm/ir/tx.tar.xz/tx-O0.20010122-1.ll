; ModuleID = '20010122-1.c'
source_filename = "20010122-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@func1 = dso_local global [6 x ptr] [ptr @test1, ptr @test2, ptr @test3, ptr @test4, ptr @test5, ptr @test6], align 16
@save_ret1 = dso_local global [6 x ptr] zeroinitializer, align 16
@ret_addr = internal global ptr null, align 8
@func2 = dso_local global [6 x ptr] [ptr @test7, ptr @test8, ptr @test9, ptr @test10, ptr @test11, ptr @test12], align 16
@save_ret2 = dso_local global [6 x ptr] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test1() #0 {
  %1 = alloca ptr, align 8
  %2 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  ret ptr %3
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.returnaddress.p0(i32 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test2() #0 {
  %1 = alloca ptr, align 8
  %2 = call ptr @dummy()
  %3 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %3, ptr %1, align 8
  %4 = load ptr, ptr %1, align 8
  ret ptr %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @dummy() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  ret ptr %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test3() #0 {
  %1 = alloca ptr, align 8
  %2 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %2, ptr %1, align 8
  %3 = call ptr @dummy()
  %4 = load ptr, ptr %1, align 8
  ret ptr %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test4() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  %4 = call ptr @test4a(ptr noundef %3)
  ret ptr %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test4a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %4, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  ret ptr %5
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test5() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  %4 = call ptr @test5a(ptr noundef %3)
  ret ptr %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test5a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = call ptr @dummy()
  %5 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %5, ptr %3, align 8
  %6 = load ptr, ptr %3, align 8
  ret ptr %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test6() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  %4 = call ptr @test6a(ptr noundef %3)
  ret ptr %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @test6a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %4, ptr %3, align 8
  %5 = call ptr @dummy()
  %6 = load ptr, ptr %3, align 8
  ret ptr %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @call_func1(i32 noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = sext i32 %4 to i64
  %6 = getelementptr inbounds [6 x ptr], ptr @func1, i64 0, i64 %5
  %7 = load ptr, ptr %6, align 8
  %8 = call ptr %7()
  %9 = load i32, ptr %3, align 4
  %10 = sext i32 %9 to i64
  %11 = getelementptr inbounds [6 x ptr], ptr @save_ret1, i64 0, i64 %10
  store ptr %8, ptr %11, align 8
  %12 = load ptr, ptr %2, align 8
  ret ptr %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test7() #0 {
  %1 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %1, ptr @ret_addr, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test8() #0 {
  %1 = call ptr @dummy()
  %2 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %2, ptr @ret_addr, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test9() #0 {
  %1 = call ptr @llvm.returnaddress.p0(i32 0)
  store ptr %1, ptr @ret_addr, align 8
  %2 = call ptr @dummy()
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test10() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  call void @test10a(ptr noundef %3)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test10a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %3, ptr @ret_addr, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test11() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  call void @test11a(ptr noundef %3)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test11a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = call ptr @dummy()
  %4 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %4, ptr @ret_addr, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test12() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i8, i64 4, align 16
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  call void @test12a(ptr noundef %3)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test12a(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %3, ptr @ret_addr, align 8
  %4 = call ptr @dummy()
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @call_func2(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = sext i32 %3 to i64
  %5 = getelementptr inbounds [6 x ptr], ptr @func2, i64 0, i64 %4
  %6 = load ptr, ptr %5, align 8
  call void %6()
  %7 = load ptr, ptr @ret_addr, align 8
  %8 = load i32, ptr %2, align 4
  %9 = sext i32 %8 to i64
  %10 = getelementptr inbounds [6 x ptr], ptr @save_ret2, i64 0, i64 %9
  store ptr %7, ptr %10, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  br label %3

3:                                                ; preds = %9, %0
  %4 = load i32, ptr %2, align 4
  %5 = icmp slt i32 %4, 6
  br i1 %5, label %6, label %12

6:                                                ; preds = %3
  %7 = load i32, ptr %2, align 4
  %8 = call ptr @call_func1(i32 noundef %7)
  br label %9

9:                                                ; preds = %6
  %10 = load i32, ptr %2, align 4
  %11 = add nsw i32 %10, 1
  store i32 %11, ptr %2, align 4
  br label %3, !llvm.loop !6

12:                                               ; preds = %3
  %13 = load ptr, ptr @save_ret1, align 16
  %14 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 8), align 8
  %15 = icmp ne ptr %13, %14
  br i1 %15, label %20, label %16

16:                                               ; preds = %12
  %17 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 8), align 8
  %18 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 16), align 16
  %19 = icmp ne ptr %17, %18
  br i1 %19, label %20, label %21

20:                                               ; preds = %16, %12
  call void @abort() #4
  unreachable

21:                                               ; preds = %16
  %22 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 24), align 8
  %23 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 32), align 16
  %24 = icmp ne ptr %22, %23
  br i1 %24, label %29, label %25

25:                                               ; preds = %21
  %26 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 32), align 16
  %27 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 40), align 8
  %28 = icmp ne ptr %26, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %25, %21
  call void @abort() #4
  unreachable

30:                                               ; preds = %25
  %31 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 24), align 8
  %32 = icmp ne ptr %31, null
  br i1 %32, label %33, label %38

33:                                               ; preds = %30
  %34 = load ptr, ptr @save_ret1, align 16
  %35 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret1, i64 24), align 8
  %36 = icmp ne ptr %34, %35
  br i1 %36, label %37, label %38

37:                                               ; preds = %33
  call void @abort() #4
  unreachable

38:                                               ; preds = %33, %30
  store i32 0, ptr %2, align 4
  br label %39

39:                                               ; preds = %44, %38
  %40 = load i32, ptr %2, align 4
  %41 = icmp slt i32 %40, 6
  br i1 %41, label %42, label %47

42:                                               ; preds = %39
  %43 = load i32, ptr %2, align 4
  call void @call_func2(i32 noundef %43)
  br label %44

44:                                               ; preds = %42
  %45 = load i32, ptr %2, align 4
  %46 = add nsw i32 %45, 1
  store i32 %46, ptr %2, align 4
  br label %39, !llvm.loop !8

47:                                               ; preds = %39
  %48 = load ptr, ptr @save_ret2, align 16
  %49 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 8), align 8
  %50 = icmp ne ptr %48, %49
  br i1 %50, label %55, label %51

51:                                               ; preds = %47
  %52 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 8), align 8
  %53 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 16), align 16
  %54 = icmp ne ptr %52, %53
  br i1 %54, label %55, label %56

55:                                               ; preds = %51, %47
  call void @abort() #4
  unreachable

56:                                               ; preds = %51
  %57 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 24), align 8
  %58 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 32), align 16
  %59 = icmp ne ptr %57, %58
  br i1 %59, label %64, label %60

60:                                               ; preds = %56
  %61 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 32), align 16
  %62 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 40), align 8
  %63 = icmp ne ptr %61, %62
  br i1 %63, label %64, label %65

64:                                               ; preds = %60, %56
  call void @abort() #4
  unreachable

65:                                               ; preds = %60
  %66 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 24), align 8
  %67 = icmp ne ptr %66, null
  br i1 %67, label %68, label %73

68:                                               ; preds = %65
  %69 = load ptr, ptr @save_ret2, align 16
  %70 = load ptr, ptr getelementptr inbounds nuw (i8, ptr @save_ret2, i64 24), align 8
  %71 = icmp ne ptr %69, %70
  br i1 %71, label %72, label %73

72:                                               ; preds = %68
  call void @abort() #4
  unreachable

73:                                               ; preds = %68, %65
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
