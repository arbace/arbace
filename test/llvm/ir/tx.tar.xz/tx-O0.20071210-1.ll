; ModuleID = '20071210-1.c'
source_filename = "20071210-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i32, i32, i32, i32 }

@__const.foo.s = private unnamed_addr constant %struct.S { i32 1, i32 2, i32 3, i32 4 }, align 4
@bar.l = internal global [5 x ptr] [ptr blockaddress(@bar, %74), ptr blockaddress(@bar, %74), ptr blockaddress(@bar, %24), ptr blockaddress(@bar, %65), ptr blockaddress(@bar, %76)], align 16
@__const.main.s = private unnamed_addr constant [6 x i32] [i32 7, i32 8, i32 9, i32 10, i32 11, i32 12], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @foo(i32 noundef %0, i32 noundef %1, i32 noundef %2) #0 {
  %4 = alloca %struct.S, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  store i32 %0, ptr %5, align 4
  store i32 %1, ptr %6, align 4
  store i32 %2, ptr %7, align 4
  %8 = load i32, ptr %5, align 4
  %9 = icmp ne i32 %8, 10
  br i1 %9, label %16, label %10

10:                                               ; preds = %3
  %11 = load i32, ptr %6, align 4
  %12 = icmp ne i32 %11, 9
  br i1 %12, label %16, label %13

13:                                               ; preds = %10
  %14 = load i32, ptr %7, align 4
  %15 = icmp ne i32 %14, 8
  br i1 %15, label %16, label %17

16:                                               ; preds = %13, %10, %3
  call void @abort() #3
  unreachable

17:                                               ; preds = %13
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 4 @__const.foo.s, i64 16, i1 false)
  %18 = load { i64, i64 }, ptr %4, align 4
  ret { i64, i64 } %18
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @bar(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca %struct.S, align 4
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  %14 = load ptr, ptr %4, align 8
  store ptr %14, ptr %6, align 8
  %15 = load ptr, ptr %5, align 8
  store ptr %15, ptr %7, align 8
  %16 = load ptr, ptr %4, align 8
  %17 = icmp ne ptr %16, null
  br i1 %17, label %19, label %18

18:                                               ; preds = %2
  store ptr @bar.l, ptr %3, align 8
  br label %77

19:                                               ; preds = %2
  %20 = load ptr, ptr %6, align 8
  %21 = getelementptr inbounds nuw ptr, ptr %20, i32 1
  store ptr %21, ptr %6, align 8
  %22 = load ptr, ptr %20, align 8
  store ptr %22, ptr %12, align 8
  %23 = load ptr, ptr %12, align 8
  br label %79

24:                                               ; preds = %79
  %25 = load ptr, ptr %12, align 8
  store ptr %25, ptr %11, align 8
  %26 = load ptr, ptr %6, align 8
  %27 = getelementptr inbounds nuw ptr, ptr %26, i32 1
  store ptr %27, ptr %6, align 8
  %28 = load ptr, ptr %26, align 8
  store ptr %28, ptr %12, align 8
  %29 = load ptr, ptr %7, align 8
  %30 = getelementptr inbounds i32, ptr %29, i64 2
  %31 = load i32, ptr %30, align 4
  store i32 %31, ptr %8, align 4
  %32 = load ptr, ptr %7, align 8
  %33 = getelementptr inbounds i32, ptr %32, i64 1
  %34 = load i32, ptr %33, align 4
  store i32 %34, ptr %9, align 4
  %35 = load ptr, ptr %7, align 8
  %36 = getelementptr inbounds i32, ptr %35, i64 0
  %37 = load i32, ptr %36, align 4
  store i32 %37, ptr %10, align 4
  %38 = load ptr, ptr %7, align 8
  %39 = getelementptr inbounds i32, ptr %38, i64 -1
  store ptr %39, ptr %7, align 8
  %40 = load i32, ptr %8, align 4
  %41 = load i32, ptr %9, align 4
  %42 = load i32, ptr %10, align 4
  %43 = call { i64, i64 } @foo(i32 noundef %40, i32 noundef %41, i32 noundef %42)
  %44 = getelementptr inbounds nuw { i64, i64 }, ptr %13, i32 0, i32 0
  %45 = extractvalue { i64, i64 } %43, 0
  store i64 %45, ptr %44, align 4
  %46 = getelementptr inbounds nuw { i64, i64 }, ptr %13, i32 0, i32 1
  %47 = extractvalue { i64, i64 } %43, 1
  store i64 %47, ptr %46, align 4
  %48 = getelementptr inbounds nuw %struct.S, ptr %13, i32 0, i32 0
  %49 = load i32, ptr %48, align 4
  %50 = load ptr, ptr %7, align 8
  %51 = getelementptr inbounds i32, ptr %50, i64 3
  store i32 %49, ptr %51, align 4
  %52 = getelementptr inbounds nuw %struct.S, ptr %13, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = load ptr, ptr %7, align 8
  %55 = getelementptr inbounds i32, ptr %54, i64 2
  store i32 %53, ptr %55, align 4
  %56 = getelementptr inbounds nuw %struct.S, ptr %13, i32 0, i32 2
  %57 = load i32, ptr %56, align 4
  %58 = load ptr, ptr %7, align 8
  %59 = getelementptr inbounds i32, ptr %58, i64 1
  store i32 %57, ptr %59, align 4
  %60 = getelementptr inbounds nuw %struct.S, ptr %13, i32 0, i32 3
  %61 = load i32, ptr %60, align 4
  %62 = load ptr, ptr %7, align 8
  %63 = getelementptr inbounds i32, ptr %62, i64 0
  store i32 %61, ptr %63, align 4
  %64 = load ptr, ptr %12, align 8
  br label %79

65:                                               ; preds = %79
  %66 = load ptr, ptr %12, align 8
  store ptr %66, ptr %11, align 8
  %67 = load ptr, ptr %6, align 8
  %68 = getelementptr inbounds nuw ptr, ptr %67, i32 1
  store ptr %68, ptr %6, align 8
  %69 = load ptr, ptr %67, align 8
  store ptr %69, ptr %12, align 8
  %70 = load ptr, ptr %7, align 8
  %71 = getelementptr inbounds i32, ptr %70, i64 1
  store ptr %71, ptr %7, align 8
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds i32, ptr %72, i64 0
  store i32 23, ptr %73, align 4
  br label %74

74:                                               ; preds = %65, %79, %79
  %75 = load ptr, ptr %12, align 8
  br label %79

76:                                               ; preds = %79
  store ptr null, ptr %3, align 8
  br label %77

77:                                               ; preds = %76, %18
  %78 = load ptr, ptr %3, align 8
  ret ptr %78

79:                                               ; preds = %74, %24, %19
  %80 = phi ptr [ %23, %19 ], [ %64, %24 ], [ %75, %74 ]
  indirectbr ptr %80, [label %74, label %74, label %24, label %65, label %76]
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca [2 x ptr], align 16
  %4 = alloca [6 x i32], align 16
  store i32 0, ptr %1, align 4
  %5 = call ptr @bar(ptr noundef null, ptr noundef null)
  store ptr %5, ptr %2, align 8
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 2
  %8 = load ptr, ptr %7, align 8
  store ptr %8, ptr %3, align 8
  %9 = getelementptr inbounds ptr, ptr %3, i64 1
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds ptr, ptr %10, i64 4
  %12 = load ptr, ptr %11, align 8
  store ptr %12, ptr %9, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %4, ptr align 16 @__const.main.s, i64 24, i1 false)
  %13 = getelementptr inbounds [2 x ptr], ptr %3, i64 0, i64 0
  %14 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 1
  %15 = call ptr @bar(ptr noundef %13, ptr noundef %14)
  %16 = icmp ne ptr %15, null
  br i1 %16, label %41, label %17

17:                                               ; preds = %0
  %18 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 0
  %19 = load i32, ptr %18, align 16
  %20 = icmp ne i32 %19, 4
  br i1 %20, label %41, label %21

21:                                               ; preds = %17
  %22 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 1
  %23 = load i32, ptr %22, align 4
  %24 = icmp ne i32 %23, 3
  br i1 %24, label %41, label %25

25:                                               ; preds = %21
  %26 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 2
  %27 = load i32, ptr %26, align 8
  %28 = icmp ne i32 %27, 2
  br i1 %28, label %41, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 3
  %31 = load i32, ptr %30, align 4
  %32 = icmp ne i32 %31, 1
  br i1 %32, label %41, label %33

33:                                               ; preds = %29
  %34 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 4
  %35 = load i32, ptr %34, align 16
  %36 = icmp ne i32 %35, 11
  br i1 %36, label %41, label %37

37:                                               ; preds = %33
  %38 = getelementptr inbounds [6 x i32], ptr %4, i64 0, i64 5
  %39 = load i32, ptr %38, align 4
  %40 = icmp ne i32 %39, 12
  br i1 %40, label %41, label %42

41:                                               ; preds = %37, %33, %29, %25, %21, %17, %0
  call void @abort() #3
  unreachable

42:                                               ; preds = %37
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
