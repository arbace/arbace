; ModuleID = '20050316-3.c'
source_filename = "20050316-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { <2 x i32> }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @test1(double noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  %4 = alloca <2 x i32>, align 8
  store double %0, ptr %3, align 8
  %5 = load <2 x i32>, ptr %3, align 8
  store <2 x i32> %5, ptr %4, align 8
  %6 = load <2 x i32>, ptr %4, align 8
  %7 = bitcast <2 x i32> %6 to i64
  %8 = bitcast i64 %7 to <2 x i32>
  store <2 x i32> %8, ptr %2, align 8
  %9 = load double, ptr %2, align 8
  ret double %9
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @test2(double noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  store double %0, ptr %2, align 8
  %4 = load <2 x i32>, ptr %2, align 8
  store <2 x i32> %4, ptr %3, align 8
  %5 = load <2 x i32>, ptr %3, align 8
  %6 = bitcast <2 x i32> %5 to i64
  %7 = bitcast i64 %6 to <2 x i32>
  %8 = bitcast <2 x i32> %7 to i64
  ret i64 %8
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %union.anon, align 8
  %3 = alloca <2 x i32>, align 8
  %4 = alloca <2 x i32>, align 8
  %5 = alloca <2 x i32>, align 8
  %6 = alloca <2 x i32>, align 8
  store i32 0, ptr %1, align 4
  store <2 x i32> splat (i32 -3), ptr %3, align 8
  %7 = load <2 x i32>, ptr %3, align 8
  store <2 x i32> %7, ptr %4, align 8
  %8 = load double, ptr %4, align 8
  %9 = call double @test1(double noundef %8)
  store double %9, ptr %5, align 8
  %10 = load <2 x i32>, ptr %5, align 8
  store <2 x i32> %10, ptr %2, align 8
  %11 = getelementptr inbounds [2 x i32], ptr %2, i64 0, i64 0
  %12 = load i32, ptr %11, align 8
  %13 = icmp ne i32 %12, -3
  br i1 %13, label %18, label %14

14:                                               ; preds = %0
  %15 = getelementptr inbounds [2 x i32], ptr %2, i64 0, i64 1
  %16 = load i32, ptr %15, align 4
  %17 = icmp ne i32 %16, -3
  br i1 %17, label %18, label %19

18:                                               ; preds = %14, %0
  call void @abort() #2
  unreachable

19:                                               ; preds = %14
  %20 = load <2 x i32>, ptr %3, align 8
  store <2 x i32> %20, ptr %6, align 8
  %21 = load double, ptr %6, align 8
  %22 = call i64 @test2(double noundef %21)
  store i64 %22, ptr %2, align 8
  %23 = getelementptr inbounds [2 x i32], ptr %2, i64 0, i64 0
  %24 = load i32, ptr %23, align 8
  %25 = icmp ne i32 %24, -3
  br i1 %25, label %30, label %26

26:                                               ; preds = %19
  %27 = getelementptr inbounds [2 x i32], ptr %2, i64 0, i64 1
  %28 = load i32, ptr %27, align 4
  %29 = icmp ne i32 %28, -3
  br i1 %29, label %30, label %31

30:                                               ; preds = %26, %19
  call void @abort() #2
  unreachable

31:                                               ; preds = %26
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
