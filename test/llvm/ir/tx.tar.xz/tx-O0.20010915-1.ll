; ModuleID = '20010915-1.c'
source_filename = "20010915-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@check = dso_local global i32 0, align 4
@o = dso_local global i32 0, align 4
@.str = private unnamed_addr constant [2 x i8] c"a\00", align 1
@.str.1 = private unnamed_addr constant [2 x i8] c"b\00", align 1
@.str.2 = private unnamed_addr constant [2 x i8] c"c\00", align 1
@.str.3 = private unnamed_addr constant [2 x i8] c"d\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"e\00", align 1
@__const.main.args = private unnamed_addr constant [5 x ptr] [ptr @.str, ptr @.str.1, ptr @.str.2, ptr @.str.3, ptr @.str.4], align 16
@h = dso_local global ptr null, align 8
@u = dso_local global ptr null, align 8
@r.c = internal global [2 x i8] c"b\00", align 1
@r.cnt = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca [5 x ptr], align 16
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %6, ptr align 16 @__const.main.args, i64 40, i1 false)
  %7 = getelementptr inbounds [5 x ptr], ptr %6, i64 0, i64 0
  %8 = call i32 @x(i32 noundef 5, ptr noundef %7)
  %9 = icmp ne i32 %8, 0
  br i1 %9, label %16, label %10

10:                                               ; preds = %2
  %11 = load i32, ptr @check, align 4
  %12 = icmp ne i32 %11, 2
  br i1 %12, label %16, label %13

13:                                               ; preds = %10
  %14 = load i32, ptr @o, align 4
  %15 = icmp ne i32 %14, 5
  br i1 %15, label %16, label %17

16:                                               ; preds = %13, %10, %2
  call void @abort() #5
  unreachable

17:                                               ; preds = %13
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @x(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store i32 0, ptr %6, align 4
  store ptr null, ptr %7, align 8
  store ptr null, ptr %8, align 8
  %9 = load i32, ptr %4, align 4
  %10 = load i32, ptr @o, align 4
  %11 = icmp sgt i32 %9, %10
  br i1 %11, label %12, label %65

12:                                               ; preds = %2
  %13 = load i32, ptr %4, align 4
  %14 = icmp sgt i32 %13, 2
  br i1 %14, label %15, label %65

15:                                               ; preds = %12
  %16 = load ptr, ptr %5, align 8
  %17 = load i32, ptr @o, align 4
  %18 = sext i32 %17 to i64
  %19 = getelementptr inbounds ptr, ptr %16, i64 %18
  %20 = load ptr, ptr %19, align 8
  %21 = icmp ne ptr %20, null
  br i1 %21, label %22, label %65

22:                                               ; preds = %15
  %23 = load ptr, ptr %5, align 8
  %24 = load i32, ptr @o, align 4
  %25 = sext i32 %24 to i64
  %26 = getelementptr inbounds ptr, ptr %23, i64 %25
  %27 = load ptr, ptr %26, align 8
  %28 = call ptr @s(ptr noundef %27, ptr noundef %8)
  store ptr %28, ptr %7, align 8
  %29 = load ptr, ptr %7, align 8
  %30 = icmp ne ptr %29, null
  br i1 %30, label %31, label %43

31:                                               ; preds = %22
  %32 = load ptr, ptr %7, align 8
  %33 = getelementptr inbounds nuw i8, ptr %32, i32 1
  store ptr %33, ptr %7, align 8
  store i8 0, ptr %32, align 1
  %34 = load ptr, ptr %7, align 8
  %35 = call ptr @s(ptr noundef %34, ptr noundef %8)
  store ptr %35, ptr @h, align 8
  %36 = load ptr, ptr %7, align 8
  %37 = load ptr, ptr %8, align 8
  %38 = icmp eq ptr %36, %37
  br i1 %38, label %39, label %42

39:                                               ; preds = %31
  %40 = load ptr, ptr %7, align 8
  %41 = call ptr @m(ptr noundef %40)
  store ptr %41, ptr @h, align 8
  br label %42

42:                                               ; preds = %39, %31
  br label %43

43:                                               ; preds = %42, %22
  %44 = load ptr, ptr %5, align 8
  %45 = load i32, ptr @o, align 4
  %46 = sext i32 %45 to i64
  %47 = getelementptr inbounds ptr, ptr %44, i64 %46
  %48 = load ptr, ptr %47, align 8
  %49 = call ptr @s(ptr noundef %48, ptr noundef %8)
  store ptr %49, ptr @u, align 8
  %50 = load ptr, ptr %5, align 8
  %51 = load i32, ptr @o, align 4
  %52 = sext i32 %51 to i64
  %53 = getelementptr inbounds ptr, ptr %50, i64 %52
  %54 = load ptr, ptr %53, align 8
  %55 = load ptr, ptr %8, align 8
  %56 = icmp eq ptr %54, %55
  br i1 %56, label %57, label %64

57:                                               ; preds = %43
  %58 = load ptr, ptr %5, align 8
  %59 = load i32, ptr @o, align 4
  %60 = sext i32 %59 to i64
  %61 = getelementptr inbounds ptr, ptr %58, i64 %60
  %62 = load ptr, ptr %61, align 8
  %63 = call ptr @m(ptr noundef %62)
  store ptr %63, ptr @u, align 8
  br label %64

64:                                               ; preds = %57, %43
  br label %66

65:                                               ; preds = %15, %12, %2
  call void @abort() #5
  unreachable

66:                                               ; preds = %64
  br label %67

67:                                               ; preds = %81, %66
  %68 = load i32, ptr @o, align 4
  %69 = add nsw i32 %68, 1
  store i32 %69, ptr @o, align 4
  %70 = load i32, ptr %4, align 4
  %71 = icmp slt i32 %69, %70
  br i1 %71, label %72, label %82

72:                                               ; preds = %67
  %73 = load ptr, ptr %5, align 8
  %74 = load i32, ptr @o, align 4
  %75 = sext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %73, i64 %75
  %77 = load ptr, ptr %76, align 8
  %78 = call i32 @r(ptr noundef %77)
  %79 = icmp eq i32 %78, 0
  br i1 %79, label %80, label %81

80:                                               ; preds = %72
  store i32 1, ptr %3, align 4
  br label %83

81:                                               ; preds = %72
  br label %67, !llvm.loop !6

82:                                               ; preds = %67
  store i32 0, ptr %3, align 4
  br label %83

83:                                               ; preds = %82, %80
  %84 = load i32, ptr %3, align 4
  ret i32 %84
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @s(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = call i32 @strcmp(ptr noundef %5, ptr noundef @.str) #7
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %12, label %8

8:                                                ; preds = %2
  %9 = load i32, ptr @check, align 4
  %10 = add nsw i32 %9, 1
  store i32 %10, ptr @check, align 4
  %11 = icmp sgt i32 %9, 1
  br i1 %11, label %12, label %13

12:                                               ; preds = %8, %2
  call void @abort() #5
  unreachable

13:                                               ; preds = %8
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds i8, ptr %14, i64 1
  %16 = load ptr, ptr %4, align 8
  store ptr %15, ptr %16, align 8
  ret ptr null
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @m(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void @abort() #5
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @r(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = load i8, ptr %3, align 1
  %5 = sext i8 %4 to i32
  %6 = load i8, ptr @r.c, align 1
  %7 = sext i8 %6 to i32
  %8 = icmp ne i32 %5, %7
  br i1 %8, label %20, label %9

9:                                                ; preds = %1
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds i8, ptr %10, i64 1
  %12 = load i8, ptr %11, align 1
  %13 = sext i8 %12 to i32
  %14 = load i8, ptr getelementptr inbounds nuw (i8, ptr @r.c, i64 1), align 1
  %15 = sext i8 %14 to i32
  %16 = icmp ne i32 %13, %15
  br i1 %16, label %20, label %17

17:                                               ; preds = %9
  %18 = load i32, ptr @r.cnt, align 4
  %19 = icmp sgt i32 %18, 3
  br i1 %19, label %20, label %21

20:                                               ; preds = %17, %9, %1
  call void @abort() #5
  unreachable

21:                                               ; preds = %17
  %22 = load i8, ptr @r.c, align 1
  %23 = add i8 %22, 1
  store i8 %23, ptr @r.c, align 1
  %24 = load i32, ptr @r.cnt, align 4
  %25 = add nsw i32 %24, 1
  store i32 %25, ptr @r.cnt, align 4
  ret i32 1
}

; Function Attrs: nounwind
declare i32 @strcmp(ptr noundef, ptr noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }
attributes #7 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
