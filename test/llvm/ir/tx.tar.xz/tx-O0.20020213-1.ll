; ModuleID = '20020213-1.c'
source_filename = "20020213-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { float, i32 }

@a = dso_local global %struct.A zeroinitializer, align 4
@b = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo() #0 {
  %1 = load float, ptr @a, align 4
  %2 = call i32 @bar(float noundef %1)
  store i32 %2, ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), align 4
  %3 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), align 4
  %4 = load i32, ptr @b, align 4
  %5 = sub nsw i32 %4, 1
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %7, label %9

7:                                                ; preds = %0
  %8 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), align 4
  br label %12

9:                                                ; preds = %0
  %10 = load i32, ptr @b, align 4
  %11 = sub nsw i32 %10, 1
  br label %12

12:                                               ; preds = %9, %7
  %13 = phi i32 [ %8, %7 ], [ %11, %9 ]
  store i32 %13, ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), align 4
  %14 = load i32, ptr getelementptr inbounds nuw (i8, ptr @a, i64 4), align 4
  %15 = load i32, ptr @b, align 4
  %16 = sub nsw i32 %15, 1
  %17 = icmp sge i32 %14, %16
  br i1 %17, label %18, label %19

18:                                               ; preds = %12
  call void @abort() #2
  unreachable

19:                                               ; preds = %12
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @bar(float noundef %0) #0 {
  %2 = alloca float, align 4
  store float %0, ptr %2, align 4
  ret i32 2241
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store float 1.000000e+00, ptr @a, align 4
  store i32 3384, ptr @b, align 4
  call void @foo()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
