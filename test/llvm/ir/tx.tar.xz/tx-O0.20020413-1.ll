; ModuleID = '20020413-1.c'
source_filename = "20020413-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test(x86_fp80 noundef %0, ptr noundef %1) #0 {
  %3 = alloca x86_fp80, align 16
  %4 = alloca ptr, align 8
  %5 = alloca x86_fp80, align 16
  %6 = alloca i32, align 4
  store x86_fp80 %0, ptr %3, align 16
  store ptr %1, ptr %4, align 8
  store x86_fp80 1.000000e+00, ptr %5, align 16
  store i32 0, ptr %6, align 4
  %7 = load x86_fp80, ptr %3, align 16
  %8 = fcmp olt x86_fp80 %7, 0.000000e+00
  br i1 %8, label %9, label %12

9:                                                ; preds = %2
  %10 = load x86_fp80, ptr %3, align 16
  %11 = fneg x86_fp80 %10
  store x86_fp80 %11, ptr %3, align 16
  br label %12

12:                                               ; preds = %9, %2
  %13 = load x86_fp80, ptr %3, align 16
  %14 = load x86_fp80, ptr %5, align 16
  %15 = fcmp oge x86_fp80 %13, %14
  br i1 %15, label %16, label %30

16:                                               ; preds = %12
  br label %17

17:                                               ; preds = %28, %16
  %18 = load x86_fp80, ptr %5, align 16
  %19 = load x86_fp80, ptr %3, align 16
  %20 = fcmp olt x86_fp80 %18, %19
  br i1 %20, label %21, label %29

21:                                               ; preds = %17
  %22 = load x86_fp80, ptr %5, align 16
  %23 = fmul x86_fp80 %22, 2.000000e+00
  store x86_fp80 %23, ptr %5, align 16
  %24 = load i32, ptr %6, align 4
  %25 = add nsw i32 %24, 1
  store i32 %25, ptr %6, align 4
  %26 = icmp sge i32 %24, 10
  br i1 %26, label %27, label %28

27:                                               ; preds = %21
  call void @abort() #3
  unreachable

28:                                               ; preds = %21
  br label %17, !llvm.loop !6

29:                                               ; preds = %17
  br label %48

30:                                               ; preds = %12
  %31 = load x86_fp80, ptr %3, align 16
  %32 = fcmp une x86_fp80 %31, 0.000000e+00
  br i1 %32, label %33, label %47

33:                                               ; preds = %30
  br label %34

34:                                               ; preds = %45, %33
  %35 = load x86_fp80, ptr %3, align 16
  %36 = load x86_fp80, ptr %5, align 16
  %37 = fcmp olt x86_fp80 %35, %36
  br i1 %37, label %38, label %46

38:                                               ; preds = %34
  %39 = load x86_fp80, ptr %5, align 16
  %40 = fdiv x86_fp80 %39, 2.000000e+00
  store x86_fp80 %40, ptr %5, align 16
  %41 = load i32, ptr %6, align 4
  %42 = add nsw i32 %41, 1
  store i32 %42, ptr %6, align 4
  %43 = icmp sge i32 %41, 10
  br i1 %43, label %44, label %45

44:                                               ; preds = %38
  call void @abort() #3
  unreachable

45:                                               ; preds = %38
  br label %34, !llvm.loop !8

46:                                               ; preds = %34
  br label %47

47:                                               ; preds = %46, %30
  br label %48

48:                                               ; preds = %47, %29
  %49 = load i32, ptr %6, align 4
  %50 = load ptr, ptr %4, align 8
  store i32 %49, ptr %50, align 4
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @test(x86_fp80 noundef 3.000000e+00, ptr noundef %2)
  call void @test(x86_fp80 noundef 3.500000e+00, ptr noundef %2)
  call void @test(x86_fp80 noundef 4.000000e+00, ptr noundef %2)
  call void @test(x86_fp80 noundef 5.000000e+00, ptr noundef %2)
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
