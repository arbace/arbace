; ModuleID = '20041113-1.c'
source_filename = "20041113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.__va_list_tag = type { i32, i32, ptr, ptr }

@a = dso_local global double 4.000000e+01, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test(i32 noundef %0, ...) #0 {
  %2 = alloca i32, align 4
  %3 = alloca [1 x %struct.__va_list_tag], align 16
  %4 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %3, i64 0, i64 0
  call void @llvm.va_start.p0(ptr %5)
  %6 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %3, i64 0, i64 0
  %7 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 0
  %8 = load i32, ptr %7, align 16
  %9 = icmp ule i32 %8, 40
  br i1 %9, label %10, label %15

10:                                               ; preds = %1
  %11 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 3
  %12 = load ptr, ptr %11, align 16
  %13 = getelementptr i8, ptr %12, i32 %8
  %14 = add i32 %8, 8
  store i32 %14, ptr %7, align 16
  br label %19

15:                                               ; preds = %1
  %16 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 2
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr i8, ptr %17, i32 8
  store ptr %18, ptr %16, align 8
  br label %19

19:                                               ; preds = %15, %10
  %20 = phi ptr [ %13, %10 ], [ %17, %15 ]
  %21 = load i32, ptr %20, align 4
  %22 = icmp ne i32 %21, 1
  br i1 %22, label %23, label %24

23:                                               ; preds = %19
  call void @abort() #4
  unreachable

24:                                               ; preds = %19
  %25 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %3, i64 0, i64 0
  %26 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %25, i32 0, i32 0
  %27 = load i32, ptr %26, align 16
  %28 = icmp ule i32 %27, 40
  br i1 %28, label %29, label %34

29:                                               ; preds = %24
  %30 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %25, i32 0, i32 3
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %31, i32 %27
  %33 = add i32 %27, 8
  store i32 %33, ptr %26, align 16
  br label %38

34:                                               ; preds = %24
  %35 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %25, i32 0, i32 2
  %36 = load ptr, ptr %35, align 8
  %37 = getelementptr i8, ptr %36, i32 8
  store ptr %37, ptr %35, align 8
  br label %38

38:                                               ; preds = %34, %29
  %39 = phi ptr [ %32, %29 ], [ %36, %34 ]
  %40 = load i32, ptr %39, align 4
  %41 = icmp ne i32 %40, 2
  br i1 %41, label %42, label %43

42:                                               ; preds = %38
  call void @abort() #4
  unreachable

43:                                               ; preds = %38
  %44 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %3, i64 0, i64 0
  %45 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %44, i32 0, i32 0
  %46 = load i32, ptr %45, align 16
  %47 = icmp ule i32 %46, 40
  br i1 %47, label %48, label %53

48:                                               ; preds = %43
  %49 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %44, i32 0, i32 3
  %50 = load ptr, ptr %49, align 16
  %51 = getelementptr i8, ptr %50, i32 %46
  %52 = add i32 %46, 8
  store i32 %52, ptr %45, align 16
  br label %57

53:                                               ; preds = %43
  %54 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %44, i32 0, i32 2
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i8, ptr %55, i32 8
  store ptr %56, ptr %54, align 8
  br label %57

57:                                               ; preds = %53, %48
  %58 = phi ptr [ %51, %48 ], [ %55, %53 ]
  %59 = load i32, ptr %58, align 4
  %60 = icmp ne i32 %59, 3
  br i1 %60, label %61, label %62

61:                                               ; preds = %57
  call void @abort() #4
  unreachable

62:                                               ; preds = %57
  %63 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %3, i64 0, i64 0
  %64 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %63, i32 0, i32 0
  %65 = load i32, ptr %64, align 16
  %66 = icmp ule i32 %65, 40
  br i1 %66, label %67, label %72

67:                                               ; preds = %62
  %68 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %63, i32 0, i32 3
  %69 = load ptr, ptr %68, align 16
  %70 = getelementptr i8, ptr %69, i32 %65
  %71 = add i32 %65, 8
  store i32 %71, ptr %64, align 16
  br label %76

72:                                               ; preds = %62
  %73 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %63, i32 0, i32 2
  %74 = load ptr, ptr %73, align 8
  %75 = getelementptr i8, ptr %74, i32 8
  store ptr %75, ptr %73, align 8
  br label %76

76:                                               ; preds = %72, %67
  %77 = phi ptr [ %70, %67 ], [ %74, %72 ]
  %78 = load i32, ptr %77, align 4
  %79 = icmp ne i32 %78, 4
  br i1 %79, label %80, label %81

80:                                               ; preds = %76
  call void @abort() #4
  unreachable

81:                                               ; preds = %76
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  %6 = load double, ptr @a, align 8
  %7 = fdiv double %6, 1.000000e+01
  %8 = fptosi double %7 to i32
  call void (i32, ...) @test(i32 noundef 0, i32 noundef 1, i32 noundef 2, i32 noundef 3, i32 noundef %8)
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
