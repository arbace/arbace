; ModuleID = '20071219-1.c'
source_filename = "20071219-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { [25 x i8] }

@p = dso_local global ptr null, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i32 0, ptr %5, align 4
  br label %6

6:                                                ; preds = %33, %2
  %7 = load i32, ptr %5, align 4
  %8 = sext i32 %7 to i64
  %9 = icmp ult i64 %8, 25
  br i1 %9, label %10, label %36

10:                                               ; preds = %6
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds nuw %struct.S, ptr %11, i32 0, i32 0
  %13 = load i32, ptr %5, align 4
  %14 = sext i32 %13 to i64
  %15 = getelementptr inbounds [25 x i8], ptr %12, i64 0, i64 %14
  %16 = load i8, ptr %15, align 1
  %17 = sext i8 %16 to i32
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %10
  call void @abort() #4
  unreachable

20:                                               ; preds = %10
  %21 = load i32, ptr %4, align 4
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %23, label %31

23:                                               ; preds = %20
  %24 = load i32, ptr %4, align 4
  %25 = trunc i32 %24 to i8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.S, ptr %26, i32 0, i32 0
  %28 = load i32, ptr %5, align 4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds [25 x i8], ptr %27, i64 0, i64 %29
  store i8 %25, ptr %30, align 1
  br label %31

31:                                               ; preds = %23, %20
  br label %32

32:                                               ; preds = %31
  br label %33

33:                                               ; preds = %32
  %34 = load i32, ptr %5, align 4
  %35 = add nsw i32 %34, 1
  store i32 %35, ptr %5, align 4
  br label %6, !llvm.loop !6

36:                                               ; preds = %6
  %37 = load ptr, ptr %3, align 8
  store ptr %37, ptr @p, align 8
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test1() #0 {
  %1 = alloca %struct.S, align 1
  %2 = alloca %struct.S, align 1
  %3 = getelementptr inbounds nuw %struct.S, ptr %1, i32 0, i32 0
  call void @llvm.memset.p0.i64(ptr align 1 %3, i8 0, i64 25, i1 false)
  call void @foo(ptr noundef %1, i32 noundef 0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %1, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 1)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %1, i64 25, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %2, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 0)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test2() #0 {
  %1 = alloca %struct.S, align 1
  %2 = alloca %struct.S, align 1
  %3 = getelementptr inbounds nuw %struct.S, ptr %1, i32 0, i32 0
  call void @llvm.memset.p0.i64(ptr align 1 %3, i8 0, i64 25, i1 false)
  call void @foo(ptr noundef %1, i32 noundef 0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %1, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 1)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %1, i64 25, i1 false)
  %4 = load ptr, ptr @p, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %4, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 0)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test3() #0 {
  %1 = alloca %struct.S, align 1
  %2 = alloca %struct.S, align 1
  %3 = getelementptr inbounds nuw %struct.S, ptr %1, i32 0, i32 0
  call void @llvm.memset.p0.i64(ptr align 1 %3, i8 0, i64 25, i1 false)
  call void @foo(ptr noundef %1, i32 noundef 0)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %1, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 1)
  %4 = load ptr, ptr @p, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %4, ptr align 1 %1, i64 25, i1 false)
  %5 = load ptr, ptr @p, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 1 %2, i64 25, i1 false)
  call void @foo(ptr noundef %2, i32 noundef 0)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @test1()
  call void @test2()
  call void @test3()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
