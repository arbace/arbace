; ModuleID = '20010518-2.c'
source_filename = "20010518-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.a_struct = type <{ i16, i64, i16, i16, %struct.b_struct }>
%struct.b_struct = type { i8, i8, i8, i8, i8, i8 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca %struct.a_struct, align 1
  %4 = alloca %struct.a_struct, align 1
  store i32 0, ptr %1, align 4
  store ptr %3, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.a_struct, ptr %4, i32 0, i32 0
  store i16 1, ptr %6, align 1
  %7 = getelementptr inbounds nuw %struct.a_struct, ptr %4, i32 0, i32 1
  store i64 2, ptr %7, align 1
  %8 = getelementptr inbounds nuw %struct.a_struct, ptr %4, i32 0, i32 2
  store i16 3, ptr %8, align 1
  %9 = getelementptr inbounds nuw %struct.a_struct, ptr %4, i32 0, i32 3
  store i16 4, ptr %9, align 1
  %10 = getelementptr inbounds nuw %struct.a_struct, ptr %4, i32 0, i32 4
  call void @llvm.memset.p0.i64(ptr align 1 %10, i8 0, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 1 %4, i64 20, i1 true)
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.a_struct, ptr %11, i32 0, i32 4
  %13 = getelementptr inbounds nuw %struct.b_struct, ptr %12, i32 0, i32 4
  store volatile i8 99, ptr %13, align 1
  %14 = load ptr, ptr %2, align 8
  %15 = getelementptr inbounds nuw %struct.a_struct, ptr %14, i32 0, i32 0
  %16 = load volatile i16, ptr %15, align 1
  %17 = sext i16 %16 to i32
  %18 = icmp ne i32 %17, 1
  br i1 %18, label %43, label %19

19:                                               ; preds = %0
  %20 = load ptr, ptr %2, align 8
  %21 = getelementptr inbounds nuw %struct.a_struct, ptr %20, i32 0, i32 1
  %22 = load volatile i64, ptr %21, align 1
  %23 = icmp ne i64 %22, 2
  br i1 %23, label %43, label %24

24:                                               ; preds = %19
  %25 = load ptr, ptr %2, align 8
  %26 = getelementptr inbounds nuw %struct.a_struct, ptr %25, i32 0, i32 2
  %27 = load volatile i16, ptr %26, align 1
  %28 = sext i16 %27 to i32
  %29 = icmp ne i32 %28, 3
  br i1 %29, label %43, label %30

30:                                               ; preds = %24
  %31 = load ptr, ptr %2, align 8
  %32 = getelementptr inbounds nuw %struct.a_struct, ptr %31, i32 0, i32 3
  %33 = load volatile i16, ptr %32, align 1
  %34 = sext i16 %33 to i32
  %35 = icmp ne i32 %34, 4
  br i1 %35, label %43, label %36

36:                                               ; preds = %30
  %37 = load ptr, ptr %2, align 8
  %38 = getelementptr inbounds nuw %struct.a_struct, ptr %37, i32 0, i32 4
  %39 = getelementptr inbounds nuw %struct.b_struct, ptr %38, i32 0, i32 4
  %40 = load volatile i8, ptr %39, align 1
  %41 = sext i8 %40 to i32
  %42 = icmp ne i32 %41, 99
  br i1 %42, label %43, label %44

43:                                               ; preds = %36, %30, %24, %19, %0
  call void @abort() #5
  unreachable

44:                                               ; preds = %36
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: noreturn
declare void @exit(i32 noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
