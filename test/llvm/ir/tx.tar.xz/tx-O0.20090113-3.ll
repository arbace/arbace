; ModuleID = '20090113-3.c'
source_filename = "20090113-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.bitmap_element_def = type { ptr, ptr, i32, [2 x i64] }
%struct.bitmap_head_def = type { ptr, ptr, i32, ptr }
%struct.bitmap_iterator = type { ptr, ptr, i32, i64 }

@bitmap_zero_bits = dso_local global %struct.bitmap_element_def zeroinitializer, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.bitmap_element_def, align 8
  %3 = alloca %struct.bitmap_head_def, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 40, i1 false)
  %4 = getelementptr inbounds { ptr, ptr, i32, [4 x i8], [2 x i64] }, ptr %2, i32 0, i32 4
  %5 = getelementptr inbounds [2 x i64], ptr %4, i32 0, i32 0
  store i64 1, ptr %5, align 8
  %6 = getelementptr inbounds [2 x i64], ptr %4, i32 0, i32 1
  store i64 1, ptr %6, align 8
  %7 = getelementptr inbounds nuw %struct.bitmap_head_def, ptr %3, i32 0, i32 0
  store ptr %2, ptr %7, align 8
  %8 = getelementptr inbounds nuw %struct.bitmap_head_def, ptr %3, i32 0, i32 1
  store ptr %2, ptr %8, align 8
  %9 = getelementptr inbounds nuw %struct.bitmap_head_def, ptr %3, i32 0, i32 2
  store i32 0, ptr %9, align 8
  %10 = getelementptr i8, ptr %3, i64 20
  call void @llvm.memset.p0.i64(ptr align 4 %10, i8 0, i64 4, i1 false)
  %11 = getelementptr inbounds nuw %struct.bitmap_head_def, ptr %3, i32 0, i32 3
  store ptr null, ptr %11, align 8
  call void @foobar(ptr noundef %3)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @foobar(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.bitmap_iterator, align 8
  %9 = alloca i32, align 4
  store ptr %0, ptr %7, align 8
  %10 = load ptr, ptr %7, align 8
  call void @bmp_iter_set_init(ptr noundef %8, ptr noundef %10, i32 noundef 0, ptr noundef %9)
  br label %11

11:                                               ; preds = %114, %1
  store ptr %8, ptr %5, align 8
  store ptr %9, ptr %6, align 8
  %12 = load ptr, ptr %5, align 8
  %13 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %12, i32 0, i32 3
  %14 = load i64, ptr %13, align 8
  %15 = icmp ne i64 %14, 0
  br i1 %15, label %16, label %33

16:                                               ; preds = %11
  br label %17

17:                                               ; preds = %24, %16
  %18 = load ptr, ptr %5, align 8
  %19 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %18, i32 0, i32 3
  %20 = load i64, ptr %19, align 8
  %21 = and i64 %20, 1
  %22 = icmp ne i64 %21, 0
  %23 = xor i1 %22, true
  br i1 %23, label %24, label %32

24:                                               ; preds = %17
  %25 = load ptr, ptr %5, align 8
  %26 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %25, i32 0, i32 3
  %27 = load i64, ptr %26, align 8
  %28 = lshr i64 %27, 1
  store i64 %28, ptr %26, align 8
  %29 = load ptr, ptr %6, align 8
  %30 = load i32, ptr %29, align 4
  %31 = add i32 %30, 1
  store i32 %31, ptr %29, align 4
  br label %17, !llvm.loop !6

32:                                               ; preds = %17
  store i8 1, ptr %4, align 1
  br label %110

33:                                               ; preds = %11
  %34 = load ptr, ptr %6, align 8
  %35 = load i32, ptr %34, align 4
  %36 = add i32 %35, 64
  %37 = sub i32 %36, 1
  %38 = udiv i32 %37, 64
  %39 = mul i32 %38, 64
  %40 = load ptr, ptr %6, align 8
  store i32 %39, ptr %40, align 4
  %41 = load ptr, ptr %5, align 8
  %42 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %41, i32 0, i32 2
  %43 = load i32, ptr %42, align 8
  %44 = add i32 %43, 1
  store i32 %44, ptr %42, align 8
  br label %45

45:                                               ; preds = %101, %33
  br label %46

46:                                               ; preds = %84, %45
  %47 = load ptr, ptr %5, align 8
  %48 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %47, i32 0, i32 2
  %49 = load i32, ptr %48, align 8
  %50 = icmp ne i32 %49, 2
  br i1 %50, label %51, label %92

51:                                               ; preds = %46
  %52 = load ptr, ptr %5, align 8
  %53 = load ptr, ptr %52, align 8
  %54 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %53, i32 0, i32 3
  %55 = load ptr, ptr %5, align 8
  %56 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %55, i32 0, i32 2
  %57 = load i32, ptr %56, align 8
  %58 = zext i32 %57 to i64
  %59 = getelementptr inbounds nuw [2 x i64], ptr %54, i64 0, i64 %58
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %5, align 8
  %62 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %61, i32 0, i32 3
  store i64 %60, ptr %62, align 8
  %63 = load ptr, ptr %5, align 8
  %64 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %63, i32 0, i32 3
  %65 = load i64, ptr %64, align 8
  %66 = icmp ne i64 %65, 0
  br i1 %66, label %67, label %84

67:                                               ; preds = %51
  br label %68

68:                                               ; preds = %75, %67
  %69 = load ptr, ptr %5, align 8
  %70 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %69, i32 0, i32 3
  %71 = load i64, ptr %70, align 8
  %72 = and i64 %71, 1
  %73 = icmp ne i64 %72, 0
  %74 = xor i1 %73, true
  br i1 %74, label %75, label %83

75:                                               ; preds = %68
  %76 = load ptr, ptr %5, align 8
  %77 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %76, i32 0, i32 3
  %78 = load i64, ptr %77, align 8
  %79 = lshr i64 %78, 1
  store i64 %79, ptr %77, align 8
  %80 = load ptr, ptr %6, align 8
  %81 = load i32, ptr %80, align 4
  %82 = add i32 %81, 1
  store i32 %82, ptr %80, align 4
  br label %68, !llvm.loop !8

83:                                               ; preds = %68
  store i8 1, ptr %4, align 1
  br label %110

84:                                               ; preds = %51
  %85 = load ptr, ptr %6, align 8
  %86 = load i32, ptr %85, align 4
  %87 = add i32 %86, 64
  store i32 %87, ptr %85, align 4
  %88 = load ptr, ptr %5, align 8
  %89 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %88, i32 0, i32 2
  %90 = load i32, ptr %89, align 8
  %91 = add i32 %90, 1
  store i32 %91, ptr %89, align 8
  br label %46, !llvm.loop !9

92:                                               ; preds = %46
  %93 = load ptr, ptr %5, align 8
  %94 = load ptr, ptr %93, align 8
  %95 = load ptr, ptr %94, align 8
  %96 = load ptr, ptr %5, align 8
  store ptr %95, ptr %96, align 8
  %97 = load ptr, ptr %5, align 8
  %98 = load ptr, ptr %97, align 8
  %99 = icmp ne ptr %98, null
  br i1 %99, label %101, label %100

100:                                              ; preds = %92
  store i8 0, ptr %4, align 1
  br label %110

101:                                              ; preds = %92
  %102 = load ptr, ptr %5, align 8
  %103 = load ptr, ptr %102, align 8
  %104 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %103, i32 0, i32 2
  %105 = load i32, ptr %104, align 8
  %106 = mul i32 %105, 128
  %107 = load ptr, ptr %6, align 8
  store i32 %106, ptr %107, align 4
  %108 = load ptr, ptr %5, align 8
  %109 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %108, i32 0, i32 2
  store i32 0, ptr %109, align 8
  br label %45

110:                                              ; preds = %32, %83, %100
  %111 = load i8, ptr %4, align 1
  %112 = icmp ne i8 %111, 0
  br i1 %112, label %113, label %122

113:                                              ; preds = %110
  br label %114

114:                                              ; preds = %113
  store ptr %8, ptr %2, align 8
  store ptr %9, ptr %3, align 8
  %115 = load ptr, ptr %2, align 8
  %116 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %115, i32 0, i32 3
  %117 = load i64, ptr %116, align 8
  %118 = lshr i64 %117, 1
  store i64 %118, ptr %116, align 8
  %119 = load ptr, ptr %3, align 8
  %120 = load i32, ptr %119, align 4
  %121 = add i32 %120, 1
  store i32 %121, ptr %119, align 4
  br label %11, !llvm.loop !10

122:                                              ; preds = %110
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @bmp_iter_set_init(ptr noundef %0, ptr noundef %1, i32 noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  store ptr %3, ptr %8, align 8
  %9 = load ptr, ptr %6, align 8
  %10 = getelementptr inbounds nuw %struct.bitmap_head_def, ptr %9, i32 0, i32 0
  %11 = load ptr, ptr %10, align 8
  %12 = load ptr, ptr %5, align 8
  %13 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %12, i32 0, i32 0
  store ptr %11, ptr %13, align 8
  %14 = load ptr, ptr %5, align 8
  %15 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %14, i32 0, i32 1
  store ptr null, ptr %15, align 8
  br label %16

16:                                               ; preds = %4, %34
  %17 = load ptr, ptr %5, align 8
  %18 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %17, i32 0, i32 0
  %19 = load ptr, ptr %18, align 8
  %20 = icmp ne ptr %19, null
  br i1 %20, label %24, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %5, align 8
  %23 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %22, i32 0, i32 0
  store ptr @bitmap_zero_bits, ptr %23, align 8
  br label %42

24:                                               ; preds = %16
  %25 = load ptr, ptr %5, align 8
  %26 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %25, i32 0, i32 0
  %27 = load ptr, ptr %26, align 8
  %28 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %27, i32 0, i32 2
  %29 = load i32, ptr %28, align 8
  %30 = load i32, ptr %7, align 4
  %31 = udiv i32 %30, 128
  %32 = icmp uge i32 %29, %31
  br i1 %32, label %33, label %34

33:                                               ; preds = %24
  br label %42

34:                                               ; preds = %24
  %35 = load ptr, ptr %5, align 8
  %36 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %35, i32 0, i32 0
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %37, i32 0, i32 0
  %39 = load ptr, ptr %38, align 8
  %40 = load ptr, ptr %5, align 8
  %41 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %40, i32 0, i32 0
  store ptr %39, ptr %41, align 8
  br label %16

42:                                               ; preds = %33, %21
  %43 = load ptr, ptr %5, align 8
  %44 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %43, i32 0, i32 0
  %45 = load ptr, ptr %44, align 8
  %46 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %45, i32 0, i32 2
  %47 = load i32, ptr %46, align 8
  %48 = load i32, ptr %7, align 4
  %49 = udiv i32 %48, 128
  %50 = icmp ne i32 %47, %49
  br i1 %50, label %51, label %58

51:                                               ; preds = %42
  %52 = load ptr, ptr %5, align 8
  %53 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %52, i32 0, i32 0
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %54, i32 0, i32 2
  %56 = load i32, ptr %55, align 8
  %57 = mul i32 %56, 128
  store i32 %57, ptr %7, align 4
  br label %58

58:                                               ; preds = %51, %42
  %59 = load i32, ptr %7, align 4
  %60 = udiv i32 %59, 64
  %61 = urem i32 %60, 2
  %62 = load ptr, ptr %5, align 8
  %63 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %62, i32 0, i32 2
  store i32 %61, ptr %63, align 8
  %64 = load ptr, ptr %5, align 8
  %65 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %64, i32 0, i32 0
  %66 = load ptr, ptr %65, align 8
  %67 = getelementptr inbounds nuw %struct.bitmap_element_def, ptr %66, i32 0, i32 3
  %68 = load ptr, ptr %5, align 8
  %69 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %68, i32 0, i32 2
  %70 = load i32, ptr %69, align 8
  %71 = zext i32 %70 to i64
  %72 = getelementptr inbounds nuw [2 x i64], ptr %67, i64 0, i64 %71
  %73 = load i64, ptr %72, align 8
  %74 = load ptr, ptr %5, align 8
  %75 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %74, i32 0, i32 3
  store i64 %73, ptr %75, align 8
  %76 = load i32, ptr %7, align 4
  %77 = urem i32 %76, 64
  %78 = load ptr, ptr %5, align 8
  %79 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %78, i32 0, i32 3
  %80 = load i64, ptr %79, align 8
  %81 = zext i32 %77 to i64
  %82 = lshr i64 %80, %81
  store i64 %82, ptr %79, align 8
  %83 = load ptr, ptr %5, align 8
  %84 = getelementptr inbounds nuw %struct.bitmap_iterator, ptr %83, i32 0, i32 3
  %85 = load i64, ptr %84, align 8
  %86 = icmp ne i64 %85, 0
  %87 = xor i1 %86, true
  %88 = zext i1 %87 to i32
  %89 = load i32, ptr %7, align 4
  %90 = add i32 %89, %88
  store i32 %90, ptr %7, align 4
  %91 = load i32, ptr %7, align 4
  %92 = load ptr, ptr %8, align 8
  store i32 %91, ptr %92, align 4
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
