; ModuleID = '20020411-1.c'
source_filename = "20020411-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local <2 x float> @foo() #0 {
  %1 = alloca { float, float }, align 4
  %2 = alloca [1 x { float, float }], align 4
  %3 = getelementptr inbounds [1 x { float, float }], ptr %2, i64 0, i64 0
  %4 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 0
  store float 1.000000e+00, ptr %4, align 4
  %5 = getelementptr inbounds [1 x { float, float }], ptr %2, i64 0, i64 0
  %6 = getelementptr inbounds nuw { float, float }, ptr %5, i32 0, i32 1
  store float 1.000000e+00, ptr %6, align 4
  %7 = getelementptr inbounds [1 x { float, float }], ptr %2, i64 0, i64 0
  %8 = getelementptr inbounds nuw { float, float }, ptr %7, i32 0, i32 0
  %9 = load float, ptr %8, align 4
  %10 = getelementptr inbounds nuw { float, float }, ptr %7, i32 0, i32 1
  %11 = load float, ptr %10, align 4
  %12 = fneg float %11
  %13 = getelementptr inbounds [1 x { float, float }], ptr %2, i64 0, i64 0
  %14 = getelementptr inbounds nuw { float, float }, ptr %13, i32 0, i32 0
  %15 = getelementptr inbounds nuw { float, float }, ptr %13, i32 0, i32 1
  store float %9, ptr %14, align 4
  store float %12, ptr %15, align 4
  %16 = getelementptr inbounds [1 x { float, float }], ptr %2, i64 0, i64 0
  %17 = getelementptr inbounds nuw { float, float }, ptr %16, i32 0, i32 0
  %18 = load float, ptr %17, align 4
  %19 = getelementptr inbounds nuw { float, float }, ptr %16, i32 0, i32 1
  %20 = load float, ptr %19, align 4
  %21 = getelementptr inbounds nuw { float, float }, ptr %1, i32 0, i32 0
  %22 = getelementptr inbounds nuw { float, float }, ptr %1, i32 0, i32 1
  store float %18, ptr %21, align 4
  store float %20, ptr %22, align 4
  %23 = load <2 x float>, ptr %1, align 4
  ret <2 x float> %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [1 x { double, double }], align 16
  %3 = alloca { float, float }, align 4
  store i32 0, ptr %1, align 4
  %4 = call <2 x float> @foo()
  store <2 x float> %4, ptr %3, align 4
  %5 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 0
  %6 = load float, ptr %5, align 4
  %7 = getelementptr inbounds nuw { float, float }, ptr %3, i32 0, i32 1
  %8 = load float, ptr %7, align 4
  %9 = fpext float %6 to double
  %10 = fpext float %8 to double
  %11 = getelementptr inbounds [1 x { double, double }], ptr %2, i64 0, i64 0
  %12 = getelementptr inbounds nuw { double, double }, ptr %11, i32 0, i32 0
  %13 = getelementptr inbounds nuw { double, double }, ptr %11, i32 0, i32 1
  store double %9, ptr %12, align 16
  store double %10, ptr %13, align 8
  %14 = getelementptr inbounds [1 x { double, double }], ptr %2, i64 0, i64 0
  %15 = getelementptr inbounds nuw { double, double }, ptr %14, i32 0, i32 0
  %16 = load double, ptr %15, align 16
  %17 = fcmp une double %16, 1.000000e+00
  br i1 %17, label %23, label %18

18:                                               ; preds = %0
  %19 = getelementptr inbounds [1 x { double, double }], ptr %2, i64 0, i64 0
  %20 = getelementptr inbounds nuw { double, double }, ptr %19, i32 0, i32 1
  %21 = load double, ptr %20, align 8
  %22 = fcmp une double %21, -1.000000e+00
  br i1 %22, label %23, label %24

23:                                               ; preds = %18, %0
  call void @abort() #3
  unreachable

24:                                               ; preds = %18
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="64" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
