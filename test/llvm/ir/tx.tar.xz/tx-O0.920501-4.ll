; ModuleID = '920501-4.c'
source_filename = "920501-4.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@x.j = internal global [3 x ptr] [ptr blockaddress(@x, %8), ptr blockaddress(@x, %9), ptr blockaddress(@x, %10)], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @x(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = sext i32 %4 to i64
  %6 = getelementptr inbounds [3 x ptr], ptr @x.j, i64 0, i64 %5
  %7 = load ptr, ptr %6, align 8
  br label %13

8:                                                ; preds = %13
  store i32 2, ptr %2, align 4
  br label %11

9:                                                ; preds = %13
  store i32 3, ptr %2, align 4
  br label %11

10:                                               ; preds = %13
  store i32 5, ptr %2, align 4
  br label %11

11:                                               ; preds = %10, %9, %8
  %12 = load i32, ptr %2, align 4
  ret i32 %12

13:                                               ; preds = %1
  %14 = phi ptr [ %7, %1 ]
  indirectbr ptr %14, [label %8, label %9, label %10]
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @x(i32 noundef 0)
  %3 = icmp ne i32 %2, 2
  br i1 %3, label %10, label %4

4:                                                ; preds = %0
  %5 = call i32 @x(i32 noundef 1)
  %6 = icmp ne i32 %5, 3
  br i1 %6, label %10, label %7

7:                                                ; preds = %4
  %8 = call i32 @x(i32 noundef 2)
  %9 = icmp ne i32 %8, 5
  br i1 %9, label %10, label %11

10:                                               ; preds = %7, %4, %0
  call void @abort() #3
  unreachable

11:                                               ; preds = %7
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
