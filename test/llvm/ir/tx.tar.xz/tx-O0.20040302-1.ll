; ModuleID = '20040302-1.c'
source_filename = "20040302-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@code = dso_local global [5 x i32] [i32 0, i32 0, i32 0, i32 0, i32 1], align 16
@bar.l = internal global [2 x ptr] [ptr blockaddress(@bar, %8), ptr blockaddress(@bar, %16)], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  store volatile i32 -1, ptr %3, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @bar(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  call void @foo(i32 noundef 0)
  %3 = load ptr, ptr %2, align 8
  %4 = load i32, ptr %3, align 4
  %5 = sext i32 %4 to i64
  %6 = getelementptr inbounds [2 x ptr], ptr @bar.l, i64 0, i64 %5
  %7 = load ptr, ptr %6, align 8
  br label %17

8:                                                ; preds = %17
  call void @foo(i32 noundef 0)
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds nuw i32, ptr %9, i32 1
  store ptr %10, ptr %2, align 8
  %11 = load ptr, ptr %2, align 8
  %12 = load i32, ptr %11, align 4
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds [2 x ptr], ptr @bar.l, i64 0, i64 %13
  %15 = load ptr, ptr %14, align 8
  br label %17

16:                                               ; preds = %17
  ret void

17:                                               ; preds = %8, %1
  %18 = phi ptr [ %7, %1 ], [ %15, %8 ]
  indirectbr ptr %18, [label %8, label %16]
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @bar(ptr noundef @code)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
