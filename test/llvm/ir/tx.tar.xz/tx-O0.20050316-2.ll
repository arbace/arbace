; ModuleID = '20050316-2.c'
source_filename = "20050316-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { i64 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @test1(double noundef %0) #0 {
  %2 = alloca <2 x float>, align 8
  %3 = alloca <2 x float>, align 8
  store double %0, ptr %2, align 8
  %4 = load <2 x float>, ptr %2, align 8
  store <2 x float> %4, ptr %3, align 8
  %5 = load <2 x float>, ptr %3, align 8
  %6 = bitcast <2 x float> %5 to <2 x i32>
  %7 = bitcast <2 x i32> %6 to i64
  ret i64 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @test2(double noundef %0) #0 {
  %2 = alloca <2 x float>, align 8
  %3 = alloca <2 x float>, align 8
  store double %0, ptr %2, align 8
  %4 = load <2 x float>, ptr %2, align 8
  store <2 x float> %4, ptr %3, align 8
  %5 = load <2 x float>, ptr %3, align 8
  %6 = bitcast <2 x float> %5 to i64
  ret i64 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @test3(double noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  store double %0, ptr %2, align 8
  %4 = load <2 x i32>, ptr %2, align 8
  store <2 x i32> %4, ptr %3, align 8
  %5 = load <2 x i32>, ptr %3, align 8
  %6 = bitcast <2 x i32> %5 to <2 x float>
  %7 = bitcast <2 x float> %6 to i64
  ret i64 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca <2 x float>, align 8
  %3 = alloca %union.anon, align 8
  %4 = alloca <2 x float>, align 8
  %5 = alloca <2 x float>, align 8
  %6 = alloca <2 x float>, align 8
  %7 = alloca <2 x i32>, align 8
  %8 = alloca <2 x i32>, align 8
  store i32 0, ptr %1, align 4
  store <2 x float> splat (float 2.000000e+00), ptr %2, align 8
  %9 = load <2 x float>, ptr %2, align 8
  store <2 x float> %9, ptr %4, align 8
  %10 = load double, ptr %4, align 8
  %11 = call i64 @test1(double noundef %10)
  store i64 %11, ptr %3, align 8
  %12 = getelementptr inbounds [2 x float], ptr %3, i64 0, i64 0
  %13 = load float, ptr %12, align 8
  %14 = fpext float %13 to double
  %15 = fcmp une double %14, 2.000000e+00
  br i1 %15, label %21, label %16

16:                                               ; preds = %0
  %17 = getelementptr inbounds [2 x float], ptr %3, i64 0, i64 1
  %18 = load float, ptr %17, align 4
  %19 = fpext float %18 to double
  %20 = fcmp une double %19, 2.000000e+00
  br i1 %20, label %21, label %22

21:                                               ; preds = %16, %0
  call void @abort() #2
  unreachable

22:                                               ; preds = %16
  store <2 x float> splat (float 6.000000e+00), ptr %5, align 8
  %23 = load <2 x float>, ptr %5, align 8
  store <2 x float> %23, ptr %6, align 8
  %24 = load double, ptr %6, align 8
  %25 = call i64 @test2(double noundef %24)
  store i64 %25, ptr %3, align 8
  %26 = getelementptr inbounds [2 x float], ptr %3, i64 0, i64 0
  %27 = load float, ptr %26, align 8
  %28 = fpext float %27 to double
  %29 = fcmp une double %28, 6.000000e+00
  br i1 %29, label %35, label %30

30:                                               ; preds = %22
  %31 = getelementptr inbounds [2 x float], ptr %3, i64 0, i64 1
  %32 = load float, ptr %31, align 4
  %33 = fpext float %32 to double
  %34 = fcmp une double %33, 6.000000e+00
  br i1 %34, label %35, label %36

35:                                               ; preds = %30, %22
  call void @abort() #2
  unreachable

36:                                               ; preds = %30
  store <2 x i32> splat (i32 4), ptr %7, align 8
  %37 = load <2 x i32>, ptr %7, align 8
  store <2 x i32> %37, ptr %8, align 8
  %38 = load double, ptr %8, align 8
  %39 = call i64 @test3(double noundef %38)
  store i64 %39, ptr %3, align 8
  %40 = getelementptr inbounds [2 x i32], ptr %3, i64 0, i64 0
  %41 = load i32, ptr %40, align 8
  %42 = icmp ne i32 %41, 4
  br i1 %42, label %47, label %43

43:                                               ; preds = %36
  %44 = getelementptr inbounds [2 x i32], ptr %3, i64 0, i64 1
  %45 = load i32, ptr %44, align 4
  %46 = icmp ne i32 %45, 4
  br i1 %46, label %47, label %48

47:                                               ; preds = %43, %36
  call void @abort() #2
  unreachable

48:                                               ; preds = %43
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
