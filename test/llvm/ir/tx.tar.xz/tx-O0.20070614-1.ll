; ModuleID = '20070614-1.c'
source_filename = "20070614-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@v = dso_local global { double, double } { double 3.000000e+00, double 1.000000e+00 }, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(double noundef %0, double noundef %1, ptr noundef %2) #0 {
  %4 = alloca { double, double }, align 8
  %5 = alloca ptr, align 8
  %6 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 0
  store double %0, ptr %6, align 8
  %7 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 1
  store double %1, ptr %7, align 8
  store ptr %2, ptr %5, align 8
  %8 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 0
  %9 = load double, ptr %8, align 8
  %10 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 1
  %11 = load double, ptr %10, align 8
  %12 = load double, ptr @v, align 8
  %13 = load double, ptr getelementptr inbounds nuw (i8, ptr @v, i64 8), align 8
  %14 = fcmp une double %9, %12
  %15 = fcmp une double %11, %13
  %16 = or i1 %14, %15
  br i1 %16, label %17, label %18

17:                                               ; preds = %3
  call void @abort() #3
  unreachable

18:                                               ; preds = %3
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong willreturn memory(read) uwtable
define dso_local { double, double } @bar(double noundef %0, double noundef %1) #2 {
  %3 = alloca { double, double }, align 8
  %4 = alloca { double, double }, align 8
  %5 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 0
  store double %0, ptr %5, align 8
  %6 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 1
  store double %1, ptr %6, align 8
  %7 = load double, ptr @v, align 8
  %8 = load double, ptr getelementptr inbounds nuw (i8, ptr @v, i64 8), align 8
  %9 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %10 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  store double %7, ptr %9, align 8
  store double %8, ptr %10, align 8
  %11 = load { double, double }, ptr %3, align 8
  ret { double, double } %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @baz() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca { double, double }, align 8
  %4 = alloca { double, double }, align 8
  store i32 0, ptr %2, align 4
  br label %5

5:                                                ; preds = %30, %0
  %6 = load i32, ptr %2, align 4
  %7 = icmp slt i32 %6, 6
  br i1 %7, label %8, label %33

8:                                                ; preds = %5
  %9 = load i32, ptr %2, align 4
  %10 = sitofp i32 %9 to float
  %11 = fmul float 0.000000e+00, %10
  %12 = fmul float 1.000000e+00, %10
  %13 = fpext float %11 to double
  %14 = fpext float %12 to double
  %15 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %16 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  store double %13, ptr %15, align 8
  store double %14, ptr %16, align 8
  %17 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 0
  %18 = load double, ptr %17, align 8
  %19 = getelementptr inbounds nuw { double, double }, ptr %3, i32 0, i32 1
  %20 = load double, ptr %19, align 8
  %21 = call { double, double } @bar(double noundef %18, double noundef %20) #4
  %22 = extractvalue { double, double } %21, 0
  %23 = extractvalue { double, double } %21, 1
  %24 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 0
  %25 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 1
  store double %22, ptr %24, align 8
  store double %23, ptr %25, align 8
  %26 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 0
  %27 = load double, ptr %26, align 8
  %28 = getelementptr inbounds nuw { double, double }, ptr %4, i32 0, i32 1
  %29 = load double, ptr %28, align 8
  call void @foo(double noundef %27, double noundef %29, ptr noundef %1)
  br label %30

30:                                               ; preds = %8
  %31 = load i32, ptr %2, align 4
  %32 = add nsw i32 %31, 1
  store i32 %32, ptr %2, align 4
  br label %5, !llvm.loop !6

33:                                               ; preds = %5
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @baz()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noinline nounwind optnone sspstrong willreturn memory(read) uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
