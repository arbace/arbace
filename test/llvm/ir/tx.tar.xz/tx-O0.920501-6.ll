; ModuleID = '920501-6.c'
source_filename = "920501-6.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [11 x i8] c"1234111111\00", align 1
@.str.1 = private unnamed_addr constant [11 x i8] c"1234111127\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @str2llu(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw i8, ptr %5, i32 1
  store ptr %6, ptr %2, align 8
  %7 = load i8, ptr %5, align 1
  %8 = sext i8 %7 to i32
  %9 = sub nsw i32 %8, 48
  %10 = sext i32 %9 to i64
  store i64 %10, ptr %3, align 8
  br label %11

11:                                               ; preds = %19, %1
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds nuw i8, ptr %12, i32 1
  store ptr %13, ptr %2, align 8
  %14 = load i8, ptr %12, align 1
  %15 = sext i8 %14 to i32
  store i32 %15, ptr %4, align 4
  %16 = load i32, ptr %4, align 4
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %18, label %19

18:                                               ; preds = %11
  br label %27

19:                                               ; preds = %11
  %20 = load i32, ptr %4, align 4
  %21 = sub nsw i32 %20, 48
  store i32 %21, ptr %4, align 4
  %22 = load i64, ptr %3, align 8
  %23 = mul i64 %22, 10
  %24 = load i32, ptr %4, align 4
  %25 = sext i32 %24 to i64
  %26 = add i64 %23, %25
  store i64 %26, ptr %3, align 8
  br label %11

27:                                               ; preds = %18
  %28 = load i64, ptr %3, align 8
  ret i64 %28
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @sqrtllu(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  store i64 0, ptr %4, align 8
  %5 = load i64, ptr %2, align 8
  store i64 %5, ptr %3, align 8
  br label %6

6:                                                ; preds = %12, %1
  %7 = load i64, ptr %4, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %4, align 8
  %9 = load i64, ptr %3, align 8
  %10 = lshr i64 %9, 1
  store i64 %10, ptr %3, align 8
  %11 = icmp ne i64 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %6
  br label %6, !llvm.loop !6

13:                                               ; preds = %6
  %14 = load i64, ptr %4, align 8
  %15 = lshr i64 %14, 1
  %16 = shl i64 1, %15
  store i64 %16, ptr %3, align 8
  %17 = load i64, ptr %4, align 8
  %18 = and i64 %17, 1
  %19 = icmp ne i64 %18, 0
  br i1 %19, label %20, label %25

20:                                               ; preds = %13
  %21 = load i64, ptr %3, align 8
  %22 = lshr i64 %21, 1
  %23 = load i64, ptr %3, align 8
  %24 = add i64 %23, %22
  store i64 %24, ptr %3, align 8
  br label %25

25:                                               ; preds = %20, %13
  br label %26

26:                                               ; preds = %34, %25
  %27 = load i64, ptr %2, align 8
  %28 = load i64, ptr %3, align 8
  %29 = udiv i64 %27, %28
  store i64 %29, ptr %4, align 8
  %30 = load i64, ptr %3, align 8
  %31 = load i64, ptr %4, align 8
  %32 = add i64 %30, %31
  %33 = lshr i64 %32, 1
  store i64 %33, ptr %3, align 8
  br label %34

34:                                               ; preds = %26
  %35 = load i64, ptr %4, align 8
  %36 = load i64, ptr %3, align 8
  %37 = icmp ult i64 %35, %36
  br i1 %37, label %26, label %38, !llvm.loop !8

38:                                               ; preds = %34
  %39 = load i64, ptr %3, align 8
  ret i64 %39
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @plist(i64 noundef %0, i64 noundef %1, ptr noundef %2) #0 {
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i64, align 8
  store i64 %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  %12 = load ptr, ptr %6, align 8
  store ptr %12, ptr %10, align 8
  %13 = load i64, ptr %4, align 8
  store i64 %13, ptr %7, align 8
  br label %14

14:                                               ; preds = %41, %3
  %15 = load i64, ptr %7, align 8
  %16 = load i64, ptr %5, align 8
  %17 = icmp ule i64 %15, %16
  br i1 %17, label %18, label %44

18:                                               ; preds = %14
  %19 = load i64, ptr %7, align 8
  %20 = call i64 @sqrtllu(i64 noundef %19)
  store i64 %20, ptr %9, align 8
  store i64 3, ptr %8, align 8
  br label %21

21:                                               ; preds = %33, %18
  %22 = load i64, ptr %8, align 8
  %23 = load i64, ptr %9, align 8
  %24 = icmp ule i64 %22, %23
  br i1 %24, label %25, label %36

25:                                               ; preds = %21
  %26 = load i64, ptr %7, align 8
  %27 = load i64, ptr %8, align 8
  %28 = urem i64 %26, %27
  store i64 %28, ptr %11, align 8
  %29 = load i64, ptr %11, align 8
  %30 = icmp eq i64 %29, 0
  br i1 %30, label %31, label %32

31:                                               ; preds = %25
  br label %40

32:                                               ; preds = %25
  br label %33

33:                                               ; preds = %32
  %34 = load i64, ptr %8, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %8, align 8
  br label %21, !llvm.loop !9

36:                                               ; preds = %21
  %37 = load i64, ptr %7, align 8
  %38 = load ptr, ptr %10, align 8
  %39 = getelementptr inbounds nuw i64, ptr %38, i32 1
  store ptr %39, ptr %10, align 8
  store i64 %37, ptr %38, align 8
  br label %40

40:                                               ; preds = %36, %31
  br label %41

41:                                               ; preds = %40
  %42 = load i64, ptr %7, align 8
  %43 = add i64 %42, 2
  store i64 %43, ptr %7, align 8
  br label %14, !llvm.loop !10

44:                                               ; preds = %14
  %45 = load ptr, ptr %10, align 8
  store i64 0, ptr %45, align 8
  %46 = load ptr, ptr %10, align 8
  %47 = load ptr, ptr %6, align 8
  %48 = ptrtoint ptr %46 to i64
  %49 = ptrtoint ptr %47 to i64
  %50 = sub i64 %48, %49
  %51 = sdiv exact i64 %50, 8
  %52 = trunc i64 %51 to i32
  ret i32 %52
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca [10 x i64], align 16
  %7 = alloca i32, align 4
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  %8 = call i64 @str2llu(ptr noundef @.str)
  %9 = call i64 @str2llu(ptr noundef @.str.1)
  %10 = getelementptr inbounds [10 x i64], ptr %6, i64 0, i64 0
  %11 = call i32 @plist(i64 noundef %8, i64 noundef %9, ptr noundef %10)
  store i32 %11, ptr %7, align 4
  %12 = getelementptr inbounds [10 x i64], ptr %6, i64 0, i64 0
  %13 = load i64, ptr %12, align 16
  %14 = icmp ne i64 %13, 1234111117
  br i1 %14, label %27, label %15

15:                                               ; preds = %2
  %16 = getelementptr inbounds [10 x i64], ptr %6, i64 0, i64 1
  %17 = load i64, ptr %16, align 8
  %18 = icmp ne i64 %17, 1234111121
  br i1 %18, label %27, label %19

19:                                               ; preds = %15
  %20 = getelementptr inbounds [10 x i64], ptr %6, i64 0, i64 2
  %21 = load i64, ptr %20, align 16
  %22 = icmp ne i64 %21, 1234111127
  br i1 %22, label %27, label %23

23:                                               ; preds = %19
  %24 = getelementptr inbounds [10 x i64], ptr %6, i64 0, i64 3
  %25 = load i64, ptr %24, align 8
  %26 = icmp ne i64 %25, 0
  br i1 %26, label %27, label %28

27:                                               ; preds = %23, %19, %15, %2
  call void @abort() #3
  unreachable

28:                                               ; preds = %23
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
