; ModuleID = '20071029-1.c'
source_filename = "20071029-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.anon = type { i32, i32, i32, i32, i32, i32, i32, i32, i64, i64, i32 }
%union.T = type { %struct.anon }

@test.i = internal global i32 11, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.anon, ptr %3, i32 0, i32 0
  %5 = load i32, ptr %4, align 8
  %6 = load i32, ptr @test.i, align 4
  %7 = add nsw i32 %6, 1
  store i32 %7, ptr @test.i, align 4
  %8 = icmp ne i32 %5, %6
  br i1 %8, label %9, label %10

9:                                                ; preds = %1
  call void @abort() #5
  unreachable

10:                                               ; preds = %1
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.anon, ptr %11, i32 0, i32 1
  %13 = load i32, ptr %12, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %60, label %15

15:                                               ; preds = %10
  %16 = load ptr, ptr %2, align 8
  %17 = getelementptr inbounds nuw %struct.anon, ptr %16, i32 0, i32 2
  %18 = load i32, ptr %17, align 8
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %60, label %20

20:                                               ; preds = %15
  %21 = load ptr, ptr %2, align 8
  %22 = getelementptr inbounds nuw %struct.anon, ptr %21, i32 0, i32 3
  %23 = load i32, ptr %22, align 4
  %24 = icmp ne i32 %23, 0
  br i1 %24, label %60, label %25

25:                                               ; preds = %20
  %26 = load ptr, ptr %2, align 8
  %27 = getelementptr inbounds nuw %struct.anon, ptr %26, i32 0, i32 4
  %28 = load i32, ptr %27, align 8
  %29 = icmp ne i32 %28, 0
  br i1 %29, label %60, label %30

30:                                               ; preds = %25
  %31 = load ptr, ptr %2, align 8
  %32 = getelementptr inbounds nuw %struct.anon, ptr %31, i32 0, i32 5
  %33 = load i32, ptr %32, align 4
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %60, label %35

35:                                               ; preds = %30
  %36 = load ptr, ptr %2, align 8
  %37 = getelementptr inbounds nuw %struct.anon, ptr %36, i32 0, i32 6
  %38 = load i32, ptr %37, align 8
  %39 = icmp ne i32 %38, 0
  br i1 %39, label %60, label %40

40:                                               ; preds = %35
  %41 = load ptr, ptr %2, align 8
  %42 = getelementptr inbounds nuw %struct.anon, ptr %41, i32 0, i32 7
  %43 = load i32, ptr %42, align 4
  %44 = icmp ne i32 %43, 0
  br i1 %44, label %60, label %45

45:                                               ; preds = %40
  %46 = load ptr, ptr %2, align 8
  %47 = getelementptr inbounds nuw %struct.anon, ptr %46, i32 0, i32 8
  %48 = load i64, ptr %47, align 8
  %49 = icmp ne i64 %48, 0
  br i1 %49, label %60, label %50

50:                                               ; preds = %45
  %51 = load ptr, ptr %2, align 8
  %52 = getelementptr inbounds nuw %struct.anon, ptr %51, i32 0, i32 9
  %53 = load i64, ptr %52, align 8
  %54 = icmp ne i64 %53, 0
  br i1 %54, label %60, label %55

55:                                               ; preds = %50
  %56 = load ptr, ptr %2, align 8
  %57 = getelementptr inbounds nuw %struct.anon, ptr %56, i32 0, i32 10
  %58 = load i32, ptr %57, align 8
  %59 = icmp ne i32 %58, 0
  br i1 %59, label %60, label %61

60:                                               ; preds = %55, %50, %45, %40, %35, %30, %25, %20, %15, %10
  call void @abort() #5
  unreachable

61:                                               ; preds = %55
  %62 = load i32, ptr @test.i, align 4
  %63 = icmp eq i32 %62, 20
  br i1 %63, label %64, label %65

64:                                               ; preds = %61
  call void @exit(i32 noundef 0) #6
  unreachable

65:                                               ; preds = %61
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca %union.T, align 8
  %4 = alloca %union.T, align 8
  store i32 %0, ptr %2, align 4
  br label %5

5:                                                ; preds = %5, %1
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 56, i1 false)
  %6 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 0
  %7 = load i32, ptr %2, align 4
  %8 = add nsw i32 %7, 1
  store i32 %8, ptr %2, align 4
  store i32 %8, ptr %6, align 8
  %9 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 1
  %10 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 2
  %11 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 3
  %12 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 4
  %13 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 5
  %14 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 6
  %15 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 7
  %16 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 8
  %17 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 9
  %18 = getelementptr inbounds nuw %struct.anon, ptr %4, i32 0, i32 10
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 56, i1 false)
  call void @test(ptr noundef %3)
  br label %5
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca %union.T, align 8
  store i32 0, ptr %1, align 4
  store i32 0, ptr %4, align 4
  store ptr null, ptr %2, align 8
  br label %6

6:                                                ; preds = %24, %0
  %7 = load ptr, ptr %2, align 8
  store ptr %7, ptr %3, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %5, i8 0, i64 56, i1 false)
  %8 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 0
  %9 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 1
  %10 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 2
  %11 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 3
  %12 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 4
  %13 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 5
  %14 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 6
  %15 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 7
  %16 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 8
  %17 = load i32, ptr %4, align 4
  %18 = add nsw i32 %17, 1
  store i32 %18, ptr %4, align 4
  %19 = sext i32 %17 to i64
  store i64 %19, ptr %16, align 8
  %20 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 9
  %21 = getelementptr inbounds nuw %struct.anon, ptr %5, i32 0, i32 10
  store ptr %5, ptr %2, align 8
  %22 = load i32, ptr %4, align 4
  %23 = icmp slt i32 %22, 3
  br i1 %23, label %24, label %25

24:                                               ; preds = %6
  br label %6

25:                                               ; preds = %6
  %26 = load ptr, ptr %2, align 8
  %27 = load ptr, ptr %3, align 8
  %28 = icmp ne ptr %26, %27
  br i1 %28, label %34, label %29

29:                                               ; preds = %25
  %30 = load ptr, ptr %2, align 8
  %31 = getelementptr inbounds nuw %struct.anon, ptr %30, i32 0, i32 8
  %32 = load i64, ptr %31, align 8
  %33 = icmp ne i64 %32, 2
  br i1 %33, label %34, label %35

34:                                               ; preds = %29, %25
  call void @abort() #5
  unreachable

35:                                               ; preds = %29
  call void @foo(i32 noundef 10)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
