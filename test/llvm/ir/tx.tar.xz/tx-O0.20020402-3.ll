; ModuleID = '20020402-3.c'
source_filename = "20020402-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.symtab = type { ptr }
%struct.blockvector = type { i32, [2 x ptr] }
%struct.block = type { i64, i64, ptr, ptr, i8, i32, [1 x %struct.symbol] }
%struct.symbol = type { i32, ptr }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @blockvector_for_pc_sect(i64 noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca ptr, align 8
  store i64 %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  %11 = load ptr, ptr %5, align 8
  %12 = getelementptr inbounds nuw %struct.symtab, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %12, align 8
  store ptr %13, ptr %10, align 8
  %14 = load ptr, ptr %10, align 8
  %15 = getelementptr inbounds nuw %struct.blockvector, ptr %14, i32 0, i32 1
  %16 = getelementptr inbounds [2 x ptr], ptr %15, i64 0, i64 0
  %17 = load ptr, ptr %16, align 8
  store ptr %17, ptr %6, align 8
  store i32 0, ptr %7, align 4
  %18 = load ptr, ptr %10, align 8
  %19 = getelementptr inbounds nuw %struct.blockvector, ptr %18, i32 0, i32 0
  %20 = load i32, ptr %19, align 8
  store i32 %20, ptr %8, align 4
  br label %21

21:                                               ; preds = %53, %2
  %22 = load i32, ptr %8, align 4
  %23 = load i32, ptr %7, align 4
  %24 = sub nsw i32 %22, %23
  %25 = icmp sgt i32 %24, 1
  br i1 %25, label %26, label %54

26:                                               ; preds = %21
  %27 = load i32, ptr %8, align 4
  %28 = load i32, ptr %7, align 4
  %29 = sub nsw i32 %27, %28
  %30 = add nsw i32 %29, 1
  %31 = ashr i32 %30, 1
  store i32 %31, ptr %9, align 4
  %32 = load ptr, ptr %10, align 8
  %33 = getelementptr inbounds nuw %struct.blockvector, ptr %32, i32 0, i32 1
  %34 = load i32, ptr %7, align 4
  %35 = load i32, ptr %9, align 4
  %36 = add nsw i32 %34, %35
  %37 = sext i32 %36 to i64
  %38 = getelementptr inbounds [2 x ptr], ptr %33, i64 0, i64 %37
  %39 = load ptr, ptr %38, align 8
  store ptr %39, ptr %6, align 8
  %40 = load ptr, ptr %6, align 8
  %41 = getelementptr inbounds nuw %struct.block, ptr %40, i32 0, i32 0
  %42 = load i64, ptr %41, align 8
  %43 = load i64, ptr %4, align 8
  %44 = icmp ule i64 %42, %43
  br i1 %44, label %45, label %49

45:                                               ; preds = %26
  %46 = load i32, ptr %9, align 4
  %47 = load i32, ptr %7, align 4
  %48 = add nsw i32 %47, %46
  store i32 %48, ptr %7, align 4
  br label %53

49:                                               ; preds = %26
  %50 = load i32, ptr %7, align 4
  %51 = load i32, ptr %9, align 4
  %52 = add nsw i32 %50, %51
  store i32 %52, ptr %8, align 4
  br label %53

53:                                               ; preds = %49, %45
  br label %21, !llvm.loop !6

54:                                               ; preds = %21
  br label %55

55:                                               ; preds = %72, %54
  %56 = load i32, ptr %7, align 4
  %57 = icmp sge i32 %56, 0
  br i1 %57, label %58, label %75

58:                                               ; preds = %55
  %59 = load ptr, ptr %10, align 8
  %60 = getelementptr inbounds nuw %struct.blockvector, ptr %59, i32 0, i32 1
  %61 = load i32, ptr %7, align 4
  %62 = sext i32 %61 to i64
  %63 = getelementptr inbounds [2 x ptr], ptr %60, i64 0, i64 %62
  %64 = load ptr, ptr %63, align 8
  store ptr %64, ptr %6, align 8
  %65 = load ptr, ptr %6, align 8
  %66 = getelementptr inbounds nuw %struct.block, ptr %65, i32 0, i32 1
  %67 = load i64, ptr %66, align 8
  %68 = load i64, ptr %4, align 8
  %69 = icmp ugt i64 %67, %68
  br i1 %69, label %70, label %72

70:                                               ; preds = %58
  %71 = load ptr, ptr %10, align 8
  store ptr %71, ptr %3, align 8
  br label %76

72:                                               ; preds = %58
  %73 = load i32, ptr %7, align 4
  %74 = add nsw i32 %73, -1
  store i32 %74, ptr %7, align 4
  br label %55, !llvm.loop !8

75:                                               ; preds = %55
  store ptr null, ptr %3, align 8
  br label %76

76:                                               ; preds = %75, %70
  %77 = load ptr, ptr %3, align 8
  ret ptr %77
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.block, align 8
  %3 = alloca %struct.block, align 8
  %4 = alloca %struct.blockvector, align 8
  %5 = alloca %struct.symtab, align 8
  %6 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 56, i1 false)
  %7 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %2, i32 0, i32 1
  store i64 65536, ptr %7, align 8
  %8 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %2, i32 0, i32 4
  store i8 1, ptr %8, align 8
  %9 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %2, i32 0, i32 6
  store i32 20, ptr %9, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %3, i8 0, i64 56, i1 false)
  %10 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %3, i32 0, i32 0
  store i64 65536, ptr %10, align 8
  %11 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %3, i32 0, i32 1
  store i64 131072, ptr %11, align 8
  %12 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %3, i32 0, i32 4
  store i8 1, ptr %12, align 8
  %13 = getelementptr inbounds { i64, i64, ptr, ptr, i8, [3 x i8], i32, [1 x %struct.symbol] }, ptr %3, i32 0, i32 6
  store i32 20, ptr %13, align 4
  %14 = getelementptr inbounds nuw %struct.blockvector, ptr %4, i32 0, i32 0
  store i32 2, ptr %14, align 8
  %15 = getelementptr i8, ptr %4, i64 4
  call void @llvm.memset.p0.i64(ptr align 4 %15, i8 0, i64 4, i1 false)
  %16 = getelementptr inbounds nuw %struct.blockvector, ptr %4, i32 0, i32 1
  store ptr %2, ptr %16, align 8
  %17 = getelementptr inbounds ptr, ptr %16, i64 1
  store ptr %3, ptr %17, align 8
  %18 = getelementptr inbounds nuw %struct.symtab, ptr %5, i32 0, i32 0
  store ptr %4, ptr %18, align 8
  %19 = call ptr @blockvector_for_pc_sect(i64 noundef 1280, ptr noundef %5)
  store ptr %19, ptr %6, align 8
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
