; ModuleID = '20041011-1.c'
source_filename = "20041011-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@gvol = dso_local global [32 x i32] zeroinitializer, align 16
@gull = dso_local global i64 0, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t1(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, -2048
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !6

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t2(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, -513
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !8

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t3(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, -512
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !9

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t4(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, -511
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !10

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t5(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, -1
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !11

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t6(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, 1
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !12

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t7(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, 511
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !13

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t8(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, 512
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !14

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t9(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %102

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr %4, align 8
  %101 = add i64 %100, 513
  store i64 %101, ptr %4, align 8
  br label %35, !llvm.loop !15

102:                                              ; preds = %35
  %103 = load i64, ptr %4, align 8
  ret i64 %103
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t10(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %103

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr @gull, align 8
  %101 = load i64, ptr %4, align 8
  %102 = add i64 %101, %100
  store i64 %102, ptr %4, align 8
  br label %35, !llvm.loop !16

103:                                              ; preds = %35
  %104 = load i64, ptr %4, align 8
  ret i64 %104
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @t11(i32 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca i32, align 4
  %28 = alloca i32, align 4
  %29 = alloca i32, align 4
  %30 = alloca i32, align 4
  %31 = alloca i32, align 4
  %32 = alloca i32, align 4
  %33 = alloca i32, align 4
  %34 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i64 %1, ptr %4, align 8
  br label %35

35:                                               ; preds = %39, %2
  %36 = load i32, ptr %3, align 4
  %37 = add nsw i32 %36, -1
  store i32 %37, ptr %3, align 4
  %38 = icmp ne i32 %36, 0
  br i1 %38, label %39, label %104

39:                                               ; preds = %35
  %40 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  store i32 %40, ptr %5, align 4
  %41 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  store i32 %41, ptr %6, align 4
  %42 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  store i32 %42, ptr %7, align 4
  %43 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  store i32 %43, ptr %8, align 4
  %44 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  store i32 %44, ptr %9, align 4
  %45 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  store i32 %45, ptr %10, align 4
  %46 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  store i32 %46, ptr %11, align 4
  %47 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  store i32 %47, ptr %12, align 4
  %48 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  store i32 %48, ptr %13, align 4
  %49 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  store i32 %49, ptr %14, align 4
  %50 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  store i32 %50, ptr %15, align 4
  %51 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  store i32 %51, ptr %16, align 4
  %52 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  store i32 %52, ptr %17, align 4
  %53 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  store i32 %53, ptr %18, align 4
  %54 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  store i32 %54, ptr %19, align 4
  %55 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  store i32 %55, ptr %20, align 4
  %56 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  store i32 %56, ptr %21, align 4
  %57 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  store i32 %57, ptr %22, align 4
  %58 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  store i32 %58, ptr %23, align 4
  %59 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  store i32 %59, ptr %24, align 4
  %60 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  store i32 %60, ptr %25, align 4
  %61 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  store i32 %61, ptr %26, align 4
  %62 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  store i32 %62, ptr %27, align 4
  %63 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  store i32 %63, ptr %28, align 4
  %64 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  store i32 %64, ptr %29, align 4
  %65 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  store i32 %65, ptr %30, align 4
  %66 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  store i32 %66, ptr %31, align 4
  %67 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  store i32 %67, ptr %32, align 4
  %68 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  store i32 %68, ptr %33, align 4
  %69 = load volatile i32, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  store i32 %69, ptr %34, align 4
  %70 = load i32, ptr %5, align 4
  store volatile i32 %70, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 4), align 4
  %71 = load i32, ptr %6, align 4
  store volatile i32 %71, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 8), align 8
  %72 = load i32, ptr %7, align 4
  store volatile i32 %72, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 12), align 4
  %73 = load i32, ptr %8, align 4
  store volatile i32 %73, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 16), align 16
  %74 = load i32, ptr %9, align 4
  store volatile i32 %74, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 20), align 4
  %75 = load i32, ptr %10, align 4
  store volatile i32 %75, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 24), align 8
  %76 = load i32, ptr %11, align 4
  store volatile i32 %76, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 28), align 4
  %77 = load i32, ptr %12, align 4
  store volatile i32 %77, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 32), align 16
  %78 = load i32, ptr %13, align 4
  store volatile i32 %78, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 36), align 4
  %79 = load i32, ptr %14, align 4
  store volatile i32 %79, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 40), align 8
  %80 = load i32, ptr %15, align 4
  store volatile i32 %80, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 44), align 4
  %81 = load i32, ptr %16, align 4
  store volatile i32 %81, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 48), align 16
  %82 = load i32, ptr %17, align 4
  store volatile i32 %82, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 52), align 4
  %83 = load i32, ptr %18, align 4
  store volatile i32 %83, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 56), align 8
  %84 = load i32, ptr %19, align 4
  store volatile i32 %84, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 60), align 4
  %85 = load i32, ptr %20, align 4
  store volatile i32 %85, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 64), align 16
  %86 = load i32, ptr %21, align 4
  store volatile i32 %86, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 68), align 4
  %87 = load i32, ptr %22, align 4
  store volatile i32 %87, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 72), align 8
  %88 = load i32, ptr %23, align 4
  store volatile i32 %88, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 76), align 4
  %89 = load i32, ptr %24, align 4
  store volatile i32 %89, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 80), align 16
  %90 = load i32, ptr %25, align 4
  store volatile i32 %90, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 84), align 4
  %91 = load i32, ptr %26, align 4
  store volatile i32 %91, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 88), align 8
  %92 = load i32, ptr %27, align 4
  store volatile i32 %92, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 92), align 4
  %93 = load i32, ptr %28, align 4
  store volatile i32 %93, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 96), align 16
  %94 = load i32, ptr %29, align 4
  store volatile i32 %94, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 100), align 4
  %95 = load i32, ptr %30, align 4
  store volatile i32 %95, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 104), align 8
  %96 = load i32, ptr %31, align 4
  store volatile i32 %96, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 108), align 4
  %97 = load i32, ptr %32, align 4
  store volatile i32 %97, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 112), align 16
  %98 = load i32, ptr %33, align 4
  store volatile i32 %98, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 116), align 4
  %99 = load i32, ptr %34, align 4
  store volatile i32 %99, ptr getelementptr inbounds nuw (i8, ptr @gvol, i64 120), align 8
  %100 = load i64, ptr @gull, align 8
  %101 = sub i64 0, %100
  %102 = load i64, ptr %4, align 8
  %103 = add i64 %102, %101
  store i64 %103, ptr %4, align 8
  br label %35, !llvm.loop !17

104:                                              ; preds = %35
  %105 = load i64, ptr %4, align 8
  ret i64 %105
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @neg(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  %4 = sub i64 0, %3
  ret i64 %4
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i64 100, ptr @gull, align 8
  %2 = call i64 @t1(i32 noundef 3, i64 noundef -1)
  %3 = icmp ne i64 %2, -6145
  br i1 %3, label %4, label %5

4:                                                ; preds = %0
  call void @abort() #3
  unreachable

5:                                                ; preds = %0
  %6 = call i64 @t1(i32 noundef 3, i64 noundef 4294967295)
  %7 = icmp ne i64 %6, 4294961151
  br i1 %7, label %8, label %9

8:                                                ; preds = %5
  call void @abort() #3
  unreachable

9:                                                ; preds = %5
  %10 = call i64 @t2(i32 noundef 3, i64 noundef -1)
  %11 = icmp ne i64 %10, -1540
  br i1 %11, label %12, label %13

12:                                               ; preds = %9
  call void @abort() #3
  unreachable

13:                                               ; preds = %9
  %14 = call i64 @t2(i32 noundef 3, i64 noundef 4294967295)
  %15 = icmp ne i64 %14, 4294965756
  br i1 %15, label %16, label %17

16:                                               ; preds = %13
  call void @abort() #3
  unreachable

17:                                               ; preds = %13
  %18 = call i64 @t3(i32 noundef 3, i64 noundef -1)
  %19 = icmp ne i64 %18, -1537
  br i1 %19, label %20, label %21

20:                                               ; preds = %17
  call void @abort() #3
  unreachable

21:                                               ; preds = %17
  %22 = call i64 @t3(i32 noundef 3, i64 noundef 4294967295)
  %23 = icmp ne i64 %22, 4294965759
  br i1 %23, label %24, label %25

24:                                               ; preds = %21
  call void @abort() #3
  unreachable

25:                                               ; preds = %21
  %26 = call i64 @t4(i32 noundef 3, i64 noundef -1)
  %27 = icmp ne i64 %26, -1534
  br i1 %27, label %28, label %29

28:                                               ; preds = %25
  call void @abort() #3
  unreachable

29:                                               ; preds = %25
  %30 = call i64 @t4(i32 noundef 3, i64 noundef 4294967295)
  %31 = icmp ne i64 %30, 4294965762
  br i1 %31, label %32, label %33

32:                                               ; preds = %29
  call void @abort() #3
  unreachable

33:                                               ; preds = %29
  %34 = call i64 @t5(i32 noundef 3, i64 noundef -1)
  %35 = icmp ne i64 %34, -4
  br i1 %35, label %36, label %37

36:                                               ; preds = %33
  call void @abort() #3
  unreachable

37:                                               ; preds = %33
  %38 = call i64 @t5(i32 noundef 3, i64 noundef 4294967295)
  %39 = icmp ne i64 %38, 4294967292
  br i1 %39, label %40, label %41

40:                                               ; preds = %37
  call void @abort() #3
  unreachable

41:                                               ; preds = %37
  %42 = call i64 @t6(i32 noundef 3, i64 noundef -1)
  %43 = icmp ne i64 %42, 2
  br i1 %43, label %44, label %45

44:                                               ; preds = %41
  call void @abort() #3
  unreachable

45:                                               ; preds = %41
  %46 = call i64 @t6(i32 noundef 3, i64 noundef 4294967295)
  %47 = icmp ne i64 %46, 4294967298
  br i1 %47, label %48, label %49

48:                                               ; preds = %45
  call void @abort() #3
  unreachable

49:                                               ; preds = %45
  %50 = call i64 @t7(i32 noundef 3, i64 noundef -1)
  %51 = icmp ne i64 %50, 1532
  br i1 %51, label %52, label %53

52:                                               ; preds = %49
  call void @abort() #3
  unreachable

53:                                               ; preds = %49
  %54 = call i64 @t7(i32 noundef 3, i64 noundef 4294967295)
  %55 = icmp ne i64 %54, 4294968828
  br i1 %55, label %56, label %57

56:                                               ; preds = %53
  call void @abort() #3
  unreachable

57:                                               ; preds = %53
  %58 = call i64 @t8(i32 noundef 3, i64 noundef -1)
  %59 = icmp ne i64 %58, 1535
  br i1 %59, label %60, label %61

60:                                               ; preds = %57
  call void @abort() #3
  unreachable

61:                                               ; preds = %57
  %62 = call i64 @t8(i32 noundef 3, i64 noundef 4294967295)
  %63 = icmp ne i64 %62, 4294968831
  br i1 %63, label %64, label %65

64:                                               ; preds = %61
  call void @abort() #3
  unreachable

65:                                               ; preds = %61
  %66 = call i64 @t9(i32 noundef 3, i64 noundef -1)
  %67 = icmp ne i64 %66, 1538
  br i1 %67, label %68, label %69

68:                                               ; preds = %65
  call void @abort() #3
  unreachable

69:                                               ; preds = %65
  %70 = call i64 @t9(i32 noundef 3, i64 noundef 4294967295)
  %71 = icmp ne i64 %70, 4294968834
  br i1 %71, label %72, label %73

72:                                               ; preds = %69
  call void @abort() #3
  unreachable

73:                                               ; preds = %69
  %74 = call i64 @t10(i32 noundef 3, i64 noundef -1)
  %75 = load i64, ptr @gull, align 8
  %76 = mul i64 %75, 3
  %77 = sub i64 %76, 1
  %78 = icmp ne i64 %74, %77
  br i1 %78, label %79, label %80

79:                                               ; preds = %73
  call void @abort() #3
  unreachable

80:                                               ; preds = %73
  %81 = call i64 @t10(i32 noundef 3, i64 noundef 4294967295)
  %82 = load i64, ptr @gull, align 8
  %83 = mul i64 %82, 3
  %84 = add i64 %83, 4294967295
  %85 = icmp ne i64 %81, %84
  br i1 %85, label %86, label %87

86:                                               ; preds = %80
  call void @abort() #3
  unreachable

87:                                               ; preds = %80
  %88 = call i64 @t11(i32 noundef 3, i64 noundef -1)
  %89 = load i64, ptr @gull, align 8
  %90 = sub i64 0, %89
  %91 = mul i64 %90, 3
  %92 = sub i64 %91, 1
  %93 = icmp ne i64 %88, %92
  br i1 %93, label %94, label %95

94:                                               ; preds = %87
  call void @abort() #3
  unreachable

95:                                               ; preds = %87
  %96 = call i64 @t11(i32 noundef 3, i64 noundef 4294967295)
  %97 = load i64, ptr @gull, align 8
  %98 = sub i64 0, %97
  %99 = mul i64 %98, 3
  %100 = add i64 %99, 4294967295
  %101 = icmp ne i64 %96, %100
  br i1 %101, label %102, label %103

102:                                              ; preds = %95
  call void @abort() #3
  unreachable

103:                                              ; preds = %95
  %104 = load i64, ptr @gull, align 8
  %105 = call i64 @neg(i64 noundef %104)
  %106 = icmp ne i64 %105, -100
  br i1 %106, label %107, label %108

107:                                              ; preds = %103
  call void @abort() #3
  unreachable

108:                                              ; preds = %103
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
