; ModuleID = '920302-1.c'
source_filename = "920302-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@buf = dso_local global [10 x i8] zeroinitializer, align 1
@execute.tab = internal global [3 x ptr] [ptr blockaddress(@execute, %31), ptr blockaddress(@execute, %41), ptr blockaddress(@execute, %51)], align 16
@optab = dso_local global [5 x i16] zeroinitializer, align 2
@p = dso_local global [5 x i16] zeroinitializer, align 2
@.str = private unnamed_addr constant [6 x i8] c"xyxyz\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @execute(ptr noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store ptr blockaddress(@execute, %31), ptr %4, align 8
  store ptr @buf, ptr %5, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = icmp eq ptr %7, null
  br i1 %8, label %9, label %30

9:                                                ; preds = %1
  store i32 0, ptr %6, align 4
  br label %10

10:                                               ; preds = %26, %9
  %11 = load i32, ptr %6, align 4
  %12 = icmp slt i32 %11, 3
  br i1 %12, label %13, label %29

13:                                               ; preds = %10
  %14 = load i32, ptr %6, align 4
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds [3 x ptr], ptr @execute.tab, i64 0, i64 %15
  %17 = load ptr, ptr %16, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = ptrtoint ptr %17 to i64
  %20 = ptrtoint ptr %18 to i64
  %21 = sub i64 %19, %20
  %22 = trunc i64 %21 to i16
  %23 = load i32, ptr %6, align 4
  %24 = sext i32 %23 to i64
  %25 = getelementptr inbounds [5 x i16], ptr @optab, i64 0, i64 %24
  store i16 %22, ptr %25, align 2
  br label %26

26:                                               ; preds = %13
  %27 = load i32, ptr %6, align 4
  %28 = add nsw i32 %27, 1
  store i32 %28, ptr %6, align 4
  br label %10, !llvm.loop !6

29:                                               ; preds = %10
  br label %55

30:                                               ; preds = %1
  br label %31

31:                                               ; preds = %30, %57, %57
  %32 = load ptr, ptr %5, align 8
  %33 = getelementptr inbounds nuw i8, ptr %32, i32 1
  store ptr %33, ptr %5, align 8
  store i8 120, ptr %32, align 1
  %34 = load ptr, ptr %4, align 8
  %35 = load ptr, ptr %3, align 8
  %36 = getelementptr inbounds nuw i16, ptr %35, i32 1
  store ptr %36, ptr %3, align 8
  %37 = load i16, ptr %35, align 2
  %38 = sext i16 %37 to i32
  %39 = sext i32 %38 to i64
  %40 = getelementptr inbounds i8, ptr %34, i64 %39
  br label %57

41:                                               ; preds = %57
  %42 = load ptr, ptr %5, align 8
  %43 = getelementptr inbounds nuw i8, ptr %42, i32 1
  store ptr %43, ptr %5, align 8
  store i8 121, ptr %42, align 1
  %44 = load ptr, ptr %4, align 8
  %45 = load ptr, ptr %3, align 8
  %46 = getelementptr inbounds nuw i16, ptr %45, i32 1
  store ptr %46, ptr %3, align 8
  %47 = load i16, ptr %45, align 2
  %48 = sext i16 %47 to i32
  %49 = sext i32 %48 to i64
  %50 = getelementptr inbounds i8, ptr %44, i64 %49
  br label %57

51:                                               ; preds = %57
  %52 = load ptr, ptr %5, align 8
  %53 = getelementptr inbounds nuw i8, ptr %52, i32 1
  store ptr %53, ptr %5, align 8
  store i8 122, ptr %52, align 1
  %54 = load ptr, ptr %5, align 8
  store i8 0, ptr %54, align 1
  br label %55

55:                                               ; preds = %51, %29
  %56 = load i32, ptr %2, align 4
  ret i32 %56

57:                                               ; preds = %41, %31
  %58 = phi ptr [ %40, %31 ], [ %50, %41 ]
  indirectbr ptr %58, [label %31, label %31, label %41, label %51]
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @execute(ptr noundef null)
  %3 = load i16, ptr getelementptr inbounds nuw (i8, ptr @optab, i64 2), align 2
  store i16 %3, ptr @p, align 2
  %4 = load i16, ptr @optab, align 2
  store i16 %4, ptr getelementptr inbounds nuw (i8, ptr @p, i64 2), align 2
  %5 = load i16, ptr getelementptr inbounds nuw (i8, ptr @optab, i64 2), align 2
  store i16 %5, ptr getelementptr inbounds nuw (i8, ptr @p, i64 4), align 2
  %6 = load i16, ptr getelementptr inbounds nuw (i8, ptr @optab, i64 4), align 2
  store i16 %6, ptr getelementptr inbounds nuw (i8, ptr @p, i64 6), align 2
  %7 = call i32 @execute(ptr noundef @p)
  %8 = call i32 @strcmp(ptr noundef @buf, ptr noundef @.str) #4
  %9 = icmp ne i32 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %0
  call void @abort() #5
  unreachable

11:                                               ; preds = %0
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: nounwind
declare i32 @strcmp(ptr noundef, ptr noundef) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
