; ModuleID = '20020406-1.c'
source_filename = "20020406-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.DUPFFstruct = type { i32, i32, ptr }

@.str = private unnamed_addr constant [40 x i8] c"DUPFFexgcd called on degrees %d and %d\0A\00", align 1
@.str.1 = private unnamed_addr constant [41 x i8] c"calling DUPFFexgcd on degrees %d and %d\0A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @FFmul(i32 noundef %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %3, align 4
  ret i32 %5
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @DUPFFdeg(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %3, i32 0, i32 1
  %5 = load i32, ptr %4, align 4
  ret i32 %5
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @DUPFFnew(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  store i32 %0, ptr %2, align 4
  %4 = call ptr @malloc(i64 noundef 16) #5
  store ptr %4, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %5, i32 0, i32 2
  store ptr null, ptr %6, align 8
  %7 = load i32, ptr %2, align 4
  %8 = icmp sge i32 %7, 0
  br i1 %8, label %9, label %16

9:                                                ; preds = %1
  %10 = load i32, ptr %2, align 4
  %11 = add nsw i32 %10, 1
  %12 = sext i32 %11 to i64
  %13 = call ptr @calloc(i64 noundef %12, i64 noundef 4) #6
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %14, i32 0, i32 2
  store ptr %13, ptr %15, align 8
  br label %16

16:                                               ; preds = %9, %1
  %17 = load i32, ptr %2, align 4
  %18 = load ptr, ptr %3, align 8
  %19 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %18, i32 0, i32 0
  store i32 %17, ptr %19, align 8
  %20 = load ptr, ptr %3, align 8
  %21 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %20, i32 0, i32 1
  store i32 -1, ptr %21, align 4
  %22 = load ptr, ptr %3, align 8
  ret ptr %22
}

; Function Attrs: allocsize(0)
declare ptr @malloc(i64 noundef) #1

; Function Attrs: allocsize(0,1)
declare ptr @calloc(i64 noundef, i64 noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @DUPFFfree(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @DUPFFswap(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @DUPFFcopy(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret ptr %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @DUPFFshift_add(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  store i32 %3, ptr %8, align 4
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @DUPFFexgcd(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca ptr, align 8
  %14 = alloca ptr, align 8
  %15 = alloca ptr, align 8
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  store ptr %0, ptr %6, align 8
  store ptr %1, ptr %7, align 8
  store ptr %2, ptr %8, align 8
  store ptr %3, ptr %9, align 8
  %24 = load ptr, ptr %8, align 8
  %25 = call i32 @DUPFFdeg(ptr noundef %24)
  %26 = load ptr, ptr %9, align 8
  %27 = call i32 @DUPFFdeg(ptr noundef %26)
  %28 = call i32 (ptr, ...) @printf(ptr noundef @.str, i32 noundef %25, i32 noundef %27)
  %29 = load ptr, ptr %8, align 8
  %30 = call i32 @DUPFFdeg(ptr noundef %29)
  %31 = load ptr, ptr %9, align 8
  %32 = call i32 @DUPFFdeg(ptr noundef %31)
  %33 = icmp slt i32 %30, %32
  br i1 %33, label %34, label %40

34:                                               ; preds = %4
  %35 = load ptr, ptr %7, align 8
  %36 = load ptr, ptr %6, align 8
  %37 = load ptr, ptr %9, align 8
  %38 = load ptr, ptr %8, align 8
  %39 = call ptr @DUPFFexgcd(ptr noundef %35, ptr noundef %36, ptr noundef %37, ptr noundef %38)
  store ptr %39, ptr %5, align 8
  br label %179

40:                                               ; preds = %4
  %41 = load ptr, ptr %8, align 8
  %42 = call i32 @DUPFFdeg(ptr noundef %41)
  %43 = icmp ne i32 %42, 2
  br i1 %43, label %48, label %44

44:                                               ; preds = %40
  %45 = load ptr, ptr %9, align 8
  %46 = call i32 @DUPFFdeg(ptr noundef %45)
  %47 = icmp ne i32 %46, 1
  br i1 %47, label %48, label %49

48:                                               ; preds = %44, %40
  call void @abort() #7
  unreachable

49:                                               ; preds = %44
  %50 = load ptr, ptr %8, align 8
  %51 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %50, i32 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = getelementptr inbounds i32, ptr %52, i64 0
  %54 = load i32, ptr %53, align 4
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %56, label %58

56:                                               ; preds = %49
  %57 = load ptr, ptr %8, align 8
  store ptr %57, ptr %5, align 8
  br label %179

58:                                               ; preds = %49
  store i32 2, ptr %19, align 4
  %59 = load ptr, ptr %8, align 8
  %60 = call i32 @DUPFFdeg(ptr noundef %59)
  store i32 %60, ptr %20, align 4
  %61 = load i32, ptr %20, align 4
  %62 = icmp slt i32 %61, 0
  br i1 %62, label %63, label %64

63:                                               ; preds = %58
  store i32 0, ptr %20, align 4
  br label %64

64:                                               ; preds = %63, %58
  %65 = load ptr, ptr %9, align 8
  %66 = call i32 @DUPFFdeg(ptr noundef %65)
  store i32 %66, ptr %21, align 4
  %67 = load i32, ptr %21, align 4
  %68 = icmp slt i32 %67, 0
  br i1 %68, label %69, label %70

69:                                               ; preds = %64
  store i32 0, ptr %21, align 4
  br label %70

70:                                               ; preds = %69, %64
  %71 = load ptr, ptr %8, align 8
  %72 = call ptr @DUPFFcopy(ptr noundef %71)
  store ptr %72, ptr %10, align 8
  %73 = load ptr, ptr %9, align 8
  %74 = call ptr @DUPFFcopy(ptr noundef %73)
  store ptr %74, ptr %11, align 8
  %75 = load i32, ptr %21, align 4
  %76 = call ptr @DUPFFnew(i32 noundef %75)
  store ptr %76, ptr %12, align 8
  %77 = load ptr, ptr %12, align 8
  %78 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %77, i32 0, i32 2
  %79 = load ptr, ptr %78, align 8
  %80 = getelementptr inbounds i32, ptr %79, i64 0
  store i32 1, ptr %80, align 4
  %81 = load ptr, ptr %12, align 8
  %82 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %81, i32 0, i32 1
  store i32 0, ptr %82, align 4
  %83 = load i32, ptr %20, align 4
  %84 = call ptr @DUPFFnew(i32 noundef %83)
  store ptr %84, ptr %13, align 8
  %85 = load i32, ptr %21, align 4
  %86 = call ptr @DUPFFnew(i32 noundef %85)
  store ptr %86, ptr %14, align 8
  %87 = load i32, ptr %20, align 4
  %88 = call ptr @DUPFFnew(i32 noundef %87)
  store ptr %88, ptr %15, align 8
  %89 = load ptr, ptr %15, align 8
  %90 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %89, i32 0, i32 2
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr inbounds i32, ptr %91, i64 0
  store i32 1, ptr %92, align 4
  %93 = load ptr, ptr %15, align 8
  %94 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %93, i32 0, i32 1
  store i32 0, ptr %94, align 4
  br label %95

95:                                               ; preds = %152, %70
  %96 = load ptr, ptr %11, align 8
  %97 = call i32 @DUPFFdeg(ptr noundef %96)
  %98 = icmp sgt i32 %97, 0
  br i1 %98, label %99, label %159

99:                                               ; preds = %95
  %100 = load ptr, ptr %11, align 8
  %101 = call i32 @DUPFFdeg(ptr noundef %100)
  store i32 %101, ptr %23, align 4
  %102 = load ptr, ptr %11, align 8
  %103 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %102, i32 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = load i32, ptr %23, align 4
  %106 = sext i32 %105 to i64
  %107 = getelementptr inbounds i32, ptr %104, i64 %106
  %108 = load i32, ptr %107, align 4
  %109 = call i32 @FFmul(i32 noundef 1, i32 noundef %108)
  store i32 %109, ptr %18, align 4
  br label %110

110:                                              ; preds = %115, %99
  %111 = load ptr, ptr %10, align 8
  %112 = call i32 @DUPFFdeg(ptr noundef %111)
  %113 = load i32, ptr %23, align 4
  %114 = icmp sge i32 %112, %113
  br i1 %114, label %115, label %152

115:                                              ; preds = %110
  %116 = load ptr, ptr %10, align 8
  %117 = call i32 @DUPFFdeg(ptr noundef %116)
  store i32 %117, ptr %22, align 4
  %118 = load ptr, ptr %10, align 8
  %119 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %118, i32 0, i32 2
  %120 = load ptr, ptr %119, align 8
  %121 = load i32, ptr %22, align 4
  %122 = sext i32 %121 to i64
  %123 = getelementptr inbounds i32, ptr %120, i64 %122
  %124 = load i32, ptr %123, align 4
  store i32 %124, ptr %17, align 4
  %125 = load i32, ptr %17, align 4
  %126 = load i32, ptr %18, align 4
  %127 = call i32 @FFmul(i32 noundef %125, i32 noundef %126)
  store i32 %127, ptr %16, align 4
  %128 = load ptr, ptr %10, align 8
  %129 = load ptr, ptr %11, align 8
  %130 = load i32, ptr %22, align 4
  %131 = load i32, ptr %23, align 4
  %132 = sub nsw i32 %130, %131
  %133 = load i32, ptr %19, align 4
  %134 = load i32, ptr %16, align 4
  %135 = sub i32 %133, %134
  call void @DUPFFshift_add(ptr noundef %128, ptr noundef %129, i32 noundef %132, i32 noundef %135)
  %136 = load ptr, ptr %12, align 8
  %137 = load ptr, ptr %14, align 8
  %138 = load i32, ptr %22, align 4
  %139 = load i32, ptr %23, align 4
  %140 = sub nsw i32 %138, %139
  %141 = load i32, ptr %19, align 4
  %142 = load i32, ptr %16, align 4
  %143 = sub i32 %141, %142
  call void @DUPFFshift_add(ptr noundef %136, ptr noundef %137, i32 noundef %140, i32 noundef %143)
  %144 = load ptr, ptr %13, align 8
  %145 = load ptr, ptr %15, align 8
  %146 = load i32, ptr %22, align 4
  %147 = load i32, ptr %23, align 4
  %148 = sub nsw i32 %146, %147
  %149 = load i32, ptr %19, align 4
  %150 = load i32, ptr %16, align 4
  %151 = sub i32 %149, %150
  call void @DUPFFshift_add(ptr noundef %144, ptr noundef %145, i32 noundef %148, i32 noundef %151)
  br label %110, !llvm.loop !6

152:                                              ; preds = %110
  %153 = load ptr, ptr %10, align 8
  %154 = load ptr, ptr %11, align 8
  call void @DUPFFswap(ptr noundef %153, ptr noundef %154)
  %155 = load ptr, ptr %12, align 8
  %156 = load ptr, ptr %14, align 8
  call void @DUPFFswap(ptr noundef %155, ptr noundef %156)
  %157 = load ptr, ptr %13, align 8
  %158 = load ptr, ptr %15, align 8
  call void @DUPFFswap(ptr noundef %157, ptr noundef %158)
  br label %95, !llvm.loop !8

159:                                              ; preds = %95
  %160 = load ptr, ptr %11, align 8
  %161 = call i32 @DUPFFdeg(ptr noundef %160)
  %162 = icmp eq i32 %161, 0
  br i1 %162, label %163, label %170

163:                                              ; preds = %159
  %164 = load ptr, ptr %10, align 8
  %165 = load ptr, ptr %11, align 8
  call void @DUPFFswap(ptr noundef %164, ptr noundef %165)
  %166 = load ptr, ptr %12, align 8
  %167 = load ptr, ptr %14, align 8
  call void @DUPFFswap(ptr noundef %166, ptr noundef %167)
  %168 = load ptr, ptr %13, align 8
  %169 = load ptr, ptr %15, align 8
  call void @DUPFFswap(ptr noundef %168, ptr noundef %169)
  br label %170

170:                                              ; preds = %163, %159
  %171 = load ptr, ptr %14, align 8
  call void @DUPFFfree(ptr noundef %171)
  %172 = load ptr, ptr %15, align 8
  call void @DUPFFfree(ptr noundef %172)
  %173 = load ptr, ptr %11, align 8
  call void @DUPFFfree(ptr noundef %173)
  %174 = load ptr, ptr %12, align 8
  %175 = load ptr, ptr %6, align 8
  store ptr %174, ptr %175, align 8
  %176 = load ptr, ptr %13, align 8
  %177 = load ptr, ptr %7, align 8
  store ptr %176, ptr %177, align 8
  %178 = load ptr, ptr %10, align 8
  store ptr %178, ptr %5, align 8
  br label %179

179:                                              ; preds = %170, %56, %34
  %180 = load ptr, ptr %5, align 8
  ret ptr %180
}

declare i32 @printf(ptr noundef, ...) #3

; Function Attrs: noreturn nounwind
declare void @abort() #4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  %7 = call ptr @DUPFFnew(i32 noundef 1)
  store ptr %7, ptr %2, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %8, i32 0, i32 2
  %10 = load ptr, ptr %9, align 8
  %11 = getelementptr inbounds i32, ptr %10, i64 1
  store i32 1, ptr %11, align 4
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %12, i32 0, i32 1
  store i32 1, ptr %13, align 4
  %14 = call ptr @DUPFFnew(i32 noundef 2)
  store ptr %14, ptr %3, align 8
  %15 = load ptr, ptr %3, align 8
  %16 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %15, i32 0, i32 2
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr inbounds i32, ptr %17, i64 2
  store i32 1, ptr %18, align 4
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.DUPFFstruct, ptr %19, i32 0, i32 1
  store i32 2, ptr %20, align 4
  %21 = load ptr, ptr %2, align 8
  %22 = call i32 @DUPFFdeg(ptr noundef %21)
  %23 = load ptr, ptr %3, align 8
  %24 = call i32 @DUPFFdeg(ptr noundef %23)
  %25 = call i32 (ptr, ...) @printf(ptr noundef @.str.1, i32 noundef %22, i32 noundef %24)
  %26 = load ptr, ptr %2, align 8
  %27 = load ptr, ptr %3, align 8
  %28 = call ptr @DUPFFexgcd(ptr noundef %4, ptr noundef %5, ptr noundef %26, ptr noundef %27)
  store ptr %28, ptr %6, align 8
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { allocsize(0,1) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { allocsize(0) }
attributes #6 = { allocsize(0,1) }
attributes #7 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
