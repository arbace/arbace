; ModuleID = '20001130-2.c'
source_filename = "20001130-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@which_alternative = internal global i32 3, align 4
@.str = private unnamed_addr constant [10 x i8] c"mov\09%1,%0\00", align 1
@.str.1 = private unnamed_addr constant [9 x i8] c"ld\09%1,%0\00", align 1
@.str.2 = private unnamed_addr constant [9 x i8] c"st\09%1,%0\00", align 1
@.str.3 = private unnamed_addr constant [4 x i8] c"foo\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  %3 = call ptr @output_25()
  store ptr %3, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds i8, ptr %4, i64 0
  %6 = load i8, ptr %5, align 1
  %7 = sext i8 %6 to i32
  %8 = icmp ne i32 %7, 115
  br i1 %8, label %9, label %10

9:                                                ; preds = %0
  call void @abort() #3
  unreachable

10:                                               ; preds = %0
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @output_25() #0 {
  %1 = alloca ptr, align 8
  %2 = load i32, ptr @which_alternative, align 4
  switch i32 %2, label %8 [
    i32 0, label %3
    i32 1, label %4
    i32 2, label %6
    i32 3, label %7
  ]

3:                                                ; preds = %0
  store ptr @.str, ptr %1, align 8
  br label %8

4:                                                ; preds = %0
  %5 = call ptr @i960_output_ldconst()
  store ptr %5, ptr %1, align 8
  br label %8

6:                                                ; preds = %0
  store ptr @.str.1, ptr %1, align 8
  br label %8

7:                                                ; preds = %0
  store ptr @.str.2, ptr %1, align 8
  br label %8

8:                                                ; preds = %3, %4, %6, %7, %0
  %9 = load ptr, ptr %1, align 8
  ret ptr %9
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @i960_output_ldconst() #0 {
  ret ptr @.str.3
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
