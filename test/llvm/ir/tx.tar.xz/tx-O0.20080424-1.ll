; ModuleID = '20080424-1.c'
source_filename = "20080424-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@bar.i = internal global i32 0, align 4
@g = dso_local global [48 x [3 x [3 x i32]]] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @bar(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i32, ptr @bar.i, align 4
  %7 = add nsw i32 %6, 8
  %8 = sext i32 %7 to i64
  %9 = getelementptr inbounds [48 x [3 x [3 x i32]]], ptr @g, i64 0, i64 %8
  %10 = getelementptr inbounds [3 x [3 x i32]], ptr %9, i64 0, i64 0
  %11 = icmp ne ptr %5, %10
  br i1 %11, label %20, label %12

12:                                               ; preds = %2
  %13 = load ptr, ptr %4, align 8
  %14 = load i32, ptr @bar.i, align 4
  %15 = add nsw i32 %14, 1
  store i32 %15, ptr @bar.i, align 4
  %16 = sext i32 %14 to i64
  %17 = getelementptr inbounds [48 x [3 x [3 x i32]]], ptr @g, i64 0, i64 %16
  %18 = getelementptr inbounds [3 x [3 x i32]], ptr %17, i64 0, i64 0
  %19 = icmp ne ptr %13, %18
  br i1 %19, label %20, label %21

20:                                               ; preds = %12, %2
  call void @abort() #2
  unreachable

21:                                               ; preds = %12
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca ptr, align 8
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 0, ptr %4, align 4
  store ptr @g, ptr %1, align 8
  store i32 0, ptr %2, align 4
  br label %5

5:                                                ; preds = %8, %0
  %6 = load i32, ptr %2, align 4
  %7 = icmp slt i32 %6, 8
  br i1 %7, label %8, label %22

8:                                                ; preds = %5
  %9 = load i32, ptr %2, align 4
  %10 = add nsw i32 %9, 8
  store i32 %10, ptr %3, align 4
  %11 = load ptr, ptr %1, align 8
  %12 = load i32, ptr %3, align 4
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds [3 x [3 x i32]], ptr %11, i64 %13
  %15 = load ptr, ptr %1, align 8
  %16 = load i32, ptr %3, align 4
  %17 = sub nsw i32 %16, 8
  %18 = sext i32 %17 to i64
  %19 = getelementptr inbounds [3 x [3 x i32]], ptr %15, i64 %18
  call void @bar(ptr noundef %14, ptr noundef %19)
  %20 = load i32, ptr %2, align 4
  %21 = add nsw i32 %20, 1
  store i32 %21, ptr %2, align 4
  br label %5, !llvm.loop !6

22:                                               ; preds = %5
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
