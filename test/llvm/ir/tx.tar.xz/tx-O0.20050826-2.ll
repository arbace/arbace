; ModuleID = '20050826-2.c'
source_filename = "20050826-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.rtattr = type { i16, i16 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @inet_check_attr(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i32 1, ptr %6, align 4
  br label %8

8:                                                ; preds = %44, %2
  %9 = load i32, ptr %6, align 4
  %10 = icmp sle i32 %9, 14
  br i1 %10, label %11, label %47

11:                                               ; preds = %8
  %12 = load ptr, ptr %5, align 8
  %13 = load i32, ptr %6, align 4
  %14 = sub nsw i32 %13, 1
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds ptr, ptr %12, i64 %15
  %17 = load ptr, ptr %16, align 8
  store ptr %17, ptr %7, align 8
  %18 = load ptr, ptr %7, align 8
  %19 = icmp ne ptr %18, null
  br i1 %19, label %20, label %43

20:                                               ; preds = %11
  %21 = load ptr, ptr %7, align 8
  %22 = getelementptr inbounds nuw %struct.rtattr, ptr %21, i32 0, i32 0
  %23 = load i16, ptr %22, align 2
  %24 = zext i16 %23 to i64
  %25 = sub i64 %24, 4
  %26 = icmp ult i64 %25, 4
  br i1 %26, label %27, label %28

27:                                               ; preds = %20
  store i32 -22, ptr %3, align 4
  br label %48

28:                                               ; preds = %20
  %29 = load i32, ptr %6, align 4
  %30 = icmp ne i32 %29, 9
  br i1 %30, label %31, label %42

31:                                               ; preds = %28
  %32 = load i32, ptr %6, align 4
  %33 = icmp ne i32 %32, 8
  br i1 %33, label %34, label %42

34:                                               ; preds = %31
  %35 = load ptr, ptr %7, align 8
  %36 = getelementptr inbounds %struct.rtattr, ptr %35, i64 1
  %37 = load ptr, ptr %5, align 8
  %38 = load i32, ptr %6, align 4
  %39 = sub nsw i32 %38, 1
  %40 = sext i32 %39 to i64
  %41 = getelementptr inbounds ptr, ptr %37, i64 %40
  store ptr %36, ptr %41, align 8
  br label %42

42:                                               ; preds = %34, %31, %28
  br label %43

43:                                               ; preds = %42, %11
  br label %44

44:                                               ; preds = %43
  %45 = load i32, ptr %6, align 4
  %46 = add nsw i32 %45, 1
  store i32 %46, ptr %6, align 4
  br label %8, !llvm.loop !6

47:                                               ; preds = %8
  store i32 0, ptr %3, align 4
  br label %48

48:                                               ; preds = %47, %27
  %49 = load i32, ptr %3, align 4
  ret i32 %49
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [2 x %struct.rtattr], align 2
  %3 = alloca [14 x ptr], align 16
  %4 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %5 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  %6 = getelementptr inbounds nuw %struct.rtattr, ptr %5, i32 0, i32 0
  store i16 12, ptr %6, align 2
  %7 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  %8 = getelementptr inbounds nuw %struct.rtattr, ptr %7, i32 0, i32 1
  store i16 0, ptr %8, align 2
  %9 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 1
  %10 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %9, ptr align 2 %10, i64 4, i1 false)
  store i32 0, ptr %4, align 4
  br label %11

11:                                               ; preds = %19, %0
  %12 = load i32, ptr %4, align 4
  %13 = icmp slt i32 %12, 14
  br i1 %13, label %14, label %22

14:                                               ; preds = %11
  %15 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  %16 = load i32, ptr %4, align 4
  %17 = sext i32 %16 to i64
  %18 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %17
  store ptr %15, ptr %18, align 8
  br label %19

19:                                               ; preds = %14
  %20 = load i32, ptr %4, align 4
  %21 = add nsw i32 %20, 1
  store i32 %21, ptr %4, align 4
  br label %11, !llvm.loop !8

22:                                               ; preds = %11
  %23 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 0
  %24 = call i32 @inet_check_attr(ptr noundef null, ptr noundef %23)
  %25 = icmp ne i32 %24, 0
  br i1 %25, label %26, label %27

26:                                               ; preds = %22
  call void @abort() #3
  unreachable

27:                                               ; preds = %22
  store i32 0, ptr %4, align 4
  br label %28

28:                                               ; preds = %49, %27
  %29 = load i32, ptr %4, align 4
  %30 = icmp slt i32 %29, 14
  br i1 %30, label %31, label %52

31:                                               ; preds = %28
  %32 = load i32, ptr %4, align 4
  %33 = sext i32 %32 to i64
  %34 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %33
  %35 = load ptr, ptr %34, align 8
  %36 = load i32, ptr %4, align 4
  %37 = icmp ne i32 %36, 7
  br i1 %37, label %38, label %41

38:                                               ; preds = %31
  %39 = load i32, ptr %4, align 4
  %40 = icmp ne i32 %39, 8
  br label %41

41:                                               ; preds = %38, %31
  %42 = phi i1 [ false, %31 ], [ %40, %38 ]
  %43 = zext i1 %42 to i32
  %44 = sext i32 %43 to i64
  %45 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 %44
  %46 = icmp ne ptr %35, %45
  br i1 %46, label %47, label %48

47:                                               ; preds = %41
  call void @abort() #3
  unreachable

48:                                               ; preds = %41
  br label %49

49:                                               ; preds = %48
  %50 = load i32, ptr %4, align 4
  %51 = add nsw i32 %50, 1
  store i32 %51, ptr %4, align 4
  br label %28, !llvm.loop !9

52:                                               ; preds = %28
  store i32 0, ptr %4, align 4
  br label %53

53:                                               ; preds = %61, %52
  %54 = load i32, ptr %4, align 4
  %55 = icmp slt i32 %54, 14
  br i1 %55, label %56, label %64

56:                                               ; preds = %53
  %57 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  %58 = load i32, ptr %4, align 4
  %59 = sext i32 %58 to i64
  %60 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %59
  store ptr %57, ptr %60, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i32, ptr %4, align 4
  %63 = add nsw i32 %62, 1
  store i32 %63, ptr %4, align 4
  br label %53, !llvm.loop !10

64:                                               ; preds = %53
  %65 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 1
  store ptr null, ptr %65, align 8
  %66 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 1
  %67 = getelementptr inbounds nuw %struct.rtattr, ptr %66, i32 0, i32 0
  %68 = load i16, ptr %67, align 2
  %69 = zext i16 %68 to i32
  %70 = sub nsw i32 %69, 8
  %71 = trunc i32 %70 to i16
  store i16 %71, ptr %67, align 2
  %72 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 1
  %73 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 5
  store ptr %72, ptr %73, align 8
  %74 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 0
  %75 = call i32 @inet_check_attr(ptr noundef null, ptr noundef %74)
  %76 = icmp ne i32 %75, -22
  br i1 %76, label %77, label %78

77:                                               ; preds = %64
  call void @abort() #3
  unreachable

78:                                               ; preds = %64
  store i32 0, ptr %4, align 4
  br label %79

79:                                               ; preds = %120, %78
  %80 = load i32, ptr %4, align 4
  %81 = icmp slt i32 %80, 14
  br i1 %81, label %82, label %123

82:                                               ; preds = %79
  %83 = load i32, ptr %4, align 4
  %84 = icmp eq i32 %83, 1
  br i1 %84, label %85, label %92

85:                                               ; preds = %82
  %86 = load i32, ptr %4, align 4
  %87 = sext i32 %86 to i64
  %88 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %87
  %89 = load ptr, ptr %88, align 8
  %90 = icmp ne ptr %89, null
  br i1 %90, label %91, label %92

91:                                               ; preds = %85
  call void @abort() #3
  unreachable

92:                                               ; preds = %85, %82
  %93 = load i32, ptr %4, align 4
  %94 = icmp ne i32 %93, 1
  br i1 %94, label %95, label %106

95:                                               ; preds = %92
  %96 = load i32, ptr %4, align 4
  %97 = icmp sle i32 %96, 5
  br i1 %97, label %98, label %106

98:                                               ; preds = %95
  %99 = load i32, ptr %4, align 4
  %100 = sext i32 %99 to i64
  %101 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %100
  %102 = load ptr, ptr %101, align 8
  %103 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 1
  %104 = icmp ne ptr %102, %103
  br i1 %104, label %105, label %106

105:                                              ; preds = %98
  call void @abort() #3
  unreachable

106:                                              ; preds = %98, %95, %92
  %107 = load i32, ptr %4, align 4
  %108 = icmp sgt i32 %107, 5
  br i1 %108, label %109, label %117

109:                                              ; preds = %106
  %110 = load i32, ptr %4, align 4
  %111 = sext i32 %110 to i64
  %112 = getelementptr inbounds [14 x ptr], ptr %3, i64 0, i64 %111
  %113 = load ptr, ptr %112, align 8
  %114 = getelementptr inbounds [2 x %struct.rtattr], ptr %2, i64 0, i64 0
  %115 = icmp ne ptr %113, %114
  br i1 %115, label %116, label %117

116:                                              ; preds = %109
  call void @abort() #3
  unreachable

117:                                              ; preds = %109, %106
  br label %118

118:                                              ; preds = %117
  br label %119

119:                                              ; preds = %118
  br label %120

120:                                              ; preds = %119
  %121 = load i32, ptr %4, align 4
  %122 = add nsw i32 %121, 1
  store i32 %122, ptr %4, align 4
  br label %79, !llvm.loop !11

123:                                              ; preds = %79
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
