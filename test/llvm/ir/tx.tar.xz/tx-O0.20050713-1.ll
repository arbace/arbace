; ModuleID = '20050713-1.c'
source_filename = "20050713-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i32, i32, i32 }

@__const.main.a = private unnamed_addr constant %struct.S { i32 3, i32 4, i32 5 }, align 4
@__const.main.b = private unnamed_addr constant %struct.S { i32 6, i32 7, i32 8 }, align 4
@__const.main.c = private unnamed_addr constant %struct.S { i32 9, i32 10, i32 11 }, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo2(i64 %0, i32 %1, i64 %2, i32 %3) #0 {
  %5 = alloca %struct.S, align 4
  %6 = alloca { i64, i32 }, align 4
  %7 = alloca %struct.S, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 0
  store i64 %0, ptr %9, align 4
  %10 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 1
  store i32 %1, ptr %10, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %6, i64 12, i1 false)
  %11 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  store i64 %2, ptr %11, align 4
  %12 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  store i32 %3, ptr %12, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %8, i64 12, i1 false)
  %13 = getelementptr inbounds nuw %struct.S, ptr %5, i32 0, i32 0
  %14 = load i32, ptr %13, align 4
  %15 = icmp ne i32 %14, 3
  br i1 %15, label %24, label %16

16:                                               ; preds = %4
  %17 = getelementptr inbounds nuw %struct.S, ptr %5, i32 0, i32 1
  %18 = load i32, ptr %17, align 4
  %19 = icmp ne i32 %18, 4
  br i1 %19, label %24, label %20

20:                                               ; preds = %16
  %21 = getelementptr inbounds nuw %struct.S, ptr %5, i32 0, i32 2
  %22 = load i32, ptr %21, align 4
  %23 = icmp ne i32 %22, 5
  br i1 %23, label %24, label %25

24:                                               ; preds = %20, %16, %4
  call void @abort() #3
  unreachable

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw %struct.S, ptr %7, i32 0, i32 0
  %27 = load i32, ptr %26, align 4
  %28 = icmp ne i32 %27, 6
  br i1 %28, label %37, label %29

29:                                               ; preds = %25
  %30 = getelementptr inbounds nuw %struct.S, ptr %7, i32 0, i32 1
  %31 = load i32, ptr %30, align 4
  %32 = icmp ne i32 %31, 7
  br i1 %32, label %37, label %33

33:                                               ; preds = %29
  %34 = getelementptr inbounds nuw %struct.S, ptr %7, i32 0, i32 2
  %35 = load i32, ptr %34, align 4
  %36 = icmp ne i32 %35, 8
  br i1 %36, label %37, label %38

37:                                               ; preds = %33, %29, %25
  call void @abort() #3
  unreachable

38:                                               ; preds = %33
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo3(i64 %0, i32 %1, i64 %2, i32 %3, i64 %4, i32 %5) #0 {
  %7 = alloca %struct.S, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = alloca %struct.S, align 4
  %10 = alloca { i64, i32 }, align 4
  %11 = alloca %struct.S, align 4
  %12 = alloca { i64, i32 }, align 4
  %13 = alloca { i64, i32 }, align 4
  %14 = alloca { i64, i32 }, align 4
  %15 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  store i64 %0, ptr %15, align 4
  %16 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  store i32 %1, ptr %16, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %8, i64 12, i1 false)
  %17 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 0
  store i64 %2, ptr %17, align 4
  %18 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 1
  store i32 %3, ptr %18, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %10, i64 12, i1 false)
  %19 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 0
  store i64 %4, ptr %19, align 4
  %20 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 1
  store i32 %5, ptr %20, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %12, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 %7, i64 12, i1 false)
  %21 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 0
  %22 = load i64, ptr %21, align 4
  %23 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 1
  %24 = load i32, ptr %23, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %9, i64 12, i1 false)
  %25 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 0
  %26 = load i64, ptr %25, align 4
  %27 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 1
  %28 = load i32, ptr %27, align 4
  %29 = call i32 @foo2(i64 %22, i32 %24, i64 %26, i32 %28)
  %30 = getelementptr inbounds nuw %struct.S, ptr %11, i32 0, i32 0
  %31 = load i32, ptr %30, align 4
  %32 = icmp ne i32 %31, 9
  br i1 %32, label %41, label %33

33:                                               ; preds = %6
  %34 = getelementptr inbounds nuw %struct.S, ptr %11, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = icmp ne i32 %35, 10
  br i1 %36, label %41, label %37

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw %struct.S, ptr %11, i32 0, i32 2
  %39 = load i32, ptr %38, align 4
  %40 = icmp ne i32 %39, 11
  br i1 %40, label %41, label %42

41:                                               ; preds = %37, %33, %6
  call void @abort() #3
  unreachable

42:                                               ; preds = %37
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @bar2(i64 %0, i32 %1, i64 %2, i32 %3) #0 {
  %5 = alloca %struct.S, align 4
  %6 = alloca { i64, i32 }, align 4
  %7 = alloca %struct.S, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = alloca { i64, i32 }, align 4
  %10 = alloca { i64, i32 }, align 4
  %11 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 0
  store i64 %0, ptr %11, align 4
  %12 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 1
  store i32 %1, ptr %12, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %6, i64 12, i1 false)
  %13 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  store i64 %2, ptr %13, align 4
  %14 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  store i32 %3, ptr %14, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %8, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %7, i64 12, i1 false)
  %15 = getelementptr inbounds nuw { i64, i32 }, ptr %9, i32 0, i32 0
  %16 = load i64, ptr %15, align 4
  %17 = getelementptr inbounds nuw { i64, i32 }, ptr %9, i32 0, i32 1
  %18 = load i32, ptr %17, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %10, ptr align 4 %5, i64 12, i1 false)
  %19 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 0
  %20 = load i64, ptr %19, align 4
  %21 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 1
  %22 = load i32, ptr %21, align 4
  %23 = call i32 @foo2(i64 %16, i32 %18, i64 %20, i32 %22)
  ret i32 %23
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @bar3(i64 %0, i32 %1, i64 %2, i32 %3, i64 %4, i32 %5) #0 {
  %7 = alloca %struct.S, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = alloca %struct.S, align 4
  %10 = alloca { i64, i32 }, align 4
  %11 = alloca %struct.S, align 4
  %12 = alloca { i64, i32 }, align 4
  %13 = alloca { i64, i32 }, align 4
  %14 = alloca { i64, i32 }, align 4
  %15 = alloca { i64, i32 }, align 4
  %16 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  store i64 %0, ptr %16, align 4
  %17 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  store i32 %1, ptr %17, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %8, i64 12, i1 false)
  %18 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 0
  store i64 %2, ptr %18, align 4
  %19 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 1
  store i32 %3, ptr %19, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %10, i64 12, i1 false)
  %20 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 0
  store i64 %4, ptr %20, align 4
  %21 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 1
  store i32 %5, ptr %21, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %12, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 %9, i64 12, i1 false)
  %22 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 0
  %23 = load i64, ptr %22, align 4
  %24 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %7, i64 12, i1 false)
  %26 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 0
  %27 = load i64, ptr %26, align 4
  %28 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 1
  %29 = load i32, ptr %28, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %15, ptr align 4 %11, i64 12, i1 false)
  %30 = getelementptr inbounds nuw { i64, i32 }, ptr %15, i32 0, i32 0
  %31 = load i64, ptr %30, align 4
  %32 = getelementptr inbounds nuw { i64, i32 }, ptr %15, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = call i32 @foo3(i64 %23, i32 %25, i64 %27, i32 %29, i64 %31, i32 %33)
  ret i32 %34
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @baz3(i64 %0, i32 %1, i64 %2, i32 %3, i64 %4, i32 %5) #0 {
  %7 = alloca %struct.S, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = alloca %struct.S, align 4
  %10 = alloca { i64, i32 }, align 4
  %11 = alloca %struct.S, align 4
  %12 = alloca { i64, i32 }, align 4
  %13 = alloca { i64, i32 }, align 4
  %14 = alloca { i64, i32 }, align 4
  %15 = alloca { i64, i32 }, align 4
  %16 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  store i64 %0, ptr %16, align 4
  %17 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  store i32 %1, ptr %17, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %8, i64 12, i1 false)
  %18 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 0
  store i64 %2, ptr %18, align 4
  %19 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 1
  store i32 %3, ptr %19, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %10, i64 12, i1 false)
  %20 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 0
  store i64 %4, ptr %20, align 4
  %21 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 1
  store i32 %5, ptr %21, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %12, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 %9, i64 12, i1 false)
  %22 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 0
  %23 = load i64, ptr %22, align 4
  %24 = getelementptr inbounds nuw { i64, i32 }, ptr %13, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %11, i64 12, i1 false)
  %26 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 0
  %27 = load i64, ptr %26, align 4
  %28 = getelementptr inbounds nuw { i64, i32 }, ptr %14, i32 0, i32 1
  %29 = load i32, ptr %28, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %15, ptr align 4 %7, i64 12, i1 false)
  %30 = getelementptr inbounds nuw { i64, i32 }, ptr %15, i32 0, i32 0
  %31 = load i64, ptr %30, align 4
  %32 = getelementptr inbounds nuw { i64, i32 }, ptr %15, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = call i32 @foo3(i64 %23, i32 %25, i64 %27, i32 %29, i64 %31, i32 %33)
  ret i32 %34
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.S, align 4
  %3 = alloca %struct.S, align 4
  %4 = alloca %struct.S, align 4
  %5 = alloca { i64, i32 }, align 4
  %6 = alloca { i64, i32 }, align 4
  %7 = alloca { i64, i32 }, align 4
  %8 = alloca { i64, i32 }, align 4
  %9 = alloca { i64, i32 }, align 4
  %10 = alloca { i64, i32 }, align 4
  %11 = alloca { i64, i32 }, align 4
  %12 = alloca { i64, i32 }, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 @__const.main.a, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %3, ptr align 4 @__const.main.b, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 4 @__const.main.c, i64 12, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %3, i64 12, i1 false)
  %13 = getelementptr inbounds nuw { i64, i32 }, ptr %5, i32 0, i32 0
  %14 = load i64, ptr %13, align 4
  %15 = getelementptr inbounds nuw { i64, i32 }, ptr %5, i32 0, i32 1
  %16 = load i32, ptr %15, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 %2, i64 12, i1 false)
  %17 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 0
  %18 = load i64, ptr %17, align 4
  %19 = getelementptr inbounds nuw { i64, i32 }, ptr %6, i32 0, i32 1
  %20 = load i32, ptr %19, align 4
  %21 = call i32 @bar2(i64 %14, i32 %16, i64 %18, i32 %20)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %7, ptr align 4 %3, i64 12, i1 false)
  %22 = getelementptr inbounds nuw { i64, i32 }, ptr %7, i32 0, i32 0
  %23 = load i64, ptr %22, align 4
  %24 = getelementptr inbounds nuw { i64, i32 }, ptr %7, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %8, ptr align 4 %2, i64 12, i1 false)
  %26 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 0
  %27 = load i64, ptr %26, align 4
  %28 = getelementptr inbounds nuw { i64, i32 }, ptr %8, i32 0, i32 1
  %29 = load i32, ptr %28, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %4, i64 12, i1 false)
  %30 = getelementptr inbounds nuw { i64, i32 }, ptr %9, i32 0, i32 0
  %31 = load i64, ptr %30, align 4
  %32 = getelementptr inbounds nuw { i64, i32 }, ptr %9, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = call i32 @bar3(i64 %23, i32 %25, i64 %27, i32 %29, i64 %31, i32 %33)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %10, ptr align 4 %4, i64 12, i1 false)
  %35 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 0
  %36 = load i64, ptr %35, align 4
  %37 = getelementptr inbounds nuw { i64, i32 }, ptr %10, i32 0, i32 1
  %38 = load i32, ptr %37, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %2, i64 12, i1 false)
  %39 = getelementptr inbounds nuw { i64, i32 }, ptr %11, i32 0, i32 0
  %40 = load i64, ptr %39, align 4
  %41 = getelementptr inbounds nuw { i64, i32 }, ptr %11, i32 0, i32 1
  %42 = load i32, ptr %41, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %12, ptr align 4 %3, i64 12, i1 false)
  %43 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 0
  %44 = load i64, ptr %43, align 4
  %45 = getelementptr inbounds nuw { i64, i32 }, ptr %12, i32 0, i32 1
  %46 = load i32, ptr %45, align 4
  %47 = call i32 @baz3(i64 %36, i32 %38, i64 %40, i32 %42, i64 %44, i32 %46)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
