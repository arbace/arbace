; ModuleID = '20001009-2.c'
source_filename = "20001009-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@b = dso_local global i32 1, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 255, ptr %1, align 4
  br label %3

3:                                                ; preds = %11, %0
  %4 = load i32, ptr @b, align 4
  %5 = icmp ne i32 %4, 0
  br i1 %5, label %6, label %14

6:                                                ; preds = %3
  store i32 1, ptr %2, align 4
  %7 = load i32, ptr %2, align 4
  call void asm sideeffect "", "r,~{dirflag},~{fpsr},~{flags}"(i32 %7) #2, !srcloc !6
  %8 = load i32, ptr %1, align 4
  %9 = trunc i32 %8 to i8
  %10 = sext i8 %9 to i32
  store i32 %10, ptr %2, align 4
  br label %11

11:                                               ; preds = %6
  %12 = load i32, ptr @b, align 4
  %13 = add nsw i32 %12, -1
  store i32 %13, ptr @b, align 4
  br label %3, !llvm.loop !7

14:                                               ; preds = %3
  %15 = load i32, ptr %2, align 4
  %16 = icmp ne i32 %15, -1
  br i1 %16, label %17, label %18

17:                                               ; preds = %14
  call void @abort() #3
  unreachable

18:                                               ; preds = %14
  %19 = load i32, ptr %2, align 4
  ret i32 %19
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @foo()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{i64 87}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
