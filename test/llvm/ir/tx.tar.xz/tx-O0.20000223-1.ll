; ModuleID = '20000223-1.c'
source_filename = "20000223-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [5 x i8] c"void\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"char\00", align 1
@.str.2 = private unnamed_addr constant [13 x i8] c"signed short\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"unsigned short\00", align 1
@.str.4 = private unnamed_addr constant [11 x i8] c"signed int\00", align 1
@.str.5 = private unnamed_addr constant [13 x i8] c"unsigned int\00", align 1
@.str.6 = private unnamed_addr constant [12 x i8] c"signed long\00", align 1
@.str.7 = private unnamed_addr constant [14 x i8] c"unsigned long\00", align 1
@.str.8 = private unnamed_addr constant [17 x i8] c"signed long long\00", align 1
@.str.9 = private unnamed_addr constant [19 x i8] c"unsigned long long\00", align 1
@.str.10 = private unnamed_addr constant [6 x i8] c"float\00", align 1
@.str.11 = private unnamed_addr constant [7 x i8] c"double\00", align 1
@.str.12 = private unnamed_addr constant [12 x i8] c"long double\00", align 1
@.str.13 = private unnamed_addr constant [7 x i8] c"void *\00", align 1
@.str.14 = private unnamed_addr constant [11 x i8] c"void (*)()\00", align 1
@.str.15 = private unnamed_addr constant [9 x i8] c"struct A\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @check(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %4, align 4
  %6 = load i32, ptr %4, align 4
  %7 = sub nsw i32 0, %6
  %8 = and i32 %5, %7
  %9 = load i32, ptr %4, align 4
  %10 = icmp ne i32 %8, %9
  br i1 %10, label %11, label %12

11:                                               ; preds = %2
  call void @abort() #2
  unreachable

12:                                               ; preds = %2
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @check(ptr noundef @.str, i32 noundef 1)
  call void @check(ptr noundef @.str.1, i32 noundef 1)
  call void @check(ptr noundef @.str.2, i32 noundef 2)
  call void @check(ptr noundef @.str.3, i32 noundef 2)
  call void @check(ptr noundef @.str.4, i32 noundef 4)
  call void @check(ptr noundef @.str.5, i32 noundef 4)
  call void @check(ptr noundef @.str.6, i32 noundef 8)
  call void @check(ptr noundef @.str.7, i32 noundef 8)
  call void @check(ptr noundef @.str.8, i32 noundef 8)
  call void @check(ptr noundef @.str.9, i32 noundef 8)
  call void @check(ptr noundef @.str.10, i32 noundef 4)
  call void @check(ptr noundef @.str.11, i32 noundef 8)
  call void @check(ptr noundef @.str.12, i32 noundef 16)
  call void @check(ptr noundef @.str.13, i32 noundef 8)
  call void @check(ptr noundef @.str.14, i32 noundef 8)
  call void @check(ptr noundef @.str.15, i32 noundef 16)
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
