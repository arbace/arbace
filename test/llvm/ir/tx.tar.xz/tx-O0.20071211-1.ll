; ModuleID = '20071211-1.c'
source_filename = "20071211-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.s = type { i64 }

@sv = dso_local global %struct.s zeroinitializer, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %3 = load i64, ptr @sv, align 8
  %4 = and i64 %3, 1099511627775
  %5 = or i64 %4, -1099511627776
  store i64 %5, ptr @sv, align 8
  call void asm sideeffect "", "~{memory},~{dirflag},~{fpsr},~{flags}"() #2, !srcloc !6
  %6 = load i64, ptr @sv, align 8
  %7 = lshr i64 %6, 40
  %8 = trunc i64 %7 to i32
  %9 = add i32 %8, 1
  %10 = zext i32 %9 to i64
  %11 = load i64, ptr @sv, align 8
  %12 = and i64 %10, 16777215
  %13 = shl i64 %12, 40
  %14 = and i64 %11, 1099511627775
  %15 = or i64 %14, %13
  store i64 %15, ptr @sv, align 8
  %16 = trunc i64 %12 to i32
  %17 = load i64, ptr @sv, align 8
  %18 = lshr i64 %17, 40
  %19 = trunc i64 %18 to i32
  store i32 %19, ptr %2, align 4
  %20 = load i32, ptr %2, align 4
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %22, label %23

22:                                               ; preds = %0
  call void @abort() #3
  unreachable

23:                                               ; preds = %0
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{i64 258}
