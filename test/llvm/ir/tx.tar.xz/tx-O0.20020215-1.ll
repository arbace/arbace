; ModuleID = '20020215-1.c'
source_filename = "20020215-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.s = type { i16, i64, i16 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr dead_on_unwind noalias writable sret(%struct.s) align 8 %0, ptr noundef byval(%struct.s) align 8 %1) #0 {
  %3 = getelementptr inbounds nuw %struct.s, ptr %1, i32 0, i32 1
  %4 = load i64, ptr %3, align 8
  %5 = add nsw i64 %4, 1
  store i64 %5, ptr %3, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %1, i64 24, i1 false)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.s, align 8
  %3 = alloca %struct.s, align 8
  store i32 0, ptr %1, align 4
  %4 = getelementptr inbounds nuw %struct.s, ptr %3, i32 0, i32 0
  store i16 1000, ptr %4, align 8
  %5 = getelementptr i8, ptr %3, i64 2
  call void @llvm.memset.p0.i64(ptr align 2 %5, i8 0, i64 6, i1 false)
  %6 = getelementptr inbounds nuw %struct.s, ptr %3, i32 0, i32 1
  store i64 2000, ptr %6, align 8
  %7 = getelementptr inbounds nuw %struct.s, ptr %3, i32 0, i32 2
  store i16 3000, ptr %7, align 8
  %8 = getelementptr i8, ptr %3, i64 18
  call void @llvm.memset.p0.i64(ptr align 2 %8, i8 0, i64 6, i1 false)
  call void @foo(ptr dead_on_unwind writable sret(%struct.s) align 8 %2, ptr noundef byval(%struct.s) align 8 %3)
  %9 = getelementptr inbounds nuw %struct.s, ptr %2, i32 0, i32 0
  %10 = load i16, ptr %9, align 8
  %11 = sext i16 %10 to i32
  %12 = icmp ne i32 %11, 1000
  br i1 %12, label %22, label %13

13:                                               ; preds = %0
  %14 = getelementptr inbounds nuw %struct.s, ptr %2, i32 0, i32 1
  %15 = load i64, ptr %14, align 8
  %16 = icmp ne i64 %15, 2001
  br i1 %16, label %22, label %17

17:                                               ; preds = %13
  %18 = getelementptr inbounds nuw %struct.s, ptr %2, i32 0, i32 2
  %19 = load i16, ptr %18, align 8
  %20 = sext i16 %19 to i32
  %21 = icmp ne i32 %20, 3000
  br i1 %21, label %22, label %23

22:                                               ; preds = %17, %13, %0
  call void @abort() #5
  unreachable

23:                                               ; preds = %17
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: noreturn
declare void @exit(i32 noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
