; ModuleID = '20041201-1.c'
source_filename = "20041201-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.Scc2 = type { { i8, i8 }, { i8, i8 } }

@s = dso_local global %struct.Scc2 { { i8, i8 } { i8 1, i8 2 }, { i8, i8 } { i8 3, i8 4 } }, align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @checkScc2(i32 %0) #0 {
  %2 = alloca %struct.Scc2, align 1
  store i32 %0, ptr %2, align 1
  %3 = getelementptr inbounds nuw %struct.Scc2, ptr %2, i32 0, i32 0
  %4 = getelementptr inbounds nuw { i8, i8 }, ptr %3, i32 0, i32 0
  %5 = load i8, ptr %4, align 1
  %6 = getelementptr inbounds nuw { i8, i8 }, ptr %3, i32 0, i32 1
  %7 = load i8, ptr %6, align 1
  %8 = sext i8 %5 to i32
  %9 = sext i8 %7 to i32
  %10 = icmp ne i32 %8, 1
  %11 = icmp ne i32 %9, 2
  %12 = or i1 %10, %11
  br i1 %12, label %24, label %13

13:                                               ; preds = %1
  %14 = getelementptr inbounds nuw %struct.Scc2, ptr %2, i32 0, i32 1
  %15 = getelementptr inbounds nuw { i8, i8 }, ptr %14, i32 0, i32 0
  %16 = load i8, ptr %15, align 1
  %17 = getelementptr inbounds nuw { i8, i8 }, ptr %14, i32 0, i32 1
  %18 = load i8, ptr %17, align 1
  %19 = sext i8 %16 to i32
  %20 = sext i8 %18 to i32
  %21 = icmp ne i32 %19, 3
  %22 = icmp ne i32 %20, 4
  %23 = or i1 %21, %22
  br label %24

24:                                               ; preds = %13, %1
  %25 = phi i1 [ true, %1 ], [ %23, %13 ]
  %26 = zext i1 %25 to i32
  ret i32 %26
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i32, ptr @s, align 1
  %3 = call i32 @checkScc2(i32 %2)
  ret i32 %3
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
