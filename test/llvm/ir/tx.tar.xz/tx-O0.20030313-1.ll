; ModuleID = '20030313-1.c'
source_filename = "20030313-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.A = type { i64, i64, i64, i64 }

@x = dso_local global %struct.A { i64 13, i64 14, i64 15, i64 16 }, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  %5 = load i32, ptr %4, align 4
  %6 = icmp ne i32 %5, 12
  br i1 %6, label %7, label %8

7:                                                ; preds = %2
  call void @abort() #3
  unreachable

8:                                                ; preds = %2
  %9 = load ptr, ptr %3, align 8
  %10 = getelementptr inbounds i64, ptr %9, i64 0
  %11 = load i64, ptr %10, align 8
  %12 = icmp ne i64 %11, 1
  br i1 %12, label %18, label %13

13:                                               ; preds = %8
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds i64, ptr %14, i64 1
  %16 = load i64, ptr %15, align 8
  %17 = icmp ne i64 %16, 11
  br i1 %17, label %18, label %19

18:                                               ; preds = %13, %8
  call void @abort() #3
  unreachable

19:                                               ; preds = %13
  %20 = load ptr, ptr %3, align 8
  %21 = getelementptr inbounds i64, ptr %20, i64 2
  %22 = load i64, ptr %21, align 8
  %23 = icmp ne i64 %22, 2
  br i1 %23, label %29, label %24

24:                                               ; preds = %19
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds i64, ptr %25, i64 3
  %27 = load i64, ptr %26, align 8
  %28 = icmp ne i64 %27, 12
  br i1 %28, label %29, label %30

29:                                               ; preds = %24, %19
  call void @abort() #3
  unreachable

30:                                               ; preds = %24
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds i64, ptr %31, i64 4
  %33 = load i64, ptr %32, align 8
  %34 = icmp ne i64 %33, 3
  br i1 %34, label %40, label %35

35:                                               ; preds = %30
  %36 = load ptr, ptr %3, align 8
  %37 = getelementptr inbounds i64, ptr %36, i64 5
  %38 = load i64, ptr %37, align 8
  %39 = icmp ne i64 %38, 13
  br i1 %39, label %40, label %41

40:                                               ; preds = %35, %30
  call void @abort() #3
  unreachable

41:                                               ; preds = %35
  %42 = load ptr, ptr %3, align 8
  %43 = getelementptr inbounds i64, ptr %42, i64 6
  %44 = load i64, ptr %43, align 8
  %45 = icmp ne i64 %44, 4
  br i1 %45, label %51, label %46

46:                                               ; preds = %41
  %47 = load ptr, ptr %3, align 8
  %48 = getelementptr inbounds i64, ptr %47, i64 7
  %49 = load i64, ptr %48, align 8
  %50 = icmp ne i64 %49, 14
  br i1 %50, label %51, label %52

51:                                               ; preds = %46, %41
  call void @abort() #3
  unreachable

52:                                               ; preds = %46
  %53 = load ptr, ptr %3, align 8
  %54 = getelementptr inbounds i64, ptr %53, i64 8
  %55 = load i64, ptr %54, align 8
  %56 = icmp ne i64 %55, 5
  br i1 %56, label %62, label %57

57:                                               ; preds = %52
  %58 = load ptr, ptr %3, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 9
  %60 = load i64, ptr %59, align 8
  %61 = icmp ne i64 %60, 15
  br i1 %61, label %62, label %63

62:                                               ; preds = %57, %52
  call void @abort() #3
  unreachable

63:                                               ; preds = %57
  %64 = load ptr, ptr %3, align 8
  %65 = getelementptr inbounds i64, ptr %64, i64 10
  %66 = load i64, ptr %65, align 8
  %67 = icmp ne i64 %66, 6
  br i1 %67, label %73, label %68

68:                                               ; preds = %63
  %69 = load ptr, ptr %3, align 8
  %70 = getelementptr inbounds i64, ptr %69, i64 11
  %71 = load i64, ptr %70, align 8
  %72 = icmp ne i64 %71, 16
  br i1 %72, label %73, label %74

73:                                               ; preds = %68, %63
  call void @abort() #3
  unreachable

74:                                               ; preds = %68
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [40 x i64], align 16
  %3 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  %5 = add nsw i32 %4, 1
  store i32 %5, ptr %3, align 4
  %6 = sext i32 %4 to i64
  %7 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %6
  store i64 1, ptr %7, align 8
  %8 = load i32, ptr %3, align 4
  %9 = add nsw i32 %8, 1
  store i32 %9, ptr %3, align 4
  %10 = sext i32 %8 to i64
  %11 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %10
  store i64 11, ptr %11, align 8
  %12 = load i32, ptr %3, align 4
  %13 = add nsw i32 %12, 1
  store i32 %13, ptr %3, align 4
  %14 = sext i32 %12 to i64
  %15 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %14
  store i64 2, ptr %15, align 8
  %16 = load i32, ptr %3, align 4
  %17 = add nsw i32 %16, 1
  store i32 %17, ptr %3, align 4
  %18 = sext i32 %16 to i64
  %19 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %18
  store i64 12, ptr %19, align 8
  %20 = load i32, ptr %3, align 4
  %21 = add nsw i32 %20, 1
  store i32 %21, ptr %3, align 4
  %22 = sext i32 %20 to i64
  %23 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %22
  store i64 3, ptr %23, align 8
  %24 = call ptr @bar()
  %25 = getelementptr inbounds nuw %struct.A, ptr %24, i32 0, i32 0
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %3, align 4
  %28 = add nsw i32 %27, 1
  store i32 %28, ptr %3, align 4
  %29 = sext i32 %27 to i64
  %30 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %29
  store i64 %26, ptr %30, align 8
  %31 = load i32, ptr %3, align 4
  %32 = add nsw i32 %31, 1
  store i32 %32, ptr %3, align 4
  %33 = sext i32 %31 to i64
  %34 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %33
  store i64 4, ptr %34, align 8
  %35 = call ptr @bar()
  %36 = getelementptr inbounds nuw %struct.A, ptr %35, i32 0, i32 1
  %37 = load i64, ptr %36, align 8
  %38 = load i32, ptr %3, align 4
  %39 = add nsw i32 %38, 1
  store i32 %39, ptr %3, align 4
  %40 = sext i32 %38 to i64
  %41 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %40
  store i64 %37, ptr %41, align 8
  %42 = load i32, ptr %3, align 4
  %43 = add nsw i32 %42, 1
  store i32 %43, ptr %3, align 4
  %44 = sext i32 %42 to i64
  %45 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %44
  store i64 5, ptr %45, align 8
  %46 = call ptr @bar()
  %47 = getelementptr inbounds nuw %struct.A, ptr %46, i32 0, i32 2
  %48 = load i64, ptr %47, align 8
  %49 = load i32, ptr %3, align 4
  %50 = add nsw i32 %49, 1
  store i32 %50, ptr %3, align 4
  %51 = sext i32 %49 to i64
  %52 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %51
  store i64 %48, ptr %52, align 8
  %53 = load i32, ptr %3, align 4
  %54 = add nsw i32 %53, 1
  store i32 %54, ptr %3, align 4
  %55 = sext i32 %53 to i64
  %56 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %55
  store i64 6, ptr %56, align 8
  %57 = call ptr @bar()
  %58 = getelementptr inbounds nuw %struct.A, ptr %57, i32 0, i32 3
  %59 = load i64, ptr %58, align 8
  %60 = load i32, ptr %3, align 4
  %61 = add nsw i32 %60, 1
  store i32 %61, ptr %3, align 4
  %62 = sext i32 %60 to i64
  %63 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 %62
  store i64 %59, ptr %63, align 8
  %64 = getelementptr inbounds [40 x i64], ptr %2, i64 0, i64 0
  %65 = load i32, ptr %3, align 4
  call void @foo(ptr noundef %64, i32 noundef %65)
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @bar() #0 {
  %1 = alloca ptr, align 8
  store ptr @x, ptr %1, align 8
  %2 = load ptr, ptr %1, align 8
  ret ptr %2
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
