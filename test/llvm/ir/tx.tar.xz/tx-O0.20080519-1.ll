; ModuleID = '20080519-1.c'
source_filename = "20080519-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.du_chain = type { ptr, i32 }

@reg_class_contents = dso_local global [2 x [2 x i64]] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @merge_overlapping_regs(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 0
  %5 = load i64, ptr %4, align 8
  %6 = icmp ne i64 %5, -1
  br i1 %6, label %12, label %7

7:                                                ; preds = %1
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds [2 x i64], ptr %8, i64 0, i64 1
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, -1
  br i1 %11, label %12, label %13

12:                                               ; preds = %7, %1
  call void @abort() #3
  unreachable

13:                                               ; preds = %7
  ret void
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @regrename_optimize(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca [2 x i64], align 16
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %7 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 0
  store i64 0, ptr %7, align 16
  %8 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 1
  store i64 0, ptr %8, align 8
  store i32 0, ptr %5, align 4
  %9 = load ptr, ptr %2, align 8
  store ptr %9, ptr %6, align 8
  br label %10

10:                                               ; preds = %38, %1
  %11 = load ptr, ptr %6, align 8
  %12 = getelementptr inbounds nuw %struct.du_chain, ptr %11, i32 0, i32 0
  %13 = load ptr, ptr %12, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %15, label %42

15:                                               ; preds = %10
  %16 = load ptr, ptr %6, align 8
  %17 = getelementptr inbounds nuw %struct.du_chain, ptr %16, i32 0, i32 1
  %18 = load i32, ptr %17, align 8
  %19 = sext i32 %18 to i64
  %20 = getelementptr inbounds [2 x [2 x i64]], ptr @reg_class_contents, i64 0, i64 %19
  %21 = getelementptr inbounds [2 x i64], ptr %20, i64 0, i64 0
  store ptr %21, ptr %4, align 8
  %22 = load i32, ptr %5, align 4
  %23 = add nsw i32 %22, 1
  store i32 %23, ptr %5, align 4
  %24 = load ptr, ptr %4, align 8
  %25 = getelementptr inbounds i64, ptr %24, i64 0
  %26 = load i64, ptr %25, align 8
  %27 = xor i64 %26, -1
  %28 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 0
  %29 = load i64, ptr %28, align 16
  %30 = or i64 %29, %27
  store i64 %30, ptr %28, align 16
  %31 = load ptr, ptr %4, align 8
  %32 = getelementptr inbounds i64, ptr %31, i64 1
  %33 = load i64, ptr %32, align 8
  %34 = xor i64 %33, -1
  %35 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 1
  %36 = load i64, ptr %35, align 8
  %37 = or i64 %36, %34
  store i64 %37, ptr %35, align 8
  br label %38

38:                                               ; preds = %15
  %39 = load ptr, ptr %6, align 8
  %40 = getelementptr inbounds nuw %struct.du_chain, ptr %39, i32 0, i32 0
  %41 = load ptr, ptr %40, align 8
  store ptr %41, ptr %6, align 8
  br label %10, !llvm.loop !6

42:                                               ; preds = %10
  %43 = load i32, ptr %5, align 4
  %44 = icmp slt i32 %43, 1
  br i1 %44, label %45, label %46

45:                                               ; preds = %42
  br label %67

46:                                               ; preds = %42
  %47 = load ptr, ptr %6, align 8
  %48 = getelementptr inbounds nuw %struct.du_chain, ptr %47, i32 0, i32 1
  %49 = load i32, ptr %48, align 8
  %50 = sext i32 %49 to i64
  %51 = getelementptr inbounds [2 x [2 x i64]], ptr @reg_class_contents, i64 0, i64 %50
  %52 = getelementptr inbounds [2 x i64], ptr %51, i64 0, i64 0
  store ptr %52, ptr %4, align 8
  %53 = load ptr, ptr %4, align 8
  %54 = getelementptr inbounds i64, ptr %53, i64 0
  %55 = load i64, ptr %54, align 8
  %56 = xor i64 %55, -1
  %57 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 0
  %58 = load i64, ptr %57, align 16
  %59 = or i64 %58, %56
  store i64 %59, ptr %57, align 16
  %60 = load ptr, ptr %4, align 8
  %61 = getelementptr inbounds i64, ptr %60, i64 1
  %62 = load i64, ptr %61, align 8
  %63 = xor i64 %62, -1
  %64 = getelementptr inbounds [2 x i64], ptr %3, i64 0, i64 1
  %65 = load i64, ptr %64, align 8
  %66 = or i64 %65, %63
  store i64 %66, ptr %64, align 8
  call void @merge_overlapping_regs(ptr noundef %3)
  br label %67

67:                                               ; preds = %46, %45
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.du_chain, align 8
  %3 = alloca %struct.du_chain, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %struct.du_chain, ptr %3, i32 0, i32 0
  store ptr %2, ptr %4, align 8
  %5 = getelementptr inbounds nuw %struct.du_chain, ptr %3, i32 0, i32 1
  store i32 1, ptr %5, align 8
  %6 = getelementptr i8, ptr %3, i64 12
  call void @llvm.memset.p0.i64(ptr align 4 %6, i8 0, i64 4, i1 false)
  store i64 -1, ptr @reg_class_contents, align 16
  store i64 -1, ptr getelementptr inbounds nuw (i8, ptr @reg_class_contents, i64 8), align 8
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @reg_class_contents, i64 16), align 16
  store i64 0, ptr getelementptr inbounds nuw (i8, ptr @reg_class_contents, i64 24), align 8
  call void @regrename_optimize(ptr noundef %3)
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
