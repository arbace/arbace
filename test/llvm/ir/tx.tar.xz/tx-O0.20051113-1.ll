; ModuleID = '20051113-1.c'
source_filename = "20051113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.Struct3 = type { i32, [0 x %union.Union] }
%union.Union = type { %struct.Struct2 }
%struct.Struct2 = type <{ i16, i16, i16, i64, i64, i64 }>
%struct.Struct1 = type <{ i16, i16, i16, i64, i64 }>

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @Sum(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store i32 0, ptr %4, align 4
  br label %5

5:                                                ; preds = %21, %1
  %6 = load i32, ptr %4, align 4
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.Struct3, ptr %7, i32 0, i32 0
  %9 = load i32, ptr %8, align 1
  %10 = icmp slt i32 %6, %9
  br i1 %10, label %11, label %24

11:                                               ; preds = %5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds nuw %struct.Struct3, ptr %12, i32 0, i32 1
  %14 = load i32, ptr %4, align 4
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds [0 x %union.Union], ptr %13, i64 0, i64 %15
  %17 = getelementptr inbounds nuw %struct.Struct1, ptr %16, i32 0, i32 3
  %18 = load i64, ptr %17, align 1
  %19 = load i64, ptr %3, align 8
  %20 = add i64 %19, %18
  store i64 %20, ptr %3, align 8
  br label %21

21:                                               ; preds = %11
  %22 = load i32, ptr %4, align 4
  %23 = add nsw i32 %22, 1
  store i32 %23, ptr %4, align 4
  br label %5, !llvm.loop !6

24:                                               ; preds = %5
  %25 = load i64, ptr %3, align 8
  ret i64 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @Sum2(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %2, align 8
  store i64 0, ptr %3, align 8
  store i32 0, ptr %4, align 4
  br label %5

5:                                                ; preds = %21, %1
  %6 = load i32, ptr %4, align 4
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.Struct3, ptr %7, i32 0, i32 0
  %9 = load i32, ptr %8, align 1
  %10 = icmp slt i32 %6, %9
  br i1 %10, label %11, label %24

11:                                               ; preds = %5
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds nuw %struct.Struct3, ptr %12, i32 0, i32 1
  %14 = load i32, ptr %4, align 4
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds [0 x %union.Union], ptr %13, i64 0, i64 %15
  %17 = getelementptr inbounds nuw %struct.Struct1, ptr %16, i32 0, i32 4
  %18 = load i64, ptr %17, align 1
  %19 = load i64, ptr %3, align 8
  %20 = add nsw i64 %19, %18
  store i64 %20, ptr %3, align 8
  br label %21

21:                                               ; preds = %11
  %22 = load i32, ptr %4, align 4
  %23 = add nsw i32 %22, 1
  store i32 %23, ptr %4, align 4
  br label %5, !llvm.loop !8

24:                                               ; preds = %5
  %25 = load i64, ptr %3, align 8
  ret i64 %25
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  %3 = call ptr @malloc(i64 noundef 94) #4
  store ptr %3, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  call void @llvm.memset.p0.i64(ptr align 1 %4, i8 0, i64 94, i1 false)
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.Struct3, ptr %5, i32 0, i32 0
  store i32 3, ptr %6, align 1
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.Struct3, ptr %7, i32 0, i32 1
  %9 = getelementptr inbounds [0 x %union.Union], ptr %8, i64 0, i64 0
  %10 = getelementptr inbounds nuw %struct.Struct1, ptr %9, i32 0, i32 3
  store i64 555, ptr %10, align 1
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.Struct3, ptr %11, i32 0, i32 1
  %13 = getelementptr inbounds [0 x %union.Union], ptr %12, i64 0, i64 1
  %14 = getelementptr inbounds nuw %struct.Struct1, ptr %13, i32 0, i32 3
  store i64 999, ptr %14, align 1
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.Struct3, ptr %15, i32 0, i32 1
  %17 = getelementptr inbounds [0 x %union.Union], ptr %16, i64 0, i64 2
  %18 = getelementptr inbounds nuw %struct.Struct1, ptr %17, i32 0, i32 3
  store i64 4311810305, ptr %18, align 1
  %19 = load ptr, ptr %2, align 8
  %20 = getelementptr inbounds nuw %struct.Struct3, ptr %19, i32 0, i32 1
  %21 = getelementptr inbounds [0 x %union.Union], ptr %20, i64 0, i64 0
  %22 = getelementptr inbounds nuw %struct.Struct1, ptr %21, i32 0, i32 4
  store i64 555, ptr %22, align 1
  %23 = load ptr, ptr %2, align 8
  %24 = getelementptr inbounds nuw %struct.Struct3, ptr %23, i32 0, i32 1
  %25 = getelementptr inbounds [0 x %union.Union], ptr %24, i64 0, i64 1
  %26 = getelementptr inbounds nuw %struct.Struct1, ptr %25, i32 0, i32 4
  store i64 999, ptr %26, align 1
  %27 = load ptr, ptr %2, align 8
  %28 = getelementptr inbounds nuw %struct.Struct3, ptr %27, i32 0, i32 1
  %29 = getelementptr inbounds [0 x %union.Union], ptr %28, i64 0, i64 2
  %30 = getelementptr inbounds nuw %struct.Struct1, ptr %29, i32 0, i32 4
  store i64 4311810305, ptr %30, align 1
  %31 = load ptr, ptr %2, align 8
  %32 = call i64 @Sum(ptr noundef %31)
  %33 = icmp ne i64 %32, 4311811859
  br i1 %33, label %34, label %35

34:                                               ; preds = %0
  call void @abort() #5
  unreachable

35:                                               ; preds = %0
  %36 = load ptr, ptr %2, align 8
  %37 = call i64 @Sum2(ptr noundef %36)
  %38 = icmp ne i64 %37, 4311811859
  br i1 %38, label %39, label %40

39:                                               ; preds = %35
  call void @abort() #5
  unreachable

40:                                               ; preds = %35
  ret i32 0
}

; Function Attrs: allocsize(0)
declare ptr @malloc(i64 noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: noreturn nounwind
declare void @abort() #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { allocsize(0) }
attributes #5 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
