; ModuleID = '20001124-1.c'
source_filename = "20001124-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.super_block = type { i32, i8, i32 }
%struct.inode = type { i64, ptr }
%struct.file = type { i64 }

@s = dso_local global %struct.super_block zeroinitializer, align 4
@i = dso_local global %struct.inode zeroinitializer, align 8
@f = dso_local global %struct.file zeroinitializer, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  store i32 512, ptr @s, align 4
  store i8 9, ptr getelementptr inbounds nuw (i8, ptr @s, i64 4), align 4
  store i64 2048, ptr @i, align 8
  store ptr @s, ptr getelementptr inbounds nuw (i8, ptr @i, i64 8), align 8
  store i64 0, ptr @f, align 8
  %6 = call i32 @do_isofs_readdir(ptr noundef @i, ptr noundef @f)
  call void @abort() #3
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @do_isofs_readdir(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca i8, align 1
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca ptr, align 8
  %11 = alloca i32, align 4
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  %12 = load ptr, ptr %4, align 8
  %13 = getelementptr inbounds nuw %struct.inode, ptr %12, i32 0, i32 1
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds nuw %struct.super_block, ptr %14, i32 0, i32 0
  %16 = load i32, ptr %15, align 4
  store i32 %16, ptr %6, align 4
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds nuw %struct.inode, ptr %17, i32 0, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds nuw %struct.super_block, ptr %19, i32 0, i32 1
  %21 = load i8, ptr %20, align 4
  store i8 %21, ptr %7, align 1
  store ptr null, ptr %10, align 8
  %22 = load ptr, ptr %5, align 8
  %23 = getelementptr inbounds nuw %struct.file, ptr %22, i32 0, i32 0
  %24 = load i64, ptr %23, align 8
  %25 = load ptr, ptr %4, align 8
  %26 = getelementptr inbounds nuw %struct.inode, ptr %25, i32 0, i32 0
  %27 = load i64, ptr %26, align 8
  %28 = icmp sge i64 %24, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %2
  store i32 0, ptr %3, align 4
  br label %104

30:                                               ; preds = %2
  %31 = load ptr, ptr %5, align 8
  %32 = getelementptr inbounds nuw %struct.file, ptr %31, i32 0, i32 0
  %33 = load i64, ptr %32, align 8
  %34 = load i32, ptr %6, align 4
  %35 = sub nsw i32 %34, 1
  %36 = sext i32 %35 to i64
  %37 = and i64 %33, %36
  %38 = trunc i64 %37 to i32
  store i32 %38, ptr %9, align 4
  %39 = load ptr, ptr %5, align 8
  %40 = getelementptr inbounds nuw %struct.file, ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  %42 = load i8, ptr %7, align 1
  %43 = zext i8 %42 to i32
  %44 = zext i32 %43 to i64
  %45 = ashr i64 %41, %44
  %46 = trunc i64 %45 to i32
  store i32 %46, ptr %8, align 4
  %47 = load ptr, ptr %4, align 8
  %48 = getelementptr inbounds nuw %struct.inode, ptr %47, i32 0, i32 1
  %49 = load ptr, ptr %48, align 8
  %50 = getelementptr inbounds nuw %struct.super_block, ptr %49, i32 0, i32 2
  %51 = load i32, ptr %50, align 4
  store i32 %51, ptr %11, align 4
  br label %52

52:                                               ; preds = %98, %30
  %53 = load ptr, ptr %5, align 8
  %54 = getelementptr inbounds nuw %struct.file, ptr %53, i32 0, i32 0
  %55 = load i64, ptr %54, align 8
  %56 = load ptr, ptr %4, align 8
  %57 = getelementptr inbounds nuw %struct.inode, ptr %56, i32 0, i32 0
  %58 = load i64, ptr %57, align 8
  %59 = icmp slt i64 %55, %58
  br i1 %59, label %60, label %103

60:                                               ; preds = %52
  %61 = load ptr, ptr %10, align 8
  %62 = icmp ne ptr %61, null
  br i1 %62, label %66, label %63

63:                                               ; preds = %60
  %64 = load i32, ptr %8, align 4
  %65 = call ptr @isofs_bread(i32 noundef %64)
  store ptr %65, ptr %10, align 8
  br label %66

66:                                               ; preds = %63, %60
  %67 = load i32, ptr %8, align 4
  %68 = load i8, ptr %7, align 1
  %69 = zext i8 %68 to i32
  %70 = shl i32 %67, %69
  %71 = load i32, ptr %11, align 4
  %72 = add i32 %71, %70
  store i32 %72, ptr %11, align 4
  %73 = load i32, ptr %11, align 4
  %74 = icmp eq i32 %73, 0
  br i1 %74, label %75, label %80

75:                                               ; preds = %66
  %76 = load ptr, ptr %5, align 8
  %77 = getelementptr inbounds nuw %struct.file, ptr %76, i32 0, i32 0
  %78 = load i64, ptr %77, align 8
  %79 = add nsw i64 %78, 1
  store i64 %79, ptr %77, align 8
  br label %80

80:                                               ; preds = %75, %66
  %81 = load i32, ptr %9, align 4
  %82 = load i32, ptr %6, align 4
  %83 = icmp uge i32 %81, %82
  br i1 %83, label %84, label %89

84:                                               ; preds = %80
  %85 = load i32, ptr %6, align 4
  %86 = sub nsw i32 %85, 1
  %87 = load i32, ptr %9, align 4
  %88 = and i32 %87, %86
  store i32 %88, ptr %9, align 4
  br label %89

89:                                               ; preds = %84, %80
  %90 = load ptr, ptr %10, align 8
  %91 = load i8, ptr %90, align 1
  %92 = icmp ne i8 %91, 0
  br i1 %92, label %93, label %98

93:                                               ; preds = %89
  %94 = load ptr, ptr %5, align 8
  %95 = getelementptr inbounds nuw %struct.file, ptr %94, i32 0, i32 0
  %96 = load i64, ptr %95, align 8
  %97 = add nsw i64 %96, 1
  store i64 %97, ptr %95, align 8
  br label %98

98:                                               ; preds = %93, %89
  %99 = load ptr, ptr %5, align 8
  %100 = getelementptr inbounds nuw %struct.file, ptr %99, i32 0, i32 0
  %101 = load i64, ptr %100, align 8
  %102 = add nsw i64 %101, 1
  store i64 %102, ptr %100, align 8
  br label %52, !llvm.loop !6

103:                                              ; preds = %52
  store i32 0, ptr %3, align 4
  br label %104

104:                                              ; preds = %103, %29
  %105 = load i32, ptr %3, align 4
  ret i32 %105
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @isofs_bread(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %1
  call void @abort() #3
  unreachable

6:                                                ; preds = %1
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
