; ModuleID = '20120808-1.c'
source_filename = "20120808-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@d = dso_local global [32 x i8] zeroinitializer, align 16
@i = dso_local global i32 0, align 4
@cp = dso_local global ptr null, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [32 x i8], align 16
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 16 %2, i8 0, i64 32, i1 false)
  %7 = load volatile i32, ptr @i, align 4
  %8 = sext i32 %7 to i64
  %9 = getelementptr inbounds i8, ptr @d, i64 %8
  store ptr %9, ptr %3, align 8
  store i32 0, ptr %4, align 4
  br label %10

10:                                               ; preds = %38, %0
  %11 = load i32, ptr %4, align 4
  %12 = icmp slt i32 %11, 30
  br i1 %12, label %13, label %41

13:                                               ; preds = %10
  store i32 255, ptr %5, align 4
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds nuw i8, ptr %14, i32 1
  store ptr %15, ptr %3, align 8
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  store i32 %17, ptr %6, align 4
  %18 = load i32, ptr %4, align 4
  switch i32 %18, label %28 [
    i32 1, label %19
    i32 2, label %22
    i32 25, label %25
  ]

19:                                               ; preds = %13
  %20 = load i32, ptr %5, align 4
  %21 = xor i32 %20, 2
  store i32 %21, ptr %5, align 4
  br label %29

22:                                               ; preds = %13
  %23 = load i32, ptr %5, align 4
  %24 = xor i32 %23, 4
  store i32 %24, ptr %5, align 4
  br label %29

25:                                               ; preds = %13
  %26 = load i32, ptr %5, align 4
  %27 = xor i32 %26, 1
  store i32 %27, ptr %5, align 4
  br label %29

28:                                               ; preds = %13
  br label %29

29:                                               ; preds = %28, %25, %22, %19
  %30 = load i32, ptr %6, align 4
  %31 = load i32, ptr %5, align 4
  %32 = or i32 %30, %31
  %33 = trunc i32 %32 to i8
  %34 = load i32, ptr %4, align 4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 %35
  store i8 %33, ptr %36, align 1
  %37 = load ptr, ptr %3, align 8
  store volatile ptr %37, ptr @cp, align 8
  br label %38

38:                                               ; preds = %29
  %39 = load i32, ptr %4, align 4
  %40 = add nsw i32 %39, 1
  store i32 %40, ptr %4, align 4
  br label %10, !llvm.loop !6

41:                                               ; preds = %10
  %42 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 0
  %43 = load i8, ptr %42, align 16
  %44 = zext i8 %43 to i32
  %45 = icmp ne i32 %44, 255
  br i1 %45, label %74, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 1
  %48 = load i8, ptr %47, align 1
  %49 = zext i8 %48 to i32
  %50 = icmp ne i32 %49, 253
  br i1 %50, label %74, label %51

51:                                               ; preds = %46
  %52 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 2
  %53 = load i8, ptr %52, align 2
  %54 = zext i8 %53 to i32
  %55 = icmp ne i32 %54, 251
  br i1 %55, label %74, label %56

56:                                               ; preds = %51
  %57 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 3
  %58 = load i8, ptr %57, align 1
  %59 = zext i8 %58 to i32
  %60 = icmp ne i32 %59, 255
  br i1 %60, label %74, label %61

61:                                               ; preds = %56
  %62 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 4
  %63 = load i8, ptr %62, align 4
  %64 = zext i8 %63 to i32
  %65 = icmp ne i32 %64, 255
  br i1 %65, label %74, label %66

66:                                               ; preds = %61
  %67 = getelementptr inbounds [32 x i8], ptr %2, i64 0, i64 25
  %68 = load i8, ptr %67, align 1
  %69 = zext i8 %68 to i32
  %70 = icmp ne i32 %69, 254
  br i1 %70, label %74, label %71

71:                                               ; preds = %66
  %72 = load volatile ptr, ptr @cp, align 8
  %73 = icmp ne ptr %72, getelementptr inbounds nuw (i8, ptr @d, i64 30)
  br i1 %73, label %74, label %75

74:                                               ; preds = %71, %66, %61, %56, %51, %46, %41
  call void @abort() #4
  unreachable

75:                                               ; preds = %71
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
