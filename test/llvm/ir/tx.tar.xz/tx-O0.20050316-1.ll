; ModuleID = '20050316-1.c'
source_filename = "20050316-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { <2 x i32> }
%union.anon.0 = type { <2 x i32> }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test1() #0 {
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @test2(double noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  store double %0, ptr %2, align 8
  %4 = load <2 x i32>, ptr %2, align 8
  store <2 x i32> %4, ptr %3, align 8
  %5 = load <2 x i32>, ptr %3, align 8
  %6 = bitcast <2 x i32> %5 to i64
  %7 = trunc i64 %6 to i32
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @test3() #0 {
  %1 = alloca <2 x i32>, align 8
  store <2 x i32> zeroinitializer, ptr %1, align 8
  %2 = load double, ptr %1, align 8
  ret double %2
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @test4(i32 noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i16>, align 4
  %4 = alloca <2 x i16>, align 4
  store i32 %0, ptr %3, align 4
  %5 = load <2 x i16>, ptr %3, align 4
  store <2 x i16> %5, ptr %4, align 4
  %6 = load <2 x i16>, ptr %4, align 4
  %7 = bitcast <2 x i16> %6 to i32
  %8 = sext i32 %7 to i64
  %9 = bitcast i64 %8 to <2 x i32>
  store <2 x i32> %9, ptr %2, align 8
  %10 = load double, ptr %2, align 8
  ret double %10
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @test5(double noundef %0) #0 {
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  %4 = alloca <2 x i32>, align 8
  store double %0, ptr %3, align 8
  %5 = load <2 x i32>, ptr %3, align 8
  store <2 x i32> %5, ptr %4, align 8
  %6 = load <2 x i32>, ptr %4, align 8
  store <2 x i32> %6, ptr %2, align 8
  %7 = load double, ptr %2, align 8
  ret double %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca <2 x i32>, align 8
  %3 = alloca <2 x i32>, align 8
  %4 = alloca %union.anon, align 8
  %5 = alloca <2 x i32>, align 8
  %6 = alloca <2 x i16>, align 4
  %7 = alloca %union.anon.0, align 8
  %8 = alloca <2 x i16>, align 4
  %9 = alloca <2 x i32>, align 8
  %10 = alloca <2 x i32>, align 8
  %11 = alloca <2 x i32>, align 8
  %12 = alloca <2 x i32>, align 8
  store i32 0, ptr %1, align 4
  %13 = call i32 @test1()
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %0
  call void @abort() #2
  unreachable

16:                                               ; preds = %0
  store <2 x i32> splat (i32 2), ptr %2, align 8
  %17 = load <2 x i32>, ptr %2, align 8
  store <2 x i32> %17, ptr %3, align 8
  %18 = load double, ptr %3, align 8
  %19 = call i32 @test2(double noundef %18)
  %20 = icmp ne i32 %19, 2
  br i1 %20, label %21, label %22

21:                                               ; preds = %16
  call void @abort() #2
  unreachable

22:                                               ; preds = %16
  %23 = call double @test3()
  store double %23, ptr %5, align 8
  %24 = load <2 x i32>, ptr %5, align 8
  store <2 x i32> %24, ptr %4, align 8
  %25 = getelementptr inbounds [2 x i32], ptr %4, i64 0, i64 0
  %26 = load i32, ptr %25, align 8
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %32, label %28

28:                                               ; preds = %22
  %29 = getelementptr inbounds [2 x i32], ptr %4, i64 0, i64 1
  %30 = load i32, ptr %29, align 4
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %32, label %33

32:                                               ; preds = %28, %22
  call void @abort() #2
  unreachable

33:                                               ; preds = %28
  store <2 x i16> splat (i16 4), ptr %6, align 4
  %34 = load <2 x i16>, ptr %6, align 4
  store <2 x i16> %34, ptr %8, align 4
  %35 = load i32, ptr %8, align 4
  %36 = call double @test4(i32 noundef %35)
  store double %36, ptr %9, align 8
  %37 = load <2 x i32>, ptr %9, align 8
  store <2 x i32> %37, ptr %7, align 8
  %38 = load i64, ptr %7, align 8
  %39 = icmp ne i64 %38, 262148
  br i1 %39, label %40, label %41

40:                                               ; preds = %33
  call void @abort() #2
  unreachable

41:                                               ; preds = %33
  store <2 x i32> splat (i32 6), ptr %10, align 8
  %42 = load <2 x i32>, ptr %10, align 8
  store <2 x i32> %42, ptr %11, align 8
  %43 = load double, ptr %11, align 8
  %44 = call double @test5(double noundef %43)
  store double %44, ptr %12, align 8
  %45 = load <2 x i32>, ptr %12, align 8
  store <2 x i32> %45, ptr %4, align 8
  %46 = getelementptr inbounds [2 x i32], ptr %4, i64 0, i64 0
  %47 = load i32, ptr %46, align 8
  %48 = icmp ne i32 %47, 6
  br i1 %48, label %53, label %49

49:                                               ; preds = %41
  %50 = getelementptr inbounds [2 x i32], ptr %4, i64 0, i64 1
  %51 = load i32, ptr %50, align 4
  %52 = icmp ne i32 %51, 6
  br i1 %52, label %53, label %54

53:                                               ; preds = %49, %41
  call void @abort() #2
  unreachable

54:                                               ; preds = %49
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
