; ModuleID = '20011113-1.c'
source_filename = "20011113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.U = type { [3 x i64] }
%struct.t = type { i32, [4 x i64] }

@t = dso_local global { i8, i8, i8, i8, [4 x i8], [4 x i64] } { i8 26, i8 0, i8 0, i8 0, [4 x i8] zeroinitializer, [4 x i64] [i64 0, i64 21, i64 22, i64 23] }, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @foo(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  store ptr %0, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = getelementptr inbounds nuw %struct.t, ptr %5, i32 0, i32 1
  %7 = getelementptr inbounds [4 x i64], ptr %6, i64 0, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %7, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 24, i1 false)
  %8 = load ptr, ptr %2, align 8
  %9 = load i32, ptr %8, align 8
  %10 = lshr i32 %9, 16
  %11 = and i32 %10, 255
  %12 = call ptr @bar(ptr noundef byval(%struct.U) align 8 %3, i32 noundef %11)
  ret ptr %12
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @bar(ptr noundef byval(%struct.U) align 8 %0, i32 noundef %1) #0 {
  %3 = alloca i32, align 4
  store i32 %1, ptr %3, align 4
  %4 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0
  %5 = getelementptr inbounds [3 x i64], ptr %4, i64 0, i64 0
  %6 = load i64, ptr %5, align 8
  %7 = icmp ne i64 %6, 21
  br i1 %7, label %18, label %8

8:                                                ; preds = %2
  %9 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0
  %10 = getelementptr inbounds [3 x i64], ptr %9, i64 0, i64 1
  %11 = load i64, ptr %10, align 8
  %12 = icmp ne i64 %11, 22
  br i1 %12, label %18, label %13

13:                                               ; preds = %8
  %14 = getelementptr inbounds nuw %struct.U, ptr %0, i32 0, i32 0
  %15 = getelementptr inbounds [3 x i64], ptr %14, i64 0, i64 2
  %16 = load i64, ptr %15, align 8
  %17 = icmp ne i64 %16, 23
  br i1 %17, label %18, label %19

18:                                               ; preds = %13, %8, %2
  call void @abort() #4
  unreachable

19:                                               ; preds = %13
  ret ptr null
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @baz(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.U, align 8
  %4 = alloca %struct.U, align 8
  store ptr %0, ptr %2, align 8
  %5 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0
  %6 = getelementptr inbounds [3 x i64], ptr %5, i64 0, i64 0
  store i64 4886718345, ptr %6, align 8
  %7 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0
  %8 = getelementptr inbounds [3 x i64], ptr %7, i64 0, i64 1
  store i64 68414056839, ptr %8, align 8
  %9 = getelementptr inbounds nuw %struct.U, ptr %3, i32 0, i32 0
  %10 = getelementptr inbounds [3 x i64], ptr %9, i64 0, i64 2
  store i64 46118400291, ptr %10, align 8
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds nuw %struct.t, ptr %11, i32 0, i32 1
  %13 = getelementptr inbounds [4 x i64], ptr %12, i64 0, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %13, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %4, i64 24, i1 false)
  %14 = load ptr, ptr %2, align 8
  %15 = load i32, ptr %14, align 8
  %16 = lshr i32 %15, 16
  %17 = and i32 %16, 255
  %18 = call ptr @bar(ptr noundef byval(%struct.U) align 8 %3, i32 noundef %17)
  ret ptr %18
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call ptr @baz(ptr noundef @t)
  %3 = call ptr @foo(ptr noundef @t)
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
