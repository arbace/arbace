; ModuleID = '921113-1.c'
source_filename = "921113-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.vector_t = type { float, float }
%struct.struct_list = type { float }

@pos = dso_local global [1 x %struct.vector_t] zeroinitializer, align 4
@limit = dso_local global [2 x %struct.vector_t] [%struct.vector_t zeroinitializer, %struct.vector_t { float 1.000000e+00, float 1.000000e+00 }], align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @w(float noundef %0, float noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca float, align 4
  %5 = alloca float, align 4
  store float %0, ptr %4, align 4
  store float %1, ptr %5, align 4
  %6 = load i32, ptr %3, align 4
  ret i32 %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f1(float noundef %0, float noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca float, align 4
  %5 = alloca float, align 4
  store float %0, ptr %4, align 4
  store float %1, ptr %5, align 4
  %6 = load float, ptr %4, align 4
  %7 = fcmp une float %6, 0.000000e+00
  br i1 %7, label %11, label %8

8:                                                ; preds = %2
  %9 = load float, ptr %5, align 4
  %10 = fcmp une float %9, 0.000000e+00
  br i1 %10, label %11, label %12

11:                                               ; preds = %8, %2
  call void @abort() #3
  unreachable

12:                                               ; preds = %8
  %13 = load i32, ptr %3, align 4
  ret i32 %13
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f2(float noundef %0, float noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca float, align 4
  %5 = alloca float, align 4
  store float %0, ptr %4, align 4
  store float %1, ptr %5, align 4
  %6 = load float, ptr %4, align 4
  %7 = fcmp une float %6, 1.000000e+00
  br i1 %7, label %11, label %8

8:                                                ; preds = %2
  %9 = load float, ptr %5, align 4
  %10 = fcmp une float %9, 1.000000e+00
  br i1 %10, label %11, label %12

11:                                               ; preds = %8, %2
  call void @abort() #3
  unreachable

12:                                               ; preds = %8
  %13 = load i32, ptr %3, align 4
  ret i32 %13
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @gitter(i32 noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3, ptr noundef %4, float noundef %5) #0 {
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca ptr, align 8
  %10 = alloca ptr, align 8
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca float, align 4
  %14 = alloca float, align 4
  %15 = alloca [128 x [128 x i32]], align 16
  store i32 %0, ptr %8, align 4
  store ptr %1, ptr %9, align 8
  store ptr %2, ptr %10, align 8
  store ptr %3, ptr %11, align 8
  store ptr %4, ptr %12, align 8
  store float %5, ptr %13, align 4
  %16 = load ptr, ptr %12, align 8
  %17 = getelementptr inbounds %struct.vector_t, ptr %16, i64 0
  %18 = getelementptr inbounds nuw %struct.vector_t, ptr %17, i32 0, i32 0
  %19 = load float, ptr %18, align 4
  %20 = load ptr, ptr %12, align 8
  %21 = getelementptr inbounds %struct.vector_t, ptr %20, i64 0
  %22 = getelementptr inbounds nuw %struct.vector_t, ptr %21, i32 0, i32 1
  %23 = load float, ptr %22, align 4
  %24 = call i32 @f1(float noundef %19, float noundef %23)
  %25 = load ptr, ptr %12, align 8
  %26 = getelementptr inbounds %struct.vector_t, ptr %25, i64 1
  %27 = getelementptr inbounds nuw %struct.vector_t, ptr %26, i32 0, i32 0
  %28 = load float, ptr %27, align 4
  %29 = load ptr, ptr %12, align 8
  %30 = getelementptr inbounds %struct.vector_t, ptr %29, i64 1
  %31 = getelementptr inbounds nuw %struct.vector_t, ptr %30, i32 0, i32 1
  %32 = load float, ptr %31, align 4
  %33 = call i32 @f2(float noundef %28, float noundef %32)
  %34 = load ptr, ptr %11, align 8
  store i32 0, ptr %34, align 4
  %35 = load ptr, ptr %9, align 8
  %36 = getelementptr inbounds %struct.vector_t, ptr %35, i64 0
  %37 = getelementptr inbounds nuw %struct.vector_t, ptr %36, i32 0, i32 0
  %38 = load float, ptr %37, align 4
  store float %38, ptr %14, align 4
  %39 = load float, ptr %14, align 4
  %40 = fpext float %39 to double
  %41 = fcmp ole double %40, 0.000000e+00
  br i1 %41, label %42, label %60

42:                                               ; preds = %6
  %43 = load float, ptr %14, align 4
  %44 = load float, ptr %13, align 4
  %45 = call i32 @w(float noundef %43, float noundef %44)
  %46 = load float, ptr %14, align 4
  %47 = fpext float %46 to double
  %48 = load float, ptr %13, align 4
  %49 = fpext float %48 to double
  %50 = fmul double %49, 5.000000e-01
  %51 = fcmp ole double %47, %50
  br i1 %51, label %52, label %59

52:                                               ; preds = %42
  %53 = load float, ptr %14, align 4
  %54 = load float, ptr %13, align 4
  %55 = call i32 @w(float noundef %53, float noundef %54)
  %56 = load ptr, ptr %10, align 8
  %57 = getelementptr inbounds %struct.struct_list, ptr %56, i64 0
  %58 = getelementptr inbounds nuw %struct.struct_list, ptr %57, i32 0, i32 0
  store float 1.000000e+00, ptr %58, align 4
  br label %59

59:                                               ; preds = %52, %42
  br label %60

60:                                               ; preds = %59, %6
  %61 = load i32, ptr %7, align 4
  ret i32 %61
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca %struct.struct_list, align 4
  store i32 0, ptr %1, align 4
  %4 = call i32 @gitter(i32 noundef 1, ptr noundef @pos, ptr noundef %3, ptr noundef %2, ptr noundef @limit, float noundef 1.000000e+00)
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
