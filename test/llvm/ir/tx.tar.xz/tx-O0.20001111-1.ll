; ModuleID = '20001111-1.c'
source_filename = "20001111-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@u = internal global i32 0, align 4
@next_buffer = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @foo(i32 noundef %0) #0 {
  %2 = alloca i64, align 8
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store i32 %0, ptr %3, align 4
  %8 = load i32, ptr @u, align 4
  store i32 %8, ptr %4, align 4
  %9 = load i32, ptr %4, align 4
  %10 = icmp ne i32 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %1
  %12 = load i32, ptr %4, align 4
  %13 = mul i32 %12, 52783
  %14 = zext i32 %13 to i64
  store i64 %14, ptr %2, align 8
  br label %35

15:                                               ; preds = %1
  %16 = load i32, ptr @next_buffer, align 4
  store i32 %16, ptr %5, align 4
  %17 = load i32, ptr %5, align 4
  %18 = mul i32 %17, 52783
  %19 = zext i32 %18 to i64
  %20 = inttoptr i64 %19 to ptr
  store ptr %20, ptr %7, align 8
  store i32 0, ptr %4, align 4
  br label %21

21:                                               ; preds = %25, %15
  %22 = load i32, ptr %4, align 4
  %23 = icmp ult i32 %22, 2
  br i1 %23, label %24, label %28

24:                                               ; preds = %21
  call void @bar()
  br label %25

25:                                               ; preds = %24
  %26 = load i32, ptr %4, align 4
  %27 = add i32 %26, 1
  store i32 %27, ptr %4, align 4
  br label %21, !llvm.loop !6

28:                                               ; preds = %21
  %29 = load i32, ptr @next_buffer, align 4
  store i32 %29, ptr %5, align 4
  %30 = load i32, ptr %5, align 4
  %31 = mul i32 %30, 52783
  %32 = load i32, ptr %3, align 4
  %33 = add i32 %31, %32
  %34 = zext i32 %33 to i64
  store i64 %34, ptr %2, align 8
  br label %35

35:                                               ; preds = %28, %11
  %36 = load i64, ptr %2, align 8
  ret i64 %36
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @bar() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i64 @foo(i32 noundef 3)
  %3 = icmp ne i64 %2, 3
  br i1 %3, label %4, label %5

4:                                                ; preds = %0
  call void @abort() #3
  unreachable

5:                                                ; preds = %0
  store i32 1, ptr @next_buffer, align 4
  %6 = call i64 @foo(i32 noundef 2)
  %7 = icmp ne i64 %6, 52785
  br i1 %7, label %8, label %9

8:                                                ; preds = %5
  call void @abort() #3
  unreachable

9:                                                ; preds = %5
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
