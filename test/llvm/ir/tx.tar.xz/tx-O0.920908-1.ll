; ModuleID = '920908-1.c'
source_filename = "920908-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.T = type { i32 }
%struct.__va_list_tag = type { i32, i32, ptr, ptr }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f(i32 noundef %0, ...) #0 {
  %2 = alloca %struct.T, align 4
  %3 = alloca i32, align 4
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  store i32 %0, ptr %3, align 4
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_start.p0(ptr %5)
  %6 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  %7 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 0
  %8 = load i32, ptr %7, align 16
  %9 = icmp ule i32 %8, 40
  br i1 %9, label %10, label %15

10:                                               ; preds = %1
  %11 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 3
  %12 = load ptr, ptr %11, align 16
  %13 = getelementptr i8, ptr %12, i32 %8
  %14 = add i32 %8, 8
  store i32 %14, ptr %7, align 16
  br label %19

15:                                               ; preds = %1
  %16 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %6, i32 0, i32 2
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr i8, ptr %17, i32 8
  store ptr %18, ptr %16, align 8
  br label %19

19:                                               ; preds = %15, %10
  %20 = phi ptr [ %13, %10 ], [ %17, %15 ]
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %20, i64 4, i1 false)
  %21 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  %22 = load i32, ptr %21, align 4
  %23 = icmp ne i32 %22, 10
  br i1 %23, label %24, label %25

24:                                               ; preds = %19
  call void @abort() #5
  unreachable

25:                                               ; preds = %19
  %26 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  %27 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %26, i32 0, i32 0
  %28 = load i32, ptr %27, align 16
  %29 = icmp ule i32 %28, 40
  br i1 %29, label %30, label %35

30:                                               ; preds = %25
  %31 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %26, i32 0, i32 3
  %32 = load ptr, ptr %31, align 16
  %33 = getelementptr i8, ptr %32, i32 %28
  %34 = add i32 %28, 8
  store i32 %34, ptr %27, align 16
  br label %39

35:                                               ; preds = %25
  %36 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %26, i32 0, i32 2
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr i8, ptr %37, i32 8
  store ptr %38, ptr %36, align 8
  br label %39

39:                                               ; preds = %35, %30
  %40 = phi ptr [ %33, %30 ], [ %37, %35 ]
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 %40, i64 4, i1 false)
  %41 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  %42 = load i32, ptr %41, align 4
  %43 = icmp ne i32 %42, 20
  br i1 %43, label %44, label %45

44:                                               ; preds = %39
  call void @abort() #5
  unreachable

45:                                               ; preds = %39
  %46 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %4, i64 0, i64 0
  call void @llvm.va_end.p0(ptr %46)
  %47 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  %48 = load i32, ptr %47, align 4
  ret i32 %48
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.T, align 4
  %3 = alloca %struct.T, align 4
  %4 = alloca i32, align 4
  %5 = alloca %struct.T, align 4
  store i32 0, ptr %1, align 4
  %6 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  store i32 10, ptr %6, align 4
  %7 = getelementptr inbounds nuw %struct.T, ptr %3, i32 0, i32 0
  store i32 20, ptr %7, align 4
  %8 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  %9 = load i32, ptr %8, align 4
  %10 = getelementptr inbounds nuw %struct.T, ptr %3, i32 0, i32 0
  %11 = load i32, ptr %10, align 4
  %12 = call i32 (i32, ...) @f(i32 noundef 2, i32 %9, i32 %11)
  %13 = getelementptr inbounds nuw %struct.T, ptr %5, i32 0, i32 0
  store i32 %12, ptr %13, align 4
  call void @exit(i32 noundef 0) #6
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind }
attributes #6 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
