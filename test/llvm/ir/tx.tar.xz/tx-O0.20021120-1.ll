; ModuleID = '20021120-1.c'
source_filename = "20021120-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@gd = dso_local global [32 x double] zeroinitializer, align 16
@gf = dso_local global [32 x float] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca double, align 8
  %14 = alloca double, align 8
  %15 = alloca double, align 8
  %16 = alloca double, align 8
  %17 = alloca double, align 8
  %18 = alloca double, align 8
  %19 = alloca double, align 8
  %20 = alloca double, align 8
  %21 = alloca double, align 8
  %22 = alloca double, align 8
  %23 = alloca double, align 8
  %24 = alloca double, align 8
  %25 = alloca double, align 8
  %26 = alloca double, align 8
  %27 = alloca double, align 8
  %28 = alloca double, align 8
  %29 = alloca double, align 8
  %30 = alloca double, align 8
  %31 = alloca double, align 8
  %32 = alloca double, align 8
  %33 = alloca double, align 8
  %34 = alloca double, align 8
  %35 = alloca float, align 4
  %36 = alloca float, align 4
  %37 = alloca float, align 4
  %38 = alloca float, align 4
  %39 = alloca float, align 4
  %40 = alloca float, align 4
  %41 = alloca float, align 4
  %42 = alloca float, align 4
  %43 = alloca float, align 4
  %44 = alloca float, align 4
  %45 = alloca float, align 4
  %46 = alloca float, align 4
  %47 = alloca float, align 4
  %48 = alloca float, align 4
  %49 = alloca float, align 4
  %50 = alloca float, align 4
  %51 = alloca float, align 4
  %52 = alloca float, align 4
  %53 = alloca float, align 4
  %54 = alloca float, align 4
  %55 = alloca float, align 4
  %56 = alloca float, align 4
  %57 = alloca float, align 4
  %58 = alloca float, align 4
  %59 = alloca float, align 4
  %60 = alloca float, align 4
  %61 = alloca float, align 4
  %62 = alloca float, align 4
  %63 = alloca float, align 4
  %64 = alloca float, align 4
  %65 = alloca float, align 4
  %66 = alloca float, align 4
  %67 = alloca ptr, align 8
  %68 = alloca ptr, align 8
  %69 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  store ptr @gd, ptr %67, align 8
  %70 = load ptr, ptr %67, align 8
  %71 = getelementptr inbounds nuw double, ptr %70, i32 1
  store ptr %71, ptr %67, align 8
  %72 = load volatile double, ptr %70, align 8
  store double %72, ptr %3, align 8
  %73 = load ptr, ptr %67, align 8
  %74 = getelementptr inbounds nuw double, ptr %73, i32 1
  store ptr %74, ptr %67, align 8
  %75 = load volatile double, ptr %73, align 8
  store double %75, ptr %4, align 8
  %76 = load ptr, ptr %67, align 8
  %77 = getelementptr inbounds nuw double, ptr %76, i32 1
  store ptr %77, ptr %67, align 8
  %78 = load volatile double, ptr %76, align 8
  store double %78, ptr %5, align 8
  %79 = load ptr, ptr %67, align 8
  %80 = getelementptr inbounds nuw double, ptr %79, i32 1
  store ptr %80, ptr %67, align 8
  %81 = load volatile double, ptr %79, align 8
  store double %81, ptr %6, align 8
  %82 = load ptr, ptr %67, align 8
  %83 = getelementptr inbounds nuw double, ptr %82, i32 1
  store ptr %83, ptr %67, align 8
  %84 = load volatile double, ptr %82, align 8
  store double %84, ptr %7, align 8
  %85 = load ptr, ptr %67, align 8
  %86 = getelementptr inbounds nuw double, ptr %85, i32 1
  store ptr %86, ptr %67, align 8
  %87 = load volatile double, ptr %85, align 8
  store double %87, ptr %8, align 8
  %88 = load ptr, ptr %67, align 8
  %89 = getelementptr inbounds nuw double, ptr %88, i32 1
  store ptr %89, ptr %67, align 8
  %90 = load volatile double, ptr %88, align 8
  store double %90, ptr %9, align 8
  %91 = load ptr, ptr %67, align 8
  %92 = getelementptr inbounds nuw double, ptr %91, i32 1
  store ptr %92, ptr %67, align 8
  %93 = load volatile double, ptr %91, align 8
  store double %93, ptr %10, align 8
  %94 = load ptr, ptr %67, align 8
  %95 = getelementptr inbounds nuw double, ptr %94, i32 1
  store ptr %95, ptr %67, align 8
  %96 = load volatile double, ptr %94, align 8
  store double %96, ptr %11, align 8
  %97 = load ptr, ptr %67, align 8
  %98 = getelementptr inbounds nuw double, ptr %97, i32 1
  store ptr %98, ptr %67, align 8
  %99 = load volatile double, ptr %97, align 8
  store double %99, ptr %12, align 8
  %100 = load ptr, ptr %67, align 8
  %101 = getelementptr inbounds nuw double, ptr %100, i32 1
  store ptr %101, ptr %67, align 8
  %102 = load volatile double, ptr %100, align 8
  store double %102, ptr %13, align 8
  %103 = load ptr, ptr %67, align 8
  %104 = getelementptr inbounds nuw double, ptr %103, i32 1
  store ptr %104, ptr %67, align 8
  %105 = load volatile double, ptr %103, align 8
  store double %105, ptr %14, align 8
  %106 = load ptr, ptr %67, align 8
  %107 = getelementptr inbounds nuw double, ptr %106, i32 1
  store ptr %107, ptr %67, align 8
  %108 = load volatile double, ptr %106, align 8
  store double %108, ptr %15, align 8
  %109 = load ptr, ptr %67, align 8
  %110 = getelementptr inbounds nuw double, ptr %109, i32 1
  store ptr %110, ptr %67, align 8
  %111 = load volatile double, ptr %109, align 8
  store double %111, ptr %16, align 8
  %112 = load ptr, ptr %67, align 8
  %113 = getelementptr inbounds nuw double, ptr %112, i32 1
  store ptr %113, ptr %67, align 8
  %114 = load volatile double, ptr %112, align 8
  store double %114, ptr %17, align 8
  %115 = load ptr, ptr %67, align 8
  %116 = getelementptr inbounds nuw double, ptr %115, i32 1
  store ptr %116, ptr %67, align 8
  %117 = load volatile double, ptr %115, align 8
  store double %117, ptr %18, align 8
  %118 = load ptr, ptr %67, align 8
  %119 = getelementptr inbounds nuw double, ptr %118, i32 1
  store ptr %119, ptr %67, align 8
  %120 = load volatile double, ptr %118, align 8
  store double %120, ptr %19, align 8
  %121 = load ptr, ptr %67, align 8
  %122 = getelementptr inbounds nuw double, ptr %121, i32 1
  store ptr %122, ptr %67, align 8
  %123 = load volatile double, ptr %121, align 8
  store double %123, ptr %20, align 8
  %124 = load ptr, ptr %67, align 8
  %125 = getelementptr inbounds nuw double, ptr %124, i32 1
  store ptr %125, ptr %67, align 8
  %126 = load volatile double, ptr %124, align 8
  store double %126, ptr %21, align 8
  %127 = load ptr, ptr %67, align 8
  %128 = getelementptr inbounds nuw double, ptr %127, i32 1
  store ptr %128, ptr %67, align 8
  %129 = load volatile double, ptr %127, align 8
  store double %129, ptr %22, align 8
  %130 = load ptr, ptr %67, align 8
  %131 = getelementptr inbounds nuw double, ptr %130, i32 1
  store ptr %131, ptr %67, align 8
  %132 = load volatile double, ptr %130, align 8
  store double %132, ptr %23, align 8
  %133 = load ptr, ptr %67, align 8
  %134 = getelementptr inbounds nuw double, ptr %133, i32 1
  store ptr %134, ptr %67, align 8
  %135 = load volatile double, ptr %133, align 8
  store double %135, ptr %24, align 8
  %136 = load ptr, ptr %67, align 8
  %137 = getelementptr inbounds nuw double, ptr %136, i32 1
  store ptr %137, ptr %67, align 8
  %138 = load volatile double, ptr %136, align 8
  store double %138, ptr %25, align 8
  %139 = load ptr, ptr %67, align 8
  %140 = getelementptr inbounds nuw double, ptr %139, i32 1
  store ptr %140, ptr %67, align 8
  %141 = load volatile double, ptr %139, align 8
  store double %141, ptr %26, align 8
  %142 = load ptr, ptr %67, align 8
  %143 = getelementptr inbounds nuw double, ptr %142, i32 1
  store ptr %143, ptr %67, align 8
  %144 = load volatile double, ptr %142, align 8
  store double %144, ptr %27, align 8
  %145 = load ptr, ptr %67, align 8
  %146 = getelementptr inbounds nuw double, ptr %145, i32 1
  store ptr %146, ptr %67, align 8
  %147 = load volatile double, ptr %145, align 8
  store double %147, ptr %28, align 8
  %148 = load ptr, ptr %67, align 8
  %149 = getelementptr inbounds nuw double, ptr %148, i32 1
  store ptr %149, ptr %67, align 8
  %150 = load volatile double, ptr %148, align 8
  store double %150, ptr %29, align 8
  %151 = load ptr, ptr %67, align 8
  %152 = getelementptr inbounds nuw double, ptr %151, i32 1
  store ptr %152, ptr %67, align 8
  %153 = load volatile double, ptr %151, align 8
  store double %153, ptr %30, align 8
  %154 = load ptr, ptr %67, align 8
  %155 = getelementptr inbounds nuw double, ptr %154, i32 1
  store ptr %155, ptr %67, align 8
  %156 = load volatile double, ptr %154, align 8
  store double %156, ptr %31, align 8
  %157 = load ptr, ptr %67, align 8
  %158 = getelementptr inbounds nuw double, ptr %157, i32 1
  store ptr %158, ptr %67, align 8
  %159 = load volatile double, ptr %157, align 8
  store double %159, ptr %32, align 8
  %160 = load ptr, ptr %67, align 8
  %161 = getelementptr inbounds nuw double, ptr %160, i32 1
  store ptr %161, ptr %67, align 8
  %162 = load volatile double, ptr %160, align 8
  store double %162, ptr %33, align 8
  %163 = load ptr, ptr %67, align 8
  %164 = getelementptr inbounds nuw double, ptr %163, i32 1
  store ptr %164, ptr %67, align 8
  %165 = load volatile double, ptr %163, align 8
  store double %165, ptr %34, align 8
  store i32 0, ptr %69, align 4
  br label %166

166:                                              ; preds = %843, %1
  %167 = load i32, ptr %69, align 4
  %168 = load i32, ptr %2, align 4
  %169 = icmp slt i32 %167, %168
  br i1 %169, label %170, label %846

170:                                              ; preds = %166
  store ptr @gf, ptr %68, align 8
  %171 = load ptr, ptr %68, align 8
  %172 = getelementptr inbounds nuw float, ptr %171, i32 1
  store ptr %172, ptr %68, align 8
  %173 = load volatile float, ptr %171, align 4
  store float %173, ptr %35, align 4
  %174 = load ptr, ptr %68, align 8
  %175 = getelementptr inbounds nuw float, ptr %174, i32 1
  store ptr %175, ptr %68, align 8
  %176 = load volatile float, ptr %174, align 4
  store float %176, ptr %36, align 4
  %177 = load ptr, ptr %68, align 8
  %178 = getelementptr inbounds nuw float, ptr %177, i32 1
  store ptr %178, ptr %68, align 8
  %179 = load volatile float, ptr %177, align 4
  store float %179, ptr %37, align 4
  %180 = load ptr, ptr %68, align 8
  %181 = getelementptr inbounds nuw float, ptr %180, i32 1
  store ptr %181, ptr %68, align 8
  %182 = load volatile float, ptr %180, align 4
  store float %182, ptr %38, align 4
  %183 = load ptr, ptr %68, align 8
  %184 = getelementptr inbounds nuw float, ptr %183, i32 1
  store ptr %184, ptr %68, align 8
  %185 = load volatile float, ptr %183, align 4
  store float %185, ptr %39, align 4
  %186 = load ptr, ptr %68, align 8
  %187 = getelementptr inbounds nuw float, ptr %186, i32 1
  store ptr %187, ptr %68, align 8
  %188 = load volatile float, ptr %186, align 4
  store float %188, ptr %40, align 4
  %189 = load ptr, ptr %68, align 8
  %190 = getelementptr inbounds nuw float, ptr %189, i32 1
  store ptr %190, ptr %68, align 8
  %191 = load volatile float, ptr %189, align 4
  store float %191, ptr %41, align 4
  %192 = load ptr, ptr %68, align 8
  %193 = getelementptr inbounds nuw float, ptr %192, i32 1
  store ptr %193, ptr %68, align 8
  %194 = load volatile float, ptr %192, align 4
  store float %194, ptr %42, align 4
  %195 = load ptr, ptr %68, align 8
  %196 = getelementptr inbounds nuw float, ptr %195, i32 1
  store ptr %196, ptr %68, align 8
  %197 = load volatile float, ptr %195, align 4
  store float %197, ptr %43, align 4
  %198 = load ptr, ptr %68, align 8
  %199 = getelementptr inbounds nuw float, ptr %198, i32 1
  store ptr %199, ptr %68, align 8
  %200 = load volatile float, ptr %198, align 4
  store float %200, ptr %44, align 4
  %201 = load ptr, ptr %68, align 8
  %202 = getelementptr inbounds nuw float, ptr %201, i32 1
  store ptr %202, ptr %68, align 8
  %203 = load volatile float, ptr %201, align 4
  store float %203, ptr %45, align 4
  %204 = load ptr, ptr %68, align 8
  %205 = getelementptr inbounds nuw float, ptr %204, i32 1
  store ptr %205, ptr %68, align 8
  %206 = load volatile float, ptr %204, align 4
  store float %206, ptr %46, align 4
  %207 = load ptr, ptr %68, align 8
  %208 = getelementptr inbounds nuw float, ptr %207, i32 1
  store ptr %208, ptr %68, align 8
  %209 = load volatile float, ptr %207, align 4
  store float %209, ptr %47, align 4
  %210 = load ptr, ptr %68, align 8
  %211 = getelementptr inbounds nuw float, ptr %210, i32 1
  store ptr %211, ptr %68, align 8
  %212 = load volatile float, ptr %210, align 4
  store float %212, ptr %48, align 4
  %213 = load ptr, ptr %68, align 8
  %214 = getelementptr inbounds nuw float, ptr %213, i32 1
  store ptr %214, ptr %68, align 8
  %215 = load volatile float, ptr %213, align 4
  store float %215, ptr %49, align 4
  %216 = load ptr, ptr %68, align 8
  %217 = getelementptr inbounds nuw float, ptr %216, i32 1
  store ptr %217, ptr %68, align 8
  %218 = load volatile float, ptr %216, align 4
  store float %218, ptr %50, align 4
  %219 = load ptr, ptr %68, align 8
  %220 = getelementptr inbounds nuw float, ptr %219, i32 1
  store ptr %220, ptr %68, align 8
  %221 = load volatile float, ptr %219, align 4
  store float %221, ptr %51, align 4
  %222 = load ptr, ptr %68, align 8
  %223 = getelementptr inbounds nuw float, ptr %222, i32 1
  store ptr %223, ptr %68, align 8
  %224 = load volatile float, ptr %222, align 4
  store float %224, ptr %52, align 4
  %225 = load ptr, ptr %68, align 8
  %226 = getelementptr inbounds nuw float, ptr %225, i32 1
  store ptr %226, ptr %68, align 8
  %227 = load volatile float, ptr %225, align 4
  store float %227, ptr %53, align 4
  %228 = load ptr, ptr %68, align 8
  %229 = getelementptr inbounds nuw float, ptr %228, i32 1
  store ptr %229, ptr %68, align 8
  %230 = load volatile float, ptr %228, align 4
  store float %230, ptr %54, align 4
  %231 = load ptr, ptr %68, align 8
  %232 = getelementptr inbounds nuw float, ptr %231, i32 1
  store ptr %232, ptr %68, align 8
  %233 = load volatile float, ptr %231, align 4
  store float %233, ptr %55, align 4
  %234 = load ptr, ptr %68, align 8
  %235 = getelementptr inbounds nuw float, ptr %234, i32 1
  store ptr %235, ptr %68, align 8
  %236 = load volatile float, ptr %234, align 4
  store float %236, ptr %56, align 4
  %237 = load ptr, ptr %68, align 8
  %238 = getelementptr inbounds nuw float, ptr %237, i32 1
  store ptr %238, ptr %68, align 8
  %239 = load volatile float, ptr %237, align 4
  store float %239, ptr %57, align 4
  %240 = load ptr, ptr %68, align 8
  %241 = getelementptr inbounds nuw float, ptr %240, i32 1
  store ptr %241, ptr %68, align 8
  %242 = load volatile float, ptr %240, align 4
  store float %242, ptr %58, align 4
  %243 = load ptr, ptr %68, align 8
  %244 = getelementptr inbounds nuw float, ptr %243, i32 1
  store ptr %244, ptr %68, align 8
  %245 = load volatile float, ptr %243, align 4
  store float %245, ptr %59, align 4
  %246 = load ptr, ptr %68, align 8
  %247 = getelementptr inbounds nuw float, ptr %246, i32 1
  store ptr %247, ptr %68, align 8
  %248 = load volatile float, ptr %246, align 4
  store float %248, ptr %60, align 4
  %249 = load ptr, ptr %68, align 8
  %250 = getelementptr inbounds nuw float, ptr %249, i32 1
  store ptr %250, ptr %68, align 8
  %251 = load volatile float, ptr %249, align 4
  store float %251, ptr %61, align 4
  %252 = load ptr, ptr %68, align 8
  %253 = getelementptr inbounds nuw float, ptr %252, i32 1
  store ptr %253, ptr %68, align 8
  %254 = load volatile float, ptr %252, align 4
  store float %254, ptr %62, align 4
  %255 = load ptr, ptr %68, align 8
  %256 = getelementptr inbounds nuw float, ptr %255, i32 1
  store ptr %256, ptr %68, align 8
  %257 = load volatile float, ptr %255, align 4
  store float %257, ptr %63, align 4
  %258 = load ptr, ptr %68, align 8
  %259 = getelementptr inbounds nuw float, ptr %258, i32 1
  store ptr %259, ptr %68, align 8
  %260 = load volatile float, ptr %258, align 4
  store float %260, ptr %64, align 4
  %261 = load ptr, ptr %68, align 8
  %262 = getelementptr inbounds nuw float, ptr %261, i32 1
  store ptr %262, ptr %68, align 8
  %263 = load volatile float, ptr %261, align 4
  store float %263, ptr %65, align 4
  %264 = load ptr, ptr %68, align 8
  %265 = getelementptr inbounds nuw float, ptr %264, i32 1
  store ptr %265, ptr %68, align 8
  %266 = load volatile float, ptr %264, align 4
  store float %266, ptr %66, align 4
  store ptr @gd, ptr %67, align 8
  %267 = load ptr, ptr %67, align 8
  %268 = getelementptr inbounds nuw double, ptr %267, i32 1
  store ptr %268, ptr %67, align 8
  %269 = load volatile double, ptr %267, align 8
  %270 = load double, ptr %3, align 8
  %271 = fadd double %270, %269
  store double %271, ptr %3, align 8
  %272 = load ptr, ptr %67, align 8
  %273 = getelementptr inbounds nuw double, ptr %272, i32 1
  store ptr %273, ptr %67, align 8
  %274 = load volatile double, ptr %272, align 8
  %275 = load double, ptr %4, align 8
  %276 = fadd double %275, %274
  store double %276, ptr %4, align 8
  %277 = load ptr, ptr %67, align 8
  %278 = getelementptr inbounds nuw double, ptr %277, i32 1
  store ptr %278, ptr %67, align 8
  %279 = load volatile double, ptr %277, align 8
  %280 = load double, ptr %5, align 8
  %281 = fadd double %280, %279
  store double %281, ptr %5, align 8
  %282 = load ptr, ptr %67, align 8
  %283 = getelementptr inbounds nuw double, ptr %282, i32 1
  store ptr %283, ptr %67, align 8
  %284 = load volatile double, ptr %282, align 8
  %285 = load double, ptr %6, align 8
  %286 = fadd double %285, %284
  store double %286, ptr %6, align 8
  %287 = load ptr, ptr %67, align 8
  %288 = getelementptr inbounds nuw double, ptr %287, i32 1
  store ptr %288, ptr %67, align 8
  %289 = load volatile double, ptr %287, align 8
  %290 = load double, ptr %7, align 8
  %291 = fadd double %290, %289
  store double %291, ptr %7, align 8
  %292 = load ptr, ptr %67, align 8
  %293 = getelementptr inbounds nuw double, ptr %292, i32 1
  store ptr %293, ptr %67, align 8
  %294 = load volatile double, ptr %292, align 8
  %295 = load double, ptr %8, align 8
  %296 = fadd double %295, %294
  store double %296, ptr %8, align 8
  %297 = load ptr, ptr %67, align 8
  %298 = getelementptr inbounds nuw double, ptr %297, i32 1
  store ptr %298, ptr %67, align 8
  %299 = load volatile double, ptr %297, align 8
  %300 = load double, ptr %9, align 8
  %301 = fadd double %300, %299
  store double %301, ptr %9, align 8
  %302 = load ptr, ptr %67, align 8
  %303 = getelementptr inbounds nuw double, ptr %302, i32 1
  store ptr %303, ptr %67, align 8
  %304 = load volatile double, ptr %302, align 8
  %305 = load double, ptr %10, align 8
  %306 = fadd double %305, %304
  store double %306, ptr %10, align 8
  %307 = load ptr, ptr %67, align 8
  %308 = getelementptr inbounds nuw double, ptr %307, i32 1
  store ptr %308, ptr %67, align 8
  %309 = load volatile double, ptr %307, align 8
  %310 = load double, ptr %11, align 8
  %311 = fadd double %310, %309
  store double %311, ptr %11, align 8
  %312 = load ptr, ptr %67, align 8
  %313 = getelementptr inbounds nuw double, ptr %312, i32 1
  store ptr %313, ptr %67, align 8
  %314 = load volatile double, ptr %312, align 8
  %315 = load double, ptr %12, align 8
  %316 = fadd double %315, %314
  store double %316, ptr %12, align 8
  %317 = load ptr, ptr %67, align 8
  %318 = getelementptr inbounds nuw double, ptr %317, i32 1
  store ptr %318, ptr %67, align 8
  %319 = load volatile double, ptr %317, align 8
  %320 = load double, ptr %13, align 8
  %321 = fadd double %320, %319
  store double %321, ptr %13, align 8
  %322 = load ptr, ptr %67, align 8
  %323 = getelementptr inbounds nuw double, ptr %322, i32 1
  store ptr %323, ptr %67, align 8
  %324 = load volatile double, ptr %322, align 8
  %325 = load double, ptr %14, align 8
  %326 = fadd double %325, %324
  store double %326, ptr %14, align 8
  %327 = load ptr, ptr %67, align 8
  %328 = getelementptr inbounds nuw double, ptr %327, i32 1
  store ptr %328, ptr %67, align 8
  %329 = load volatile double, ptr %327, align 8
  %330 = load double, ptr %15, align 8
  %331 = fadd double %330, %329
  store double %331, ptr %15, align 8
  %332 = load ptr, ptr %67, align 8
  %333 = getelementptr inbounds nuw double, ptr %332, i32 1
  store ptr %333, ptr %67, align 8
  %334 = load volatile double, ptr %332, align 8
  %335 = load double, ptr %16, align 8
  %336 = fadd double %335, %334
  store double %336, ptr %16, align 8
  %337 = load ptr, ptr %67, align 8
  %338 = getelementptr inbounds nuw double, ptr %337, i32 1
  store ptr %338, ptr %67, align 8
  %339 = load volatile double, ptr %337, align 8
  %340 = load double, ptr %17, align 8
  %341 = fadd double %340, %339
  store double %341, ptr %17, align 8
  %342 = load ptr, ptr %67, align 8
  %343 = getelementptr inbounds nuw double, ptr %342, i32 1
  store ptr %343, ptr %67, align 8
  %344 = load volatile double, ptr %342, align 8
  %345 = load double, ptr %18, align 8
  %346 = fadd double %345, %344
  store double %346, ptr %18, align 8
  %347 = load ptr, ptr %67, align 8
  %348 = getelementptr inbounds nuw double, ptr %347, i32 1
  store ptr %348, ptr %67, align 8
  %349 = load volatile double, ptr %347, align 8
  %350 = load double, ptr %19, align 8
  %351 = fadd double %350, %349
  store double %351, ptr %19, align 8
  %352 = load ptr, ptr %67, align 8
  %353 = getelementptr inbounds nuw double, ptr %352, i32 1
  store ptr %353, ptr %67, align 8
  %354 = load volatile double, ptr %352, align 8
  %355 = load double, ptr %20, align 8
  %356 = fadd double %355, %354
  store double %356, ptr %20, align 8
  %357 = load ptr, ptr %67, align 8
  %358 = getelementptr inbounds nuw double, ptr %357, i32 1
  store ptr %358, ptr %67, align 8
  %359 = load volatile double, ptr %357, align 8
  %360 = load double, ptr %21, align 8
  %361 = fadd double %360, %359
  store double %361, ptr %21, align 8
  %362 = load ptr, ptr %67, align 8
  %363 = getelementptr inbounds nuw double, ptr %362, i32 1
  store ptr %363, ptr %67, align 8
  %364 = load volatile double, ptr %362, align 8
  %365 = load double, ptr %22, align 8
  %366 = fadd double %365, %364
  store double %366, ptr %22, align 8
  %367 = load ptr, ptr %67, align 8
  %368 = getelementptr inbounds nuw double, ptr %367, i32 1
  store ptr %368, ptr %67, align 8
  %369 = load volatile double, ptr %367, align 8
  %370 = load double, ptr %23, align 8
  %371 = fadd double %370, %369
  store double %371, ptr %23, align 8
  %372 = load ptr, ptr %67, align 8
  %373 = getelementptr inbounds nuw double, ptr %372, i32 1
  store ptr %373, ptr %67, align 8
  %374 = load volatile double, ptr %372, align 8
  %375 = load double, ptr %24, align 8
  %376 = fadd double %375, %374
  store double %376, ptr %24, align 8
  %377 = load ptr, ptr %67, align 8
  %378 = getelementptr inbounds nuw double, ptr %377, i32 1
  store ptr %378, ptr %67, align 8
  %379 = load volatile double, ptr %377, align 8
  %380 = load double, ptr %25, align 8
  %381 = fadd double %380, %379
  store double %381, ptr %25, align 8
  %382 = load ptr, ptr %67, align 8
  %383 = getelementptr inbounds nuw double, ptr %382, i32 1
  store ptr %383, ptr %67, align 8
  %384 = load volatile double, ptr %382, align 8
  %385 = load double, ptr %26, align 8
  %386 = fadd double %385, %384
  store double %386, ptr %26, align 8
  %387 = load ptr, ptr %67, align 8
  %388 = getelementptr inbounds nuw double, ptr %387, i32 1
  store ptr %388, ptr %67, align 8
  %389 = load volatile double, ptr %387, align 8
  %390 = load double, ptr %27, align 8
  %391 = fadd double %390, %389
  store double %391, ptr %27, align 8
  %392 = load ptr, ptr %67, align 8
  %393 = getelementptr inbounds nuw double, ptr %392, i32 1
  store ptr %393, ptr %67, align 8
  %394 = load volatile double, ptr %392, align 8
  %395 = load double, ptr %28, align 8
  %396 = fadd double %395, %394
  store double %396, ptr %28, align 8
  %397 = load ptr, ptr %67, align 8
  %398 = getelementptr inbounds nuw double, ptr %397, i32 1
  store ptr %398, ptr %67, align 8
  %399 = load volatile double, ptr %397, align 8
  %400 = load double, ptr %29, align 8
  %401 = fadd double %400, %399
  store double %401, ptr %29, align 8
  %402 = load ptr, ptr %67, align 8
  %403 = getelementptr inbounds nuw double, ptr %402, i32 1
  store ptr %403, ptr %67, align 8
  %404 = load volatile double, ptr %402, align 8
  %405 = load double, ptr %30, align 8
  %406 = fadd double %405, %404
  store double %406, ptr %30, align 8
  %407 = load ptr, ptr %67, align 8
  %408 = getelementptr inbounds nuw double, ptr %407, i32 1
  store ptr %408, ptr %67, align 8
  %409 = load volatile double, ptr %407, align 8
  %410 = load double, ptr %31, align 8
  %411 = fadd double %410, %409
  store double %411, ptr %31, align 8
  %412 = load ptr, ptr %67, align 8
  %413 = getelementptr inbounds nuw double, ptr %412, i32 1
  store ptr %413, ptr %67, align 8
  %414 = load volatile double, ptr %412, align 8
  %415 = load double, ptr %32, align 8
  %416 = fadd double %415, %414
  store double %416, ptr %32, align 8
  %417 = load ptr, ptr %67, align 8
  %418 = getelementptr inbounds nuw double, ptr %417, i32 1
  store ptr %418, ptr %67, align 8
  %419 = load volatile double, ptr %417, align 8
  %420 = load double, ptr %33, align 8
  %421 = fadd double %420, %419
  store double %421, ptr %33, align 8
  %422 = load ptr, ptr %67, align 8
  %423 = getelementptr inbounds nuw double, ptr %422, i32 1
  store ptr %423, ptr %67, align 8
  %424 = load volatile double, ptr %422, align 8
  %425 = load double, ptr %34, align 8
  %426 = fadd double %425, %424
  store double %426, ptr %34, align 8
  store ptr @gd, ptr %67, align 8
  %427 = load ptr, ptr %67, align 8
  %428 = getelementptr inbounds nuw double, ptr %427, i32 1
  store ptr %428, ptr %67, align 8
  %429 = load volatile double, ptr %427, align 8
  %430 = load double, ptr %3, align 8
  %431 = fadd double %430, %429
  store double %431, ptr %3, align 8
  %432 = load ptr, ptr %67, align 8
  %433 = getelementptr inbounds nuw double, ptr %432, i32 1
  store ptr %433, ptr %67, align 8
  %434 = load volatile double, ptr %432, align 8
  %435 = load double, ptr %4, align 8
  %436 = fadd double %435, %434
  store double %436, ptr %4, align 8
  %437 = load ptr, ptr %67, align 8
  %438 = getelementptr inbounds nuw double, ptr %437, i32 1
  store ptr %438, ptr %67, align 8
  %439 = load volatile double, ptr %437, align 8
  %440 = load double, ptr %5, align 8
  %441 = fadd double %440, %439
  store double %441, ptr %5, align 8
  %442 = load ptr, ptr %67, align 8
  %443 = getelementptr inbounds nuw double, ptr %442, i32 1
  store ptr %443, ptr %67, align 8
  %444 = load volatile double, ptr %442, align 8
  %445 = load double, ptr %6, align 8
  %446 = fadd double %445, %444
  store double %446, ptr %6, align 8
  %447 = load ptr, ptr %67, align 8
  %448 = getelementptr inbounds nuw double, ptr %447, i32 1
  store ptr %448, ptr %67, align 8
  %449 = load volatile double, ptr %447, align 8
  %450 = load double, ptr %7, align 8
  %451 = fadd double %450, %449
  store double %451, ptr %7, align 8
  %452 = load ptr, ptr %67, align 8
  %453 = getelementptr inbounds nuw double, ptr %452, i32 1
  store ptr %453, ptr %67, align 8
  %454 = load volatile double, ptr %452, align 8
  %455 = load double, ptr %8, align 8
  %456 = fadd double %455, %454
  store double %456, ptr %8, align 8
  %457 = load ptr, ptr %67, align 8
  %458 = getelementptr inbounds nuw double, ptr %457, i32 1
  store ptr %458, ptr %67, align 8
  %459 = load volatile double, ptr %457, align 8
  %460 = load double, ptr %9, align 8
  %461 = fadd double %460, %459
  store double %461, ptr %9, align 8
  %462 = load ptr, ptr %67, align 8
  %463 = getelementptr inbounds nuw double, ptr %462, i32 1
  store ptr %463, ptr %67, align 8
  %464 = load volatile double, ptr %462, align 8
  %465 = load double, ptr %10, align 8
  %466 = fadd double %465, %464
  store double %466, ptr %10, align 8
  %467 = load ptr, ptr %67, align 8
  %468 = getelementptr inbounds nuw double, ptr %467, i32 1
  store ptr %468, ptr %67, align 8
  %469 = load volatile double, ptr %467, align 8
  %470 = load double, ptr %11, align 8
  %471 = fadd double %470, %469
  store double %471, ptr %11, align 8
  %472 = load ptr, ptr %67, align 8
  %473 = getelementptr inbounds nuw double, ptr %472, i32 1
  store ptr %473, ptr %67, align 8
  %474 = load volatile double, ptr %472, align 8
  %475 = load double, ptr %12, align 8
  %476 = fadd double %475, %474
  store double %476, ptr %12, align 8
  %477 = load ptr, ptr %67, align 8
  %478 = getelementptr inbounds nuw double, ptr %477, i32 1
  store ptr %478, ptr %67, align 8
  %479 = load volatile double, ptr %477, align 8
  %480 = load double, ptr %13, align 8
  %481 = fadd double %480, %479
  store double %481, ptr %13, align 8
  %482 = load ptr, ptr %67, align 8
  %483 = getelementptr inbounds nuw double, ptr %482, i32 1
  store ptr %483, ptr %67, align 8
  %484 = load volatile double, ptr %482, align 8
  %485 = load double, ptr %14, align 8
  %486 = fadd double %485, %484
  store double %486, ptr %14, align 8
  %487 = load ptr, ptr %67, align 8
  %488 = getelementptr inbounds nuw double, ptr %487, i32 1
  store ptr %488, ptr %67, align 8
  %489 = load volatile double, ptr %487, align 8
  %490 = load double, ptr %15, align 8
  %491 = fadd double %490, %489
  store double %491, ptr %15, align 8
  %492 = load ptr, ptr %67, align 8
  %493 = getelementptr inbounds nuw double, ptr %492, i32 1
  store ptr %493, ptr %67, align 8
  %494 = load volatile double, ptr %492, align 8
  %495 = load double, ptr %16, align 8
  %496 = fadd double %495, %494
  store double %496, ptr %16, align 8
  %497 = load ptr, ptr %67, align 8
  %498 = getelementptr inbounds nuw double, ptr %497, i32 1
  store ptr %498, ptr %67, align 8
  %499 = load volatile double, ptr %497, align 8
  %500 = load double, ptr %17, align 8
  %501 = fadd double %500, %499
  store double %501, ptr %17, align 8
  %502 = load ptr, ptr %67, align 8
  %503 = getelementptr inbounds nuw double, ptr %502, i32 1
  store ptr %503, ptr %67, align 8
  %504 = load volatile double, ptr %502, align 8
  %505 = load double, ptr %18, align 8
  %506 = fadd double %505, %504
  store double %506, ptr %18, align 8
  %507 = load ptr, ptr %67, align 8
  %508 = getelementptr inbounds nuw double, ptr %507, i32 1
  store ptr %508, ptr %67, align 8
  %509 = load volatile double, ptr %507, align 8
  %510 = load double, ptr %19, align 8
  %511 = fadd double %510, %509
  store double %511, ptr %19, align 8
  %512 = load ptr, ptr %67, align 8
  %513 = getelementptr inbounds nuw double, ptr %512, i32 1
  store ptr %513, ptr %67, align 8
  %514 = load volatile double, ptr %512, align 8
  %515 = load double, ptr %20, align 8
  %516 = fadd double %515, %514
  store double %516, ptr %20, align 8
  %517 = load ptr, ptr %67, align 8
  %518 = getelementptr inbounds nuw double, ptr %517, i32 1
  store ptr %518, ptr %67, align 8
  %519 = load volatile double, ptr %517, align 8
  %520 = load double, ptr %21, align 8
  %521 = fadd double %520, %519
  store double %521, ptr %21, align 8
  %522 = load ptr, ptr %67, align 8
  %523 = getelementptr inbounds nuw double, ptr %522, i32 1
  store ptr %523, ptr %67, align 8
  %524 = load volatile double, ptr %522, align 8
  %525 = load double, ptr %22, align 8
  %526 = fadd double %525, %524
  store double %526, ptr %22, align 8
  %527 = load ptr, ptr %67, align 8
  %528 = getelementptr inbounds nuw double, ptr %527, i32 1
  store ptr %528, ptr %67, align 8
  %529 = load volatile double, ptr %527, align 8
  %530 = load double, ptr %23, align 8
  %531 = fadd double %530, %529
  store double %531, ptr %23, align 8
  %532 = load ptr, ptr %67, align 8
  %533 = getelementptr inbounds nuw double, ptr %532, i32 1
  store ptr %533, ptr %67, align 8
  %534 = load volatile double, ptr %532, align 8
  %535 = load double, ptr %24, align 8
  %536 = fadd double %535, %534
  store double %536, ptr %24, align 8
  %537 = load ptr, ptr %67, align 8
  %538 = getelementptr inbounds nuw double, ptr %537, i32 1
  store ptr %538, ptr %67, align 8
  %539 = load volatile double, ptr %537, align 8
  %540 = load double, ptr %25, align 8
  %541 = fadd double %540, %539
  store double %541, ptr %25, align 8
  %542 = load ptr, ptr %67, align 8
  %543 = getelementptr inbounds nuw double, ptr %542, i32 1
  store ptr %543, ptr %67, align 8
  %544 = load volatile double, ptr %542, align 8
  %545 = load double, ptr %26, align 8
  %546 = fadd double %545, %544
  store double %546, ptr %26, align 8
  %547 = load ptr, ptr %67, align 8
  %548 = getelementptr inbounds nuw double, ptr %547, i32 1
  store ptr %548, ptr %67, align 8
  %549 = load volatile double, ptr %547, align 8
  %550 = load double, ptr %27, align 8
  %551 = fadd double %550, %549
  store double %551, ptr %27, align 8
  %552 = load ptr, ptr %67, align 8
  %553 = getelementptr inbounds nuw double, ptr %552, i32 1
  store ptr %553, ptr %67, align 8
  %554 = load volatile double, ptr %552, align 8
  %555 = load double, ptr %28, align 8
  %556 = fadd double %555, %554
  store double %556, ptr %28, align 8
  %557 = load ptr, ptr %67, align 8
  %558 = getelementptr inbounds nuw double, ptr %557, i32 1
  store ptr %558, ptr %67, align 8
  %559 = load volatile double, ptr %557, align 8
  %560 = load double, ptr %29, align 8
  %561 = fadd double %560, %559
  store double %561, ptr %29, align 8
  %562 = load ptr, ptr %67, align 8
  %563 = getelementptr inbounds nuw double, ptr %562, i32 1
  store ptr %563, ptr %67, align 8
  %564 = load volatile double, ptr %562, align 8
  %565 = load double, ptr %30, align 8
  %566 = fadd double %565, %564
  store double %566, ptr %30, align 8
  %567 = load ptr, ptr %67, align 8
  %568 = getelementptr inbounds nuw double, ptr %567, i32 1
  store ptr %568, ptr %67, align 8
  %569 = load volatile double, ptr %567, align 8
  %570 = load double, ptr %31, align 8
  %571 = fadd double %570, %569
  store double %571, ptr %31, align 8
  %572 = load ptr, ptr %67, align 8
  %573 = getelementptr inbounds nuw double, ptr %572, i32 1
  store ptr %573, ptr %67, align 8
  %574 = load volatile double, ptr %572, align 8
  %575 = load double, ptr %32, align 8
  %576 = fadd double %575, %574
  store double %576, ptr %32, align 8
  %577 = load ptr, ptr %67, align 8
  %578 = getelementptr inbounds nuw double, ptr %577, i32 1
  store ptr %578, ptr %67, align 8
  %579 = load volatile double, ptr %577, align 8
  %580 = load double, ptr %33, align 8
  %581 = fadd double %580, %579
  store double %581, ptr %33, align 8
  %582 = load ptr, ptr %67, align 8
  %583 = getelementptr inbounds nuw double, ptr %582, i32 1
  store ptr %583, ptr %67, align 8
  %584 = load volatile double, ptr %582, align 8
  %585 = load double, ptr %34, align 8
  %586 = fadd double %585, %584
  store double %586, ptr %34, align 8
  store ptr @gd, ptr %67, align 8
  %587 = load ptr, ptr %67, align 8
  %588 = getelementptr inbounds nuw double, ptr %587, i32 1
  store ptr %588, ptr %67, align 8
  %589 = load volatile double, ptr %587, align 8
  %590 = load double, ptr %3, align 8
  %591 = fadd double %590, %589
  store double %591, ptr %3, align 8
  %592 = load ptr, ptr %67, align 8
  %593 = getelementptr inbounds nuw double, ptr %592, i32 1
  store ptr %593, ptr %67, align 8
  %594 = load volatile double, ptr %592, align 8
  %595 = load double, ptr %4, align 8
  %596 = fadd double %595, %594
  store double %596, ptr %4, align 8
  %597 = load ptr, ptr %67, align 8
  %598 = getelementptr inbounds nuw double, ptr %597, i32 1
  store ptr %598, ptr %67, align 8
  %599 = load volatile double, ptr %597, align 8
  %600 = load double, ptr %5, align 8
  %601 = fadd double %600, %599
  store double %601, ptr %5, align 8
  %602 = load ptr, ptr %67, align 8
  %603 = getelementptr inbounds nuw double, ptr %602, i32 1
  store ptr %603, ptr %67, align 8
  %604 = load volatile double, ptr %602, align 8
  %605 = load double, ptr %6, align 8
  %606 = fadd double %605, %604
  store double %606, ptr %6, align 8
  %607 = load ptr, ptr %67, align 8
  %608 = getelementptr inbounds nuw double, ptr %607, i32 1
  store ptr %608, ptr %67, align 8
  %609 = load volatile double, ptr %607, align 8
  %610 = load double, ptr %7, align 8
  %611 = fadd double %610, %609
  store double %611, ptr %7, align 8
  %612 = load ptr, ptr %67, align 8
  %613 = getelementptr inbounds nuw double, ptr %612, i32 1
  store ptr %613, ptr %67, align 8
  %614 = load volatile double, ptr %612, align 8
  %615 = load double, ptr %8, align 8
  %616 = fadd double %615, %614
  store double %616, ptr %8, align 8
  %617 = load ptr, ptr %67, align 8
  %618 = getelementptr inbounds nuw double, ptr %617, i32 1
  store ptr %618, ptr %67, align 8
  %619 = load volatile double, ptr %617, align 8
  %620 = load double, ptr %9, align 8
  %621 = fadd double %620, %619
  store double %621, ptr %9, align 8
  %622 = load ptr, ptr %67, align 8
  %623 = getelementptr inbounds nuw double, ptr %622, i32 1
  store ptr %623, ptr %67, align 8
  %624 = load volatile double, ptr %622, align 8
  %625 = load double, ptr %10, align 8
  %626 = fadd double %625, %624
  store double %626, ptr %10, align 8
  %627 = load ptr, ptr %67, align 8
  %628 = getelementptr inbounds nuw double, ptr %627, i32 1
  store ptr %628, ptr %67, align 8
  %629 = load volatile double, ptr %627, align 8
  %630 = load double, ptr %11, align 8
  %631 = fadd double %630, %629
  store double %631, ptr %11, align 8
  %632 = load ptr, ptr %67, align 8
  %633 = getelementptr inbounds nuw double, ptr %632, i32 1
  store ptr %633, ptr %67, align 8
  %634 = load volatile double, ptr %632, align 8
  %635 = load double, ptr %12, align 8
  %636 = fadd double %635, %634
  store double %636, ptr %12, align 8
  %637 = load ptr, ptr %67, align 8
  %638 = getelementptr inbounds nuw double, ptr %637, i32 1
  store ptr %638, ptr %67, align 8
  %639 = load volatile double, ptr %637, align 8
  %640 = load double, ptr %13, align 8
  %641 = fadd double %640, %639
  store double %641, ptr %13, align 8
  %642 = load ptr, ptr %67, align 8
  %643 = getelementptr inbounds nuw double, ptr %642, i32 1
  store ptr %643, ptr %67, align 8
  %644 = load volatile double, ptr %642, align 8
  %645 = load double, ptr %14, align 8
  %646 = fadd double %645, %644
  store double %646, ptr %14, align 8
  %647 = load ptr, ptr %67, align 8
  %648 = getelementptr inbounds nuw double, ptr %647, i32 1
  store ptr %648, ptr %67, align 8
  %649 = load volatile double, ptr %647, align 8
  %650 = load double, ptr %15, align 8
  %651 = fadd double %650, %649
  store double %651, ptr %15, align 8
  %652 = load ptr, ptr %67, align 8
  %653 = getelementptr inbounds nuw double, ptr %652, i32 1
  store ptr %653, ptr %67, align 8
  %654 = load volatile double, ptr %652, align 8
  %655 = load double, ptr %16, align 8
  %656 = fadd double %655, %654
  store double %656, ptr %16, align 8
  %657 = load ptr, ptr %67, align 8
  %658 = getelementptr inbounds nuw double, ptr %657, i32 1
  store ptr %658, ptr %67, align 8
  %659 = load volatile double, ptr %657, align 8
  %660 = load double, ptr %17, align 8
  %661 = fadd double %660, %659
  store double %661, ptr %17, align 8
  %662 = load ptr, ptr %67, align 8
  %663 = getelementptr inbounds nuw double, ptr %662, i32 1
  store ptr %663, ptr %67, align 8
  %664 = load volatile double, ptr %662, align 8
  %665 = load double, ptr %18, align 8
  %666 = fadd double %665, %664
  store double %666, ptr %18, align 8
  %667 = load ptr, ptr %67, align 8
  %668 = getelementptr inbounds nuw double, ptr %667, i32 1
  store ptr %668, ptr %67, align 8
  %669 = load volatile double, ptr %667, align 8
  %670 = load double, ptr %19, align 8
  %671 = fadd double %670, %669
  store double %671, ptr %19, align 8
  %672 = load ptr, ptr %67, align 8
  %673 = getelementptr inbounds nuw double, ptr %672, i32 1
  store ptr %673, ptr %67, align 8
  %674 = load volatile double, ptr %672, align 8
  %675 = load double, ptr %20, align 8
  %676 = fadd double %675, %674
  store double %676, ptr %20, align 8
  %677 = load ptr, ptr %67, align 8
  %678 = getelementptr inbounds nuw double, ptr %677, i32 1
  store ptr %678, ptr %67, align 8
  %679 = load volatile double, ptr %677, align 8
  %680 = load double, ptr %21, align 8
  %681 = fadd double %680, %679
  store double %681, ptr %21, align 8
  %682 = load ptr, ptr %67, align 8
  %683 = getelementptr inbounds nuw double, ptr %682, i32 1
  store ptr %683, ptr %67, align 8
  %684 = load volatile double, ptr %682, align 8
  %685 = load double, ptr %22, align 8
  %686 = fadd double %685, %684
  store double %686, ptr %22, align 8
  %687 = load ptr, ptr %67, align 8
  %688 = getelementptr inbounds nuw double, ptr %687, i32 1
  store ptr %688, ptr %67, align 8
  %689 = load volatile double, ptr %687, align 8
  %690 = load double, ptr %23, align 8
  %691 = fadd double %690, %689
  store double %691, ptr %23, align 8
  %692 = load ptr, ptr %67, align 8
  %693 = getelementptr inbounds nuw double, ptr %692, i32 1
  store ptr %693, ptr %67, align 8
  %694 = load volatile double, ptr %692, align 8
  %695 = load double, ptr %24, align 8
  %696 = fadd double %695, %694
  store double %696, ptr %24, align 8
  %697 = load ptr, ptr %67, align 8
  %698 = getelementptr inbounds nuw double, ptr %697, i32 1
  store ptr %698, ptr %67, align 8
  %699 = load volatile double, ptr %697, align 8
  %700 = load double, ptr %25, align 8
  %701 = fadd double %700, %699
  store double %701, ptr %25, align 8
  %702 = load ptr, ptr %67, align 8
  %703 = getelementptr inbounds nuw double, ptr %702, i32 1
  store ptr %703, ptr %67, align 8
  %704 = load volatile double, ptr %702, align 8
  %705 = load double, ptr %26, align 8
  %706 = fadd double %705, %704
  store double %706, ptr %26, align 8
  %707 = load ptr, ptr %67, align 8
  %708 = getelementptr inbounds nuw double, ptr %707, i32 1
  store ptr %708, ptr %67, align 8
  %709 = load volatile double, ptr %707, align 8
  %710 = load double, ptr %27, align 8
  %711 = fadd double %710, %709
  store double %711, ptr %27, align 8
  %712 = load ptr, ptr %67, align 8
  %713 = getelementptr inbounds nuw double, ptr %712, i32 1
  store ptr %713, ptr %67, align 8
  %714 = load volatile double, ptr %712, align 8
  %715 = load double, ptr %28, align 8
  %716 = fadd double %715, %714
  store double %716, ptr %28, align 8
  %717 = load ptr, ptr %67, align 8
  %718 = getelementptr inbounds nuw double, ptr %717, i32 1
  store ptr %718, ptr %67, align 8
  %719 = load volatile double, ptr %717, align 8
  %720 = load double, ptr %29, align 8
  %721 = fadd double %720, %719
  store double %721, ptr %29, align 8
  %722 = load ptr, ptr %67, align 8
  %723 = getelementptr inbounds nuw double, ptr %722, i32 1
  store ptr %723, ptr %67, align 8
  %724 = load volatile double, ptr %722, align 8
  %725 = load double, ptr %30, align 8
  %726 = fadd double %725, %724
  store double %726, ptr %30, align 8
  %727 = load ptr, ptr %67, align 8
  %728 = getelementptr inbounds nuw double, ptr %727, i32 1
  store ptr %728, ptr %67, align 8
  %729 = load volatile double, ptr %727, align 8
  %730 = load double, ptr %31, align 8
  %731 = fadd double %730, %729
  store double %731, ptr %31, align 8
  %732 = load ptr, ptr %67, align 8
  %733 = getelementptr inbounds nuw double, ptr %732, i32 1
  store ptr %733, ptr %67, align 8
  %734 = load volatile double, ptr %732, align 8
  %735 = load double, ptr %32, align 8
  %736 = fadd double %735, %734
  store double %736, ptr %32, align 8
  %737 = load ptr, ptr %67, align 8
  %738 = getelementptr inbounds nuw double, ptr %737, i32 1
  store ptr %738, ptr %67, align 8
  %739 = load volatile double, ptr %737, align 8
  %740 = load double, ptr %33, align 8
  %741 = fadd double %740, %739
  store double %741, ptr %33, align 8
  %742 = load ptr, ptr %67, align 8
  %743 = getelementptr inbounds nuw double, ptr %742, i32 1
  store ptr %743, ptr %67, align 8
  %744 = load volatile double, ptr %742, align 8
  %745 = load double, ptr %34, align 8
  %746 = fadd double %745, %744
  store double %746, ptr %34, align 8
  store ptr @gf, ptr %68, align 8
  %747 = load float, ptr %35, align 4
  %748 = load ptr, ptr %68, align 8
  %749 = getelementptr inbounds nuw float, ptr %748, i32 1
  store ptr %749, ptr %68, align 8
  store volatile float %747, ptr %748, align 4
  %750 = load float, ptr %36, align 4
  %751 = load ptr, ptr %68, align 8
  %752 = getelementptr inbounds nuw float, ptr %751, i32 1
  store ptr %752, ptr %68, align 8
  store volatile float %750, ptr %751, align 4
  %753 = load float, ptr %37, align 4
  %754 = load ptr, ptr %68, align 8
  %755 = getelementptr inbounds nuw float, ptr %754, i32 1
  store ptr %755, ptr %68, align 8
  store volatile float %753, ptr %754, align 4
  %756 = load float, ptr %38, align 4
  %757 = load ptr, ptr %68, align 8
  %758 = getelementptr inbounds nuw float, ptr %757, i32 1
  store ptr %758, ptr %68, align 8
  store volatile float %756, ptr %757, align 4
  %759 = load float, ptr %39, align 4
  %760 = load ptr, ptr %68, align 8
  %761 = getelementptr inbounds nuw float, ptr %760, i32 1
  store ptr %761, ptr %68, align 8
  store volatile float %759, ptr %760, align 4
  %762 = load float, ptr %40, align 4
  %763 = load ptr, ptr %68, align 8
  %764 = getelementptr inbounds nuw float, ptr %763, i32 1
  store ptr %764, ptr %68, align 8
  store volatile float %762, ptr %763, align 4
  %765 = load float, ptr %41, align 4
  %766 = load ptr, ptr %68, align 8
  %767 = getelementptr inbounds nuw float, ptr %766, i32 1
  store ptr %767, ptr %68, align 8
  store volatile float %765, ptr %766, align 4
  %768 = load float, ptr %42, align 4
  %769 = load ptr, ptr %68, align 8
  %770 = getelementptr inbounds nuw float, ptr %769, i32 1
  store ptr %770, ptr %68, align 8
  store volatile float %768, ptr %769, align 4
  %771 = load float, ptr %43, align 4
  %772 = load ptr, ptr %68, align 8
  %773 = getelementptr inbounds nuw float, ptr %772, i32 1
  store ptr %773, ptr %68, align 8
  store volatile float %771, ptr %772, align 4
  %774 = load float, ptr %44, align 4
  %775 = load ptr, ptr %68, align 8
  %776 = getelementptr inbounds nuw float, ptr %775, i32 1
  store ptr %776, ptr %68, align 8
  store volatile float %774, ptr %775, align 4
  %777 = load float, ptr %45, align 4
  %778 = load ptr, ptr %68, align 8
  %779 = getelementptr inbounds nuw float, ptr %778, i32 1
  store ptr %779, ptr %68, align 8
  store volatile float %777, ptr %778, align 4
  %780 = load float, ptr %46, align 4
  %781 = load ptr, ptr %68, align 8
  %782 = getelementptr inbounds nuw float, ptr %781, i32 1
  store ptr %782, ptr %68, align 8
  store volatile float %780, ptr %781, align 4
  %783 = load float, ptr %47, align 4
  %784 = load ptr, ptr %68, align 8
  %785 = getelementptr inbounds nuw float, ptr %784, i32 1
  store ptr %785, ptr %68, align 8
  store volatile float %783, ptr %784, align 4
  %786 = load float, ptr %48, align 4
  %787 = load ptr, ptr %68, align 8
  %788 = getelementptr inbounds nuw float, ptr %787, i32 1
  store ptr %788, ptr %68, align 8
  store volatile float %786, ptr %787, align 4
  %789 = load float, ptr %49, align 4
  %790 = load ptr, ptr %68, align 8
  %791 = getelementptr inbounds nuw float, ptr %790, i32 1
  store ptr %791, ptr %68, align 8
  store volatile float %789, ptr %790, align 4
  %792 = load float, ptr %50, align 4
  %793 = load ptr, ptr %68, align 8
  %794 = getelementptr inbounds nuw float, ptr %793, i32 1
  store ptr %794, ptr %68, align 8
  store volatile float %792, ptr %793, align 4
  %795 = load float, ptr %51, align 4
  %796 = load ptr, ptr %68, align 8
  %797 = getelementptr inbounds nuw float, ptr %796, i32 1
  store ptr %797, ptr %68, align 8
  store volatile float %795, ptr %796, align 4
  %798 = load float, ptr %52, align 4
  %799 = load ptr, ptr %68, align 8
  %800 = getelementptr inbounds nuw float, ptr %799, i32 1
  store ptr %800, ptr %68, align 8
  store volatile float %798, ptr %799, align 4
  %801 = load float, ptr %53, align 4
  %802 = load ptr, ptr %68, align 8
  %803 = getelementptr inbounds nuw float, ptr %802, i32 1
  store ptr %803, ptr %68, align 8
  store volatile float %801, ptr %802, align 4
  %804 = load float, ptr %54, align 4
  %805 = load ptr, ptr %68, align 8
  %806 = getelementptr inbounds nuw float, ptr %805, i32 1
  store ptr %806, ptr %68, align 8
  store volatile float %804, ptr %805, align 4
  %807 = load float, ptr %55, align 4
  %808 = load ptr, ptr %68, align 8
  %809 = getelementptr inbounds nuw float, ptr %808, i32 1
  store ptr %809, ptr %68, align 8
  store volatile float %807, ptr %808, align 4
  %810 = load float, ptr %56, align 4
  %811 = load ptr, ptr %68, align 8
  %812 = getelementptr inbounds nuw float, ptr %811, i32 1
  store ptr %812, ptr %68, align 8
  store volatile float %810, ptr %811, align 4
  %813 = load float, ptr %57, align 4
  %814 = load ptr, ptr %68, align 8
  %815 = getelementptr inbounds nuw float, ptr %814, i32 1
  store ptr %815, ptr %68, align 8
  store volatile float %813, ptr %814, align 4
  %816 = load float, ptr %58, align 4
  %817 = load ptr, ptr %68, align 8
  %818 = getelementptr inbounds nuw float, ptr %817, i32 1
  store ptr %818, ptr %68, align 8
  store volatile float %816, ptr %817, align 4
  %819 = load float, ptr %59, align 4
  %820 = load ptr, ptr %68, align 8
  %821 = getelementptr inbounds nuw float, ptr %820, i32 1
  store ptr %821, ptr %68, align 8
  store volatile float %819, ptr %820, align 4
  %822 = load float, ptr %60, align 4
  %823 = load ptr, ptr %68, align 8
  %824 = getelementptr inbounds nuw float, ptr %823, i32 1
  store ptr %824, ptr %68, align 8
  store volatile float %822, ptr %823, align 4
  %825 = load float, ptr %61, align 4
  %826 = load ptr, ptr %68, align 8
  %827 = getelementptr inbounds nuw float, ptr %826, i32 1
  store ptr %827, ptr %68, align 8
  store volatile float %825, ptr %826, align 4
  %828 = load float, ptr %62, align 4
  %829 = load ptr, ptr %68, align 8
  %830 = getelementptr inbounds nuw float, ptr %829, i32 1
  store ptr %830, ptr %68, align 8
  store volatile float %828, ptr %829, align 4
  %831 = load float, ptr %63, align 4
  %832 = load ptr, ptr %68, align 8
  %833 = getelementptr inbounds nuw float, ptr %832, i32 1
  store ptr %833, ptr %68, align 8
  store volatile float %831, ptr %832, align 4
  %834 = load float, ptr %64, align 4
  %835 = load ptr, ptr %68, align 8
  %836 = getelementptr inbounds nuw float, ptr %835, i32 1
  store ptr %836, ptr %68, align 8
  store volatile float %834, ptr %835, align 4
  %837 = load float, ptr %65, align 4
  %838 = load ptr, ptr %68, align 8
  %839 = getelementptr inbounds nuw float, ptr %838, i32 1
  store ptr %839, ptr %68, align 8
  store volatile float %837, ptr %838, align 4
  %840 = load float, ptr %66, align 4
  %841 = load ptr, ptr %68, align 8
  %842 = getelementptr inbounds nuw float, ptr %841, i32 1
  store ptr %842, ptr %68, align 8
  store volatile float %840, ptr %841, align 4
  br label %843

843:                                              ; preds = %170
  %844 = load i32, ptr %69, align 4
  %845 = add nsw i32 %844, 1
  store i32 %845, ptr %69, align 4
  br label %166, !llvm.loop !6

846:                                              ; preds = %166
  store ptr @gd, ptr %67, align 8
  %847 = load double, ptr %3, align 8
  %848 = load ptr, ptr %67, align 8
  %849 = getelementptr inbounds nuw double, ptr %848, i32 1
  store ptr %849, ptr %67, align 8
  store volatile double %847, ptr %848, align 8
  %850 = load double, ptr %4, align 8
  %851 = load ptr, ptr %67, align 8
  %852 = getelementptr inbounds nuw double, ptr %851, i32 1
  store ptr %852, ptr %67, align 8
  store volatile double %850, ptr %851, align 8
  %853 = load double, ptr %5, align 8
  %854 = load ptr, ptr %67, align 8
  %855 = getelementptr inbounds nuw double, ptr %854, i32 1
  store ptr %855, ptr %67, align 8
  store volatile double %853, ptr %854, align 8
  %856 = load double, ptr %6, align 8
  %857 = load ptr, ptr %67, align 8
  %858 = getelementptr inbounds nuw double, ptr %857, i32 1
  store ptr %858, ptr %67, align 8
  store volatile double %856, ptr %857, align 8
  %859 = load double, ptr %7, align 8
  %860 = load ptr, ptr %67, align 8
  %861 = getelementptr inbounds nuw double, ptr %860, i32 1
  store ptr %861, ptr %67, align 8
  store volatile double %859, ptr %860, align 8
  %862 = load double, ptr %8, align 8
  %863 = load ptr, ptr %67, align 8
  %864 = getelementptr inbounds nuw double, ptr %863, i32 1
  store ptr %864, ptr %67, align 8
  store volatile double %862, ptr %863, align 8
  %865 = load double, ptr %9, align 8
  %866 = load ptr, ptr %67, align 8
  %867 = getelementptr inbounds nuw double, ptr %866, i32 1
  store ptr %867, ptr %67, align 8
  store volatile double %865, ptr %866, align 8
  %868 = load double, ptr %10, align 8
  %869 = load ptr, ptr %67, align 8
  %870 = getelementptr inbounds nuw double, ptr %869, i32 1
  store ptr %870, ptr %67, align 8
  store volatile double %868, ptr %869, align 8
  %871 = load double, ptr %11, align 8
  %872 = load ptr, ptr %67, align 8
  %873 = getelementptr inbounds nuw double, ptr %872, i32 1
  store ptr %873, ptr %67, align 8
  store volatile double %871, ptr %872, align 8
  %874 = load double, ptr %12, align 8
  %875 = load ptr, ptr %67, align 8
  %876 = getelementptr inbounds nuw double, ptr %875, i32 1
  store ptr %876, ptr %67, align 8
  store volatile double %874, ptr %875, align 8
  %877 = load double, ptr %13, align 8
  %878 = load ptr, ptr %67, align 8
  %879 = getelementptr inbounds nuw double, ptr %878, i32 1
  store ptr %879, ptr %67, align 8
  store volatile double %877, ptr %878, align 8
  %880 = load double, ptr %14, align 8
  %881 = load ptr, ptr %67, align 8
  %882 = getelementptr inbounds nuw double, ptr %881, i32 1
  store ptr %882, ptr %67, align 8
  store volatile double %880, ptr %881, align 8
  %883 = load double, ptr %15, align 8
  %884 = load ptr, ptr %67, align 8
  %885 = getelementptr inbounds nuw double, ptr %884, i32 1
  store ptr %885, ptr %67, align 8
  store volatile double %883, ptr %884, align 8
  %886 = load double, ptr %16, align 8
  %887 = load ptr, ptr %67, align 8
  %888 = getelementptr inbounds nuw double, ptr %887, i32 1
  store ptr %888, ptr %67, align 8
  store volatile double %886, ptr %887, align 8
  %889 = load double, ptr %17, align 8
  %890 = load ptr, ptr %67, align 8
  %891 = getelementptr inbounds nuw double, ptr %890, i32 1
  store ptr %891, ptr %67, align 8
  store volatile double %889, ptr %890, align 8
  %892 = load double, ptr %18, align 8
  %893 = load ptr, ptr %67, align 8
  %894 = getelementptr inbounds nuw double, ptr %893, i32 1
  store ptr %894, ptr %67, align 8
  store volatile double %892, ptr %893, align 8
  %895 = load double, ptr %19, align 8
  %896 = load ptr, ptr %67, align 8
  %897 = getelementptr inbounds nuw double, ptr %896, i32 1
  store ptr %897, ptr %67, align 8
  store volatile double %895, ptr %896, align 8
  %898 = load double, ptr %20, align 8
  %899 = load ptr, ptr %67, align 8
  %900 = getelementptr inbounds nuw double, ptr %899, i32 1
  store ptr %900, ptr %67, align 8
  store volatile double %898, ptr %899, align 8
  %901 = load double, ptr %21, align 8
  %902 = load ptr, ptr %67, align 8
  %903 = getelementptr inbounds nuw double, ptr %902, i32 1
  store ptr %903, ptr %67, align 8
  store volatile double %901, ptr %902, align 8
  %904 = load double, ptr %22, align 8
  %905 = load ptr, ptr %67, align 8
  %906 = getelementptr inbounds nuw double, ptr %905, i32 1
  store ptr %906, ptr %67, align 8
  store volatile double %904, ptr %905, align 8
  %907 = load double, ptr %23, align 8
  %908 = load ptr, ptr %67, align 8
  %909 = getelementptr inbounds nuw double, ptr %908, i32 1
  store ptr %909, ptr %67, align 8
  store volatile double %907, ptr %908, align 8
  %910 = load double, ptr %24, align 8
  %911 = load ptr, ptr %67, align 8
  %912 = getelementptr inbounds nuw double, ptr %911, i32 1
  store ptr %912, ptr %67, align 8
  store volatile double %910, ptr %911, align 8
  %913 = load double, ptr %25, align 8
  %914 = load ptr, ptr %67, align 8
  %915 = getelementptr inbounds nuw double, ptr %914, i32 1
  store ptr %915, ptr %67, align 8
  store volatile double %913, ptr %914, align 8
  %916 = load double, ptr %26, align 8
  %917 = load ptr, ptr %67, align 8
  %918 = getelementptr inbounds nuw double, ptr %917, i32 1
  store ptr %918, ptr %67, align 8
  store volatile double %916, ptr %917, align 8
  %919 = load double, ptr %27, align 8
  %920 = load ptr, ptr %67, align 8
  %921 = getelementptr inbounds nuw double, ptr %920, i32 1
  store ptr %921, ptr %67, align 8
  store volatile double %919, ptr %920, align 8
  %922 = load double, ptr %28, align 8
  %923 = load ptr, ptr %67, align 8
  %924 = getelementptr inbounds nuw double, ptr %923, i32 1
  store ptr %924, ptr %67, align 8
  store volatile double %922, ptr %923, align 8
  %925 = load double, ptr %29, align 8
  %926 = load ptr, ptr %67, align 8
  %927 = getelementptr inbounds nuw double, ptr %926, i32 1
  store ptr %927, ptr %67, align 8
  store volatile double %925, ptr %926, align 8
  %928 = load double, ptr %30, align 8
  %929 = load ptr, ptr %67, align 8
  %930 = getelementptr inbounds nuw double, ptr %929, i32 1
  store ptr %930, ptr %67, align 8
  store volatile double %928, ptr %929, align 8
  %931 = load double, ptr %31, align 8
  %932 = load ptr, ptr %67, align 8
  %933 = getelementptr inbounds nuw double, ptr %932, i32 1
  store ptr %933, ptr %67, align 8
  store volatile double %931, ptr %932, align 8
  %934 = load double, ptr %32, align 8
  %935 = load ptr, ptr %67, align 8
  %936 = getelementptr inbounds nuw double, ptr %935, i32 1
  store ptr %936, ptr %67, align 8
  store volatile double %934, ptr %935, align 8
  %937 = load double, ptr %33, align 8
  %938 = load ptr, ptr %67, align 8
  %939 = getelementptr inbounds nuw double, ptr %938, i32 1
  store ptr %939, ptr %67, align 8
  store volatile double %937, ptr %938, align 8
  %940 = load double, ptr %34, align 8
  %941 = load ptr, ptr %67, align 8
  %942 = getelementptr inbounds nuw double, ptr %941, i32 1
  store ptr %942, ptr %67, align 8
  store volatile double %940, ptr %941, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr %2, align 4
  br label %3

3:                                                ; preds = %17, %0
  %4 = load i32, ptr %2, align 4
  %5 = icmp slt i32 %4, 32
  br i1 %5, label %6, label %20

6:                                                ; preds = %3
  %7 = load i32, ptr %2, align 4
  %8 = sitofp i32 %7 to double
  %9 = load i32, ptr %2, align 4
  %10 = sext i32 %9 to i64
  %11 = getelementptr inbounds [32 x double], ptr @gd, i64 0, i64 %10
  store volatile double %8, ptr %11, align 8
  %12 = load i32, ptr %2, align 4
  %13 = sitofp i32 %12 to float
  %14 = load i32, ptr %2, align 4
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds [32 x float], ptr @gf, i64 0, i64 %15
  store volatile float %13, ptr %16, align 4
  br label %17

17:                                               ; preds = %6
  %18 = load i32, ptr %2, align 4
  %19 = add nsw i32 %18, 1
  store i32 %19, ptr %2, align 4
  br label %3, !llvm.loop !8

20:                                               ; preds = %3
  call void @foo(i32 noundef 1)
  store i32 0, ptr %2, align 4
  br label %21

21:                                               ; preds = %43, %20
  %22 = load i32, ptr %2, align 4
  %23 = icmp slt i32 %22, 32
  br i1 %23, label %24, label %46

24:                                               ; preds = %21
  %25 = load i32, ptr %2, align 4
  %26 = sext i32 %25 to i64
  %27 = getelementptr inbounds [32 x double], ptr @gd, i64 0, i64 %26
  %28 = load volatile double, ptr %27, align 8
  %29 = load i32, ptr %2, align 4
  %30 = mul nsw i32 %29, 4
  %31 = sitofp i32 %30 to double
  %32 = fcmp une double %28, %31
  br i1 %32, label %41, label %33

33:                                               ; preds = %24
  %34 = load i32, ptr %2, align 4
  %35 = sext i32 %34 to i64
  %36 = getelementptr inbounds [32 x float], ptr @gf, i64 0, i64 %35
  %37 = load volatile float, ptr %36, align 4
  %38 = load i32, ptr %2, align 4
  %39 = sitofp i32 %38 to float
  %40 = fcmp une float %37, %39
  br i1 %40, label %41, label %42

41:                                               ; preds = %33, %24
  call void @abort() #3
  unreachable

42:                                               ; preds = %33
  br label %43

43:                                               ; preds = %42
  %44 = load i32, ptr %2, align 4
  %45 = add nsw i32 %44, 1
  store i32 %45, ptr %2, align 4
  br label %21, !llvm.loop !9

46:                                               ; preds = %21
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
