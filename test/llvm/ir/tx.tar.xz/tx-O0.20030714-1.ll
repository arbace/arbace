; ModuleID = '20030714-1.c'
source_filename = "20030714-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.RenderBox = type { [6 x i32], i16, i16, ptr }
%struct.RenderStyle = type { %struct.NonInheritedFlags }
%struct.NonInheritedFlags = type { %union.anon }
%union.anon = type { %struct.anon }
%struct.anon = type { i32 }

@false = dso_local constant i8 0, align 1
@true = dso_local constant i8 1, align 1
@g_this = dso_local global %struct.RenderBox zeroinitializer, align 8
@g__style = dso_local global %struct.RenderStyle zeroinitializer, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @RenderBox_setStyle(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i8, align 1
  %7 = alloca i8, align 1
  %8 = alloca i32, align 4
  %9 = alloca i8, align 1
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i8, align 1
  %13 = alloca i8, align 1
  %14 = alloca i8, align 1
  %15 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %16 = load ptr, ptr %3, align 8
  store ptr %16, ptr %5, align 8
  %17 = load ptr, ptr %5, align 8
  %18 = getelementptr inbounds nuw %struct.RenderBox, ptr %17, i32 0, i32 2
  %19 = load i16, ptr %18, align 2
  %20 = lshr i16 %19, 4
  %21 = and i16 %20, 1
  %22 = trunc i16 %21 to i1
  %23 = zext i1 %22 to i8
  store i8 %23, ptr %7, align 1
  %24 = load i8, ptr %7, align 1
  %25 = icmp ne i8 %24, 0
  %26 = zext i1 %25 to i8
  store i8 %26, ptr %6, align 1
  %27 = load ptr, ptr %5, align 8
  %28 = load ptr, ptr %4, align 8
  call void @RenderObject_setStyle(ptr noundef %27, ptr noundef %28)
  %29 = load ptr, ptr %4, align 8
  %30 = getelementptr inbounds nuw %struct.RenderStyle, ptr %29, i32 0, i32 0
  %31 = getelementptr inbounds nuw %struct.NonInheritedFlags, ptr %30, i32 0, i32 0
  %32 = load i32, ptr %31, align 4
  %33 = lshr i32 %32, 17
  %34 = and i32 %33, 3
  store i32 %34, ptr %8, align 4
  %35 = load i32, ptr %8, align 4
  switch i32 %35, label %48 [
    i32 2, label %36
    i32 3, label %36
  ]

36:                                               ; preds = %2, %2
  store i8 1, ptr %9, align 1
  %37 = load i8, ptr %9, align 1
  %38 = icmp ne i8 %37, 0
  %39 = load ptr, ptr %5, align 8
  %40 = getelementptr inbounds nuw %struct.RenderBox, ptr %39, i32 0, i32 2
  %41 = zext i1 %38 to i16
  %42 = load i16, ptr %40, align 2
  %43 = shl i16 %41, 4
  %44 = and i16 %42, -17
  %45 = or i16 %44, %43
  store i16 %45, ptr %40, align 2
  %46 = trunc i16 %41 to i8
  %47 = icmp ne i8 %46, 0
  br label %125

48:                                               ; preds = %2
  %49 = load i8, ptr %6, align 1
  %50 = icmp ne i8 %49, 0
  br i1 %50, label %51, label %64

51:                                               ; preds = %48
  store i8 1, ptr %12, align 1
  %52 = load i8, ptr %12, align 1
  %53 = icmp ne i8 %52, 0
  %54 = load ptr, ptr %5, align 8
  %55 = getelementptr inbounds nuw %struct.RenderBox, ptr %54, i32 0, i32 2
  %56 = zext i1 %53 to i16
  %57 = load i16, ptr %55, align 2
  %58 = shl i16 %56, 4
  %59 = and i16 %57, -17
  %60 = or i16 %59, %58
  store i16 %60, ptr %55, align 2
  %61 = trunc i16 %56 to i8
  %62 = icmp ne i8 %61, 0
  %63 = load ptr, ptr %5, align 8
  call void @removeFromSpecialObjects(ptr noundef %63)
  br label %64

64:                                               ; preds = %51, %48
  store i8 0, ptr %13, align 1
  %65 = load i8, ptr %13, align 1
  %66 = icmp ne i8 %65, 0
  %67 = load ptr, ptr %5, align 8
  %68 = getelementptr inbounds nuw %struct.RenderBox, ptr %67, i32 0, i32 2
  %69 = zext i1 %66 to i16
  %70 = load i16, ptr %68, align 2
  %71 = shl i16 %69, 4
  %72 = and i16 %70, -17
  %73 = or i16 %72, %71
  store i16 %73, ptr %68, align 2
  %74 = trunc i16 %69 to i8
  %75 = icmp ne i8 %74, 0
  %76 = load ptr, ptr %4, align 8
  %77 = getelementptr inbounds nuw %struct.RenderStyle, ptr %76, i32 0, i32 0
  %78 = getelementptr inbounds nuw %struct.NonInheritedFlags, ptr %77, i32 0, i32 0
  %79 = load i32, ptr %78, align 4
  %80 = lshr i32 %79, 19
  %81 = and i32 %80, 3
  store i32 %81, ptr %10, align 4
  %82 = load ptr, ptr %5, align 8
  %83 = getelementptr inbounds nuw %struct.RenderBox, ptr %82, i32 0, i32 3
  %84 = load ptr, ptr %83, align 8
  %85 = load ptr, ptr %5, align 8
  %86 = call zeroext i1 %84(ptr noundef %85)
  br i1 %86, label %102, label %87

87:                                               ; preds = %64
  %88 = load i32, ptr %10, align 4
  %89 = icmp eq i32 %88, 0
  br i1 %89, label %102, label %90

90:                                               ; preds = %87
  store i8 1, ptr %14, align 1
  %91 = load i8, ptr %14, align 1
  %92 = icmp ne i8 %91, 0
  %93 = load ptr, ptr %5, align 8
  %94 = getelementptr inbounds nuw %struct.RenderBox, ptr %93, i32 0, i32 2
  %95 = zext i1 %92 to i16
  %96 = load i16, ptr %94, align 2
  %97 = shl i16 %95, 3
  %98 = and i16 %96, -9
  %99 = or i16 %98, %97
  store i16 %99, ptr %94, align 2
  %100 = trunc i16 %95 to i8
  %101 = icmp ne i8 %100, 0
  br label %124

102:                                              ; preds = %87, %64
  %103 = load ptr, ptr %4, align 8
  %104 = getelementptr inbounds nuw %struct.RenderStyle, ptr %103, i32 0, i32 0
  %105 = getelementptr inbounds nuw %struct.NonInheritedFlags, ptr %104, i32 0, i32 0
  %106 = load i32, ptr %105, align 4
  %107 = lshr i32 %106, 17
  %108 = and i32 %107, 3
  store i32 %108, ptr %11, align 4
  %109 = load i32, ptr %11, align 4
  %110 = icmp eq i32 %109, 1
  br i1 %110, label %111, label %123

111:                                              ; preds = %102
  store i8 1, ptr %15, align 1
  %112 = load i8, ptr %15, align 1
  %113 = icmp ne i8 %112, 0
  %114 = load ptr, ptr %5, align 8
  %115 = getelementptr inbounds nuw %struct.RenderBox, ptr %114, i32 0, i32 2
  %116 = zext i1 %113 to i16
  %117 = load i16, ptr %115, align 2
  %118 = shl i16 %116, 6
  %119 = and i16 %117, -65
  %120 = or i16 %119, %118
  store i16 %120, ptr %115, align 2
  %121 = trunc i16 %116 to i8
  %122 = icmp ne i8 %121, 0
  br label %123

123:                                              ; preds = %111, %102
  br label %124

124:                                              ; preds = %123, %90
  br label %125

125:                                              ; preds = %124, %36
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @RenderObject_setStyle(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load ptr, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @removeFromSpecialObjects(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local zeroext i1 @RenderBox_isTableCell(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  ret i1 false
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %3 = and i16 %2, -65
  %4 = or i16 %3, 0
  store i16 %4, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %5 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %6 = and i16 %5, -17
  %7 = or i16 %6, 0
  store i16 %7, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %8 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %9 = and i16 %8, -9
  %10 = or i16 %9, 0
  store i16 %10, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  store ptr @RenderBox_isTableCell, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 32), align 8
  %11 = load i32, ptr @g__style, align 4
  %12 = and i32 %11, -393217
  %13 = or i32 %12, 393216
  store i32 %13, ptr @g__style, align 4
  %14 = load i32, ptr @g__style, align 4
  %15 = and i32 %14, -1572865
  %16 = or i32 %15, 0
  store i32 %16, ptr @g__style, align 4
  call void @RenderBox_setStyle(ptr noundef @g_this, ptr noundef @g__style)
  %17 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %18 = lshr i16 %17, 4
  %19 = and i16 %18, 1
  %20 = trunc i16 %19 to i1
  %21 = zext i1 %20 to i32
  %22 = icmp ne i32 %21, 1
  br i1 %22, label %23, label %24

23:                                               ; preds = %0
  call void @abort() #3
  unreachable

24:                                               ; preds = %0
  %25 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %26 = lshr i16 %25, 6
  %27 = and i16 %26, 1
  %28 = trunc i16 %27 to i1
  %29 = zext i1 %28 to i32
  %30 = icmp ne i32 %29, 0
  br i1 %30, label %31, label %32

31:                                               ; preds = %24
  call void @abort() #3
  unreachable

32:                                               ; preds = %24
  %33 = load i16, ptr getelementptr inbounds nuw (i8, ptr @g_this, i64 26), align 2
  %34 = lshr i16 %33, 3
  %35 = and i16 %34, 1
  %36 = trunc i16 %35 to i1
  %37 = zext i1 %36 to i32
  %38 = icmp ne i32 %37, 0
  br i1 %38, label %39, label %40

39:                                               ; preds = %32
  call void @abort() #3
  unreachable

40:                                               ; preds = %32
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
