; ModuleID = '20171008-1.c'
source_filename = "20171008-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i8, i8, i8, i8 }

@i = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.S, align 4
  store i32 0, ptr %1, align 4
  %3 = call i32 @foo()
  store i32 %3, ptr %2, align 4
  %4 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 0
  %5 = load i8, ptr %4, align 4
  %6 = sext i8 %5 to i32
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %8, label %9

8:                                                ; preds = %0
  call void @abort() #2
  unreachable

9:                                                ; preds = %0
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @foo() #0 {
  %1 = alloca %struct.S, align 4
  %2 = alloca i8, align 1
  %3 = alloca i8, align 1
  %4 = alloca i8, align 1
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  store ptr %2, ptr %6, align 8
  %7 = call signext i8 @bar(ptr noundef %6)
  store i8 %7, ptr %3, align 1
  %8 = load i8, ptr %3, align 1
  %9 = icmp ne i8 %8, 0
  br i1 %9, label %10, label %13

10:                                               ; preds = %0
  %11 = load ptr, ptr %6, align 8
  %12 = load i8, ptr %11, align 1
  store i8 %12, ptr %5, align 1
  br label %13

13:                                               ; preds = %10, %0
  store i8 0, ptr %4, align 1
  %14 = load i8, ptr %4, align 1
  %15 = getelementptr inbounds nuw %struct.S, ptr %1, i32 0, i32 0
  store i8 %14, ptr %15, align 4
  %16 = load i8, ptr %5, align 1
  %17 = getelementptr inbounds nuw %struct.S, ptr %1, i32 0, i32 1
  store i8 %16, ptr %17, align 1
  %18 = load i32, ptr %1, align 4
  ret i32 %18
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal signext i8 @bar(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  store i32 1, ptr @i, align 4
  ret i8 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
