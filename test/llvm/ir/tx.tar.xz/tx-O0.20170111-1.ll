; ModuleID = '20170111-1.c'
source_filename = "20170111-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i16, i64, i16, i8, i16, ptr }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i64, align 8
  %3 = alloca %struct.S, align 8
  store i32 0, ptr %1, align 4
  store i64 1, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 0
  store i16 0, ptr %4, align 8
  %5 = getelementptr i8, ptr %3, i64 2
  call void @llvm.memset.p0.i64(ptr align 2 %5, i8 0, i64 6, i1 false)
  %6 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 1
  store i64 0, ptr %6, align 8
  %7 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 2
  store i16 0, ptr %7, align 8
  %8 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 3
  store i8 0, ptr %8, align 2
  %9 = getelementptr i8, ptr %3, i64 19
  call void @llvm.memset.p0.i64(ptr align 1 %9, i8 0, i64 1, i1 false)
  %10 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 4
  store i16 2, ptr %10, align 4
  %11 = getelementptr i8, ptr %3, i64 22
  call void @llvm.memset.p0.i64(ptr align 2 %11, i8 0, i64 2, i1 false)
  %12 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 5
  store ptr %2, ptr %12, align 8
  %13 = call i64 @foo(ptr noundef %3)
  store i64 %13, ptr %2, align 8
  %14 = load i64, ptr %2, align 8
  %15 = icmp ne i64 %14, 0
  br i1 %15, label %16, label %17

16:                                               ; preds = %0
  call void @abort() #3
  unreachable

17:                                               ; preds = %0
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @foo(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  store i64 1, ptr %3, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds nuw %struct.S, ptr %4, i32 0, i32 4
  %6 = load i16, ptr %5, align 4
  %7 = zext i16 %6 to i64
  %8 = load i64, ptr %3, align 8
  %9 = sdiv i64 %8, %7
  store i64 %9, ptr %3, align 8
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds nuw %struct.S, ptr %10, i32 0, i32 5
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %3, align 8
  %14 = getelementptr inbounds i64, ptr %12, i64 %13
  %15 = load i64, ptr %14, align 8
  %16 = add nsw i64 %15, -1
  store i64 %16, ptr %14, align 8
  %17 = load i64, ptr %3, align 8
  ret i64 %17
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
