; ModuleID = '20001203-2.c'
source_filename = "20001203-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.type = type { i32, ptr, i16, ptr }
%struct.objfile = type { ptr, %struct.obstack }
%struct.obstack = type { i64, ptr, ptr, ptr, ptr, i32, i32 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @create_array_type(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca ptr, align 8
  %11 = alloca ptr, align 8
  %12 = alloca ptr, align 8
  %13 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %14 = load ptr, ptr %3, align 8
  %15 = icmp eq ptr %14, null
  br i1 %15, label %16, label %18

16:                                               ; preds = %2
  %17 = call ptr @alloc_type()
  store ptr %17, ptr %3, align 8
  br label %18

18:                                               ; preds = %16, %2
  call void @get_discrete_bounds(ptr noundef %5, ptr noundef %6)
  %19 = load ptr, ptr %4, align 8
  %20 = getelementptr inbounds nuw %struct.type, ptr %19, i32 0, i32 0
  %21 = load i32, ptr %20, align 8
  %22 = zext i32 %21 to i64
  %23 = load i64, ptr %6, align 8
  %24 = load i64, ptr %5, align 8
  %25 = sub nsw i64 %23, %24
  %26 = add nsw i64 %25, 1
  %27 = mul nsw i64 %22, %26
  %28 = trunc i64 %27 to i32
  %29 = load ptr, ptr %3, align 8
  %30 = getelementptr inbounds nuw %struct.type, ptr %29, i32 0, i32 0
  store i32 %28, ptr %30, align 8
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.type, ptr %31, i32 0, i32 2
  store i16 1, ptr %32, align 8
  %33 = load ptr, ptr %3, align 8
  %34 = getelementptr inbounds nuw %struct.type, ptr %33, i32 0, i32 1
  %35 = load ptr, ptr %34, align 8
  %36 = icmp ne ptr %35, null
  br i1 %36, label %37, label %131

37:                                               ; preds = %18
  %38 = load ptr, ptr %3, align 8
  %39 = getelementptr inbounds nuw %struct.type, ptr %38, i32 0, i32 1
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds nuw %struct.objfile, ptr %40, i32 0, i32 1
  store ptr %41, ptr %7, align 8
  %42 = load ptr, ptr %7, align 8
  store ptr %42, ptr %8, align 8
  store i32 32, ptr %9, align 4
  %43 = load ptr, ptr %8, align 8
  %44 = getelementptr inbounds nuw %struct.obstack, ptr %43, i32 0, i32 4
  %45 = load ptr, ptr %44, align 8
  %46 = load ptr, ptr %8, align 8
  %47 = getelementptr inbounds nuw %struct.obstack, ptr %46, i32 0, i32 3
  %48 = load ptr, ptr %47, align 8
  %49 = ptrtoint ptr %45 to i64
  %50 = ptrtoint ptr %48 to i64
  %51 = sub i64 %49, %50
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = icmp slt i64 %51, %53
  br i1 %54, label %55, label %58

55:                                               ; preds = %37
  %56 = load ptr, ptr %8, align 8
  %57 = load i32, ptr %9, align 4
  call void @_obstack_newchunk(ptr noundef %56, i32 noundef %57)
  br label %58

58:                                               ; preds = %55, %37
  %59 = load i32, ptr %9, align 4
  %60 = load ptr, ptr %8, align 8
  %61 = getelementptr inbounds nuw %struct.obstack, ptr %60, i32 0, i32 3
  %62 = load ptr, ptr %61, align 8
  %63 = sext i32 %59 to i64
  %64 = getelementptr inbounds i8, ptr %62, i64 %63
  store ptr %64, ptr %61, align 8
  %65 = load ptr, ptr %7, align 8
  store ptr %65, ptr %11, align 8
  %66 = load ptr, ptr %11, align 8
  %67 = getelementptr inbounds nuw %struct.obstack, ptr %66, i32 0, i32 2
  %68 = load ptr, ptr %67, align 8
  store ptr %68, ptr %12, align 8
  %69 = load ptr, ptr %11, align 8
  %70 = getelementptr inbounds nuw %struct.obstack, ptr %69, i32 0, i32 3
  %71 = load ptr, ptr %70, align 8
  %72 = load ptr, ptr %12, align 8
  %73 = icmp eq ptr %71, %72
  br i1 %73, label %74, label %77

74:                                               ; preds = %58
  %75 = load ptr, ptr %11, align 8
  %76 = getelementptr inbounds nuw %struct.obstack, ptr %75, i32 0, i32 6
  store i32 1, ptr %76, align 4
  br label %77

77:                                               ; preds = %74, %58
  %78 = load ptr, ptr %11, align 8
  %79 = getelementptr inbounds nuw %struct.obstack, ptr %78, i32 0, i32 3
  %80 = load ptr, ptr %79, align 8
  %81 = ptrtoint ptr %80 to i64
  %82 = sub i64 %81, 0
  %83 = load ptr, ptr %11, align 8
  %84 = getelementptr inbounds nuw %struct.obstack, ptr %83, i32 0, i32 5
  %85 = load i32, ptr %84, align 8
  %86 = sext i32 %85 to i64
  %87 = add nsw i64 %82, %86
  %88 = load ptr, ptr %11, align 8
  %89 = getelementptr inbounds nuw %struct.obstack, ptr %88, i32 0, i32 5
  %90 = load i32, ptr %89, align 8
  %91 = xor i32 %90, -1
  %92 = sext i32 %91 to i64
  %93 = and i64 %87, %92
  %94 = inttoptr i64 %93 to ptr
  %95 = load ptr, ptr %11, align 8
  %96 = getelementptr inbounds nuw %struct.obstack, ptr %95, i32 0, i32 3
  store ptr %94, ptr %96, align 8
  %97 = load ptr, ptr %11, align 8
  %98 = getelementptr inbounds nuw %struct.obstack, ptr %97, i32 0, i32 3
  %99 = load ptr, ptr %98, align 8
  %100 = load ptr, ptr %11, align 8
  %101 = getelementptr inbounds nuw %struct.obstack, ptr %100, i32 0, i32 1
  %102 = load ptr, ptr %101, align 8
  %103 = ptrtoint ptr %99 to i64
  %104 = ptrtoint ptr %102 to i64
  %105 = sub i64 %103, %104
  %106 = load ptr, ptr %11, align 8
  %107 = getelementptr inbounds nuw %struct.obstack, ptr %106, i32 0, i32 4
  %108 = load ptr, ptr %107, align 8
  %109 = load ptr, ptr %11, align 8
  %110 = getelementptr inbounds nuw %struct.obstack, ptr %109, i32 0, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = ptrtoint ptr %108 to i64
  %113 = ptrtoint ptr %111 to i64
  %114 = sub i64 %112, %113
  %115 = icmp sgt i64 %105, %114
  br i1 %115, label %116, label %122

116:                                              ; preds = %77
  %117 = load ptr, ptr %11, align 8
  %118 = getelementptr inbounds nuw %struct.obstack, ptr %117, i32 0, i32 4
  %119 = load ptr, ptr %118, align 8
  %120 = load ptr, ptr %11, align 8
  %121 = getelementptr inbounds nuw %struct.obstack, ptr %120, i32 0, i32 3
  store ptr %119, ptr %121, align 8
  br label %122

122:                                              ; preds = %116, %77
  %123 = load ptr, ptr %11, align 8
  %124 = getelementptr inbounds nuw %struct.obstack, ptr %123, i32 0, i32 3
  %125 = load ptr, ptr %124, align 8
  %126 = load ptr, ptr %11, align 8
  %127 = getelementptr inbounds nuw %struct.obstack, ptr %126, i32 0, i32 2
  store ptr %125, ptr %127, align 8
  %128 = load ptr, ptr %12, align 8
  store ptr %128, ptr %13, align 8
  %129 = load ptr, ptr %13, align 8
  store ptr %129, ptr %10, align 8
  %130 = load ptr, ptr %10, align 8
  br label %133

131:                                              ; preds = %18
  %132 = call ptr @xmalloc(i32 noundef 32)
  br label %133

133:                                              ; preds = %131, %122
  %134 = phi ptr [ %130, %122 ], [ %132, %131 ]
  %135 = load ptr, ptr %3, align 8
  %136 = getelementptr inbounds nuw %struct.type, ptr %135, i32 0, i32 3
  store ptr %134, ptr %136, align 8
  %137 = load ptr, ptr %3, align 8
  ret ptr %137
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @alloc_type() #0 {
  call void @abort() #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @get_discrete_bounds(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  store i64 0, ptr %5, align 8
  %6 = load ptr, ptr %4, align 8
  store i64 2, ptr %6, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @_obstack_newchunk(ptr noundef %0, i32 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  call void @abort() #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @xmalloc(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  ret ptr null
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.type, align 8
  %3 = alloca %struct.type, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 32, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %3, i8 0, i64 32, i1 false)
  %4 = getelementptr inbounds nuw %struct.type, ptr %2, i32 0, i32 0
  store i32 4, ptr %4, align 8
  %5 = call ptr @create_array_type(ptr noundef %3, ptr noundef %2)
  %6 = getelementptr inbounds nuw %struct.type, ptr %3, i32 0, i32 0
  %7 = load i32, ptr %6, align 8
  %8 = icmp ne i32 %7, 12
  br i1 %8, label %9, label %10

9:                                                ; preds = %0
  call void @abort() #4
  unreachable

10:                                               ; preds = %0
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
