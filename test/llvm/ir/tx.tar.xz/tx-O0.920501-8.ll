; ModuleID = '920501-8.c'
source_filename = "920501-8.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.__va_list_tag = type { i32, i32, ptr, ptr }

@buf = dso_local global [50 x i8] zeroinitializer, align 16
@.str = private unnamed_addr constant [48 x i8] c"%d,%f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\00", align 1
@.str.1 = private unnamed_addr constant [45 x i8] c"1,1.000000,2,3,4,5,6,7,8,9,10,11,12,13,14,15\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @va(i32 noundef %0, double noundef %1, i32 noundef %2, ...) #0 {
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  %8 = alloca [1 x %struct.__va_list_tag], align 16
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i32, align 4
  %21 = alloca i32, align 4
  store i32 %0, ptr %5, align 4
  store double %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  %22 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  call void @llvm.va_start.p0(ptr %22)
  %23 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %24 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %23, i32 0, i32 0
  %25 = load i32, ptr %24, align 16
  %26 = icmp ule i32 %25, 40
  br i1 %26, label %27, label %32

27:                                               ; preds = %3
  %28 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %23, i32 0, i32 3
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %29, i32 %25
  %31 = add i32 %25, 8
  store i32 %31, ptr %24, align 16
  br label %36

32:                                               ; preds = %3
  %33 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %23, i32 0, i32 2
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr i8, ptr %34, i32 8
  store ptr %35, ptr %33, align 8
  br label %36

36:                                               ; preds = %32, %27
  %37 = phi ptr [ %30, %27 ], [ %34, %32 ]
  %38 = load i32, ptr %37, align 4
  store i32 %38, ptr %9, align 4
  %39 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %40 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %39, i32 0, i32 0
  %41 = load i32, ptr %40, align 16
  %42 = icmp ule i32 %41, 40
  br i1 %42, label %43, label %48

43:                                               ; preds = %36
  %44 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %39, i32 0, i32 3
  %45 = load ptr, ptr %44, align 16
  %46 = getelementptr i8, ptr %45, i32 %41
  %47 = add i32 %41, 8
  store i32 %47, ptr %40, align 16
  br label %52

48:                                               ; preds = %36
  %49 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %39, i32 0, i32 2
  %50 = load ptr, ptr %49, align 8
  %51 = getelementptr i8, ptr %50, i32 8
  store ptr %51, ptr %49, align 8
  br label %52

52:                                               ; preds = %48, %43
  %53 = phi ptr [ %46, %43 ], [ %50, %48 ]
  %54 = load i32, ptr %53, align 4
  store i32 %54, ptr %10, align 4
  %55 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %56 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %55, i32 0, i32 0
  %57 = load i32, ptr %56, align 16
  %58 = icmp ule i32 %57, 40
  br i1 %58, label %59, label %64

59:                                               ; preds = %52
  %60 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %55, i32 0, i32 3
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %61, i32 %57
  %63 = add i32 %57, 8
  store i32 %63, ptr %56, align 16
  br label %68

64:                                               ; preds = %52
  %65 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %55, i32 0, i32 2
  %66 = load ptr, ptr %65, align 8
  %67 = getelementptr i8, ptr %66, i32 8
  store ptr %67, ptr %65, align 8
  br label %68

68:                                               ; preds = %64, %59
  %69 = phi ptr [ %62, %59 ], [ %66, %64 ]
  %70 = load i32, ptr %69, align 4
  store i32 %70, ptr %11, align 4
  %71 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %72 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %71, i32 0, i32 0
  %73 = load i32, ptr %72, align 16
  %74 = icmp ule i32 %73, 40
  br i1 %74, label %75, label %80

75:                                               ; preds = %68
  %76 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %71, i32 0, i32 3
  %77 = load ptr, ptr %76, align 16
  %78 = getelementptr i8, ptr %77, i32 %73
  %79 = add i32 %73, 8
  store i32 %79, ptr %72, align 16
  br label %84

80:                                               ; preds = %68
  %81 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %71, i32 0, i32 2
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i8, ptr %82, i32 8
  store ptr %83, ptr %81, align 8
  br label %84

84:                                               ; preds = %80, %75
  %85 = phi ptr [ %78, %75 ], [ %82, %80 ]
  %86 = load i32, ptr %85, align 4
  store i32 %86, ptr %12, align 4
  %87 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %88 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %87, i32 0, i32 0
  %89 = load i32, ptr %88, align 16
  %90 = icmp ule i32 %89, 40
  br i1 %90, label %91, label %96

91:                                               ; preds = %84
  %92 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %87, i32 0, i32 3
  %93 = load ptr, ptr %92, align 16
  %94 = getelementptr i8, ptr %93, i32 %89
  %95 = add i32 %89, 8
  store i32 %95, ptr %88, align 16
  br label %100

96:                                               ; preds = %84
  %97 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %87, i32 0, i32 2
  %98 = load ptr, ptr %97, align 8
  %99 = getelementptr i8, ptr %98, i32 8
  store ptr %99, ptr %97, align 8
  br label %100

100:                                              ; preds = %96, %91
  %101 = phi ptr [ %94, %91 ], [ %98, %96 ]
  %102 = load i32, ptr %101, align 4
  store i32 %102, ptr %13, align 4
  %103 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %104 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %103, i32 0, i32 0
  %105 = load i32, ptr %104, align 16
  %106 = icmp ule i32 %105, 40
  br i1 %106, label %107, label %112

107:                                              ; preds = %100
  %108 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %103, i32 0, i32 3
  %109 = load ptr, ptr %108, align 16
  %110 = getelementptr i8, ptr %109, i32 %105
  %111 = add i32 %105, 8
  store i32 %111, ptr %104, align 16
  br label %116

112:                                              ; preds = %100
  %113 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %103, i32 0, i32 2
  %114 = load ptr, ptr %113, align 8
  %115 = getelementptr i8, ptr %114, i32 8
  store ptr %115, ptr %113, align 8
  br label %116

116:                                              ; preds = %112, %107
  %117 = phi ptr [ %110, %107 ], [ %114, %112 ]
  %118 = load i32, ptr %117, align 4
  store i32 %118, ptr %14, align 4
  %119 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %120 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %119, i32 0, i32 0
  %121 = load i32, ptr %120, align 16
  %122 = icmp ule i32 %121, 40
  br i1 %122, label %123, label %128

123:                                              ; preds = %116
  %124 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %119, i32 0, i32 3
  %125 = load ptr, ptr %124, align 16
  %126 = getelementptr i8, ptr %125, i32 %121
  %127 = add i32 %121, 8
  store i32 %127, ptr %120, align 16
  br label %132

128:                                              ; preds = %116
  %129 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %119, i32 0, i32 2
  %130 = load ptr, ptr %129, align 8
  %131 = getelementptr i8, ptr %130, i32 8
  store ptr %131, ptr %129, align 8
  br label %132

132:                                              ; preds = %128, %123
  %133 = phi ptr [ %126, %123 ], [ %130, %128 ]
  %134 = load i32, ptr %133, align 4
  store i32 %134, ptr %15, align 4
  %135 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %136 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %135, i32 0, i32 0
  %137 = load i32, ptr %136, align 16
  %138 = icmp ule i32 %137, 40
  br i1 %138, label %139, label %144

139:                                              ; preds = %132
  %140 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %135, i32 0, i32 3
  %141 = load ptr, ptr %140, align 16
  %142 = getelementptr i8, ptr %141, i32 %137
  %143 = add i32 %137, 8
  store i32 %143, ptr %136, align 16
  br label %148

144:                                              ; preds = %132
  %145 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %135, i32 0, i32 2
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i8, ptr %146, i32 8
  store ptr %147, ptr %145, align 8
  br label %148

148:                                              ; preds = %144, %139
  %149 = phi ptr [ %142, %139 ], [ %146, %144 ]
  %150 = load i32, ptr %149, align 4
  store i32 %150, ptr %16, align 4
  %151 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %152 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %151, i32 0, i32 0
  %153 = load i32, ptr %152, align 16
  %154 = icmp ule i32 %153, 40
  br i1 %154, label %155, label %160

155:                                              ; preds = %148
  %156 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %151, i32 0, i32 3
  %157 = load ptr, ptr %156, align 16
  %158 = getelementptr i8, ptr %157, i32 %153
  %159 = add i32 %153, 8
  store i32 %159, ptr %152, align 16
  br label %164

160:                                              ; preds = %148
  %161 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %151, i32 0, i32 2
  %162 = load ptr, ptr %161, align 8
  %163 = getelementptr i8, ptr %162, i32 8
  store ptr %163, ptr %161, align 8
  br label %164

164:                                              ; preds = %160, %155
  %165 = phi ptr [ %158, %155 ], [ %162, %160 ]
  %166 = load i32, ptr %165, align 4
  store i32 %166, ptr %17, align 4
  %167 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %168 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %167, i32 0, i32 0
  %169 = load i32, ptr %168, align 16
  %170 = icmp ule i32 %169, 40
  br i1 %170, label %171, label %176

171:                                              ; preds = %164
  %172 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %167, i32 0, i32 3
  %173 = load ptr, ptr %172, align 16
  %174 = getelementptr i8, ptr %173, i32 %169
  %175 = add i32 %169, 8
  store i32 %175, ptr %168, align 16
  br label %180

176:                                              ; preds = %164
  %177 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %167, i32 0, i32 2
  %178 = load ptr, ptr %177, align 8
  %179 = getelementptr i8, ptr %178, i32 8
  store ptr %179, ptr %177, align 8
  br label %180

180:                                              ; preds = %176, %171
  %181 = phi ptr [ %174, %171 ], [ %178, %176 ]
  %182 = load i32, ptr %181, align 4
  store i32 %182, ptr %18, align 4
  %183 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %184 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %183, i32 0, i32 0
  %185 = load i32, ptr %184, align 16
  %186 = icmp ule i32 %185, 40
  br i1 %186, label %187, label %192

187:                                              ; preds = %180
  %188 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %183, i32 0, i32 3
  %189 = load ptr, ptr %188, align 16
  %190 = getelementptr i8, ptr %189, i32 %185
  %191 = add i32 %185, 8
  store i32 %191, ptr %184, align 16
  br label %196

192:                                              ; preds = %180
  %193 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %183, i32 0, i32 2
  %194 = load ptr, ptr %193, align 8
  %195 = getelementptr i8, ptr %194, i32 8
  store ptr %195, ptr %193, align 8
  br label %196

196:                                              ; preds = %192, %187
  %197 = phi ptr [ %190, %187 ], [ %194, %192 ]
  %198 = load i32, ptr %197, align 4
  store i32 %198, ptr %19, align 4
  %199 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %200 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %199, i32 0, i32 0
  %201 = load i32, ptr %200, align 16
  %202 = icmp ule i32 %201, 40
  br i1 %202, label %203, label %208

203:                                              ; preds = %196
  %204 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %199, i32 0, i32 3
  %205 = load ptr, ptr %204, align 16
  %206 = getelementptr i8, ptr %205, i32 %201
  %207 = add i32 %201, 8
  store i32 %207, ptr %200, align 16
  br label %212

208:                                              ; preds = %196
  %209 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %199, i32 0, i32 2
  %210 = load ptr, ptr %209, align 8
  %211 = getelementptr i8, ptr %210, i32 8
  store ptr %211, ptr %209, align 8
  br label %212

212:                                              ; preds = %208, %203
  %213 = phi ptr [ %206, %203 ], [ %210, %208 ]
  %214 = load i32, ptr %213, align 4
  store i32 %214, ptr %20, align 4
  %215 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  %216 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %215, i32 0, i32 0
  %217 = load i32, ptr %216, align 16
  %218 = icmp ule i32 %217, 40
  br i1 %218, label %219, label %224

219:                                              ; preds = %212
  %220 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %215, i32 0, i32 3
  %221 = load ptr, ptr %220, align 16
  %222 = getelementptr i8, ptr %221, i32 %217
  %223 = add i32 %217, 8
  store i32 %223, ptr %216, align 16
  br label %228

224:                                              ; preds = %212
  %225 = getelementptr inbounds nuw %struct.__va_list_tag, ptr %215, i32 0, i32 2
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr i8, ptr %226, i32 8
  store ptr %227, ptr %225, align 8
  br label %228

228:                                              ; preds = %224, %219
  %229 = phi ptr [ %222, %219 ], [ %226, %224 ]
  %230 = load i32, ptr %229, align 4
  store i32 %230, ptr %21, align 4
  %231 = load i32, ptr %5, align 4
  %232 = load double, ptr %6, align 8
  %233 = load i32, ptr %7, align 4
  %234 = load i32, ptr %9, align 4
  %235 = load i32, ptr %10, align 4
  %236 = load i32, ptr %11, align 4
  %237 = load i32, ptr %12, align 4
  %238 = load i32, ptr %13, align 4
  %239 = load i32, ptr %14, align 4
  %240 = load i32, ptr %15, align 4
  %241 = load i32, ptr %16, align 4
  %242 = load i32, ptr %17, align 4
  %243 = load i32, ptr %18, align 4
  %244 = load i32, ptr %19, align 4
  %245 = load i32, ptr %20, align 4
  %246 = load i32, ptr %21, align 4
  %247 = call i32 (ptr, ptr, ...) @sprintf(ptr noundef @buf, ptr noundef @.str, i32 noundef %231, double noundef %232, i32 noundef %233, i32 noundef %234, i32 noundef %235, i32 noundef %236, i32 noundef %237, i32 noundef %238, i32 noundef %239, i32 noundef %240, i32 noundef %241, i32 noundef %242, i32 noundef %243, i32 noundef %244, i32 noundef %245, i32 noundef %246) #5
  %248 = getelementptr inbounds [1 x %struct.__va_list_tag], ptr %8, i64 0, i64 0
  call void @llvm.va_end.p0(ptr %248)
  %249 = load i32, ptr %4, align 4
  ret i32 %249
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #1

; Function Attrs: nounwind
declare i32 @sprintf(ptr noundef, ptr noundef, ...) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 (i32, double, i32, ...) @va(i32 noundef 1, double noundef 1.000000e+00, i32 noundef 2, i32 noundef 3, i32 noundef 4, i32 noundef 5, i32 noundef 6, i32 noundef 7, i32 noundef 8, i32 noundef 9, i32 noundef 10, i32 noundef 11, i32 noundef 12, i32 noundef 13, i32 noundef 14, i32 noundef 15)
  %3 = call i32 @strcmp(ptr noundef @.str.1, ptr noundef @buf) #5
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %5, label %6

5:                                                ; preds = %0
  call void @abort() #6
  unreachable

6:                                                ; preds = %0
  call void @exit(i32 noundef 0) #7
  unreachable
}

; Function Attrs: nounwind
declare i32 @strcmp(ptr noundef, ptr noundef) #2

; Function Attrs: noreturn nounwind
declare void @abort() #3

; Function Attrs: noreturn
declare void @exit(i32 noundef) #4

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn }
attributes #2 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nounwind }
attributes #6 = { noreturn nounwind }
attributes #7 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
