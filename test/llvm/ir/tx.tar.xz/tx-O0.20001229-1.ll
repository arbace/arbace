; ModuleID = '20001229-1.c'
source_filename = "20001229-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @showinfo() #0 {
  %1 = alloca [33 x i8], align 16
  %2 = alloca [38 x i8], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %1, i8 0, i64 33, i1 false)
  call void @llvm.memset.p0.i64(ptr align 16 %2, i8 0, i64 38, i1 false)
  %3 = getelementptr inbounds [38 x i8], ptr %2, i32 0, i32 0
  store i8 47, ptr %3, align 16
  %4 = getelementptr inbounds [38 x i8], ptr %2, i32 0, i32 1
  store i8 100, ptr %4, align 1
  %5 = getelementptr inbounds [38 x i8], ptr %2, i32 0, i32 2
  store i8 101, ptr %5, align 2
  %6 = getelementptr inbounds [38 x i8], ptr %2, i32 0, i32 3
  store i8 118, ptr %6, align 1
  %7 = getelementptr inbounds [38 x i8], ptr %2, i32 0, i32 4
  store i8 47, ptr %7, align 4
  %8 = getelementptr inbounds [33 x i8], ptr %1, i64 0, i64 0
  %9 = getelementptr inbounds [38 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %8, ptr noundef %9)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @showinfo()
  call void @exit(i32 noundef 0) #3
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
