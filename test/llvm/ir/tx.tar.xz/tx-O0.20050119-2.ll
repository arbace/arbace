; ModuleID = '20050119-2.c'
source_filename = "20050119-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i8, i8, i8, i8 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 0
  %5 = load i8, ptr %4, align 1
  %6 = zext i8 %5 to i32
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds nuw %struct.S, ptr %7, i32 0, i32 1
  %9 = load i8, ptr %8, align 1
  %10 = zext i8 %9 to i32
  %11 = icmp ne i32 %6, %10
  br i1 %11, label %12, label %13

12:                                               ; preds = %1
  call void @abort() #3
  unreachable

13:                                               ; preds = %1
  %14 = load ptr, ptr %2, align 8
  %15 = getelementptr inbounds nuw %struct.S, ptr %14, i32 0, i32 2
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  %18 = icmp ne i32 %17, 2
  br i1 %18, label %19, label %20

19:                                               ; preds = %13
  call void @abort() #3
  unreachable

20:                                               ; preds = %13
  %21 = load ptr, ptr %2, align 8
  %22 = getelementptr inbounds nuw %struct.S, ptr %21, i32 0, i32 3
  %23 = load i8, ptr %22, align 1
  %24 = zext i8 %23 to i32
  ret i32 %24
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [2 x %struct.S], align 1
  store i32 0, ptr %1, align 4
  %3 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 0
  %4 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 0
  store i8 1, ptr %4, align 1
  %5 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 0
  %6 = getelementptr inbounds nuw %struct.S, ptr %5, i32 0, i32 1
  store i8 1, ptr %6, align 1
  %7 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 0
  %8 = getelementptr inbounds nuw %struct.S, ptr %7, i32 0, i32 2
  store i8 2, ptr %8, align 1
  %9 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 0
  %10 = getelementptr inbounds nuw %struct.S, ptr %9, i32 0, i32 3
  store i8 3, ptr %10, align 1
  %11 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 1
  %12 = getelementptr inbounds nuw %struct.S, ptr %11, i32 0, i32 0
  store i8 3, ptr %12, align 1
  %13 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 1
  %14 = getelementptr inbounds nuw %struct.S, ptr %13, i32 0, i32 1
  store i8 2, ptr %14, align 1
  %15 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 1
  %16 = getelementptr inbounds nuw %struct.S, ptr %15, i32 0, i32 2
  store i8 1, ptr %16, align 1
  %17 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 1
  %18 = getelementptr inbounds nuw %struct.S, ptr %17, i32 0, i32 3
  store i8 0, ptr %18, align 1
  %19 = getelementptr inbounds [2 x %struct.S], ptr %2, i64 0, i64 0
  %20 = call i32 @foo(ptr noundef %19)
  %21 = icmp ne i32 %20, 3
  br i1 %21, label %22, label %23

22:                                               ; preds = %0
  call void @abort() #3
  unreachable

23:                                               ; preds = %0
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
