; ModuleID = '20011008-3.c'
source_filename = "20011008-3.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.__db_lsn = type { i32, i32 }
%struct.__db_txnlist = type { i32, %struct.anon, %union.anon }
%struct.anon = type { ptr, ptr }
%union.anon = type { %struct.anon.3 }
%struct.anon.3 = type { i32, i32, ptr, i32, ptr, [20 x i8] }
%struct.anon.2 = type { i32, i32, ptr }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @log_compare(ptr noundef %0, ptr noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  ret i32 1
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @__db_txnlist_lsnadd(i32 noundef %0, ptr noundef %1, ptr noundef %2, i32 noundef %3) #0 {
  %5 = alloca i32, align 4
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca %struct.__db_lsn, align 4
  store i32 %0, ptr %5, align 4
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  store i32 %3, ptr %8, align 4
  store i32 0, ptr %9, align 4
  br label %12

12:                                               ; preds = %91, %4
  %13 = load i32, ptr %9, align 4
  %14 = load i32, ptr %8, align 4
  %15 = and i32 %14, 1
  %16 = icmp ne i32 %15, 0
  br i1 %16, label %18, label %17

17:                                               ; preds = %12
  br label %23

18:                                               ; preds = %12
  %19 = load ptr, ptr %6, align 8
  %20 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %19, i32 0, i32 2
  %21 = getelementptr inbounds nuw %struct.anon.2, ptr %20, i32 0, i32 0
  %22 = load i32, ptr %21, align 8
  br label %23

23:                                               ; preds = %18, %17
  %24 = phi i32 [ 1, %17 ], [ %22, %18 ]
  %25 = icmp slt i32 %13, %24
  br i1 %25, label %26, label %94

26:                                               ; preds = %23
  %27 = load i32, ptr %5, align 4
  %28 = add nsw i32 %27, 1
  store i32 %28, ptr %5, align 4
  store i32 0, ptr %10, align 4
  br label %29

29:                                               ; preds = %87, %26
  %30 = load i32, ptr %10, align 4
  %31 = load ptr, ptr %6, align 8
  %32 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %31, i32 0, i32 2
  %33 = getelementptr inbounds nuw %struct.anon.2, ptr %32, i32 0, i32 0
  %34 = load i32, ptr %33, align 8
  %35 = sub nsw i32 %34, 1
  %36 = icmp slt i32 %30, %35
  br i1 %36, label %37, label %90

37:                                               ; preds = %29
  %38 = load ptr, ptr %6, align 8
  %39 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %38, i32 0, i32 2
  %40 = getelementptr inbounds nuw %struct.anon.2, ptr %39, i32 0, i32 2
  %41 = load ptr, ptr %40, align 8
  %42 = load i32, ptr %10, align 4
  %43 = sext i32 %42 to i64
  %44 = getelementptr inbounds %struct.__db_lsn, ptr %41, i64 %43
  %45 = load ptr, ptr %6, align 8
  %46 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %45, i32 0, i32 2
  %47 = getelementptr inbounds nuw %struct.anon.2, ptr %46, i32 0, i32 2
  %48 = load ptr, ptr %47, align 8
  %49 = load i32, ptr %10, align 4
  %50 = add nsw i32 %49, 1
  %51 = sext i32 %50 to i64
  %52 = getelementptr inbounds %struct.__db_lsn, ptr %48, i64 %51
  %53 = call i32 @log_compare(ptr noundef %44, ptr noundef %52)
  %54 = icmp slt i32 %53, 0
  br i1 %54, label %55, label %86

55:                                               ; preds = %37
  %56 = load ptr, ptr %6, align 8
  %57 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %56, i32 0, i32 2
  %58 = getelementptr inbounds nuw %struct.anon.2, ptr %57, i32 0, i32 2
  %59 = load ptr, ptr %58, align 8
  %60 = load i32, ptr %10, align 4
  %61 = sext i32 %60 to i64
  %62 = getelementptr inbounds %struct.__db_lsn, ptr %59, i64 %61
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %11, ptr align 4 %62, i64 8, i1 false)
  %63 = load ptr, ptr %6, align 8
  %64 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %63, i32 0, i32 2
  %65 = getelementptr inbounds nuw %struct.anon.2, ptr %64, i32 0, i32 2
  %66 = load ptr, ptr %65, align 8
  %67 = load i32, ptr %10, align 4
  %68 = sext i32 %67 to i64
  %69 = getelementptr inbounds %struct.__db_lsn, ptr %66, i64 %68
  %70 = load ptr, ptr %6, align 8
  %71 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %70, i32 0, i32 2
  %72 = getelementptr inbounds nuw %struct.anon.2, ptr %71, i32 0, i32 2
  %73 = load ptr, ptr %72, align 8
  %74 = load i32, ptr %10, align 4
  %75 = add nsw i32 %74, 1
  %76 = sext i32 %75 to i64
  %77 = getelementptr inbounds %struct.__db_lsn, ptr %73, i64 %76
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %69, ptr align 4 %77, i64 8, i1 false)
  %78 = load ptr, ptr %6, align 8
  %79 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %78, i32 0, i32 2
  %80 = getelementptr inbounds nuw %struct.anon.2, ptr %79, i32 0, i32 2
  %81 = load ptr, ptr %80, align 8
  %82 = load i32, ptr %10, align 4
  %83 = add nsw i32 %82, 1
  %84 = sext i32 %83 to i64
  %85 = getelementptr inbounds %struct.__db_lsn, ptr %81, i64 %84
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %85, ptr align 4 %11, i64 8, i1 false)
  br label %86

86:                                               ; preds = %55, %37
  br label %87

87:                                               ; preds = %86
  %88 = load i32, ptr %10, align 4
  %89 = add nsw i32 %88, 1
  store i32 %89, ptr %10, align 4
  br label %29, !llvm.loop !6

90:                                               ; preds = %29
  br label %91

91:                                               ; preds = %90
  %92 = load i32, ptr %9, align 4
  %93 = add nsw i32 %92, 1
  store i32 %93, ptr %9, align 4
  br label %12, !llvm.loop !8

94:                                               ; preds = %23
  %95 = load ptr, ptr %7, align 8
  %96 = load ptr, ptr %6, align 8
  %97 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %96, i32 0, i32 2
  %98 = getelementptr inbounds nuw %struct.anon.2, ptr %97, i32 0, i32 2
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr inbounds %struct.__db_lsn, ptr %99, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %95, ptr align 4 %100, i64 8, i1 false)
  %101 = load i32, ptr %5, align 4
  ret i32 %101
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.__db_txnlist, align 8
  %3 = alloca %struct.__db_lsn, align 4
  %4 = alloca [1235 x %struct.__db_lsn], align 16
  store i32 0, ptr %1, align 4
  %5 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %2, i32 0, i32 2
  %6 = getelementptr inbounds nuw %struct.anon.2, ptr %5, i32 0, i32 0
  store i32 1234, ptr %6, align 8
  %7 = getelementptr inbounds [1235 x %struct.__db_lsn], ptr %4, i64 0, i64 0
  %8 = getelementptr inbounds nuw %struct.__db_txnlist, ptr %2, i32 0, i32 2
  %9 = getelementptr inbounds nuw %struct.anon.2, ptr %8, i32 0, i32 2
  store ptr %7, ptr %9, align 8
  %10 = call i32 @__db_txnlist_lsnadd(i32 noundef 0, ptr noundef %2, ptr noundef %3, i32 noundef 0)
  %11 = icmp ne i32 %10, 1
  br i1 %11, label %12, label %13

12:                                               ; preds = %0
  call void @abort() #4
  unreachable

13:                                               ; preds = %0
  %14 = call i32 @__db_txnlist_lsnadd(i32 noundef 0, ptr noundef %2, ptr noundef %3, i32 noundef 1)
  %15 = icmp ne i32 %14, 1234
  br i1 %15, label %16, label %17

16:                                               ; preds = %13
  call void @abort() #4
  unreachable

17:                                               ; preds = %13
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
