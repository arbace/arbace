; ModuleID = '920908-2.c'
source_filename = "920908-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.T = type { i32 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f(i32 %0) #0 {
  %2 = alloca %struct.T, align 4
  %3 = alloca [1 x %struct.T], align 4
  %4 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  store i32 %0, ptr %4, align 4
  %5 = getelementptr inbounds [1 x %struct.T], ptr %3, i64 0, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %2, i64 4, i1 false)
  %6 = getelementptr inbounds [1 x %struct.T], ptr %3, i64 0, i64 0
  %7 = load i32, ptr %6, align 4
  %8 = lshr i32 %7, 8
  %9 = trunc i32 %8 to i8
  %10 = sext i8 %9 to i32
  ret i32 %10
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.T, align 4
  store i32 0, ptr %1, align 4
  %3 = load i32, ptr %2, align 4
  %4 = and i32 %3, -256
  %5 = or i32 %4, 255
  store i32 %5, ptr %2, align 4
  %6 = load i32, ptr %2, align 4
  %7 = and i32 %6, 255
  %8 = or i32 %7, -61184
  store i32 %8, ptr %2, align 4
  %9 = getelementptr inbounds nuw %struct.T, ptr %2, i32 0, i32 0
  %10 = load i32, ptr %9, align 4
  %11 = call i32 @f(i32 %10)
  %12 = icmp ne i32 %11, 17
  br i1 %12, label %13, label %14

13:                                               ; preds = %0
  call void @abort() #4
  unreachable

14:                                               ; preds = %0
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
