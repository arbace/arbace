; ModuleID = '20030323-1.c'
source_filename = "20030323-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @NSReturnAddress(i32 noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  %4 = load i32, ptr %3, align 4
  switch i32 %4, label %205 [
    i32 0, label %5
    i32 1, label %7
    i32 2, label %9
    i32 3, label %11
    i32 4, label %13
    i32 5, label %15
    i32 6, label %17
    i32 7, label %19
    i32 8, label %21
    i32 9, label %23
    i32 10, label %25
    i32 11, label %27
    i32 12, label %29
    i32 13, label %31
    i32 14, label %33
    i32 15, label %35
    i32 16, label %37
    i32 17, label %39
    i32 18, label %41
    i32 19, label %43
    i32 20, label %45
    i32 21, label %47
    i32 22, label %49
    i32 23, label %51
    i32 24, label %53
    i32 25, label %55
    i32 26, label %57
    i32 27, label %59
    i32 28, label %61
    i32 29, label %63
    i32 30, label %65
    i32 31, label %67
    i32 32, label %69
    i32 33, label %71
    i32 34, label %73
    i32 35, label %75
    i32 36, label %77
    i32 37, label %79
    i32 38, label %81
    i32 39, label %83
    i32 40, label %85
    i32 41, label %87
    i32 42, label %89
    i32 43, label %91
    i32 44, label %93
    i32 45, label %95
    i32 46, label %97
    i32 47, label %99
    i32 48, label %101
    i32 49, label %103
    i32 50, label %105
    i32 51, label %107
    i32 52, label %109
    i32 53, label %111
    i32 54, label %113
    i32 55, label %115
    i32 56, label %117
    i32 57, label %119
    i32 58, label %121
    i32 59, label %123
    i32 60, label %125
    i32 61, label %127
    i32 62, label %129
    i32 63, label %131
    i32 64, label %133
    i32 65, label %135
    i32 66, label %137
    i32 67, label %139
    i32 68, label %141
    i32 69, label %143
    i32 70, label %145
    i32 71, label %147
    i32 72, label %149
    i32 73, label %151
    i32 74, label %153
    i32 75, label %155
    i32 76, label %157
    i32 77, label %159
    i32 78, label %161
    i32 79, label %163
    i32 80, label %165
    i32 81, label %167
    i32 82, label %169
    i32 83, label %171
    i32 84, label %173
    i32 85, label %175
    i32 86, label %177
    i32 87, label %179
    i32 88, label %181
    i32 89, label %183
    i32 90, label %185
    i32 91, label %187
    i32 92, label %189
    i32 93, label %191
    i32 94, label %193
    i32 95, label %195
    i32 96, label %197
    i32 97, label %199
    i32 98, label %201
    i32 99, label %203
  ]

5:                                                ; preds = %1
  %6 = call ptr @llvm.returnaddress.p0(i32 1)
  store ptr %6, ptr %2, align 8
  br label %206

7:                                                ; preds = %1
  %8 = call ptr @llvm.returnaddress.p0(i32 2)
  store ptr %8, ptr %2, align 8
  br label %206

9:                                                ; preds = %1
  %10 = call ptr @llvm.returnaddress.p0(i32 3)
  store ptr %10, ptr %2, align 8
  br label %206

11:                                               ; preds = %1
  %12 = call ptr @llvm.returnaddress.p0(i32 4)
  store ptr %12, ptr %2, align 8
  br label %206

13:                                               ; preds = %1
  %14 = call ptr @llvm.returnaddress.p0(i32 5)
  store ptr %14, ptr %2, align 8
  br label %206

15:                                               ; preds = %1
  %16 = call ptr @llvm.returnaddress.p0(i32 6)
  store ptr %16, ptr %2, align 8
  br label %206

17:                                               ; preds = %1
  %18 = call ptr @llvm.returnaddress.p0(i32 7)
  store ptr %18, ptr %2, align 8
  br label %206

19:                                               ; preds = %1
  %20 = call ptr @llvm.returnaddress.p0(i32 8)
  store ptr %20, ptr %2, align 8
  br label %206

21:                                               ; preds = %1
  %22 = call ptr @llvm.returnaddress.p0(i32 9)
  store ptr %22, ptr %2, align 8
  br label %206

23:                                               ; preds = %1
  %24 = call ptr @llvm.returnaddress.p0(i32 10)
  store ptr %24, ptr %2, align 8
  br label %206

25:                                               ; preds = %1
  %26 = call ptr @llvm.returnaddress.p0(i32 11)
  store ptr %26, ptr %2, align 8
  br label %206

27:                                               ; preds = %1
  %28 = call ptr @llvm.returnaddress.p0(i32 12)
  store ptr %28, ptr %2, align 8
  br label %206

29:                                               ; preds = %1
  %30 = call ptr @llvm.returnaddress.p0(i32 13)
  store ptr %30, ptr %2, align 8
  br label %206

31:                                               ; preds = %1
  %32 = call ptr @llvm.returnaddress.p0(i32 14)
  store ptr %32, ptr %2, align 8
  br label %206

33:                                               ; preds = %1
  %34 = call ptr @llvm.returnaddress.p0(i32 15)
  store ptr %34, ptr %2, align 8
  br label %206

35:                                               ; preds = %1
  %36 = call ptr @llvm.returnaddress.p0(i32 16)
  store ptr %36, ptr %2, align 8
  br label %206

37:                                               ; preds = %1
  %38 = call ptr @llvm.returnaddress.p0(i32 17)
  store ptr %38, ptr %2, align 8
  br label %206

39:                                               ; preds = %1
  %40 = call ptr @llvm.returnaddress.p0(i32 18)
  store ptr %40, ptr %2, align 8
  br label %206

41:                                               ; preds = %1
  %42 = call ptr @llvm.returnaddress.p0(i32 19)
  store ptr %42, ptr %2, align 8
  br label %206

43:                                               ; preds = %1
  %44 = call ptr @llvm.returnaddress.p0(i32 20)
  store ptr %44, ptr %2, align 8
  br label %206

45:                                               ; preds = %1
  %46 = call ptr @llvm.returnaddress.p0(i32 21)
  store ptr %46, ptr %2, align 8
  br label %206

47:                                               ; preds = %1
  %48 = call ptr @llvm.returnaddress.p0(i32 22)
  store ptr %48, ptr %2, align 8
  br label %206

49:                                               ; preds = %1
  %50 = call ptr @llvm.returnaddress.p0(i32 23)
  store ptr %50, ptr %2, align 8
  br label %206

51:                                               ; preds = %1
  %52 = call ptr @llvm.returnaddress.p0(i32 24)
  store ptr %52, ptr %2, align 8
  br label %206

53:                                               ; preds = %1
  %54 = call ptr @llvm.returnaddress.p0(i32 25)
  store ptr %54, ptr %2, align 8
  br label %206

55:                                               ; preds = %1
  %56 = call ptr @llvm.returnaddress.p0(i32 26)
  store ptr %56, ptr %2, align 8
  br label %206

57:                                               ; preds = %1
  %58 = call ptr @llvm.returnaddress.p0(i32 27)
  store ptr %58, ptr %2, align 8
  br label %206

59:                                               ; preds = %1
  %60 = call ptr @llvm.returnaddress.p0(i32 28)
  store ptr %60, ptr %2, align 8
  br label %206

61:                                               ; preds = %1
  %62 = call ptr @llvm.returnaddress.p0(i32 29)
  store ptr %62, ptr %2, align 8
  br label %206

63:                                               ; preds = %1
  %64 = call ptr @llvm.returnaddress.p0(i32 30)
  store ptr %64, ptr %2, align 8
  br label %206

65:                                               ; preds = %1
  %66 = call ptr @llvm.returnaddress.p0(i32 31)
  store ptr %66, ptr %2, align 8
  br label %206

67:                                               ; preds = %1
  %68 = call ptr @llvm.returnaddress.p0(i32 32)
  store ptr %68, ptr %2, align 8
  br label %206

69:                                               ; preds = %1
  %70 = call ptr @llvm.returnaddress.p0(i32 33)
  store ptr %70, ptr %2, align 8
  br label %206

71:                                               ; preds = %1
  %72 = call ptr @llvm.returnaddress.p0(i32 34)
  store ptr %72, ptr %2, align 8
  br label %206

73:                                               ; preds = %1
  %74 = call ptr @llvm.returnaddress.p0(i32 35)
  store ptr %74, ptr %2, align 8
  br label %206

75:                                               ; preds = %1
  %76 = call ptr @llvm.returnaddress.p0(i32 36)
  store ptr %76, ptr %2, align 8
  br label %206

77:                                               ; preds = %1
  %78 = call ptr @llvm.returnaddress.p0(i32 37)
  store ptr %78, ptr %2, align 8
  br label %206

79:                                               ; preds = %1
  %80 = call ptr @llvm.returnaddress.p0(i32 38)
  store ptr %80, ptr %2, align 8
  br label %206

81:                                               ; preds = %1
  %82 = call ptr @llvm.returnaddress.p0(i32 39)
  store ptr %82, ptr %2, align 8
  br label %206

83:                                               ; preds = %1
  %84 = call ptr @llvm.returnaddress.p0(i32 40)
  store ptr %84, ptr %2, align 8
  br label %206

85:                                               ; preds = %1
  %86 = call ptr @llvm.returnaddress.p0(i32 41)
  store ptr %86, ptr %2, align 8
  br label %206

87:                                               ; preds = %1
  %88 = call ptr @llvm.returnaddress.p0(i32 42)
  store ptr %88, ptr %2, align 8
  br label %206

89:                                               ; preds = %1
  %90 = call ptr @llvm.returnaddress.p0(i32 43)
  store ptr %90, ptr %2, align 8
  br label %206

91:                                               ; preds = %1
  %92 = call ptr @llvm.returnaddress.p0(i32 44)
  store ptr %92, ptr %2, align 8
  br label %206

93:                                               ; preds = %1
  %94 = call ptr @llvm.returnaddress.p0(i32 45)
  store ptr %94, ptr %2, align 8
  br label %206

95:                                               ; preds = %1
  %96 = call ptr @llvm.returnaddress.p0(i32 46)
  store ptr %96, ptr %2, align 8
  br label %206

97:                                               ; preds = %1
  %98 = call ptr @llvm.returnaddress.p0(i32 47)
  store ptr %98, ptr %2, align 8
  br label %206

99:                                               ; preds = %1
  %100 = call ptr @llvm.returnaddress.p0(i32 48)
  store ptr %100, ptr %2, align 8
  br label %206

101:                                              ; preds = %1
  %102 = call ptr @llvm.returnaddress.p0(i32 49)
  store ptr %102, ptr %2, align 8
  br label %206

103:                                              ; preds = %1
  %104 = call ptr @llvm.returnaddress.p0(i32 50)
  store ptr %104, ptr %2, align 8
  br label %206

105:                                              ; preds = %1
  %106 = call ptr @llvm.returnaddress.p0(i32 51)
  store ptr %106, ptr %2, align 8
  br label %206

107:                                              ; preds = %1
  %108 = call ptr @llvm.returnaddress.p0(i32 52)
  store ptr %108, ptr %2, align 8
  br label %206

109:                                              ; preds = %1
  %110 = call ptr @llvm.returnaddress.p0(i32 53)
  store ptr %110, ptr %2, align 8
  br label %206

111:                                              ; preds = %1
  %112 = call ptr @llvm.returnaddress.p0(i32 54)
  store ptr %112, ptr %2, align 8
  br label %206

113:                                              ; preds = %1
  %114 = call ptr @llvm.returnaddress.p0(i32 55)
  store ptr %114, ptr %2, align 8
  br label %206

115:                                              ; preds = %1
  %116 = call ptr @llvm.returnaddress.p0(i32 56)
  store ptr %116, ptr %2, align 8
  br label %206

117:                                              ; preds = %1
  %118 = call ptr @llvm.returnaddress.p0(i32 57)
  store ptr %118, ptr %2, align 8
  br label %206

119:                                              ; preds = %1
  %120 = call ptr @llvm.returnaddress.p0(i32 58)
  store ptr %120, ptr %2, align 8
  br label %206

121:                                              ; preds = %1
  %122 = call ptr @llvm.returnaddress.p0(i32 59)
  store ptr %122, ptr %2, align 8
  br label %206

123:                                              ; preds = %1
  %124 = call ptr @llvm.returnaddress.p0(i32 60)
  store ptr %124, ptr %2, align 8
  br label %206

125:                                              ; preds = %1
  %126 = call ptr @llvm.returnaddress.p0(i32 61)
  store ptr %126, ptr %2, align 8
  br label %206

127:                                              ; preds = %1
  %128 = call ptr @llvm.returnaddress.p0(i32 62)
  store ptr %128, ptr %2, align 8
  br label %206

129:                                              ; preds = %1
  %130 = call ptr @llvm.returnaddress.p0(i32 63)
  store ptr %130, ptr %2, align 8
  br label %206

131:                                              ; preds = %1
  %132 = call ptr @llvm.returnaddress.p0(i32 64)
  store ptr %132, ptr %2, align 8
  br label %206

133:                                              ; preds = %1
  %134 = call ptr @llvm.returnaddress.p0(i32 65)
  store ptr %134, ptr %2, align 8
  br label %206

135:                                              ; preds = %1
  %136 = call ptr @llvm.returnaddress.p0(i32 66)
  store ptr %136, ptr %2, align 8
  br label %206

137:                                              ; preds = %1
  %138 = call ptr @llvm.returnaddress.p0(i32 67)
  store ptr %138, ptr %2, align 8
  br label %206

139:                                              ; preds = %1
  %140 = call ptr @llvm.returnaddress.p0(i32 68)
  store ptr %140, ptr %2, align 8
  br label %206

141:                                              ; preds = %1
  %142 = call ptr @llvm.returnaddress.p0(i32 69)
  store ptr %142, ptr %2, align 8
  br label %206

143:                                              ; preds = %1
  %144 = call ptr @llvm.returnaddress.p0(i32 70)
  store ptr %144, ptr %2, align 8
  br label %206

145:                                              ; preds = %1
  %146 = call ptr @llvm.returnaddress.p0(i32 71)
  store ptr %146, ptr %2, align 8
  br label %206

147:                                              ; preds = %1
  %148 = call ptr @llvm.returnaddress.p0(i32 72)
  store ptr %148, ptr %2, align 8
  br label %206

149:                                              ; preds = %1
  %150 = call ptr @llvm.returnaddress.p0(i32 73)
  store ptr %150, ptr %2, align 8
  br label %206

151:                                              ; preds = %1
  %152 = call ptr @llvm.returnaddress.p0(i32 74)
  store ptr %152, ptr %2, align 8
  br label %206

153:                                              ; preds = %1
  %154 = call ptr @llvm.returnaddress.p0(i32 75)
  store ptr %154, ptr %2, align 8
  br label %206

155:                                              ; preds = %1
  %156 = call ptr @llvm.returnaddress.p0(i32 76)
  store ptr %156, ptr %2, align 8
  br label %206

157:                                              ; preds = %1
  %158 = call ptr @llvm.returnaddress.p0(i32 77)
  store ptr %158, ptr %2, align 8
  br label %206

159:                                              ; preds = %1
  %160 = call ptr @llvm.returnaddress.p0(i32 78)
  store ptr %160, ptr %2, align 8
  br label %206

161:                                              ; preds = %1
  %162 = call ptr @llvm.returnaddress.p0(i32 79)
  store ptr %162, ptr %2, align 8
  br label %206

163:                                              ; preds = %1
  %164 = call ptr @llvm.returnaddress.p0(i32 80)
  store ptr %164, ptr %2, align 8
  br label %206

165:                                              ; preds = %1
  %166 = call ptr @llvm.returnaddress.p0(i32 81)
  store ptr %166, ptr %2, align 8
  br label %206

167:                                              ; preds = %1
  %168 = call ptr @llvm.returnaddress.p0(i32 82)
  store ptr %168, ptr %2, align 8
  br label %206

169:                                              ; preds = %1
  %170 = call ptr @llvm.returnaddress.p0(i32 83)
  store ptr %170, ptr %2, align 8
  br label %206

171:                                              ; preds = %1
  %172 = call ptr @llvm.returnaddress.p0(i32 84)
  store ptr %172, ptr %2, align 8
  br label %206

173:                                              ; preds = %1
  %174 = call ptr @llvm.returnaddress.p0(i32 85)
  store ptr %174, ptr %2, align 8
  br label %206

175:                                              ; preds = %1
  %176 = call ptr @llvm.returnaddress.p0(i32 86)
  store ptr %176, ptr %2, align 8
  br label %206

177:                                              ; preds = %1
  %178 = call ptr @llvm.returnaddress.p0(i32 87)
  store ptr %178, ptr %2, align 8
  br label %206

179:                                              ; preds = %1
  %180 = call ptr @llvm.returnaddress.p0(i32 88)
  store ptr %180, ptr %2, align 8
  br label %206

181:                                              ; preds = %1
  %182 = call ptr @llvm.returnaddress.p0(i32 89)
  store ptr %182, ptr %2, align 8
  br label %206

183:                                              ; preds = %1
  %184 = call ptr @llvm.returnaddress.p0(i32 90)
  store ptr %184, ptr %2, align 8
  br label %206

185:                                              ; preds = %1
  %186 = call ptr @llvm.returnaddress.p0(i32 91)
  store ptr %186, ptr %2, align 8
  br label %206

187:                                              ; preds = %1
  %188 = call ptr @llvm.returnaddress.p0(i32 92)
  store ptr %188, ptr %2, align 8
  br label %206

189:                                              ; preds = %1
  %190 = call ptr @llvm.returnaddress.p0(i32 93)
  store ptr %190, ptr %2, align 8
  br label %206

191:                                              ; preds = %1
  %192 = call ptr @llvm.returnaddress.p0(i32 94)
  store ptr %192, ptr %2, align 8
  br label %206

193:                                              ; preds = %1
  %194 = call ptr @llvm.returnaddress.p0(i32 95)
  store ptr %194, ptr %2, align 8
  br label %206

195:                                              ; preds = %1
  %196 = call ptr @llvm.returnaddress.p0(i32 96)
  store ptr %196, ptr %2, align 8
  br label %206

197:                                              ; preds = %1
  %198 = call ptr @llvm.returnaddress.p0(i32 97)
  store ptr %198, ptr %2, align 8
  br label %206

199:                                              ; preds = %1
  %200 = call ptr @llvm.returnaddress.p0(i32 98)
  store ptr %200, ptr %2, align 8
  br label %206

201:                                              ; preds = %1
  %202 = call ptr @llvm.returnaddress.p0(i32 99)
  store ptr %202, ptr %2, align 8
  br label %206

203:                                              ; preds = %1
  %204 = call ptr @llvm.returnaddress.p0(i32 100)
  store ptr %204, ptr %2, align 8
  br label %206

205:                                              ; preds = %1
  store ptr null, ptr %2, align 8
  br label %206

206:                                              ; preds = %205, %203, %201, %199, %197, %195, %193, %191, %189, %187, %185, %183, %181, %179, %177, %175, %173, %171, %169, %167, %165, %163, %161, %159, %157, %155, %153, %151, %149, %147, %145, %143, %141, %139, %137, %135, %133, %131, %129, %127, %125, %123, %121, %119, %117, %115, %113, %111, %109, %107, %105, %103, %101, %99, %97, %95, %93, %91, %89, %87, %85, %83, %81, %79, %77, %75, %73, %71, %69, %67, %65, %63, %61, %59, %57, %55, %53, %51, %49, %47, %45, %43, %41, %39, %37, %35, %33, %31, %29, %27, %25, %23, %21, %19, %17, %15, %13, %11, %9, %7, %5
  %207 = load ptr, ptr %2, align 8
  ret ptr %207
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.returnaddress.p0(i32 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
