; ModuleID = '20110418-1.c'
source_filename = "20110418-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %10 = load i64, ptr %4, align 8
  store i64 %10, ptr %5, align 8
  %11 = load ptr, ptr %3, align 8
  %12 = load i64, ptr %11, align 8
  store i64 %12, ptr %6, align 8
  store i32 32, ptr %7, align 4
  store i64 4294967295, ptr %8, align 8
  %13 = load i64, ptr %6, align 8
  %14 = load i64, ptr %8, align 8
  %15 = and i64 %13, %14
  store i64 %15, ptr %9, align 8
  %16 = load i64, ptr %8, align 8
  %17 = load i64, ptr %5, align 8
  %18 = and i64 %17, %16
  store i64 %18, ptr %5, align 8
  %19 = load i64, ptr %9, align 8
  %20 = load i64, ptr %5, align 8
  %21 = icmp ugt i64 %19, %20
  br i1 %21, label %22, label %28

22:                                               ; preds = %2
  %23 = load i32, ptr %7, align 4
  %24 = zext i32 %23 to i64
  %25 = shl i64 1, %24
  %26 = load i64, ptr %5, align 8
  %27 = add i64 %26, %25
  store i64 %27, ptr %5, align 8
  br label %28

28:                                               ; preds = %22, %2
  %29 = load i64, ptr %6, align 8
  %30 = load i64, ptr %8, align 8
  %31 = xor i64 %30, -1
  %32 = and i64 %29, %31
  %33 = load i64, ptr %5, align 8
  %34 = add i64 %33, %32
  store i64 %34, ptr %5, align 8
  %35 = load i64, ptr %5, align 8
  %36 = load ptr, ptr %3, align 8
  store i64 %35, ptr %36, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store i32 0, ptr %1, align 4
  store i64 4294967297, ptr %2, align 8
  %5 = load i64, ptr %2, align 8
  store i64 %5, ptr %4, align 8
  %6 = load i64, ptr %2, align 8
  %7 = add i64 %6, 1
  %8 = and i64 %7, 4294967295
  store i64 %8, ptr %3, align 8
  %9 = load i64, ptr %3, align 8
  call void @f(ptr noundef %2, i64 noundef %9)
  %10 = load i64, ptr %2, align 8
  %11 = load i64, ptr %4, align 8
  %12 = add i64 %11, 1
  %13 = icmp ne i64 %10, %12
  br i1 %13, label %14, label %15

14:                                               ; preds = %0
  call void @abort() #2
  unreachable

15:                                               ; preds = %0
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
