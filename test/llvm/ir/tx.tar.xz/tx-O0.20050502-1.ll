; ModuleID = '20050502-1.c'
source_filename = "20050502-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@.str = private unnamed_addr constant [10 x i8] c"abcde'fgh\00", align 1
@.str.1 = private unnamed_addr constant [4 x i8] c"fgh\00", align 1
@.str.2 = private unnamed_addr constant [6 x i8] c"abcde\00", align 1
@.str.3 = private unnamed_addr constant [11 x i8] c"ABCDEFG\22HI\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"HI\00", align 1
@.str.5 = private unnamed_addr constant [8 x i8] c"ABCDEFG\00", align 1
@.str.6 = private unnamed_addr constant [11 x i8] c"abcd\22e'fgh\00", align 1
@.str.7 = private unnamed_addr constant [6 x i8] c"e'fgh\00", align 1
@.str.8 = private unnamed_addr constant [5 x i8] c"abcd\00", align 1
@.str.9 = private unnamed_addr constant [12 x i8] c"ABCDEF'G\22HI\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"G\22HI\00", align 1
@.str.11 = private unnamed_addr constant [7 x i8] c"ABCDEF\00", align 1
@.str.12 = private unnamed_addr constant [10 x i8] c"abcdef@gh\00", align 1
@.str.13 = private unnamed_addr constant [3 x i8] c"gh\00", align 1
@.str.14 = private unnamed_addr constant [7 x i8] c"abcdef\00", align 1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @bar(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds nuw i8, ptr %4, i32 1
  store ptr %5, ptr %3, align 8
  %6 = load i8, ptr %4, align 1
  %7 = sext i8 %6 to i32
  ret i32 %7
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @baz(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = icmp ne i32 %3, 64
  %5 = zext i1 %4 to i32
  ret i32 %5
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0, ptr noundef %1, i1 noundef zeroext %2, i1 noundef zeroext %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i8, align 1
  %8 = alloca i8, align 1
  %9 = alloca i8, align 1
  %10 = alloca i32, align 4
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  %11 = zext i1 %2 to i8
  store i8 %11, ptr %7, align 1
  %12 = zext i1 %3 to i8
  store i8 %12, ptr %8, align 1
  %13 = load ptr, ptr %5, align 8
  %14 = call i32 @bar(ptr noundef %13)
  %15 = trunc i32 %14 to i8
  store i8 %15, ptr %9, align 1
  store i32 0, ptr %10, align 4
  br label %16

16:                                               ; preds = %4, %53
  %17 = load i8, ptr %9, align 1
  %18 = load ptr, ptr %6, align 8
  %19 = load i32, ptr %10, align 4
  %20 = add nsw i32 %19, 1
  store i32 %20, ptr %10, align 4
  %21 = sext i32 %19 to i64
  %22 = getelementptr inbounds i8, ptr %18, i64 %21
  store i8 %17, ptr %22, align 1
  %23 = load ptr, ptr %5, align 8
  %24 = call i32 @bar(ptr noundef %23)
  %25 = trunc i32 %24 to i8
  store i8 %25, ptr %9, align 1
  %26 = load i8, ptr %7, align 1
  %27 = icmp ne i8 %26, 0
  br i1 %27, label %28, label %33

28:                                               ; preds = %16
  %29 = load i8, ptr %9, align 1
  %30 = sext i8 %29 to i32
  %31 = icmp eq i32 %30, 39
  br i1 %31, label %32, label %33

32:                                               ; preds = %28
  br label %54

33:                                               ; preds = %28, %16
  %34 = load i8, ptr %8, align 1
  %35 = icmp ne i8 %34, 0
  br i1 %35, label %36, label %41

36:                                               ; preds = %33
  %37 = load i8, ptr %9, align 1
  %38 = sext i8 %37 to i32
  %39 = icmp eq i32 %38, 34
  br i1 %39, label %40, label %41

40:                                               ; preds = %36
  br label %54

41:                                               ; preds = %36, %33
  %42 = load i8, ptr %7, align 1
  %43 = icmp ne i8 %42, 0
  br i1 %43, label %53, label %44

44:                                               ; preds = %41
  %45 = load i8, ptr %8, align 1
  %46 = icmp ne i8 %45, 0
  br i1 %46, label %53, label %47

47:                                               ; preds = %44
  %48 = load i8, ptr %9, align 1
  %49 = sext i8 %48 to i32
  %50 = call i32 @baz(i32 noundef %49)
  %51 = icmp ne i32 %50, 0
  br i1 %51, label %53, label %52

52:                                               ; preds = %47
  br label %54

53:                                               ; preds = %47, %44, %41
  br label %16

54:                                               ; preds = %52, %40, %32
  %55 = load ptr, ptr %6, align 8
  %56 = load i32, ptr %10, align 4
  %57 = sext i32 %56 to i64
  %58 = getelementptr inbounds i8, ptr %55, i64 %57
  store i8 0, ptr %58, align 1
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [64 x i8], align 16
  %3 = alloca ptr, align 8
  store i32 0, ptr %1, align 4
  store ptr @.str, ptr %3, align 8
  %4 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %3, ptr noundef %4, i1 noundef zeroext true, i1 noundef zeroext false)
  %5 = load ptr, ptr %3, align 8
  %6 = call i32 @strcmp(ptr noundef %5, ptr noundef @.str.1) #3
  %7 = icmp ne i32 %6, 0
  br i1 %7, label %12, label %8

8:                                                ; preds = %0
  %9 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  %10 = call i32 @strcmp(ptr noundef %9, ptr noundef @.str.2) #3
  %11 = icmp ne i32 %10, 0
  br i1 %11, label %12, label %13

12:                                               ; preds = %8, %0
  call void @abort() #4
  unreachable

13:                                               ; preds = %8
  store ptr @.str.3, ptr %3, align 8
  %14 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %3, ptr noundef %14, i1 noundef zeroext false, i1 noundef zeroext true)
  %15 = load ptr, ptr %3, align 8
  %16 = call i32 @strcmp(ptr noundef %15, ptr noundef @.str.4) #3
  %17 = icmp ne i32 %16, 0
  br i1 %17, label %22, label %18

18:                                               ; preds = %13
  %19 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  %20 = call i32 @strcmp(ptr noundef %19, ptr noundef @.str.5) #3
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %22, label %23

22:                                               ; preds = %18, %13
  call void @abort() #4
  unreachable

23:                                               ; preds = %18
  store ptr @.str.6, ptr %3, align 8
  %24 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %3, ptr noundef %24, i1 noundef zeroext true, i1 noundef zeroext true)
  %25 = load ptr, ptr %3, align 8
  %26 = call i32 @strcmp(ptr noundef %25, ptr noundef @.str.7) #3
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %32, label %28

28:                                               ; preds = %23
  %29 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  %30 = call i32 @strcmp(ptr noundef %29, ptr noundef @.str.8) #3
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %32, label %33

32:                                               ; preds = %28, %23
  call void @abort() #4
  unreachable

33:                                               ; preds = %28
  store ptr @.str.9, ptr %3, align 8
  %34 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %3, ptr noundef %34, i1 noundef zeroext true, i1 noundef zeroext true)
  %35 = load ptr, ptr %3, align 8
  %36 = call i32 @strcmp(ptr noundef %35, ptr noundef @.str.10) #3
  %37 = icmp ne i32 %36, 0
  br i1 %37, label %42, label %38

38:                                               ; preds = %33
  %39 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  %40 = call i32 @strcmp(ptr noundef %39, ptr noundef @.str.11) #3
  %41 = icmp ne i32 %40, 0
  br i1 %41, label %42, label %43

42:                                               ; preds = %38, %33
  call void @abort() #4
  unreachable

43:                                               ; preds = %38
  store ptr @.str.12, ptr %3, align 8
  %44 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  call void @foo(ptr noundef %3, ptr noundef %44, i1 noundef zeroext false, i1 noundef zeroext false)
  %45 = load ptr, ptr %3, align 8
  %46 = call i32 @strcmp(ptr noundef %45, ptr noundef @.str.13) #3
  %47 = icmp ne i32 %46, 0
  br i1 %47, label %52, label %48

48:                                               ; preds = %43
  %49 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 0
  %50 = call i32 @strcmp(ptr noundef %49, ptr noundef @.str.14) #3
  %51 = icmp ne i32 %50, 0
  br i1 %51, label %52, label %53

52:                                               ; preds = %48, %43
  call void @abort() #4
  unreachable

53:                                               ; preds = %48
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @strcmp(ptr noundef, ptr noundef) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nounwind }
attributes #4 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
