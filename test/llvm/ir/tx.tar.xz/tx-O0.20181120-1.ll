; ModuleID = '20181120-1.c'
source_filename = "20181120-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.U1 = type { i32 }

@d = dso_local global i32 0, align 4
@e = dso_local global ptr @d, align 8
@u = dso_local global %union.U1 { i32 67305985 }, align 4
@c = dso_local global i32 0, align 4
@__const.main.f = private unnamed_addr constant %union.U1 { i32 67305985 }, align 4
@b = dso_local global i32 0, align 4
@a = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %union.U1, align 4
  store i32 0, ptr %1, align 4
  store i32 0, ptr @c, align 4
  br label %3

3:                                                ; preds = %16, %0
  %4 = load i32, ptr @c, align 4
  %5 = icmp sle i32 %4, 1
  br i1 %5, label %6, label %19

6:                                                ; preds = %3
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 @__const.main.f, i64 4, i1 false)
  %7 = load i32, ptr @c, align 4
  %8 = icmp eq i32 %7, 1
  br i1 %8, label %9, label %11

9:                                                ; preds = %6
  %10 = load volatile i32, ptr @b, align 4
  br label %11

11:                                               ; preds = %9, %6
  %12 = load i16, ptr %2, align 4
  %13 = and i16 %12, 32767
  %14 = zext i16 %13 to i32
  %15 = load ptr, ptr @e, align 8
  store i32 %14, ptr %15, align 4
  br label %16

16:                                               ; preds = %11
  %17 = load i32, ptr @c, align 4
  %18 = add nsw i32 %17, 1
  store i32 %18, ptr @c, align 4
  br label %3, !llvm.loop !6

19:                                               ; preds = %3
  %20 = load i32, ptr @d, align 4
  %21 = load volatile i16, ptr @u, align 4
  %22 = and i16 %21, 32767
  %23 = zext i16 %22 to i32
  %24 = icmp ne i32 %20, %23
  br i1 %24, label %25, label %26

25:                                               ; preds = %19
  call void @abort() #3
  unreachable

26:                                               ; preds = %19
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
