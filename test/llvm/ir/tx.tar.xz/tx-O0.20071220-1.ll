; ModuleID = '20071220-1.c'
source_filename = "20071220-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@bar.b = internal global [1 x ptr] [ptr blockaddress(@bar, %4)], align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local ptr @baz(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = call ptr asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(ptr %3) #2, !srcloc !6
  store ptr %4, ptr %2, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = load ptr, ptr %5, align 8
  ret ptr %6
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f1() #0 {
  %1 = call i32 @bar()
  ret i32 %1
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @bar() #0 {
  %1 = alloca ptr, align 8
  %2 = call ptr @baz(ptr noundef @bar.b)
  store ptr %2, ptr %1, align 8
  %3 = load ptr, ptr %1, align 8
  br label %5

4:                                                ; preds = %5
  ret i32 17

5:                                                ; preds = %0
  %6 = phi ptr [ %3, %0 ]
  indirectbr ptr %6, [label %4]
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f2() #0 {
  %1 = call i32 @bar()
  ret i32 %1
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %2 = call i32 @f1()
  %3 = icmp ne i32 %2, 17
  br i1 %3, label %13, label %4

4:                                                ; preds = %0
  %5 = call i32 @f1()
  %6 = icmp ne i32 %5, 17
  br i1 %6, label %13, label %7

7:                                                ; preds = %4
  %8 = call i32 @f2()
  %9 = icmp ne i32 %8, 17
  br i1 %9, label %13, label %10

10:                                               ; preds = %7
  %11 = call i32 @f2()
  %12 = icmp ne i32 %11, 17
  br i1 %12, label %13, label %14

13:                                               ; preds = %10, %7, %4, %0
  call void @abort() #3
  unreachable

14:                                               ; preds = %10
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nounwind }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = !{i64 234}
