; ModuleID = '20040703-1.c'
source_filename = "20040703-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.cpp_num = type { i32, i32, i32, i32 }

@precision = dso_local global i32 64, align 4
@n = dso_local global i32 16, align 4
@num = dso_local global %struct.cpp_num { i32 0, i32 3, i32 0, i32 0 }, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local { i64, i64 } @num_lshift(i64 %0, i64 %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca %struct.cpp_num, align 4
  %6 = alloca %struct.cpp_num, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca %struct.cpp_num, align 4
  %10 = alloca i32, align 4
  %11 = alloca %struct.cpp_num, align 4
  %12 = alloca %struct.cpp_num, align 4
  %13 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  store i64 %0, ptr %13, align 4
  %14 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  store i64 %1, ptr %14, align 4
  store i32 %2, ptr %7, align 4
  store i32 %3, ptr %8, align 4
  %15 = load i32, ptr %8, align 4
  %16 = load i32, ptr %7, align 4
  %17 = icmp uge i32 %15, %16
  br i1 %17, label %18, label %36

18:                                               ; preds = %4
  %19 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 2
  %20 = load i32, ptr %19, align 4
  %21 = icmp ne i32 %20, 0
  br i1 %21, label %30, label %22

22:                                               ; preds = %18
  %23 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %26 = load i32, ptr %25, align 4
  %27 = or i32 %24, %26
  %28 = icmp eq i32 %27, 0
  %29 = xor i1 %28, true
  br label %30

30:                                               ; preds = %22, %18
  %31 = phi i1 [ false, %18 ], [ %29, %22 ]
  %32 = zext i1 %31 to i32
  %33 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 3
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  store i32 0, ptr %34, align 4
  %35 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 0, ptr %35, align 4
  br label %116

36:                                               ; preds = %4
  %37 = load i32, ptr %8, align 4
  store i32 %37, ptr %10, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %9, ptr align 4 %6, i64 16, i1 false)
  %38 = load i32, ptr %10, align 4
  %39 = zext i32 %38 to i64
  %40 = icmp uge i64 %39, 32
  br i1 %40, label %41, label %50

41:                                               ; preds = %36
  %42 = load i32, ptr %10, align 4
  %43 = zext i32 %42 to i64
  %44 = sub i64 %43, 32
  %45 = trunc i64 %44 to i32
  store i32 %45, ptr %10, align 4
  %46 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %47, ptr %48, align 4
  %49 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  store i32 0, ptr %49, align 4
  br label %50

50:                                               ; preds = %41, %36
  %51 = load i32, ptr %10, align 4
  %52 = icmp ne i32 %51, 0
  br i1 %52, label %53, label %71

53:                                               ; preds = %50
  %54 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %55 = load i32, ptr %54, align 4
  %56 = load i32, ptr %10, align 4
  %57 = shl i32 %55, %56
  %58 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %59 = load i32, ptr %58, align 4
  %60 = load i32, ptr %10, align 4
  %61 = zext i32 %60 to i64
  %62 = sub i64 32, %61
  %63 = trunc i64 %62 to i32
  %64 = lshr i32 %59, %63
  %65 = or i32 %57, %64
  %66 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %65, ptr %66, align 4
  %67 = load i32, ptr %10, align 4
  %68 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %69 = load i32, ptr %68, align 4
  %70 = shl i32 %69, %67
  store i32 %70, ptr %68, align 4
  br label %71

71:                                               ; preds = %53, %50
  %72 = load i32, ptr %7, align 4
  %73 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  %74 = load i64, ptr %73, align 4
  %75 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  %76 = load i64, ptr %75, align 4
  %77 = call { i64, i64 } @num_trim(i64 %74, i64 %76, i32 noundef %72)
  %78 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 0
  %79 = extractvalue { i64, i64 } %77, 0
  store i64 %79, ptr %78, align 4
  %80 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 1
  %81 = extractvalue { i64, i64 } %77, 1
  store i64 %81, ptr %80, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 %11, i64 16, i1 false)
  %82 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 2
  %83 = load i32, ptr %82, align 4
  %84 = icmp ne i32 %83, 0
  br i1 %84, label %85, label %87

85:                                               ; preds = %71
  %86 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 3
  store i32 0, ptr %86, align 4
  br label %115

87:                                               ; preds = %71
  %88 = load i32, ptr %7, align 4
  %89 = load i32, ptr %8, align 4
  %90 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  %91 = load i64, ptr %90, align 4
  %92 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  %93 = load i64, ptr %92, align 4
  %94 = call { i64, i64 } @num_rshift(i64 %91, i64 %93, i32 noundef %88, i32 noundef %89)
  %95 = getelementptr inbounds nuw { i64, i64 }, ptr %12, i32 0, i32 0
  %96 = extractvalue { i64, i64 } %94, 0
  store i64 %96, ptr %95, align 4
  %97 = getelementptr inbounds nuw { i64, i64 }, ptr %12, i32 0, i32 1
  %98 = extractvalue { i64, i64 } %94, 1
  store i64 %98, ptr %97, align 4
  %99 = getelementptr inbounds nuw %struct.cpp_num, ptr %9, i32 0, i32 1
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr inbounds nuw %struct.cpp_num, ptr %12, i32 0, i32 1
  %102 = load i32, ptr %101, align 4
  %103 = icmp eq i32 %100, %102
  br i1 %103, label %104, label %110

104:                                              ; preds = %87
  %105 = getelementptr inbounds nuw %struct.cpp_num, ptr %9, i32 0, i32 0
  %106 = load i32, ptr %105, align 4
  %107 = getelementptr inbounds nuw %struct.cpp_num, ptr %12, i32 0, i32 0
  %108 = load i32, ptr %107, align 4
  %109 = icmp eq i32 %106, %108
  br label %110

110:                                              ; preds = %104, %87
  %111 = phi i1 [ false, %87 ], [ %109, %104 ]
  %112 = xor i1 %111, true
  %113 = zext i1 %112 to i32
  %114 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 3
  store i32 %113, ptr %114, align 4
  br label %115

115:                                              ; preds = %110, %85
  br label %116

116:                                              ; preds = %115, %30
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %6, i64 16, i1 false)
  %117 = load { i64, i64 }, ptr %5, align 4
  ret { i64, i64 } %117
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal { i64, i64 } @num_trim(i64 %0, i64 %1, i32 noundef %2) #0 {
  %4 = alloca %struct.cpp_num, align 4
  %5 = alloca %struct.cpp_num, align 4
  %6 = alloca i32, align 4
  %7 = getelementptr inbounds nuw { i64, i64 }, ptr %5, i32 0, i32 0
  store i64 %0, ptr %7, align 4
  %8 = getelementptr inbounds nuw { i64, i64 }, ptr %5, i32 0, i32 1
  store i64 %1, ptr %8, align 4
  store i32 %2, ptr %6, align 4
  %9 = load i32, ptr %6, align 4
  %10 = zext i32 %9 to i64
  %11 = icmp ugt i64 %10, 32
  br i1 %11, label %12, label %28

12:                                               ; preds = %3
  %13 = load i32, ptr %6, align 4
  %14 = zext i32 %13 to i64
  %15 = sub i64 %14, 32
  %16 = trunc i64 %15 to i32
  store i32 %16, ptr %6, align 4
  %17 = load i32, ptr %6, align 4
  %18 = zext i32 %17 to i64
  %19 = icmp ult i64 %18, 32
  br i1 %19, label %20, label %27

20:                                               ; preds = %12
  %21 = load i32, ptr %6, align 4
  %22 = shl i32 1, %21
  %23 = sub i32 %22, 1
  %24 = getelementptr inbounds nuw %struct.cpp_num, ptr %5, i32 0, i32 0
  %25 = load i32, ptr %24, align 4
  %26 = and i32 %25, %23
  store i32 %26, ptr %24, align 4
  br label %27

27:                                               ; preds = %20, %12
  br label %41

28:                                               ; preds = %3
  %29 = load i32, ptr %6, align 4
  %30 = zext i32 %29 to i64
  %31 = icmp ult i64 %30, 32
  br i1 %31, label %32, label %39

32:                                               ; preds = %28
  %33 = load i32, ptr %6, align 4
  %34 = shl i32 1, %33
  %35 = sub i32 %34, 1
  %36 = getelementptr inbounds nuw %struct.cpp_num, ptr %5, i32 0, i32 1
  %37 = load i32, ptr %36, align 4
  %38 = and i32 %37, %35
  store i32 %38, ptr %36, align 4
  br label %39

39:                                               ; preds = %32, %28
  %40 = getelementptr inbounds nuw %struct.cpp_num, ptr %5, i32 0, i32 0
  store i32 0, ptr %40, align 4
  br label %41

41:                                               ; preds = %39, %27
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 4 %5, i64 16, i1 false)
  %42 = load { i64, i64 }, ptr %4, align 4
  ret { i64, i64 } %42
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal { i64, i64 } @num_rshift(i64 %0, i64 %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca %struct.cpp_num, align 4
  %6 = alloca %struct.cpp_num, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca %struct.cpp_num, align 4
  %12 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  store i64 %0, ptr %12, align 4
  %13 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  store i64 %1, ptr %13, align 4
  store i32 %2, ptr %7, align 4
  store i32 %3, ptr %8, align 4
  %14 = load i32, ptr %7, align 4
  %15 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  %16 = load i64, ptr %15, align 4
  %17 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  %18 = load i64, ptr %17, align 4
  %19 = call i32 @num_positive(i64 %16, i64 %18, i32 noundef %14)
  store i32 %19, ptr %10, align 4
  %20 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 2
  %21 = load i32, ptr %20, align 4
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %26, label %23

23:                                               ; preds = %4
  %24 = load i32, ptr %10, align 4
  %25 = icmp ne i32 %24, 0
  br i1 %25, label %26, label %27

26:                                               ; preds = %23, %4
  store i32 0, ptr %9, align 4
  br label %28

27:                                               ; preds = %23
  store i32 -1, ptr %9, align 4
  br label %28

28:                                               ; preds = %27, %26
  %29 = load i32, ptr %8, align 4
  %30 = load i32, ptr %7, align 4
  %31 = icmp uge i32 %29, %30
  br i1 %31, label %32, label %36

32:                                               ; preds = %28
  %33 = load i32, ptr %9, align 4
  %34 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  store i32 %33, ptr %34, align 4
  %35 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %33, ptr %35, align 4
  br label %108

36:                                               ; preds = %28
  %37 = load i32, ptr %7, align 4
  %38 = zext i32 %37 to i64
  %39 = icmp ult i64 %38, 32
  br i1 %39, label %40, label %49

40:                                               ; preds = %36
  %41 = load i32, ptr %9, align 4
  %42 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %41, ptr %42, align 4
  %43 = load i32, ptr %9, align 4
  %44 = load i32, ptr %7, align 4
  %45 = shl i32 %43, %44
  %46 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %47 = load i32, ptr %46, align 4
  %48 = or i32 %47, %45
  store i32 %48, ptr %46, align 4
  br label %64

49:                                               ; preds = %36
  %50 = load i32, ptr %7, align 4
  %51 = zext i32 %50 to i64
  %52 = icmp ult i64 %51, 64
  br i1 %52, label %53, label %63

53:                                               ; preds = %49
  %54 = load i32, ptr %9, align 4
  %55 = load i32, ptr %7, align 4
  %56 = zext i32 %55 to i64
  %57 = sub i64 %56, 32
  %58 = trunc i64 %57 to i32
  %59 = shl i32 %54, %58
  %60 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %61 = load i32, ptr %60, align 4
  %62 = or i32 %61, %59
  store i32 %62, ptr %60, align 4
  br label %63

63:                                               ; preds = %53, %49
  br label %64

64:                                               ; preds = %63, %40
  %65 = load i32, ptr %8, align 4
  %66 = zext i32 %65 to i64
  %67 = icmp uge i64 %66, 32
  br i1 %67, label %68, label %78

68:                                               ; preds = %64
  %69 = load i32, ptr %8, align 4
  %70 = zext i32 %69 to i64
  %71 = sub i64 %70, 32
  %72 = trunc i64 %71 to i32
  store i32 %72, ptr %8, align 4
  %73 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  store i32 %74, ptr %75, align 4
  %76 = load i32, ptr %9, align 4
  %77 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %76, ptr %77, align 4
  br label %78

78:                                               ; preds = %68, %64
  %79 = load i32, ptr %8, align 4
  %80 = icmp ne i32 %79, 0
  br i1 %80, label %81, label %107

81:                                               ; preds = %78
  %82 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  %83 = load i32, ptr %82, align 4
  %84 = load i32, ptr %8, align 4
  %85 = lshr i32 %83, %84
  %86 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %87 = load i32, ptr %86, align 4
  %88 = load i32, ptr %8, align 4
  %89 = zext i32 %88 to i64
  %90 = sub i64 32, %89
  %91 = trunc i64 %90 to i32
  %92 = shl i32 %87, %91
  %93 = or i32 %85, %92
  %94 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 1
  store i32 %93, ptr %94, align 4
  %95 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  %96 = load i32, ptr %95, align 4
  %97 = load i32, ptr %8, align 4
  %98 = lshr i32 %96, %97
  %99 = load i32, ptr %9, align 4
  %100 = load i32, ptr %8, align 4
  %101 = zext i32 %100 to i64
  %102 = sub i64 32, %101
  %103 = trunc i64 %102 to i32
  %104 = shl i32 %99, %103
  %105 = or i32 %98, %104
  %106 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 0
  store i32 %105, ptr %106, align 4
  br label %107

107:                                              ; preds = %81, %78
  br label %108

108:                                              ; preds = %107, %32
  %109 = load i32, ptr %7, align 4
  %110 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 0
  %111 = load i64, ptr %110, align 4
  %112 = getelementptr inbounds nuw { i64, i64 }, ptr %6, i32 0, i32 1
  %113 = load i64, ptr %112, align 4
  %114 = call { i64, i64 } @num_trim(i64 %111, i64 %113, i32 noundef %109)
  %115 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 0
  %116 = extractvalue { i64, i64 } %114, 0
  store i64 %116, ptr %115, align 4
  %117 = getelementptr inbounds nuw { i64, i64 }, ptr %11, i32 0, i32 1
  %118 = extractvalue { i64, i64 } %114, 1
  store i64 %118, ptr %117, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %6, ptr align 4 %11, i64 16, i1 false)
  %119 = getelementptr inbounds nuw %struct.cpp_num, ptr %6, i32 0, i32 3
  store i32 0, ptr %119, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %5, ptr align 4 %6, i64 16, i1 false)
  %120 = load { i64, i64 }, ptr %5, align 4
  ret { i64, i64 } %120
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.cpp_num, align 4
  store i32 0, ptr %1, align 4
  %3 = load i32, ptr @n, align 4
  %4 = load i64, ptr @num, align 4
  %5 = load i64, ptr getelementptr inbounds nuw (i8, ptr @num, i64 8), align 4
  %6 = call { i64, i64 } @num_lshift(i64 %4, i64 %5, i32 noundef 64, i32 noundef %3)
  %7 = getelementptr inbounds nuw { i64, i64 }, ptr %2, i32 0, i32 0
  %8 = extractvalue { i64, i64 } %6, 0
  store i64 %8, ptr %7, align 4
  %9 = getelementptr inbounds nuw { i64, i64 }, ptr %2, i32 0, i32 1
  %10 = extractvalue { i64, i64 } %6, 1
  store i64 %10, ptr %9, align 4
  %11 = getelementptr inbounds nuw %struct.cpp_num, ptr %2, i32 0, i32 1
  %12 = load i32, ptr %11, align 4
  %13 = icmp ne i32 %12, 196608
  br i1 %13, label %14, label %15

14:                                               ; preds = %0
  call void @abort() #4
  unreachable

15:                                               ; preds = %0
  %16 = getelementptr inbounds nuw %struct.cpp_num, ptr %2, i32 0, i32 0
  %17 = load i32, ptr %16, align 4
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %15
  call void @abort() #4
  unreachable

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw %struct.cpp_num, ptr %2, i32 0, i32 3
  %22 = load i32, ptr %21, align 4
  %23 = icmp ne i32 %22, 0
  br i1 %23, label %24, label %25

24:                                               ; preds = %20
  call void @abort() #4
  unreachable

25:                                               ; preds = %20
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @num_positive(i64 %0, i64 %1, i32 noundef %2) #0 {
  %4 = alloca i32, align 4
  %5 = alloca %struct.cpp_num, align 4
  %6 = alloca i32, align 4
  %7 = getelementptr inbounds nuw { i64, i64 }, ptr %5, i32 0, i32 0
  store i64 %0, ptr %7, align 4
  %8 = getelementptr inbounds nuw { i64, i64 }, ptr %5, i32 0, i32 1
  store i64 %1, ptr %8, align 4
  store i32 %2, ptr %6, align 4
  %9 = load i32, ptr %6, align 4
  %10 = zext i32 %9 to i64
  %11 = icmp ugt i64 %10, 32
  br i1 %11, label %12, label %25

12:                                               ; preds = %3
  %13 = load i32, ptr %6, align 4
  %14 = zext i32 %13 to i64
  %15 = sub i64 %14, 32
  %16 = trunc i64 %15 to i32
  store i32 %16, ptr %6, align 4
  %17 = getelementptr inbounds nuw %struct.cpp_num, ptr %5, i32 0, i32 0
  %18 = load i32, ptr %17, align 4
  %19 = load i32, ptr %6, align 4
  %20 = sub i32 %19, 1
  %21 = shl i32 1, %20
  %22 = and i32 %18, %21
  %23 = icmp eq i32 %22, 0
  %24 = zext i1 %23 to i32
  store i32 %24, ptr %4, align 4
  br label %34

25:                                               ; preds = %3
  %26 = getelementptr inbounds nuw %struct.cpp_num, ptr %5, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = load i32, ptr %6, align 4
  %29 = sub i32 %28, 1
  %30 = shl i32 1, %29
  %31 = and i32 %27, %30
  %32 = icmp eq i32 %31, 0
  %33 = zext i1 %32 to i32
  store i32 %33, ptr %4, align 4
  br label %34

34:                                               ; preds = %25, %12
  %35 = load i32, ptr %4, align 4
  ret i32 %35
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
