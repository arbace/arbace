; ModuleID = '20030224-2.c'
source_filename = "20030224-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.node = type { %struct.jint16_t, %struct.jint16_t, i32 }
%struct.jint16_t = type { i16 }

@node = dso_local global %struct.node zeroinitializer, align 1
@node_p = dso_local global ptr @node, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.node, align 1
  store i32 0, ptr %1, align 4
  %3 = getelementptr inbounds nuw %struct.node, ptr %2, i32 0, i32 0
  %4 = getelementptr inbounds nuw %struct.jint16_t, ptr %3, i32 0, i32 0
  store i16 6533, ptr %4, align 1
  %5 = getelementptr inbounds nuw %struct.node, ptr %2, i32 0, i32 1
  %6 = getelementptr inbounds nuw %struct.jint16_t, ptr %5, i32 0, i32 0
  store i16 8195, ptr %6, align 1
  %7 = getelementptr inbounds nuw %struct.node, ptr %2, i32 0, i32 2
  %8 = load ptr, ptr @node_p, align 8
  %9 = getelementptr inbounds nuw %struct.node, ptr %8, i32 0, i32 2
  %10 = load i32, ptr %9, align 1
  store i32 %10, ptr %7, align 1
  %11 = getelementptr inbounds nuw %struct.node, ptr %2, i32 0, i32 0
  %12 = getelementptr inbounds nuw %struct.jint16_t, ptr %11, i32 0, i32 0
  %13 = load i16, ptr %12, align 1
  %14 = sext i16 %13 to i32
  %15 = icmp ne i32 %14, 6533
  br i1 %15, label %16, label %17

16:                                               ; preds = %0
  call void @abort() #2
  unreachable

17:                                               ; preds = %0
  %18 = getelementptr inbounds nuw %struct.node, ptr %2, i32 0, i32 1
  %19 = getelementptr inbounds nuw %struct.jint16_t, ptr %18, i32 0, i32 0
  %20 = load i16, ptr %19, align 1
  %21 = sext i16 %20 to i32
  %22 = icmp ne i32 %21, 8195
  br i1 %22, label %23, label %24

23:                                               ; preds = %17
  call void @abort() #2
  unreachable

24:                                               ; preds = %17
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
