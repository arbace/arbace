; ModuleID = '20020314-1.c'
source_filename = "20020314-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f(ptr noundef %0, double noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca double, align 8
  store ptr %0, ptr %3, align 8
  store double %1, ptr %4, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @g(double noundef %0, double noundef %1, double noundef %2, double noundef %3) #0 {
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca ptr, align 8
  store double %0, ptr %5, align 8
  store double %1, ptr %6, align 8
  store double %2, ptr %7, align 8
  store double %3, ptr %8, align 8
  %13 = load double, ptr %5, align 8
  %14 = load double, ptr %6, align 8
  %15 = fadd double %13, %14
  store double %15, ptr %9, align 8
  %16 = load double, ptr %7, align 8
  %17 = load double, ptr %8, align 8
  %18 = fmul double %16, %17
  store double %18, ptr %10, align 8
  %19 = alloca i8, i64 16, align 16
  store ptr %19, ptr %12, align 8
  %20 = load ptr, ptr %12, align 8
  %21 = load double, ptr %10, align 8
  call void @f(ptr noundef %20, double noundef %21)
  %22 = load double, ptr %9, align 8
  %23 = load double, ptr %10, align 8
  %24 = fmul double %22, %23
  %25 = load double, ptr %5, align 8
  %26 = fmul double %24, %25
  store double %26, ptr %11, align 8
  %27 = load double, ptr %11, align 8
  %28 = load double, ptr %6, align 8
  %29 = fadd double %27, %28
  ret double %29
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  store i32 0, ptr %1, align 4
  store double 1.000000e+00, ptr %2, align 8
  store double 0.000000e+00, ptr %3, align 8
  store double 1.000000e+01, ptr %4, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = load double, ptr %2, align 8
  %7 = load double, ptr %3, align 8
  %8 = load double, ptr %4, align 8
  %9 = load double, ptr %5, align 8
  %10 = call double @g(double noundef %6, double noundef %7, double noundef %8, double noundef %9)
  %11 = fcmp une double %10, 0.000000e+00
  br i1 %11, label %12, label %13

12:                                               ; preds = %0
  call void @abort() #3
  unreachable

13:                                               ; preds = %0
  %14 = load double, ptr %2, align 8
  %15 = fcmp une double %14, 1.000000e+00
  br i1 %15, label %25, label %16

16:                                               ; preds = %13
  %17 = load double, ptr %3, align 8
  %18 = fcmp une double %17, 0.000000e+00
  br i1 %18, label %25, label %19

19:                                               ; preds = %16
  %20 = load double, ptr %4, align 8
  %21 = fcmp une double %20, 1.000000e+01
  br i1 %21, label %25, label %22

22:                                               ; preds = %19
  %23 = load double, ptr %5, align 8
  %24 = fcmp une double %23, 0.000000e+00
  br i1 %24, label %25, label %26

25:                                               ; preds = %22, %19, %16, %13
  call void @abort() #3
  unreachable

26:                                               ; preds = %22
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
