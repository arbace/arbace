; ModuleID = '20071202-1.c'
source_filename = "20071202-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.S = type { i32, i32, [6 x i32], %struct.T }
%struct.T = type { i32, [8 x i32] }

@constinit = private constant [6 x i32] zeroinitializer, align 4
@__const.main.s = private unnamed_addr constant %struct.S { i32 6, i32 12, [6 x i32] [i32 1, i32 2, i32 3, i32 4, i32 5, i32 6], %struct.T { i32 7, [8 x i32] [i32 8, i32 9, i32 10, i32 11, i32 12, i32 13, i32 14, i32 15] } }, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.S, align 4
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 0
  %6 = load ptr, ptr %2, align 8
  %7 = getelementptr inbounds nuw %struct.S, ptr %6, i32 0, i32 1
  %8 = load i32, ptr %7, align 4
  store i32 %8, ptr %5, align 4
  %9 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 1
  %10 = load ptr, ptr %2, align 8
  %11 = getelementptr inbounds nuw %struct.S, ptr %10, i32 0, i32 0
  %12 = load i32, ptr %11, align 4
  store i32 %12, ptr %9, align 4
  %13 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 2
  call void @llvm.memset.p0.i64(ptr align 4 %13, i8 0, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %13, ptr align 4 @constinit, i64 24, i1 false)
  %14 = getelementptr inbounds nuw %struct.S, ptr %3, i32 0, i32 3
  %15 = load ptr, ptr %2, align 8
  %16 = getelementptr inbounds nuw %struct.S, ptr %15, i32 0, i32 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %14, ptr align 4 %16, i64 36, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %4, ptr align 4 %3, i64 68, i1 false)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.S, align 4
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 4 %2, ptr align 4 @__const.main.s, i64 68, i1 false)
  call void @foo(ptr noundef %2)
  %3 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 0
  %4 = load i32, ptr %3, align 4
  %5 = icmp ne i32 %4, 12
  br i1 %5, label %40, label %6

6:                                                ; preds = %0
  %7 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 1
  %8 = load i32, ptr %7, align 4
  %9 = icmp ne i32 %8, 6
  br i1 %9, label %40, label %10

10:                                               ; preds = %6
  %11 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %12 = getelementptr inbounds [6 x i32], ptr %11, i64 0, i64 0
  %13 = load i32, ptr %12, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %40, label %15

15:                                               ; preds = %10
  %16 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %17 = getelementptr inbounds [6 x i32], ptr %16, i64 0, i64 1
  %18 = load i32, ptr %17, align 4
  %19 = icmp ne i32 %18, 0
  br i1 %19, label %40, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %22 = getelementptr inbounds [6 x i32], ptr %21, i64 0, i64 2
  %23 = load i32, ptr %22, align 4
  %24 = icmp ne i32 %23, 0
  br i1 %24, label %40, label %25

25:                                               ; preds = %20
  %26 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %27 = getelementptr inbounds [6 x i32], ptr %26, i64 0, i64 3
  %28 = load i32, ptr %27, align 4
  %29 = icmp ne i32 %28, 0
  br i1 %29, label %40, label %30

30:                                               ; preds = %25
  %31 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %32 = getelementptr inbounds [6 x i32], ptr %31, i64 0, i64 4
  %33 = load i32, ptr %32, align 4
  %34 = icmp ne i32 %33, 0
  br i1 %34, label %40, label %35

35:                                               ; preds = %30
  %36 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 2
  %37 = getelementptr inbounds [6 x i32], ptr %36, i64 0, i64 5
  %38 = load i32, ptr %37, align 4
  %39 = icmp ne i32 %38, 0
  br i1 %39, label %40, label %41

40:                                               ; preds = %35, %30, %25, %20, %15, %10, %6, %0
  call void @abort() #4
  unreachable

41:                                               ; preds = %35
  %42 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %43 = getelementptr inbounds nuw %struct.T, ptr %42, i32 0, i32 0
  %44 = load i32, ptr %43, align 4
  %45 = icmp ne i32 %44, 7
  br i1 %45, label %94, label %46

46:                                               ; preds = %41
  %47 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %48 = getelementptr inbounds nuw %struct.T, ptr %47, i32 0, i32 1
  %49 = getelementptr inbounds [8 x i32], ptr %48, i64 0, i64 0
  %50 = load i32, ptr %49, align 4
  %51 = icmp ne i32 %50, 8
  br i1 %51, label %94, label %52

52:                                               ; preds = %46
  %53 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %54 = getelementptr inbounds nuw %struct.T, ptr %53, i32 0, i32 1
  %55 = getelementptr inbounds [8 x i32], ptr %54, i64 0, i64 1
  %56 = load i32, ptr %55, align 4
  %57 = icmp ne i32 %56, 9
  br i1 %57, label %94, label %58

58:                                               ; preds = %52
  %59 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %60 = getelementptr inbounds nuw %struct.T, ptr %59, i32 0, i32 1
  %61 = getelementptr inbounds [8 x i32], ptr %60, i64 0, i64 2
  %62 = load i32, ptr %61, align 4
  %63 = icmp ne i32 %62, 10
  br i1 %63, label %94, label %64

64:                                               ; preds = %58
  %65 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %66 = getelementptr inbounds nuw %struct.T, ptr %65, i32 0, i32 1
  %67 = getelementptr inbounds [8 x i32], ptr %66, i64 0, i64 3
  %68 = load i32, ptr %67, align 4
  %69 = icmp ne i32 %68, 11
  br i1 %69, label %94, label %70

70:                                               ; preds = %64
  %71 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %72 = getelementptr inbounds nuw %struct.T, ptr %71, i32 0, i32 1
  %73 = getelementptr inbounds [8 x i32], ptr %72, i64 0, i64 4
  %74 = load i32, ptr %73, align 4
  %75 = icmp ne i32 %74, 12
  br i1 %75, label %94, label %76

76:                                               ; preds = %70
  %77 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %78 = getelementptr inbounds nuw %struct.T, ptr %77, i32 0, i32 1
  %79 = getelementptr inbounds [8 x i32], ptr %78, i64 0, i64 5
  %80 = load i32, ptr %79, align 4
  %81 = icmp ne i32 %80, 13
  br i1 %81, label %94, label %82

82:                                               ; preds = %76
  %83 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %84 = getelementptr inbounds nuw %struct.T, ptr %83, i32 0, i32 1
  %85 = getelementptr inbounds [8 x i32], ptr %84, i64 0, i64 6
  %86 = load i32, ptr %85, align 4
  %87 = icmp ne i32 %86, 14
  br i1 %87, label %94, label %88

88:                                               ; preds = %82
  %89 = getelementptr inbounds nuw %struct.S, ptr %2, i32 0, i32 3
  %90 = getelementptr inbounds nuw %struct.T, ptr %89, i32 0, i32 1
  %91 = getelementptr inbounds [8 x i32], ptr %90, i64 0, i64 7
  %92 = load i32, ptr %91, align 4
  %93 = icmp ne i32 %92, 15
  br i1 %93, label %94, label %95

94:                                               ; preds = %88, %82, %76, %70, %64, %58, %52, %46, %41
  call void @abort() #4
  unreachable

95:                                               ; preds = %88
  ret i32 0
}

; Function Attrs: noreturn nounwind
declare void @abort() #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
