; ModuleID = '20020402-2.c'
source_filename = "20020402-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.WorkEntrySType = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%struct.ShrPcPteSType = type { %struct.ShrPcStatsSType }
%struct.ShrPcStatsSType = type { i32, i32, %struct.ShrPcCommonStatSType, %union.ShrPcStatUnion }
%struct.ShrPcCommonStatSType = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64 }
%union.ShrPcStatUnion = type { %struct.ShrPcGemStatSType }
%struct.ShrPcGemStatSType = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, [40 x i64] }

@Local1 = dso_local global ptr null, align 8
@Local2 = dso_local global ptr null, align 8
@Local3 = dso_local global ptr null, align 8
@RDbf1 = dso_local global ptr null, align 8
@RDbf2 = dso_local global ptr null, align 8
@RDbf3 = dso_local global ptr null, align 8
@IntVc1 = dso_local global ptr null, align 8
@IntVc2 = dso_local global ptr null, align 8
@IntCode3 = dso_local global ptr null, align 8
@IntCode4 = dso_local global ptr null, align 8
@IntCode5 = dso_local global ptr null, align 8
@IntCode6 = dso_local global ptr null, align 8
@Lom1 = dso_local global ptr null, align 8
@Lom2 = dso_local global ptr null, align 8
@Lom3 = dso_local global ptr null, align 8
@Lom4 = dso_local global ptr null, align 8
@Lom5 = dso_local global ptr null, align 8
@Lom6 = dso_local global ptr null, align 8
@Lom7 = dso_local global ptr null, align 8
@Lom8 = dso_local global ptr null, align 8
@Lom9 = dso_local global ptr null, align 8
@Lom10 = dso_local global ptr null, align 8
@RDbf11 = dso_local global ptr null, align 8
@RDbf12 = dso_local global ptr null, align 8
@Workspace = dso_local global %struct.WorkEntrySType zeroinitializer, align 8
@MyPte = dso_local global %struct.ShrPcPteSType zeroinitializer, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @InitCache(i32 noundef %0) #0 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  %3 = load i32, ptr %2, align 4
  %4 = sext i32 %3 to i64
  call void @initPte(ptr noundef null, i64 noundef %4)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @initPte(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  store ptr @MyPte, ptr %5, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds nuw %struct.ShrPcPteSType, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %4, align 8
  call void @setStatPointers(ptr noundef %7, i64 noundef %8)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  call void @InitCache(i32 noundef 5)
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @setStatPointers(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %6 = load i64, ptr %4, align 8
  %7 = trunc i64 %6 to i32
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %8, i32 0, i32 1
  store i32 %7, ptr %9, align 4
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %10, i32 0, i32 2
  %12 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %11, i32 0, i32 0
  store i64 0, ptr %12, align 8
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %13, i32 0, i32 2
  %15 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %14, i32 0, i32 1
  store i64 5, ptr %15, align 8
  %16 = load ptr, ptr %3, align 8
  %17 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %16, i32 0, i32 2
  %18 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %17, i32 0, i32 2
  store ptr %18, ptr @Local1, align 8
  %19 = load ptr, ptr %3, align 8
  %20 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %19, i32 0, i32 2
  %21 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %20, i32 0, i32 3
  store ptr %21, ptr @Local2, align 8
  %22 = load ptr, ptr %3, align 8
  %23 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %22, i32 0, i32 2
  %24 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %23, i32 0, i32 4
  store ptr %24, ptr @Local3, align 8
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %25, i32 0, i32 2
  %27 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %26, i32 0, i32 5
  store ptr %27, ptr @RDbf1, align 8
  %28 = load ptr, ptr %3, align 8
  %29 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %28, i32 0, i32 2
  %30 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %29, i32 0, i32 6
  store ptr %30, ptr @RDbf2, align 8
  %31 = load ptr, ptr %3, align 8
  %32 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %31, i32 0, i32 2
  %33 = getelementptr inbounds nuw %struct.ShrPcCommonStatSType, ptr %32, i32 0, i32 7
  store ptr %33, ptr @RDbf3, align 8
  %34 = load ptr, ptr @RDbf3, align 8
  store i64 1, ptr %34, align 8
  %35 = load ptr, ptr %3, align 8
  %36 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %35, i32 0, i32 3
  %37 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %36, i32 0, i32 12
  store ptr %37, ptr @IntVc1, align 8
  %38 = load ptr, ptr %3, align 8
  %39 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %38, i32 0, i32 3
  %40 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %39, i32 0, i32 13
  store ptr %40, ptr @IntVc2, align 8
  %41 = load ptr, ptr %3, align 8
  %42 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %41, i32 0, i32 3
  %43 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %42, i32 0, i32 14
  store ptr %43, ptr @IntCode3, align 8
  %44 = load ptr, ptr %3, align 8
  %45 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %44, i32 0, i32 3
  %46 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %45, i32 0, i32 15
  store ptr %46, ptr @IntCode4, align 8
  %47 = load ptr, ptr %3, align 8
  %48 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %47, i32 0, i32 3
  %49 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %48, i32 0, i32 16
  store ptr %49, ptr @IntCode5, align 8
  %50 = load ptr, ptr %3, align 8
  %51 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %50, i32 0, i32 3
  %52 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %51, i32 0, i32 17
  store ptr %52, ptr @IntCode6, align 8
  store ptr @Workspace, ptr %5, align 8
  %53 = load ptr, ptr %3, align 8
  %54 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %53, i32 0, i32 3
  %55 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %54, i32 0, i32 18
  %56 = load ptr, ptr %5, align 8
  %57 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %56, i32 0, i32 0
  store ptr %55, ptr %57, align 8
  %58 = load ptr, ptr %3, align 8
  %59 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %58, i32 0, i32 3
  %60 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %59, i32 0, i32 19
  %61 = load ptr, ptr %5, align 8
  %62 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %61, i32 0, i32 1
  store ptr %60, ptr %62, align 8
  %63 = load ptr, ptr %3, align 8
  %64 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %63, i32 0, i32 3
  %65 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %64, i32 0, i32 20
  %66 = load ptr, ptr %5, align 8
  %67 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %66, i32 0, i32 2
  store ptr %65, ptr %67, align 8
  %68 = load ptr, ptr %3, align 8
  %69 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %68, i32 0, i32 3
  %70 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %69, i32 0, i32 21
  %71 = load ptr, ptr %5, align 8
  %72 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %71, i32 0, i32 3
  store ptr %70, ptr %72, align 8
  %73 = load ptr, ptr %3, align 8
  %74 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %73, i32 0, i32 3
  %75 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %74, i32 0, i32 22
  %76 = load ptr, ptr %5, align 8
  %77 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %76, i32 0, i32 4
  store ptr %75, ptr %77, align 8
  %78 = load ptr, ptr %3, align 8
  %79 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %78, i32 0, i32 3
  %80 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %79, i32 0, i32 23
  %81 = load ptr, ptr %5, align 8
  %82 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %81, i32 0, i32 5
  store ptr %80, ptr %82, align 8
  %83 = load ptr, ptr %3, align 8
  %84 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %83, i32 0, i32 3
  %85 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %84, i32 0, i32 24
  %86 = load ptr, ptr %5, align 8
  %87 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %86, i32 0, i32 6
  store ptr %85, ptr %87, align 8
  %88 = load ptr, ptr %3, align 8
  %89 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %88, i32 0, i32 3
  %90 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %89, i32 0, i32 25
  %91 = load ptr, ptr %5, align 8
  %92 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %91, i32 0, i32 7
  store ptr %90, ptr %92, align 8
  %93 = load ptr, ptr %3, align 8
  %94 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %93, i32 0, i32 3
  %95 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %94, i32 0, i32 26
  %96 = load ptr, ptr %5, align 8
  %97 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %96, i32 0, i32 8
  store ptr %95, ptr %97, align 8
  %98 = load ptr, ptr %3, align 8
  %99 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %98, i32 0, i32 3
  %100 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %99, i32 0, i32 27
  %101 = load ptr, ptr %5, align 8
  %102 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %101, i32 0, i32 9
  store ptr %100, ptr %102, align 8
  %103 = load ptr, ptr %3, align 8
  %104 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %103, i32 0, i32 3
  %105 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %104, i32 0, i32 28
  %106 = load ptr, ptr %5, align 8
  %107 = getelementptr inbounds nuw %struct.WorkEntrySType, ptr %106, i32 0, i32 10
  store ptr %105, ptr %107, align 8
  %108 = load ptr, ptr %3, align 8
  %109 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %108, i32 0, i32 3
  %110 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %109, i32 0, i32 0
  store ptr %110, ptr @Lom1, align 8
  %111 = load ptr, ptr %3, align 8
  %112 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %111, i32 0, i32 3
  %113 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %112, i32 0, i32 1
  store ptr %113, ptr @Lom2, align 8
  %114 = load ptr, ptr %3, align 8
  %115 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %114, i32 0, i32 3
  %116 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %115, i32 0, i32 2
  store ptr %116, ptr @Lom3, align 8
  %117 = load ptr, ptr %3, align 8
  %118 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %117, i32 0, i32 3
  %119 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %118, i32 0, i32 3
  store ptr %119, ptr @Lom4, align 8
  %120 = load ptr, ptr %3, align 8
  %121 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %120, i32 0, i32 3
  %122 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %121, i32 0, i32 4
  store ptr %122, ptr @Lom5, align 8
  %123 = load ptr, ptr %3, align 8
  %124 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %123, i32 0, i32 3
  %125 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %124, i32 0, i32 5
  store ptr %125, ptr @Lom6, align 8
  %126 = load ptr, ptr %3, align 8
  %127 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %126, i32 0, i32 3
  %128 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %127, i32 0, i32 6
  store ptr %128, ptr @Lom7, align 8
  %129 = load ptr, ptr %3, align 8
  %130 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %129, i32 0, i32 3
  %131 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %130, i32 0, i32 7
  store ptr %131, ptr @Lom8, align 8
  %132 = load ptr, ptr %3, align 8
  %133 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %132, i32 0, i32 3
  %134 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %133, i32 0, i32 8
  store ptr %134, ptr @Lom9, align 8
  %135 = load ptr, ptr %3, align 8
  %136 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %135, i32 0, i32 3
  %137 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %136, i32 0, i32 9
  store ptr %137, ptr @Lom10, align 8
  %138 = load ptr, ptr %3, align 8
  %139 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %138, i32 0, i32 3
  %140 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %139, i32 0, i32 10
  store ptr %140, ptr @RDbf11, align 8
  %141 = load ptr, ptr %3, align 8
  %142 = getelementptr inbounds nuw %struct.ShrPcStatsSType, ptr %141, i32 0, i32 3
  %143 = getelementptr inbounds nuw %struct.ShrPcGemStatSType, ptr %142, i32 0, i32 11
  store ptr %143, ptr @RDbf12, align 8
  ret void
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
