; ModuleID = '20000731-1.c'
source_filename = "20000731-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local double @foo() #0 {
  ret double 0.000000e+00
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @do_sibcall() #0 {
  %1 = call double @foo()
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca double, align 8
  store i32 0, ptr %1, align 4
  store double 0.000000e+00, ptr %2, align 8
  br label %3

3:                                                ; preds = %7, %0
  %4 = load double, ptr %2, align 8
  %5 = fcmp olt double %4, 2.000000e+01
  br i1 %5, label %6, label %10

6:                                                ; preds = %3
  call void @do_sibcall()
  br label %7

7:                                                ; preds = %6
  %8 = load double, ptr %2, align 8
  %9 = fadd double %8, 1.000000e+00
  store double %9, ptr %2, align 8
  br label %3, !llvm.loop !6

10:                                               ; preds = %3
  %11 = load double, ptr %2, align 8
  %12 = fcmp oge double %11, 1.000000e+01
  br i1 %12, label %14, label %13

13:                                               ; preds = %10
  call void @abort() #3
  unreachable

14:                                               ; preds = %10
  call void @exit(i32 noundef 0) #4
  unreachable
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noreturn
declare void @exit(i32 noundef) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }
attributes #4 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
