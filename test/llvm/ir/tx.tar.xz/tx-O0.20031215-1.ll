; ModuleID = '20031215-1.c'
source_filename = "20031215-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@ao = dso_local constant { i32, i32, [3 x i8], i8 } { i32 2, i32 2, [3 x i8] c"OK\00", i8 0 }, align 4
@a = dso_local constant ptr @ao, align 8

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test1() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test2() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @test3() #0 {
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  call void @test1()
  call void @test2()
  call void @test3()
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
