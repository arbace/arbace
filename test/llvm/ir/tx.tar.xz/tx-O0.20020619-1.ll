; ModuleID = '20020619-1.c'
source_filename = "20020619-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%union.anon = type { i32, [4 x i8] }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  store i32 0, ptr %1, align 4
  %3 = call i32 @ref()
  store i32 %3, ptr %2, align 4
  %4 = load i32, ptr %2, align 4
  %5 = icmp ne i32 %4, 16909060
  br i1 %5, label %6, label %10

6:                                                ; preds = %0
  %7 = load i32, ptr %2, align 4
  %8 = icmp ne i32 %7, 67305985
  br i1 %8, label %9, label %10

9:                                                ; preds = %6
  call void @abort() #3
  unreachable

10:                                               ; preds = %6, %0
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @ref() #0 {
  %1 = alloca %union.anon, align 4
  call void @llvm.memset.p0.i64(ptr align 4 %1, i8 0, i64 8, i1 false)
  %2 = getelementptr inbounds [5 x i8], ptr %1, i64 0, i64 0
  store i8 1, ptr %2, align 4
  %3 = getelementptr inbounds [5 x i8], ptr %1, i64 0, i64 1
  store i8 2, ptr %3, align 1
  %4 = getelementptr inbounds [5 x i8], ptr %1, i64 0, i64 2
  store i8 3, ptr %4, align 2
  %5 = getelementptr inbounds [5 x i8], ptr %1, i64 0, i64 3
  store i8 4, ptr %5, align 1
  %6 = load i32, ptr %1, align 4
  ret i32 %6
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
