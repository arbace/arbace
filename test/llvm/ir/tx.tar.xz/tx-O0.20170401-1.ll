; ModuleID = '20170401-1.c'
source_filename = "20170401-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.source = type { i32, i32 }
%struct.packed_ushort = type { i16 }

@flag = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.source, align 4
  %3 = alloca i32, align 4
  %4 = alloca %struct.packed_ushort, align 1
  store i32 0, ptr %1, align 4
  %5 = getelementptr inbounds nuw %struct.source, ptr %2, i32 0, i32 0
  store i32 0, ptr %5, align 4
  %6 = getelementptr inbounds nuw %struct.source, ptr %2, i32 0, i32 1
  store i32 0, ptr %6, align 4
  store i32 0, ptr @flag, align 4
  store i32 0, ptr %3, align 4
  br label %7

7:                                                ; preds = %30, %0
  %8 = load i32, ptr %3, align 4
  %9 = icmp slt i32 %8, 16
  br i1 %9, label %10, label %33

10:                                               ; preds = %7
  %11 = call i16 @next(ptr noundef %2)
  %12 = getelementptr inbounds nuw %struct.packed_ushort, ptr %4, i32 0, i32 0
  store i16 %11, ptr %12, align 1
  %13 = load i32, ptr %3, align 4
  %14 = icmp eq i32 %13, 0
  br i1 %14, label %15, label %20

15:                                               ; preds = %10
  %16 = getelementptr inbounds nuw %struct.packed_ushort, ptr %4, i32 0, i32 0
  %17 = load i16, ptr %16, align 1
  %18 = zext i16 %17 to i32
  %19 = icmp ne i32 %18, 65535
  br i1 %19, label %28, label %20

20:                                               ; preds = %15, %10
  %21 = load i32, ptr %3, align 4
  %22 = icmp sgt i32 %21, 0
  br i1 %22, label %23, label %29

23:                                               ; preds = %20
  %24 = getelementptr inbounds nuw %struct.packed_ushort, ptr %4, i32 0, i32 0
  %25 = load i16, ptr %24, align 1
  %26 = zext i16 %25 to i32
  %27 = icmp ne i32 %26, 0
  br i1 %27, label %28, label %29

28:                                               ; preds = %23, %15
  call void @abort() #3
  unreachable

29:                                               ; preds = %23, %20
  br label %30

30:                                               ; preds = %29
  %31 = load i32, ptr %3, align 4
  %32 = add nsw i32 %31, 1
  store i32 %32, ptr %3, align 4
  br label %7, !llvm.loop !6

33:                                               ; preds = %7
  ret i32 0
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i16 @next(ptr noundef %0) #0 {
  %2 = alloca %struct.packed_ushort, align 1
  %3 = alloca ptr, align 8
  %4 = alloca %struct.packed_ushort, align 1
  store ptr %0, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.source, ptr %5, i32 0, i32 0
  %7 = load i32, ptr %6, align 4
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.source, ptr %8, i32 0, i32 1
  %10 = load i32, ptr %9, align 4
  %11 = icmp sge i32 %7, %10
  br i1 %11, label %12, label %22

12:                                               ; preds = %1
  %13 = load i32, ptr @flag, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %20

15:                                               ; preds = %12
  store i32 0, ptr @flag, align 4
  %16 = load ptr, ptr %3, align 8
  call void @fetch(ptr noundef %16)
  %17 = load ptr, ptr %3, align 8
  %18 = call i16 @next(ptr noundef %17)
  %19 = getelementptr inbounds nuw %struct.packed_ushort, ptr %2, i32 0, i32 0
  store i16 %18, ptr %19, align 1
  br label %24

20:                                               ; preds = %12
  store i32 1, ptr @flag, align 4
  %21 = getelementptr inbounds nuw %struct.packed_ushort, ptr %4, i32 0, i32 0
  store i16 -1, ptr %21, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %4, i64 2, i1 false)
  br label %24

22:                                               ; preds = %1
  %23 = getelementptr inbounds nuw %struct.packed_ushort, ptr %4, i32 0, i32 0
  store i16 0, ptr %23, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %2, ptr align 1 %4, i64 2, i1 false)
  br label %24

24:                                               ; preds = %22, %20, %15
  %25 = getelementptr inbounds nuw %struct.packed_ushort, ptr %2, i32 0, i32 0
  %26 = load i16, ptr %25, align 1
  ret i16 %26
}

; Function Attrs: noreturn nounwind
declare void @abort() #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @fetch(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.source, ptr %3, i32 0, i32 1
  store i32 128, ptr %4, align 4
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
