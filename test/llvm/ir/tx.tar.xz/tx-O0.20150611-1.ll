; ModuleID = '20150611-1.c'
source_filename = "20150611-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@b = dso_local global i16 0, align 2
@a = dso_local global i32 0, align 4
@d = dso_local global i32 0, align 4
@c = dso_local global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [1 x i32], align 4
  store i32 0, ptr %1, align 4
  br label %3

3:                                                ; preds = %30, %0
  %4 = load i16, ptr @b, align 2
  %5 = sext i16 %4 to i32
  %6 = icmp slt i32 %5, 2
  br i1 %6, label %7, label %33

7:                                                ; preds = %3
  store i32 0, ptr @a, align 4
  %8 = load i16, ptr @b, align 2
  %9 = sext i16 %8 to i32
  %10 = icmp eq i32 %9, 28378
  br i1 %10, label %11, label %16

11:                                               ; preds = %7
  %12 = load i16, ptr @b, align 2
  %13 = sext i16 %12 to i64
  %14 = getelementptr inbounds [1 x i32], ptr %2, i64 0, i64 %13
  %15 = load i32, ptr %14, align 4
  store i32 %15, ptr @a, align 4
  br label %16

16:                                               ; preds = %11, %7
  %17 = load i32, ptr @d, align 4
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %29, label %19

19:                                               ; preds = %16
  %20 = load i16, ptr @b, align 2
  %21 = sext i16 %20 to i32
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %29, label %23

23:                                               ; preds = %19
  br label %24

24:                                               ; preds = %27, %23
  %25 = load i32, ptr @c, align 4
  %26 = icmp ne i32 %25, 0
  br i1 %26, label %27, label %28

27:                                               ; preds = %24
  br label %24, !llvm.loop !6

28:                                               ; preds = %24
  br label %29

29:                                               ; preds = %28, %19, %16
  br label %30

30:                                               ; preds = %29
  %31 = load i16, ptr @b, align 2
  %32 = add i16 %31, 1
  store i16 %32, ptr @b, align 2
  br label %3, !llvm.loop !8

33:                                               ; preds = %3
  ret i32 0
}

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
