; ModuleID = '20021010-2.c'
source_filename = "20021010-2.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.IOGBounds = type { i16, i16, i16, i16 }

@expectedwidth = dso_local global i32 50, align 4
@global_vramPtr = dso_local global ptr inttoptr (i64 40960 to ptr), align 8
@global_bounds = dso_local global %struct.IOGBounds { i16 100, i16 150, i16 100, i16 150 }, align 2
@global_saveRect = dso_local global %struct.IOGBounds { i16 75, i16 175, i16 75, i16 175 }, align 2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca ptr, align 8
  %3 = alloca i32, align 4
  %4 = alloca %struct.IOGBounds, align 2
  %5 = alloca %struct.IOGBounds, align 2
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %4, ptr align 2 @global_saveRect, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %5, ptr align 2 @global_bounds, i64 8, i1 false)
  %6 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 0
  %7 = load i16, ptr %6, align 2
  %8 = sext i16 %7 to i32
  %9 = getelementptr inbounds nuw %struct.IOGBounds, ptr %5, i32 0, i32 0
  %10 = load i16, ptr %9, align 2
  %11 = sext i16 %10 to i32
  %12 = icmp slt i32 %8, %11
  br i1 %12, label %13, label %17

13:                                               ; preds = %0
  %14 = getelementptr inbounds nuw %struct.IOGBounds, ptr %5, i32 0, i32 0
  %15 = load i16, ptr %14, align 2
  %16 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 0
  store i16 %15, ptr %16, align 2
  br label %17

17:                                               ; preds = %13, %0
  %18 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 1
  %19 = load i16, ptr %18, align 2
  %20 = sext i16 %19 to i32
  %21 = getelementptr inbounds nuw %struct.IOGBounds, ptr %5, i32 0, i32 1
  %22 = load i16, ptr %21, align 2
  %23 = sext i16 %22 to i32
  %24 = icmp sgt i32 %20, %23
  br i1 %24, label %25, label %29

25:                                               ; preds = %17
  %26 = getelementptr inbounds nuw %struct.IOGBounds, ptr %5, i32 0, i32 1
  %27 = load i16, ptr %26, align 2
  %28 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 1
  store i16 %27, ptr %28, align 2
  br label %29

29:                                               ; preds = %25, %17
  %30 = load ptr, ptr @global_vramPtr, align 8
  %31 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 2
  %32 = load i16, ptr %31, align 2
  %33 = sext i16 %32 to i32
  %34 = getelementptr inbounds nuw %struct.IOGBounds, ptr %5, i32 0, i32 2
  %35 = load i16, ptr %34, align 2
  %36 = sext i16 %35 to i32
  %37 = sub nsw i32 %33, %36
  %38 = sext i32 %37 to i64
  %39 = getelementptr inbounds i32, ptr %30, i64 %38
  store ptr %39, ptr %2, align 8
  %40 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 1
  %41 = load i16, ptr %40, align 2
  %42 = sext i16 %41 to i32
  %43 = getelementptr inbounds nuw %struct.IOGBounds, ptr %4, i32 0, i32 0
  %44 = load i16, ptr %43, align 2
  %45 = sext i16 %44 to i32
  %46 = sub nsw i32 %42, %45
  store i32 %46, ptr %3, align 4
  %47 = load i32, ptr %3, align 4
  %48 = load i32, ptr @expectedwidth, align 4
  %49 = icmp ne i32 %47, %48
  br i1 %49, label %50, label %51

50:                                               ; preds = %29
  call void @abort() #4
  unreachable

51:                                               ; preds = %29
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
