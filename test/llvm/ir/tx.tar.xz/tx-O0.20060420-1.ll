; ModuleID = '20060420-1.c'
source_filename = "20060420-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@buffer = dso_local global [64 x float] zeroinitializer, align 16

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @foo(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca float, align 4
  %14 = alloca <4 x float>, align 16
  %15 = alloca <4 x float>, align 16
  %16 = alloca <4 x float>, align 16
  %17 = alloca <4 x float>, align 16
  %18 = alloca float, align 4
  store ptr %0, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store i32 %2, ptr %7, align 4
  store i32 %3, ptr %8, align 4
  store i32 4, ptr %11, align 4
  store i32 15, ptr %12, align 4
  store i32 0, ptr %10, align 4
  br label %19

19:                                               ; preds = %68, %4
  %20 = load i32, ptr %10, align 4
  %21 = load i32, ptr %8, align 4
  %22 = icmp slt i32 %20, %21
  br i1 %22, label %23, label %33

23:                                               ; preds = %19
  %24 = load ptr, ptr %5, align 8
  %25 = ptrtoint ptr %24 to i64
  %26 = load i32, ptr %10, align 4
  %27 = sext i32 %26 to i64
  %28 = add i64 %25, %27
  %29 = load i32, ptr %12, align 4
  %30 = zext i32 %29 to i64
  %31 = and i64 %28, %30
  %32 = icmp ne i64 %31, 0
  br label %33

33:                                               ; preds = %23, %19
  %34 = phi i1 [ false, %19 ], [ %32, %23 ]
  br i1 %34, label %35, label %71

35:                                               ; preds = %33
  %36 = load ptr, ptr %6, align 8
  %37 = getelementptr inbounds ptr, ptr %36, i64 0
  %38 = load ptr, ptr %37, align 8
  %39 = load i32, ptr %10, align 4
  %40 = sext i32 %39 to i64
  %41 = getelementptr inbounds float, ptr %38, i64 %40
  %42 = load float, ptr %41, align 4
  store float %42, ptr %13, align 4
  store i32 1, ptr %9, align 4
  br label %43

43:                                               ; preds = %59, %35
  %44 = load i32, ptr %9, align 4
  %45 = load i32, ptr %7, align 4
  %46 = icmp slt i32 %44, %45
  br i1 %46, label %47, label %62

47:                                               ; preds = %43
  %48 = load ptr, ptr %6, align 8
  %49 = load i32, ptr %9, align 4
  %50 = sext i32 %49 to i64
  %51 = getelementptr inbounds ptr, ptr %48, i64 %50
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %10, align 4
  %54 = sext i32 %53 to i64
  %55 = getelementptr inbounds float, ptr %52, i64 %54
  %56 = load float, ptr %55, align 4
  %57 = load float, ptr %13, align 4
  %58 = fadd float %57, %56
  store float %58, ptr %13, align 4
  br label %59

59:                                               ; preds = %47
  %60 = load i32, ptr %9, align 4
  %61 = add nsw i32 %60, 1
  store i32 %61, ptr %9, align 4
  br label %43, !llvm.loop !6

62:                                               ; preds = %43
  %63 = load float, ptr %13, align 4
  %64 = load ptr, ptr %5, align 8
  %65 = load i32, ptr %10, align 4
  %66 = sext i32 %65 to i64
  %67 = getelementptr inbounds float, ptr %64, i64 %66
  store float %63, ptr %67, align 4
  br label %68

68:                                               ; preds = %62
  %69 = load i32, ptr %10, align 4
  %70 = add nsw i32 %69, 1
  store i32 %70, ptr %10, align 4
  br label %19, !llvm.loop !8

71:                                               ; preds = %33
  br label %72

72:                                               ; preds = %230, %71
  %73 = load i32, ptr %10, align 4
  %74 = load i32, ptr %8, align 4
  %75 = load i32, ptr %11, align 4
  %76 = mul nsw i32 4, %75
  %77 = sub nsw i32 %76, 1
  %78 = sub nsw i32 %74, %77
  %79 = icmp slt i32 %73, %78
  br i1 %79, label %80, label %235

80:                                               ; preds = %72
  %81 = load ptr, ptr %6, align 8
  %82 = getelementptr inbounds ptr, ptr %81, i64 0
  %83 = load ptr, ptr %82, align 8
  %84 = load i32, ptr %10, align 4
  %85 = sext i32 %84 to i64
  %86 = getelementptr inbounds float, ptr %83, i64 %85
  %87 = load i32, ptr %11, align 4
  %88 = mul nsw i32 0, %87
  %89 = sext i32 %88 to i64
  %90 = getelementptr inbounds float, ptr %86, i64 %89
  %91 = load <4 x float>, ptr %90, align 16
  store <4 x float> %91, ptr %14, align 16
  %92 = load ptr, ptr %6, align 8
  %93 = getelementptr inbounds ptr, ptr %92, i64 0
  %94 = load ptr, ptr %93, align 8
  %95 = load i32, ptr %10, align 4
  %96 = sext i32 %95 to i64
  %97 = getelementptr inbounds float, ptr %94, i64 %96
  %98 = load i32, ptr %11, align 4
  %99 = mul nsw i32 1, %98
  %100 = sext i32 %99 to i64
  %101 = getelementptr inbounds float, ptr %97, i64 %100
  %102 = load <4 x float>, ptr %101, align 16
  store <4 x float> %102, ptr %15, align 16
  %103 = load ptr, ptr %6, align 8
  %104 = getelementptr inbounds ptr, ptr %103, i64 0
  %105 = load ptr, ptr %104, align 8
  %106 = load i32, ptr %10, align 4
  %107 = sext i32 %106 to i64
  %108 = getelementptr inbounds float, ptr %105, i64 %107
  %109 = load i32, ptr %11, align 4
  %110 = mul nsw i32 2, %109
  %111 = sext i32 %110 to i64
  %112 = getelementptr inbounds float, ptr %108, i64 %111
  %113 = load <4 x float>, ptr %112, align 16
  store <4 x float> %113, ptr %16, align 16
  %114 = load ptr, ptr %6, align 8
  %115 = getelementptr inbounds ptr, ptr %114, i64 0
  %116 = load ptr, ptr %115, align 8
  %117 = load i32, ptr %10, align 4
  %118 = sext i32 %117 to i64
  %119 = getelementptr inbounds float, ptr %116, i64 %118
  %120 = load i32, ptr %11, align 4
  %121 = mul nsw i32 3, %120
  %122 = sext i32 %121 to i64
  %123 = getelementptr inbounds float, ptr %119, i64 %122
  %124 = load <4 x float>, ptr %123, align 16
  store <4 x float> %124, ptr %17, align 16
  store i32 1, ptr %9, align 4
  br label %125

125:                                              ; preds = %190, %80
  %126 = load i32, ptr %9, align 4
  %127 = load i32, ptr %7, align 4
  %128 = icmp slt i32 %126, %127
  br i1 %128, label %129, label %193

129:                                              ; preds = %125
  %130 = load ptr, ptr %6, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = getelementptr inbounds ptr, ptr %130, i64 %132
  %134 = load ptr, ptr %133, align 8
  %135 = load i32, ptr %10, align 4
  %136 = sext i32 %135 to i64
  %137 = getelementptr inbounds float, ptr %134, i64 %136
  %138 = load i32, ptr %11, align 4
  %139 = mul nsw i32 0, %138
  %140 = sext i32 %139 to i64
  %141 = getelementptr inbounds float, ptr %137, i64 %140
  %142 = load <4 x float>, ptr %141, align 16
  %143 = load <4 x float>, ptr %14, align 16
  %144 = fadd <4 x float> %143, %142
  store <4 x float> %144, ptr %14, align 16
  %145 = load ptr, ptr %6, align 8
  %146 = load i32, ptr %9, align 4
  %147 = sext i32 %146 to i64
  %148 = getelementptr inbounds ptr, ptr %145, i64 %147
  %149 = load ptr, ptr %148, align 8
  %150 = load i32, ptr %10, align 4
  %151 = sext i32 %150 to i64
  %152 = getelementptr inbounds float, ptr %149, i64 %151
  %153 = load i32, ptr %11, align 4
  %154 = mul nsw i32 1, %153
  %155 = sext i32 %154 to i64
  %156 = getelementptr inbounds float, ptr %152, i64 %155
  %157 = load <4 x float>, ptr %156, align 16
  %158 = load <4 x float>, ptr %15, align 16
  %159 = fadd <4 x float> %158, %157
  store <4 x float> %159, ptr %15, align 16
  %160 = load ptr, ptr %6, align 8
  %161 = load i32, ptr %9, align 4
  %162 = sext i32 %161 to i64
  %163 = getelementptr inbounds ptr, ptr %160, i64 %162
  %164 = load ptr, ptr %163, align 8
  %165 = load i32, ptr %10, align 4
  %166 = sext i32 %165 to i64
  %167 = getelementptr inbounds float, ptr %164, i64 %166
  %168 = load i32, ptr %11, align 4
  %169 = mul nsw i32 2, %168
  %170 = sext i32 %169 to i64
  %171 = getelementptr inbounds float, ptr %167, i64 %170
  %172 = load <4 x float>, ptr %171, align 16
  %173 = load <4 x float>, ptr %16, align 16
  %174 = fadd <4 x float> %173, %172
  store <4 x float> %174, ptr %16, align 16
  %175 = load ptr, ptr %6, align 8
  %176 = load i32, ptr %9, align 4
  %177 = sext i32 %176 to i64
  %178 = getelementptr inbounds ptr, ptr %175, i64 %177
  %179 = load ptr, ptr %178, align 8
  %180 = load i32, ptr %10, align 4
  %181 = sext i32 %180 to i64
  %182 = getelementptr inbounds float, ptr %179, i64 %181
  %183 = load i32, ptr %11, align 4
  %184 = mul nsw i32 3, %183
  %185 = sext i32 %184 to i64
  %186 = getelementptr inbounds float, ptr %182, i64 %185
  %187 = load <4 x float>, ptr %186, align 16
  %188 = load <4 x float>, ptr %17, align 16
  %189 = fadd <4 x float> %188, %187
  store <4 x float> %189, ptr %17, align 16
  br label %190

190:                                              ; preds = %129
  %191 = load i32, ptr %9, align 4
  %192 = add nsw i32 %191, 1
  store i32 %192, ptr %9, align 4
  br label %125, !llvm.loop !9

193:                                              ; preds = %125
  %194 = load <4 x float>, ptr %14, align 16
  %195 = load ptr, ptr %5, align 8
  %196 = load i32, ptr %10, align 4
  %197 = sext i32 %196 to i64
  %198 = getelementptr inbounds float, ptr %195, i64 %197
  %199 = load i32, ptr %11, align 4
  %200 = mul nsw i32 0, %199
  %201 = sext i32 %200 to i64
  %202 = getelementptr inbounds float, ptr %198, i64 %201
  store <4 x float> %194, ptr %202, align 16
  %203 = load <4 x float>, ptr %15, align 16
  %204 = load ptr, ptr %5, align 8
  %205 = load i32, ptr %10, align 4
  %206 = sext i32 %205 to i64
  %207 = getelementptr inbounds float, ptr %204, i64 %206
  %208 = load i32, ptr %11, align 4
  %209 = mul nsw i32 1, %208
  %210 = sext i32 %209 to i64
  %211 = getelementptr inbounds float, ptr %207, i64 %210
  store <4 x float> %203, ptr %211, align 16
  %212 = load <4 x float>, ptr %16, align 16
  %213 = load ptr, ptr %5, align 8
  %214 = load i32, ptr %10, align 4
  %215 = sext i32 %214 to i64
  %216 = getelementptr inbounds float, ptr %213, i64 %215
  %217 = load i32, ptr %11, align 4
  %218 = mul nsw i32 2, %217
  %219 = sext i32 %218 to i64
  %220 = getelementptr inbounds float, ptr %216, i64 %219
  store <4 x float> %212, ptr %220, align 16
  %221 = load <4 x float>, ptr %17, align 16
  %222 = load ptr, ptr %5, align 8
  %223 = load i32, ptr %10, align 4
  %224 = sext i32 %223 to i64
  %225 = getelementptr inbounds float, ptr %222, i64 %224
  %226 = load i32, ptr %11, align 4
  %227 = mul nsw i32 3, %226
  %228 = sext i32 %227 to i64
  %229 = getelementptr inbounds float, ptr %225, i64 %228
  store <4 x float> %221, ptr %229, align 16
  br label %230

230:                                              ; preds = %193
  %231 = load i32, ptr %11, align 4
  %232 = mul nsw i32 4, %231
  %233 = load i32, ptr %10, align 4
  %234 = add nsw i32 %233, %232
  store i32 %234, ptr %10, align 4
  br label %72, !llvm.loop !10

235:                                              ; preds = %72
  br label %236

236:                                              ; preds = %273, %235
  %237 = load i32, ptr %10, align 4
  %238 = load i32, ptr %8, align 4
  %239 = icmp slt i32 %237, %238
  br i1 %239, label %240, label %276

240:                                              ; preds = %236
  %241 = load ptr, ptr %6, align 8
  %242 = getelementptr inbounds ptr, ptr %241, i64 0
  %243 = load ptr, ptr %242, align 8
  %244 = load i32, ptr %10, align 4
  %245 = sext i32 %244 to i64
  %246 = getelementptr inbounds float, ptr %243, i64 %245
  %247 = load float, ptr %246, align 4
  store float %247, ptr %18, align 4
  store i32 1, ptr %9, align 4
  br label %248

248:                                              ; preds = %264, %240
  %249 = load i32, ptr %9, align 4
  %250 = load i32, ptr %7, align 4
  %251 = icmp slt i32 %249, %250
  br i1 %251, label %252, label %267

252:                                              ; preds = %248
  %253 = load ptr, ptr %6, align 8
  %254 = load i32, ptr %9, align 4
  %255 = sext i32 %254 to i64
  %256 = getelementptr inbounds ptr, ptr %253, i64 %255
  %257 = load ptr, ptr %256, align 8
  %258 = load i32, ptr %10, align 4
  %259 = sext i32 %258 to i64
  %260 = getelementptr inbounds float, ptr %257, i64 %259
  %261 = load float, ptr %260, align 4
  %262 = load float, ptr %18, align 4
  %263 = fadd float %262, %261
  store float %263, ptr %18, align 4
  br label %264

264:                                              ; preds = %252
  %265 = load i32, ptr %9, align 4
  %266 = add nsw i32 %265, 1
  store i32 %266, ptr %9, align 4
  br label %248, !llvm.loop !11

267:                                              ; preds = %248
  %268 = load float, ptr %18, align 4
  %269 = load ptr, ptr %5, align 8
  %270 = load i32, ptr %10, align 4
  %271 = sext i32 %270 to i64
  %272 = getelementptr inbounds float, ptr %269, i64 %271
  store float %268, ptr %272, align 4
  br label %273

273:                                              ; preds = %267
  %274 = load i32, ptr %10, align 4
  %275 = add nsw i32 %274, 1
  store i32 %275, ptr %10, align 4
  br label %236, !llvm.loop !12

276:                                              ; preds = %236
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca [2 x ptr], align 16
  %5 = alloca ptr, align 8
  %6 = alloca float, align 4
  store i32 0, ptr %1, align 4
  store ptr @buffer, ptr %5, align 8
  %7 = and i64 sub (i64 0, i64 ptrtoint (ptr @buffer to i64)), 63
  %8 = load ptr, ptr %5, align 8
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 %7
  store ptr %9, ptr %5, align 8
  %10 = load ptr, ptr %5, align 8
  store ptr %10, ptr %3, align 8
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds float, ptr %11, i64 16
  %13 = getelementptr inbounds [2 x ptr], ptr %4, i64 0, i64 0
  store ptr %12, ptr %13, align 16
  %14 = load ptr, ptr %3, align 8
  %15 = getelementptr inbounds float, ptr %14, i64 32
  %16 = getelementptr inbounds [2 x ptr], ptr %4, i64 0, i64 1
  store ptr %15, ptr %16, align 8
  store i32 0, ptr %2, align 4
  br label %17

17:                                               ; preds = %41, %0
  %18 = load i32, ptr %2, align 4
  %19 = icmp slt i32 %18, 16
  br i1 %19, label %20, label %44

20:                                               ; preds = %17
  %21 = load i32, ptr %2, align 4
  %22 = sitofp i32 %21 to float
  %23 = load i32, ptr %2, align 4
  %24 = sitofp i32 %23 to float
  %25 = call float @llvm.fmuladd.f32(float 1.100000e+01, float %24, float %22)
  %26 = getelementptr inbounds [2 x ptr], ptr %4, i64 0, i64 0
  %27 = load ptr, ptr %26, align 16
  %28 = load i32, ptr %2, align 4
  %29 = sext i32 %28 to i64
  %30 = getelementptr inbounds float, ptr %27, i64 %29
  store float %25, ptr %30, align 4
  %31 = load i32, ptr %2, align 4
  %32 = sitofp i32 %31 to float
  %33 = load i32, ptr %2, align 4
  %34 = sitofp i32 %33 to float
  %35 = call float @llvm.fmuladd.f32(float 1.200000e+01, float %34, float %32)
  %36 = getelementptr inbounds [2 x ptr], ptr %4, i64 0, i64 1
  %37 = load ptr, ptr %36, align 8
  %38 = load i32, ptr %2, align 4
  %39 = sext i32 %38 to i64
  %40 = getelementptr inbounds float, ptr %37, i64 %39
  store float %35, ptr %40, align 4
  br label %41

41:                                               ; preds = %20
  %42 = load i32, ptr %2, align 4
  %43 = add nsw i32 %42, 1
  store i32 %43, ptr %2, align 4
  br label %17, !llvm.loop !13

44:                                               ; preds = %17
  %45 = load ptr, ptr %3, align 8
  %46 = getelementptr inbounds [2 x ptr], ptr %4, i64 0, i64 0
  call void @foo(ptr noundef %45, ptr noundef %46, i32 noundef 2, i32 noundef 16)
  store i32 0, ptr %2, align 4
  br label %47

47:                                               ; preds = %71, %44
  %48 = load i32, ptr %2, align 4
  %49 = icmp slt i32 %48, 16
  br i1 %49, label %50, label %74

50:                                               ; preds = %47
  %51 = load i32, ptr %2, align 4
  %52 = sitofp i32 %51 to float
  %53 = load i32, ptr %2, align 4
  %54 = sitofp i32 %53 to float
  %55 = call float @llvm.fmuladd.f32(float 1.100000e+01, float %54, float %52)
  %56 = load i32, ptr %2, align 4
  %57 = sitofp i32 %56 to float
  %58 = fadd float %55, %57
  %59 = load i32, ptr %2, align 4
  %60 = sitofp i32 %59 to float
  %61 = call float @llvm.fmuladd.f32(float 1.200000e+01, float %60, float %58)
  store float %61, ptr %6, align 4
  %62 = load ptr, ptr %3, align 8
  %63 = load i32, ptr %2, align 4
  %64 = sext i32 %63 to i64
  %65 = getelementptr inbounds float, ptr %62, i64 %64
  %66 = load float, ptr %65, align 4
  %67 = load float, ptr %6, align 4
  %68 = fcmp une float %66, %67
  br i1 %68, label %69, label %70

69:                                               ; preds = %50
  call void @abort() #3
  unreachable

70:                                               ; preds = %50
  br label %71

71:                                               ; preds = %70
  %72 = load i32, ptr %2, align 4
  %73 = add nsw i32 %72, 1
  store i32 %73, ptr %2, align 4
  br label %47, !llvm.loop !14

74:                                               ; preds = %47
  ret i32 0
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fmuladd.f32(float, float, float) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
