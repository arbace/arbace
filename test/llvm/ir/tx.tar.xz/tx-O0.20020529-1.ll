; ModuleID = '20020529-1.c'
source_filename = "20020529-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.xx = type { i32, ptr, i16 }

@f1.beenhere = internal global i32 0, align 4

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @foo(ptr noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  store ptr %0, ptr %5, align 8
  store i32 %1, ptr %6, align 4
  store i32 %2, ptr %7, align 4
  store i32 %3, ptr %8, align 4
  br label %10

10:                                               ; preds = %52, %19, %4
  %11 = load ptr, ptr %5, align 8
  %12 = call i32 @f1(ptr noundef %11)
  store i32 %12, ptr %9, align 4
  %13 = load i32, ptr %9, align 4
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %10
  ret i32 0

16:                                               ; preds = %10
  %17 = load i32, ptr %6, align 4
  %18 = icmp ne i32 %17, 0
  br i1 %18, label %19, label %20

19:                                               ; preds = %16
  br label %10

20:                                               ; preds = %16
  %21 = load i32, ptr %8, align 4
  %22 = trunc i32 %21 to i16
  %23 = load ptr, ptr %5, align 8
  %24 = getelementptr inbounds nuw %struct.xx, ptr %23, i32 0, i32 2
  store i16 %22, ptr %24, align 8
  %25 = load ptr, ptr %5, align 8
  %26 = getelementptr inbounds nuw %struct.xx, ptr %25, i32 0, i32 0
  %27 = load i32, ptr %26, align 8
  %28 = icmp ne i32 %27, 0
  br i1 %28, label %29, label %30

29:                                               ; preds = %20
  call void @f2()
  br label %30

30:                                               ; preds = %29, %20
  %31 = load i32, ptr %7, align 4
  %32 = icmp ne i32 %31, 0
  br i1 %32, label %33, label %34

33:                                               ; preds = %30
  call void @f2()
  br label %34

34:                                               ; preds = %33, %30
  %35 = load ptr, ptr %5, align 8
  %36 = getelementptr inbounds nuw %struct.xx, ptr %35, i32 0, i32 2
  %37 = load i16, ptr %36, align 8
  %38 = sext i16 %37 to i32
  store i32 %38, ptr %8, align 4
  %39 = load i32, ptr %9, align 4
  switch i32 %39, label %51 [
    i32 1, label %40
  ]

40:                                               ; preds = %34
  %41 = load ptr, ptr %5, align 8
  %42 = getelementptr inbounds nuw %struct.xx, ptr %41, i32 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = icmp ne ptr %43, null
  br i1 %44, label %45, label %46

45:                                               ; preds = %40
  call void @f2()
  br label %46

46:                                               ; preds = %45, %40
  %47 = load i32, ptr %7, align 4
  %48 = icmp ne i32 %47, 0
  br i1 %48, label %49, label %50

49:                                               ; preds = %46
  call void @f2()
  br label %50

50:                                               ; preds = %49, %46
  br label %51

51:                                               ; preds = %34, %50
  br label %52

52:                                               ; preds = %51
  br label %10
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @f1(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load i32, ptr @f1.beenhere, align 4
  %4 = add nsw i32 %3, 1
  store i32 %4, ptr @f1.beenhere, align 4
  %5 = icmp sgt i32 %3, 1
  br i1 %5, label %6, label %7

6:                                                ; preds = %1
  call void @abort() #4
  unreachable

7:                                                ; preds = %1
  %8 = load i32, ptr @f1.beenhere, align 4
  %9 = icmp sgt i32 %8, 1
  %10 = zext i1 %9 to i32
  ret i32 %10
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local void @f2() #0 {
  call void @abort() #4
  unreachable
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.xx, align 8
  store i32 0, ptr %1, align 4
  %3 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 0
  store i32 0, ptr %3, align 8
  %4 = getelementptr i8, ptr %2, i64 4
  call void @llvm.memset.p0.i64(ptr align 4 %4, i8 0, i64 4, i1 false)
  %5 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 1
  store ptr %2, ptr %5, align 8
  %6 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 2
  store i16 23, ptr %6, align 8
  %7 = getelementptr i8, ptr %2, i64 18
  call void @llvm.memset.p0.i64(ptr align 2 %7, i8 0, i64 6, i1 false)
  %8 = call i32 @foo(ptr noundef %2, i32 noundef 0, i32 noundef 0, i32 noundef 0)
  %9 = icmp ne i32 %8, 0
  br i1 %9, label %23, label %10

10:                                               ; preds = %0
  %11 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 0
  %12 = load i32, ptr %11, align 8
  %13 = icmp ne i32 %12, 0
  br i1 %13, label %23, label %14

14:                                               ; preds = %10
  %15 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 1
  %16 = load ptr, ptr %15, align 8
  %17 = icmp ne ptr %16, %2
  br i1 %17, label %23, label %18

18:                                               ; preds = %14
  %19 = getelementptr inbounds nuw %struct.xx, ptr %2, i32 0, i32 2
  %20 = load i16, ptr %19, align 8
  %21 = sext i16 %20 to i32
  %22 = icmp ne i32 %21, 0
  br i1 %22, label %23, label %24

23:                                               ; preds = %18, %14, %10, %0
  call void @abort() #4
  unreachable

24:                                               ; preds = %18
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
