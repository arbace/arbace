; ModuleID = '20040218-1.c'
source_filename = "20040218-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

@__const.main.y = private unnamed_addr constant [2 x i64] [i64 -1, i64 16000], align 16
@__const.main.yw = private unnamed_addr constant [2 x i16] [i16 -1, i16 16000], align 2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @xb(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = load i64, ptr %4, align 8
  %6 = and i64 %5, 255
  store i64 %6, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i64, ptr %8, i64 1
  %10 = load i64, ptr %9, align 8
  %11 = add nsw i64 %7, %10
  ret i64 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i64 @xw(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = load i64, ptr %4, align 8
  %6 = and i64 %5, 65535
  store i64 %6, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i64, ptr %8, i64 1
  %10 = load i64, ptr %9, align 8
  %11 = add nsw i64 %7, %10
  ret i64 %11
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local signext i16 @yb(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca i16, align 2
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = load i16, ptr %4, align 2
  %6 = sext i16 %5 to i32
  %7 = and i32 %6, 255
  %8 = trunc i32 %7 to i16
  store i16 %8, ptr %3, align 2
  %9 = load i16, ptr %3, align 2
  %10 = sext i16 %9 to i32
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds i16, ptr %11, i64 1
  %13 = load i16, ptr %12, align 2
  %14 = sext i16 %13 to i32
  %15 = add nsw i32 %10, %14
  %16 = trunc i32 %15 to i16
  ret i16 %16
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca [2 x i64], align 16
  %3 = alloca [2 x i16], align 2
  store i32 0, ptr %1, align 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %2, ptr align 16 @__const.main.y, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 2 %3, ptr align 2 @__const.main.yw, i64 4, i1 false)
  %4 = getelementptr inbounds [2 x i64], ptr %2, i64 0, i64 0
  %5 = call i64 @xb(ptr noundef %4)
  %6 = icmp ne i64 %5, 16255
  br i1 %6, label %16, label %7

7:                                                ; preds = %0
  %8 = getelementptr inbounds [2 x i64], ptr %2, i64 0, i64 0
  %9 = call i64 @xw(ptr noundef %8)
  %10 = icmp ne i64 %9, 81535
  br i1 %10, label %16, label %11

11:                                               ; preds = %7
  %12 = getelementptr inbounds [2 x i16], ptr %3, i64 0, i64 0
  %13 = call signext i16 @yb(ptr noundef %12)
  %14 = sext i16 %13 to i32
  %15 = icmp ne i32 %14, 16255
  br i1 %15, label %16, label %17

16:                                               ; preds = %11, %7, %0
  call void @abort() #4
  unreachable

17:                                               ; preds = %11
  call void @exit(i32 noundef 0) #5
  unreachable
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

; Function Attrs: noreturn
declare void @exit(i32 noundef) #3

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { noreturn nounwind }
attributes #5 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
