; ModuleID = '20071030-1.c'
source_filename = "20071030-1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-alpine-linux-musl"

%struct.client_s = type { i32, i32, [64 x %struct.client_frame_t] }
%struct.client_frame_t = type { double, float, %struct.packet_entities_t }
%struct.packet_entities_t = type { i32, ptr }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @CalcPing(ptr noundef %0) #0 {
  %2 = alloca i32, align 4
  %3 = alloca ptr, align 8
  %4 = alloca float, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %8 = load ptr, ptr %3, align 8
  %9 = getelementptr inbounds nuw %struct.client_s, ptr %8, i32 0, i32 0
  %10 = load i32, ptr %9, align 8
  %11 = icmp eq i32 %10, 1
  br i1 %11, label %12, label %16

12:                                               ; preds = %1
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds nuw %struct.client_s, ptr %13, i32 0, i32 1
  %15 = load i32, ptr %14, align 4
  store i32 %15, ptr %2, align 4
  br label %54

16:                                               ; preds = %1
  store float 0.000000e+00, ptr %4, align 4
  store i32 0, ptr %5, align 4
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw %struct.client_s, ptr %17, i32 0, i32 2
  %19 = getelementptr inbounds [64 x %struct.client_frame_t], ptr %18, i64 0, i64 0
  store ptr %19, ptr %7, align 8
  store i32 0, ptr %6, align 4
  br label %20

20:                                               ; preds = %37, %16
  %21 = load i32, ptr %6, align 4
  %22 = icmp slt i32 %21, 64
  br i1 %22, label %23, label %42

23:                                               ; preds = %20
  %24 = load ptr, ptr %7, align 8
  %25 = getelementptr inbounds nuw %struct.client_frame_t, ptr %24, i32 0, i32 1
  %26 = load float, ptr %25, align 8
  %27 = fcmp ogt float %26, 0.000000e+00
  br i1 %27, label %28, label %36

28:                                               ; preds = %23
  %29 = load ptr, ptr %7, align 8
  %30 = getelementptr inbounds nuw %struct.client_frame_t, ptr %29, i32 0, i32 1
  %31 = load float, ptr %30, align 8
  %32 = load float, ptr %4, align 4
  %33 = fadd float %32, %31
  store float %33, ptr %4, align 4
  %34 = load i32, ptr %5, align 4
  %35 = add nsw i32 %34, 1
  store i32 %35, ptr %5, align 4
  br label %36

36:                                               ; preds = %28, %23
  br label %37

37:                                               ; preds = %36
  %38 = load i32, ptr %6, align 4
  %39 = add nsw i32 %38, 1
  store i32 %39, ptr %6, align 4
  %40 = load ptr, ptr %7, align 8
  %41 = getelementptr inbounds nuw %struct.client_frame_t, ptr %40, i32 1
  store ptr %41, ptr %7, align 8
  br label %20, !llvm.loop !6

42:                                               ; preds = %20
  %43 = load i32, ptr %5, align 4
  %44 = icmp ne i32 %43, 0
  br i1 %44, label %46, label %45

45:                                               ; preds = %42
  store i32 9999, ptr %2, align 4
  br label %54

46:                                               ; preds = %42
  %47 = load i32, ptr %5, align 4
  %48 = sitofp i32 %47 to float
  %49 = load float, ptr %4, align 4
  %50 = fdiv float %49, %48
  store float %50, ptr %4, align 4
  %51 = load float, ptr %4, align 4
  %52 = fmul float %51, 1.000000e+03
  %53 = fptosi float %52 to i32
  store i32 %53, ptr %2, align 4
  br label %54

54:                                               ; preds = %46, %45, %12
  %55 = load i32, ptr %2, align 4
  ret i32 %55
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main() #0 {
  %1 = alloca i32, align 4
  %2 = alloca %struct.client_s, align 8
  store i32 0, ptr %1, align 4
  call void @llvm.memset.p0.i64(ptr align 8 %2, i8 0, i64 2056, i1 false)
  %3 = getelementptr inbounds nuw %struct.client_s, ptr %2, i32 0, i32 2
  %4 = getelementptr inbounds [64 x %struct.client_frame_t], ptr %3, i64 0, i64 0
  %5 = getelementptr inbounds nuw %struct.client_frame_t, ptr %4, i32 0, i32 1
  store float 1.000000e+00, ptr %5, align 8
  %6 = call i32 @CalcPing(ptr noundef %2)
  %7 = icmp ne i32 %6, 1000
  br i1 %7, label %8, label %9

8:                                                ; preds = %0
  call void @abort() #3
  unreachable

9:                                                ; preds = %0
  ret i32 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: noreturn nounwind
declare void @abort() #2

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "probe-stack"="inline-asm" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #2 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 4, !"probe-stack", !"inline-asm"}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"Alpine clang version 23.1.4"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
