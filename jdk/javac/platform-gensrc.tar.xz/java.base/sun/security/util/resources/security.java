package sun.security.util.resources;

import java.util.ListResourceBundle;

public final class security extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { ".Principal.", "\tPrincipal: " },
            { ".Private.Credential.", "\tPrivate Credential: " },
            { ".Private.Credential.inaccessible.", "\tPrivate Credential inaccessible\n" },
            { ".Public.Credential.", "\tPublic Credential: " },
            { "CredOwner.Principal.Class.class.Principal.Name.name", "CredOwner:\n\tPrincipal Class = {0}\n\tPrincipal Name = {1}" },
            { "Credential.Class.not.followed.by.a.Principal.Class.and.Name", "Credential Class not followed by a Principal Class and Name" },
            { "Invalid.null.input.name", "Invalid null input: name" },
            { "Login.Failure.all.modules.ignored", "Login Failure: all modules ignored" },
            { "LoginModuleControlFlag.", "LoginModuleControlFlag: " },
            { "NEWLINE", "\n" },
            { "No.LoginModules.configured.for.name", "No LoginModules configured for {0}" },
            { "PKCS11.Token.providerName.Password.", "PKCS11 Token [{0}] Password: " },
            { "Principal.Class.not.followed.by.a.Principal.Name", "Principal Class not followed by a Principal Name" },
            { "Principal.Name.missing.end.quote", "Principal Name missing end quote" },
            { "Principal.Name.must.be.surrounded.by.quotes", "Principal Name must be surrounded by quotes" },
            { "PrivateCredentialPermission.Principal.Class.can.not.be.a.wildcard.value.if.Principal.Name.is.not.a.wildcard.value", "PrivateCredentialPermission Principal Class can not be a wildcard (*) value if Principal Name is not a wildcard (*) value" },
            { "Subject.", "Subject:\n" },
            { "Subject.is.read.only", "Subject is read-only" },
            { "actions.can.only.be.read.", "actions can only be 'read'" },
            { "attempting.to.add.an.object.which.is.not.an.instance.of.class", "attempting to add an object which is not an instance of {0}" },
            { "attempting.to.add.an.object.which.is.not.an.instance.of.java.security.Principal.to.a.Subject.s.Principal.Set", "attempting to add an object which is not an instance of java.security.Principal to a Subject's Principal Set" },
            { "duplicate.keystore.domain.name", "duplicate keystore domain name: {0}" },
            { "duplicate.keystore.name", "duplicate keystore name: {0}" },
            { "expected.expect.read.end.of.file.", "expected [{0}], read [end of file]" },
            { "expected.read.end.of.file.", "expected [;], read [end of file]" },
            { "invalid.null.CallbackHandler.provided", "invalid null CallbackHandler provided" },
            { "invalid.null.Class.provided", "invalid null Class provided" },
            { "invalid.null.Subject.provided", "invalid null Subject provided" },
            { "invalid.null.action.provided", "invalid null action provided" },
            { "invalid.null.input.s.", "invalid null input(s)" },
            { "line.number.expected.expect.found.actual.", "line {0}: expected [{1}], found [{2}]" },
            { "line.number.msg", "line {0}: {1}" },
            { "null.subject.logout.called.before.login", "null subject - logout called before login" },
            { "number.", "number " },
            { "permission.name.name.syntax.invalid.", "permission name [{0}] syntax invalid: " },
            { "provided.null.OID.map", "provided null OID map" },
            { "provided.null.keyword.map", "provided null keyword map" },
            { "provided.null.name", "provided null name" },
            { "warning.input.may.be.visible.on.screen", "[WARNING: Input may be visible on screen] " },
        };
    }
}
