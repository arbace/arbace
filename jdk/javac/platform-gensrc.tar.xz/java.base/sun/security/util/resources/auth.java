package sun.security.util.resources;

import java.util.ListResourceBundle;

public final class auth extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "Configuration.Error.Can.not.specify.multiple.entries.for.appName", "Configuration Error:\n\tCan not specify multiple entries for {0}" },
            { "Configuration.Error.Invalid.control.flag.flag", "Configuration Error:\n\tInvalid control flag, {0}" },
            { "Configuration.Error.Line.line.expected.expect.", "Configuration Error:\n\tLine {0}: expected [{1}]" },
            { "Configuration.Error.Line.line.expected.expect.found.value.", "Configuration Error:\n\tLine {0}: expected [{1}], found [{2}]" },
            { "Configuration.Error.Line.line.system.property.value.expanded.to.empty.value", "Configuration Error:\n\tLine {0}: system property [{1}] expanded to empty value" },
            { "Configuration.Error.No.such.file.or.directory", "Configuration Error:\n\tNo such file or directory" },
            { "Configuration.Error.expected.expect.read.end.of.file.", "Configuration Error:\n\texpected [{0}], read [end of file]" },
            { "Invalid.NTSid.value", "Invalid NTSid value" },
            { "Kerberos.password.for.username.", "Kerberos password for {0}: " },
            { "Kerberos.username.defUsername.", "Kerberos username [{0}]: " },
            { "Keystore.alias.", "Keystore alias: " },
            { "Keystore.password.", "Keystore password: " },
            { "NTDomainPrincipal.name", "NTDomainPrincipal: {0}" },
            { "NTNumericCredential.name", "NTNumericCredential: {0}" },
            { "NTSid.name", "NTSid: {0}" },
            { "NTSidDomainPrincipal.name", "NTSidDomainPrincipal: {0}" },
            { "NTSidGroupPrincipal.name", "NTSidGroupPrincipal: {0}" },
            { "NTSidPrimaryGroupPrincipal.name", "NTSidPrimaryGroupPrincipal: {0}" },
            { "NTSidUserPrincipal.name", "NTSidUserPrincipal: {0}" },
            { "NTUserPrincipal.name", "NTUserPrincipal: {0}" },
            { "Please.enter.keystore.information", "Please enter keystore information" },
            { "Private.key.password.optional.", "Private key password (optional): " },
            { "Unable.to.properly.expand.config", "Unable to properly expand {0}" },
            { "UnixNumericGroupPrincipal.Primary.Group.name", "UnixNumericGroupPrincipal [Primary Group]: {0}" },
            { "UnixNumericGroupPrincipal.Supplementary.Group.name", "UnixNumericGroupPrincipal [Supplementary Group]: {0}" },
            { "UnixNumericUserPrincipal.name", "UnixNumericUserPrincipal: {0}" },
            { "UnixPrincipal.name", "UnixPrincipal: {0}" },
            { "extra.config.No.such.file.or.directory.", "{0} (No such file or directory)" },
            { "invalid.null.input.value", "invalid null input: {0}" },
            { "password.", "password: " },
            { "username.", "username: " },
        };
    }
}
