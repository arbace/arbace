//line a2g_classes.ae:1
package aot_arbace_spec_gen_alpha

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_spec_gen_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_A_New()}; return nil }

var A_arbace_spec_gen_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_A_new}

var A_arbace_spec_gen_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_A"})

func init() { i := A_arbace_spec_gen_alpha_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_A_Init; i.Table = A_arbace_spec_gen_alpha_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_A]()) }

func A_arbace_spec_gen_alpha_cat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_cat_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_cat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_cat_A_New()}; return nil }

func A_arbace_spec_gen_alpha_cat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_cat_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_cat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_cat_A_invoke, New: A_arbace_spec_gen_alpha_cat_A_new, Get: A_arbace_spec_gen_alpha_cat_A_get}

var A_arbace_spec_gen_alpha_cat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$cat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "cat", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_cat_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_cat_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_cat_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_cat_A_Init; i.Table = A_arbace_spec_gen_alpha_cat_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_cat_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_cat_A]()) }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_cat_fn__1067000325_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_cat_fn__1067000325_A_New()}; return nil }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_cat_fn__1067000325_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_cat_fn__1067000325_A_invoke, New: A_arbace_spec_gen_alpha_cat_fn__1067000325_A_new, Get: A_arbace_spec_gen_alpha_cat_fn__1067000325_A_get}

var A_arbace_spec_gen_alpha_cat_fn__1067000325_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$cat$fn__1067000325", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_cat_A_class, Simple: "fn__1067000325", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_cat_fn__1067000325_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_cat_fn__1067000325_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_Init; i.Table = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_cat_fn__1067000325_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_cat_fn__1067000325_A]()) }

func A_arbace_spec_gen_alpha_delay_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_delay_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_gen_alpha_delay_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_delay_A_New()}; return nil }

func A_arbace_spec_gen_alpha_delay_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_delay_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_delay_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_delay_A_invoke, New: A_arbace_spec_gen_alpha_delay_A_new, Get: A_arbace_spec_gen_alpha_delay_A_get}

var A_arbace_spec_gen_alpha_delay_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$delay", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "delay", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_delay_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_delay_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_delay_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_delay_A_Init; i.Table = A_arbace_spec_gen_alpha_delay_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_delay_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_delay_A]()) }

func A_arbace_spec_gen_alpha_delay_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_delay_impl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_delay_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_delay_impl_A_New()}; return nil }

func A_arbace_spec_gen_alpha_delay_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_delay_impl_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_delay_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_delay_impl_A_invoke, New: A_arbace_spec_gen_alpha_delay_impl_A_new, Get: A_arbace_spec_gen_alpha_delay_impl_A_get}

var A_arbace_spec_gen_alpha_delay_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$delay_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "delay_impl", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_delay_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_delay_impl_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_delay_impl_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_delay_impl_A_Init; i.Table = A_arbace_spec_gen_alpha_delay_impl_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_delay_impl_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_delay_impl_A]()) }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_invoke, New: A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_new, Get: A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_get}

var A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$delay_impl$fn__1067000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_gen_alpha_delay_impl_A_class, Simple: "fn__1067000037", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_Init; i.Table = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A]()) }

func A_arbace_spec_gen_alpha_dynaload_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_dynaload_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_dynaload_A_New()}; return nil }

func A_arbace_spec_gen_alpha_dynaload_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_dynaload_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_dynaload_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_dynaload_A_invoke, New: A_arbace_spec_gen_alpha_dynaload_A_new, Get: A_arbace_spec_gen_alpha_dynaload_A_get}

var A_arbace_spec_gen_alpha_dynaload_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$dynaload", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "dynaload", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_dynaload_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_dynaload_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_dynaload_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_dynaload_A_Init; i.Table = A_arbace_spec_gen_alpha_dynaload_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_dynaload_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_dynaload_A]()) }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_invoke, New: A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_new, Get: A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_get}

var A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$dynaload$fn__1067000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_dynaload_A_class, Simple: "fn__1067000014", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_Init; i.Table = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A]()) }

func A_arbace_spec_gen_alpha_eval1067000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000002_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000002_A_new}

var A_arbace_spec_gen_alpha_eval1067000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000002", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000002_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000002_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000002_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000002_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000002_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000002_A]()) }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_new, Get: A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_get}

var A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000002$loading__1927001464__auto____1067000003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000002_A_class, Simple: "loading__1927001464__auto____1067000003", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A]()) }

func A_arbace_spec_gen_alpha_eval1067000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000006_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000006_A_new}

var A_arbace_spec_gen_alpha_eval1067000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000006", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000006_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000006_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000006_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000006_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000006_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000006_A]()) }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_new, Get: A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_get}

var A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000006$fn__1067000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000006_A_class, Simple: "fn__1067000007", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000023_A_new}

var A_arbace_spec_gen_alpha_eval1067000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000023", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000023_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$fn__1067000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "fn__1067000024", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$fn__1067000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "fn__1067000026", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$fn__1067000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "fn__1067000028", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$generate__1067000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "generate__1067000034", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$generator_QMARK___1067000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "generator_QMARK___1067000030", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A]()) }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_new, Get: A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_get}

var A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000023$generator__1067000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000023_A_class, Simple: "generator__1067000032", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A]()) }

func A_arbace_spec_gen_alpha_eval1067000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000059_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000059_A_new}

var A_arbace_spec_gen_alpha_eval1067000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000059", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000059_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000059_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000059_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000059_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000059_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000059_A]()) }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_new, Get: A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_get}

var A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000059$fn__1067000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000059_A_class, Simple: "fn__1067000060", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A]()) }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_new, Get: A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_get}

var A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000059$hash_map__1067000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000059_A_class, Simple: "hash_map__1067000062", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A]()) }

func A_arbace_spec_gen_alpha_eval1067000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000065_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000065_A_new}

var A_arbace_spec_gen_alpha_eval1067000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000065", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000065_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000065_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000065_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000065_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000065_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000065_A]()) }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_new, Get: A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_get}

var A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000065$fn__1067000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000065_A_class, Simple: "fn__1067000066", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A]()) }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_new, Get: A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_get}

var A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000065$list__1067000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000065_A_class, Simple: "list__1067000068", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A]()) }

func A_arbace_spec_gen_alpha_eval1067000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000071_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000071_A_new}

var A_arbace_spec_gen_alpha_eval1067000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000071", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000071_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000071_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000071_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000071_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000071_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000071_A]()) }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_new, Get: A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_get}

var A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000071$fn__1067000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000071_A_class, Simple: "fn__1067000072", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A]()) }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_new, Get: A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_get}

var A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000071$map__1067000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000071_A_class, Simple: "map__1067000074", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A]()) }

func A_arbace_spec_gen_alpha_eval1067000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000077_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000077_A_new}

var A_arbace_spec_gen_alpha_eval1067000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000077", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000077_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000077_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000077_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000077_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000077_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000077_A]()) }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_new, Get: A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_get}

var A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000077$fn__1067000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000077_A_class, Simple: "fn__1067000078", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A]()) }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_new, Get: A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_get}

var A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000077$not_empty__1067000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000077_A_class, Simple: "not_empty__1067000080", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A]()) }

func A_arbace_spec_gen_alpha_eval1067000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000083_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000083_A_new}

var A_arbace_spec_gen_alpha_eval1067000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000083", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000083_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000083_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000083_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000083_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000083_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000083_A]()) }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_new, Get: A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_get}

var A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000083$fn__1067000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000083_A_class, Simple: "fn__1067000084", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A]()) }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_new, Get: A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_get}

var A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000083$set__1067000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000083_A_class, Simple: "set__1067000086", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A]()) }

func A_arbace_spec_gen_alpha_eval1067000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000089_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000089_A_new}

var A_arbace_spec_gen_alpha_eval1067000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000089", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000089_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000089_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000089_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000089_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000089_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000089_A]()) }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_new, Get: A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_get}

var A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000089$fn__1067000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000089_A_class, Simple: "fn__1067000090", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A]()) }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_new, Get: A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_get}

var A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000089$vector__1067000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000089_A_class, Simple: "vector__1067000092", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A]()) }

func A_arbace_spec_gen_alpha_eval1067000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000095_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000095_A_new}

var A_arbace_spec_gen_alpha_eval1067000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000095", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000095_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000095_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000095_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000095_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000095_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000095_A]()) }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_new, Get: A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_get}

var A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000095$fn__1067000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000095_A_class, Simple: "fn__1067000096", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A]()) }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_new, Get: A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_get}

var A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000095$vector_distinct__1067000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000095_A_class, Simple: "vector_distinct__1067000098", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A]()) }

func A_arbace_spec_gen_alpha_eval1067000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000101_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000101_A_new}

var A_arbace_spec_gen_alpha_eval1067000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000101", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000101_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000101_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000101_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000101_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000101_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000101_A]()) }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_new, Get: A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_get}

var A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000101$elements__1067000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000101_A_class, Simple: "elements__1067000104", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A]()) }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_new, Get: A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_get}

var A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000101$fn__1067000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000101_A_class, Simple: "fn__1067000102", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A]()) }

func A_arbace_spec_gen_alpha_eval1067000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000107_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000107_A_new}

var A_arbace_spec_gen_alpha_eval1067000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000107", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000107_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000107_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000107_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000107_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000107_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000107_A]()) }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_new, Get: A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_get}

var A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000107$bind__1067000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000107_A_class, Simple: "bind__1067000110", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A]()) }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_new, Get: A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_get}

var A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000107$fn__1067000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000107_A_class, Simple: "fn__1067000108", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A]()) }

func A_arbace_spec_gen_alpha_eval1067000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000113_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000113_A_new}

var A_arbace_spec_gen_alpha_eval1067000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000113", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000113_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000113_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000113_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000113_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000113_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000113_A]()) }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_new, Get: A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_get}

var A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000113$choose__1067000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000113_A_class, Simple: "choose__1067000116", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A]()) }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_new, Get: A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_get}

var A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000113$fn__1067000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000113_A_class, Simple: "fn__1067000114", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A]()) }

func A_arbace_spec_gen_alpha_eval1067000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000119_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000119_A_new}

var A_arbace_spec_gen_alpha_eval1067000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000119", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000119_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000119_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000119_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000119_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000119_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000119_A]()) }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_new, Get: A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_get}

var A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000119$fmap__1067000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000119_A_class, Simple: "fmap__1067000122", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A]()) }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_new, Get: A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_get}

var A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000119$fn__1067000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000119_A_class, Simple: "fn__1067000120", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A]()) }

func A_arbace_spec_gen_alpha_eval1067000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000125_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000125_A_new}

var A_arbace_spec_gen_alpha_eval1067000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000125", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000125_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000125_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000125_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000125_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000125_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000125_A]()) }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_new, Get: A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_get}

var A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000125$fn__1067000126", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000125_A_class, Simple: "fn__1067000126", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A]()) }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_new, Get: A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_get}

var A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000125$one_of__1067000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000125_A_class, Simple: "one_of__1067000128", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A]()) }

func A_arbace_spec_gen_alpha_eval1067000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000131_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000131_A_new}

var A_arbace_spec_gen_alpha_eval1067000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000131", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000131_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000131_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000131_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000131_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000131_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000131_A]()) }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_new, Get: A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_get}

var A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000131$fn__1067000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000131_A_class, Simple: "fn__1067000132", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A]()) }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_new, Get: A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_get}

var A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000131$such_that__1067000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000131_A_class, Simple: "such_that__1067000134", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A]()) }

func A_arbace_spec_gen_alpha_eval1067000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000137_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000137_A_new}

var A_arbace_spec_gen_alpha_eval1067000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000137", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000137_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000137_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000137_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000137_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000137_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000137_A]()) }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_new, Get: A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_get}

var A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000137$fn__1067000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000137_A_class, Simple: "fn__1067000138", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A]()) }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_new, Get: A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_get}

var A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000137$tuple__1067000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000137_A_class, Simple: "tuple__1067000140", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A]()) }

func A_arbace_spec_gen_alpha_eval1067000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000143_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000143_A_new}

var A_arbace_spec_gen_alpha_eval1067000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000143", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000143_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000143_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000143_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000143_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000143_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000143_A]()) }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_new, Get: A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_get}

var A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000143$fn__1067000144", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000143_A_class, Simple: "fn__1067000144", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A]()) }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_new, Get: A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_get}

var A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000143$sample__1067000146", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000143_A_class, Simple: "sample__1067000146", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A]()) }

func A_arbace_spec_gen_alpha_eval1067000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000149_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000149_A_new}

var A_arbace_spec_gen_alpha_eval1067000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000149", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000149_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000149_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000149_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000149_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000149_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000149_A]()) }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_new, Get: A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_get}

var A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000149$fn__1067000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000149_A_class, Simple: "fn__1067000150", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A]()) }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_new, Get: A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_get}

var A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000149$return__1067000152", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000149_A_class, Simple: "return__1067000152", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A]()) }

func A_arbace_spec_gen_alpha_eval1067000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000155_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000155_A_new}

var A_arbace_spec_gen_alpha_eval1067000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000155", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000155_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000155_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000155_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000155_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000155_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000155_A]()) }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_new, Get: A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_get}

var A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000155$fn__1067000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000155_A_class, Simple: "fn__1067000156", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A]()) }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_new, Get: A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_get}

var A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000155$large_integer_STAR___1067000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000155_A_class, Simple: "large_integer_STAR___1067000158", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A]()) }

func A_arbace_spec_gen_alpha_eval1067000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000161_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000161_A_new}

var A_arbace_spec_gen_alpha_eval1067000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000161", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000161_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000161_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000161_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000161_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000161_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000161_A]()) }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_new, Get: A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_get}

var A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000161$double_STAR___1067000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000161_A_class, Simple: "double_STAR___1067000164", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A]()) }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_new, Get: A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_get}

var A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000161$fn__1067000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000161_A_class, Simple: "fn__1067000162", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A]()) }

func A_arbace_spec_gen_alpha_eval1067000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000167_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000167_A_new}

var A_arbace_spec_gen_alpha_eval1067000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000167", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000167_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000167_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000167_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000167_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000167_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000167_A]()) }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_new, Get: A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_get}

var A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000167$fn__1067000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000167_A_class, Simple: "fn__1067000168", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A]()) }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_new, Get: A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_get}

var A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000167$frequency__1067000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000167_A_class, Simple: "frequency__1067000170", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A]()) }

func A_arbace_spec_gen_alpha_eval1067000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000173_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000173_A_new}

var A_arbace_spec_gen_alpha_eval1067000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000173", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000173_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000173_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000173_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000173_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000173_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000173_A]()) }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_new, Get: A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_get}

var A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000173$fn__1067000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000173_A_class, Simple: "fn__1067000174", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A]()) }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_new, Get: A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_get}

var A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000173$shuffle__1067000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000173_A_class, Simple: "shuffle__1067000176", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A]()) }

func A_arbace_spec_gen_alpha_eval1067000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000192_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000192_A_new}

var A_arbace_spec_gen_alpha_eval1067000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000192", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000192_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000192_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000192_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000192_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000192_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000192_A]()) }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_new, Get: A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_get}

var A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000192$any__1067000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000192_A_class, Simple: "any__1067000195", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A]()) }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_new, Get: A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_get}

var A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000192$fn__1067000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000192_A_class, Simple: "fn__1067000193", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A]()) }

func A_arbace_spec_gen_alpha_eval1067000198_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000198_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000198_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000198_A_new}

var A_arbace_spec_gen_alpha_eval1067000198_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000198", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000198", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000198_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000198_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000198_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000198_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000198_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000198_A]()) }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_new, Get: A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_get}

var A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000198$any_printable__1067000201", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000198_A_class, Simple: "any_printable__1067000201", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A]()) }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_new, Get: A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_get}

var A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000198$fn__1067000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000198_A_class, Simple: "fn__1067000199", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A]()) }

func A_arbace_spec_gen_alpha_eval1067000204_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000204_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000204_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000204_A_new}

var A_arbace_spec_gen_alpha_eval1067000204_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000204", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000204", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000204_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000204_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000204_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000204_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000204_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000204_A]()) }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_new, Get: A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_get}

var A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000204$boolean__1067000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000204_A_class, Simple: "boolean__1067000207", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A]()) }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_new, Get: A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_get}

var A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000204$fn__1067000205", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000204_A_class, Simple: "fn__1067000205", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A]()) }

func A_arbace_spec_gen_alpha_eval1067000210_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000210_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000210_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000210_A_new}

var A_arbace_spec_gen_alpha_eval1067000210_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000210", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000210", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000210_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000210_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000210_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000210_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000210_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000210_A]()) }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_new, Get: A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_get}

var A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000210$bytes__1067000213", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000210_A_class, Simple: "bytes__1067000213", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A]()) }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_new, Get: A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_get}

var A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000210$fn__1067000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000210_A_class, Simple: "fn__1067000211", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A]()) }

func A_arbace_spec_gen_alpha_eval1067000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000216_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000216_A_new}

var A_arbace_spec_gen_alpha_eval1067000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000216", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000216_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000216_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000216_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000216_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000216_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000216_A]()) }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_new, Get: A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_get}

var A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000216$char__1067000219", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000216_A_class, Simple: "char__1067000219", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A]()) }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_new, Get: A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_get}

var A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000216$fn__1067000217", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000216_A_class, Simple: "fn__1067000217", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A]()) }

func A_arbace_spec_gen_alpha_eval1067000222_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000222_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000222_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000222_A_new}

var A_arbace_spec_gen_alpha_eval1067000222_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000222", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000222", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000222_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000222_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000222_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000222_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000222_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000222_A]()) }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_new, Get: A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_get}

var A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000222$char_alpha__1067000225", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000222_A_class, Simple: "char_alpha__1067000225", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A]()) }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_new, Get: A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_get}

var A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000222$fn__1067000223", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000222_A_class, Simple: "fn__1067000223", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A]()) }

func A_arbace_spec_gen_alpha_eval1067000228_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000228_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000228_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000228_A_new}

var A_arbace_spec_gen_alpha_eval1067000228_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000228", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000228", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000228_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000228_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000228_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000228_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000228_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000228_A]()) }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_new, Get: A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_get}

var A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000228$char_alphanumeric__1067000231", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000228_A_class, Simple: "char_alphanumeric__1067000231", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A]()) }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_new, Get: A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_get}

var A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000228$fn__1067000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000228_A_class, Simple: "fn__1067000229", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A]()) }

func A_arbace_spec_gen_alpha_eval1067000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000234_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000234_A_new}

var A_arbace_spec_gen_alpha_eval1067000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000234", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000234_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000234_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000234_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000234_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000234_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000234_A]()) }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_new, Get: A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_get}

var A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000234$char_ascii__1067000237", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000234_A_class, Simple: "char_ascii__1067000237", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A]()) }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_new, Get: A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_get}

var A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000234$fn__1067000235", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000234_A_class, Simple: "fn__1067000235", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A]()) }

func A_arbace_spec_gen_alpha_eval1067000240_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000240_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000240_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000240_A_new}

var A_arbace_spec_gen_alpha_eval1067000240_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000240", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000240", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000240_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000240_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000240_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000240_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000240_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000240_A]()) }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_new, Get: A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_get}

var A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000240$double__1067000243", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000240_A_class, Simple: "double__1067000243", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A]()) }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_new, Get: A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_get}

var A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000240$fn__1067000241", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000240_A_class, Simple: "fn__1067000241", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A]()) }

func A_arbace_spec_gen_alpha_eval1067000246_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000246_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000246_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000246_A_new}

var A_arbace_spec_gen_alpha_eval1067000246_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000246", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000246", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000246_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000246_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000246_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000246_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000246_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000246_A]()) }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_new, Get: A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_get}

var A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000246$fn__1067000247", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000246_A_class, Simple: "fn__1067000247", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A]()) }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_new, Get: A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_get}

var A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000246$int__1067000249", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000246_A_class, Simple: "int__1067000249", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A]()) }

func A_arbace_spec_gen_alpha_eval1067000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000252_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000252_A_new}

var A_arbace_spec_gen_alpha_eval1067000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000252", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000252_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000252_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000252_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000252_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000252_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000252_A]()) }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_new, Get: A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_get}

var A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000252$fn__1067000253", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000252_A_class, Simple: "fn__1067000253", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A]()) }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_new, Get: A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_get}

var A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000252$keyword__1067000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000252_A_class, Simple: "keyword__1067000255", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A]()) }

func A_arbace_spec_gen_alpha_eval1067000258_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000258_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000258_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000258_A_new}

var A_arbace_spec_gen_alpha_eval1067000258_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000258", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000258", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000258_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000258_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000258_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000258_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000258_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000258_A]()) }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_new, Get: A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_get}

var A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000258$fn__1067000259", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000258_A_class, Simple: "fn__1067000259", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A]()) }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_new, Get: A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_get}

var A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000258$keyword_ns__1067000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000258_A_class, Simple: "keyword_ns__1067000261", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A]()) }

func A_arbace_spec_gen_alpha_eval1067000264_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000264_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000264_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000264_A_new}

var A_arbace_spec_gen_alpha_eval1067000264_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000264", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000264", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000264_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000264_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000264_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000264_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000264_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000264_A]()) }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_new, Get: A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_get}

var A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000264$fn__1067000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000264_A_class, Simple: "fn__1067000265", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A]()) }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_new, Get: A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_get}

var A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000264$large_integer__1067000267", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000264_A_class, Simple: "large_integer__1067000267", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A]()) }

func A_arbace_spec_gen_alpha_eval1067000270_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000270_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000270_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000270_A_new}

var A_arbace_spec_gen_alpha_eval1067000270_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000270", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000270", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000270_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000270_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000270_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000270_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000270_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000270_A]()) }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_new, Get: A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_get}

var A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000270$fn__1067000271", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000270_A_class, Simple: "fn__1067000271", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A]()) }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_new, Get: A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_get}

var A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000270$ratio__1067000273", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000270_A_class, Simple: "ratio__1067000273", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A]()) }

func A_arbace_spec_gen_alpha_eval1067000276_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000276_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000276_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000276_A_new}

var A_arbace_spec_gen_alpha_eval1067000276_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000276", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000276", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000276_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000276_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000276_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000276_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000276_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000276_A]()) }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_new, Get: A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_get}

var A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000276$fn__1067000277", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000276_A_class, Simple: "fn__1067000277", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A]()) }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_new, Get: A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_get}

var A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000276$simple_type__1067000279", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000276_A_class, Simple: "simple_type__1067000279", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A]()) }

func A_arbace_spec_gen_alpha_eval1067000282_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000282_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000282_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000282_A_new}

var A_arbace_spec_gen_alpha_eval1067000282_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000282", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000282", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000282_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000282_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000282_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000282_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000282_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000282_A]()) }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_new, Get: A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_get}

var A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000282$fn__1067000283", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000282_A_class, Simple: "fn__1067000283", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A]()) }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_new, Get: A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_get}

var A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000282$simple_type_printable__1067000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000282_A_class, Simple: "simple_type_printable__1067000285", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A]()) }

func A_arbace_spec_gen_alpha_eval1067000288_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000288_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000288_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000288_A_new}

var A_arbace_spec_gen_alpha_eval1067000288_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000288", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000288", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000288_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000288_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000288_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000288_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000288_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000288_A]()) }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_new, Get: A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_get}

var A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000288$fn__1067000289", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000288_A_class, Simple: "fn__1067000289", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A]()) }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_new, Get: A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_get}

var A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000288$string__1067000291", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000288_A_class, Simple: "string__1067000291", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A]()) }

func A_arbace_spec_gen_alpha_eval1067000294_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000294_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000294_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000294_A_new}

var A_arbace_spec_gen_alpha_eval1067000294_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000294", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000294", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000294_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000294_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000294_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000294_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000294_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000294_A]()) }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_new, Get: A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_get}

var A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000294$fn__1067000295", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000294_A_class, Simple: "fn__1067000295", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A]()) }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_new, Get: A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_get}

var A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000294$string_ascii__1067000297", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000294_A_class, Simple: "string_ascii__1067000297", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A]()) }

func A_arbace_spec_gen_alpha_eval1067000300_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000300_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000300_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000300_A_new}

var A_arbace_spec_gen_alpha_eval1067000300_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000300", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000300", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000300_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000300_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000300_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000300_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000300_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000300_A]()) }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_new, Get: A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_get}

var A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000300$fn__1067000301", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000300_A_class, Simple: "fn__1067000301", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A]()) }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_new, Get: A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_get}

var A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000300$string_alphanumeric__1067000303", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000300_A_class, Simple: "string_alphanumeric__1067000303", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A]()) }

func A_arbace_spec_gen_alpha_eval1067000306_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000306_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000306_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000306_A_new}

var A_arbace_spec_gen_alpha_eval1067000306_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000306", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000306", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000306_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000306_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000306_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000306_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000306_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000306_A]()) }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_new, Get: A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_get}

var A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000306$fn__1067000307", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000306_A_class, Simple: "fn__1067000307", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A]()) }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_new, Get: A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_get}

var A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000306$symbol__1067000309", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000306_A_class, Simple: "symbol__1067000309", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A]()) }

func A_arbace_spec_gen_alpha_eval1067000312_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000312_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000312_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000312_A_new}

var A_arbace_spec_gen_alpha_eval1067000312_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000312", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000312", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000312_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000312_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000312_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000312_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000312_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000312_A]()) }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_new, Get: A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_get}

var A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000312$fn__1067000313", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000312_A_class, Simple: "fn__1067000313", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A]()) }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_new, Get: A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_get}

var A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000312$symbol_ns__1067000315", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000312_A_class, Simple: "symbol_ns__1067000315", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A]()) }

func A_arbace_spec_gen_alpha_eval1067000318_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000318_A_New()}; return nil }

var A_arbace_spec_gen_alpha_eval1067000318_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_gen_alpha_eval1067000318_A_new}

var A_arbace_spec_gen_alpha_eval1067000318_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000318", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "eval1067000318", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000318_A"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000318_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000318_A_InstanceOf; i.Table = A_arbace_spec_gen_alpha_eval1067000318_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000318_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000318_A]()) }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_New()}; return nil }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_new, Get: A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_get}

var A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000318$fn__1067000319", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000318_A_class, Simple: "fn__1067000319", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A]()) }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_New_O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_invoke, New: A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_new, Get: A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_get}

var A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$eval1067000318$uuid__1067000321", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_eval1067000318_A_class, Simple: "uuid__1067000321", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_Init; i.Table = A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000017_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000017_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000017_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000017_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000017_A_get}

var A_arbace_spec_gen_alpha_fn__1067000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "fn__1067000017", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000017_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000017_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000017_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000017_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000017_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000017_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000017_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000020_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000020_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000020_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000020_A_get}

var A_arbace_spec_gen_alpha_fn__1067000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "fn__1067000020", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000020_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000020_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000020_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000020_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000020_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000020_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000020_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000332_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000332_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000332_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000332_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000332_A_get}

var A_arbace_spec_gen_alpha_fn__1067000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "fn__1067000332", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000332_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000332_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000332_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000332_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000332_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000332_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000332_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_get}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000332$fn__1067000333", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_fn__1067000332_A_class, Simple: "fn__1067000333", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_get}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000332$fn__1067000335", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_fn__1067000332_A_class, Simple: "fn__1067000335", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A]()) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_New()}; return nil }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_invoke, New: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_new, Get: A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_get}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$fn__1067000332$fn__1067000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_fn__1067000332_A_class, Simple: "fn__1067000337", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_Init; i.Table = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A]()) }

func A_arbace_spec_gen_alpha_for_all_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_for_all_STAR__A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_for_all_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_for_all_STAR__A_New()}; return nil }

func A_arbace_spec_gen_alpha_for_all_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_for_all_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_for_all_STAR__A_invoke, New: A_arbace_spec_gen_alpha_for_all_STAR__A_new, Get: A_arbace_spec_gen_alpha_for_all_STAR__A_get}

var A_arbace_spec_gen_alpha_for_all_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$for_all_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "for_all_STAR_", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_for_all_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_for_all_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_for_all_STAR__A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_for_all_STAR__A_Init; i.Table = A_arbace_spec_gen_alpha_for_all_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_for_all_STAR__A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_for_all_STAR__A]()) }

func A_arbace_spec_gen_alpha_gen_for_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_gen_for_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_gen_for_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_gen_for_name_A_New()}; return nil }

func A_arbace_spec_gen_alpha_gen_for_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_gen_for_name_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_gen_for_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_gen_for_name_A_invoke, New: A_arbace_spec_gen_alpha_gen_for_name_A_new, Get: A_arbace_spec_gen_alpha_gen_for_name_A_get}

var A_arbace_spec_gen_alpha_gen_for_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$gen_for_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "gen_for_name", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_gen_for_name_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_gen_for_name_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_gen_for_name_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_gen_for_name_A_Init; i.Table = A_arbace_spec_gen_alpha_gen_for_name_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_gen_for_name_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_gen_for_name_A]()) }

func A_arbace_spec_gen_alpha_gen_for_pred_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_gen_for_pred_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_gen_for_pred_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_gen_for_pred_A_New()}; return nil }

func A_arbace_spec_gen_alpha_gen_for_pred_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_gen_for_pred_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_gen_for_pred_A_invoke, New: A_arbace_spec_gen_alpha_gen_for_pred_A_new, Get: A_arbace_spec_gen_alpha_gen_for_pred_A_get}

var A_arbace_spec_gen_alpha_gen_for_pred_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$gen_for_pred", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "gen_for_pred", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_gen_for_pred_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_gen_for_pred_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_gen_for_pred_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_gen_for_pred_A_Init; i.Table = A_arbace_spec_gen_alpha_gen_for_pred_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_gen_for_pred_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_gen_for_pred_A]()) }

func A_arbace_spec_gen_alpha_lazy_combinator_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_combinator_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinator_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_combinator_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinator_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_combinator_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_combinator_A_invoke, New: A_arbace_spec_gen_alpha_lazy_combinator_A_new, Get: A_arbace_spec_gen_alpha_lazy_combinator_A_get}

var A_arbace_spec_gen_alpha_lazy_combinator_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_combinator", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "lazy_combinator", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_combinator_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_combinator_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_combinator_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_combinator_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_combinator_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_combinator_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_combinator_A]()) }

func A_arbace_spec_gen_alpha_lazy_combinators_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_combinators_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinators_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_combinators_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinators_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_combinators_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_combinators_A_invoke, New: A_arbace_spec_gen_alpha_lazy_combinators_A_new, Get: A_arbace_spec_gen_alpha_lazy_combinators_A_get}

var A_arbace_spec_gen_alpha_lazy_combinators_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_combinators", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "lazy_combinators", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_combinators_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_combinators_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_combinators_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_combinators_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_combinators_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_combinators_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_combinators_A]()) }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_invoke, New: A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_new, Get: A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_get}

var A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_combinators$fn__1067000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_lazy_combinators_A_class, Simple: "fn__1067000052", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A]()) }

func A_arbace_spec_gen_alpha_lazy_prim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_prim_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_gen_alpha_lazy_prim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_prim_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_prim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_prim_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_prim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_prim_A_invoke, New: A_arbace_spec_gen_alpha_lazy_prim_A_new, Get: A_arbace_spec_gen_alpha_lazy_prim_A_get}

var A_arbace_spec_gen_alpha_lazy_prim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_prim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "lazy_prim", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_prim_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_prim_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_prim_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_prim_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_prim_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_prim_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_prim_A]()) }

func A_arbace_spec_gen_alpha_lazy_prims_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_prims_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_gen_alpha_lazy_prims_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_prims_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_prims_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_prims_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_prims_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_prims_A_invoke, New: A_arbace_spec_gen_alpha_lazy_prims_A_new, Get: A_arbace_spec_gen_alpha_lazy_prims_A_get}

var A_arbace_spec_gen_alpha_lazy_prims_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_prims", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "lazy_prims", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_prims_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_prims_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_prims_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_prims_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_prims_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_prims_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_prims_A]()) }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_New()}; return nil }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_invoke, New: A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_new, Get: A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_get}

var A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$lazy_prims$fn__1067000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_lazy_prims_A_class, Simple: "fn__1067000185", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_Init; i.Table = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A]()) }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_qualified_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_qualified_QMARK__A_New()}; return nil }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_qualified_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_qualified_QMARK__A_invoke, New: A_arbace_spec_gen_alpha_qualified_QMARK__A_new, Get: A_arbace_spec_gen_alpha_qualified_QMARK__A_get}

var A_arbace_spec_gen_alpha_qualified_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$qualified_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "qualified_QMARK_", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_qualified_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_qualified_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_qualified_QMARK__A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_qualified_QMARK__A_Init; i.Table = A_arbace_spec_gen_alpha_qualified_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_qualified_QMARK__A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_qualified_QMARK__A]()) }

func A_arbace_spec_gen_alpha_quick_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_gen_alpha_quick_check_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_gen_alpha_quick_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha_quick_check_A_New()}; return nil }

func A_arbace_spec_gen_alpha_quick_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_gen_alpha_quick_check_A_fn_class)}; return nil }

var A_arbace_spec_gen_alpha_quick_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_gen_alpha_quick_check_A_invoke, New: A_arbace_spec_gen_alpha_quick_check_A_new, Get: A_arbace_spec_gen_alpha_quick_check_A_get}

var A_arbace_spec_gen_alpha_quick_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha$quick_check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_gen_alpha_A_class, Simple: "quick_check", Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_quick_check_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha_quick_check_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha_quick_check_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha_quick_check_A_Init; i.Table = A_arbace_spec_gen_alpha_quick_check_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha_quick_check_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha_quick_check_A]()) }

func A_arbace_spec_gen_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha__init_A_Load__O(); case 1: return A_arbace_spec_gen_alpha__init_A_Unit0__O(); case 2: return A_arbace_spec_gen_alpha__init_A_Unit1__O(); case 3: return A_arbace_spec_gen_alpha__init_A_Unit10__O(); case 4: return A_arbace_spec_gen_alpha__init_A_Unit11__O(); case 5: return A_arbace_spec_gen_alpha__init_A_Unit12__O(); case 6: return A_arbace_spec_gen_alpha__init_A_Unit13__O(); case 7: return A_arbace_spec_gen_alpha__init_A_Unit14__O(); case 8: return A_arbace_spec_gen_alpha__init_A_Unit15__O(); case 9: return A_arbace_spec_gen_alpha__init_A_Unit16__O(); case 10: return A_arbace_spec_gen_alpha__init_A_Unit17__O(); case 11: return A_arbace_spec_gen_alpha__init_A_Unit18__O(); case 12: return A_arbace_spec_gen_alpha__init_A_Unit19__O(); case 13: return A_arbace_spec_gen_alpha__init_A_Unit2__O(); case 14: return A_arbace_spec_gen_alpha__init_A_Unit20__O(); case 15: return A_arbace_spec_gen_alpha__init_A_Unit21__O(); case 16: return A_arbace_spec_gen_alpha__init_A_Unit22__O(); case 17: return A_arbace_spec_gen_alpha__init_A_Unit23__O(); case 18: return A_arbace_spec_gen_alpha__init_A_Unit24__O(); case 19: return A_arbace_spec_gen_alpha__init_A_Unit25__O(); case 20: return A_arbace_spec_gen_alpha__init_A_Unit26__O(); case 21: return A_arbace_spec_gen_alpha__init_A_Unit27__O(); case 22: return A_arbace_spec_gen_alpha__init_A_Unit28__O(); case 23: return A_arbace_spec_gen_alpha__init_A_Unit29__O(); case 24: return A_arbace_spec_gen_alpha__init_A_Unit3__O(); case 25: return A_arbace_spec_gen_alpha__init_A_Unit30__O(); case 26: return A_arbace_spec_gen_alpha__init_A_Unit31__O(); case 27: return A_arbace_spec_gen_alpha__init_A_Unit32__O(); case 28: return A_arbace_spec_gen_alpha__init_A_Unit33__O(); case 29: return A_arbace_spec_gen_alpha__init_A_Unit34__O(); case 30: return A_arbace_spec_gen_alpha__init_A_Unit35__O(); case 31: return A_arbace_spec_gen_alpha__init_A_Unit36__O(); case 32: return A_arbace_spec_gen_alpha__init_A_Unit37__O(); case 33: return A_arbace_spec_gen_alpha__init_A_Unit38__O(); case 34: return A_arbace_spec_gen_alpha__init_A_Unit39__O(); case 35: return A_arbace_spec_gen_alpha__init_A_Unit4__O(); case 36: return A_arbace_spec_gen_alpha__init_A_Unit40__O(); case 37: return A_arbace_spec_gen_alpha__init_A_Unit41__O(); case 38: return A_arbace_spec_gen_alpha__init_A_Unit42__O(); case 39: return A_arbace_spec_gen_alpha__init_A_Unit43__O(); case 40: return A_arbace_spec_gen_alpha__init_A_Unit44__O(); case 41: return A_arbace_spec_gen_alpha__init_A_Unit45__O(); case 42: return A_arbace_spec_gen_alpha__init_A_Unit46__O(); case 43: return A_arbace_spec_gen_alpha__init_A_Unit47__O(); case 44: return A_arbace_spec_gen_alpha__init_A_Unit48__O(); case 45: return A_arbace_spec_gen_alpha__init_A_Unit49__O(); case 46: return A_arbace_spec_gen_alpha__init_A_Unit5__O(); case 47: return A_arbace_spec_gen_alpha__init_A_Unit50__O(); case 48: return A_arbace_spec_gen_alpha__init_A_Unit51__O(); case 49: return A_arbace_spec_gen_alpha__init_A_Unit52__O(); case 50: return A_arbace_spec_gen_alpha__init_A_Unit53__O(); case 51: return A_arbace_spec_gen_alpha__init_A_Unit54__O(); case 52: return A_arbace_spec_gen_alpha__init_A_Unit55__O(); case 53: return A_arbace_spec_gen_alpha__init_A_Unit56__O(); case 54: return A_arbace_spec_gen_alpha__init_A_Unit57__O(); case 55: return A_arbace_spec_gen_alpha__init_A_Unit58__O(); case 56: return A_arbace_spec_gen_alpha__init_A_Unit59__O(); case 57: return A_arbace_spec_gen_alpha__init_A_Unit6__O(); case 58: return A_arbace_spec_gen_alpha__init_A_Unit60__O(); case 59: return A_arbace_spec_gen_alpha__init_A_Unit61__O(); case 60: return A_arbace_spec_gen_alpha__init_A_Unit62__O(); case 61: return A_arbace_spec_gen_alpha__init_A_Unit63__O(); case 62: return A_arbace_spec_gen_alpha__init_A_Unit64__O(); case 63: return A_arbace_spec_gen_alpha__init_A_Unit65__O(); case 64: return A_arbace_spec_gen_alpha__init_A_Unit66__O(); case 65: return A_arbace_spec_gen_alpha__init_A_Unit67__O(); case 66: return A_arbace_spec_gen_alpha__init_A_Unit68__O(); case 67: return A_arbace_spec_gen_alpha__init_A_Unit69__O(); case 68: return A_arbace_spec_gen_alpha__init_A_Unit7__O(); case 69: return A_arbace_spec_gen_alpha__init_A_Unit70__O(); case 70: return A_arbace_spec_gen_alpha__init_A_Unit71__O(); case 71: return A_arbace_spec_gen_alpha__init_A_Unit72__O(); case 72: return A_arbace_spec_gen_alpha__init_A_Unit73__O(); case 73: return A_arbace_spec_gen_alpha__init_A_Unit74__O(); case 74: return A_arbace_spec_gen_alpha__init_A_Unit8__O(); case 75: return A_arbace_spec_gen_alpha__init_A_Unit9__O()}; return nil }

func A_arbace_spec_gen_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_gen_alpha__init_A_New()}; return nil }

var A_arbace_spec_gen_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_spec_gen_alpha__init_A_invoke, New: A_arbace_spec_gen_alpha__init_A_new}

var A_arbace_spec_gen_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.gen.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_gen_alpha__init_A_class.Info(); i.IsInstance = A_arbace_spec_gen_alpha__init_A_InstanceOf; i.Init = A_arbace_spec_gen_alpha__init_A_Init; i.Table = A_arbace_spec_gen_alpha__init_A_members; jrt.RegisterGoType(A_arbace_spec_gen_alpha__init_A_class, reflect.TypeFor[A_arbace_spec_gen_alpha__init_A]()) }
