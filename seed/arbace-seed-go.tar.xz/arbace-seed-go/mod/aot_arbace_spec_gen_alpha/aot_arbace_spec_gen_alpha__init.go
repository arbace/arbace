//line aot_arbace_spec_gen_alpha__init.ae:1
package aot_arbace_spec_gen_alpha

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_spec_gen_alpha__init_A_Load__O() any { A_arbace_spec_gen_alpha__init_A_Init(); jrt.StartCheck(); A_arbace_spec_gen_alpha__init_A_Unit0__O(); A_arbace_spec_gen_alpha__init_A_Unit1__O(); A_arbace_spec_gen_alpha__init_A_Unit2__O(); A_arbace_spec_gen_alpha__init_A_Unit3__O(); A_arbace_spec_gen_alpha__init_A_Unit4__O(); A_arbace_spec_gen_alpha__init_A_Unit5__O(); A_arbace_spec_gen_alpha__init_A_Unit6__O(); A_arbace_spec_gen_alpha__init_A_Unit7__O(); A_arbace_spec_gen_alpha__init_A_Unit8__O(); A_arbace_spec_gen_alpha__init_A_Unit9__O(); A_arbace_spec_gen_alpha__init_A_Unit10__O(); A_arbace_spec_gen_alpha__init_A_Unit11__O(); A_arbace_spec_gen_alpha__init_A_Unit12__O(); A_arbace_spec_gen_alpha__init_A_Unit13__O(); A_arbace_spec_gen_alpha__init_A_Unit14__O(); A_arbace_spec_gen_alpha__init_A_Unit15__O(); A_arbace_spec_gen_alpha__init_A_Unit16__O(); A_arbace_spec_gen_alpha__init_A_Unit17__O(); A_arbace_spec_gen_alpha__init_A_Unit18__O(); A_arbace_spec_gen_alpha__init_A_Unit19__O(); A_arbace_spec_gen_alpha__init_A_Unit20__O(); A_arbace_spec_gen_alpha__init_A_Unit21__O(); A_arbace_spec_gen_alpha__init_A_Unit22__O(); A_arbace_spec_gen_alpha__init_A_Unit23__O(); A_arbace_spec_gen_alpha__init_A_Unit24__O(); A_arbace_spec_gen_alpha__init_A_Unit25__O(); A_arbace_spec_gen_alpha__init_A_Unit26__O(); A_arbace_spec_gen_alpha__init_A_Unit27__O(); A_arbace_spec_gen_alpha__init_A_Unit28__O(); A_arbace_spec_gen_alpha__init_A_Unit29__O(); A_arbace_spec_gen_alpha__init_A_Unit30__O(); A_arbace_spec_gen_alpha__init_A_Unit31__O(); A_arbace_spec_gen_alpha__init_A_Unit32__O(); A_arbace_spec_gen_alpha__init_A_Unit33__O(); A_arbace_spec_gen_alpha__init_A_Unit34__O(); A_arbace_spec_gen_alpha__init_A_Unit35__O(); A_arbace_spec_gen_alpha__init_A_Unit36__O(); A_arbace_spec_gen_alpha__init_A_Unit37__O(); A_arbace_spec_gen_alpha__init_A_Unit38__O(); A_arbace_spec_gen_alpha__init_A_Unit39__O(); A_arbace_spec_gen_alpha__init_A_Unit40__O(); A_arbace_spec_gen_alpha__init_A_Unit41__O(); A_arbace_spec_gen_alpha__init_A_Unit42__O(); A_arbace_spec_gen_alpha__init_A_Unit43__O(); A_arbace_spec_gen_alpha__init_A_Unit44__O(); A_arbace_spec_gen_alpha__init_A_Unit45__O(); A_arbace_spec_gen_alpha__init_A_Unit46__O(); A_arbace_spec_gen_alpha__init_A_Unit47__O(); A_arbace_spec_gen_alpha__init_A_Unit48__O(); A_arbace_spec_gen_alpha__init_A_Unit49__O(); A_arbace_spec_gen_alpha__init_A_Unit50__O(); A_arbace_spec_gen_alpha__init_A_Unit51__O(); A_arbace_spec_gen_alpha__init_A_Unit52__O(); A_arbace_spec_gen_alpha__init_A_Unit53__O(); A_arbace_spec_gen_alpha__init_A_Unit54__O(); A_arbace_spec_gen_alpha__init_A_Unit55__O(); A_arbace_spec_gen_alpha__init_A_Unit56__O(); A_arbace_spec_gen_alpha__init_A_Unit57__O(); A_arbace_spec_gen_alpha__init_A_Unit58__O(); A_arbace_spec_gen_alpha__init_A_Unit59__O(); A_arbace_spec_gen_alpha__init_A_Unit60__O(); A_arbace_spec_gen_alpha__init_A_Unit61__O(); A_arbace_spec_gen_alpha__init_A_Unit62__O(); A_arbace_spec_gen_alpha__init_A_Unit63__O(); A_arbace_spec_gen_alpha__init_A_Unit64__O(); A_arbace_spec_gen_alpha__init_A_Unit65__O(); A_arbace_spec_gen_alpha__init_A_Unit66__O(); A_arbace_spec_gen_alpha__init_A_Unit67__O(); A_arbace_spec_gen_alpha__init_A_Unit68__O(); A_arbace_spec_gen_alpha__init_A_Unit69__O(); A_arbace_spec_gen_alpha__init_A_Unit70__O(); A_arbace_spec_gen_alpha__init_A_Unit71__O(); A_arbace_spec_gen_alpha__init_A_Unit72__O(); A_arbace_spec_gen_alpha__init_A_Unit73__O(); A_arbace_spec_gen_alpha__init_A_Unit74__O(); return nil }







func A_arbace_spec_gen_alpha__init_A_Unit0__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return lang.IFn_Cast(A_arbace_spec_gen_alpha__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha__init_A_const_1) }
//line :13:1
func A_arbace_spec_gen_alpha__init_A_Unit1__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 any = A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :13:1
func A_arbace_spec_gen_alpha__init_A_Unit2__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_spec_gen_alpha__init_A_const_1)).Equals_O__Z(A_arbace_spec_gen_alpha__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_spec_gen_alpha__init_A_Unit3__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var root_3 any = A_arbace_spec_gen_alpha__init_A_const_3.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_alias_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = A_arbace_spec_gen_alpha__init_A_const_4; var arg_7 any = A_arbace_spec_gen_alpha__init_A_const_5; if linked_4 == nil { return ifn_5.Invoke_O_O__O(arg_6, arg_7) } else { return linked_4.(*aot_arbace_core.A_arbace_core_alias_A).Invoke_O_O_O__O(root_3, arg_6, arg_7) } }

func A_arbace_spec_gen_alpha__init_A_Unit4__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_7)); v__1927001498__auto____1 = A_arbace_spec_gen_alpha__init_A_const_6; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_6; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_8)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_6; tmp3.BindRoot_O__V(jrt.Object_New()); return A_arbace_spec_gen_alpha__init_A_const_6 } }

func A_arbace_spec_gen_alpha__init_A_Unit5__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_9; var tmp2 any = A_arbace_spec_gen_alpha_dynaload_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_spec_gen_alpha_dynaload_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_spec_gen_alpha_dynaload_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_10)); return A_arbace_spec_gen_alpha__init_A_const_9 }










func A_arbace_spec_gen_alpha__init_A_Unit6__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_11; var tmp2 any = A_arbace_spec_gen_alpha_fn__1067000017_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class; if
							fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; /*line :34:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_12)); return A_arbace_spec_gen_alpha__init_A_const_11 }

func A_arbace_spec_gen_alpha__init_A_Unit7__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_13; var tmp2 any = A_arbace_spec_gen_alpha_quick_check_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_spec_gen_alpha_quick_check_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, true); A_arbace_spec_gen_alpha_quick_check_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_14)); return A_arbace_spec_gen_alpha__init_A_const_13 }



func A_arbace_spec_gen_alpha__init_A_Unit8__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_15; var tmp2 any = A_arbace_spec_gen_alpha_fn__1067000020_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class; if
							fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; /*line :40:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_16)); return A_arbace_spec_gen_alpha__init_A_const_15 }

func A_arbace_spec_gen_alpha__init_A_Unit9__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_17; var tmp2 any = A_arbace_spec_gen_alpha_for_all_STAR__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_18)); return A_arbace_spec_gen_alpha__init_A_const_17 }




func A_arbace_spec_gen_alpha__init_A_Unit10__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var g_QMARK___1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_New(); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; g_QMARK___1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var g__2 any; var tmp3 any = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_New(); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class; if
							fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; g__2 = /*line :47:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var mkg__3 any; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_New(); var tmp6 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class; if

	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class = fncls__15d; tmp6 = fncls__15d } else { tmp6 = fncls__15 }; mkg__3 = /*line :47:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp7 /*line :50:1*/*lang.Var = A_arbace_spec_gen_alpha__init_A_const_21; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_22)); var tmp8 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_21; var tmp9 any = A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_New_O(g_QMARK___1); var tmp10 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class = fncls__17d; tmp10 = fncls__17d } else { tmp10 = fncls__17 }; tmp8.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); var tmp11 /*line :53:1*/*lang.Var = A_arbace_spec_gen_alpha__init_A_const_23; tmp11.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_24)); var tmp12 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_23; var tmp13 any = A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_New_O(mkg__3); var tmp14 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class = fncls__18d; tmp14 = fncls__18d } else { tmp14 = fncls__18 }; tmp12.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp15 /*line :56:1*/*lang.Var = A_arbace_spec_gen_alpha__init_A_const_19; tmp15.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_20)); var tmp16 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_19; var tmp17 any = A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_New_O(g__2); var tmp18 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class = fncls__16d; tmp18 = fncls__16d } else { tmp18 = fncls__16 }; tmp16.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); return A_arbace_spec_gen_alpha__init_A_const_19 }




func A_arbace_spec_gen_alpha__init_A_Unit11__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_25; var tmp2 any = A_arbace_spec_gen_alpha_delay_impl_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_spec_gen_alpha_delay_impl_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_spec_gen_alpha_delay_impl_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_26)); return A_arbace_spec_gen_alpha__init_A_const_25 }





func A_arbace_spec_gen_alpha__init_A_Unit12__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_27; var tmp2 any = A_arbace_spec_gen_alpha_delay_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_spec_gen_alpha_delay_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, true); A_arbace_spec_gen_alpha_delay_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_28)); return A_arbace_spec_gen_alpha__init_A_const_27 }
//line :67:1
func A_arbace_spec_gen_alpha__init_A_Unit13__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); A_arbace_spec_gen_alpha__init_A_const_27.SetMacro__V(); return nil }
//line :67:1
func A_arbace_spec_gen_alpha__init_A_Unit14__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); return A_arbace_spec_gen_alpha__init_A_const_27 }






func A_arbace_spec_gen_alpha__init_A_Unit15__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_29; var tmp2 any = A_arbace_spec_gen_alpha_gen_for_name_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_spec_gen_alpha_gen_for_name_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_spec_gen_alpha_gen_for_name_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_30)); return A_arbace_spec_gen_alpha__init_A_const_29 }







func A_arbace_spec_gen_alpha__init_A_Unit16__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_31; var tmp2 any = A_arbace_spec_gen_alpha_lazy_combinator_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_32)); return A_arbace_spec_gen_alpha__init_A_const_31 }
//line :82:1
func A_arbace_spec_gen_alpha__init_A_Unit17__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); A_arbace_spec_gen_alpha__init_A_const_31.SetMacro__V(); return nil }
//line :82:1
func A_arbace_spec_gen_alpha__init_A_Unit18__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); return A_arbace_spec_gen_alpha__init_A_const_31 }










func A_arbace_spec_gen_alpha__init_A_Unit19__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_33; var tmp2 any = A_arbace_spec_gen_alpha_lazy_combinators_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, true); A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_34)); return A_arbace_spec_gen_alpha__init_A_const_33 }
//line :93:1
func A_arbace_spec_gen_alpha__init_A_Unit20__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); A_arbace_spec_gen_alpha__init_A_const_33.SetMacro__V(); return nil }
//line :93:1
func A_arbace_spec_gen_alpha__init_A_Unit21__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); return A_arbace_spec_gen_alpha__init_A_const_33 }







func A_arbace_spec_gen_alpha__init_A_Unit22__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_New(); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_35; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_36)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_35; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, true); A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class = fncls__25d; tmp6 = fncls__25d } else { tmp6 = fncls__25 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_35 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit23__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_New(); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_37; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_38)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_37; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, true); A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class = fncls__27d; tmp6 = fncls__27d } else { tmp6 = fncls__27 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_37 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit24__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_New(); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_39; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_40)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_39; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, true); A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class = fncls__29d; tmp6 = fncls__29d } else { tmp6 = fncls__29 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_39 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit25__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_41; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_42)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_41; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, true); A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class = fncls__31d; tmp6 = fncls__31d } else { tmp6 = fncls__31 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_41 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit26__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_New(); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_43; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_44)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_43; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, true); A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class = fncls__33d; tmp6 = fncls__33d } else { tmp6 = fncls__33 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_43 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit27__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_New(); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_45; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_46)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_45; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, true); A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class = fncls__35d; tmp6 = fncls__35d } else { tmp6 = fncls__35 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_45 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit28__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_New(); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_47; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_48)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_47; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, true); A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class = fncls__37d; tmp6 = fncls__37d } else { tmp6 = fncls__37 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_47 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit29__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_New(); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_49; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_50)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_49; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, true); A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class = fncls__39d; tmp6 = fncls__39d } else { tmp6 = fncls__39 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_49 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit30__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_New(); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_51; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_52)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_51; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, true); A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class = fncls__41d; tmp6 = fncls__41d } else { tmp6 = fncls__41 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_51 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit31__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_New(); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_53; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_54)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_53; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, true); A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class = fncls__43d; tmp6 = fncls__43d } else { tmp6 = fncls__43 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_53 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit32__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_New(); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_55; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_56)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_55; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, true); A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class = fncls__45d; tmp6 = fncls__45d } else { tmp6 = fncls__45 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_55 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit33__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_New(); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_57; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_58)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_57; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, true); A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class = fncls__47d; tmp6 = fncls__47d } else { tmp6 = fncls__47 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_57 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit34__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_New(); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_59; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_60)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_59; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, true); A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class = fncls__49d; tmp6 = fncls__49d } else { tmp6 = fncls__49 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_59 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit35__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_New(); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_61; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_62)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_61; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, true); A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class = fncls__51d; tmp6 = fncls__51d } else { tmp6 = fncls__51 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_61 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit36__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_New(); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_63; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_64)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_63; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, true); A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class = fncls__53d; tmp6 = fncls__53d } else { tmp6 = fncls__53 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_63 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit37__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_New(); var tmp2 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class = fncls__54d; tmp2 = fncls__54d } else { tmp2 = fncls__54 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_65; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_66)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_65; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, true); A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class = fncls__55d; tmp6 = fncls__55d } else { tmp6 = fncls__55 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_65 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit38__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_New(); var tmp2 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class = fncls__56d; tmp2 = fncls__56d } else { tmp2 = fncls__56 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_67; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_68)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_67; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, true); A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class = fncls__57d; tmp6 = fncls__57d } else { tmp6 = fncls__57 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_67 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit39__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_New(); var tmp2 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class = fncls__58d; tmp2 = fncls__58d } else { tmp2 = fncls__58 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_69; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_70)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_69; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, true); A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class = fncls__59d; tmp6 = fncls__59d } else { tmp6 = fncls__59 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_69 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit40__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_New(); var tmp2 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class = fncls__60d; tmp2 = fncls__60d } else { tmp2 = fncls__60 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_71; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_72)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_71; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, true); A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class = fncls__61d; tmp6 = fncls__61d } else { tmp6 = fncls__61 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_71 }
//line :101:1
func A_arbace_spec_gen_alpha__init_A_Unit41__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var g__1067000046__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_New(); var tmp2 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class = fncls__62d; tmp2 = fncls__62d } else { tmp2 = fncls__62 }; g__1067000046__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_73; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_74)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_73; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_New_O(g__1067000046__auto____1); var tmp6 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, true); A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class = fncls__63d; tmp6 = fncls__63d } else { tmp6 = fncls__63 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_73 }



func A_arbace_spec_gen_alpha__init_A_Unit42__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_75; var tmp2 any = A_arbace_spec_gen_alpha_lazy_prim_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_spec_gen_alpha_lazy_prim_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_spec_gen_alpha_lazy_prim_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_76)); return A_arbace_spec_gen_alpha__init_A_const_75 }
//line :105:1
func A_arbace_spec_gen_alpha__init_A_Unit43__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); A_arbace_spec_gen_alpha__init_A_const_75.SetMacro__V(); return nil }
//line :105:1
func A_arbace_spec_gen_alpha__init_A_Unit44__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); return A_arbace_spec_gen_alpha__init_A_const_75 }










func A_arbace_spec_gen_alpha__init_A_Unit45__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_77; var tmp2 any = A_arbace_spec_gen_alpha_lazy_prims_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_spec_gen_alpha_lazy_prims_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, true); A_arbace_spec_gen_alpha_lazy_prims_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_78)); return A_arbace_spec_gen_alpha__init_A_const_77 }
//line :116:1
func A_arbace_spec_gen_alpha__init_A_Unit46__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); A_arbace_spec_gen_alpha__init_A_const_77.SetMacro__V(); return nil }
//line :116:1
func A_arbace_spec_gen_alpha__init_A_Unit47__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); return A_arbace_spec_gen_alpha__init_A_const_77 }







func A_arbace_spec_gen_alpha__init_A_Unit48__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_New(); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_79; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_80)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_79; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, true); A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class = fncls__67d; tmp6 = fncls__67d } else { tmp6 = fncls__67 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_79 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit49__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_New(); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_81; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_82)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_81; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, true); A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class = fncls__69d; tmp6 = fncls__69d } else { tmp6 = fncls__69 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_81 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit50__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_New(); var tmp2 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class = fncls__70d; tmp2 = fncls__70d } else { tmp2 = fncls__70 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_83; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_84)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_83; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, true); A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class = fncls__71d; tmp6 = fncls__71d } else { tmp6 = fncls__71 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_83 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit51__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_New(); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_85; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_86)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_85; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, true); A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class = fncls__73d; tmp6 = fncls__73d } else { tmp6 = fncls__73 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_85 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit52__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_New(); var tmp2 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class = fncls__74d; tmp2 = fncls__74d } else { tmp2 = fncls__74 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_87; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_88)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_87; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, true); A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class = fncls__75d; tmp6 = fncls__75d } else { tmp6 = fncls__75 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_87 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit53__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_New(); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_89; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_90)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_89; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, true); A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class = fncls__77d; tmp6 = fncls__77d } else { tmp6 = fncls__77 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_89 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit54__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_New(); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_91; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_92)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_91; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, true); A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class = fncls__79d; tmp6 = fncls__79d } else { tmp6 = fncls__79 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_91 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit55__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_New(); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_93; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_94)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_93; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, true); A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class = fncls__81d; tmp6 = fncls__81d } else { tmp6 = fncls__81 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_93 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit56__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_New(); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_95; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_96)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_95; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, true); A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class = fncls__83d; tmp6 = fncls__83d } else { tmp6 = fncls__83 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_95 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit57__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_New(); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_97; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_98)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_97; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, true); A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class = fncls__85d; tmp6 = fncls__85d } else { tmp6 = fncls__85 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_97 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit58__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_New(); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_99; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_100)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_99; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, true); A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class = fncls__87d; tmp6 = fncls__87d } else { tmp6 = fncls__87 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_99 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit59__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_New(); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_101; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_102)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_101; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, true); A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class = fncls__89d; tmp6 = fncls__89d } else { tmp6 = fncls__89 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_101 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit60__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_New(); var tmp2 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_103; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_104)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_103; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, true); A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class = fncls__91d; tmp6 = fncls__91d } else { tmp6 = fncls__91 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_103 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit61__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_New(); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_105; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_106)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_105; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, true); A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class = fncls__93d; tmp6 = fncls__93d } else { tmp6 = fncls__93 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_105 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit62__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_New(); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_107; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_108)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_107; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, true); A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class = fncls__95d; tmp6 = fncls__95d } else { tmp6 = fncls__95 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_107 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit63__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_New(); var tmp2 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class = fncls__96d; tmp2 = fncls__96d } else { tmp2 = fncls__96 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_109; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_110)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_109; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, true); A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class = fncls__97d; tmp6 = fncls__97d } else { tmp6 = fncls__97 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_109 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit64__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_New(); var tmp2 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class = fncls__98d; tmp2 = fncls__98d } else { tmp2 = fncls__98 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_111; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_112)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_111; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, true); A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class = fncls__99d; tmp6 = fncls__99d } else { tmp6 = fncls__99 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_111 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit65__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_New(); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_113; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_114)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_113; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, true); A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class = fncls__101d; tmp6 = fncls__101d } else { tmp6 = fncls__101 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_113 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit66__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_New(); var tmp2 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class = fncls__102d; tmp2 = fncls__102d } else { tmp2 = fncls__102 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_115; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_116)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_115; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, true); A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class = fncls__103d; tmp6 = fncls__103d } else { tmp6 = fncls__103 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_115 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit67__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_New(); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_117; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_118)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_117; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, true); A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class = fncls__105d; tmp6 = fncls__105d } else { tmp6 = fncls__105 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_117 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit68__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_New(); var tmp2 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class = fncls__106d; tmp2 = fncls__106d } else { tmp2 = fncls__106 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_119; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_120)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_119; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, true); A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class = fncls__107d; tmp6 = fncls__107d } else { tmp6 = fncls__107 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_119 }
//line :124:1
func A_arbace_spec_gen_alpha__init_A_Unit69__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var g__1067000179__auto____1 any; var tmp1 any = A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_New(); var tmp2 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class = fncls__108d; tmp2 = fncls__108d } else { tmp2 = fncls__108 }; g__1067000179__auto____1 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var tmp3 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_121; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_122)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_121; var tmp5 any = A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_New_O(g__1067000179__auto____1); var tmp6 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, true); A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class = fncls__109d; tmp6 = fncls__109d } else { tmp6 = fncls__109 }; tmp4.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp5, tmp6, nil, 0)); return A_arbace_spec_gen_alpha__init_A_const_121 }



func A_arbace_spec_gen_alpha__init_A_Unit70__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_123; var tmp2 any = A_arbace_spec_gen_alpha_cat_A_New(); var tmp3 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_spec_gen_alpha_cat_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, true); A_arbace_spec_gen_alpha_cat_A_fn_class = fncls__110d; tmp3 = fncls__110d } else { tmp3 = fncls__110 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_124)); return A_arbace_spec_gen_alpha__init_A_const_123 }






func A_arbace_spec_gen_alpha__init_A_Unit71__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_125; var tmp2 any = A_arbace_spec_gen_alpha_qualified_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_126)); return A_arbace_spec_gen_alpha__init_A_const_125 }

func A_arbace_spec_gen_alpha__init_A_Unit72__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_127; var tmp2 any = A_arbace_spec_gen_alpha_fn__1067000332_A_New(); var tmp3 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class; if

	fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class = fncls__112d; tmp3 = fncls__112d } else { tmp3 = fncls__112 }; /*line :137:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_128)); return A_arbace_spec_gen_alpha__init_A_const_127 }


























































func A_arbace_spec_gen_alpha__init_A_Unit73__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_129; var tmp2 any = A_arbace_spec_gen_alpha_gen_for_pred_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_gen_alpha__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_gen_alpha__init_A_const_130)); return A_arbace_spec_gen_alpha__init_A_const_129 }






func A_arbace_spec_gen_alpha__init_A_Unit74__O() any { A_arbace_spec_gen_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); return nil }





type A_arbace_spec_gen_alpha__init_A struct{ jrt.Object }

var A_arbace_spec_gen_alpha__init_A_const_pool *jrt.RefArray

var A_arbace_spec_gen_alpha__init_A_const_0 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_1 any

var A_arbace_spec_gen_alpha__init_A_const_2 any

var A_arbace_spec_gen_alpha__init_A_const_3 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_4 any

var A_arbace_spec_gen_alpha__init_A_const_5 any

var A_arbace_spec_gen_alpha__init_A_const_6 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_7 any

var A_arbace_spec_gen_alpha__init_A_const_8 any

var A_arbace_spec_gen_alpha__init_A_const_9 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_10 any

var A_arbace_spec_gen_alpha__init_A_const_11 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_12 any

var A_arbace_spec_gen_alpha__init_A_const_13 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_14 any

var A_arbace_spec_gen_alpha__init_A_const_15 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_16 any

var A_arbace_spec_gen_alpha__init_A_const_17 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_18 any

var A_arbace_spec_gen_alpha__init_A_const_19 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_20 any

var A_arbace_spec_gen_alpha__init_A_const_21 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_22 any

var A_arbace_spec_gen_alpha__init_A_const_23 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_24 any

var A_arbace_spec_gen_alpha__init_A_const_25 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_26 any

var A_arbace_spec_gen_alpha__init_A_const_27 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_28 any

var A_arbace_spec_gen_alpha__init_A_const_29 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_30 any

var A_arbace_spec_gen_alpha__init_A_const_31 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_32 any

var A_arbace_spec_gen_alpha__init_A_const_33 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_34 any

var A_arbace_spec_gen_alpha__init_A_const_35 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_36 any

var A_arbace_spec_gen_alpha__init_A_const_37 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_38 any

var A_arbace_spec_gen_alpha__init_A_const_39 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_40 any

var A_arbace_spec_gen_alpha__init_A_const_41 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_42 any

var A_arbace_spec_gen_alpha__init_A_const_43 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_44 any

var A_arbace_spec_gen_alpha__init_A_const_45 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_46 any

var A_arbace_spec_gen_alpha__init_A_const_47 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_48 any

var A_arbace_spec_gen_alpha__init_A_const_49 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_50 any

var A_arbace_spec_gen_alpha__init_A_const_51 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_52 any

var A_arbace_spec_gen_alpha__init_A_const_53 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_54 any

var A_arbace_spec_gen_alpha__init_A_const_55 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_56 any

var A_arbace_spec_gen_alpha__init_A_const_57 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_58 any

var A_arbace_spec_gen_alpha__init_A_const_59 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_60 any

var A_arbace_spec_gen_alpha__init_A_const_61 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_62 any

var A_arbace_spec_gen_alpha__init_A_const_63 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_64 any

var A_arbace_spec_gen_alpha__init_A_const_65 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_66 any

var A_arbace_spec_gen_alpha__init_A_const_67 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_68 any

var A_arbace_spec_gen_alpha__init_A_const_69 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_70 any

var A_arbace_spec_gen_alpha__init_A_const_71 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_72 any

var A_arbace_spec_gen_alpha__init_A_const_73 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_74 any

var A_arbace_spec_gen_alpha__init_A_const_75 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_76 any

var A_arbace_spec_gen_alpha__init_A_const_77 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_78 any

var A_arbace_spec_gen_alpha__init_A_const_79 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_80 any

var A_arbace_spec_gen_alpha__init_A_const_81 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_82 any

var A_arbace_spec_gen_alpha__init_A_const_83 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_84 any

var A_arbace_spec_gen_alpha__init_A_const_85 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_86 any

var A_arbace_spec_gen_alpha__init_A_const_87 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_88 any

var A_arbace_spec_gen_alpha__init_A_const_89 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_90 any

var A_arbace_spec_gen_alpha__init_A_const_91 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_92 any

var A_arbace_spec_gen_alpha__init_A_const_93 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_94 any

var A_arbace_spec_gen_alpha__init_A_const_95 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_96 any

var A_arbace_spec_gen_alpha__init_A_const_97 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_98 any

var A_arbace_spec_gen_alpha__init_A_const_99 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_100 any

var A_arbace_spec_gen_alpha__init_A_const_101 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_102 any

var A_arbace_spec_gen_alpha__init_A_const_103 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_104 any

var A_arbace_spec_gen_alpha__init_A_const_105 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_106 any

var A_arbace_spec_gen_alpha__init_A_const_107 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_108 any

var A_arbace_spec_gen_alpha__init_A_const_109 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_110 any

var A_arbace_spec_gen_alpha__init_A_const_111 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_112 any

var A_arbace_spec_gen_alpha__init_A_const_113 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_114 any

var A_arbace_spec_gen_alpha__init_A_const_115 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_116 any

var A_arbace_spec_gen_alpha__init_A_const_117 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_118 any

var A_arbace_spec_gen_alpha__init_A_const_119 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_120 any

var A_arbace_spec_gen_alpha__init_A_const_121 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_122 any

var A_arbace_spec_gen_alpha__init_A_const_123 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_124 any

var A_arbace_spec_gen_alpha__init_A_const_125 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_126 any

var A_arbace_spec_gen_alpha__init_A_const_127 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_128 any

var A_arbace_spec_gen_alpha__init_A_const_129 *lang.Var

var A_arbace_spec_gen_alpha__init_A_const_130 any

var A_arbace_spec_gen_alpha__init_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha__init_A_Init() { if !A_arbace_spec_gen_alpha__init_A_init.Done() { A_arbace_spec_gen_alpha__init_A_init.Run(A_arbace_spec_gen_alpha__init_A_clinit) } }

func A_arbace_spec_gen_alpha__init_A_clinit() { A_arbace_spec_gen_alpha__init_A_clinit_p0(); A_arbace_spec_gen_alpha__init_A_clinit_p1(); A_arbace_spec_gen_alpha__init_A_clinit_p2(); A_arbace_spec_gen_alpha__init_A_clinit_p3(); A_arbace_spec_gen_alpha__init_A_clinit_p4(); A_arbace_spec_gen_alpha__init_A_clinit_p5(); A_arbace_spec_gen_alpha__init_A_clinit_p6(); A_arbace_spec_gen_alpha__init_A_clinit_p7(); A_arbace_spec_gen_alpha__init_A_clinit_p8(); A_arbace_spec_gen_alpha__init_A_clinit_p9(); A_arbace_spec_gen_alpha__init_A_clinit_p10() }

func A_arbace_spec_gen_alpha__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_gen_alpha__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_19, 153); A_arbace_spec_gen_alpha__init_A_const_0 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[22]); A_arbace_spec_gen_alpha__init_A_const_1 = A_arbace_spec_gen_alpha__init_A_const_pool.A[23]; A_arbace_spec_gen_alpha__init_A_const_2 = A_arbace_spec_gen_alpha__init_A_const_pool.A[24]; A_arbace_spec_gen_alpha__init_A_const_3 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[25]); A_arbace_spec_gen_alpha__init_A_const_4 = A_arbace_spec_gen_alpha__init_A_const_pool.A[26]; A_arbace_spec_gen_alpha__init_A_const_5 = A_arbace_spec_gen_alpha__init_A_const_pool.A[27]; A_arbace_spec_gen_alpha__init_A_const_6 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[28]); A_arbace_spec_gen_alpha__init_A_const_7 = A_arbace_spec_gen_alpha__init_A_const_pool.A[29]; A_arbace_spec_gen_alpha__init_A_const_8 = A_arbace_spec_gen_alpha__init_A_const_pool.A[30]; A_arbace_spec_gen_alpha__init_A_const_9 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[31]); A_arbace_spec_gen_alpha__init_A_const_10 = A_arbace_spec_gen_alpha__init_A_const_pool.A[32]; A_arbace_spec_gen_alpha__init_A_const_11 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[33]); A_arbace_spec_gen_alpha__init_A_const_12 = A_arbace_spec_gen_alpha__init_A_const_pool.A[34] }

func A_arbace_spec_gen_alpha__init_A_clinit_p1() { A_arbace_spec_gen_alpha__init_A_const_13 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[35]); A_arbace_spec_gen_alpha__init_A_const_14 = A_arbace_spec_gen_alpha__init_A_const_pool.A[36]; A_arbace_spec_gen_alpha__init_A_const_15 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[37]); A_arbace_spec_gen_alpha__init_A_const_16 = A_arbace_spec_gen_alpha__init_A_const_pool.A[38]; A_arbace_spec_gen_alpha__init_A_const_17 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[39]); A_arbace_spec_gen_alpha__init_A_const_18 = A_arbace_spec_gen_alpha__init_A_const_pool.A[40]; A_arbace_spec_gen_alpha__init_A_const_19 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[41]); A_arbace_spec_gen_alpha__init_A_const_20 = A_arbace_spec_gen_alpha__init_A_const_pool.A[42]; A_arbace_spec_gen_alpha__init_A_const_21 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[43]); A_arbace_spec_gen_alpha__init_A_const_22 = A_arbace_spec_gen_alpha__init_A_const_pool.A[44]; A_arbace_spec_gen_alpha__init_A_const_23 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[45]); A_arbace_spec_gen_alpha__init_A_const_24 = A_arbace_spec_gen_alpha__init_A_const_pool.A[46]; A_arbace_spec_gen_alpha__init_A_const_25 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[47]) }

func A_arbace_spec_gen_alpha__init_A_clinit_p2() { A_arbace_spec_gen_alpha__init_A_const_26 = A_arbace_spec_gen_alpha__init_A_const_pool.A[48]; A_arbace_spec_gen_alpha__init_A_const_27 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[49]); A_arbace_spec_gen_alpha__init_A_const_28 = A_arbace_spec_gen_alpha__init_A_const_pool.A[50]; A_arbace_spec_gen_alpha__init_A_const_29 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[51]); A_arbace_spec_gen_alpha__init_A_const_30 = A_arbace_spec_gen_alpha__init_A_const_pool.A[52]; A_arbace_spec_gen_alpha__init_A_const_31 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[53]); A_arbace_spec_gen_alpha__init_A_const_32 = A_arbace_spec_gen_alpha__init_A_const_pool.A[54]; A_arbace_spec_gen_alpha__init_A_const_33 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[55]); A_arbace_spec_gen_alpha__init_A_const_34 = A_arbace_spec_gen_alpha__init_A_const_pool.A[56]; A_arbace_spec_gen_alpha__init_A_const_35 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[57]); A_arbace_spec_gen_alpha__init_A_const_36 = A_arbace_spec_gen_alpha__init_A_const_pool.A[58]; A_arbace_spec_gen_alpha__init_A_const_37 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[59]); A_arbace_spec_gen_alpha__init_A_const_38 = A_arbace_spec_gen_alpha__init_A_const_pool.A[60] }

func A_arbace_spec_gen_alpha__init_A_clinit_p3() { A_arbace_spec_gen_alpha__init_A_const_39 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[61]); A_arbace_spec_gen_alpha__init_A_const_40 = A_arbace_spec_gen_alpha__init_A_const_pool.A[62]; A_arbace_spec_gen_alpha__init_A_const_41 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[63]); A_arbace_spec_gen_alpha__init_A_const_42 = A_arbace_spec_gen_alpha__init_A_const_pool.A[64]; A_arbace_spec_gen_alpha__init_A_const_43 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[65]); A_arbace_spec_gen_alpha__init_A_const_44 = A_arbace_spec_gen_alpha__init_A_const_pool.A[66]; A_arbace_spec_gen_alpha__init_A_const_45 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[67]); A_arbace_spec_gen_alpha__init_A_const_46 = A_arbace_spec_gen_alpha__init_A_const_pool.A[68]; A_arbace_spec_gen_alpha__init_A_const_47 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[69]); A_arbace_spec_gen_alpha__init_A_const_48 = A_arbace_spec_gen_alpha__init_A_const_pool.A[70]; A_arbace_spec_gen_alpha__init_A_const_49 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[71]); A_arbace_spec_gen_alpha__init_A_const_50 = A_arbace_spec_gen_alpha__init_A_const_pool.A[72]; A_arbace_spec_gen_alpha__init_A_const_51 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[73]) }

func A_arbace_spec_gen_alpha__init_A_clinit_p4() { A_arbace_spec_gen_alpha__init_A_const_52 = A_arbace_spec_gen_alpha__init_A_const_pool.A[74]; A_arbace_spec_gen_alpha__init_A_const_53 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[75]); A_arbace_spec_gen_alpha__init_A_const_54 = A_arbace_spec_gen_alpha__init_A_const_pool.A[76]; A_arbace_spec_gen_alpha__init_A_const_55 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[77]); A_arbace_spec_gen_alpha__init_A_const_56 = A_arbace_spec_gen_alpha__init_A_const_pool.A[78]; A_arbace_spec_gen_alpha__init_A_const_57 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[79]); A_arbace_spec_gen_alpha__init_A_const_58 = A_arbace_spec_gen_alpha__init_A_const_pool.A[80]; A_arbace_spec_gen_alpha__init_A_const_59 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[81]); A_arbace_spec_gen_alpha__init_A_const_60 = A_arbace_spec_gen_alpha__init_A_const_pool.A[82]; A_arbace_spec_gen_alpha__init_A_const_61 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[83]); A_arbace_spec_gen_alpha__init_A_const_62 = A_arbace_spec_gen_alpha__init_A_const_pool.A[84]; A_arbace_spec_gen_alpha__init_A_const_63 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[85]); A_arbace_spec_gen_alpha__init_A_const_64 = A_arbace_spec_gen_alpha__init_A_const_pool.A[86] }

func A_arbace_spec_gen_alpha__init_A_clinit_p5() { A_arbace_spec_gen_alpha__init_A_const_65 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[87]); A_arbace_spec_gen_alpha__init_A_const_66 = A_arbace_spec_gen_alpha__init_A_const_pool.A[88]; A_arbace_spec_gen_alpha__init_A_const_67 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[89]); A_arbace_spec_gen_alpha__init_A_const_68 = A_arbace_spec_gen_alpha__init_A_const_pool.A[90]; A_arbace_spec_gen_alpha__init_A_const_69 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[91]); A_arbace_spec_gen_alpha__init_A_const_70 = A_arbace_spec_gen_alpha__init_A_const_pool.A[92]; A_arbace_spec_gen_alpha__init_A_const_71 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[93]); A_arbace_spec_gen_alpha__init_A_const_72 = A_arbace_spec_gen_alpha__init_A_const_pool.A[94]; A_arbace_spec_gen_alpha__init_A_const_73 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[95]); A_arbace_spec_gen_alpha__init_A_const_74 = A_arbace_spec_gen_alpha__init_A_const_pool.A[96]; A_arbace_spec_gen_alpha__init_A_const_75 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[97]); A_arbace_spec_gen_alpha__init_A_const_76 = A_arbace_spec_gen_alpha__init_A_const_pool.A[98]; A_arbace_spec_gen_alpha__init_A_const_77 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[99]) }

func A_arbace_spec_gen_alpha__init_A_clinit_p6() { A_arbace_spec_gen_alpha__init_A_const_78 = A_arbace_spec_gen_alpha__init_A_const_pool.A[100]; A_arbace_spec_gen_alpha__init_A_const_79 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[101]); A_arbace_spec_gen_alpha__init_A_const_80 = A_arbace_spec_gen_alpha__init_A_const_pool.A[102]; A_arbace_spec_gen_alpha__init_A_const_81 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[103]); A_arbace_spec_gen_alpha__init_A_const_82 = A_arbace_spec_gen_alpha__init_A_const_pool.A[104]; A_arbace_spec_gen_alpha__init_A_const_83 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[105]); A_arbace_spec_gen_alpha__init_A_const_84 = A_arbace_spec_gen_alpha__init_A_const_pool.A[106]; A_arbace_spec_gen_alpha__init_A_const_85 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[107]); A_arbace_spec_gen_alpha__init_A_const_86 = A_arbace_spec_gen_alpha__init_A_const_pool.A[108]; A_arbace_spec_gen_alpha__init_A_const_87 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[109]); A_arbace_spec_gen_alpha__init_A_const_88 = A_arbace_spec_gen_alpha__init_A_const_pool.A[110]; A_arbace_spec_gen_alpha__init_A_const_89 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[111]); A_arbace_spec_gen_alpha__init_A_const_90 = A_arbace_spec_gen_alpha__init_A_const_pool.A[112] }

func A_arbace_spec_gen_alpha__init_A_clinit_p7() { A_arbace_spec_gen_alpha__init_A_const_91 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[113]); A_arbace_spec_gen_alpha__init_A_const_92 = A_arbace_spec_gen_alpha__init_A_const_pool.A[114]; A_arbace_spec_gen_alpha__init_A_const_93 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[115]); A_arbace_spec_gen_alpha__init_A_const_94 = A_arbace_spec_gen_alpha__init_A_const_pool.A[116]; A_arbace_spec_gen_alpha__init_A_const_95 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[117]); A_arbace_spec_gen_alpha__init_A_const_96 = A_arbace_spec_gen_alpha__init_A_const_pool.A[118]; A_arbace_spec_gen_alpha__init_A_const_97 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[119]); A_arbace_spec_gen_alpha__init_A_const_98 = A_arbace_spec_gen_alpha__init_A_const_pool.A[120]; A_arbace_spec_gen_alpha__init_A_const_99 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[121]); A_arbace_spec_gen_alpha__init_A_const_100 = A_arbace_spec_gen_alpha__init_A_const_pool.A[122]; A_arbace_spec_gen_alpha__init_A_const_101 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[123]); A_arbace_spec_gen_alpha__init_A_const_102 = A_arbace_spec_gen_alpha__init_A_const_pool.A[124]; A_arbace_spec_gen_alpha__init_A_const_103 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[125]) }

func A_arbace_spec_gen_alpha__init_A_clinit_p8() { A_arbace_spec_gen_alpha__init_A_const_104 = A_arbace_spec_gen_alpha__init_A_const_pool.A[126]; A_arbace_spec_gen_alpha__init_A_const_105 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[127]); A_arbace_spec_gen_alpha__init_A_const_106 = A_arbace_spec_gen_alpha__init_A_const_pool.A[128]; A_arbace_spec_gen_alpha__init_A_const_107 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[129]); A_arbace_spec_gen_alpha__init_A_const_108 = A_arbace_spec_gen_alpha__init_A_const_pool.A[130]; A_arbace_spec_gen_alpha__init_A_const_109 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[131]); A_arbace_spec_gen_alpha__init_A_const_110 = A_arbace_spec_gen_alpha__init_A_const_pool.A[132]; A_arbace_spec_gen_alpha__init_A_const_111 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[133]); A_arbace_spec_gen_alpha__init_A_const_112 = A_arbace_spec_gen_alpha__init_A_const_pool.A[134]; A_arbace_spec_gen_alpha__init_A_const_113 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[135]); A_arbace_spec_gen_alpha__init_A_const_114 = A_arbace_spec_gen_alpha__init_A_const_pool.A[136]; A_arbace_spec_gen_alpha__init_A_const_115 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[137]); A_arbace_spec_gen_alpha__init_A_const_116 = A_arbace_spec_gen_alpha__init_A_const_pool.A[138] }

func A_arbace_spec_gen_alpha__init_A_clinit_p9() { A_arbace_spec_gen_alpha__init_A_const_117 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[139]); A_arbace_spec_gen_alpha__init_A_const_118 = A_arbace_spec_gen_alpha__init_A_const_pool.A[140]; A_arbace_spec_gen_alpha__init_A_const_119 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[141]); A_arbace_spec_gen_alpha__init_A_const_120 = A_arbace_spec_gen_alpha__init_A_const_pool.A[142]; A_arbace_spec_gen_alpha__init_A_const_121 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[143]); A_arbace_spec_gen_alpha__init_A_const_122 = A_arbace_spec_gen_alpha__init_A_const_pool.A[144]; A_arbace_spec_gen_alpha__init_A_const_123 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[145]); A_arbace_spec_gen_alpha__init_A_const_124 = A_arbace_spec_gen_alpha__init_A_const_pool.A[146]; A_arbace_spec_gen_alpha__init_A_const_125 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[147]); A_arbace_spec_gen_alpha__init_A_const_126 = A_arbace_spec_gen_alpha__init_A_const_pool.A[148]; A_arbace_spec_gen_alpha__init_A_const_127 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[149]); A_arbace_spec_gen_alpha__init_A_const_128 = A_arbace_spec_gen_alpha__init_A_const_pool.A[150]; A_arbace_spec_gen_alpha__init_A_const_129 = lang.Var_Cast(A_arbace_spec_gen_alpha__init_A_const_pool.A[151]) }

func A_arbace_spec_gen_alpha__init_A_clinit_p10() { A_arbace_spec_gen_alpha__init_A_const_130 = A_arbace_spec_gen_alpha__init_A_const_pool.A[152] }

func A_arbace_spec_gen_alpha__init_A_New() *A_arbace_spec_gen_alpha__init_A { A_arbace_spec_gen_alpha__init_A_Init(); t := &A_arbace_spec_gen_alpha__init_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha__init_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha__init_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha__init_A_class }

func (t *A_arbace_spec_gen_alpha__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha__init_A); return ok }

func A_arbace_spec_gen_alpha__init_A_Cast(x any) *A_arbace_spec_gen_alpha__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha__init_A_class)) }; return v }
