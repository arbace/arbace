//line aot_arbace_spec_gen_alpha.ae:1
package aot_arbace_spec_gen_alpha

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_New() *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_gen_alpha_A_const_1, A_arbace_spec_gen_alpha_A_const_2, A_arbace_spec_gen_alpha_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :13:1
func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_New() *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_4.GetRawRoot__O()); var tmp2 any; var root_7 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_spec_gen_alpha_A_const_6; if linked_8 == nil { tmp2 = ifn_9.Invoke_O__O(arg_10) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_7, arg_10) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_spec_gen_alpha_A_const_7.GetRawRoot__O(), A_arbace_spec_gen_alpha_A_const_8) }









func A_arbace_spec_gen_alpha_dynaload_A_New() *A_arbace_spec_gen_alpha_dynaload_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_dynaload_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_spec_gen_alpha_dynaload_A) Ctor() {}
//line :23:1
func (t *A_arbace_spec_gen_alpha_dynaload_A) Invoke_O_O__O(self, s__0 any) any { var ns__2 any; var root_17 any = A_arbace_spec_gen_alpha_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_19 lang.IFn; if

	linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = s__0; if linked_18 == nil { ns__2 = ifn_19.Invoke_O__O(arg_20) } else { ns__2 = linked_18.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_17, arg_20) }; if
	jrt.J2g_Truth(ns__2) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_12))).Ref()))) }; var lockee__1927000360__auto____3 any = /*line :23:1*/A_arbace_spec_gen_alpha_A_const_13.GetRawRoot__O(); var tmp1 any = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_New_O_O(lockee__1927000360__auto____3, ns__2); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class; if



	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var v__3 any; var root_21 any = /*line :23:1*/A_arbace_spec_gen_alpha_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_23 lang.IFn; if





	linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = s__0; if linked_22 == nil { v__3 = ifn_23.Invoke_O__O(arg_24) } else { v__3 = linked_22.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_21, arg_24) }; if
	jrt.J2g_Truth(v__3) { var root_25 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = v__3; if linked_26 == nil { return ifn_27.Invoke_O__O(arg_28) } else { return linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) } } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil))))) } }
//line :27:1
func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_New_O_O(p0, p1 any) *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Ctor_O_O(c__lockee__1927000360__auto__, c__ns any) { t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__; t.F_ns = c__ns }
//line :27:1
func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_14.GetRawRoot__O()); var tmp3 any; var root_33 any = A_arbace_spec_gen_alpha_A_const_15.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var t__2 any = t.F_ns; t.F_ns = nil; arg_36 = t__2; if linked_34 == nil { tmp3 = ifn_35.Invoke_O__O(arg_36) } else { tmp3 = linked_34.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_33, arg_36) }; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :27:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp4 != nil { panic(tmp4) }; return tmp1 }







func A_arbace_spec_gen_alpha_fn__1067000017_A_New() *A_arbace_spec_gen_alpha_fn__1067000017_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000017_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Ctor() {}
//line :35:1
func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Invoke_O__O(self any) any { var root_42 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_spec_gen_alpha_A_const_17; if linked_43 == nil { return ifn_44.Invoke_O__O(arg_45) } else { return linked_43.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_42, arg_45) } }
func A_arbace_spec_gen_alpha_quick_check_A_New() *A_arbace_spec_gen_alpha_quick_check_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_quick_check_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_spec_gen_alpha_quick_check_A) Ctor() {}
//line :36:1
func (t *A_arbace_spec_gen_alpha_quick_check_A) DoInvoke_O_O__O(self, args__0 any) any {

	var root_50 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any; var root_46 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = A_arbace_spec_gen_alpha_A_const_19.GetRawRoot__O(); if linked_47 == nil { arg_53 = ifn_48.Invoke_O__O(arg_49) } else { arg_53 = linked_47.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_46, arg_49) }; var arg_54 any = args__0; if linked_51 == nil { return ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { return linked_51.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_50, arg_53, arg_54)
	}
}
func A_arbace_spec_gen_alpha_fn__1067000020_A_New() *A_arbace_spec_gen_alpha_fn__1067000020_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000020_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Ctor() {}
//line :41:1
func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Invoke_O__O(self any) any { var root_55 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = A_arbace_spec_gen_alpha_A_const_20; if linked_56 == nil { return ifn_57.Invoke_O__O(arg_58) } else { return linked_56.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_55, arg_58) } }
func A_arbace_spec_gen_alpha_for_all_STAR__A_New() *A_arbace_spec_gen_alpha_for_all_STAR__A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_for_all_STAR__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) Ctor() {}
//line :42:1
func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) DoInvoke_O_O__O(self, args__0 any) any {


	var root_63 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_59 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_spec_gen_alpha_A_const_21.GetRawRoot__O(); if linked_60 == nil { arg_66 = ifn_61.Invoke_O__O(arg_62) } else { arg_66 = linked_60.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_59, arg_62) }; var arg_67 any = args__0; if linked_64 == nil { return ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { return linked_64.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_63, arg_66, arg_67)
	} }
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Ctor() {}
//line :47:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Invoke_O__O(self any) any { var root_68 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_spec_gen_alpha_A_const_22; if linked_69 == nil { return ifn_70.Invoke_O__O(arg_71) } else { return linked_69.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_68, arg_71) } }
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Invoke_O__O(self any) any { var root_72 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_spec_gen_alpha_A_const_23; if linked_73 == nil { return ifn_74.Invoke_O__O(arg_75) } else { return linked_73.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_72, arg_75) } }
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Ctor() {}
//line :49:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Invoke_O__O(self any) any { var root_76 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = A_arbace_spec_gen_alpha_A_const_24; if linked_77 == nil { return ifn_78.Invoke_O__O(arg_79) } else { return linked_77.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_76, arg_79) } }
func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A{}; t.Ctor_O(p0); return t }
//line :50:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Ctor_O(c__g_QMARK_ any) { t.F_g_QMARK_ = c__g_QMARK_ }
//line :50:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Invoke_O_O__O(self, x__1 any) any {

	var tmp1 any; var root_84 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = t.F_g_QMARK_; if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_84, arg_87) }; return lang.IFn_Cast(tmp1).Invoke_O__O(x__1) }
func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Ctor_O(c__mkg any) { t.F_mkg = c__mkg }
//line :53:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Invoke_O_O__O(self, gfn__1 any) any {

	var tmp1 any; var root_88 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = t.F_mkg; if linked_89 == nil { tmp1 = ifn_90.Invoke_O__O(arg_91) } else { tmp1 = linked_89.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_88, arg_91) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gfn__1) }
func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :56:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Invoke_O_O__O(self, generator__1 any) any {


	var tmp1 any; var root_80 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = t.F_g; if linked_81 == nil { tmp1 = ifn_82.Invoke_O__O(arg_83) } else { tmp1 = linked_81.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_80, arg_83) }; return lang.IFn_Cast(tmp1).Invoke_O__O(generator__1)
}
func A_arbace_spec_gen_alpha_delay_impl_A_New() *A_arbace_spec_gen_alpha_delay_impl_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_delay_impl_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_spec_gen_alpha_delay_impl_A) Ctor() {}
//line :61:1
func (t *A_arbace_spec_gen_alpha_delay_impl_A) Invoke_O_O__O(self, gfnd__0 any) any {


	var root_97 any = A_arbace_spec_gen_alpha_A_const_25.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var tmp1 any = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_New_O(gfnd__0); var tmp2 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class = fncls__96d; tmp2 = fncls__96d } else { tmp2 = fncls__96 }; arg_100 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A).Invoke_O_O__O(root_97, arg_100) } }
//line :64:1
func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_New_O(p0 any) *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A{}; t.Ctor_O(p0); return t }
//line :64:1
func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Ctor_O(c__gfnd any) { t.F_gfnd = c__gfnd }
//line :64:1
func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Invoke_O_O_O__O(self, rnd__1, size__2 any) any {
	var tmp1 *lang.Keyword = A_arbace_spec_gen_alpha_A_const_26; var tmp2 any; var root_92 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t.F_gfnd; if linked_93 == nil { tmp2 = ifn_94.Invoke_O__O(arg_95) } else { tmp2 = linked_93.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_92, arg_95) }; return lang.IFn_Cast(tmp1.Invoke_O__O(tmp2)).Invoke_O_O__O(rnd__1, size__2)
}
func A_arbace_spec_gen_alpha_delay_A_New() *A_arbace_spec_gen_alpha_delay_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_delay_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_spec_gen_alpha_delay_A) Ctor() {}
//line :67:1
func (t *A_arbace_spec_gen_alpha_delay_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_115 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any; var root_110 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_30); var arg_114 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp2 any; var root_106 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_101 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_31); var arg_105 any = body__2; if linked_102 == nil { arg_109 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { arg_109 = linked_102.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; if linked_107 == nil { tmp2 = ifn_108.Invoke_O__O(arg_109) } else { tmp2 = linked_107.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_106, arg_109) }; arg_114 = tmp1.Invoke_O__O(tmp2); if linked_111 == nil { arg_118 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { arg_118 = linked_111.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) }; if linked_116 == nil { return ifn_117.Invoke_O__O(arg_118) } else { return linked_116.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_115, arg_118) } }






func A_arbace_spec_gen_alpha_gen_for_name_A_New() *A_arbace_spec_gen_alpha_gen_for_name_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_gen_for_name_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Ctor() {}
//line :74:1
func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Invoke_O_O__O(self, s__0 any) any { var g__2 any; var root_119 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_121 lang.IFn; if


	linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = s__0; if linked_120 == nil { g__2 = ifn_121.Invoke_O__O(arg_122) } else { g__2 = linked_120.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_119, arg_122) }; var tmp1 any; var root_123 any =
	A_arbace_spec_gen_alpha_A_const_32.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = g__2; if linked_124 == nil { tmp1 = ifn_125.Invoke_O__O(arg_126) } else { tmp1 = linked_124.(*A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(tmp1) { return g__2 } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil))))) } }



func A_arbace_spec_gen_alpha_lazy_combinator_A_New() *A_arbace_spec_gen_alpha_lazy_combinator_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinator_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Ctor() {}
//line :82:1
func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, s__2 any) any { var fqn__4 any; var root_131 any = A_arbace_spec_gen_alpha_A_const_15.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_133 lang.IFn; if


	linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = Lit_14; var arg_135 any; var root_127 any = A_arbace_spec_gen_alpha_A_const_33.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = s__2; if linked_128 == nil { arg_135 = ifn_129.Invoke_O__O(arg_130) } else { arg_135 = linked_128.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_127, arg_130) }; if linked_132 == nil { fqn__4 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { fqn__4 = linked_132.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }; var doc__5 any = /*line :82:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, fqn__4)).Ref(); var root_228 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_230 lang.IFn; if


	linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_34); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp4 any; var root_172 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = A_arbace_spec_gen_alpha_A_const_35.GetRawRoot__O(); var arg_176 any; var root_168 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var root_163 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_36); var arg_167 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp6 any; var root_159 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_154 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_37); var arg_158 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp8 any; var root_150 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_145 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_38); var arg_149 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp10 any; var root_141 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_136 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_39); var arg_140 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(fqn__4); if linked_137 == nil { arg_144 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { arg_144 = linked_137.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if linked_142 == nil { tmp10 = ifn_143.Invoke_O__O(arg_144) } else { tmp10 = linked_142.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_141, arg_144) }; arg_149 = tmp9.Invoke_O__O(tmp10); if linked_146 == nil { arg_153 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { arg_153 = linked_146.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; if linked_151 == nil { tmp8 = ifn_152.Invoke_O__O(arg_153) } else { tmp8 = linked_151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_150, arg_153) }; arg_158 = tmp7.Invoke_O__O(tmp8); if linked_155 == nil { arg_162 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { arg_162 = linked_155.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }; if linked_160 == nil { tmp6 = ifn_161.Invoke_O__O(arg_162) } else { tmp6 = linked_160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_159, arg_162) }; arg_167 = tmp5.Invoke_O__O(tmp6); if linked_164 == nil { arg_171 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { arg_171 = linked_164.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; if linked_169 == nil { arg_176 = ifn_170.Invoke_O__O(arg_171) } else { arg_176 = linked_169.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_168, arg_171) }; if linked_173 == nil { tmp4 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { tmp4 = linked_173.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; var tmp11 any = tmp3.Invoke_O__O(tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp13 any; var root_218 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_40); var tmp16 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(s__2); var tmp17 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(doc__5); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp19 any; var root_186 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = A_arbace_spec_gen_alpha_A_const_35.GetRawRoot__O(); var arg_190 any; var root_182 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_177 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_41); var arg_181 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_42); if linked_178 == nil { arg_185 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { arg_185 = linked_178.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; if linked_183 == nil { arg_190 = ifn_184.Invoke_O__O(arg_185) } else { arg_190 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; if linked_187 == nil { tmp19 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { tmp19 = linked_187.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) }; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp22 any; var root_206 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O()); var tmp24 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_43); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp26 any; var root_196 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var root_191 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_44); var arg_195 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_36); if linked_192 == nil { arg_199 = ifn_193.Invoke_O_O__O(arg_194, arg_195) } else { arg_199 = linked_192.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_191, arg_194, arg_195) }; if linked_197 == nil { tmp26 = ifn_198.Invoke_O__O(arg_199) } else { tmp26 = linked_197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_196, arg_199) }; arg_209 = tmp23.Invoke_O_O_O__O(tmp24, tmp25.Invoke_O__O(tmp26), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_45)); if linked_207 == nil { tmp22 = ifn_208.Invoke_O__O(arg_209) } else { tmp22 = linked_207.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_206, arg_209) }; arg_221 = tmp14.Invoke_O_O_O_O_O__O(tmp15, tmp16, tmp17, tmp20, tmp21.Invoke_O__O(tmp22)); if linked_219 == nil { tmp13 = ifn_220.Invoke_O__O(arg_221) } else { tmp13 = linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) }; arg_231 = tmp1.Invoke_O_O_O__O(tmp2, tmp11, tmp12.Invoke_O__O(tmp13)); if linked_229 == nil { return ifn_230.Invoke_O__O(arg_231) } else { return linked_229.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_228, arg_231) } }







func A_arbace_spec_gen_alpha_lazy_combinators_A_New() *A_arbace_spec_gen_alpha_lazy_combinators_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinators_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) Ctor() {}
//line :93:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, syms__2 any) any { var root_243 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var root_238 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_46); var arg_242 any; var root_233 any = A_arbace_spec_gen_alpha_A_const_47.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_235 lang.IFn; if



	linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var tmp1 any = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_New(); var tmp2 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class; if
	fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class = fncls__232d; tmp2 = fncls__232d } else { tmp2 = fncls__232 }; arg_236 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_237 any = syms__2; if /*line :97:1*/ linked_234 == nil { arg_242 = ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { arg_242 = linked_234.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_233, arg_236, arg_237) }; if /*line :93:1*/ linked_239 == nil { arg_246 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { arg_246 = linked_239.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) }; if linked_244 == nil { return ifn_245.Invoke_O__O(arg_246) } else { return linked_244.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_243, arg_246) } }




func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_New() *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Ctor() {}
//line :98:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Invoke_O_O__O(self, s__1 any) any { return lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_48, s__1) }


func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_New() *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Invoke_O__O(self any) any { var root_247 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = A_arbace_spec_gen_alpha_A_const_49; if linked_248 == nil { return ifn_249.Invoke_O__O(arg_250) } else { return linked_248.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_247, arg_250) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) DoInvoke_O_O__O(self, args__1 any) any { var root_255 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var root_251 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = t.F_g__1067000046__auto__; if linked_252 == nil { arg_258 = ifn_253.Invoke_O__O(arg_254) } else { arg_258 = linked_252.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_251, arg_254) }; var arg_259 any = args__1; if linked_256 == nil { return ifn_257.Invoke_O_O__O(arg_258, arg_259) } else { return linked_256.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_255, arg_258, arg_259) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_New() *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Invoke_O__O(self any) any { var root_260 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = A_arbace_spec_gen_alpha_A_const_50; if linked_261 == nil { return ifn_262.Invoke_O__O(arg_263) } else { return linked_261.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_260, arg_263) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) DoInvoke_O_O__O(self, args__1 any) any { var root_268 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var root_264 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = t.F_g__1067000046__auto__; if linked_265 == nil { arg_271 = ifn_266.Invoke_O__O(arg_267) } else { arg_271 = linked_265.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_264, arg_267) }; var arg_272 any = args__1; if linked_269 == nil { return ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { return linked_269.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_New() *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Invoke_O__O(self any) any { var root_273 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_spec_gen_alpha_A_const_51; if linked_274 == nil { return ifn_275.Invoke_O__O(arg_276) } else { return linked_274.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_273, arg_276) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) DoInvoke_O_O__O(self, args__1 any) any { var root_281 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_277 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t.F_g__1067000046__auto__; if linked_278 == nil { arg_284 = ifn_279.Invoke_O__O(arg_280) } else { arg_284 = linked_278.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_277, arg_280) }; var arg_285 any = args__1; if linked_282 == nil { return ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { return linked_282.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_New() *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Invoke_O__O(self any) any { var root_286 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = A_arbace_spec_gen_alpha_A_const_52; if linked_287 == nil { return ifn_288.Invoke_O__O(arg_289) } else { return linked_287.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_286, arg_289) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) DoInvoke_O_O__O(self, args__1 any) any { var root_294 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_290 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = t.F_g__1067000046__auto__; if linked_291 == nil { arg_297 = ifn_292.Invoke_O__O(arg_293) } else { arg_297 = linked_291.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_290, arg_293) }; var arg_298 any = args__1; if linked_295 == nil { return ifn_296.Invoke_O_O__O(arg_297, arg_298) } else { return linked_295.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_294, arg_297, arg_298) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_New() *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Invoke_O__O(self any) any { var root_299 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_spec_gen_alpha_A_const_53; if linked_300 == nil { return ifn_301.Invoke_O__O(arg_302) } else { return linked_300.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_299, arg_302) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) DoInvoke_O_O__O(self, args__1 any) any { var root_307 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var root_303 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = t.F_g__1067000046__auto__; if linked_304 == nil { arg_310 = ifn_305.Invoke_O__O(arg_306) } else { arg_310 = linked_304.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_303, arg_306) }; var arg_311 any = args__1; if linked_308 == nil { return ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { return linked_308.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_New() *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Invoke_O__O(self any) any { var root_312 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_spec_gen_alpha_A_const_54; if linked_313 == nil { return ifn_314.Invoke_O__O(arg_315) } else { return linked_313.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_312, arg_315) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) DoInvoke_O_O__O(self, args__1 any) any { var root_320 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any; var root_316 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = t.F_g__1067000046__auto__; if linked_317 == nil { arg_323 = ifn_318.Invoke_O__O(arg_319) } else { arg_323 = linked_317.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_316, arg_319) }; var arg_324 any = args__1; if linked_321 == nil { return ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { return linked_321.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_New() *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Invoke_O__O(self any) any { var root_325 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_spec_gen_alpha_A_const_55; if linked_326 == nil { return ifn_327.Invoke_O__O(arg_328) } else { return linked_326.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_325, arg_328) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) DoInvoke_O_O__O(self, args__1 any) any { var root_333 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_329 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = t.F_g__1067000046__auto__; if linked_330 == nil { arg_336 = ifn_331.Invoke_O__O(arg_332) } else { arg_336 = linked_330.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_329, arg_332) }; var arg_337 any = args__1; if linked_334 == nil { return ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { return linked_334.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) DoInvoke_O_O__O(self, args__1 any) any { var root_346 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any; var root_342 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = t.F_g__1067000046__auto__; if linked_343 == nil { arg_349 = ifn_344.Invoke_O__O(arg_345) } else { arg_349 = linked_343.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_342, arg_345) }; var arg_350 any = args__1; if linked_347 == nil { return ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { return linked_347.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_New() *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Invoke_O__O(self any) any { var root_338 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_spec_gen_alpha_A_const_56; if linked_339 == nil { return ifn_340.Invoke_O__O(arg_341) } else { return linked_339.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_338, arg_341) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) DoInvoke_O_O__O(self, args__1 any) any { var root_359 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var root_355 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = t.F_g__1067000046__auto__; if linked_356 == nil { arg_362 = ifn_357.Invoke_O__O(arg_358) } else { arg_362 = linked_356.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_355, arg_358) }; var arg_363 any = args__1; if linked_360 == nil { return ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { return linked_360.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_New() *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Invoke_O__O(self any) any { var root_351 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = A_arbace_spec_gen_alpha_A_const_57; if linked_352 == nil { return ifn_353.Invoke_O__O(arg_354) } else { return linked_352.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_351, arg_354) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) DoInvoke_O_O__O(self, args__1 any) any { var root_372 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var root_368 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = t.F_g__1067000046__auto__; if linked_369 == nil { arg_375 = ifn_370.Invoke_O__O(arg_371) } else { arg_375 = linked_369.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_368, arg_371) }; var arg_376 any = args__1; if linked_373 == nil { return ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { return linked_373.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_New() *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Invoke_O__O(self any) any { var root_364 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = A_arbace_spec_gen_alpha_A_const_58; if linked_365 == nil { return ifn_366.Invoke_O__O(arg_367) } else { return linked_365.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_364, arg_367) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) DoInvoke_O_O__O(self, args__1 any) any { var root_385 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var root_381 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t.F_g__1067000046__auto__; if linked_382 == nil { arg_388 = ifn_383.Invoke_O__O(arg_384) } else { arg_388 = linked_382.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_381, arg_384) }; var arg_389 any = args__1; if linked_386 == nil { return ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { return linked_386.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_385, arg_388, arg_389) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_New() *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Invoke_O__O(self any) any { var root_377 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_spec_gen_alpha_A_const_59; if linked_378 == nil { return ifn_379.Invoke_O__O(arg_380) } else { return linked_378.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_377, arg_380) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_New() *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Invoke_O__O(self any) any { var root_390 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = A_arbace_spec_gen_alpha_A_const_60; if linked_391 == nil { return ifn_392.Invoke_O__O(arg_393) } else { return linked_391.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_390, arg_393) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) DoInvoke_O_O__O(self, args__1 any) any { var root_398 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var root_394 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = t.F_g__1067000046__auto__; if linked_395 == nil { arg_401 = ifn_396.Invoke_O__O(arg_397) } else { arg_401 = linked_395.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_394, arg_397) }; var arg_402 any = args__1; if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_New() *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Invoke_O__O(self any) any { var root_403 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = A_arbace_spec_gen_alpha_A_const_61; if linked_404 == nil { return ifn_405.Invoke_O__O(arg_406) } else { return linked_404.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_403, arg_406) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) DoInvoke_O_O__O(self, args__1 any) any { var root_411 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var root_407 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = t.F_g__1067000046__auto__; if linked_408 == nil { arg_414 = ifn_409.Invoke_O__O(arg_410) } else { arg_414 = linked_408.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_407, arg_410) }; var arg_415 any = args__1; if linked_412 == nil { return ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { return linked_412.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_411, arg_414, arg_415) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_New() *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Invoke_O__O(self any) any { var root_416 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = A_arbace_spec_gen_alpha_A_const_62; if linked_417 == nil { return ifn_418.Invoke_O__O(arg_419) } else { return linked_417.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_416, arg_419) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) DoInvoke_O_O__O(self, args__1 any) any { var root_424 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any; var root_420 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = t.F_g__1067000046__auto__; if linked_421 == nil { arg_427 = ifn_422.Invoke_O__O(arg_423) } else { arg_427 = linked_421.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_420, arg_423) }; var arg_428 any = args__1; if linked_425 == nil { return ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { return linked_425.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_New() *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Invoke_O__O(self any) any { var root_429 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = A_arbace_spec_gen_alpha_A_const_63; if linked_430 == nil { return ifn_431.Invoke_O__O(arg_432) } else { return linked_430.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_429, arg_432) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) DoInvoke_O_O__O(self, args__1 any) any { var root_437 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var root_433 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = t.F_g__1067000046__auto__; if linked_434 == nil { arg_440 = ifn_435.Invoke_O__O(arg_436) } else { arg_440 = linked_434.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_433, arg_436) }; var arg_441 any = args__1; if linked_438 == nil { return ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { return linked_438.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_New() *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Invoke_O__O(self any) any { var root_442 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = A_arbace_spec_gen_alpha_A_const_64; if linked_443 == nil { return ifn_444.Invoke_O__O(arg_445) } else { return linked_443.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_442, arg_445) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) DoInvoke_O_O__O(self, args__1 any) any { var root_450 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_446 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t.F_g__1067000046__auto__; if linked_447 == nil { arg_453 = ifn_448.Invoke_O__O(arg_449) } else { arg_453 = linked_447.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_446, arg_449) }; var arg_454 any = args__1; if linked_451 == nil { return ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { return linked_451.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_New() *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Invoke_O__O(self any) any { var root_455 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = A_arbace_spec_gen_alpha_A_const_65; if linked_456 == nil { return ifn_457.Invoke_O__O(arg_458) } else { return linked_456.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_455, arg_458) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) DoInvoke_O_O__O(self, args__1 any) any { var root_463 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var root_459 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t.F_g__1067000046__auto__; if linked_460 == nil { arg_466 = ifn_461.Invoke_O__O(arg_462) } else { arg_466 = linked_460.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_459, arg_462) }; var arg_467 any = args__1; if linked_464 == nil { return ifn_465.Invoke_O_O__O(arg_466, arg_467) } else { return linked_464.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_463, arg_466, arg_467) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) DoInvoke_O_O__O(self, args__1 any) any { var root_476 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_472 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = t.F_g__1067000046__auto__; if linked_473 == nil { arg_479 = ifn_474.Invoke_O__O(arg_475) } else { arg_479 = linked_473.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_472, arg_475) }; var arg_480 any = args__1; if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_New() *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Invoke_O__O(self any) any { var root_468 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = A_arbace_spec_gen_alpha_A_const_66; if linked_469 == nil { return ifn_470.Invoke_O__O(arg_471) } else { return linked_469.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_468, arg_471) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_New() *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Invoke_O__O(self any) any { var root_481 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = A_arbace_spec_gen_alpha_A_const_67; if linked_482 == nil { return ifn_483.Invoke_O__O(arg_484) } else { return linked_482.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_481, arg_484) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) DoInvoke_O_O__O(self, args__1 any) any { var root_489 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_485 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = t.F_g__1067000046__auto__; if linked_486 == nil { arg_492 = ifn_487.Invoke_O__O(arg_488) } else { arg_492 = linked_486.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_485, arg_488) }; var arg_493 any = args__1; if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_New() *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Invoke_O__O(self any) any { var root_494 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = A_arbace_spec_gen_alpha_A_const_68; if linked_495 == nil { return ifn_496.Invoke_O__O(arg_497) } else { return linked_495.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_494, arg_497) } }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) DoInvoke_O_O__O(self, args__1 any) any { var root_502 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var root_498 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = t.F_g__1067000046__auto__; if linked_499 == nil { arg_505 = ifn_500.Invoke_O__O(arg_501) } else { arg_505 = linked_499.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_498, arg_501) }; var arg_506 any = args__1; if linked_503 == nil { return ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { return linked_503.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } }



func A_arbace_spec_gen_alpha_lazy_prim_A_New() *A_arbace_spec_gen_alpha_lazy_prim_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prim_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Ctor() {}
//line :105:1
func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, s__2 any) any { var fqn__4 any; var root_511 any = A_arbace_spec_gen_alpha_A_const_15.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_513 lang.IFn; if


	linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = Lit_14; var arg_515 any; var root_507 any = A_arbace_spec_gen_alpha_A_const_33.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__2; if linked_508 == nil { arg_515 = ifn_509.Invoke_O__O(arg_510) } else { arg_515 = linked_508.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_507, arg_510) }; if linked_512 == nil { fqn__4 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { fqn__4 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) }; var doc__5 any = /*line :105:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, fqn__4)).Ref(); var root_598 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_600 lang.IFn; if


	linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_69); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp4 any; var root_552 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = A_arbace_spec_gen_alpha_A_const_35.GetRawRoot__O(); var arg_556 any; var root_548 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var root_543 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_70); var arg_547 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp6 any; var root_539 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var root_534 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_71); var arg_538 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp8 any; var root_530 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any; var root_525 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_72); var arg_529 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp10 any; var root_521 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any; var root_516 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_39); var arg_520 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(fqn__4); if linked_517 == nil { arg_524 = ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { arg_524 = linked_517.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) }; if linked_522 == nil { tmp10 = ifn_523.Invoke_O__O(arg_524) } else { tmp10 = linked_522.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_521, arg_524) }; arg_529 = tmp9.Invoke_O__O(tmp10); if linked_526 == nil { arg_533 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { arg_533 = linked_526.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }; if linked_531 == nil { tmp8 = ifn_532.Invoke_O__O(arg_533) } else { tmp8 = linked_531.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_530, arg_533) }; arg_538 = tmp7.Invoke_O__O(tmp8); if linked_535 == nil { arg_542 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { arg_542 = linked_535.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }; if linked_540 == nil { tmp6 = ifn_541.Invoke_O__O(arg_542) } else { tmp6 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; arg_547 = tmp5.Invoke_O__O(tmp6); if linked_544 == nil { arg_551 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { arg_551 = linked_544.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; if linked_549 == nil { arg_556 = ifn_550.Invoke_O__O(arg_551) } else { arg_556 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; if linked_553 == nil { tmp4 = ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { tmp4 = linked_553.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) }; var tmp11 any = tmp3.Invoke_O__O(tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp13 any; var root_588 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_73); var tmp16 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(s__2); var tmp17 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(doc__5); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp19 any; var root_566 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = A_arbace_spec_gen_alpha_A_const_35.GetRawRoot__O(); var arg_570 any; var root_562 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var root_557 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_74); var arg_561 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_75); if linked_558 == nil { arg_565 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { arg_565 = linked_558.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; if linked_563 == nil { arg_570 = ifn_564.Invoke_O__O(arg_565) } else { arg_570 = linked_563.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_562, arg_565) }; if linked_567 == nil { tmp19 = ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { tmp19 = linked_567.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) }; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()); var tmp22 any; var root_576 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var root_571 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_44); var arg_575 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_70); if linked_572 == nil { arg_579 = ifn_573.Invoke_O_O__O(arg_574, arg_575) } else { arg_579 = linked_572.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_571, arg_574, arg_575) }; if linked_577 == nil { tmp22 = ifn_578.Invoke_O__O(arg_579) } else { tmp22 = linked_577.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_576, arg_579) }; arg_591 = tmp14.Invoke_O_O_O_O_O__O(tmp15, tmp16, tmp17, tmp20, tmp21.Invoke_O__O(tmp22)); if linked_589 == nil { tmp13 = ifn_590.Invoke_O__O(arg_591) } else { tmp13 = linked_589.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_588, arg_591) }; arg_601 = tmp1.Invoke_O_O_O__O(tmp2, tmp11, tmp12.Invoke_O__O(tmp13)); if linked_599 == nil { return ifn_600.Invoke_O__O(arg_601) } else { return linked_599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_598, arg_601) } }







func A_arbace_spec_gen_alpha_lazy_prims_A_New() *A_arbace_spec_gen_alpha_lazy_prims_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prims_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_A) Ctor() {}
//line :116:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, syms__2 any) any { var root_613 any = A_arbace_spec_gen_alpha_A_const_27.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any; var root_608 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_76); var arg_612 any; var root_603 any = A_arbace_spec_gen_alpha_A_const_47.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_605 lang.IFn; if



	linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var tmp1 any = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_New(); var tmp2 *jrt.Class; var fncls__602 *jrt.Class = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class; if
	fncls__602 == nil { var fncls__602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class = fncls__602d; tmp2 = fncls__602d } else { tmp2 = fncls__602 }; arg_606 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_607 any = syms__2; if /*line :120:1*/ linked_604 == nil { arg_612 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { arg_612 = linked_604.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }; if /*line :116:1*/ linked_609 == nil { arg_616 = ifn_610.Invoke_O_O__O(arg_611, arg_612) } else { arg_616 = linked_609.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_608, arg_611, arg_612) }; if linked_614 == nil { return ifn_615.Invoke_O__O(arg_616) } else { return linked_614.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_613, arg_616) } }




func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_New() *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Ctor() {}
//line :121:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Invoke_O_O__O(self, s__1 any) any { return lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_77, s__1) }


func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) DoInvoke_O_O__O(self, args__1 any) any { var root_621 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = t.F_g__1067000179__auto__; if linked_622 == nil { return ifn_623.Invoke_O__O(arg_624) } else { return linked_622.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_621, arg_624) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_New() *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Invoke_O__O(self any) any { var root_617 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = A_arbace_spec_gen_alpha_A_const_78; if linked_618 == nil { return ifn_619.Invoke_O__O(arg_620) } else { return linked_618.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_617, arg_620) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) DoInvoke_O_O__O(self, args__1 any) any { var root_629 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = t.F_g__1067000179__auto__; if linked_630 == nil { return ifn_631.Invoke_O__O(arg_632) } else { return linked_630.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_629, arg_632) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_New() *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Invoke_O__O(self any) any { var root_625 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_spec_gen_alpha_A_const_79; if linked_626 == nil { return ifn_627.Invoke_O__O(arg_628) } else { return linked_626.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_625, arg_628) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) DoInvoke_O_O__O(self, args__1 any) any { var root_637 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = t.F_g__1067000179__auto__; if linked_638 == nil { return ifn_639.Invoke_O__O(arg_640) } else { return linked_638.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_637, arg_640) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_New() *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Invoke_O__O(self any) any { var root_633 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = A_arbace_spec_gen_alpha_A_const_80; if linked_634 == nil { return ifn_635.Invoke_O__O(arg_636) } else { return linked_634.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_633, arg_636) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) DoInvoke_O_O__O(self, args__1 any) any { var root_645 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = t.F_g__1067000179__auto__; if linked_646 == nil { return ifn_647.Invoke_O__O(arg_648) } else { return linked_646.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_645, arg_648) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_New() *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Invoke_O__O(self any) any { var root_641 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = A_arbace_spec_gen_alpha_A_const_81; if linked_642 == nil { return ifn_643.Invoke_O__O(arg_644) } else { return linked_642.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_641, arg_644) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) DoInvoke_O_O__O(self, args__1 any) any { var root_653 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = t.F_g__1067000179__auto__; if linked_654 == nil { return ifn_655.Invoke_O__O(arg_656) } else { return linked_654.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_653, arg_656) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_New() *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Invoke_O__O(self any) any { var root_649 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = A_arbace_spec_gen_alpha_A_const_82; if linked_650 == nil { return ifn_651.Invoke_O__O(arg_652) } else { return linked_650.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_649, arg_652) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) DoInvoke_O_O__O(self, args__1 any) any { var root_661 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = t.F_g__1067000179__auto__; if linked_662 == nil { return ifn_663.Invoke_O__O(arg_664) } else { return linked_662.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_661, arg_664) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_New() *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Invoke_O__O(self any) any { var root_657 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = A_arbace_spec_gen_alpha_A_const_83; if linked_658 == nil { return ifn_659.Invoke_O__O(arg_660) } else { return linked_658.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_657, arg_660) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) DoInvoke_O_O__O(self, args__1 any) any { var root_669 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = t.F_g__1067000179__auto__; if linked_670 == nil { return ifn_671.Invoke_O__O(arg_672) } else { return linked_670.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_669, arg_672) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_New() *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Invoke_O__O(self any) any { var root_665 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = A_arbace_spec_gen_alpha_A_const_84; if linked_666 == nil { return ifn_667.Invoke_O__O(arg_668) } else { return linked_666.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_665, arg_668) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) DoInvoke_O_O__O(self, args__1 any) any { var root_677 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = t.F_g__1067000179__auto__; if linked_678 == nil { return ifn_679.Invoke_O__O(arg_680) } else { return linked_678.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_677, arg_680) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_New() *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Invoke_O__O(self any) any { var root_673 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = A_arbace_spec_gen_alpha_A_const_85; if linked_674 == nil { return ifn_675.Invoke_O__O(arg_676) } else { return linked_674.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_673, arg_676) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) DoInvoke_O_O__O(self, args__1 any) any { var root_685 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = t.F_g__1067000179__auto__; if linked_686 == nil { return ifn_687.Invoke_O__O(arg_688) } else { return linked_686.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_685, arg_688) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_New() *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Invoke_O__O(self any) any { var root_681 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = A_arbace_spec_gen_alpha_A_const_86; if linked_682 == nil { return ifn_683.Invoke_O__O(arg_684) } else { return linked_682.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_681, arg_684) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_New() *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Invoke_O__O(self any) any { var root_689 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = A_arbace_spec_gen_alpha_A_const_87; if linked_690 == nil { return ifn_691.Invoke_O__O(arg_692) } else { return linked_690.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_689, arg_692) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) DoInvoke_O_O__O(self, args__1 any) any { var root_693 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = t.F_g__1067000179__auto__; if linked_694 == nil { return ifn_695.Invoke_O__O(arg_696) } else { return linked_694.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_693, arg_696) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_New() *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Invoke_O__O(self any) any { var root_697 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = A_arbace_spec_gen_alpha_A_const_88; if linked_698 == nil { return ifn_699.Invoke_O__O(arg_700) } else { return linked_698.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_697, arg_700) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) DoInvoke_O_O__O(self, args__1 any) any { var root_701 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = t.F_g__1067000179__auto__; if linked_702 == nil { return ifn_703.Invoke_O__O(arg_704) } else { return linked_702.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_701, arg_704) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_New() *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Invoke_O__O(self any) any { var root_705 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = A_arbace_spec_gen_alpha_A_const_89; if linked_706 == nil { return ifn_707.Invoke_O__O(arg_708) } else { return linked_706.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_705, arg_708) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) DoInvoke_O_O__O(self, args__1 any) any { var root_709 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = t.F_g__1067000179__auto__; if linked_710 == nil { return ifn_711.Invoke_O__O(arg_712) } else { return linked_710.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_709, arg_712) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_New() *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Invoke_O__O(self any) any { var root_713 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = A_arbace_spec_gen_alpha_A_const_90; if linked_714 == nil { return ifn_715.Invoke_O__O(arg_716) } else { return linked_714.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_713, arg_716) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) DoInvoke_O_O__O(self, args__1 any) any { var root_717 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = t.F_g__1067000179__auto__; if linked_718 == nil { return ifn_719.Invoke_O__O(arg_720) } else { return linked_718.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_717, arg_720) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_New() *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Invoke_O__O(self any) any { var root_721 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = A_arbace_spec_gen_alpha_A_const_91; if linked_722 == nil { return ifn_723.Invoke_O__O(arg_724) } else { return linked_722.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_721, arg_724) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) DoInvoke_O_O__O(self, args__1 any) any { var root_725 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = t.F_g__1067000179__auto__; if linked_726 == nil { return ifn_727.Invoke_O__O(arg_728) } else { return linked_726.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_725, arg_728) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_New() *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Invoke_O__O(self any) any { var root_729 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = A_arbace_spec_gen_alpha_A_const_92; if linked_730 == nil { return ifn_731.Invoke_O__O(arg_732) } else { return linked_730.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_729, arg_732) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) DoInvoke_O_O__O(self, args__1 any) any { var root_733 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = t.F_g__1067000179__auto__; if linked_734 == nil { return ifn_735.Invoke_O__O(arg_736) } else { return linked_734.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_733, arg_736) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_New() *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Invoke_O__O(self any) any { var root_737 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = A_arbace_spec_gen_alpha_A_const_93; if linked_738 == nil { return ifn_739.Invoke_O__O(arg_740) } else { return linked_738.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_737, arg_740) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) DoInvoke_O_O__O(self, args__1 any) any { var root_741 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_g__1067000179__auto__; if linked_742 == nil { return ifn_743.Invoke_O__O(arg_744) } else { return linked_742.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_741, arg_744) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_New() *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Invoke_O__O(self any) any { var root_745 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = A_arbace_spec_gen_alpha_A_const_94; if linked_746 == nil { return ifn_747.Invoke_O__O(arg_748) } else { return linked_746.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_745, arg_748) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) DoInvoke_O_O__O(self, args__1 any) any { var root_749 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = t.F_g__1067000179__auto__; if linked_750 == nil { return ifn_751.Invoke_O__O(arg_752) } else { return linked_750.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_749, arg_752) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_New() *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Invoke_O__O(self any) any { var root_753 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = A_arbace_spec_gen_alpha_A_const_95; if linked_754 == nil { return ifn_755.Invoke_O__O(arg_756) } else { return linked_754.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_753, arg_756) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) DoInvoke_O_O__O(self, args__1 any) any { var root_757 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = t.F_g__1067000179__auto__; if linked_758 == nil { return ifn_759.Invoke_O__O(arg_760) } else { return linked_758.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_757, arg_760) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_New() *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Invoke_O__O(self any) any { var root_761 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_spec_gen_alpha_A_const_96; if linked_762 == nil { return ifn_763.Invoke_O__O(arg_764) } else { return linked_762.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_761, arg_764) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) DoInvoke_O_O__O(self, args__1 any) any { var root_765 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = t.F_g__1067000179__auto__; if linked_766 == nil { return ifn_767.Invoke_O__O(arg_768) } else { return linked_766.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_765, arg_768) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_New() *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Invoke_O__O(self any) any { var root_769 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_spec_gen_alpha_A_const_97; if linked_770 == nil { return ifn_771.Invoke_O__O(arg_772) } else { return linked_770.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_769, arg_772) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) DoInvoke_O_O__O(self, args__1 any) any { var root_773 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = t.F_g__1067000179__auto__; if linked_774 == nil { return ifn_775.Invoke_O__O(arg_776) } else { return linked_774.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_773, arg_776) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_New() *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Invoke_O__O(self any) any { var root_777 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = A_arbace_spec_gen_alpha_A_const_98; if linked_778 == nil { return ifn_779.Invoke_O__O(arg_780) } else { return linked_778.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_777, arg_780) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) DoInvoke_O_O__O(self, args__1 any) any { var root_781 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = t.F_g__1067000179__auto__; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_781, arg_784) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_New() *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Invoke_O__O(self any) any { var root_785 any = A_arbace_spec_gen_alpha_A_const_16.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_spec_gen_alpha_dynaload_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = A_arbace_spec_gen_alpha_A_const_99; if linked_786 == nil { return ifn_787.Invoke_O__O(arg_788) } else { return linked_786.(*A_arbace_spec_gen_alpha_dynaload_A).Invoke_O_O__O(root_785, arg_788) } }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) DoInvoke_O_O__O(self, args__1 any) any { var root_789 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = t.F_g__1067000179__auto__; if linked_790 == nil { return ifn_791.Invoke_O__O(arg_792) } else { return linked_790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_789, arg_792) } }



func A_arbace_spec_gen_alpha_cat_A_New() *A_arbace_spec_gen_alpha_cat_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_cat_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_spec_gen_alpha_cat_A) Ctor() {}
//line :128:1
func (t *A_arbace_spec_gen_alpha_cat_A) DoInvoke_O_O__O(self, gens__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_New(); var tmp3 *jrt.Class; var fncls__798 *jrt.Class = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class; if fncls__798 == nil { var fncls__798d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class = fncls__798d; tmp3 = fncls__798d } else { tmp3 = fncls__798 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; var root_799 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_801 lang.IFn
	if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = A_arbace_spec_gen_alpha_A_const_101.GetRawRoot__O(); var arg_803 any = gens__0; if linked_800 == nil { tmp5 = ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { tmp5 = linked_800.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) }
//line :132:1
	return tmp1.Invoke_O_O__O(tmp4, tmp5) }
//line :132:1
func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_New() *A_arbace_spec_gen_alpha_cat_fn__1067000325_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_cat_fn__1067000325_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Ctor() {}
//line :132:1
func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Invoke_O_O__O(self, p1__1067000324_SHARP___1 any) any { var root_793 any = A_arbace_spec_gen_alpha_A_const_18.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = A_arbace_spec_gen_alpha_A_const_28.GetRawRoot__O(); var arg_797 any = p1__1067000324_SHARP___1; if linked_794 == nil { return ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { return linked_794.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) } }


func A_arbace_spec_gen_alpha_qualified_QMARK__A_New() *A_arbace_spec_gen_alpha_qualified_QMARK__A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_qualified_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Invoke_O_O__O(self, ident__0 any) any { var root_813 any = A_arbace_spec_gen_alpha_A_const_102.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any; var tmp1 any; var root_809 any = A_arbace_spec_gen_alpha_A_const_9.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = ident__0; if linked_810 == nil { tmp1 = ifn_811.Invoke_O__O(arg_812) } else { tmp1 = linked_810.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_809, arg_812) }; arg_816 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, nil)).Ref(); if linked_814 == nil { return ifn_815.Invoke_O__O(arg_816) } else { return linked_814.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_813, arg_816) } }



func A_arbace_spec_gen_alpha_fn__1067000332_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Ctor() {}
//line :139:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Invoke_O__O(self any) any { var simple__1 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_103.GetRawRoot__O()).Invoke__O(); var tmp1 any = A_arbace_spec_gen_alpha_A_const_104.GetRawRoot__O(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_New(); var tmp4 *jrt.Class; var fncls__820 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class; if
























	fncls__820 == nil { var fncls__820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class = fncls__820d; tmp4 = fncls__820d } else { tmp4 = fncls__820 }; var tmp5 any = /*line :139:1*/tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_106.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_107)); var tmp6 any = A_arbace_spec_gen_alpha_A_const_108.GetRawRoot__O(); var tmp7 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_110.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_111.GetRawRoot__O()).Invoke__O()); var tmp8 any = A_arbace_spec_gen_alpha_A_const_112.GetRawRoot__O(); var tmp9 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(simple__1); var tmp10 any = A_arbace_spec_gen_alpha_A_const_114.GetRawRoot__O(); var tmp11 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1); var tmp12 any = A_arbace_spec_gen_alpha_A_const_116.GetRawRoot__O(); var tmp13 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(nil), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_119.GetRawRoot__O()).Invoke__O())); var tmp14 any = A_arbace_spec_gen_alpha_A_const_120.GetRawRoot__O(); var tmp15 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_121.GetRawRoot__O()).Invoke__O(); var tmp16 any = A_arbace_spec_gen_alpha_A_const_122.GetRawRoot__O(); var tmp17 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_123.GetRawRoot__O()).Invoke__O(); var tmp18 any = A_arbace_spec_gen_alpha_A_const_124.GetRawRoot__O(); var tmp19 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_124.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_119.GetRawRoot__O()).Invoke__O()); var tmp20 any = A_arbace_spec_gen_alpha_A_const_125.GetRawRoot__O(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_100.GetRawRoot__O()); var tmp22 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_New(); var tmp23 *jrt.Class; var fncls__871 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class; if


























	fncls__871 == nil { var fncls__871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class = fncls__871d; tmp23 = fncls__871d } else { tmp23 = fncls__871 }; var tmp24 any = /*line :139:1*/tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_126.GetRawRoot__O()).Invoke__O()); var tmp25 any = A_arbace_spec_gen_alpha_A_const_127.GetRawRoot__O(); var tmp26 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_128.GetRawRoot__O()).Invoke__O(); var tmp27 any = A_arbace_spec_gen_alpha_A_const_129.GetRawRoot__O(); var tmp28 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1))); var tmp29 any = A_arbace_spec_gen_alpha_A_const_130.GetRawRoot__O(); var tmp30 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_131.GetRawRoot__O()).Invoke__O(); var tmp31 any = A_arbace_spec_gen_alpha_A_const_132.GetRawRoot__O(); var tmp32 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(simple__1); var tmp33 any = A_arbace_spec_gen_alpha_A_const_134.GetRawRoot__O(); var tmp34 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_135.GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1); var tmp35 any = A_arbace_spec_gen_alpha_A_const_136.GetRawRoot__O(); var tmp36 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(nil, lang.PersistentList_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref(), lang.PersistentArrayMap_EMPTY.Ref(), lang.PersistentHashSet_EMPTY.Ref())); var tmp37 any = A_arbace_spec_gen_alpha_A_const_138.GetRawRoot__O(); var tmp38 any = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_139.GetRawRoot__O()).Invoke__O(); var tmp39 any = A_arbace_spec_gen_alpha_A_const_140.GetRawRoot__O(); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_100.GetRawRoot__O()); var tmp41 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_New(); var tmp42 *jrt.Class; var fncls__914 *jrt.Class = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class; if























	fncls__914 == nil { var fncls__914d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class = fncls__914d; tmp42 = fncls__914d } else { tmp42 = fncls__914 }; return /*line :139:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_141.GetRawRoot__O()).Invoke__O()), A_arbace_spec_gen_alpha_A_const_142.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_131.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_143.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_126.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_144.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_135.GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1))), A_arbace_spec_gen_alpha_A_const_145.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_111.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1), A_arbace_spec_gen_alpha_A_const_147.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_148), A_arbace_spec_gen_alpha_A_const_149.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_150.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_151.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_153), A_arbace_spec_gen_alpha_A_const_154.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(nil), A_arbace_spec_gen_alpha_A_const_155.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_156.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_157.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_111.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_158.GetRawRoot__O()).Invoke__O())), A_arbace_spec_gen_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_110.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_111.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_158.GetRawRoot__O()).Invoke__O()))), A_arbace_spec_gen_alpha_A_const_160.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()), A_arbace_spec_gen_alpha_A_const_161.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_126.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_162.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_162.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_163.GetRawRoot__O()).Invoke__O()), A_arbace_spec_gen_alpha_A_const_164.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_165), A_arbace_spec_gen_alpha_A_const_166.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_gen_alpha_A_const_167), A_arbace_spec_gen_alpha_A_const_168.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_141.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_169.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_FALSE.Ref()), A_arbace_spec_gen_alpha_A_const_170.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(simple__1), A_arbace_spec_gen_alpha_A_const_171.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_150.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_128.GetRawRoot__O()).Invoke__O())), A_arbace_spec_gen_alpha_A_const_172.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_126.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_163.GetRawRoot__O()).Invoke__O())), A_arbace_spec_gen_alpha_A_const_173.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_126.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_131.GetRawRoot__O()).Invoke__O())), A_arbace_spec_gen_alpha_A_const_174.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_gen_alpha_A_const_110.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_158.GetRawRoot__O()).Invoke__O()), A_arbace_spec_gen_alpha_A_const_175.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(nil), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_135.GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_139.GetRawRoot__O()).Invoke__O())), A_arbace_spec_gen_alpha_A_const_176.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_158.GetRawRoot__O()).Invoke__O(), A_arbace_spec_gen_alpha_A_const_177.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_135.GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_115.GetRawRoot__O()).Invoke_O__O(simple__1), lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(simple__1))))) }























func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Ctor() {}
//line :163:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Invoke_O_O__O(self, p1__1067000329_SHARP___1 any) any { return jrt.URI_Create_String__URI(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, nil, p1__1067000329_SHARP___1, nil))).Ref() }
func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Ctor() {}
//line :164:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Invoke_O_O__O(self, p1__1067000330_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_spec_gen_alpha_A_const_105; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_10, jrt.RefArrayOf(jrt.Object_class, p1__1067000330_SHARP___1)) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Ctor() {}
//line :166:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Invoke_O_O__O(self, p1__1067000331_SHARP___1 any) any { return jrt.Date_New_J(lang.RT_LongCast_O__J_NoInit(p1__1067000331_SHARP___1)) }





























func A_arbace_spec_gen_alpha_gen_for_pred_A_New() *A_arbace_spec_gen_alpha_gen_for_pred_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_gen_for_pred_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Ctor() {}
//line :196:1
func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Invoke_O_O__O(self, pred__0 any) any {


	var tmp1 any; var root_1116 any = A_arbace_spec_gen_alpha_A_const_132.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = pred__0; if linked_1117 == nil { tmp1 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp1 = linked_1117.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1116, arg_1119) }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_spec_gen_alpha_A_const_137.GetRawRoot__O()).Invoke_O__O(pred__0) } else {
			var tmp2 any; var root_1124 any = A_arbace_spec_gen_alpha_A_const_5.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_spec_gen_alpha_A_const_178.GetRawRoot__O(); if linked_1125 == nil { tmp2 = ifn_1126.Invoke_O__O(arg_1127) } else { tmp2 = linked_1125.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1124, arg_1127) }; return lang.RT_Get_O_O__O_NoInit(tmp2, pred__0)
		}
}



























































































































































































































































































































































































































































































































type A_arbace_spec_gen_alpha_A struct{ jrt.Object }

var A_arbace_spec_gen_alpha_A_const_pool *jrt.RefArray

var A_arbace_spec_gen_alpha_A_const_0 *lang.Var

var A_arbace_spec_gen_alpha_A_const_1 any

var A_arbace_spec_gen_alpha_A_const_2 *lang.Keyword

var A_arbace_spec_gen_alpha_A_const_3 any

var A_arbace_spec_gen_alpha_A_const_4 *lang.Var

var A_arbace_spec_gen_alpha_A_const_5 *lang.Var

var A_arbace_spec_gen_alpha_A_const_6 *lang.Var

var A_arbace_spec_gen_alpha_A_const_7 *lang.Var

var A_arbace_spec_gen_alpha_A_const_8 any

var A_arbace_spec_gen_alpha_A_const_9 *lang.Var

var A_arbace_spec_gen_alpha_A_const_10 *lang.Var

var A_arbace_spec_gen_alpha_A_const_11 *lang.Var

var A_arbace_spec_gen_alpha_A_const_12 any

var A_arbace_spec_gen_alpha_A_const_13 *lang.Var

var A_arbace_spec_gen_alpha_A_const_14 *lang.Var

var A_arbace_spec_gen_alpha_A_const_15 *lang.Var

var A_arbace_spec_gen_alpha_A_const_16 *lang.Var

var A_arbace_spec_gen_alpha_A_const_17 any

var A_arbace_spec_gen_alpha_A_const_18 *lang.Var

var A_arbace_spec_gen_alpha_A_const_19 *lang.Var

var A_arbace_spec_gen_alpha_A_const_20 any

var A_arbace_spec_gen_alpha_A_const_21 *lang.Var

var A_arbace_spec_gen_alpha_A_const_22 any

var A_arbace_spec_gen_alpha_A_const_23 any

var A_arbace_spec_gen_alpha_A_const_24 any

var A_arbace_spec_gen_alpha_A_const_25 *lang.Var

var A_arbace_spec_gen_alpha_A_const_26 *lang.Keyword

var A_arbace_spec_gen_alpha_A_const_27 *lang.Var

var A_arbace_spec_gen_alpha_A_const_28 *lang.Var

var A_arbace_spec_gen_alpha_A_const_29 *lang.Var

var A_arbace_spec_gen_alpha_A_const_30 any

var A_arbace_spec_gen_alpha_A_const_31 any

var A_arbace_spec_gen_alpha_A_const_32 *lang.Var

var A_arbace_spec_gen_alpha_A_const_33 *lang.Var

var A_arbace_spec_gen_alpha_A_const_34 any

var A_arbace_spec_gen_alpha_A_const_35 *lang.Var

var A_arbace_spec_gen_alpha_A_const_36 any

var A_arbace_spec_gen_alpha_A_const_37 any

var A_arbace_spec_gen_alpha_A_const_38 any

var A_arbace_spec_gen_alpha_A_const_39 any

var A_arbace_spec_gen_alpha_A_const_40 any

var A_arbace_spec_gen_alpha_A_const_41 any

var A_arbace_spec_gen_alpha_A_const_42 any

var A_arbace_spec_gen_alpha_A_const_43 any

var A_arbace_spec_gen_alpha_A_const_44 any

var A_arbace_spec_gen_alpha_A_const_45 any

var A_arbace_spec_gen_alpha_A_const_46 any

var A_arbace_spec_gen_alpha_A_const_47 *lang.Var

var A_arbace_spec_gen_alpha_A_const_48 any

var A_arbace_spec_gen_alpha_A_const_49 any

var A_arbace_spec_gen_alpha_A_const_50 any

var A_arbace_spec_gen_alpha_A_const_51 any

var A_arbace_spec_gen_alpha_A_const_52 any

var A_arbace_spec_gen_alpha_A_const_53 any

var A_arbace_spec_gen_alpha_A_const_54 any

var A_arbace_spec_gen_alpha_A_const_55 any

var A_arbace_spec_gen_alpha_A_const_56 any

var A_arbace_spec_gen_alpha_A_const_57 any

var A_arbace_spec_gen_alpha_A_const_58 any

var A_arbace_spec_gen_alpha_A_const_59 any

var A_arbace_spec_gen_alpha_A_const_60 any

var A_arbace_spec_gen_alpha_A_const_61 any

var A_arbace_spec_gen_alpha_A_const_62 any

var A_arbace_spec_gen_alpha_A_const_63 any

var A_arbace_spec_gen_alpha_A_const_64 any

var A_arbace_spec_gen_alpha_A_const_65 any

var A_arbace_spec_gen_alpha_A_const_66 any

var A_arbace_spec_gen_alpha_A_const_67 any

var A_arbace_spec_gen_alpha_A_const_68 any

var A_arbace_spec_gen_alpha_A_const_69 any

var A_arbace_spec_gen_alpha_A_const_70 any

var A_arbace_spec_gen_alpha_A_const_71 any

var A_arbace_spec_gen_alpha_A_const_72 any

var A_arbace_spec_gen_alpha_A_const_73 any

var A_arbace_spec_gen_alpha_A_const_74 any

var A_arbace_spec_gen_alpha_A_const_75 any

var A_arbace_spec_gen_alpha_A_const_76 any

var A_arbace_spec_gen_alpha_A_const_77 any

var A_arbace_spec_gen_alpha_A_const_78 any

var A_arbace_spec_gen_alpha_A_const_79 any

var A_arbace_spec_gen_alpha_A_const_80 any

var A_arbace_spec_gen_alpha_A_const_81 any

var A_arbace_spec_gen_alpha_A_const_82 any

var A_arbace_spec_gen_alpha_A_const_83 any

var A_arbace_spec_gen_alpha_A_const_84 any

var A_arbace_spec_gen_alpha_A_const_85 any

var A_arbace_spec_gen_alpha_A_const_86 any

var A_arbace_spec_gen_alpha_A_const_87 any

var A_arbace_spec_gen_alpha_A_const_88 any

var A_arbace_spec_gen_alpha_A_const_89 any

var A_arbace_spec_gen_alpha_A_const_90 any

var A_arbace_spec_gen_alpha_A_const_91 any

var A_arbace_spec_gen_alpha_A_const_92 any

var A_arbace_spec_gen_alpha_A_const_93 any

var A_arbace_spec_gen_alpha_A_const_94 any

var A_arbace_spec_gen_alpha_A_const_95 any

var A_arbace_spec_gen_alpha_A_const_96 any

var A_arbace_spec_gen_alpha_A_const_97 any

var A_arbace_spec_gen_alpha_A_const_98 any

var A_arbace_spec_gen_alpha_A_const_99 any

var A_arbace_spec_gen_alpha_A_const_100 *lang.Var

var A_arbace_spec_gen_alpha_A_const_101 *lang.Var

var A_arbace_spec_gen_alpha_A_const_102 *lang.Var

var A_arbace_spec_gen_alpha_A_const_103 *lang.Var

var A_arbace_spec_gen_alpha_A_const_104 *lang.Var

var A_arbace_spec_gen_alpha_A_const_105 *jrt.Class

var A_arbace_spec_gen_alpha_A_const_106 *lang.Var

var A_arbace_spec_gen_alpha_A_const_107 any

var A_arbace_spec_gen_alpha_A_const_108 *lang.Var

var A_arbace_spec_gen_alpha_A_const_109 *lang.Var

var A_arbace_spec_gen_alpha_A_const_110 *lang.Var

var A_arbace_spec_gen_alpha_A_const_111 *lang.Var

var A_arbace_spec_gen_alpha_A_const_112 *lang.Var

var A_arbace_spec_gen_alpha_A_const_113 *lang.Var

var A_arbace_spec_gen_alpha_A_const_114 *lang.Var

var A_arbace_spec_gen_alpha_A_const_115 *lang.Var

var A_arbace_spec_gen_alpha_A_const_116 *lang.Var

var A_arbace_spec_gen_alpha_A_const_117 *lang.Var

var A_arbace_spec_gen_alpha_A_const_118 *lang.Var

var A_arbace_spec_gen_alpha_A_const_119 *lang.Var

var A_arbace_spec_gen_alpha_A_const_120 *lang.Var

var A_arbace_spec_gen_alpha_A_const_121 *lang.Var

var A_arbace_spec_gen_alpha_A_const_122 *lang.Var

var A_arbace_spec_gen_alpha_A_const_123 *lang.Var

var A_arbace_spec_gen_alpha_A_const_124 *lang.Var

var A_arbace_spec_gen_alpha_A_const_125 *lang.Var

var A_arbace_spec_gen_alpha_A_const_126 *lang.Var

var A_arbace_spec_gen_alpha_A_const_127 *lang.Var

var A_arbace_spec_gen_alpha_A_const_128 *lang.Var

var A_arbace_spec_gen_alpha_A_const_129 *lang.Var

var A_arbace_spec_gen_alpha_A_const_130 *lang.Var

var A_arbace_spec_gen_alpha_A_const_131 *lang.Var

var A_arbace_spec_gen_alpha_A_const_132 *lang.Var

var A_arbace_spec_gen_alpha_A_const_133 *lang.Var

var A_arbace_spec_gen_alpha_A_const_134 *lang.Var

var A_arbace_spec_gen_alpha_A_const_135 *lang.Var

var A_arbace_spec_gen_alpha_A_const_136 *lang.Var

var A_arbace_spec_gen_alpha_A_const_137 *lang.Var

var A_arbace_spec_gen_alpha_A_const_138 *lang.Var

var A_arbace_spec_gen_alpha_A_const_139 *lang.Var

var A_arbace_spec_gen_alpha_A_const_140 *lang.Var

var A_arbace_spec_gen_alpha_A_const_141 *lang.Var

var A_arbace_spec_gen_alpha_A_const_142 *lang.Var

var A_arbace_spec_gen_alpha_A_const_143 *lang.Var

var A_arbace_spec_gen_alpha_A_const_144 *lang.Var

var A_arbace_spec_gen_alpha_A_const_145 *lang.Var

var A_arbace_spec_gen_alpha_A_const_146 *lang.Var

var A_arbace_spec_gen_alpha_A_const_147 *lang.Var

var A_arbace_spec_gen_alpha_A_const_148 any

var A_arbace_spec_gen_alpha_A_const_149 *lang.Var

var A_arbace_spec_gen_alpha_A_const_150 *lang.Var

var A_arbace_spec_gen_alpha_A_const_151 *lang.Var

var A_arbace_spec_gen_alpha_A_const_152 *lang.Var

var A_arbace_spec_gen_alpha_A_const_153 any

var A_arbace_spec_gen_alpha_A_const_154 *lang.Var

var A_arbace_spec_gen_alpha_A_const_155 *lang.Var

var A_arbace_spec_gen_alpha_A_const_156 *lang.Var

var A_arbace_spec_gen_alpha_A_const_157 *lang.Var

var A_arbace_spec_gen_alpha_A_const_158 *lang.Var

var A_arbace_spec_gen_alpha_A_const_159 *lang.Var

var A_arbace_spec_gen_alpha_A_const_160 *lang.Var

var A_arbace_spec_gen_alpha_A_const_161 *lang.Var

var A_arbace_spec_gen_alpha_A_const_162 *lang.Var

var A_arbace_spec_gen_alpha_A_const_163 *lang.Var

var A_arbace_spec_gen_alpha_A_const_164 *lang.Var

var A_arbace_spec_gen_alpha_A_const_165 any

var A_arbace_spec_gen_alpha_A_const_166 *lang.Var

var A_arbace_spec_gen_alpha_A_const_167 any

var A_arbace_spec_gen_alpha_A_const_168 *lang.Var

var A_arbace_spec_gen_alpha_A_const_169 *lang.Var

var A_arbace_spec_gen_alpha_A_const_170 *lang.Var

var A_arbace_spec_gen_alpha_A_const_171 *lang.Var

var A_arbace_spec_gen_alpha_A_const_172 *lang.Var

var A_arbace_spec_gen_alpha_A_const_173 *lang.Var

var A_arbace_spec_gen_alpha_A_const_174 *lang.Var

var A_arbace_spec_gen_alpha_A_const_175 *lang.Var

var A_arbace_spec_gen_alpha_A_const_176 *lang.Var

var A_arbace_spec_gen_alpha_A_const_177 *lang.Var

var A_arbace_spec_gen_alpha_A_const_178 *lang.Var

var A_arbace_spec_gen_alpha_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_A_Init() { if !A_arbace_spec_gen_alpha_A_init.Done() { A_arbace_spec_gen_alpha_A_init.Run(A_arbace_spec_gen_alpha_A_clinit) } }

func A_arbace_spec_gen_alpha_A_clinit() { A_arbace_spec_gen_alpha_A_clinit_p0(); A_arbace_spec_gen_alpha_A_clinit_p1(); A_arbace_spec_gen_alpha_A_clinit_p2(); A_arbace_spec_gen_alpha_A_clinit_p3(); A_arbace_spec_gen_alpha_A_clinit_p4(); A_arbace_spec_gen_alpha_A_clinit_p5(); A_arbace_spec_gen_alpha_A_clinit_p6(); A_arbace_spec_gen_alpha_A_clinit_p7(); A_arbace_spec_gen_alpha_A_clinit_p8(); A_arbace_spec_gen_alpha_A_clinit_p9(); A_arbace_spec_gen_alpha_A_clinit_p10(); A_arbace_spec_gen_alpha_A_clinit_p11(); A_arbace_spec_gen_alpha_A_clinit_p12(); A_arbace_spec_gen_alpha_A_clinit_p13() }

func A_arbace_spec_gen_alpha_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_gen_alpha_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 269); A_arbace_spec_gen_alpha_A_const_0 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[90]); A_arbace_spec_gen_alpha_A_const_1 = A_arbace_spec_gen_alpha_A_const_pool.A[91]; A_arbace_spec_gen_alpha_A_const_2 = lang.Keyword_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[92]); A_arbace_spec_gen_alpha_A_const_3 = A_arbace_spec_gen_alpha_A_const_pool.A[93]; A_arbace_spec_gen_alpha_A_const_4 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[94]); A_arbace_spec_gen_alpha_A_const_5 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[95]); A_arbace_spec_gen_alpha_A_const_6 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[96]); A_arbace_spec_gen_alpha_A_const_7 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[97]); A_arbace_spec_gen_alpha_A_const_8 = A_arbace_spec_gen_alpha_A_const_pool.A[98]; A_arbace_spec_gen_alpha_A_const_9 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[99]); A_arbace_spec_gen_alpha_A_const_10 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[100]); A_arbace_spec_gen_alpha_A_const_11 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[101]) }

func A_arbace_spec_gen_alpha_A_clinit_p1() { A_arbace_spec_gen_alpha_A_const_12 = A_arbace_spec_gen_alpha_A_const_pool.A[102]; A_arbace_spec_gen_alpha_A_const_13 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[103]); A_arbace_spec_gen_alpha_A_const_14 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[104]); A_arbace_spec_gen_alpha_A_const_15 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[105]); A_arbace_spec_gen_alpha_A_const_16 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[106]); A_arbace_spec_gen_alpha_A_const_17 = A_arbace_spec_gen_alpha_A_const_pool.A[107]; A_arbace_spec_gen_alpha_A_const_18 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[108]); A_arbace_spec_gen_alpha_A_const_19 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[109]); A_arbace_spec_gen_alpha_A_const_20 = A_arbace_spec_gen_alpha_A_const_pool.A[110]; A_arbace_spec_gen_alpha_A_const_21 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[111]); A_arbace_spec_gen_alpha_A_const_22 = A_arbace_spec_gen_alpha_A_const_pool.A[112]; A_arbace_spec_gen_alpha_A_const_23 = A_arbace_spec_gen_alpha_A_const_pool.A[113]; A_arbace_spec_gen_alpha_A_const_24 = A_arbace_spec_gen_alpha_A_const_pool.A[114] }

func A_arbace_spec_gen_alpha_A_clinit_p2() { A_arbace_spec_gen_alpha_A_const_25 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[115]); A_arbace_spec_gen_alpha_A_const_26 = lang.Keyword_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[116]); A_arbace_spec_gen_alpha_A_const_27 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[117]); A_arbace_spec_gen_alpha_A_const_28 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[118]); A_arbace_spec_gen_alpha_A_const_29 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[119]); A_arbace_spec_gen_alpha_A_const_30 = A_arbace_spec_gen_alpha_A_const_pool.A[120]; A_arbace_spec_gen_alpha_A_const_31 = A_arbace_spec_gen_alpha_A_const_pool.A[121]; A_arbace_spec_gen_alpha_A_const_32 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[122]); A_arbace_spec_gen_alpha_A_const_33 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[123]); A_arbace_spec_gen_alpha_A_const_34 = A_arbace_spec_gen_alpha_A_const_pool.A[124]; A_arbace_spec_gen_alpha_A_const_35 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[125]); A_arbace_spec_gen_alpha_A_const_36 = A_arbace_spec_gen_alpha_A_const_pool.A[126]; A_arbace_spec_gen_alpha_A_const_37 = A_arbace_spec_gen_alpha_A_const_pool.A[127] }

func A_arbace_spec_gen_alpha_A_clinit_p3() { A_arbace_spec_gen_alpha_A_const_38 = A_arbace_spec_gen_alpha_A_const_pool.A[128]; A_arbace_spec_gen_alpha_A_const_39 = A_arbace_spec_gen_alpha_A_const_pool.A[129]; A_arbace_spec_gen_alpha_A_const_40 = A_arbace_spec_gen_alpha_A_const_pool.A[130]; A_arbace_spec_gen_alpha_A_const_41 = A_arbace_spec_gen_alpha_A_const_pool.A[131]; A_arbace_spec_gen_alpha_A_const_42 = A_arbace_spec_gen_alpha_A_const_pool.A[132]; A_arbace_spec_gen_alpha_A_const_43 = A_arbace_spec_gen_alpha_A_const_pool.A[133]; A_arbace_spec_gen_alpha_A_const_44 = A_arbace_spec_gen_alpha_A_const_pool.A[134]; A_arbace_spec_gen_alpha_A_const_45 = A_arbace_spec_gen_alpha_A_const_pool.A[135]; A_arbace_spec_gen_alpha_A_const_46 = A_arbace_spec_gen_alpha_A_const_pool.A[136]; A_arbace_spec_gen_alpha_A_const_47 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[137]); A_arbace_spec_gen_alpha_A_const_48 = A_arbace_spec_gen_alpha_A_const_pool.A[138]; A_arbace_spec_gen_alpha_A_const_49 = A_arbace_spec_gen_alpha_A_const_pool.A[139]; A_arbace_spec_gen_alpha_A_const_50 = A_arbace_spec_gen_alpha_A_const_pool.A[140]; A_arbace_spec_gen_alpha_A_const_51 = A_arbace_spec_gen_alpha_A_const_pool.A[141]; A_arbace_spec_gen_alpha_A_const_52 = A_arbace_spec_gen_alpha_A_const_pool.A[142] }

func A_arbace_spec_gen_alpha_A_clinit_p4() { A_arbace_spec_gen_alpha_A_const_53 = A_arbace_spec_gen_alpha_A_const_pool.A[143]; A_arbace_spec_gen_alpha_A_const_54 = A_arbace_spec_gen_alpha_A_const_pool.A[144]; A_arbace_spec_gen_alpha_A_const_55 = A_arbace_spec_gen_alpha_A_const_pool.A[145]; A_arbace_spec_gen_alpha_A_const_56 = A_arbace_spec_gen_alpha_A_const_pool.A[146]; A_arbace_spec_gen_alpha_A_const_57 = A_arbace_spec_gen_alpha_A_const_pool.A[147]; A_arbace_spec_gen_alpha_A_const_58 = A_arbace_spec_gen_alpha_A_const_pool.A[148]; A_arbace_spec_gen_alpha_A_const_59 = A_arbace_spec_gen_alpha_A_const_pool.A[149]; A_arbace_spec_gen_alpha_A_const_60 = A_arbace_spec_gen_alpha_A_const_pool.A[150]; A_arbace_spec_gen_alpha_A_const_61 = A_arbace_spec_gen_alpha_A_const_pool.A[151]; A_arbace_spec_gen_alpha_A_const_62 = A_arbace_spec_gen_alpha_A_const_pool.A[152]; A_arbace_spec_gen_alpha_A_const_63 = A_arbace_spec_gen_alpha_A_const_pool.A[153]; A_arbace_spec_gen_alpha_A_const_64 = A_arbace_spec_gen_alpha_A_const_pool.A[154]; A_arbace_spec_gen_alpha_A_const_65 = A_arbace_spec_gen_alpha_A_const_pool.A[155]; A_arbace_spec_gen_alpha_A_const_66 = A_arbace_spec_gen_alpha_A_const_pool.A[156]; A_arbace_spec_gen_alpha_A_const_67 = A_arbace_spec_gen_alpha_A_const_pool.A[157]; A_arbace_spec_gen_alpha_A_const_68 = A_arbace_spec_gen_alpha_A_const_pool.A[158] }

func A_arbace_spec_gen_alpha_A_clinit_p5() { A_arbace_spec_gen_alpha_A_const_69 = A_arbace_spec_gen_alpha_A_const_pool.A[159]; A_arbace_spec_gen_alpha_A_const_70 = A_arbace_spec_gen_alpha_A_const_pool.A[160]; A_arbace_spec_gen_alpha_A_const_71 = A_arbace_spec_gen_alpha_A_const_pool.A[161]; A_arbace_spec_gen_alpha_A_const_72 = A_arbace_spec_gen_alpha_A_const_pool.A[162]; A_arbace_spec_gen_alpha_A_const_73 = A_arbace_spec_gen_alpha_A_const_pool.A[163]; A_arbace_spec_gen_alpha_A_const_74 = A_arbace_spec_gen_alpha_A_const_pool.A[164]; A_arbace_spec_gen_alpha_A_const_75 = A_arbace_spec_gen_alpha_A_const_pool.A[165]; A_arbace_spec_gen_alpha_A_const_76 = A_arbace_spec_gen_alpha_A_const_pool.A[166]; A_arbace_spec_gen_alpha_A_const_77 = A_arbace_spec_gen_alpha_A_const_pool.A[167]; A_arbace_spec_gen_alpha_A_const_78 = A_arbace_spec_gen_alpha_A_const_pool.A[168]; A_arbace_spec_gen_alpha_A_const_79 = A_arbace_spec_gen_alpha_A_const_pool.A[169]; A_arbace_spec_gen_alpha_A_const_80 = A_arbace_spec_gen_alpha_A_const_pool.A[170]; A_arbace_spec_gen_alpha_A_const_81 = A_arbace_spec_gen_alpha_A_const_pool.A[171]; A_arbace_spec_gen_alpha_A_const_82 = A_arbace_spec_gen_alpha_A_const_pool.A[172]; A_arbace_spec_gen_alpha_A_const_83 = A_arbace_spec_gen_alpha_A_const_pool.A[173]; A_arbace_spec_gen_alpha_A_const_84 = A_arbace_spec_gen_alpha_A_const_pool.A[174] }

func A_arbace_spec_gen_alpha_A_clinit_p6() { A_arbace_spec_gen_alpha_A_const_85 = A_arbace_spec_gen_alpha_A_const_pool.A[175]; A_arbace_spec_gen_alpha_A_const_86 = A_arbace_spec_gen_alpha_A_const_pool.A[176]; A_arbace_spec_gen_alpha_A_const_87 = A_arbace_spec_gen_alpha_A_const_pool.A[177]; A_arbace_spec_gen_alpha_A_const_88 = A_arbace_spec_gen_alpha_A_const_pool.A[178]; A_arbace_spec_gen_alpha_A_const_89 = A_arbace_spec_gen_alpha_A_const_pool.A[179]; A_arbace_spec_gen_alpha_A_const_90 = A_arbace_spec_gen_alpha_A_const_pool.A[180]; A_arbace_spec_gen_alpha_A_const_91 = A_arbace_spec_gen_alpha_A_const_pool.A[181]; A_arbace_spec_gen_alpha_A_const_92 = A_arbace_spec_gen_alpha_A_const_pool.A[182]; A_arbace_spec_gen_alpha_A_const_93 = A_arbace_spec_gen_alpha_A_const_pool.A[183]; A_arbace_spec_gen_alpha_A_const_94 = A_arbace_spec_gen_alpha_A_const_pool.A[184]; A_arbace_spec_gen_alpha_A_const_95 = A_arbace_spec_gen_alpha_A_const_pool.A[185]; A_arbace_spec_gen_alpha_A_const_96 = A_arbace_spec_gen_alpha_A_const_pool.A[186]; A_arbace_spec_gen_alpha_A_const_97 = A_arbace_spec_gen_alpha_A_const_pool.A[187]; A_arbace_spec_gen_alpha_A_const_98 = A_arbace_spec_gen_alpha_A_const_pool.A[188]; A_arbace_spec_gen_alpha_A_const_99 = A_arbace_spec_gen_alpha_A_const_pool.A[189] }

func A_arbace_spec_gen_alpha_A_clinit_p7() { A_arbace_spec_gen_alpha_A_const_100 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[190]); A_arbace_spec_gen_alpha_A_const_101 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[191]); A_arbace_spec_gen_alpha_A_const_102 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[192]); A_arbace_spec_gen_alpha_A_const_103 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[193]); A_arbace_spec_gen_alpha_A_const_104 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[194]); A_arbace_spec_gen_alpha_A_const_105 = jrt.Class_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[195]); A_arbace_spec_gen_alpha_A_const_106 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[196]); A_arbace_spec_gen_alpha_A_const_107 = A_arbace_spec_gen_alpha_A_const_pool.A[197]; A_arbace_spec_gen_alpha_A_const_108 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[198]); A_arbace_spec_gen_alpha_A_const_109 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[199]); A_arbace_spec_gen_alpha_A_const_110 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[200]); A_arbace_spec_gen_alpha_A_const_111 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[201]) }

func A_arbace_spec_gen_alpha_A_clinit_p8() { A_arbace_spec_gen_alpha_A_const_112 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[202]); A_arbace_spec_gen_alpha_A_const_113 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[203]); A_arbace_spec_gen_alpha_A_const_114 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[204]); A_arbace_spec_gen_alpha_A_const_115 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[205]); A_arbace_spec_gen_alpha_A_const_116 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[206]); A_arbace_spec_gen_alpha_A_const_117 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[207]); A_arbace_spec_gen_alpha_A_const_118 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[208]); A_arbace_spec_gen_alpha_A_const_119 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[209]); A_arbace_spec_gen_alpha_A_const_120 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[210]); A_arbace_spec_gen_alpha_A_const_121 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[211]); A_arbace_spec_gen_alpha_A_const_122 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[212]); A_arbace_spec_gen_alpha_A_const_123 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[213]) }

func A_arbace_spec_gen_alpha_A_clinit_p9() { A_arbace_spec_gen_alpha_A_const_124 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[214]); A_arbace_spec_gen_alpha_A_const_125 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[215]); A_arbace_spec_gen_alpha_A_const_126 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[216]); A_arbace_spec_gen_alpha_A_const_127 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[217]); A_arbace_spec_gen_alpha_A_const_128 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[218]); A_arbace_spec_gen_alpha_A_const_129 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[219]); A_arbace_spec_gen_alpha_A_const_130 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[220]); A_arbace_spec_gen_alpha_A_const_131 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[221]); A_arbace_spec_gen_alpha_A_const_132 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[222]); A_arbace_spec_gen_alpha_A_const_133 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[223]); A_arbace_spec_gen_alpha_A_const_134 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[224]); A_arbace_spec_gen_alpha_A_const_135 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[225]) }

func A_arbace_spec_gen_alpha_A_clinit_p10() { A_arbace_spec_gen_alpha_A_const_136 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[226]); A_arbace_spec_gen_alpha_A_const_137 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[227]); A_arbace_spec_gen_alpha_A_const_138 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[228]); A_arbace_spec_gen_alpha_A_const_139 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[229]); A_arbace_spec_gen_alpha_A_const_140 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[230]); A_arbace_spec_gen_alpha_A_const_141 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[231]); A_arbace_spec_gen_alpha_A_const_142 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[232]); A_arbace_spec_gen_alpha_A_const_143 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[233]); A_arbace_spec_gen_alpha_A_const_144 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[234]); A_arbace_spec_gen_alpha_A_const_145 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[235]); A_arbace_spec_gen_alpha_A_const_146 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[236]); A_arbace_spec_gen_alpha_A_const_147 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[237]) }

func A_arbace_spec_gen_alpha_A_clinit_p11() { A_arbace_spec_gen_alpha_A_const_148 = A_arbace_spec_gen_alpha_A_const_pool.A[238]; A_arbace_spec_gen_alpha_A_const_149 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[239]); A_arbace_spec_gen_alpha_A_const_150 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[240]); A_arbace_spec_gen_alpha_A_const_151 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[241]); A_arbace_spec_gen_alpha_A_const_152 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[242]); A_arbace_spec_gen_alpha_A_const_153 = A_arbace_spec_gen_alpha_A_const_pool.A[243]; A_arbace_spec_gen_alpha_A_const_154 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[244]); A_arbace_spec_gen_alpha_A_const_155 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[245]); A_arbace_spec_gen_alpha_A_const_156 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[246]); A_arbace_spec_gen_alpha_A_const_157 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[247]); A_arbace_spec_gen_alpha_A_const_158 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[248]); A_arbace_spec_gen_alpha_A_const_159 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[249]) }

func A_arbace_spec_gen_alpha_A_clinit_p12() { A_arbace_spec_gen_alpha_A_const_160 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[250]); A_arbace_spec_gen_alpha_A_const_161 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[251]); A_arbace_spec_gen_alpha_A_const_162 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[252]); A_arbace_spec_gen_alpha_A_const_163 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[253]); A_arbace_spec_gen_alpha_A_const_164 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[254]); A_arbace_spec_gen_alpha_A_const_165 = A_arbace_spec_gen_alpha_A_const_pool.A[255]; A_arbace_spec_gen_alpha_A_const_166 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[256]); A_arbace_spec_gen_alpha_A_const_167 = A_arbace_spec_gen_alpha_A_const_pool.A[257]; A_arbace_spec_gen_alpha_A_const_168 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[258]); A_arbace_spec_gen_alpha_A_const_169 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[259]); A_arbace_spec_gen_alpha_A_const_170 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[260]); A_arbace_spec_gen_alpha_A_const_171 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[261]) }

func A_arbace_spec_gen_alpha_A_clinit_p13() { A_arbace_spec_gen_alpha_A_const_172 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[262]); A_arbace_spec_gen_alpha_A_const_173 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[263]); A_arbace_spec_gen_alpha_A_const_174 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[264]); A_arbace_spec_gen_alpha_A_const_175 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[265]); A_arbace_spec_gen_alpha_A_const_176 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[266]); A_arbace_spec_gen_alpha_A_const_177 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[267]); A_arbace_spec_gen_alpha_A_const_178 = lang.Var_Cast(A_arbace_spec_gen_alpha_A_const_pool.A[268]) }

func A_arbace_spec_gen_alpha_A_New() *A_arbace_spec_gen_alpha_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_A_class }

func (t *A_arbace_spec_gen_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_A); return ok }

func A_arbace_spec_gen_alpha_A_Cast(x any) *A_arbace_spec_gen_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_A_class)) }; return v }



type A_arbace_spec_gen_alpha_cat_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_cat_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_cat_fn__1067000325_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_delay_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_delay_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_delay_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_delay_impl_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A struct{ j2g_header uint64; F_gfnd any }

var A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_dynaload_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_dynaload_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A struct{ j2g_header uint64; F_lockee__1927000360__auto__, F_ns any }

var A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000002_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000002_A_New() *A_arbace_spec_gen_alpha_eval1067000002_A { t := &A_arbace_spec_gen_alpha_eval1067000002_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000002_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000002_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000002_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000006_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000006_A_New() *A_arbace_spec_gen_alpha_eval1067000006_A { t := &A_arbace_spec_gen_alpha_eval1067000006_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000006_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000006_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000006_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000023_A_New() *A_arbace_spec_gen_alpha_eval1067000023_A { t := &A_arbace_spec_gen_alpha_eval1067000023_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A struct{ j2g_header uint64; F_g any }

var A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A struct{ j2g_header uint64; F_g_QMARK_ any }

var A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A struct{ j2g_header uint64; F_mkg any }

var A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000059_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000059_A_New() *A_arbace_spec_gen_alpha_eval1067000059_A { t := &A_arbace_spec_gen_alpha_eval1067000059_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000059_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000059_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000059_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000065_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000065_A_New() *A_arbace_spec_gen_alpha_eval1067000065_A { t := &A_arbace_spec_gen_alpha_eval1067000065_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000065_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000065_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000065_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000071_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000071_A_New() *A_arbace_spec_gen_alpha_eval1067000071_A { t := &A_arbace_spec_gen_alpha_eval1067000071_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000071_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000071_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000071_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000077_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000077_A_New() *A_arbace_spec_gen_alpha_eval1067000077_A { t := &A_arbace_spec_gen_alpha_eval1067000077_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000077_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000077_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000077_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000083_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000083_A_New() *A_arbace_spec_gen_alpha_eval1067000083_A { t := &A_arbace_spec_gen_alpha_eval1067000083_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000083_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000083_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000083_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000083_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000083_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000089_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000089_A_New() *A_arbace_spec_gen_alpha_eval1067000089_A { t := &A_arbace_spec_gen_alpha_eval1067000089_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000089_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000089_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000089_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000095_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000095_A_New() *A_arbace_spec_gen_alpha_eval1067000095_A { t := &A_arbace_spec_gen_alpha_eval1067000095_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000095_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000095_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000095_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000101_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000101_A_New() *A_arbace_spec_gen_alpha_eval1067000101_A { t := &A_arbace_spec_gen_alpha_eval1067000101_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000101_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000101_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000101_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000107_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000107_A_New() *A_arbace_spec_gen_alpha_eval1067000107_A { t := &A_arbace_spec_gen_alpha_eval1067000107_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000107_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000107_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000107_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000113_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000113_A_New() *A_arbace_spec_gen_alpha_eval1067000113_A { t := &A_arbace_spec_gen_alpha_eval1067000113_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000113_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000113_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000113_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000119_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000119_A_New() *A_arbace_spec_gen_alpha_eval1067000119_A { t := &A_arbace_spec_gen_alpha_eval1067000119_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000119_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000119_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000119_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000125_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000125_A_New() *A_arbace_spec_gen_alpha_eval1067000125_A { t := &A_arbace_spec_gen_alpha_eval1067000125_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000125_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000125_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000125_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000131_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000131_A_New() *A_arbace_spec_gen_alpha_eval1067000131_A { t := &A_arbace_spec_gen_alpha_eval1067000131_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000131_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000131_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000131_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000137_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000137_A_New() *A_arbace_spec_gen_alpha_eval1067000137_A { t := &A_arbace_spec_gen_alpha_eval1067000137_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000137_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000137_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000137_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000143_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000143_A_New() *A_arbace_spec_gen_alpha_eval1067000143_A { t := &A_arbace_spec_gen_alpha_eval1067000143_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000143_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000143_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000143_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000149_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000149_A_New() *A_arbace_spec_gen_alpha_eval1067000149_A { t := &A_arbace_spec_gen_alpha_eval1067000149_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000149_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000149_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000149_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000149_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000149_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000155_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000155_A_New() *A_arbace_spec_gen_alpha_eval1067000155_A { t := &A_arbace_spec_gen_alpha_eval1067000155_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000155_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000155_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000155_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000161_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000161_A_New() *A_arbace_spec_gen_alpha_eval1067000161_A { t := &A_arbace_spec_gen_alpha_eval1067000161_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000161_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000161_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000161_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000167_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000167_A_New() *A_arbace_spec_gen_alpha_eval1067000167_A { t := &A_arbace_spec_gen_alpha_eval1067000167_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000167_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000167_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000167_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000173_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000173_A_New() *A_arbace_spec_gen_alpha_eval1067000173_A { t := &A_arbace_spec_gen_alpha_eval1067000173_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000173_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000173_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000173_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000173_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000173_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A struct{ j2g_header uint64; F_g__1067000046__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000192_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000192_A_New() *A_arbace_spec_gen_alpha_eval1067000192_A { t := &A_arbace_spec_gen_alpha_eval1067000192_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000192_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000192_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000192_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000198_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000198_A_New() *A_arbace_spec_gen_alpha_eval1067000198_A { t := &A_arbace_spec_gen_alpha_eval1067000198_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000198_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000198_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000198_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000204_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000204_A_New() *A_arbace_spec_gen_alpha_eval1067000204_A { t := &A_arbace_spec_gen_alpha_eval1067000204_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000204_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000204_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000204_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000204_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000204_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000210_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000210_A_New() *A_arbace_spec_gen_alpha_eval1067000210_A { t := &A_arbace_spec_gen_alpha_eval1067000210_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000210_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000210_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000210_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000216_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000216_A_New() *A_arbace_spec_gen_alpha_eval1067000216_A { t := &A_arbace_spec_gen_alpha_eval1067000216_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000216_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000216_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000216_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000216_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000216_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000222_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000222_A_New() *A_arbace_spec_gen_alpha_eval1067000222_A { t := &A_arbace_spec_gen_alpha_eval1067000222_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000222_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000222_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000222_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000222_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000222_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000228_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000228_A_New() *A_arbace_spec_gen_alpha_eval1067000228_A { t := &A_arbace_spec_gen_alpha_eval1067000228_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000228_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000228_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000228_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000228_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000228_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000234_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000234_A_New() *A_arbace_spec_gen_alpha_eval1067000234_A { t := &A_arbace_spec_gen_alpha_eval1067000234_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000234_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000234_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000234_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000234_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000234_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000240_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000240_A_New() *A_arbace_spec_gen_alpha_eval1067000240_A { t := &A_arbace_spec_gen_alpha_eval1067000240_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000240_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000240_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000240_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000246_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000246_A_New() *A_arbace_spec_gen_alpha_eval1067000246_A { t := &A_arbace_spec_gen_alpha_eval1067000246_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000246_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000246_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000246_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000246_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000246_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000252_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000252_A_New() *A_arbace_spec_gen_alpha_eval1067000252_A { t := &A_arbace_spec_gen_alpha_eval1067000252_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000252_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000252_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000252_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000258_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000258_A_New() *A_arbace_spec_gen_alpha_eval1067000258_A { t := &A_arbace_spec_gen_alpha_eval1067000258_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000258_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000258_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000258_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000258_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000258_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000264_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000264_A_New() *A_arbace_spec_gen_alpha_eval1067000264_A { t := &A_arbace_spec_gen_alpha_eval1067000264_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000264_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000264_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000264_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000270_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000270_A_New() *A_arbace_spec_gen_alpha_eval1067000270_A { t := &A_arbace_spec_gen_alpha_eval1067000270_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000270_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000270_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000270_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000270_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000270_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000276_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000276_A_New() *A_arbace_spec_gen_alpha_eval1067000276_A { t := &A_arbace_spec_gen_alpha_eval1067000276_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000276_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000276_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000276_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000282_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000282_A_New() *A_arbace_spec_gen_alpha_eval1067000282_A { t := &A_arbace_spec_gen_alpha_eval1067000282_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000282_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000282_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000282_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000282_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000282_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000288_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000288_A_New() *A_arbace_spec_gen_alpha_eval1067000288_A { t := &A_arbace_spec_gen_alpha_eval1067000288_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000288_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000288_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000288_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000288_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000288_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000294_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000294_A_New() *A_arbace_spec_gen_alpha_eval1067000294_A { t := &A_arbace_spec_gen_alpha_eval1067000294_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000294_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000294_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000294_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000294_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000294_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000300_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000300_A_New() *A_arbace_spec_gen_alpha_eval1067000300_A { t := &A_arbace_spec_gen_alpha_eval1067000300_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000300_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000300_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000300_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000300_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000300_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000306_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000306_A_New() *A_arbace_spec_gen_alpha_eval1067000306_A { t := &A_arbace_spec_gen_alpha_eval1067000306_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000306_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000306_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000306_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000306_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000306_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000312_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000312_A_New() *A_arbace_spec_gen_alpha_eval1067000312_A { t := &A_arbace_spec_gen_alpha_eval1067000312_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000312_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000312_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000312_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000312_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000312_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000318_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000318_A_New() *A_arbace_spec_gen_alpha_eval1067000318_A { t := &A_arbace_spec_gen_alpha_eval1067000318_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000318_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000318_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000318_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000318_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000318_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A struct{ j2g_header uint64; F_g__1067000179__auto__ any }

var A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000017_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000020_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000332_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_for_all_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_gen_for_name_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_gen_for_name_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_gen_for_pred_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_combinator_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_combinators_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_prim_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_prim_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_prims_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_prims_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_qualified_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_gen_alpha_quick_check_A struct{ j2g_header uint64 }

var A_arbace_spec_gen_alpha_quick_check_A_fn_class *jrt.Class
