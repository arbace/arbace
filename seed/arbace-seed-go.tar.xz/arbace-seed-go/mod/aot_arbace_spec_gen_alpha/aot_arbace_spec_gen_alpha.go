//line aot_arbace_spec_gen_alpha.ae:1
package aot_arbace_spec_gen_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_New() *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A { A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp4 = A_arbace_spec_gen_alpha_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_spec_gen_alpha_A_Init(); tmp6 = A_arbace_spec_gen_alpha_A_const_1; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_spec_gen_alpha_A_Init(); tmp8 = A_arbace_spec_gen_alpha_A_const_2; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_spec_gen_alpha_A_Init(); tmp10 = A_arbace_spec_gen_alpha_A_const_3; tmp3 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp11 != nil { panic(tmp11) }; return tmp3 }
//line :13:1
func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_New() *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A { A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp7 = A_arbace_spec_gen_alpha_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }









func A_arbace_spec_gen_alpha_dynaload_A_New() *A_arbace_spec_gen_alpha_dynaload_A { A_arbace_spec_gen_alpha_dynaload_A_Init(); t := &A_arbace_spec_gen_alpha_dynaload_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_spec_gen_alpha_dynaload_A) Ctor() {}
//line :23:1
func (t *A_arbace_spec_gen_alpha_dynaload_A) Invoke_O_O__O(self, s__0 any) any { var ns__2 any; var tmp1 *lang.Var;

	A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_9; ns__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); if
	jrt.A2g_Truth(ns__2) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_144, nil); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_15; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref()))) }; var lockee__1927000360__auto____3 any; var tmp6 /*line :23:1*/*lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp6 = A_arbace_spec_gen_alpha_A_const_12; lockee__1927000360__auto____3 = jrt.NN(tmp6).GetRawRoot__O(); var tmp7 any =



	A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_New_O_O(lockee__1927000360__auto____3, ns__2); var tmp8 *jrt.Class; A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_Init(); tmp8 = A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); var v__3 any; var tmp9 /*line :23:1*/*lang.Var;





	A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_10; v__3 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(s__0); if
	jrt.A2g_Truth(v__3) { var tmp10 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp10 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(v__3) } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_145, nil, Lit_146), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil))))) } }
//line :27:1
func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_New_O_O(p0, p1 any) *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A { A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_Init(); t := &A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Ctor_O_O(c__lockee__1927000360__auto__, c__ns any) { t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__; t.F_ns = c__ns }
//line :27:1
func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____3); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp2 = A_arbace_spec_gen_alpha_A_const_13; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp4 = A_arbace_spec_gen_alpha_A_const_14; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_ns; t.F_ns = nil; tmp6 = t__2; tmp1 = tmp3.Invoke_O__O(tmp5.Invoke_O__O(tmp6)) }
//line :27:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____3); if tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_spec_gen_alpha_fn__1067000017_A_New() *A_arbace_spec_gen_alpha_fn__1067000017_A { A_arbace_spec_gen_alpha_fn__1067000017_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000017_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Ctor() {}
//line :35:1
func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_17; return tmp2.Invoke_O__O(tmp3) }
func A_arbace_spec_gen_alpha_quick_check_A_New() *A_arbace_spec_gen_alpha_quick_check_A { A_arbace_spec_gen_alpha_quick_check_A_Init(); t := &A_arbace_spec_gen_alpha_quick_check_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_spec_gen_alpha_quick_check_A) Ctor() {}
//line :36:1
func (t *A_arbace_spec_gen_alpha_quick_check_A) DoInvoke_O_O__O(self, args__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_19; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), args__0)
}

func A_arbace_spec_gen_alpha_fn__1067000020_A_New() *A_arbace_spec_gen_alpha_fn__1067000020_A { A_arbace_spec_gen_alpha_fn__1067000020_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000020_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Ctor() {}
//line :41:1
func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_20; return tmp2.Invoke_O__O(tmp3) }
func A_arbace_spec_gen_alpha_for_all_STAR__A_New() *A_arbace_spec_gen_alpha_for_all_STAR__A { A_arbace_spec_gen_alpha_for_all_STAR__A_Init(); t := &A_arbace_spec_gen_alpha_for_all_STAR__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) Ctor() {}
//line :42:1
func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) DoInvoke_O_O__O(self, args__0 any) any {


	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_21; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), args__0)
}
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Ctor() {}
//line :47:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_22; return tmp2.Invoke_O__O(tmp3) }
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_23; return tmp2.Invoke_O__O(tmp3) }
func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_New() *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Ctor() {}
//line :49:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_24; return tmp2.Invoke_O__O(tmp3) }
func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A { A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A{}; t.Ctor_O(p0); return t }
//line :50:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Ctor_O(c__g_QMARK_ any) { t.F_g_QMARK_ = c__g_QMARK_ }
//line :50:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Invoke_O_O__O(self, x__1 any) any {

	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g_QMARK_)).Invoke_O__O(x__1) }
func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A { A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Ctor_O(c__mkg any) { t.F_mkg = c__mkg }
//line :53:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Invoke_O_O__O(self, gfn__1 any) any {

	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_mkg)).Invoke_O__O(gfn__1) }
func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A { A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :56:1
func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Invoke_O_O__O(self, generator__1 any) any {


	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g)).Invoke_O__O(generator__1)
}
func A_arbace_spec_gen_alpha_delay_impl_A_New() *A_arbace_spec_gen_alpha_delay_impl_A { A_arbace_spec_gen_alpha_delay_impl_A_Init(); t := &A_arbace_spec_gen_alpha_delay_impl_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_spec_gen_alpha_delay_impl_A) Ctor() {}
//line :61:1
func (t *A_arbace_spec_gen_alpha_delay_impl_A) Invoke_O_O__O(self, gfnd__0 any) any {


	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_New_O(gfnd__0); var tmp4 *jrt.Class; A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_Init(); tmp4 = A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class; return tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :64:1
func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_New_O(p0 any) *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A { A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_Init(); t := &A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A{}; t.Ctor_O(p0); return t }
//line :64:1
func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Ctor_O(c__gfnd any) { t.F_gfnd = c__gfnd }
//line :64:1
func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Invoke_O_O_O__O(self, rnd__1, size__2 any) any {
	var tmp1 *lang.Keyword; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_26; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_gfnd))).Invoke_O_O__O(rnd__1, size__2)
}
func A_arbace_spec_gen_alpha_delay_A_New() *A_arbace_spec_gen_alpha_delay_A { A_arbace_spec_gen_alpha_delay_A_Init(); t := &A_arbace_spec_gen_alpha_delay_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_spec_gen_alpha_delay_A) Ctor() {}
//line :67:1
func (t *A_arbace_spec_gen_alpha_delay_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_28; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_gen_alpha_A_Init(); tmp7 = A_arbace_spec_gen_alpha_A_const_30; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_29; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp11 = A_arbace_spec_gen_alpha_A_const_27; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp13 = A_arbace_spec_gen_alpha_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp15 = A_arbace_spec_gen_alpha_A_const_29; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_spec_gen_alpha_A_Init(); tmp17 = A_arbace_spec_gen_alpha_A_const_31; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp16.Invoke_O__O(tmp17), body__2))))) }






func A_arbace_spec_gen_alpha_gen_for_name_A_New() *A_arbace_spec_gen_alpha_gen_for_name_A { A_arbace_spec_gen_alpha_gen_for_name_A_Init(); t := &A_arbace_spec_gen_alpha_gen_for_name_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Ctor() {}
//line :74:1
func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Invoke_O_O__O(self, s__0 any) any { var g__2 any; var tmp1 *lang.Var;


	A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; g__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); var tmp2 /*line :78:1*/*lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp2 = A_arbace_spec_gen_alpha_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(g__2)) { return g__2 } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_145, nil, Lit_251), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil))))) } }



func A_arbace_spec_gen_alpha_lazy_combinator_A_New() *A_arbace_spec_gen_alpha_lazy_combinator_A { A_arbace_spec_gen_alpha_lazy_combinator_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinator_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Ctor() {}
//line :82:1
func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, s__2 any) any { var fqn__4 any; var tmp1 *lang.Var;


	A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_33; fqn__4 = tmp2.Invoke_O_O__O(Lit_41, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__2)); var doc__5 any = /*line :82:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_254, nil), jrt.RefArrayOf(jrt.Object_class, nil, fqn__4)).Ref(); var tmp4 *lang.Var;


	A_arbace_spec_gen_alpha_A_Init(); tmp4 = A_arbace_spec_gen_alpha_A_const_27; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp6 = A_arbace_spec_gen_alpha_A_const_28; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp8 = A_arbace_spec_gen_alpha_A_const_29; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_spec_gen_alpha_A_Init(); tmp10 = A_arbace_spec_gen_alpha_A_const_34; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp12 = A_arbace_spec_gen_alpha_A_const_29; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp14 = A_arbace_spec_gen_alpha_A_const_18; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp16 = A_arbace_spec_gen_alpha_A_const_35; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp18 = A_arbace_spec_gen_alpha_A_const_27; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp20 = A_arbace_spec_gen_alpha_A_const_28; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp22 = A_arbace_spec_gen_alpha_A_const_29; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_spec_gen_alpha_A_Init(); tmp24 = A_arbace_spec_gen_alpha_A_const_36; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp26 = A_arbace_spec_gen_alpha_A_const_29; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp28 = A_arbace_spec_gen_alpha_A_const_27; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp30 = A_arbace_spec_gen_alpha_A_const_28; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp32 = A_arbace_spec_gen_alpha_A_const_29; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_spec_gen_alpha_A_Init(); tmp34 = A_arbace_spec_gen_alpha_A_const_37; var tmp35 any = tmp33.Invoke_O__O(tmp34); var tmp36 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp36 = A_arbace_spec_gen_alpha_A_const_29; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp38 = A_arbace_spec_gen_alpha_A_const_27; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp40 = A_arbace_spec_gen_alpha_A_const_28; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp42 = A_arbace_spec_gen_alpha_A_const_29; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 any; A_arbace_spec_gen_alpha_A_Init(); tmp44 = A_arbace_spec_gen_alpha_A_const_38; var tmp45 any = tmp43.Invoke_O__O(tmp44); var tmp46 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp46 = A_arbace_spec_gen_alpha_A_const_29; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp48 = A_arbace_spec_gen_alpha_A_const_27; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp50 = A_arbace_spec_gen_alpha_A_const_28; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp52 = A_arbace_spec_gen_alpha_A_const_29; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_spec_gen_alpha_A_Init(); tmp54 = A_arbace_spec_gen_alpha_A_const_39; var tmp55 any = tmp53.Invoke_O__O(tmp54); var tmp56 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp56 = A_arbace_spec_gen_alpha_A_const_29; var tmp57 any = tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp19.Invoke_O__O(tmp21.Invoke_O_O__O(tmp25, tmp27.Invoke_O__O(tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp35, tmp37.Invoke_O__O(tmp39.Invoke_O__O(tmp41.Invoke_O_O__O(tmp45, tmp47.Invoke_O__O(tmp49.Invoke_O__O(tmp51.Invoke_O_O__O(tmp55, lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(fqn__4)))))))))))))); var tmp58 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp58 = A_arbace_spec_gen_alpha_A_const_29; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp60 = A_arbace_spec_gen_alpha_A_const_27; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp62 = A_arbace_spec_gen_alpha_A_const_28; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp64 = A_arbace_spec_gen_alpha_A_const_29; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 any; A_arbace_spec_gen_alpha_A_Init(); tmp66 = A_arbace_spec_gen_alpha_A_const_40; var tmp67 any = tmp65.Invoke_O__O(tmp66); var tmp68 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp68 = A_arbace_spec_gen_alpha_A_const_29; var tmp69 any = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(s__2); var tmp70 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp70 = A_arbace_spec_gen_alpha_A_const_29; var tmp71 any = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(doc__5); var tmp72 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp72 = A_arbace_spec_gen_alpha_A_const_29; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp74 = A_arbace_spec_gen_alpha_A_const_18; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp76 = A_arbace_spec_gen_alpha_A_const_35; var tmp77 any = jrt.NN(tmp76).GetRawRoot__O(); var tmp78 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp78 = A_arbace_spec_gen_alpha_A_const_27; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp80 = A_arbace_spec_gen_alpha_A_const_28; var tmp81 lang.IFn = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()); var tmp82 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp82 = A_arbace_spec_gen_alpha_A_const_29; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any; A_arbace_spec_gen_alpha_A_Init(); tmp84 = A_arbace_spec_gen_alpha_A_const_41; var tmp85 any = tmp83.Invoke_O__O(tmp84); var tmp86 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp86 = A_arbace_spec_gen_alpha_A_const_29; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 any; A_arbace_spec_gen_alpha_A_Init(); tmp88 = A_arbace_spec_gen_alpha_A_const_42; var tmp89 any = tmp73.Invoke_O__O(tmp75.Invoke_O_O__O(tmp77, tmp79.Invoke_O__O(tmp81.Invoke_O_O__O(tmp85, tmp87.Invoke_O__O(tmp88))))); var tmp90 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp90 = A_arbace_spec_gen_alpha_A_const_29; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp92 = A_arbace_spec_gen_alpha_A_const_27; var tmp93 lang.IFn = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()); var tmp94 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp94 = A_arbace_spec_gen_alpha_A_const_28; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp96 = A_arbace_spec_gen_alpha_A_const_29; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 any; A_arbace_spec_gen_alpha_A_Init(); tmp98 = A_arbace_spec_gen_alpha_A_const_43; var tmp99 any = tmp97.Invoke_O__O(tmp98); var tmp100 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp100 = A_arbace_spec_gen_alpha_A_const_29; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp102 = A_arbace_spec_gen_alpha_A_const_27; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp104 = A_arbace_spec_gen_alpha_A_const_28; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp106 = A_arbace_spec_gen_alpha_A_const_29; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 any; A_arbace_spec_gen_alpha_A_Init(); tmp108 = A_arbace_spec_gen_alpha_A_const_44; var tmp109 any = tmp107.Invoke_O__O(tmp108); var tmp110 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp110 = A_arbace_spec_gen_alpha_A_const_29; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 any; A_arbace_spec_gen_alpha_A_Init(); tmp112 = A_arbace_spec_gen_alpha_A_const_36; var tmp113 any = tmp101.Invoke_O__O(tmp103.Invoke_O__O(tmp105.Invoke_O_O__O(tmp109, tmp111.Invoke_O__O(tmp112)))); var tmp114 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp114 = A_arbace_spec_gen_alpha_A_const_29; var tmp115 lang.IFn = lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()); var tmp116 any; A_arbace_spec_gen_alpha_A_Init(); tmp116 = A_arbace_spec_gen_alpha_A_const_45; return tmp5.Invoke_O__O(tmp7.Invoke_O_O_O__O(tmp11, tmp57, tmp59.Invoke_O__O(tmp61.Invoke_O__O(tmp63.Invoke_O_O_O_O_O__O(tmp67, tmp69, tmp71, tmp89, tmp91.Invoke_O__O(tmp93.Invoke_O__O(tmp95.Invoke_O_O_O__O(tmp99, tmp113, tmp115.Invoke_O__O(tmp116))))))))) }







func A_arbace_spec_gen_alpha_lazy_combinators_A_New() *A_arbace_spec_gen_alpha_lazy_combinators_A { A_arbace_spec_gen_alpha_lazy_combinators_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinators_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) Ctor() {}
//line :93:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, syms__2 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_28; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_gen_alpha_A_Init(); tmp7 = A_arbace_spec_gen_alpha_A_const_47; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_46; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_New(); var tmp12 *jrt.Class; A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_Init(); tmp12 = A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), syms__2))) }




func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_New() *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A { A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Ctor() {}
//line :98:1
func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_48; return tmp2.Invoke_O_O__O(tmp3, s__1) }


func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_New() *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A { A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_49; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A { A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_New() *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A { A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_50; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A { A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_New() *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A { A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_51; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A { A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_New() *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A { A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_52; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A { A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_New() *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A { A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_53; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A { A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_New() *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A { A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_54; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A { A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_New() *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A { A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_55; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A { A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A { A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_New() *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A { A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_56; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A { A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_New() *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A { A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_57; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A { A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_New() *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A { A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_58; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A { A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_New() *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A { A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_59; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_New() *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A { A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_60; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A { A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_New() *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A { A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_61; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A { A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_New() *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A { A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_62; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A { A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_New() *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A { A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_63; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A { A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_New() *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A { A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_64; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A { A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_New() *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A { A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_65; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A { A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A { A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_New() *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A { A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_66; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_New() *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A { A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_67; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A { A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_New() *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A { A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Ctor() {}
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_68; return tmp2.Invoke_O__O(tmp3) }
//line :101:1
func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A { A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) Ctor_O(c__g__1067000046__auto__ any) { t.F_g__1067000046__auto__ = c__g__1067000046__auto__ }
//line :101:1
func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000046__auto__), args__1) }



func A_arbace_spec_gen_alpha_lazy_prim_A_New() *A_arbace_spec_gen_alpha_lazy_prim_A { A_arbace_spec_gen_alpha_lazy_prim_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prim_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Ctor() {}
//line :105:1
func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, s__2 any) any { var fqn__4 any; var tmp1 *lang.Var;


	A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_33; fqn__4 = tmp2.Invoke_O_O__O(Lit_41, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__2)); var doc__5 any = /*line :105:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_258, nil), jrt.RefArrayOf(jrt.Object_class, nil, fqn__4)).Ref(); var tmp4 *lang.Var;


	A_arbace_spec_gen_alpha_A_Init(); tmp4 = A_arbace_spec_gen_alpha_A_const_27; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp6 = A_arbace_spec_gen_alpha_A_const_28; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp8 = A_arbace_spec_gen_alpha_A_const_29; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_spec_gen_alpha_A_Init(); tmp10 = A_arbace_spec_gen_alpha_A_const_69; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp12 = A_arbace_spec_gen_alpha_A_const_29; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp14 = A_arbace_spec_gen_alpha_A_const_18; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp16 = A_arbace_spec_gen_alpha_A_const_35; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp18 = A_arbace_spec_gen_alpha_A_const_27; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp20 = A_arbace_spec_gen_alpha_A_const_28; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp22 = A_arbace_spec_gen_alpha_A_const_29; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_spec_gen_alpha_A_Init(); tmp24 = A_arbace_spec_gen_alpha_A_const_70; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp26 = A_arbace_spec_gen_alpha_A_const_29; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp28 = A_arbace_spec_gen_alpha_A_const_27; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp30 = A_arbace_spec_gen_alpha_A_const_28; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp32 = A_arbace_spec_gen_alpha_A_const_29; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_spec_gen_alpha_A_Init(); tmp34 = A_arbace_spec_gen_alpha_A_const_71; var tmp35 any = tmp33.Invoke_O__O(tmp34); var tmp36 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp36 = A_arbace_spec_gen_alpha_A_const_29; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp38 = A_arbace_spec_gen_alpha_A_const_27; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp40 = A_arbace_spec_gen_alpha_A_const_28; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp42 = A_arbace_spec_gen_alpha_A_const_29; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 any; A_arbace_spec_gen_alpha_A_Init(); tmp44 = A_arbace_spec_gen_alpha_A_const_72; var tmp45 any = tmp43.Invoke_O__O(tmp44); var tmp46 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp46 = A_arbace_spec_gen_alpha_A_const_29; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp48 = A_arbace_spec_gen_alpha_A_const_27; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp50 = A_arbace_spec_gen_alpha_A_const_28; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp52 = A_arbace_spec_gen_alpha_A_const_29; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_spec_gen_alpha_A_Init(); tmp54 = A_arbace_spec_gen_alpha_A_const_39; var tmp55 any = tmp53.Invoke_O__O(tmp54); var tmp56 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp56 = A_arbace_spec_gen_alpha_A_const_29; var tmp57 any = tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp19.Invoke_O__O(tmp21.Invoke_O_O__O(tmp25, tmp27.Invoke_O__O(tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp35, tmp37.Invoke_O__O(tmp39.Invoke_O__O(tmp41.Invoke_O_O__O(tmp45, tmp47.Invoke_O__O(tmp49.Invoke_O__O(tmp51.Invoke_O_O__O(tmp55, lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(fqn__4)))))))))))))); var tmp58 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp58 = A_arbace_spec_gen_alpha_A_const_29; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp60 = A_arbace_spec_gen_alpha_A_const_27; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp62 = A_arbace_spec_gen_alpha_A_const_28; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp64 = A_arbace_spec_gen_alpha_A_const_29; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 any; A_arbace_spec_gen_alpha_A_Init(); tmp66 = A_arbace_spec_gen_alpha_A_const_73; var tmp67 any = tmp65.Invoke_O__O(tmp66); var tmp68 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp68 = A_arbace_spec_gen_alpha_A_const_29; var tmp69 any = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(s__2); var tmp70 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp70 = A_arbace_spec_gen_alpha_A_const_29; var tmp71 any = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(doc__5); var tmp72 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp72 = A_arbace_spec_gen_alpha_A_const_29; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp74 = A_arbace_spec_gen_alpha_A_const_18; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp76 = A_arbace_spec_gen_alpha_A_const_35; var tmp77 any = jrt.NN(tmp76).GetRawRoot__O(); var tmp78 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp78 = A_arbace_spec_gen_alpha_A_const_27; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp80 = A_arbace_spec_gen_alpha_A_const_28; var tmp81 lang.IFn = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()); var tmp82 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp82 = A_arbace_spec_gen_alpha_A_const_29; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any; A_arbace_spec_gen_alpha_A_Init(); tmp84 = A_arbace_spec_gen_alpha_A_const_74; var tmp85 any = tmp83.Invoke_O__O(tmp84); var tmp86 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp86 = A_arbace_spec_gen_alpha_A_const_29; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 any; A_arbace_spec_gen_alpha_A_Init(); tmp88 = A_arbace_spec_gen_alpha_A_const_75; var tmp89 any = tmp73.Invoke_O__O(tmp75.Invoke_O_O__O(tmp77, tmp79.Invoke_O__O(tmp81.Invoke_O_O__O(tmp85, tmp87.Invoke_O__O(tmp88))))); var tmp90 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp90 = A_arbace_spec_gen_alpha_A_const_29; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp92 = A_arbace_spec_gen_alpha_A_const_27; var tmp93 lang.IFn = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()); var tmp94 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp94 = A_arbace_spec_gen_alpha_A_const_28; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp96 = A_arbace_spec_gen_alpha_A_const_29; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 any; A_arbace_spec_gen_alpha_A_Init(); tmp98 = A_arbace_spec_gen_alpha_A_const_44; var tmp99 any = tmp97.Invoke_O__O(tmp98); var tmp100 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp100 = A_arbace_spec_gen_alpha_A_const_29; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 any; A_arbace_spec_gen_alpha_A_Init(); tmp102 = A_arbace_spec_gen_alpha_A_const_70; return tmp5.Invoke_O__O(tmp7.Invoke_O_O_O__O(tmp11, tmp57, tmp59.Invoke_O__O(tmp61.Invoke_O__O(tmp63.Invoke_O_O_O_O_O__O(tmp67, tmp69, tmp71, tmp89, tmp91.Invoke_O__O(tmp93.Invoke_O__O(tmp95.Invoke_O_O__O(tmp99, tmp101.Invoke_O__O(tmp102))))))))) }







func A_arbace_spec_gen_alpha_lazy_prims_A_New() *A_arbace_spec_gen_alpha_lazy_prims_A { A_arbace_spec_gen_alpha_lazy_prims_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prims_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_A) Ctor() {}
//line :116:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, syms__2 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_28; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_gen_alpha_A_Init(); tmp7 = A_arbace_spec_gen_alpha_A_const_76; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_46; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_New(); var tmp12 *jrt.Class; A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_Init(); tmp12 = A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), syms__2))) }




func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_New() *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A { A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_Init(); t := &A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Ctor() {}
//line :121:1
func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_77; return tmp2.Invoke_O_O__O(tmp3, s__1) }


func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A { A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_New() *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A { A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_78; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A { A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_New() *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A { A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_79; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A { A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_New() *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A { A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_80; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A { A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_New() *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A { A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_81; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A { A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_New() *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A { A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_82; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A { A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_New() *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A { A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_83; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A { A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_New() *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A { A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_84; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A { A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_New() *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A { A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_85; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A { A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_New() *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A { A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_86; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_New() *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A { A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_87; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A { A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_New() *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A { A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_88; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A { A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_New() *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A { A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_89; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A { A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_New() *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A { A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_90; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A { A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_New() *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A { A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_91; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A { A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_New() *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A { A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_92; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A { A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_New() *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A { A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_93; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A { A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_New() *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A { A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_94; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A { A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_New() *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A { A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_95; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A { A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_New() *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A { A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_96; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A { A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_New() *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A { A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_97; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A { A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_New() *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A { A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_98; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A { A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_New() *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A { A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Ctor() {}
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_99; return tmp2.Invoke_O__O(tmp3) }
//line :124:1
func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_New_O(p0 any) *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A { A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_Init(); t := &A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) Ctor_O(c__g__1067000179__auto__ any) { t.F_g__1067000179__auto__ = c__g__1067000179__auto__ }
//line :124:1
func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) DoInvoke_O_O__O(self, args__1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_5; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_g__1067000179__auto__) }



func A_arbace_spec_gen_alpha_cat_A_New() *A_arbace_spec_gen_alpha_cat_A { A_arbace_spec_gen_alpha_cat_A_Init(); t := &A_arbace_spec_gen_alpha_cat_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_spec_gen_alpha_cat_A) Ctor() {}
//line :128:1
func (t *A_arbace_spec_gen_alpha_cat_A) DoInvoke_O_O__O(self, gens__0 any) any {



	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_100; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_New(); var tmp4 *jrt.Class; A_arbace_spec_gen_alpha_cat_fn__1067000325_A_Init(); tmp4 = A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp6 = A_arbace_spec_gen_alpha_A_const_18; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp8 = A_arbace_spec_gen_alpha_A_const_101; return tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), gens__0)) }
//line :132:1
func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_New() *A_arbace_spec_gen_alpha_cat_fn__1067000325_A { A_arbace_spec_gen_alpha_cat_fn__1067000325_A_Init(); t := &A_arbace_spec_gen_alpha_cat_fn__1067000325_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Ctor() {}
//line :132:1
func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Invoke_O_O__O(self, p1__1067000324_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_28; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), p1__1067000324_SHARP___1) }


func A_arbace_spec_gen_alpha_qualified_QMARK__A_New() *A_arbace_spec_gen_alpha_qualified_QMARK__A { A_arbace_spec_gen_alpha_qualified_QMARK__A_Init(); t := &A_arbace_spec_gen_alpha_qualified_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Invoke_O_O__O(self, ident__0 any) any { var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_102; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_9; return tmp2.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(ident__0), nil)).Ref()) }



func A_arbace_spec_gen_alpha_fn__1067000332_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_A { A_arbace_spec_gen_alpha_fn__1067000332_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Ctor() {}
//line :139:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Invoke_O__O(self any) any { var simple__1 any; var tmp1 *lang.Var;
										A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_103; simple__1 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O(); var tmp2 /*line :139:1*/*lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp2 = A_arbace_spec_gen_alpha_A_const_104; var tmp3 any = jrt.NN(tmp2).GetRawRoot__O(); var tmp4 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp4 = A_arbace_spec_gen_alpha_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_New(); var tmp7 *jrt.Class; A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_Init(); tmp7 = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp9 = A_arbace_spec_gen_alpha_A_const_169; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_spec_gen_alpha_A_Init(); tmp11 = A_arbace_spec_gen_alpha_A_const_170; var tmp12 any = tmp5.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp11)); var tmp13 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp13 = A_arbace_spec_gen_alpha_A_const_105; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp15 = A_arbace_spec_gen_alpha_A_const_106; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp17 = A_arbace_spec_gen_alpha_A_const_171; var tmp18 any = jrt.NN(tmp17).GetRawRoot__O(); var tmp19 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp19 = A_arbace_spec_gen_alpha_A_const_138; var tmp20 any = tmp16.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O()); var tmp21 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp21 = A_arbace_spec_gen_alpha_A_const_107; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp23 = A_arbace_spec_gen_alpha_A_const_108; var tmp24 any = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp25 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp25 = A_arbace_spec_gen_alpha_A_const_109; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp27 = A_arbace_spec_gen_alpha_A_const_110; var tmp28 any = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp29 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp29 = A_arbace_spec_gen_alpha_A_const_111; var tmp30 any = jrt.NN(tmp29).GetRawRoot__O(); var tmp31 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp31 = A_arbace_spec_gen_alpha_A_const_112; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp33 = A_arbace_spec_gen_alpha_A_const_141; var tmp34 any = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(nil); var tmp35 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp35 = A_arbace_spec_gen_alpha_A_const_172; var tmp36 any = tmp32.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp34, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke__O())); var tmp37 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp37 = A_arbace_spec_gen_alpha_A_const_113; var tmp38 any = jrt.NN(tmp37).GetRawRoot__O(); var tmp39 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp39 = A_arbace_spec_gen_alpha_A_const_114; var tmp40 any = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke__O(); var tmp41 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp41 = A_arbace_spec_gen_alpha_A_const_115; var tmp42 any = jrt.NN(tmp41).GetRawRoot__O(); var tmp43 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp43 = A_arbace_spec_gen_alpha_A_const_116; var tmp44 any = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke__O(); var tmp45 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp45 = A_arbace_spec_gen_alpha_A_const_117; var tmp46 any = jrt.NN(tmp45).GetRawRoot__O(); var tmp47 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp47 = A_arbace_spec_gen_alpha_A_const_106; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp49 = A_arbace_spec_gen_alpha_A_const_117; var tmp50 any = jrt.NN(tmp49).GetRawRoot__O(); var tmp51 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp51 = A_arbace_spec_gen_alpha_A_const_172; var tmp52 any = tmp48.Invoke_O_O__O(tmp50, lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke__O()); var tmp53 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp53 = A_arbace_spec_gen_alpha_A_const_118; var tmp54 any = jrt.NN(tmp53).GetRawRoot__O(); var tmp55 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp55 = A_arbace_spec_gen_alpha_A_const_100; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_New(); var tmp58 *jrt.Class; A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_Init(); tmp58 = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class; var tmp59 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil); var tmp60 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp60 = A_arbace_spec_gen_alpha_A_const_135; var tmp61 any = tmp56.Invoke_O_O__O(tmp59, lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke__O()); var tmp62 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp62 = A_arbace_spec_gen_alpha_A_const_119; var tmp63 any = jrt.NN(tmp62).GetRawRoot__O(); var tmp64 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp64 = A_arbace_spec_gen_alpha_A_const_120; var tmp65 any = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke__O(); var tmp66 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp66 = A_arbace_spec_gen_alpha_A_const_121; var tmp67 any = jrt.NN(tmp66).GetRawRoot__O(); var tmp68 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp68 = A_arbace_spec_gen_alpha_A_const_112; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp70 = A_arbace_spec_gen_alpha_A_const_108; var tmp71 any = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp72 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp72 = A_arbace_spec_gen_alpha_A_const_110; var tmp73 any = tmp69.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp71, lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(simple__1))); var tmp74 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp74 = A_arbace_spec_gen_alpha_A_const_122; var tmp75 any = jrt.NN(tmp74).GetRawRoot__O(); var tmp76 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp76 = A_arbace_spec_gen_alpha_A_const_123; var tmp77 any = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke__O(); var tmp78 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp78 = A_arbace_spec_gen_alpha_A_const_124; var tmp79 any = jrt.NN(tmp78).GetRawRoot__O(); var tmp80 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp80 = A_arbace_spec_gen_alpha_A_const_125; var tmp81 any = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp82 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp82 = A_arbace_spec_gen_alpha_A_const_126; var tmp83 any = jrt.NN(tmp82).GetRawRoot__O(); var tmp84 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp84 = A_arbace_spec_gen_alpha_A_const_127; var tmp85 any = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1); var tmp86 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp86 = A_arbace_spec_gen_alpha_A_const_128; var tmp87 any = jrt.NN(tmp86).GetRawRoot__O(); var tmp88 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp88 = A_arbace_spec_gen_alpha_A_const_129; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp90 = lang.PersistentList_EMPTY; var tmp91 any = tmp90.Ref(); var tmp92 *lang.PersistentVector; lang.PersistentVector_Init(); tmp92 = lang.PersistentVector_EMPTY; var tmp93 any = tmp92.Ref(); var tmp94 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp94 = lang.PersistentArrayMap_EMPTY; var tmp95 any = tmp94.Ref(); var tmp96 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp96 = lang.PersistentHashSet_EMPTY; var tmp97 any = tmp89.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(nil, tmp91, tmp93, tmp95, tmp96.Ref())); var tmp98 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp98 = A_arbace_spec_gen_alpha_A_const_130; var tmp99 any = jrt.NN(tmp98).GetRawRoot__O(); var tmp100 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp100 = A_arbace_spec_gen_alpha_A_const_131; var tmp101 any = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()).Invoke__O(); var tmp102 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp102 = A_arbace_spec_gen_alpha_A_const_132; var tmp103 any = jrt.NN(tmp102).GetRawRoot__O(); var tmp104 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp104 = A_arbace_spec_gen_alpha_A_const_100; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 any = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_New(); var tmp107 *jrt.Class; A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_Init(); tmp107 = A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class; var tmp108 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp106, tmp107, nil); var tmp109 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp109 = A_arbace_spec_gen_alpha_A_const_157; var tmp110 any = tmp105.Invoke_O_O__O(tmp108, lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke__O()); var tmp111 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp111 = A_arbace_spec_gen_alpha_A_const_133; var tmp112 any = jrt.NN(tmp111).GetRawRoot__O(); var tmp113 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp113 = A_arbace_spec_gen_alpha_A_const_123; var tmp114 any = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()).Invoke__O(); var tmp115 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp115 = A_arbace_spec_gen_alpha_A_const_134; var tmp116 any = jrt.NN(tmp115).GetRawRoot__O(); var tmp117 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp117 = A_arbace_spec_gen_alpha_A_const_135; var tmp118 any = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke__O(); var tmp119 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp119 = A_arbace_spec_gen_alpha_A_const_136; var tmp120 any = jrt.NN(tmp119).GetRawRoot__O(); var tmp121 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp121 = A_arbace_spec_gen_alpha_A_const_112; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp123 = A_arbace_spec_gen_alpha_A_const_127; var tmp124 any = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1); var tmp125 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp125 = A_arbace_spec_gen_alpha_A_const_110; var tmp126 any = tmp122.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp124, lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()).Invoke_O__O(simple__1))); var tmp127 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp127 = A_arbace_spec_gen_alpha_A_const_137; var tmp128 any = jrt.NN(tmp127).GetRawRoot__O(); var tmp129 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp129 = A_arbace_spec_gen_alpha_A_const_138; var tmp130 any = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()).Invoke__O(); var tmp131 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp131 = A_arbace_spec_gen_alpha_A_const_139; var tmp132 any = jrt.NN(tmp131).GetRawRoot__O(); var tmp133 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp133 = A_arbace_spec_gen_alpha_A_const_110; var tmp134 any = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp135 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp135 = A_arbace_spec_gen_alpha_A_const_140; var tmp136 any = jrt.NN(tmp135).GetRawRoot__O(); var tmp137 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp137 = A_arbace_spec_gen_alpha_A_const_141; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 any; A_arbace_spec_gen_alpha_A_Init(); tmp139 = A_arbace_spec_gen_alpha_A_const_173; var tmp140 any = tmp138.Invoke_O__O(tmp139); var tmp141 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp141 = A_arbace_spec_gen_alpha_A_const_142; var tmp142 any = jrt.NN(tmp141).GetRawRoot__O(); var tmp143 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp143 = A_arbace_spec_gen_alpha_A_const_143; var tmp144 any = lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()).Invoke__O(); var tmp145 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp145 = A_arbace_spec_gen_alpha_A_const_144; var tmp146 any = jrt.NN(tmp145).GetRawRoot__O(); var tmp147 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp147 = A_arbace_spec_gen_alpha_A_const_145; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 any; A_arbace_spec_gen_alpha_A_Init(); tmp149 = A_arbace_spec_gen_alpha_A_const_174; var tmp150 any = tmp148.Invoke_O__O(tmp149); var tmp151 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp151 = A_arbace_spec_gen_alpha_A_const_146; var tmp152 any = jrt.NN(tmp151).GetRawRoot__O(); var tmp153 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp153 = A_arbace_spec_gen_alpha_A_const_141; var tmp154 any = lang.IFn_Cast(jrt.NN(tmp153).GetRawRoot__O()).Invoke_O__O(nil); var tmp155 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp155 = A_arbace_spec_gen_alpha_A_const_147; var tmp156 any = jrt.NN(tmp155).GetRawRoot__O(); var tmp157 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp157 = A_arbace_spec_gen_alpha_A_const_148; var tmp158 any = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()).Invoke__O(); var tmp159 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp159 = A_arbace_spec_gen_alpha_A_const_149; var tmp160 any = jrt.NN(tmp159).GetRawRoot__O(); var tmp161 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp161 = A_arbace_spec_gen_alpha_A_const_112; var tmp162 lang.IFn = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()); var tmp163 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp163 = A_arbace_spec_gen_alpha_A_const_138; var tmp164 any = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke__O(); var tmp165 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp165 = A_arbace_spec_gen_alpha_A_const_166; var tmp166 any = tmp162.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp164, lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()).Invoke__O())); var tmp167 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp167 = A_arbace_spec_gen_alpha_A_const_150; var tmp168 any = jrt.NN(tmp167).GetRawRoot__O(); var tmp169 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp169 = A_arbace_spec_gen_alpha_A_const_106; var tmp170 lang.IFn = lang.IFn_Cast(jrt.NN(tmp169).GetRawRoot__O()); var tmp171 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp171 = A_arbace_spec_gen_alpha_A_const_171; var tmp172 any = jrt.NN(tmp171).GetRawRoot__O(); var tmp173 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp173 = A_arbace_spec_gen_alpha_A_const_112; var tmp174 lang.IFn = lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()); var tmp175 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp175 = A_arbace_spec_gen_alpha_A_const_138; var tmp176 any = lang.IFn_Cast(jrt.NN(tmp175).GetRawRoot__O()).Invoke__O(); var tmp177 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp177 = A_arbace_spec_gen_alpha_A_const_166; var tmp178 any = tmp170.Invoke_O_O__O(tmp172, tmp174.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp176, lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()).Invoke__O()))); var tmp179 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp179 = A_arbace_spec_gen_alpha_A_const_151; var tmp180 any = jrt.NN(tmp179).GetRawRoot__O(); var tmp181 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp181 = A_arbace_spec_gen_alpha_A_const_141; var tmp182 lang.IFn = lang.IFn_Cast(jrt.NN(tmp181).GetRawRoot__O()); var tmp183 *jrt.Boolean; jrt.Boolean_Init(); tmp183 = jrt.Boolean_TRUE; var tmp184 any = tmp182.Invoke_O__O(tmp183.Ref()); var tmp185 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp185 = A_arbace_spec_gen_alpha_A_const_152; var tmp186 any = jrt.NN(tmp185).GetRawRoot__O(); var tmp187 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp187 = A_arbace_spec_gen_alpha_A_const_135; var tmp188 any = lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()).Invoke__O(); var tmp189 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp189 = A_arbace_spec_gen_alpha_A_const_153; var tmp190 any = jrt.NN(tmp189).GetRawRoot__O(); var tmp191 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp191 = A_arbace_spec_gen_alpha_A_const_106; var tmp192 lang.IFn = lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()); var tmp193 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp193 = A_arbace_spec_gen_alpha_A_const_153; var tmp194 any = jrt.NN(tmp193).GetRawRoot__O(); var tmp195 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp195 = A_arbace_spec_gen_alpha_A_const_175; var tmp196 any = tmp192.Invoke_O_O__O(tmp194, lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()).Invoke__O()); var tmp197 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp197 = A_arbace_spec_gen_alpha_A_const_154; var tmp198 any = jrt.NN(tmp197).GetRawRoot__O(); var tmp199 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp199 = A_arbace_spec_gen_alpha_A_const_145; var tmp200 lang.IFn = lang.IFn_Cast(jrt.NN(tmp199).GetRawRoot__O()); var tmp201 any; A_arbace_spec_gen_alpha_A_Init(); tmp201 = A_arbace_spec_gen_alpha_A_const_176; var tmp202 any = tmp200.Invoke_O__O(tmp201); var tmp203 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp203 = A_arbace_spec_gen_alpha_A_const_155; var tmp204 any = jrt.NN(tmp203).GetRawRoot__O(); var tmp205 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp205 = A_arbace_spec_gen_alpha_A_const_145; var tmp206 lang.IFn = lang.IFn_Cast(jrt.NN(tmp205).GetRawRoot__O()); var tmp207 any; A_arbace_spec_gen_alpha_A_Init(); tmp207 = A_arbace_spec_gen_alpha_A_const_177; var tmp208 any = tmp206.Invoke_O__O(tmp207); var tmp209 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp209 = A_arbace_spec_gen_alpha_A_const_156; var tmp210 any = jrt.NN(tmp209).GetRawRoot__O(); var tmp211 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp211 = A_arbace_spec_gen_alpha_A_const_157; var tmp212 any = lang.IFn_Cast(jrt.NN(tmp211).GetRawRoot__O()).Invoke__O(); var tmp213 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp213 = A_arbace_spec_gen_alpha_A_const_158; var tmp214 any = jrt.NN(tmp213).GetRawRoot__O(); var tmp215 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp215 = A_arbace_spec_gen_alpha_A_const_141; var tmp216 lang.IFn = lang.IFn_Cast(jrt.NN(tmp215).GetRawRoot__O()); var tmp217 *jrt.Boolean; jrt.Boolean_Init(); tmp217 = jrt.Boolean_FALSE; var tmp218 any = tmp216.Invoke_O__O(tmp217.Ref()); var tmp219 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp219 = A_arbace_spec_gen_alpha_A_const_159; var tmp220 any = jrt.NN(tmp219).GetRawRoot__O(); var tmp221 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp221 = A_arbace_spec_gen_alpha_A_const_108; var tmp222 any = lang.IFn_Cast(jrt.NN(tmp221).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp223 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp223 = A_arbace_spec_gen_alpha_A_const_160; var tmp224 any = jrt.NN(tmp223).GetRawRoot__O(); var tmp225 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp225 = A_arbace_spec_gen_alpha_A_const_112; var tmp226 lang.IFn = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()); var tmp227 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp227 = A_arbace_spec_gen_alpha_A_const_143; var tmp228 any = lang.IFn_Cast(jrt.NN(tmp227).GetRawRoot__O()).Invoke__O(); var tmp229 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp229 = A_arbace_spec_gen_alpha_A_const_120; var tmp230 any = tmp226.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp228, lang.IFn_Cast(jrt.NN(tmp229).GetRawRoot__O()).Invoke__O())); var tmp231 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp231 = A_arbace_spec_gen_alpha_A_const_161; var tmp232 any = jrt.NN(tmp231).GetRawRoot__O(); var tmp233 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp233 = A_arbace_spec_gen_alpha_A_const_112; var tmp234 lang.IFn = lang.IFn_Cast(jrt.NN(tmp233).GetRawRoot__O()); var tmp235 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp235 = A_arbace_spec_gen_alpha_A_const_135; var tmp236 any = lang.IFn_Cast(jrt.NN(tmp235).GetRawRoot__O()).Invoke__O(); var tmp237 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp237 = A_arbace_spec_gen_alpha_A_const_175; var tmp238 any = tmp234.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp236, lang.IFn_Cast(jrt.NN(tmp237).GetRawRoot__O()).Invoke__O())); var tmp239 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp239 = A_arbace_spec_gen_alpha_A_const_162; var tmp240 any = jrt.NN(tmp239).GetRawRoot__O(); var tmp241 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp241 = A_arbace_spec_gen_alpha_A_const_112; var tmp242 lang.IFn = lang.IFn_Cast(jrt.NN(tmp241).GetRawRoot__O()); var tmp243 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp243 = A_arbace_spec_gen_alpha_A_const_135; var tmp244 any = lang.IFn_Cast(jrt.NN(tmp243).GetRawRoot__O()).Invoke__O(); var tmp245 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp245 = A_arbace_spec_gen_alpha_A_const_123; var tmp246 any = tmp242.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp244, lang.IFn_Cast(jrt.NN(tmp245).GetRawRoot__O()).Invoke__O())); var tmp247 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp247 = A_arbace_spec_gen_alpha_A_const_163; var tmp248 any = jrt.NN(tmp247).GetRawRoot__O(); var tmp249 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp249 = A_arbace_spec_gen_alpha_A_const_106; var tmp250 lang.IFn = lang.IFn_Cast(jrt.NN(tmp249).GetRawRoot__O()); var tmp251 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp251 = A_arbace_spec_gen_alpha_A_const_171; var tmp252 any = jrt.NN(tmp251).GetRawRoot__O(); var tmp253 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp253 = A_arbace_spec_gen_alpha_A_const_166; var tmp254 any = tmp250.Invoke_O_O__O(tmp252, lang.IFn_Cast(jrt.NN(tmp253).GetRawRoot__O()).Invoke__O()); var tmp255 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp255 = A_arbace_spec_gen_alpha_A_const_164; var tmp256 any = jrt.NN(tmp255).GetRawRoot__O(); var tmp257 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp257 = A_arbace_spec_gen_alpha_A_const_112; var tmp258 lang.IFn = lang.IFn_Cast(jrt.NN(tmp257).GetRawRoot__O()); var tmp259 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp259 = A_arbace_spec_gen_alpha_A_const_141; var tmp260 any = lang.IFn_Cast(jrt.NN(tmp259).GetRawRoot__O()).Invoke_O__O(nil); var tmp261 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp261 = A_arbace_spec_gen_alpha_A_const_108; var tmp262 any = lang.IFn_Cast(jrt.NN(tmp261).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp263 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp263 = A_arbace_spec_gen_alpha_A_const_110; var tmp264 any = lang.IFn_Cast(jrt.NN(tmp263).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp265 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp265 = A_arbace_spec_gen_alpha_A_const_127; var tmp266 any = lang.IFn_Cast(jrt.NN(tmp265).GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1); var tmp267 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp267 = A_arbace_spec_gen_alpha_A_const_125; var tmp268 any = lang.IFn_Cast(jrt.NN(tmp267).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp269 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp269 = A_arbace_spec_gen_alpha_A_const_131; var tmp270 any = tmp258.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp260, tmp262, tmp264, tmp266, tmp268, lang.IFn_Cast(jrt.NN(tmp269).GetRawRoot__O()).Invoke__O())); var tmp271 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp271 = A_arbace_spec_gen_alpha_A_const_165; var tmp272 any = jrt.NN(tmp271).GetRawRoot__O(); var tmp273 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp273 = A_arbace_spec_gen_alpha_A_const_166; var tmp274 any = lang.IFn_Cast(jrt.NN(tmp273).GetRawRoot__O()).Invoke__O(); var tmp275 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp275 = A_arbace_spec_gen_alpha_A_const_167; var tmp276 any = jrt.NN(tmp275).GetRawRoot__O(); var tmp277 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp277 = A_arbace_spec_gen_alpha_A_const_112; var tmp278 lang.IFn = lang.IFn_Cast(jrt.NN(tmp277).GetRawRoot__O()); var tmp279 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp279 = A_arbace_spec_gen_alpha_A_const_127; var tmp280 any = lang.IFn_Cast(jrt.NN(tmp279).GetRawRoot__O()).Invoke_O_O__O(simple__1, simple__1); var tmp281 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp281 = A_arbace_spec_gen_alpha_A_const_108; var tmp282 any = lang.IFn_Cast(jrt.NN(tmp281).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp283 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp283 = A_arbace_spec_gen_alpha_A_const_110; var tmp284 any = lang.IFn_Cast(jrt.NN(tmp283).GetRawRoot__O()).Invoke_O__O(simple__1); var tmp285 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp285 = A_arbace_spec_gen_alpha_A_const_125; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp12, tmp14, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, tmp36, tmp38, tmp40, tmp42, tmp44, tmp46, tmp52, tmp54, tmp61, tmp63, tmp65, tmp67, tmp73, tmp75, tmp77, tmp79, tmp81, tmp83, tmp85, tmp87, tmp97, tmp99, tmp101, tmp103, tmp110, tmp112, tmp114, tmp116, tmp118, tmp120, tmp126, tmp128, tmp130, tmp132, tmp134, tmp136, tmp140, tmp142, tmp144, tmp146, tmp150, tmp152, tmp154, tmp156, tmp158, tmp160, tmp166, tmp168, tmp178, tmp180, tmp184, tmp186, tmp188, tmp190, tmp196, tmp198, tmp202, tmp204, tmp208, tmp210, tmp212, tmp214, tmp218, tmp220, tmp222, tmp224, tmp230, tmp232, tmp238, tmp240, tmp246, tmp248, tmp254, tmp256, tmp270, tmp272, tmp274, tmp276, tmp278.Invoke_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp280, tmp282, tmp284, lang.IFn_Cast(jrt.NN(tmp285).GetRawRoot__O()).Invoke_O__O(simple__1))))) }























func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Ctor() {}
//line :163:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Invoke_O_O__O(self, p1__1067000329_SHARP___1 any) any { return jrt.URI_Create_String__URI(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_247, nil, Lit_248), jrt.RefArrayOf(jrt.Object_class, nil, p1__1067000329_SHARP___1, nil))).Ref() }
func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Ctor() {}
//line :164:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Invoke_O_O__O(self, p1__1067000330_SHARP___1 any) any { var tmp1 *jrt.Class; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_168; var tmp2 *jrt.Class = tmp1; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp2, Lit_244, jrt.RefArrayOf(jrt.Object_class, p1__1067000330_SHARP___1)) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_New() *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_Init(); t := &A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Ctor() {}
//line :166:1
func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Invoke_O_O__O(self, p1__1067000331_SHARP___1 any) any { return jrt.Date_New_J(lang.RT_LongCast_O__J(p1__1067000331_SHARP___1)) }





























func A_arbace_spec_gen_alpha_gen_for_pred_A_New() *A_arbace_spec_gen_alpha_gen_for_pred_A { A_arbace_spec_gen_alpha_gen_for_pred_A_Init(); t := &A_arbace_spec_gen_alpha_gen_for_pred_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Ctor() {}
//line :196:1
func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Invoke_O_O__O(self, pred__0 any) any {


	var tmp1 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp1 = A_arbace_spec_gen_alpha_A_const_124; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(pred__0)) {
		var tmp2 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp2 = A_arbace_spec_gen_alpha_A_const_129; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(pred__0) } else {
			var tmp3 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp3 = A_arbace_spec_gen_alpha_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_gen_alpha_A_Init(); tmp5 = A_arbace_spec_gen_alpha_A_const_178; return lang.RT_Get_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), pred__0)
		}
}



























































































































































































































































































































































































































































































































type A_arbace_spec_gen_alpha_A struct{ jrt.Object }

var A_arbace_spec_gen_alpha_A_const_0 *lang.Var

var A_arbace_spec_gen_alpha_A_const_1 any

var A_arbace_spec_gen_alpha_A_const_2 *lang.Keyword

var A_arbace_spec_gen_alpha_A_const_3 any

var A_arbace_spec_gen_alpha_A_const_4 *lang.Var

var A_arbace_spec_gen_alpha_A_const_5 *lang.Var

var A_arbace_spec_gen_alpha_A_const_6 *lang.Var

var A_arbace_spec_gen_alpha_A_const_7 any

var A_arbace_spec_gen_alpha_A_const_8 *lang.Var

var A_arbace_spec_gen_alpha_A_const_9 *lang.Var

var A_arbace_spec_gen_alpha_A_const_10 *lang.Var

var A_arbace_spec_gen_alpha_A_const_11 *lang.Var

var A_arbace_spec_gen_alpha_A_const_12 *lang.Var

var A_arbace_spec_gen_alpha_A_const_13 *lang.Var

var A_arbace_spec_gen_alpha_A_const_14 *lang.Var

var A_arbace_spec_gen_alpha_A_const_15 any

var A_arbace_spec_gen_alpha_A_const_16 *lang.Var

var A_arbace_spec_gen_alpha_A_const_17 any

var A_arbace_spec_gen_alpha_A_const_18 *lang.Var

var A_arbace_spec_gen_alpha_A_const_19 *lang.Var

var A_arbace_spec_gen_alpha_A_const_20 any

var A_arbace_spec_gen_alpha_A_const_21 *lang.Var

var A_arbace_spec_gen_alpha_A_const_22 any

var A_arbace_spec_gen_alpha_A_const_23 any

var A_arbace_spec_gen_alpha_A_const_24 any

var A_arbace_spec_gen_alpha_A_const_25 *lang.Var

var A_arbace_spec_gen_alpha_A_const_26 *lang.Keyword

var A_arbace_spec_gen_alpha_A_const_27 *lang.Var

var A_arbace_spec_gen_alpha_A_const_28 *lang.Var

var A_arbace_spec_gen_alpha_A_const_29 *lang.Var

var A_arbace_spec_gen_alpha_A_const_30 any

var A_arbace_spec_gen_alpha_A_const_31 any

var A_arbace_spec_gen_alpha_A_const_32 *lang.Var

var A_arbace_spec_gen_alpha_A_const_33 *lang.Var

var A_arbace_spec_gen_alpha_A_const_34 any

var A_arbace_spec_gen_alpha_A_const_35 *lang.Var

var A_arbace_spec_gen_alpha_A_const_36 any

var A_arbace_spec_gen_alpha_A_const_37 any

var A_arbace_spec_gen_alpha_A_const_38 any

var A_arbace_spec_gen_alpha_A_const_39 any

var A_arbace_spec_gen_alpha_A_const_40 any

var A_arbace_spec_gen_alpha_A_const_41 any

var A_arbace_spec_gen_alpha_A_const_42 any

var A_arbace_spec_gen_alpha_A_const_43 any

var A_arbace_spec_gen_alpha_A_const_44 any

var A_arbace_spec_gen_alpha_A_const_45 any

var A_arbace_spec_gen_alpha_A_const_46 *lang.Var

var A_arbace_spec_gen_alpha_A_const_47 any

var A_arbace_spec_gen_alpha_A_const_48 any

var A_arbace_spec_gen_alpha_A_const_49 any

var A_arbace_spec_gen_alpha_A_const_50 any

var A_arbace_spec_gen_alpha_A_const_51 any

var A_arbace_spec_gen_alpha_A_const_52 any

var A_arbace_spec_gen_alpha_A_const_53 any

var A_arbace_spec_gen_alpha_A_const_54 any

var A_arbace_spec_gen_alpha_A_const_55 any

var A_arbace_spec_gen_alpha_A_const_56 any

var A_arbace_spec_gen_alpha_A_const_57 any

var A_arbace_spec_gen_alpha_A_const_58 any

var A_arbace_spec_gen_alpha_A_const_59 any

var A_arbace_spec_gen_alpha_A_const_60 any

var A_arbace_spec_gen_alpha_A_const_61 any

var A_arbace_spec_gen_alpha_A_const_62 any

var A_arbace_spec_gen_alpha_A_const_63 any

var A_arbace_spec_gen_alpha_A_const_64 any

var A_arbace_spec_gen_alpha_A_const_65 any

var A_arbace_spec_gen_alpha_A_const_66 any

var A_arbace_spec_gen_alpha_A_const_67 any

var A_arbace_spec_gen_alpha_A_const_68 any

var A_arbace_spec_gen_alpha_A_const_69 any

var A_arbace_spec_gen_alpha_A_const_70 any

var A_arbace_spec_gen_alpha_A_const_71 any

var A_arbace_spec_gen_alpha_A_const_72 any

var A_arbace_spec_gen_alpha_A_const_73 any

var A_arbace_spec_gen_alpha_A_const_74 any

var A_arbace_spec_gen_alpha_A_const_75 any

var A_arbace_spec_gen_alpha_A_const_76 any

var A_arbace_spec_gen_alpha_A_const_77 any

var A_arbace_spec_gen_alpha_A_const_78 any

var A_arbace_spec_gen_alpha_A_const_79 any

var A_arbace_spec_gen_alpha_A_const_80 any

var A_arbace_spec_gen_alpha_A_const_81 any

var A_arbace_spec_gen_alpha_A_const_82 any

var A_arbace_spec_gen_alpha_A_const_83 any

var A_arbace_spec_gen_alpha_A_const_84 any

var A_arbace_spec_gen_alpha_A_const_85 any

var A_arbace_spec_gen_alpha_A_const_86 any

var A_arbace_spec_gen_alpha_A_const_87 any

var A_arbace_spec_gen_alpha_A_const_88 any

var A_arbace_spec_gen_alpha_A_const_89 any

var A_arbace_spec_gen_alpha_A_const_90 any

var A_arbace_spec_gen_alpha_A_const_91 any

var A_arbace_spec_gen_alpha_A_const_92 any

var A_arbace_spec_gen_alpha_A_const_93 any

var A_arbace_spec_gen_alpha_A_const_94 any

var A_arbace_spec_gen_alpha_A_const_95 any

var A_arbace_spec_gen_alpha_A_const_96 any

var A_arbace_spec_gen_alpha_A_const_97 any

var A_arbace_spec_gen_alpha_A_const_98 any

var A_arbace_spec_gen_alpha_A_const_99 any

var A_arbace_spec_gen_alpha_A_const_100 *lang.Var

var A_arbace_spec_gen_alpha_A_const_101 *lang.Var

var A_arbace_spec_gen_alpha_A_const_102 *lang.Var

var A_arbace_spec_gen_alpha_A_const_103 *lang.Var

var A_arbace_spec_gen_alpha_A_const_104 *lang.Var

var A_arbace_spec_gen_alpha_A_const_105 *lang.Var

var A_arbace_spec_gen_alpha_A_const_106 *lang.Var

var A_arbace_spec_gen_alpha_A_const_107 *lang.Var

var A_arbace_spec_gen_alpha_A_const_108 *lang.Var

var A_arbace_spec_gen_alpha_A_const_109 *lang.Var

var A_arbace_spec_gen_alpha_A_const_110 *lang.Var

var A_arbace_spec_gen_alpha_A_const_111 *lang.Var

var A_arbace_spec_gen_alpha_A_const_112 *lang.Var

var A_arbace_spec_gen_alpha_A_const_113 *lang.Var

var A_arbace_spec_gen_alpha_A_const_114 *lang.Var

var A_arbace_spec_gen_alpha_A_const_115 *lang.Var

var A_arbace_spec_gen_alpha_A_const_116 *lang.Var

var A_arbace_spec_gen_alpha_A_const_117 *lang.Var

var A_arbace_spec_gen_alpha_A_const_118 *lang.Var

var A_arbace_spec_gen_alpha_A_const_119 *lang.Var

var A_arbace_spec_gen_alpha_A_const_120 *lang.Var

var A_arbace_spec_gen_alpha_A_const_121 *lang.Var

var A_arbace_spec_gen_alpha_A_const_122 *lang.Var

var A_arbace_spec_gen_alpha_A_const_123 *lang.Var

var A_arbace_spec_gen_alpha_A_const_124 *lang.Var

var A_arbace_spec_gen_alpha_A_const_125 *lang.Var

var A_arbace_spec_gen_alpha_A_const_126 *lang.Var

var A_arbace_spec_gen_alpha_A_const_127 *lang.Var

var A_arbace_spec_gen_alpha_A_const_128 *lang.Var

var A_arbace_spec_gen_alpha_A_const_129 *lang.Var

var A_arbace_spec_gen_alpha_A_const_130 *lang.Var

var A_arbace_spec_gen_alpha_A_const_131 *lang.Var

var A_arbace_spec_gen_alpha_A_const_132 *lang.Var

var A_arbace_spec_gen_alpha_A_const_133 *lang.Var

var A_arbace_spec_gen_alpha_A_const_134 *lang.Var

var A_arbace_spec_gen_alpha_A_const_135 *lang.Var

var A_arbace_spec_gen_alpha_A_const_136 *lang.Var

var A_arbace_spec_gen_alpha_A_const_137 *lang.Var

var A_arbace_spec_gen_alpha_A_const_138 *lang.Var

var A_arbace_spec_gen_alpha_A_const_139 *lang.Var

var A_arbace_spec_gen_alpha_A_const_140 *lang.Var

var A_arbace_spec_gen_alpha_A_const_141 *lang.Var

var A_arbace_spec_gen_alpha_A_const_142 *lang.Var

var A_arbace_spec_gen_alpha_A_const_143 *lang.Var

var A_arbace_spec_gen_alpha_A_const_144 *lang.Var

var A_arbace_spec_gen_alpha_A_const_145 *lang.Var

var A_arbace_spec_gen_alpha_A_const_146 *lang.Var

var A_arbace_spec_gen_alpha_A_const_147 *lang.Var

var A_arbace_spec_gen_alpha_A_const_148 *lang.Var

var A_arbace_spec_gen_alpha_A_const_149 *lang.Var

var A_arbace_spec_gen_alpha_A_const_150 *lang.Var

var A_arbace_spec_gen_alpha_A_const_151 *lang.Var

var A_arbace_spec_gen_alpha_A_const_152 *lang.Var

var A_arbace_spec_gen_alpha_A_const_153 *lang.Var

var A_arbace_spec_gen_alpha_A_const_154 *lang.Var

var A_arbace_spec_gen_alpha_A_const_155 *lang.Var

var A_arbace_spec_gen_alpha_A_const_156 *lang.Var

var A_arbace_spec_gen_alpha_A_const_157 *lang.Var

var A_arbace_spec_gen_alpha_A_const_158 *lang.Var

var A_arbace_spec_gen_alpha_A_const_159 *lang.Var

var A_arbace_spec_gen_alpha_A_const_160 *lang.Var

var A_arbace_spec_gen_alpha_A_const_161 *lang.Var

var A_arbace_spec_gen_alpha_A_const_162 *lang.Var

var A_arbace_spec_gen_alpha_A_const_163 *lang.Var

var A_arbace_spec_gen_alpha_A_const_164 *lang.Var

var A_arbace_spec_gen_alpha_A_const_165 *lang.Var

var A_arbace_spec_gen_alpha_A_const_166 *lang.Var

var A_arbace_spec_gen_alpha_A_const_167 *lang.Var

var A_arbace_spec_gen_alpha_A_const_168 *jrt.Class

var A_arbace_spec_gen_alpha_A_const_169 *lang.Var

var A_arbace_spec_gen_alpha_A_const_170 any

var A_arbace_spec_gen_alpha_A_const_171 *lang.Var

var A_arbace_spec_gen_alpha_A_const_172 *lang.Var

var A_arbace_spec_gen_alpha_A_const_173 any

var A_arbace_spec_gen_alpha_A_const_174 any

var A_arbace_spec_gen_alpha_A_const_175 *lang.Var

var A_arbace_spec_gen_alpha_A_const_176 any

var A_arbace_spec_gen_alpha_A_const_177 any

var A_arbace_spec_gen_alpha_A_const_178 *lang.Var

var A_arbace_spec_gen_alpha_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_A_Init() { if !A_arbace_spec_gen_alpha_A_init.Done() { A_arbace_spec_gen_alpha_A_init.Run(A_arbace_spec_gen_alpha_A_clinit) } }

func A_arbace_spec_gen_alpha_A_clinit() { A_arbace_spec_gen_alpha_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_spec_gen_alpha_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_spec_gen_alpha_A_const_2 = lang.RT_Keyword_String_String__Keyword(nil, Lit_2); A_arbace_spec_gen_alpha_A_const_3 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())); A_arbace_spec_gen_alpha_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_spec_gen_alpha_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_spec_gen_alpha_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_spec_gen_alpha_A_const_7 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(); A_arbace_spec_gen_alpha_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_spec_gen_alpha_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_spec_gen_alpha_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_spec_gen_alpha_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_spec_gen_alpha_A_const_12 = lang.RT_Var_String_String__Var(Lit_25, Lit_30); A_arbace_spec_gen_alpha_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_spec_gen_alpha_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_spec_gen_alpha_A_const_15 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(); A_arbace_spec_gen_alpha_A_const_16 = lang.RT_Var_String_String__Var(Lit_25, Lit_33); A_arbace_spec_gen_alpha_A_const_17 = lang.Symbol_Intern_String_String__Symbol(Lit_34, Lit_35).Ref(); A_arbace_spec_gen_alpha_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_spec_gen_alpha_A_const_19 = lang.RT_Var_String_String__Var(Lit_25, Lit_37); A_arbace_spec_gen_alpha_A_const_20 = lang.Symbol_Intern_String_String__Symbol(Lit_38, Lit_39).Ref(); A_arbace_spec_gen_alpha_A_const_21 = lang.RT_Var_String_String__Var(Lit_25, Lit_40); A_arbace_spec_gen_alpha_A_const_22 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_42).Ref(); A_arbace_spec_gen_alpha_A_const_23 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_43).Ref(); A_arbace_spec_gen_alpha_A_const_24 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_44).Ref(); A_arbace_spec_gen_alpha_A_const_25 = lang.RT_Var_String_String__Var(Lit_25, Lit_45); A_arbace_spec_gen_alpha_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_spec_gen_alpha_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_spec_gen_alpha_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_spec_gen_alpha_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_spec_gen_alpha_A_const_30 = lang.Symbol_Intern_String_String__Symbol(Lit_25, Lit_49).Ref(); A_arbace_spec_gen_alpha_A_const_31 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_19).Ref(); A_arbace_spec_gen_alpha_A_const_32 = lang.RT_Var_String_String__Var(Lit_25, Lit_42); A_arbace_spec_gen_alpha_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_spec_gen_alpha_A_const_34 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_51).Ref(); A_arbace_spec_gen_alpha_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_spec_gen_alpha_A_const_36 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref(); A_arbace_spec_gen_alpha_A_const_37 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_19).Ref(); A_arbace_spec_gen_alpha_A_const_38 = lang.Symbol_Intern_String_String__Symbol(Lit_25, Lit_33).Ref(); A_arbace_spec_gen_alpha_A_const_39 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_53).Ref(); A_arbace_spec_gen_alpha_A_const_40 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_54).Ref(); A_arbace_spec_gen_alpha_A_const_41 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(); A_arbace_spec_gen_alpha_A_const_42 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(); A_arbace_spec_gen_alpha_A_const_43 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_36).Ref(); A_arbace_spec_gen_alpha_A_const_44 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_23).Ref(); A_arbace_spec_gen_alpha_A_const_45 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(); A_arbace_spec_gen_alpha_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_spec_gen_alpha_A_const_47 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref(); A_arbace_spec_gen_alpha_A_const_48 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref(); A_arbace_spec_gen_alpha_A_const_49 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_6).Ref(); A_arbace_spec_gen_alpha_A_const_50 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_7).Ref(); A_arbace_spec_gen_alpha_A_const_51 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_8).Ref(); A_arbace_spec_gen_alpha_A_const_52 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_9).Ref(); A_arbace_spec_gen_alpha_A_const_53 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_10).Ref(); A_arbace_spec_gen_alpha_A_const_54 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_11).Ref(); A_arbace_spec_gen_alpha_A_const_55 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_59).Ref(); A_arbace_spec_gen_alpha_A_const_56 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_60).Ref(); A_arbace_spec_gen_alpha_A_const_57 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_61).Ref(); A_arbace_spec_gen_alpha_A_const_58 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_62).Ref(); A_arbace_spec_gen_alpha_A_const_59 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_63).Ref(); A_arbace_spec_gen_alpha_A_const_60 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_64).Ref(); A_arbace_spec_gen_alpha_A_const_61 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_65).Ref(); A_arbace_spec_gen_alpha_A_const_62 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_66).Ref(); A_arbace_spec_gen_alpha_A_const_63 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_67).Ref(); A_arbace_spec_gen_alpha_A_const_64 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_21).Ref(); A_arbace_spec_gen_alpha_A_const_65 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_68).Ref(); A_arbace_spec_gen_alpha_A_const_66 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_69).Ref(); A_arbace_spec_gen_alpha_A_const_67 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_70).Ref(); A_arbace_spec_gen_alpha_A_const_68 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_20).Ref(); A_arbace_spec_gen_alpha_A_const_69 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_51).Ref(); A_arbace_spec_gen_alpha_A_const_70 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(); A_arbace_spec_gen_alpha_A_const_71 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_19).Ref(); A_arbace_spec_gen_alpha_A_const_72 = lang.Symbol_Intern_String_String__Symbol(Lit_25, Lit_33).Ref(); A_arbace_spec_gen_alpha_A_const_73 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_54).Ref(); A_arbace_spec_gen_alpha_A_const_74 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(); A_arbace_spec_gen_alpha_A_const_75 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(); A_arbace_spec_gen_alpha_A_const_76 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref(); A_arbace_spec_gen_alpha_A_const_77 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(); A_arbace_spec_gen_alpha_A_const_78 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_73).Ref(); A_arbace_spec_gen_alpha_A_const_79 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_74).Ref(); A_arbace_spec_gen_alpha_A_const_80 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_3).Ref(); A_arbace_spec_gen_alpha_A_const_81 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_4).Ref(); A_arbace_spec_gen_alpha_A_const_82 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_12).Ref(); A_arbace_spec_gen_alpha_A_const_83 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_75).Ref(); A_arbace_spec_gen_alpha_A_const_84 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_76).Ref(); A_arbace_spec_gen_alpha_A_const_85 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_77).Ref(); A_arbace_spec_gen_alpha_A_const_86 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_13).Ref(); A_arbace_spec_gen_alpha_A_const_87 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_14).Ref(); A_arbace_spec_gen_alpha_A_const_88 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_15).Ref(); A_arbace_spec_gen_alpha_A_const_89 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_78).Ref(); A_arbace_spec_gen_alpha_A_const_90 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_79).Ref(); A_arbace_spec_gen_alpha_A_const_91 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_80).Ref(); A_arbace_spec_gen_alpha_A_const_92 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_81).Ref(); A_arbace_spec_gen_alpha_A_const_93 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_82).Ref(); A_arbace_spec_gen_alpha_A_const_94 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_17).Ref(); A_arbace_spec_gen_alpha_A_const_95 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_83).Ref(); A_arbace_spec_gen_alpha_A_const_96 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_84).Ref(); A_arbace_spec_gen_alpha_A_const_97 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_16).Ref(); A_arbace_spec_gen_alpha_A_const_98 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_85).Ref(); A_arbace_spec_gen_alpha_A_const_99 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_18).Ref(); A_arbace_spec_gen_alpha_A_const_100 = lang.RT_Var_String_String__Var(Lit_25, Lit_63); A_arbace_spec_gen_alpha_A_const_101 = lang.RT_Var_String_String__Var(Lit_25, Lit_66); A_arbace_spec_gen_alpha_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_spec_gen_alpha_A_const_103 = lang.RT_Var_String_String__Var(Lit_25, Lit_82); A_arbace_spec_gen_alpha_A_const_104 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_spec_gen_alpha_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_spec_gen_alpha_A_const_106 = lang.RT_Var_String_String__Var(Lit_25, Lit_65); A_arbace_spec_gen_alpha_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_spec_gen_alpha_A_const_108 = lang.RT_Var_String_String__Var(Lit_25, Lit_7); A_arbace_spec_gen_alpha_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_spec_gen_alpha_A_const_110 = lang.RT_Var_String_String__Var(Lit_25, Lit_11); A_arbace_spec_gen_alpha_A_const_111 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_spec_gen_alpha_A_const_112 = lang.RT_Var_String_String__Var(Lit_25, Lit_64); A_arbace_spec_gen_alpha_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_spec_gen_alpha_A_const_114 = lang.RT_Var_String_String__Var(Lit_25, Lit_3); A_arbace_spec_gen_alpha_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_spec_gen_alpha_A_const_116 = lang.RT_Var_String_String__Var(Lit_25, Lit_12); A_arbace_spec_gen_alpha_A_const_117 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_spec_gen_alpha_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_spec_gen_alpha_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_spec_gen_alpha_A_const_120 = lang.RT_Var_String_String__Var(Lit_25, Lit_16); A_arbace_spec_gen_alpha_A_const_121 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_spec_gen_alpha_A_const_122 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_spec_gen_alpha_A_const_123 = lang.RT_Var_String_String__Var(Lit_25, Lit_13); A_arbace_spec_gen_alpha_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_spec_gen_alpha_A_const_125 = lang.RT_Var_String_String__Var(Lit_25, Lit_10); A_arbace_spec_gen_alpha_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_spec_gen_alpha_A_const_127 = lang.RT_Var_String_String__Var(Lit_25, Lit_8); A_arbace_spec_gen_alpha_A_const_128 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_spec_gen_alpha_A_const_129 = lang.RT_Var_String_String__Var(Lit_25, Lit_60); A_arbace_spec_gen_alpha_A_const_130 = lang.RT_Var_String_String__Var(Lit_0, Lit_102); A_arbace_spec_gen_alpha_A_const_131 = lang.RT_Var_String_String__Var(Lit_25, Lit_84); A_arbace_spec_gen_alpha_A_const_132 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_spec_gen_alpha_A_const_133 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_spec_gen_alpha_A_const_134 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_spec_gen_alpha_A_const_135 = lang.RT_Var_String_String__Var(Lit_25, Lit_79); A_arbace_spec_gen_alpha_A_const_136 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_spec_gen_alpha_A_const_137 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_spec_gen_alpha_A_const_138 = lang.RT_Var_String_String__Var(Lit_25, Lit_78); A_arbace_spec_gen_alpha_A_const_139 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_spec_gen_alpha_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_spec_gen_alpha_A_const_141 = lang.RT_Var_String_String__Var(Lit_25, Lit_21); A_arbace_spec_gen_alpha_A_const_142 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_spec_gen_alpha_A_const_143 = lang.RT_Var_String_String__Var(Lit_25, Lit_15); A_arbace_spec_gen_alpha_A_const_144 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_spec_gen_alpha_A_const_145 = lang.RT_Var_String_String__Var(Lit_25, Lit_68); A_arbace_spec_gen_alpha_A_const_146 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_spec_gen_alpha_A_const_147 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_spec_gen_alpha_A_const_148 = lang.RT_Var_String_String__Var(Lit_25, Lit_4); A_arbace_spec_gen_alpha_A_const_149 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_spec_gen_alpha_A_const_150 = lang.RT_Var_String_String__Var(Lit_0, Lit_115); A_arbace_spec_gen_alpha_A_const_151 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_spec_gen_alpha_A_const_152 = lang.RT_Var_String_String__Var(Lit_0, Lit_117); A_arbace_spec_gen_alpha_A_const_153 = lang.RT_Var_String_String__Var(Lit_0, Lit_118); A_arbace_spec_gen_alpha_A_const_154 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_spec_gen_alpha_A_const_155 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_spec_gen_alpha_A_const_156 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_spec_gen_alpha_A_const_157 = lang.RT_Var_String_String__Var(Lit_25, Lit_18); A_arbace_spec_gen_alpha_A_const_158 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_spec_gen_alpha_A_const_159 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_spec_gen_alpha_A_const_160 = lang.RT_Var_String_String__Var(Lit_0, Lit_124); A_arbace_spec_gen_alpha_A_const_161 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_spec_gen_alpha_A_const_162 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_spec_gen_alpha_A_const_163 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_spec_gen_alpha_A_const_164 = lang.RT_Var_String_String__Var(Lit_0, Lit_128); A_arbace_spec_gen_alpha_A_const_165 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_spec_gen_alpha_A_const_166 = lang.RT_Var_String_String__Var(Lit_25, Lit_85); A_arbace_spec_gen_alpha_A_const_167 = lang.RT_Var_String_String__Var(Lit_0, Lit_130); A_arbace_spec_gen_alpha_A_const_168 = lang.RT_ClassForNameNonLoading_String__Class(Lit_131); A_arbace_spec_gen_alpha_A_const_169 = lang.RT_Var_String_String__Var(Lit_25, Lit_69); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; var tmp3 any = tmp2.Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; A_arbace_spec_gen_alpha_A_const_170 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp5.Ref())); A_arbace_spec_gen_alpha_A_const_171 = lang.RT_Var_String_String__Var(Lit_25, Lit_134); A_arbace_spec_gen_alpha_A_const_172 = lang.RT_Var_String_String__Var(Lit_25, Lit_74); A_arbace_spec_gen_alpha_A_const_173 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_spec_gen_alpha_A_const_174 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Long_ValueOf_J__Long(-1).Ref())); A_arbace_spec_gen_alpha_A_const_175 = lang.RT_Var_String_String__Var(Lit_25, Lit_80); A_arbace_spec_gen_alpha_A_const_176 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())); A_arbace_spec_gen_alpha_A_const_177 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), jrt.Long_ValueOf_J__Long(1).Ref())); A_arbace_spec_gen_alpha_A_const_178 = lang.RT_Var_String_String__Var(Lit_25, Lit_137) }

func A_arbace_spec_gen_alpha_A_New() *A_arbace_spec_gen_alpha_A { A_arbace_spec_gen_alpha_A_Init(); t := &A_arbace_spec_gen_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_A_class }

func (t *A_arbace_spec_gen_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_A); return ok }

func A_arbace_spec_gen_alpha_A_Cast(x any) *A_arbace_spec_gen_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_A_class)) }; return v }



type A_arbace_spec_gen_alpha_cat_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_cat_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_cat_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_cat_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_cat_A_Init() { if !A_arbace_spec_gen_alpha_cat_A_init.Done() { A_arbace_spec_gen_alpha_cat_A_init.Run(A_arbace_spec_gen_alpha_cat_A_clinit) } }

func A_arbace_spec_gen_alpha_cat_A_clinit() { A_arbace_spec_gen_alpha_cat_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_cat_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_cat_A_class }

func (t *A_arbace_spec_gen_alpha_cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_cat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_cat_A); return ok }

func A_arbace_spec_gen_alpha_cat_A_Cast(x any) *A_arbace_spec_gen_alpha_cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_cat_A_class)) }; return v }



type A_arbace_spec_gen_alpha_cat_fn__1067000325_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_cat_fn__1067000325_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_Init() { if !A_arbace_spec_gen_alpha_cat_fn__1067000325_A_init.Done() { A_arbace_spec_gen_alpha_cat_fn__1067000325_A_init.Run(A_arbace_spec_gen_alpha_cat_fn__1067000325_A_clinit) } }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_clinit() { A_arbace_spec_gen_alpha_cat_fn__1067000325_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_cat_fn__1067000325_A_class }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_cat_fn__1067000325_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_cat_fn__1067000325_A); return ok }

func A_arbace_spec_gen_alpha_cat_fn__1067000325_A_Cast(x any) *A_arbace_spec_gen_alpha_cat_fn__1067000325_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_cat_fn__1067000325_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_cat_fn__1067000325_A_class)) }; return v }



type A_arbace_spec_gen_alpha_delay_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_delay_A) Is_Compiler_AOTR2() {}

var A_arbace_spec_gen_alpha_delay_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_delay_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_delay_A_Init() { if !A_arbace_spec_gen_alpha_delay_A_init.Done() { A_arbace_spec_gen_alpha_delay_A_init.Run(A_arbace_spec_gen_alpha_delay_A_clinit) } }

func A_arbace_spec_gen_alpha_delay_A_clinit() { A_arbace_spec_gen_alpha_delay_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_delay_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_delay_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_delay_A_class }

func (t *A_arbace_spec_gen_alpha_delay_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_delay_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_delay_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_delay_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_delay_A); return ok }

func A_arbace_spec_gen_alpha_delay_A_Cast(x any) *A_arbace_spec_gen_alpha_delay_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_delay_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_delay_A_class)) }; return v }



type A_arbace_spec_gen_alpha_delay_impl_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_delay_impl_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_delay_impl_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_delay_impl_A_Init() { if !A_arbace_spec_gen_alpha_delay_impl_A_init.Done() { A_arbace_spec_gen_alpha_delay_impl_A_init.Run(A_arbace_spec_gen_alpha_delay_impl_A_clinit) } }

func A_arbace_spec_gen_alpha_delay_impl_A_clinit() { A_arbace_spec_gen_alpha_delay_impl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_delay_impl_A_class }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_delay_impl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_delay_impl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_delay_impl_A); return ok }

func A_arbace_spec_gen_alpha_delay_impl_A_Cast(x any) *A_arbace_spec_gen_alpha_delay_impl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_delay_impl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_delay_impl_A_class)) }; return v }



type A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A struct{ jrt.Object; F_gfnd any }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_Init() { if !A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_init.Done() { A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_init.Run(A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_clinit) } }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_clinit() { A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_class }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A); return ok }

func A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_Cast(x any) *A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_delay_impl_fn__1067000037_A_class)) }; return v }



type A_arbace_spec_gen_alpha_dynaload_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_dynaload_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_dynaload_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_dynaload_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_dynaload_A_Init() { if !A_arbace_spec_gen_alpha_dynaload_A_init.Done() { A_arbace_spec_gen_alpha_dynaload_A_init.Run(A_arbace_spec_gen_alpha_dynaload_A_clinit) } }

func A_arbace_spec_gen_alpha_dynaload_A_clinit() { A_arbace_spec_gen_alpha_dynaload_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_dynaload_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_dynaload_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_dynaload_A_class }

func (t *A_arbace_spec_gen_alpha_dynaload_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_dynaload_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_dynaload_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_dynaload_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_dynaload_A); return ok }

func A_arbace_spec_gen_alpha_dynaload_A_Cast(x any) *A_arbace_spec_gen_alpha_dynaload_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_dynaload_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_dynaload_A_class)) }; return v }



type A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A struct{ jrt.Object; F_lockee__1927000360__auto__, F_ns any }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_Init() { if !A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_init.Done() { A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_init.Run(A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_clinit) } }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_clinit() { A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_class }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A); return ok }

func A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_Cast(x any) *A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_dynaload_fn__1067000014_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000002_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000002_A_New() *A_arbace_spec_gen_alpha_eval1067000002_A { t := &A_arbace_spec_gen_alpha_eval1067000002_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000002_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000002_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000002_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_init.Run(A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_clinit() { A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000002_loading__1927001464__auto____1067000003_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000006_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000006_A_New() *A_arbace_spec_gen_alpha_eval1067000006_A { t := &A_arbace_spec_gen_alpha_eval1067000006_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000006_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000006_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000006_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_init.Run(A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_clinit() { A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000006_fn__1067000007_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000023_A_New() *A_arbace_spec_gen_alpha_eval1067000023_A { t := &A_arbace_spec_gen_alpha_eval1067000023_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_150, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_fn__1067000024_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_fn__1067000026_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_fn__1067000028_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A struct{ jrt.Object; F_g any }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_153, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A struct{ jrt.Object; F_g_QMARK_ any }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_generator_QMARK___1067000030_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A struct{ jrt.Object; F_mkg any }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_init.Run(A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_clinit() { A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000023_generator__1067000032_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000059_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000059_A_New() *A_arbace_spec_gen_alpha_eval1067000059_A { t := &A_arbace_spec_gen_alpha_eval1067000059_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000059_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000059_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000059_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_init.Run(A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_clinit() { A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000059_fn__1067000060_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_init.Run(A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_clinit() { A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000059_hash_map__1067000062_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000065_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000065_A_New() *A_arbace_spec_gen_alpha_eval1067000065_A { t := &A_arbace_spec_gen_alpha_eval1067000065_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000065_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000065_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000065_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_init.Run(A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_clinit() { A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000065_fn__1067000066_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_init.Run(A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_clinit() { A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000065_list__1067000068_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000071_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000071_A_New() *A_arbace_spec_gen_alpha_eval1067000071_A { t := &A_arbace_spec_gen_alpha_eval1067000071_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000071_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000071_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000071_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_init.Run(A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_clinit() { A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000071_fn__1067000072_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_init.Run(A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_clinit() { A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000071_map__1067000074_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000077_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000077_A_New() *A_arbace_spec_gen_alpha_eval1067000077_A { t := &A_arbace_spec_gen_alpha_eval1067000077_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000077_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000077_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000077_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_init.Run(A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_clinit() { A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000077_fn__1067000078_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_init.Run(A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_clinit() { A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000077_not_empty__1067000080_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000083_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000083_A_New() *A_arbace_spec_gen_alpha_eval1067000083_A { t := &A_arbace_spec_gen_alpha_eval1067000083_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000083_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000083_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000083_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000083_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000083_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_init.Run(A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_clinit() { A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000083_fn__1067000084_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_init.Run(A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_clinit() { A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000083_set__1067000086_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000089_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000089_A_New() *A_arbace_spec_gen_alpha_eval1067000089_A { t := &A_arbace_spec_gen_alpha_eval1067000089_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000089_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000089_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000089_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_init.Run(A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_clinit() { A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000089_fn__1067000090_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_init.Run(A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_clinit() { A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000089_vector__1067000092_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000095_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000095_A_New() *A_arbace_spec_gen_alpha_eval1067000095_A { t := &A_arbace_spec_gen_alpha_eval1067000095_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000095_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000095_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000095_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_init.Run(A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_clinit() { A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000095_fn__1067000096_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_init.Run(A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_clinit() { A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000095_vector_distinct__1067000098_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000101_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000101_A_New() *A_arbace_spec_gen_alpha_eval1067000101_A { t := &A_arbace_spec_gen_alpha_eval1067000101_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000101_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000101_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000101_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_init.Run(A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_clinit() { A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000101_elements__1067000104_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_init.Run(A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_clinit() { A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000101_fn__1067000102_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000107_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000107_A_New() *A_arbace_spec_gen_alpha_eval1067000107_A { t := &A_arbace_spec_gen_alpha_eval1067000107_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000107_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000107_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000107_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_init.Run(A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_clinit() { A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000107_bind__1067000110_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_init.Run(A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_clinit() { A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000107_fn__1067000108_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000113_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000113_A_New() *A_arbace_spec_gen_alpha_eval1067000113_A { t := &A_arbace_spec_gen_alpha_eval1067000113_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000113_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000113_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000113_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_init.Run(A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_clinit() { A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000113_choose__1067000116_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_init.Run(A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_clinit() { A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000113_fn__1067000114_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000119_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000119_A_New() *A_arbace_spec_gen_alpha_eval1067000119_A { t := &A_arbace_spec_gen_alpha_eval1067000119_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000119_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000119_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000119_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_init.Run(A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_clinit() { A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_176, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000119_fmap__1067000122_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_init.Run(A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_clinit() { A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_177, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000119_fn__1067000120_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000125_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000125_A_New() *A_arbace_spec_gen_alpha_eval1067000125_A { t := &A_arbace_spec_gen_alpha_eval1067000125_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000125_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000125_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000125_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_init.Run(A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_clinit() { A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000125_fn__1067000126_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_init.Run(A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_clinit() { A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000125_one_of__1067000128_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000131_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000131_A_New() *A_arbace_spec_gen_alpha_eval1067000131_A { t := &A_arbace_spec_gen_alpha_eval1067000131_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000131_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000131_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000131_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_init.Run(A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_clinit() { A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000131_fn__1067000132_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_init.Run(A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_clinit() { A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000131_such_that__1067000134_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000137_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000137_A_New() *A_arbace_spec_gen_alpha_eval1067000137_A { t := &A_arbace_spec_gen_alpha_eval1067000137_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000137_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000137_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000137_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_init.Run(A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_clinit() { A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000137_fn__1067000138_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_init.Run(A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_clinit() { A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000137_tuple__1067000140_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000143_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000143_A_New() *A_arbace_spec_gen_alpha_eval1067000143_A { t := &A_arbace_spec_gen_alpha_eval1067000143_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000143_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000143_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000143_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_init.Run(A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_clinit() { A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000143_fn__1067000144_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_init.Run(A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_clinit() { A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_185, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000143_sample__1067000146_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000149_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000149_A_New() *A_arbace_spec_gen_alpha_eval1067000149_A { t := &A_arbace_spec_gen_alpha_eval1067000149_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000149_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000149_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000149_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000149_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000149_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_init.Run(A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_clinit() { A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000149_fn__1067000150_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_init.Run(A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_clinit() { A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_187, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000149_return__1067000152_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000155_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000155_A_New() *A_arbace_spec_gen_alpha_eval1067000155_A { t := &A_arbace_spec_gen_alpha_eval1067000155_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000155_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000155_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000155_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_init.Run(A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_clinit() { A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_188, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000155_fn__1067000156_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_init.Run(A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_clinit() { A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_189, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000155_large_integer_STAR___1067000158_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000161_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000161_A_New() *A_arbace_spec_gen_alpha_eval1067000161_A { t := &A_arbace_spec_gen_alpha_eval1067000161_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000161_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000161_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000161_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_init.Run(A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_clinit() { A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_190, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000161_double_STAR___1067000164_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_init.Run(A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_clinit() { A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_191, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000161_fn__1067000162_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000167_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000167_A_New() *A_arbace_spec_gen_alpha_eval1067000167_A { t := &A_arbace_spec_gen_alpha_eval1067000167_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000167_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000167_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000167_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_init.Run(A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_clinit() { A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_192, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000167_fn__1067000168_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_init.Run(A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_clinit() { A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000167_frequency__1067000170_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000173_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000173_A_New() *A_arbace_spec_gen_alpha_eval1067000173_A { t := &A_arbace_spec_gen_alpha_eval1067000173_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000173_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000173_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000173_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000173_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000173_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_init.Run(A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_clinit() { A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000173_fn__1067000174_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A struct{ jrt.Object; F_g__1067000046__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_init.Run(A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_clinit() { A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000173_shuffle__1067000176_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000192_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000192_A_New() *A_arbace_spec_gen_alpha_eval1067000192_A { t := &A_arbace_spec_gen_alpha_eval1067000192_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000192_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000192_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000192_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_init.Run(A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_clinit() { A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000192_any__1067000195_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_init.Run(A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_clinit() { A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000192_fn__1067000193_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000198_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000198_A_New() *A_arbace_spec_gen_alpha_eval1067000198_A { t := &A_arbace_spec_gen_alpha_eval1067000198_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000198_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000198_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000198_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_init.Run(A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_clinit() { A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000198_any_printable__1067000201_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_init.Run(A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_clinit() { A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000198_fn__1067000199_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000204_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000204_A_New() *A_arbace_spec_gen_alpha_eval1067000204_A { t := &A_arbace_spec_gen_alpha_eval1067000204_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000204_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000204_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000204_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000204_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000204_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_init.Run(A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_clinit() { A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000204_boolean__1067000207_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_init.Run(A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_clinit() { A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000204_fn__1067000205_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000210_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000210_A_New() *A_arbace_spec_gen_alpha_eval1067000210_A { t := &A_arbace_spec_gen_alpha_eval1067000210_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000210_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000210_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000210_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_init.Run(A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_clinit() { A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000210_bytes__1067000213_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_init.Run(A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_clinit() { A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000210_fn__1067000211_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000216_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000216_A_New() *A_arbace_spec_gen_alpha_eval1067000216_A { t := &A_arbace_spec_gen_alpha_eval1067000216_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000216_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000216_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000216_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000216_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000216_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_init.Run(A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_clinit() { A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000216_char__1067000219_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_init.Run(A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_clinit() { A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000216_fn__1067000217_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000222_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000222_A_New() *A_arbace_spec_gen_alpha_eval1067000222_A { t := &A_arbace_spec_gen_alpha_eval1067000222_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000222_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000222_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000222_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000222_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000222_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_init.Run(A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_clinit() { A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000222_char_alpha__1067000225_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_init.Run(A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_clinit() { A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000222_fn__1067000223_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000228_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000228_A_New() *A_arbace_spec_gen_alpha_eval1067000228_A { t := &A_arbace_spec_gen_alpha_eval1067000228_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000228_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000228_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000228_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000228_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000228_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_init.Run(A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_clinit() { A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000228_char_alphanumeric__1067000231_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_init.Run(A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_clinit() { A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000228_fn__1067000229_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000234_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000234_A_New() *A_arbace_spec_gen_alpha_eval1067000234_A { t := &A_arbace_spec_gen_alpha_eval1067000234_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000234_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000234_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000234_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000234_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000234_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_init.Run(A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_clinit() { A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000234_char_ascii__1067000237_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_init.Run(A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_clinit() { A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000234_fn__1067000235_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000240_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000240_A_New() *A_arbace_spec_gen_alpha_eval1067000240_A { t := &A_arbace_spec_gen_alpha_eval1067000240_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000240_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000240_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000240_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_init.Run(A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_clinit() { A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000240_double__1067000243_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_init.Run(A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_clinit() { A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000240_fn__1067000241_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000246_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000246_A_New() *A_arbace_spec_gen_alpha_eval1067000246_A { t := &A_arbace_spec_gen_alpha_eval1067000246_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000246_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000246_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000246_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000246_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000246_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_init.Run(A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_clinit() { A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000246_fn__1067000247_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_init.Run(A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_clinit() { A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000246_int__1067000249_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000252_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000252_A_New() *A_arbace_spec_gen_alpha_eval1067000252_A { t := &A_arbace_spec_gen_alpha_eval1067000252_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000252_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000252_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000252_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_init.Run(A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_clinit() { A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000252_fn__1067000253_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_init.Run(A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_clinit() { A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000252_keyword__1067000255_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000258_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000258_A_New() *A_arbace_spec_gen_alpha_eval1067000258_A { t := &A_arbace_spec_gen_alpha_eval1067000258_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000258_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000258_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000258_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000258_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000258_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_init.Run(A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_clinit() { A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000258_fn__1067000259_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_init.Run(A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_clinit() { A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000258_keyword_ns__1067000261_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000264_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000264_A_New() *A_arbace_spec_gen_alpha_eval1067000264_A { t := &A_arbace_spec_gen_alpha_eval1067000264_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000264_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000264_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000264_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_init.Run(A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_clinit() { A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000264_fn__1067000265_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_init.Run(A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_clinit() { A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000264_large_integer__1067000267_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000270_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000270_A_New() *A_arbace_spec_gen_alpha_eval1067000270_A { t := &A_arbace_spec_gen_alpha_eval1067000270_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000270_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000270_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000270_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000270_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000270_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_init.Run(A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_clinit() { A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000270_fn__1067000271_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_init.Run(A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_clinit() { A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000270_ratio__1067000273_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000276_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000276_A_New() *A_arbace_spec_gen_alpha_eval1067000276_A { t := &A_arbace_spec_gen_alpha_eval1067000276_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000276_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000276_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000276_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_init.Run(A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_clinit() { A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000276_fn__1067000277_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_init.Run(A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_clinit() { A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000276_simple_type__1067000279_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000282_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000282_A_New() *A_arbace_spec_gen_alpha_eval1067000282_A { t := &A_arbace_spec_gen_alpha_eval1067000282_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000282_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000282_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000282_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000282_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000282_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_init.Run(A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_clinit() { A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_226, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000282_fn__1067000283_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_init.Run(A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_clinit() { A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_227, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000282_simple_type_printable__1067000285_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000288_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000288_A_New() *A_arbace_spec_gen_alpha_eval1067000288_A { t := &A_arbace_spec_gen_alpha_eval1067000288_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000288_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000288_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000288_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000288_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000288_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_init.Run(A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_clinit() { A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000288_fn__1067000289_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_init.Run(A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_clinit() { A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_229, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000288_string__1067000291_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000294_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000294_A_New() *A_arbace_spec_gen_alpha_eval1067000294_A { t := &A_arbace_spec_gen_alpha_eval1067000294_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000294_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000294_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000294_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000294_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000294_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_init.Run(A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_clinit() { A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_230, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000294_fn__1067000295_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_init.Run(A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_clinit() { A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000294_string_ascii__1067000297_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000300_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000300_A_New() *A_arbace_spec_gen_alpha_eval1067000300_A { t := &A_arbace_spec_gen_alpha_eval1067000300_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000300_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000300_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000300_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000300_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000300_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_init.Run(A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_clinit() { A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000300_fn__1067000301_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_init.Run(A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_clinit() { A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_233, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000300_string_alphanumeric__1067000303_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000306_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000306_A_New() *A_arbace_spec_gen_alpha_eval1067000306_A { t := &A_arbace_spec_gen_alpha_eval1067000306_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000306_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000306_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000306_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000306_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000306_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_init.Run(A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_clinit() { A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000306_fn__1067000307_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_init.Run(A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_clinit() { A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000306_symbol__1067000309_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000312_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000312_A_New() *A_arbace_spec_gen_alpha_eval1067000312_A { t := &A_arbace_spec_gen_alpha_eval1067000312_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000312_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000312_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000312_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000312_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000312_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_init.Run(A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_clinit() { A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000312_fn__1067000313_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_init.Run(A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_clinit() { A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000312_symbol_ns__1067000315_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000318_A struct{ jrt.Object }

func A_arbace_spec_gen_alpha_eval1067000318_A_New() *A_arbace_spec_gen_alpha_eval1067000318_A { t := &A_arbace_spec_gen_alpha_eval1067000318_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Ctor() {}

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000318_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000318_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000318_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000318_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000318_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_init.Run(A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_clinit() { A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000318_fn__1067000319_A_class)) }; return v }



type A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A struct{ jrt.Object; F_g__1067000179__auto__ any }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_Init() { if !A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_init.Done() { A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_init.Run(A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_clinit) } }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_clinit() { A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_class }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A); return ok }

func A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_Cast(x any) *A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_eval1067000318_uuid__1067000321_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000017_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000017_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000017_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000017_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000017_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000017_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000017_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000017_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000017_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000017_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000017_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000020_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000020_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000020_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000020_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000020_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000020_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000020_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000020_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000020_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000020_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000020_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000332_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000332_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000332_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000332_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000332_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000332_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000332_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000332_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000332_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000332_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000332_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000332_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000332_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000333_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000335_A_class)) }; return v }



type A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_Init() { if !A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_init.Done() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_init.Run(A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_clinit) } }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_clinit() { A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_class }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A); return ok }

func A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_Cast(x any) *A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_fn__1067000332_fn__1067000337_A_class)) }; return v }



type A_arbace_spec_gen_alpha_for_all_STAR__A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_for_all_STAR__A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_for_all_STAR__A_Init() { if !A_arbace_spec_gen_alpha_for_all_STAR__A_init.Done() { A_arbace_spec_gen_alpha_for_all_STAR__A_init.Run(A_arbace_spec_gen_alpha_for_all_STAR__A_clinit) } }

func A_arbace_spec_gen_alpha_for_all_STAR__A_clinit() { A_arbace_spec_gen_alpha_for_all_STAR__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_for_all_STAR__A_class }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_for_all_STAR__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_for_all_STAR__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_for_all_STAR__A); return ok }

func A_arbace_spec_gen_alpha_for_all_STAR__A_Cast(x any) *A_arbace_spec_gen_alpha_for_all_STAR__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_for_all_STAR__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_for_all_STAR__A_class)) }; return v }



type A_arbace_spec_gen_alpha_gen_for_name_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_gen_for_name_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_gen_for_name_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_gen_for_name_A_Init() { if !A_arbace_spec_gen_alpha_gen_for_name_A_init.Done() { A_arbace_spec_gen_alpha_gen_for_name_A_init.Run(A_arbace_spec_gen_alpha_gen_for_name_A_clinit) } }

func A_arbace_spec_gen_alpha_gen_for_name_A_clinit() { A_arbace_spec_gen_alpha_gen_for_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_gen_for_name_A_class }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_gen_for_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_gen_for_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_gen_for_name_A); return ok }

func A_arbace_spec_gen_alpha_gen_for_name_A_Cast(x any) *A_arbace_spec_gen_alpha_gen_for_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_gen_for_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_gen_for_name_A_class)) }; return v }



type A_arbace_spec_gen_alpha_gen_for_pred_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_gen_for_pred_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_gen_for_pred_A_Init() { if !A_arbace_spec_gen_alpha_gen_for_pred_A_init.Done() { A_arbace_spec_gen_alpha_gen_for_pred_A_init.Run(A_arbace_spec_gen_alpha_gen_for_pred_A_clinit) } }

func A_arbace_spec_gen_alpha_gen_for_pred_A_clinit() { A_arbace_spec_gen_alpha_gen_for_pred_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_gen_for_pred_A_class }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_gen_for_pred_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_gen_for_pred_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_gen_for_pred_A); return ok }

func A_arbace_spec_gen_alpha_gen_for_pred_A_Cast(x any) *A_arbace_spec_gen_alpha_gen_for_pred_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_gen_for_pred_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_gen_for_pred_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_combinator_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_combinator_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_combinator_A_Init() { if !A_arbace_spec_gen_alpha_lazy_combinator_A_init.Done() { A_arbace_spec_gen_alpha_lazy_combinator_A_init.Run(A_arbace_spec_gen_alpha_lazy_combinator_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_combinator_A_clinit() { A_arbace_spec_gen_alpha_lazy_combinator_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_253, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_combinator_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinator_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_combinator_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinator_A); return ok }

func A_arbace_spec_gen_alpha_lazy_combinator_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_combinator_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinator_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_combinator_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_combinators_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) Is_Compiler_AOTR2() {}

var A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_combinators_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_combinators_A_Init() { if !A_arbace_spec_gen_alpha_lazy_combinators_A_init.Done() { A_arbace_spec_gen_alpha_lazy_combinators_A_init.Run(A_arbace_spec_gen_alpha_lazy_combinators_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_combinators_A_clinit() { A_arbace_spec_gen_alpha_lazy_combinators_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_combinators_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_combinators_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinators_A); return ok }

func A_arbace_spec_gen_alpha_lazy_combinators_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_combinators_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinators_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_combinators_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_Init() { if !A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_init.Done() { A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_init.Run(A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_clinit() { A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_256, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A); return ok }

func A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_combinators_fn__1067000052_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_prim_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_gen_alpha_lazy_prim_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_prim_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_prim_A_Init() { if !A_arbace_spec_gen_alpha_lazy_prim_A_init.Done() { A_arbace_spec_gen_alpha_lazy_prim_A_init.Run(A_arbace_spec_gen_alpha_lazy_prim_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_prim_A_clinit() { A_arbace_spec_gen_alpha_lazy_prim_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_prim_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prim_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_prim_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_prim_A); return ok }

func A_arbace_spec_gen_alpha_lazy_prim_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_prim_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_prim_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_prim_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_prims_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) Is_Compiler_AOTR2() {}

var A_arbace_spec_gen_alpha_lazy_prims_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_prims_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_prims_A_Init() { if !A_arbace_spec_gen_alpha_lazy_prims_A_init.Done() { A_arbace_spec_gen_alpha_lazy_prims_A_init.Run(A_arbace_spec_gen_alpha_lazy_prims_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_prims_A_clinit() { A_arbace_spec_gen_alpha_lazy_prims_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_prims_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_prims_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_prims_A); return ok }

func A_arbace_spec_gen_alpha_lazy_prims_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_prims_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_prims_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_prims_A_class)) }; return v }



type A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_Init() { if !A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_init.Done() { A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_init.Run(A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_clinit) } }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_clinit() { A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_260, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_class }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A); return ok }

func A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_Cast(x any) *A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_lazy_prims_fn__1067000185_A_class)) }; return v }



type A_arbace_spec_gen_alpha_qualified_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_qualified_QMARK__A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_qualified_QMARK__A_Init() { if !A_arbace_spec_gen_alpha_qualified_QMARK__A_init.Done() { A_arbace_spec_gen_alpha_qualified_QMARK__A_init.Run(A_arbace_spec_gen_alpha_qualified_QMARK__A_clinit) } }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_clinit() { A_arbace_spec_gen_alpha_qualified_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_qualified_QMARK__A_class }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_qualified_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_qualified_QMARK__A); return ok }

func A_arbace_spec_gen_alpha_qualified_QMARK__A_Cast(x any) *A_arbace_spec_gen_alpha_qualified_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_qualified_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_qualified_QMARK__A_class)) }; return v }



type A_arbace_spec_gen_alpha_quick_check_A struct{ jrt.Object }

func (t *A_arbace_spec_gen_alpha_quick_check_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_gen_alpha_quick_check_A_fn_class *jrt.Class

var A_arbace_spec_gen_alpha_quick_check_A_init jrt.ClassInit

func A_arbace_spec_gen_alpha_quick_check_A_Init() { if !A_arbace_spec_gen_alpha_quick_check_A_init.Done() { A_arbace_spec_gen_alpha_quick_check_A_init.Run(A_arbace_spec_gen_alpha_quick_check_A_clinit) } }

func A_arbace_spec_gen_alpha_quick_check_A_clinit() { A_arbace_spec_gen_alpha_quick_check_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_gen_alpha_quick_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_gen_alpha_quick_check_A) GetClass__Class() *jrt.Class { return A_arbace_spec_gen_alpha_quick_check_A_class }

func (t *A_arbace_spec_gen_alpha_quick_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_gen_alpha_quick_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_gen_alpha_quick_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_gen_alpha_quick_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_gen_alpha_quick_check_A); return ok }

func A_arbace_spec_gen_alpha_quick_check_A_Cast(x any) *A_arbace_spec_gen_alpha_quick_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_gen_alpha_quick_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_gen_alpha_quick_check_A_class)) }; return v }
