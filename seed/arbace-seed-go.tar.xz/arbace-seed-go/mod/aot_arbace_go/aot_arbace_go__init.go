//line aot_arbace_go__init.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go__init_A_Unit0__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go__init_A_const_1) }
//line :1:1
func A_arbace_go__init_A_Unit1__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_2)) }
//line :1:1
func A_arbace_go__init_A_Unit2__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go__init_A_Unit3__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go__init_A_const_1)).Equals_O__Z(A_arbace_go__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_eval1822000008_fn__1822000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_eval1822000008_fn__1822000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_go_eval1822000008_fn__1822000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go__init_A_Load__O() any { A_arbace_go__init_A_Init(); jrt.StartCheck(); A_arbace_go__init_A_Unit0__O(); A_arbace_go__init_A_Unit1__O(); A_arbace_go__init_A_Unit2__O(); A_arbace_go__init_A_Unit3__O(); A_arbace_go__init_A_Unit4__O(); A_arbace_go__init_A_Unit5__O(); A_arbace_go__init_A_Unit6__O(); A_arbace_go__init_A_Unit7__O(); A_arbace_go__init_A_Unit8__O(); A_arbace_go__init_A_Unit9__O(); A_arbace_go__init_A_Unit10__O(); A_arbace_go__init_A_Unit11__O(); A_arbace_go__init_A_Unit12__O(); A_arbace_go__init_A_Unit13__O(); A_arbace_go__init_A_Unit14__O(); A_arbace_go__init_A_Unit15__O(); A_arbace_go__init_A_Unit16__O(); A_arbace_go__init_A_Unit17__O(); A_arbace_go__init_A_Unit18__O(); A_arbace_go__init_A_Unit19__O(); A_arbace_go__init_A_Unit20__O(); A_arbace_go__init_A_Unit21__O(); A_arbace_go__init_A_Unit22__O(); A_arbace_go__init_A_Unit23__O(); A_arbace_go__init_A_Unit24__O(); A_arbace_go__init_A_Unit25__O(); A_arbace_go__init_A_Unit26__O(); A_arbace_go__init_A_Unit27__O(); A_arbace_go__init_A_Unit28__O(); A_arbace_go__init_A_Unit29__O(); A_arbace_go__init_A_Unit30__O(); A_arbace_go__init_A_Unit31__O(); A_arbace_go__init_A_Unit32__O(); A_arbace_go__init_A_Unit33__O(); A_arbace_go__init_A_Unit34__O(); A_arbace_go__init_A_Unit35__O(); A_arbace_go__init_A_Unit36__O(); A_arbace_go__init_A_Unit37__O(); A_arbace_go__init_A_Unit38__O(); A_arbace_go__init_A_Unit39__O(); A_arbace_go__init_A_Unit40__O(); A_arbace_go__init_A_Unit41__O(); A_arbace_go__init_A_Unit42__O(); A_arbace_go__init_A_Unit43__O(); A_arbace_go__init_A_Unit44__O(); A_arbace_go__init_A_Unit45__O(); A_arbace_go__init_A_Unit46__O(); A_arbace_go__init_A_Unit47__O(); A_arbace_go__init_A_Unit48__O(); A_arbace_go__init_A_Unit49__O(); A_arbace_go__init_A_Unit50__O(); A_arbace_go__init_A_Unit51__O(); A_arbace_go__init_A_Unit52__O(); A_arbace_go__init_A_Unit53__O(); A_arbace_go__init_A_Unit54__O(); A_arbace_go__init_A_Unit55__O(); A_arbace_go__init_A_Unit56__O(); A_arbace_go__init_A_Unit57__O(); A_arbace_go__init_A_Unit58__O(); A_arbace_go__init_A_Unit59__O(); A_arbace_go__init_A_Unit60__O(); A_arbace_go__init_A_Unit61__O(); A_arbace_go__init_A_Unit62__O(); A_arbace_go__init_A_Unit63__O(); A_arbace_go__init_A_Unit64__O(); return nil }












































func A_arbace_go__init_A_Unit4__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_path__GT_ns_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_go_path__GT_ns_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_5)); return A_arbace_go__init_A_const_4 }





func A_arbace_go__init_A_Unit5__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_fn__1822000016_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_fn__1822000016_A_fn_class; if
					fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_go_fn__1822000016_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); /*line :56:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_7)); return A_arbace_go__init_A_const_6 }





func A_arbace_go__init_A_Unit6__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_digest_forms_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_digest_forms_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_go_digest_forms_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_9)); return A_arbace_go__init_A_const_8 }











func A_arbace_go__init_A_Unit7__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_params_of_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_params_of_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_go_params_of_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_11)); return A_arbace_go__init_A_const_10 }









func A_arbace_go__init_A_Unit8__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_strip_doc_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_strip_doc_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_go_strip_doc_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_13)); return A_arbace_go__init_A_const_12 }

func A_arbace_go__init_A_Unit9__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_const_value_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_const_value_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); A_arbace_go_const_value_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_15)); return A_arbace_go__init_A_const_14 }

















func A_arbace_go__init_A_Unit10__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_digest_info_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_digest_info_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_go_digest_info_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_17)); return A_arbace_go__init_A_const_16 }




































func A_arbace_go__init_A_Unit11__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_19)); return A_arbace_go__init_A_const_18 }

func A_arbace_go__init_A_Unit12__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_member_var_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_member_var_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_go_member_var_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_21)); return A_arbace_go__init_A_const_20 }













func A_arbace_go__init_A_Unit13__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_table_ns_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_table_ns_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_go_table_ns_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_23)); return A_arbace_go__init_A_const_22 }

































func A_arbace_go__init_A_Unit14__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_interpretable_ns_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_interpretable_ns_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_go_interpretable_ns_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_25)); return A_arbace_go__init_A_const_24 }









func A_arbace_go__init_A_Unit15__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_packages_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_packages_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_go_packages_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_27)); return A_arbace_go__init_A_const_26 }







func A_arbace_go__init_A_Unit16__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_new_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_new_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); A_arbace_go_new_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_29)); return A_arbace_go__init_A_const_28 }




func A_arbace_go__init_A_Unit17__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_zero_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_zero_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_go_zero_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_31)); return A_arbace_go__init_A_const_30 }




func A_arbace_go__init_A_Unit18__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_type_of_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_type_of_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_go_type_of_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_33)); return A_arbace_go__init_A_const_32 }




func A_arbace_go__init_A_Unit19__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_str_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_str_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_go_str_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_35)); return A_arbace_go__init_A_const_34 }




func A_arbace_go__init_A_Unit20__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_spread_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_spread_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_go_spread_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_37)); return A_arbace_go__init_A_const_36 }





func A_arbace_go__init_A_Unit21__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_assign_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_assign_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_go_assign_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_39)); return A_arbace_go__init_A_const_38 }










func A_arbace_go__init_A_Unit22__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(246, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_40; var tmp2 any; var root_39 any = A_arbace_go__init_A_const_41.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_40 == nil { tmp2 = ifn_41.Invoke_O__O(arg_42) } else { tmp2 = linked_40.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_39, arg_42) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go__init_A_const_40; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_42)); return A_arbace_go__init_A_const_40 }

func A_arbace_go__init_A_Unit23__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_type_names_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_type_names_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_go_type_names_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_44)); return A_arbace_go__init_A_const_43 }

func A_arbace_go__init_A_Unit24__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_reify_type_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_reify_type_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_go_reify_type_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_46)); return A_arbace_go__init_A_const_45 }








func A_arbace_go__init_A_Unit25__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_reify_data_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_reify_data_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_go_reify_data_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_48)); return A_arbace_go__init_A_const_47 }


















func A_arbace_go__init_A_Unit26__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_repl_fn_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_repl_fn_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_go_repl_fn_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_49)); return A_arbace_go__init_A_const_18 }

func A_arbace_go__init_A_Unit27__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_pos_of_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_pos_of_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_go_pos_of_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_51)); return A_arbace_go__init_A_const_50 }

func A_arbace_go__init_A_Unit28__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_52; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__54 any = A_arbace_go_package_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_package_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, true, nil); A_arbace_go_package_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__54, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_53)); return A_arbace_go__init_A_const_52 }
//line :282:1
func A_arbace_go__init_A_Unit29__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); A_arbace_go__init_A_const_52.SetMacro__V(); return nil }
//line :282:1
func A_arbace_go__init_A_Unit30__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); return A_arbace_go__init_A_const_52 }




func A_arbace_go__init_A_Unit31__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_54; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__56 any = A_arbace_go_file_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_file_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, true, nil); A_arbace_go_file_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__56, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_55)); return A_arbace_go__init_A_const_54 }
//line :287:1
func A_arbace_go__init_A_Unit32__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); A_arbace_go__init_A_const_54.SetMacro__V(); return nil }
//line :287:1
func A_arbace_go__init_A_Unit33__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); return A_arbace_go__init_A_const_54 }




func A_arbace_go__init_A_Unit34__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_declare_STAR__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_declare_STAR__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_go_declare_STAR__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_57)); return A_arbace_go__init_A_const_56 }




func A_arbace_go__init_A_Unit35__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_58; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__60 any = A_arbace_go_func_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_func_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, true, nil); A_arbace_go_func_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__60, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_59)); return A_arbace_go__init_A_const_58 }
//line :297:1
func A_arbace_go__init_A_Unit36__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); A_arbace_go__init_A_const_58.SetMacro__V(); return nil }
//line :297:1
func A_arbace_go__init_A_Unit37__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); return A_arbace_go__init_A_const_58 }


func A_arbace_go__init_A_Unit38__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_60; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__62 any = A_arbace_go_method_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_method_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, true, nil); A_arbace_go_method_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__62, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_61)); return A_arbace_go__init_A_const_60 }
//line :300:1
func A_arbace_go__init_A_Unit39__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); A_arbace_go__init_A_const_60.SetMacro__V(); return nil }
//line :300:1
func A_arbace_go__init_A_Unit40__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); return A_arbace_go__init_A_const_60 }


func A_arbace_go__init_A_Unit41__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_62; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__64 any = A_arbace_go_type_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_type_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, true, nil); A_arbace_go_type_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__64, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_63)); return A_arbace_go__init_A_const_62 }
//line :303:1
func A_arbace_go__init_A_Unit42__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); A_arbace_go__init_A_const_62.SetMacro__V(); return nil }
//line :303:1
func A_arbace_go__init_A_Unit43__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); return A_arbace_go__init_A_const_62 }


func A_arbace_go__init_A_Unit44__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_64; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__66 any = A_arbace_go_var_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_var_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, true, nil); A_arbace_go_var_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__66, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_65)); return A_arbace_go__init_A_const_64 }
//line :306:1
func A_arbace_go__init_A_Unit45__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); A_arbace_go__init_A_const_64.SetMacro__V(); return nil }
//line :306:1
func A_arbace_go__init_A_Unit46__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); return A_arbace_go__init_A_const_64 }


func A_arbace_go__init_A_Unit47__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_66; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__68 any = A_arbace_go_const_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_const_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, true, nil); A_arbace_go_const_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__68, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_67)); return A_arbace_go__init_A_const_66 }
//line :309:1
func A_arbace_go__init_A_Unit48__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); A_arbace_go__init_A_const_66.SetMacro__V(); return nil }
//line :309:1
func A_arbace_go__init_A_Unit49__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); return A_arbace_go__init_A_const_66 }


func A_arbace_go__init_A_Unit50__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_68; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__70 any = A_arbace_go_directive_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_directive_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, true, nil); A_arbace_go_directive_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__70, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_69)); return A_arbace_go__init_A_const_68 }
//line :312:1
func A_arbace_go__init_A_Unit51__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); A_arbace_go__init_A_const_68.SetMacro__V(); return nil }
//line :312:1
func A_arbace_go__init_A_Unit52__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); return A_arbace_go__init_A_const_68 }

func A_arbace_go__init_A_Unit53__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_70; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__72 any = A_arbace_go_import_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_import_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, true, nil); A_arbace_go_import_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__72, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_71)); return A_arbace_go__init_A_const_70 }
//line :314:1
func A_arbace_go__init_A_Unit54__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); A_arbace_go__init_A_const_70.SetMacro__V(); return nil }
//line :314:1
func A_arbace_go__init_A_Unit55__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); return A_arbace_go__init_A_const_70 }




func A_arbace_go__init_A_Unit56__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_72; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__74 any = A_arbace_go_inst_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_inst_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, true, nil); A_arbace_go_inst_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__74, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_73)); return A_arbace_go__init_A_const_72 }
//line :319:1
func A_arbace_go__init_A_Unit57__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); A_arbace_go__init_A_const_72.SetMacro__V(); return nil }
//line :319:1
func A_arbace_go__init_A_Unit58__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); return A_arbace_go__init_A_const_72 }









func A_arbace_go__init_A_Unit59__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_74; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__76 any = A_arbace_go_eval_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_eval_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, true, nil); A_arbace_go_eval_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__76, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_75)); return A_arbace_go__init_A_const_74 }
//line :329:1
func A_arbace_go__init_A_Unit60__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); A_arbace_go__init_A_const_74.SetMacro__V(); return nil }
//line :329:1
func A_arbace_go__init_A_Unit61__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); return A_arbace_go__init_A_const_74 }





func A_arbace_go__init_A_Unit62__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_run_main_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_run_main_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_go_run_main_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_77)); return A_arbace_go__init_A_const_76 }




func A_arbace_go__init_A_Unit63__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_78; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__80 any = A_arbace_go_run_compiled_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_run_compiled_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, true, nil); A_arbace_go_run_compiled_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__80, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_79)); return A_arbace_go__init_A_const_78 }





func A_arbace_go__init_A_Unit64__O() any { A_arbace_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_go__init_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_check_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_check_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_go_check_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go__init_A_const_81)); return A_arbace_go__init_A_const_80 }












type A_arbace_go__init_A struct{ jrt.Object }

var A_arbace_go__init_A_const_pool *jrt.RefArray

var A_arbace_go__init_A_const_0 *lang.Var

var A_arbace_go__init_A_const_1 any

var A_arbace_go__init_A_const_2 any

var A_arbace_go__init_A_const_3 any

var A_arbace_go__init_A_const_4 *lang.Var

var A_arbace_go__init_A_const_5 any

var A_arbace_go__init_A_const_6 *lang.Var

var A_arbace_go__init_A_const_7 any

var A_arbace_go__init_A_const_8 *lang.Var

var A_arbace_go__init_A_const_9 any

var A_arbace_go__init_A_const_10 *lang.Var

var A_arbace_go__init_A_const_11 any

var A_arbace_go__init_A_const_12 *lang.Var

var A_arbace_go__init_A_const_13 any

var A_arbace_go__init_A_const_14 *lang.Var

var A_arbace_go__init_A_const_15 any

var A_arbace_go__init_A_const_16 *lang.Var

var A_arbace_go__init_A_const_17 any

var A_arbace_go__init_A_const_18 *lang.Var

var A_arbace_go__init_A_const_19 any

var A_arbace_go__init_A_const_20 *lang.Var

var A_arbace_go__init_A_const_21 any

var A_arbace_go__init_A_const_22 *lang.Var

var A_arbace_go__init_A_const_23 any

var A_arbace_go__init_A_const_24 *lang.Var

var A_arbace_go__init_A_const_25 any

var A_arbace_go__init_A_const_26 *lang.Var

var A_arbace_go__init_A_const_27 any

var A_arbace_go__init_A_const_28 *lang.Var

var A_arbace_go__init_A_const_29 any

var A_arbace_go__init_A_const_30 *lang.Var

var A_arbace_go__init_A_const_31 any

var A_arbace_go__init_A_const_32 *lang.Var

var A_arbace_go__init_A_const_33 any

var A_arbace_go__init_A_const_34 *lang.Var

var A_arbace_go__init_A_const_35 any

var A_arbace_go__init_A_const_36 *lang.Var

var A_arbace_go__init_A_const_37 any

var A_arbace_go__init_A_const_38 *lang.Var

var A_arbace_go__init_A_const_39 any

var A_arbace_go__init_A_const_40 *lang.Var

var A_arbace_go__init_A_const_41 *lang.Var

var A_arbace_go__init_A_const_42 any

var A_arbace_go__init_A_const_43 *lang.Var

var A_arbace_go__init_A_const_44 any

var A_arbace_go__init_A_const_45 *lang.Var

var A_arbace_go__init_A_const_46 any

var A_arbace_go__init_A_const_47 *lang.Var

var A_arbace_go__init_A_const_48 any

var A_arbace_go__init_A_const_49 any

var A_arbace_go__init_A_const_50 *lang.Var

var A_arbace_go__init_A_const_51 any

var A_arbace_go__init_A_const_52 *lang.Var

var A_arbace_go__init_A_const_53 any

var A_arbace_go__init_A_const_54 *lang.Var

var A_arbace_go__init_A_const_55 any

var A_arbace_go__init_A_const_56 *lang.Var

var A_arbace_go__init_A_const_57 any

var A_arbace_go__init_A_const_58 *lang.Var

var A_arbace_go__init_A_const_59 any

var A_arbace_go__init_A_const_60 *lang.Var

var A_arbace_go__init_A_const_61 any

var A_arbace_go__init_A_const_62 *lang.Var

var A_arbace_go__init_A_const_63 any

var A_arbace_go__init_A_const_64 *lang.Var

var A_arbace_go__init_A_const_65 any

var A_arbace_go__init_A_const_66 *lang.Var

var A_arbace_go__init_A_const_67 any

var A_arbace_go__init_A_const_68 *lang.Var

var A_arbace_go__init_A_const_69 any

var A_arbace_go__init_A_const_70 *lang.Var

var A_arbace_go__init_A_const_71 any

var A_arbace_go__init_A_const_72 *lang.Var

var A_arbace_go__init_A_const_73 any

var A_arbace_go__init_A_const_74 *lang.Var

var A_arbace_go__init_A_const_75 any

var A_arbace_go__init_A_const_76 *lang.Var

var A_arbace_go__init_A_const_77 any

var A_arbace_go__init_A_const_78 *lang.Var

var A_arbace_go__init_A_const_79 any

var A_arbace_go__init_A_const_80 *lang.Var

var A_arbace_go__init_A_const_81 any

var A_arbace_go__init_A_init jrt.ClassInit

func A_arbace_go__init_A_Init() { if !A_arbace_go__init_A_init.Done() { A_arbace_go__init_A_init.Run(A_arbace_go__init_A_clinit) } }

func A_arbace_go__init_A_clinit() { A_arbace_go__init_A_clinit_p0(); A_arbace_go__init_A_clinit_p1(); A_arbace_go__init_A_clinit_p2(); A_arbace_go__init_A_clinit_p3(); A_arbace_go__init_A_clinit_p4(); A_arbace_go__init_A_clinit_p5(); A_arbace_go__init_A_clinit_p6() }

func A_arbace_go__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_69, 118); A_arbace_go__init_A_const_0 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[36]); A_arbace_go__init_A_const_1 = A_arbace_go__init_A_const_pool.A[37]; A_arbace_go__init_A_const_2 = A_arbace_go__init_A_const_pool.A[38]; A_arbace_go__init_A_const_3 = A_arbace_go__init_A_const_pool.A[39]; A_arbace_go__init_A_const_4 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[40]); A_arbace_go__init_A_const_5 = A_arbace_go__init_A_const_pool.A[41]; A_arbace_go__init_A_const_6 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[42]); A_arbace_go__init_A_const_7 = A_arbace_go__init_A_const_pool.A[43]; A_arbace_go__init_A_const_8 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[44]); A_arbace_go__init_A_const_9 = A_arbace_go__init_A_const_pool.A[45]; A_arbace_go__init_A_const_10 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[46]); A_arbace_go__init_A_const_11 = A_arbace_go__init_A_const_pool.A[47]; A_arbace_go__init_A_const_12 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[48]) }

func A_arbace_go__init_A_clinit_p1() { A_arbace_go__init_A_const_13 = A_arbace_go__init_A_const_pool.A[49]; A_arbace_go__init_A_const_14 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[50]); A_arbace_go__init_A_const_15 = A_arbace_go__init_A_const_pool.A[51]; A_arbace_go__init_A_const_16 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[52]); A_arbace_go__init_A_const_17 = A_arbace_go__init_A_const_pool.A[53]; A_arbace_go__init_A_const_18 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[54]); A_arbace_go__init_A_const_19 = A_arbace_go__init_A_const_pool.A[55]; A_arbace_go__init_A_const_20 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[56]); A_arbace_go__init_A_const_21 = A_arbace_go__init_A_const_pool.A[57]; A_arbace_go__init_A_const_22 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[58]); A_arbace_go__init_A_const_23 = A_arbace_go__init_A_const_pool.A[59]; A_arbace_go__init_A_const_24 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[60]); A_arbace_go__init_A_const_25 = A_arbace_go__init_A_const_pool.A[61] }

func A_arbace_go__init_A_clinit_p2() { A_arbace_go__init_A_const_26 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[62]); A_arbace_go__init_A_const_27 = A_arbace_go__init_A_const_pool.A[63]; A_arbace_go__init_A_const_28 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[64]); A_arbace_go__init_A_const_29 = A_arbace_go__init_A_const_pool.A[65]; A_arbace_go__init_A_const_30 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[66]); A_arbace_go__init_A_const_31 = A_arbace_go__init_A_const_pool.A[67]; A_arbace_go__init_A_const_32 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[68]); A_arbace_go__init_A_const_33 = A_arbace_go__init_A_const_pool.A[69]; A_arbace_go__init_A_const_34 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[70]); A_arbace_go__init_A_const_35 = A_arbace_go__init_A_const_pool.A[71]; A_arbace_go__init_A_const_36 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[72]); A_arbace_go__init_A_const_37 = A_arbace_go__init_A_const_pool.A[73]; A_arbace_go__init_A_const_38 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[74]) }

func A_arbace_go__init_A_clinit_p3() { A_arbace_go__init_A_const_39 = A_arbace_go__init_A_const_pool.A[75]; A_arbace_go__init_A_const_40 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[76]); A_arbace_go__init_A_const_41 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[77]); A_arbace_go__init_A_const_42 = A_arbace_go__init_A_const_pool.A[78]; A_arbace_go__init_A_const_43 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[79]); A_arbace_go__init_A_const_44 = A_arbace_go__init_A_const_pool.A[80]; A_arbace_go__init_A_const_45 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[81]); A_arbace_go__init_A_const_46 = A_arbace_go__init_A_const_pool.A[82]; A_arbace_go__init_A_const_47 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[83]); A_arbace_go__init_A_const_48 = A_arbace_go__init_A_const_pool.A[84]; A_arbace_go__init_A_const_49 = A_arbace_go__init_A_const_pool.A[85]; A_arbace_go__init_A_const_50 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[86]); A_arbace_go__init_A_const_51 = A_arbace_go__init_A_const_pool.A[87] }

func A_arbace_go__init_A_clinit_p4() { A_arbace_go__init_A_const_52 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[88]); A_arbace_go__init_A_const_53 = A_arbace_go__init_A_const_pool.A[89]; A_arbace_go__init_A_const_54 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[90]); A_arbace_go__init_A_const_55 = A_arbace_go__init_A_const_pool.A[91]; A_arbace_go__init_A_const_56 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[92]); A_arbace_go__init_A_const_57 = A_arbace_go__init_A_const_pool.A[93]; A_arbace_go__init_A_const_58 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[94]); A_arbace_go__init_A_const_59 = A_arbace_go__init_A_const_pool.A[95]; A_arbace_go__init_A_const_60 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[96]); A_arbace_go__init_A_const_61 = A_arbace_go__init_A_const_pool.A[97]; A_arbace_go__init_A_const_62 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[98]); A_arbace_go__init_A_const_63 = A_arbace_go__init_A_const_pool.A[99]; A_arbace_go__init_A_const_64 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[100]) }

func A_arbace_go__init_A_clinit_p5() { A_arbace_go__init_A_const_65 = A_arbace_go__init_A_const_pool.A[101]; A_arbace_go__init_A_const_66 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[102]); A_arbace_go__init_A_const_67 = A_arbace_go__init_A_const_pool.A[103]; A_arbace_go__init_A_const_68 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[104]); A_arbace_go__init_A_const_69 = A_arbace_go__init_A_const_pool.A[105]; A_arbace_go__init_A_const_70 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[106]); A_arbace_go__init_A_const_71 = A_arbace_go__init_A_const_pool.A[107]; A_arbace_go__init_A_const_72 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[108]); A_arbace_go__init_A_const_73 = A_arbace_go__init_A_const_pool.A[109]; A_arbace_go__init_A_const_74 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[110]); A_arbace_go__init_A_const_75 = A_arbace_go__init_A_const_pool.A[111]; A_arbace_go__init_A_const_76 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[112]); A_arbace_go__init_A_const_77 = A_arbace_go__init_A_const_pool.A[113] }

func A_arbace_go__init_A_clinit_p6() { A_arbace_go__init_A_const_78 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[114]); A_arbace_go__init_A_const_79 = A_arbace_go__init_A_const_pool.A[115]; A_arbace_go__init_A_const_80 = lang.Var_Cast(A_arbace_go__init_A_const_pool.A[116]); A_arbace_go__init_A_const_81 = A_arbace_go__init_A_const_pool.A[117] }

func A_arbace_go__init_A_New() *A_arbace_go__init_A { A_arbace_go__init_A_Init(); t := &A_arbace_go__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go__init_A) Ctor() {}

func (t *A_arbace_go__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go__init_A) GetClass__Class() *jrt.Class { return A_arbace_go__init_A_class }

func (t *A_arbace_go__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go__init_A); return ok }

func A_arbace_go__init_A_Cast(x any) *A_arbace_go__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go__init_A_class)) }; return v }
