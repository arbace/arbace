//line j2g_strings.ae:1
package aot_arbace_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn3,newyn3,stryn4,typeyn6,importyn4,evalkn3,dockn5,indexkn4,textkn5,startkn3,eofks9,arbace.go3,eofyn1,&kn3,tagyn1,_kn4,elseyn7,float32kn11,type-paramskn8,arglistskn5,constkn3,valks2,go10,underlyingks2,go4,kindks2,go7,packagekn6,methodkn3,varkn4,funckn4,typekn4,linekn6,columnys9,arbace.go7,repl-fnyn5,quoteys9,arbace.go8,declare*kn2,nsv11,arbace.core5,referR0,R1,V5,R2,R3,R4,R5,R6,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn9,arbace.gom2,R7,s2596,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  GR3: the macros of Go forms (§2.2). In a go.* namespace a Go package is the namespace's\n  (go/package, or implicitly the first declaration's: S2); each declaration head of Go forms is\n  a macro that hands its form, quoted, to arbace.go.repl, which checks and defines it at once\n  at the REPL (§2.5), or queues it while the package's file loads (§2.3):\n\n    (ns go.demo (:require [arbace.go :as go]))\n    (go/import [strings \"strings\"])\n    (go/func Greet ^string [^string name] (+ \"hello, \" (strings/ToUpper name)))\n    (Greet \"go\")                                ;=> \"hello, GO\"\n    (go/eval (Greet \"x\"))                       ;=> \"hello, X\"\n\n  The forms are data from the reader to the checker: nothing in them is evaluated as Arbace.\n\n  GR5: Arbace fns given for Go func parameters are Go funcs (§7.5); a panic leaving Go is a\n  GoPanic with gc's text, its interpreted frames in its trace and ex-data, a run-time error's\n  Java exception as its cause (§10.4, §10.6); Go values print as gc's %#v with goi's type names\n  (§5.7); their methods and fields are reachable by interop ((.Len buf), (.-X p): GS10), their\n  elements by count, nth, get and seq (GS7); Go forms reach Arbace through the package arbace\n  (§7.3); go/run-compiled builds a package's program with gc and runs it (G15).v11,arbace.core6,symbolv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core9,interposev11,arbace.core3,mapC16,java.lang.StringR8,v11,arbace.core11,read-stringv11,arbace.core4,subsl0,R9,R10,v9,arbace.go12,digest-indexv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,readm2,R11,R12,R12,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core3,vecv11,arbace.core11,map-indexedR13,R13,v11,arbace.core7,symbol?R14,v11,arbace.core4,not=R15,v11,arbace.core4,nameR16,v11,arbace.core7,string?v11,arbace.core4,restv11,arbace.core8,integer?v11,arbace.core5,char?v11,arbace.core6,float?v11,arbace.core6,ratio?v11,arbace.core8,decimal?R17,v11,arbace.core4,seq?v11,arbace.core6,mapcatv11,arbace.core6,secondv11,arbace.core6,reducev11,arbace.core3,notv11,arbace.core9,namespacev9,arbace.go9,strip-docv11,arbace.core4,dropl2,R18,v11,arbace.core5,assocR7,R19,v11,arbace.core4,listv9,arbace.go9,params-ofR20,v9,arbace.go11,const-valueR21,R22,v9,arbace.go12,digest-formsR23,R24,v11,arbace.core6,internv11,arbace.core9,with-metaR25,R26,R27,R28,v11,arbace.core9,create-nsv9,arbace.go8,path->nsv11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core7,keywordv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core9,partitionl3,v9,arbace.go11,digest-infov11,arbace.core9,contains?v9,arbace.go10,member-varv11,arbace.core4,sortv11,arbace.core6,concatv11,arbace.core4,keysv9,arbace.go11,reify-typesv11,arbace.core5,swap!v9,arbace.go10,type-namesv11,arbace.core4,somev11,arbace.core17,requiring-resolvev11,arbace.core11,select-keysV2,R29,R30,R31,R32,v11,arbace.core7,ns-namev11,arbace.core4,*ns*R31,v9,arbace.go7,repl-fnR33,v9,arbace.go6,pos-ofR34,R33,R33,R33,R33,R31,R31,")

var Lit_1 *jrt.String = jrt.Intern("check!")

var Lit_2 *jrt.String = jrt.Intern("byte-string")

var Lit_3 *jrt.String = jrt.Intern("arbace.go$const_value$fn__1822000029")

var Lit_4 *jrt.String = jrt.Intern("UTF-8")

var Lit_5 *jrt.String = jrt.Intern("complex")

var Lit_6 *jrt.String = jrt.Intern("rune")

var Lit_7 *jrt.String = jrt.Intern("binary-float")

var Lit_8 *jrt.String = jrt.Intern("declare!")

var Lit_9 *jrt.String = jrt.Intern("arbace.go$digest_info$fn__1822000032")

var Lit_10 *jrt.String = jrt.Intern("go")

var Lit_11 *jrt.String = jrt.Intern("method")

var Lit_12 *jrt.String = jrt.Intern(".")

var Lit_13 *jrt.String = jrt.Intern("type")

var Lit_14 *jrt.String = jrt.Intern("const")

var Lit_15 *jrt.String = jrt.Intern("func")

var Lit_16 *jrt.String = jrt.Intern("var")

var Lit_17 *jrt.String = jrt.Intern("eval!")

var Lit_18 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_19 *jrt.String = jrt.Intern("arbace.lang.GoFn")

var Lit_20 *jrt.String = jrt.Intern("arbace.lang.GoVar")

var Lit_21 *jrt.String = jrt.Intern("arbace.lang.GoType")

var Lit_22 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_23 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_24 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_25 *jrt.String = jrt.Intern("file!")

var Lit_26 *jrt.String = jrt.Intern("\n")

var Lit_27 *jrt.String = jrt.Intern("import!")

var Lit_28 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_29 *jrt.String = jrt.Intern("package!")

var Lit_30 *jrt.String = jrt.Intern("arbace.go$params_of$fn__1822000024")

var Lit_31 *jrt.String = jrt.Intern("p")

var Lit_32 *jrt.String = jrt.Intern("go.")

var Lit_33 *jrt.String = jrt.Intern("arbace.go$path__GT_ns$fn__1822000013")

var Lit_34 *jrt.String = jrt.Intern("split")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("replaceAll")

var Lit_37 *jrt.String = jrt.Intern("[.-]")

var Lit_38 *jrt.String = jrt.Intern("_")

var Lit_39 *jrt.String = jrt.Intern("reify: ")

var Lit_40 *jrt.String = jrt.Intern(" is no method of ")

var Lit_41 *jrt.String = jrt.Intern("arbace.go$reify_data$iter__1822000112__1822000116")

var Lit_42 *jrt.String = jrt.Intern("arbace.go$reify_data$iter__1822000112__1822000116$fn__1822000117")

var Lit_43 *jrt.String = jrt.Intern("arbace.go$reify_data$iter__1822000112__1822000116$fn__1822000117$fn__1822000118")

var Lit_44 *jrt.String = jrt.Intern("reify: method ")

var Lit_45 *jrt.String = jrt.Intern(" of ")

var Lit_46 *jrt.String = jrt.Intern(" is missing")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.repl")

var Lit_48 *jrt.String = jrt.Intern("run-compiled!")

var Lit_49 *jrt.String = jrt.Intern("run-main!")

var Lit_50 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049")

var Lit_51 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000061")

var Lit_52 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063")

var Lit_53 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$make__1822000081")

var Lit_54 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$resolver__1822000086")

var Lit_55 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068")

var Lit_56 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069")

var Lit_57 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069$fn__1822000070")

var Lit_58 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050")

var Lit_59 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050$fn__1822000051")

var Lit_60 *jrt.String = jrt.Intern(", ")

var Lit_61 *jrt.String = jrt.Intern("arbace.go$type_names$fn__1822000101")

var Lit_62 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,filekn7,privateyn1,pyn2,pvyn2,xsyn1,vyn10,underlyingyn2,nsyn4,kindyn6,handleyn4,infoyn6,GoTypeyn5,GoVaryn1,xyn2,tsyn2,rtyn3,fnsyn2,nmyn4,formyn1,&yn4,optsyn1,_yn5,specsyn5,stmtsyn6,ns-symyn4,argsv11,arbace.core5,in-nsMyn9,arbace.gom2,R0,s2596,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  GR3: the macros of Go forms (§2.2). In a go.* namespace a Go package is the namespace's\n  (go/package, or implicitly the first declaration's: S2); each declaration head of Go forms is\n  a macro that hands its form, quoted, to arbace.go.repl, which checks and defines it at once\n  at the REPL (§2.5), or queues it while the package's file loads (§2.3):\n\n    (ns go.demo (:require [arbace.go :as go]))\n    (go/import [strings \"strings\"])\n    (go/func Greet ^string [^string name] (+ \"hello, \" (strings/ToUpper name)))\n    (Greet \"go\")                                ;=> \"hello, GO\"\n    (go/eval (Greet \"x\"))                       ;=> \"hello, X\"\n\n  The forms are data from the reader to the checker: nothing in them is evaluated as Arbace.\n\n  GR5: Arbace fns given for Go func parameters are Go funcs (§7.5); a panic leaving Go is a\n  GoPanic with gc's text, its interpreted frames in its trace and ex-data, a run-time error's\n  Java exception as its cause (§10.4, §10.6); Go values print as gc's %#v with goi's type names\n  (§5.7); their methods and fields are reachable by interop ((.Len buf), (.-X p): GS10), their\n  elements by count, nth, get and seq (GS7); Go forms reach Arbace through the package arbace\n  (§7.3); go/run-compiled builds a package's program with gc and runs it (G15).m2,R0,s2596,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  GR3: the macros of Go forms (§2.2). In a go.* namespace a Go package is the namespace's\n  (go/package, or implicitly the first declaration's: S2); each declaration head of Go forms is\n  a macro that hands its form, quoted, to arbace.go.repl, which checks and defines it at once\n  at the REPL (§2.5), or queues it while the package's file loads (§2.3):\n\n    (ns go.demo (:require [arbace.go :as go]))\n    (go/import [strings \"strings\"])\n    (go/func Greet ^string [^string name] (+ \"hello, \" (strings/ToUpper name)))\n    (Greet \"go\")                                ;=> \"hello, GO\"\n    (go/eval (Greet \"x\"))                       ;=> \"hello, X\"\n\n  The forms are data from the reader to the checker: nothing in them is evaluated as Arbace.\n\n  GR5: Arbace fns given for Go func parameters are Go funcs (§7.5); a panic leaving Go is a\n  GoPanic with gc's text, its interpreted frames in its trace and ex-data, a run-time error's\n  Java exception as its cause (§10.4, §10.6); Go values print as gc's %#v with goi's type names\n  (§5.7); their methods and fields are reachable by interop ((.Len buf), (.-X p): GS10), their\n  elements by count, nth, get and seq (GS7); Go forms reach Arbace through the package arbace\n  (§7.3); go/run-compiled builds a package's program with gc and runs it (G15).R1,v9,arbace.go8,path->nsm10,R2,L1,V1,Myn1,pm2,R3,R4,R0,s109,The namespace of Go import path p (SPEC.md §4.1): go. and the path, / as ., . and - inside an\n  element as _.R5,i50,R6,i1,R7,s12,arbace/go.aev9,arbace.go12,digest-indexm8,R8,TR5,i56,R6,i1,R7,s12,arbace/go.aev9,arbace.go12,digest-formsm10,R2,L1,V1,R9,R0,s113,The forms of the digest of listed package path p (§6.5): its go/package, go/file and\n  declaration forms, or nil.R5,i62,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,params-ofm12,R8,TR2,L1,V1,R10,R0,s82,The parameter names of a signature's vector (Go's names; p1 ... for unnamed ones).R5,i74,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,strip-docm10,R8,TR2,L1,V1,R11,R5,i84,R6,i1,R7,s12,arbace/go.aev9,arbace.go11,const-valuem12,R8,TR2,L1,V2,R12,R13,R0,s204,A constant's :val as an Arbace value (§2.1, §5.6): integers as Long or BigInt, floats as a\n  Double (a Float for a float32 constant), runes as their Long, strings as String, complex\n  values as Go values.R5,i86,R6,i1,R7,s12,arbace/go.aev9,arbace.go11,digest-infom12,R8,TR2,L1,V1,R9,R0,s89,What the digest says of package p's exported names: {name {:doc :arglists :const value}}.R5,i104,R6,i1,R7,s12,arbace/go.aev9,arbace.go10,member-varm12,R8,TR2,L1,V6,R14,Myn4,pathm2,R3,R4,Myn2,nmm2,R3,R4,R15,R16,R17,R0,s65,Interns the var of member name (kind, handle, digest info) in ns.R5,i135,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,table-ns!m10,R2,L1,V1,R9,R0,s217,Makes the namespace of listed package path p (arbace.lang.GoInterp's loadTable, for\n  RT.load): its vars are made when first resolved, all of them when the namespace's mappings\n  are asked for (ns-publics, refer: S9).R5,i149,R6,i1,R7,s12,arbace/go.aev9,arbace.go8,packagesm10,R2,L1,V0,R0,s71,The import paths of the table's packages (go/arbace/gotable.edn, §6.6).R5,i173,R6,i1,R7,s12,arbace/go.aev9,arbace.go3,newm10,R2,L1,V1,Myn1,tm2,R3,R18,R0,s65,Go's new(T) for GoType t: a pointer to a new zero T (a Go value).R5,i181,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,zerom10,R2,L1,V1,Myn1,tm2,R3,R18,R0,s53,The zero value of GoType t, converted to Arbace by t.R5,i186,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,type-ofm10,R2,L1,V1,R12,R0,s45,The Go type (a GoType) of Go value v, or nil.R5,i191,R6,i1,R7,s12,arbace/go.aev9,arbace.go3,strm10,R2,L1,V1,R12,R0,s77,fmt.Sprint of v (a Go value; an Arbace scalar or string as Go's) as a String.R5,i196,R6,i1,R7,s12,arbace/go.aev9,arbace.go6,spreadm10,R2,L1,V1,R11,R0,s132,(go/spread xs) as the last argument of a variadic Go function passes the Go slice xs as its\n  variadic parameter (Go's f(a, xs...)).R5,i201,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,assign!m10,R2,L1,V2,Myn1,vm2,R3,R19,R20,R0,s133,Assigns the package variable of GoVar v (a var's root: (go/assign! go.x/V 3)) the Arbace\n  value x, converted by the variable's type.R5,i207,R6,i1,R7,s12,arbace/go.aev9,arbace.go11,reify-typesv11,arbace.core4,atomm8,R8,TR5,i218,R6,i1,R7,s12,arbace/go.aev9,arbace.go10,type-namesm10,R8,TR2,L1,V1,R21,R5,i220,R6,i1,R7,s12,arbace/go.aev9,arbace.go10,reify-typem10,R2,L1,V1,R21,R0,s148,The reify type of Go interface types ts (GoTypes of listed packages' interfaces) and its\n  methods' names in order: [T name...], made once per list.R5,i222,R6,i1,R7,s12,arbace/go.aev9,arbace.go10,reify-datam10,R2,L1,V3,R22,R21,R23,R0,s239,The data of a reify of Go interfaces (arbace.lang.GoReify's goiReify): rt its reify-type,\n  fns its methods' fns by name (each taking the object first), as an Object[] [T f...] in rt's\n  order; every method of the interfaces must be given.R5,i231,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,repl-fnm10,R2,L1,V1,R24,R0,s65,arbace.go.repl's function nm (the namespace loaded on first use).R5,i250,R6,i1,R7,s12,arbace/go.aev9,arbace.go6,pos-ofm10,R8,TR2,L1,V1,R25,R5,i252,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,packagem10,R2,L1,V3,R24,R26,R27,R0,s69,go/package: the namespace's Go package (its name, :path, :files ...).R5,i254,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,filem10,R2,L1,V3,R24,R26,R27,R0,s60,go/file: the namespace's current Go file, its :imports (S5).R5,i259,R6,i1,R7,s12,arbace/go.aev9,arbace.go8,declare*m10,R2,L1,V2,R25,R27,R0,s67,A declaration form's call of arbace.go.repl/declare! (the macros').R5,i264,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,funcm10,R2,L1,V2,R26,R28,R0,s69,go/func: a Go function (§2.5): checked and defined, its var returned.R5,i269,R6,i1,R7,s12,arbace/go.aev9,arbace.go6,methodm10,R2,L1,V2,R26,R28,R0,s30,go/method: a Go method (§2.5).R5,i272,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,typem10,R2,L1,V2,R26,R28,R0,s26,go/type: a Go type (§2.5).R5,i275,R6,i1,R7,s12,arbace/go.aev9,arbace.go3,varm10,R2,L1,V2,R26,R28,R0,s37,go/var: a Go package variable (§2.5).R5,i278,R6,i1,R7,s12,arbace/go.aev9,arbace.go5,constm10,R2,L1,V2,R26,R28,R0,s31,go/const: a Go constant (§2.5).R5,i281,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,directivem10,R2,L1,V2,R26,R28,R0,s39,go/directive: accepted, ignored (§2.2).R5,i284,R6,i1,R7,s12,arbace/go.aev9,arbace.go6,importm10,R2,L1,V2,R26,R29,R0,s69,go/import: import specs [name \"path\"] for the current REPL file (S5).R5,i286,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,evalm10,R2,L1,V2,R26,R30,R0,s120,go/eval: Go statements run in the namespace's package (go.user outside go.*), the last one's\n  value as Arbace's (§2.4).R5,i291,R6,i1,R7,s12,arbace/go.aev9,arbace.go8,run-mainm10,R2,L1,V1,R31,R0,s75,Runs package ns-sym's main (§2.6): nil, or a GoExit when it called os.Exit.R5,i297,R6,i1,R7,s12,arbace/go.aev9,arbace.go12,run-compiledm10,R2,L1,V3,R31,R26,R32,R0,s183,Prints package ns-sym's program (it and the interpreted packages it imports) with repr/go,\n  builds it with build/go and runs it with args as a child process (G15): {:out :err :exit}.R5,i302,R6,i1,R7,s12,arbace/go.aev9,arbace.go5,checkm10,R2,L1,V1,R31,R0,s70,The errors of package ns-sym checked again, as data (nothing defined).R5,i308,R6,i1,R7,s12,arbace/go.ae")

var Lit_63 *jrt.String = jrt.Intern("arbace.go$eval1822000004$loading__1927001464__auto____1822000005")

var Lit_64 *jrt.String = jrt.Intern("arbace.go$eval1822000008$fn__1822000009")

var Lit_65 *jrt.String = jrt.Intern("arbace.go$path__GT_ns")

var Lit_66 *jrt.String = jrt.Intern("arbace.go$fn__1822000016")

var Lit_67 *jrt.String = jrt.Intern("arbace.go$digest_forms")

var Lit_68 *jrt.String = jrt.Intern("arbace.go$params_of")

var Lit_69 *jrt.String = jrt.Intern("arbace.go$strip_doc")

var Lit_70 *jrt.String = jrt.Intern("arbace.go$const_value")

var Lit_71 *jrt.String = jrt.Intern("arbace.go$digest_info")

var Lit_72 *jrt.String = jrt.Intern("arbace.go$member_var")

var Lit_73 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_")

var Lit_74 *jrt.String = jrt.Intern("arbace.go$packages")

var Lit_75 *jrt.String = jrt.Intern("arbace.go$new")

var Lit_76 *jrt.String = jrt.Intern("arbace.go$zero")

var Lit_77 *jrt.String = jrt.Intern("arbace.go$type_of")

var Lit_78 *jrt.String = jrt.Intern("arbace.go$str")

var Lit_79 *jrt.String = jrt.Intern("arbace.go$spread")

var Lit_80 *jrt.String = jrt.Intern("arbace.go$assign_BANG_")

var Lit_81 *jrt.String = jrt.Intern("arbace.go$type_names")

var Lit_82 *jrt.String = jrt.Intern("arbace.go$reify_type")

var Lit_83 *jrt.String = jrt.Intern("arbace.go$reify_data")

var Lit_84 *jrt.String = jrt.Intern("arbace.go$repl_fn")

var Lit_85 *jrt.String = jrt.Intern("arbace.go$pos_of")

var Lit_86 *jrt.String = jrt.Intern("arbace.go$package")

var Lit_87 *jrt.String = jrt.Intern("arbace.go$file")

var Lit_88 *jrt.String = jrt.Intern("arbace.go$declare_STAR_")

var Lit_89 *jrt.String = jrt.Intern("arbace.go$func")

var Lit_90 *jrt.String = jrt.Intern("arbace.go$method")

var Lit_91 *jrt.String = jrt.Intern("arbace.go$type")

var Lit_92 *jrt.String = jrt.Intern("arbace.go$var")

var Lit_93 *jrt.String = jrt.Intern("arbace.go$const")

var Lit_94 *jrt.String = jrt.Intern("arbace.go$directive")

var Lit_95 *jrt.String = jrt.Intern("arbace.go$import")

var Lit_96 *jrt.String = jrt.Intern("arbace.go$eval")

var Lit_97 *jrt.String = jrt.Intern("arbace.go$run_main")

var Lit_98 *jrt.String = jrt.Intern("arbace.go$run_compiled")

var Lit_99 *jrt.String = jrt.Intern("arbace.go$check")
