//line j2g_strings.ae:1
package aot_arbace_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn3,newyn3,strkn3,dockn5,indexkn4,textkn5,startkn3,eofks9,arbace.go3,eofyn1,&kn3,tagyn1,_kn4,elseyn7,float32kn11,type-paramskn8,arglistskn5,constkn3,valks2,go10,underlyingks2,go4,kindks2,go7,packagekn6,methodkn3,varkn4,funckn4,typev11,arbace.core5,referR0,R1,V2,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn9,arbace.gom2,R4,s1411,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  The macros of Go forms (go/func, go/type ...), the checker and the interpreter come with GR2\n  and GR3.v11,arbace.core6,symbolv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core9,interposev11,arbace.core3,mapC16,java.lang.StringR5,v11,arbace.core11,read-stringv11,arbace.core4,subsl0,R6,R7,v9,arbace.go12,digest-indexv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,readm2,R8,R9,R9,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core3,vecv11,arbace.core11,map-indexedR10,R10,v11,arbace.core7,symbol?R11,v11,arbace.core4,not=R12,v11,arbace.core4,nameR13,v11,arbace.core7,string?v11,arbace.core4,restv11,arbace.core8,integer?v11,arbace.core5,char?v11,arbace.core6,float?v11,arbace.core6,ratio?v11,arbace.core8,decimal?R14,v11,arbace.core4,seq?v11,arbace.core6,mapcatv11,arbace.core6,secondv11,arbace.core6,reducev11,arbace.core3,notv11,arbace.core9,namespacev9,arbace.go9,strip-docv11,arbace.core4,dropl2,R15,v11,arbace.core5,assocR4,R16,v11,arbace.core4,listv9,arbace.go9,params-ofR17,v9,arbace.go11,const-valueR18,R19,v9,arbace.go12,digest-formsR20,R21,v11,arbace.core6,internv11,arbace.core9,with-metaR22,R23,R24,R25,v11,arbace.core9,create-nsv9,arbace.go8,path->nsv11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core7,keywordv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core9,partitionl3,v9,arbace.go11,digest-infov11,arbace.core9,contains?v9,arbace.go10,member-varv11,arbace.core4,sortv11,arbace.core6,concatv11,arbace.core4,keys")

var Lit_1 *jrt.String = jrt.Intern("byte-string")

var Lit_2 *jrt.String = jrt.Intern("arbace.go$const_value$fn__1822000029")

var Lit_3 *jrt.String = jrt.Intern("UTF-8")

var Lit_4 *jrt.String = jrt.Intern("complex")

var Lit_5 *jrt.String = jrt.Intern("rune")

var Lit_6 *jrt.String = jrt.Intern("binary-float")

var Lit_7 *jrt.String = jrt.Intern("arbace.go$digest_info$fn__1822000032")

var Lit_8 *jrt.String = jrt.Intern("go")

var Lit_9 *jrt.String = jrt.Intern("method")

var Lit_10 *jrt.String = jrt.Intern(".")

var Lit_11 *jrt.String = jrt.Intern("type")

var Lit_12 *jrt.String = jrt.Intern("const")

var Lit_13 *jrt.String = jrt.Intern("func")

var Lit_14 *jrt.String = jrt.Intern("var")

var Lit_15 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_16 *jrt.String = jrt.Intern("arbace.lang.GoFn")

var Lit_17 *jrt.String = jrt.Intern("arbace.lang.GoVar")

var Lit_18 *jrt.String = jrt.Intern("arbace.lang.GoType")

var Lit_19 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_20 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_21 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_22 *jrt.String = jrt.Intern("\n")

var Lit_23 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_24 *jrt.String = jrt.Intern("arbace.go$params_of$fn__1822000024")

var Lit_25 *jrt.String = jrt.Intern("p")

var Lit_26 *jrt.String = jrt.Intern("go.")

var Lit_27 *jrt.String = jrt.Intern("arbace.go$path__GT_ns$fn__1822000013")

var Lit_28 *jrt.String = jrt.Intern("split")

var Lit_29 *jrt.String = jrt.Intern("/")

var Lit_30 *jrt.String = jrt.Intern("replaceAll")

var Lit_31 *jrt.String = jrt.Intern("[.-]")

var Lit_32 *jrt.String = jrt.Intern("_")

var Lit_33 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049")

var Lit_34 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000061")

var Lit_35 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063")

var Lit_36 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$make__1822000081")

var Lit_37 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$resolver__1822000086")

var Lit_38 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068")

var Lit_39 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069")

var Lit_40 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069$fn__1822000070")

var Lit_41 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050")

var Lit_42 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050$fn__1822000051")

var Lit_43 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,filekn7,privateyn1,pyn2,pvyn2,xsyn1,vyn10,underlyingyn2,nsyn4,kindyn6,handleyn4,infoyn6,GoTypeyn5,GoVaryn1,xv11,arbace.core5,in-nsMyn9,arbace.gom2,R0,s1411,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  The macros of Go forms (go/func, go/type ...), the checker and the interpreter come with GR2\n  and GR3.m2,R0,s1411,Go forms at the REPL (doc/go/GOI-SPEC.md), milestone GR1: Arbace calling compiled Go.\n\n  A package of goi's table of compiled packages (go/arbace/gotable.edn: strings, strconv, math,\n  time, fmt ...) is a namespace, go. and its import path (go.strings, go.math.rand.v2), made\n  from the table when it is required (§2.1, §7.2; arbace.lang.RT's load asks\n  arbace.lang.GoInterp first):\n\n    (require '[go.strings :as strings])\n    (strings/ToUpper \"go\")                      ;=> \"GO\"\n    (strings/Cut \"k=v\" \"=\")                     ;=> [\"k\" \"v\" true]\n    (let [b (go/new go.strings/Builder)]\n      (strings/Builder.WriteString b \"x\")       ; a method: T.M, the receiver first\n      (strings/Builder.String b))               ;=> \"x\"\n\n  Its vars are made on first use (S9): each function a GoFn, each method T.M a GoFn of its\n  method expression, each variable a GoVar (deref it), each type a GoType (an IFn: (T) its zero\n  value, (T v) a conversion, (T {:Field v}) a struct), each constant its value. Arguments and\n  results convert by the Go types (§5.6): Long, Double, Boolean, String, Character for Go's\n  scalars and strings, Go values (of the class arbace.lang.GoValue, printed #go \"...\") for the\n  rest; several results are a vector; a panic is an arbace.lang.GoPanic, os.Exit an\n  arbace.lang.GoExit.\n\n  The macros of Go forms (go/func, go/type ...), the checker and the interpreter come with GR2\n  and GR3.R1,v9,arbace.go8,path->nsm10,R2,L1,V1,Myn1,pm2,R3,R4,R0,s109,The namespace of Go import path p (SPEC.md §4.1): go. and the path, / as ., . and - inside an\n  element as _.R5,i33,R6,i1,R7,s12,arbace/go.aev9,arbace.go12,digest-indexm8,R8,TR5,i39,R6,i1,R7,s12,arbace/go.aev9,arbace.go12,digest-formsm10,R2,L1,V1,R9,R0,s113,The forms of the digest of listed package path p (§6.5): its go/package, go/file and\n  declaration forms, or nil.R5,i45,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,params-ofm12,R8,TR2,L1,V1,R10,R0,s82,The parameter names of a signature's vector (Go's names; p1 ... for unnamed ones).R5,i57,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,strip-docm10,R8,TR2,L1,V1,R11,R5,i67,R6,i1,R7,s12,arbace/go.aev9,arbace.go11,const-valuem12,R8,TR2,L1,V2,R12,R13,R0,s204,A constant's :val as an Arbace value (§2.1, §5.6): integers as Long or BigInt, floats as a\n  Double (a Float for a float32 constant), runes as their Long, strings as String, complex\n  values as Go values.R5,i69,R6,i1,R7,s12,arbace/go.aev9,arbace.go11,digest-infom12,R8,TR2,L1,V1,R9,R0,s89,What the digest says of package p's exported names: {name {:doc :arglists :const value}}.R5,i87,R6,i1,R7,s12,arbace/go.aev9,arbace.go10,member-varm12,R8,TR2,L1,V6,R14,Myn4,pathm2,R3,R4,Myn2,nmm2,R3,R4,R15,R16,R17,R0,s65,Interns the var of member name (kind, handle, digest info) in ns.R5,i118,R6,i1,R7,s12,arbace/go.aev9,arbace.go9,table-ns!m10,R2,L1,V1,R9,R0,s217,Makes the namespace of listed package path p (arbace.lang.GoInterp's loadTable, for\n  RT.load): its vars are made when first resolved, all of them when the namespace's mappings\n  are asked for (ns-publics, refer: S9).R5,i132,R6,i1,R7,s12,arbace/go.aev9,arbace.go8,packagesm10,R2,L1,V0,R0,s71,The import paths of the table's packages (go/arbace/gotable.edn, §6.6).R5,i156,R6,i1,R7,s12,arbace/go.aev9,arbace.go3,newm10,R2,L1,V1,Myn1,tm2,R3,R18,R0,s65,Go's new(T) for GoType t: a pointer to a new zero T (a Go value).R5,i164,R6,i1,R7,s12,arbace/go.aev9,arbace.go4,zerom10,R2,L1,V1,Myn1,tm2,R3,R18,R0,s53,The zero value of GoType t, converted to Arbace by t.R5,i169,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,type-ofm10,R2,L1,V1,R12,R0,s45,The Go type (a GoType) of Go value v, or nil.R5,i174,R6,i1,R7,s12,arbace/go.aev9,arbace.go3,strm10,R2,L1,V1,R12,R0,s77,fmt.Sprint of v (a Go value; an Arbace scalar or string as Go's) as a String.R5,i179,R6,i1,R7,s12,arbace/go.aev9,arbace.go6,spreadm10,R2,L1,V1,R11,R0,s132,(go/spread xs) as the last argument of a variadic Go function passes the Go slice xs as its\n  variadic parameter (Go's f(a, xs...)).R5,i184,R6,i1,R7,s12,arbace/go.aev9,arbace.go7,assign!m10,R2,L1,V2,Myn1,vm2,R3,R19,R20,R0,s133,Assigns the package variable of GoVar v (a var's root: (go/assign! go.x/V 3)) the Arbace\n  value x, converted by the variable's type.R5,i190,R6,i1,R7,s12,arbace/go.ae")

var Lit_44 *jrt.String = jrt.Intern("arbace.go$eval1822000004$loading__1927001464__auto____1822000005")

var Lit_45 *jrt.String = jrt.Intern("arbace.go$eval1822000008$fn__1822000009")

var Lit_46 *jrt.String = jrt.Intern("arbace.go$path__GT_ns")

var Lit_47 *jrt.String = jrt.Intern("arbace.go$fn__1822000016")

var Lit_48 *jrt.String = jrt.Intern("arbace.go$digest_forms")

var Lit_49 *jrt.String = jrt.Intern("arbace.go$params_of")

var Lit_50 *jrt.String = jrt.Intern("arbace.go$strip_doc")

var Lit_51 *jrt.String = jrt.Intern("arbace.go$const_value")

var Lit_52 *jrt.String = jrt.Intern("arbace.go$digest_info")

var Lit_53 *jrt.String = jrt.Intern("arbace.go$member_var")

var Lit_54 *jrt.String = jrt.Intern("arbace.go$table_ns_BANG_")

var Lit_55 *jrt.String = jrt.Intern("arbace.go$packages")

var Lit_56 *jrt.String = jrt.Intern("arbace.go$new")

var Lit_57 *jrt.String = jrt.Intern("arbace.go$zero")

var Lit_58 *jrt.String = jrt.Intern("arbace.go$type_of")

var Lit_59 *jrt.String = jrt.Intern("arbace.go$str")

var Lit_60 *jrt.String = jrt.Intern("arbace.go$spread")

var Lit_61 *jrt.String = jrt.Intern("arbace.go$assign_BANG_")
