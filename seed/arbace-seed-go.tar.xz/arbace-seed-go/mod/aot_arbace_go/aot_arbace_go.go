//line aot_arbace_go.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New() *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_A_const_1, A_arbace_go_A_const_2, A_arbace_go_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_eval1822000008_fn__1822000009_A_New() *A_arbace_go_eval1822000008_fn__1822000009_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000008_fn__1822000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_go_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_A_const_7.GetRawRoot__O(), A_arbace_go_A_const_8) }









































func A_arbace_go_path__GT_ns_A_New() *A_arbace_go_path__GT_ns_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_go_path__GT_ns_A) Ctor() {}
//line :43:1
func (t *A_arbace_go_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {



	var root_17 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil); var tmp2 any; var root_21 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_25 any; var root_26 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = Lit_12; var arg_30 any; var root_31 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp3 any = A_arbace_go_path__GT_ns_fn__1822000013_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *jrt.Class = A_arbace_go_A_const_14; var arg_35 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__0, tmp5, Lit_34, jrt.RefArrayOf(jrt.Object_class, Lit_35)); if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_17, arg_20) } }
//line :47:1
func A_arbace_go_path__GT_ns_fn__1822000013_A_New() *A_arbace_go_path__GT_ns_fn__1822000013_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_fn__1822000013_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Ctor() {}
//line :47:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Invoke_O_O__O(self, p1__1822000012_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_go_A_const_14; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1822000012_SHARP___1, tmp1, Lit_36, jrt.RefArrayOf(jrt.Object_class, Lit_37, Lit_38)) }


func A_arbace_go_fn__1822000016_A_New() *A_arbace_go_fn__1822000016_A { A_arbace_go_A_Init(); t := &A_arbace_go_fn__1822000016_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_fn__1822000016_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_fn__1822000016_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_26); var tmp1 any = A_arbace_go_A_const_15; var tmp2 any; var root_37 any = A_arbace_go_A_const_16.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_39 lang.IFn

		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__2; var arg_45 any = A_arbace_go_A_const_18; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_37, arg_40) }
//line :51:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_A_const_19; var tmp5 any = A_arbace_go_A_const_20; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_digest_forms_A_New() *A_arbace_go_digest_forms_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_forms_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_digest_forms_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_47 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_49 lang.IFn; if



	linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_A_const_21.GetRawRoot__O(); if linked_48 == nil { temp__1927000414__auto____2 = ifn_49.Invoke_O__O(arg_50) } else { temp__1927000414__auto____2 = linked_48.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__1822000018__3 any = temp__1927000414__auto____2; var map__1822000018__4 any; if lang.ISeq_InstanceOf(map__1822000018__3) { var tmp1 any; var root_51 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = map__1822000018__3; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_55 any = A_arbace_go_A_const_23.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = map__1822000018__3; if linked_56 == nil { tmp2 = ifn_57.Invoke_O__O(arg_58) } else { tmp2 = linked_56.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_55, arg_58) }; map__1822000018__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_59 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = map__1822000018__3; if linked_60 == nil { tmp3 = ifn_61.Invoke_O__O(arg_62) } else { tmp3 = linked_60.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_59, arg_62) }; if jrt.J2g_Truth(tmp3) { var root_63 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = map__1822000018__3; if linked_64 == nil { map__1822000018__4 = ifn_65.Invoke_O__O(arg_66) } else { map__1822000018__4 = linked_64.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_63, arg_66) } } else { map__1822000018__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1822000018__4 = map__1822000018__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_15); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_19); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_20); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__1822000020__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(1), nil); var r__12 any; var tmp4 any; var root_67 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_69 lang.IFn
			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = text__6; var arg_71 any; var na_73 any = start__7; var na_74 any = a__10; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_73); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_74) }; tmp5 = tmp6; if tmp5 { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); var n1_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var nr_77 int64 = n0_75 + n1_76; if (n0_75^nr_77)&(n1_76^nr_77) >= 0 { arg_71 = jrt.Long_ValueOf_J__Long_NoInit(nr_77).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_73); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_74) }; tmp7 = tmp8; if tmp7 { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); var n1_76_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); arg_71 = jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + n1_76_2).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } }; var arg_72 any; var na_78 any = start__7; var na_79 any = b__11; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_78); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_79) }; tmp9 = tmp10; if tmp9 { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var nr_82 int64 = n0_80 + n1_81; if (n0_80^nr_82)&(n1_81^nr_82) >= 0 { arg_72 = jrt.Long_ValueOf_J__Long_NoInit(nr_82).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_78); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_79) }; tmp11 = tmp12; if tmp11 { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); arg_72 = jrt.Double_ValueOf_D__Double_NoInit(n0_80_2 + n1_81_2).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } }; if linked_68 == nil { tmp4 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) }
//line :60:1
			r__12 = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(tmp4)))

			var root_91 any = A_arbace_go_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_A_const_32, jrt.Boolean_FALSE.Ref()); if linked_92 == nil { ifn_93.Invoke_O__O(arg_94) } else { linked_92.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_91, arg_94) }
//line :60:1
			var tmp13 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__15 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__16 any; var root_83 any = A_arbace_go_A_const_26.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_85 lang.IFn



				if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_go_A_const_27; var arg_87 any = r__12; if linked_84 == nil { f__16 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { f__16 = linked_84.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }
				if lang.Util_Equiv_O_O__Z_NoInit(f__16, A_arbace_go_A_const_28) { tmp13 = acc__15 } else { var tmp14 any; var root_100 any = A_arbace_go_A_const_7.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = acc__15; var arg_104 any = f__16; if linked_101 == nil { tmp14 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp14 = linked_101.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; acc__15 = tmp14; continue L1 }
//line :60:1
				break L1 } }; return nil }(); var root_88 any = A_arbace_go_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_90 lang.IFn

			if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; if linked_89 == nil { ifn_90.Invoke__O() } else { linked_89.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_88) }
//line :60:1
			if tmp15 != nil { panic(tmp15) }; return tmp13 } else { return nil } } else {
//line :59:1
				return nil } }







func A_arbace_go_params_of_A_New() *A_arbace_go_params_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_go_params_of_A) Ctor() {}
//line :67:1
func (t *A_arbace_go_params_of_A) Invoke_O_O__O(self, pv__0 any) any {


	var root_105 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_go_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp1 any = A_arbace_go_params_of_fn__1822000024_A_New(); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_params_of_fn__1822000024_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_params_of_fn__1822000024_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_113 any = pv__0; if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_105, arg_108) } }
//line :70:1
func A_arbace_go_params_of_fn__1822000024_A_New() *A_arbace_go_params_of_fn__1822000024_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_fn__1822000024_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Ctor() {}
//line :70:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, x__2) } else {
												if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_114 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_116 lang.IFn

		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__2; if linked_115 == nil { and__1927000168__auto____3 = ifn_116.Invoke_O__O(arg_117) } else { and__1927000168__auto____3 = linked_115.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_118 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_go_A_const_40; var arg_122 any = x__2; if linked_119 == nil { tmp1 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_118, arg_121, arg_122) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :71:1
		if jrt.J2g_Truth(tmp1) {

			var root_123 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = x__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_127, arg_130) }; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_123, arg_126) } } else {
//line :71:1
				if A_arbace_go_A_const_42 != nil {


					var root_131 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp4 jrt.Number_I; var na_135 any = i__1; if jrt.Long_InstanceOf(na_135) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); if n0_136 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_136 + 1)) } } else { if jrt.Double_InstanceOf(na_135) { var n0_136_2 float64 = jrt.NN(jrt.Double_Cast(na_135)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_136_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } }; arg_134 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_132 == nil { return ifn_133.Invoke_O__O(arg_134) } else { return linked_132.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_131, arg_134) } } else {
//line :71:1
						return nil } } } } }
//line :70:1
func (t *A_arbace_go_params_of_fn__1822000024_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, x__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_137 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_139 lang.IFn

		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = x__2; if linked_138 == nil { and__1927000168__auto____3 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____3 = linked_138.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_141 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_go_A_const_40; var arg_145 any = x__2; if linked_142 == nil { tmp1 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :71:1
		if jrt.J2g_Truth(tmp1) {

			var root_146 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_150 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = x__2; if linked_151 == nil { arg_149 = ifn_152.Invoke_O__O(arg_153) } else { arg_149 = linked_151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_150, arg_153) }; if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_146, arg_149) } } else {
//line :71:1
				if A_arbace_go_A_const_42 != nil {


					var root_154 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp4 jrt.Number_I; var n0_158 int64 = i__1_l; if n0_158 == 9223372036854775807 { var tmp5 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp5 = i__1_b } else { tmp5 = i__1_b }; tmp4 = lang.Numbers_Inc_O__Number_NoInit(tmp5) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_158 + 1)) }; arg_157 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_155 == nil { return ifn_156.Invoke_O__O(arg_157) } else { return linked_155.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_154, arg_157) } } else {
//line :71:1
						return nil
					}
			}
	}
}

func A_arbace_go_strip_doc_A_New() *A_arbace_go_strip_doc_A { A_arbace_go_A_Init(); t := &A_arbace_go_strip_doc_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_go_strip_doc_A) Ctor() {}
//line :77:1
func (t *A_arbace_go_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_160 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_164 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = xs__0; if linked_165 == nil { arg_163 = ifn_166.Invoke_O__O(arg_167) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_168 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = xs__0; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) }; var tmp3 any = tmp2; var tmp4 any; var root_172 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = xs__0; if linked_173 == nil { tmp4 = ifn_174.Invoke_O__O(arg_175) } else { tmp4 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) } }

func A_arbace_go_const_value_A_New() *A_arbace_go_const_value_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_const_value_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_const_value_A) Invoke_O_O_O__O(self, v__0, underlying__1 any) any {




	var tmp1 any; var root_176 any = A_arbace_go_A_const_45.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_178 lang.IFn
	if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = v__0; if linked_177 == nil { tmp1 = ifn_178.Invoke_O__O(arg_179) } else { tmp1 = linked_177.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_176, arg_179) }
//line :84:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var root_180 any = A_arbace_go_A_const_46.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_182 lang.IFn

		if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = v__0; if linked_181 == nil { tmp2 = ifn_182.Invoke_O__O(arg_183) } else { tmp2 = linked_181.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_180, arg_183) }
//line :84:1
		if jrt.J2g_Truth(tmp2) {

			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__0))).Ref() } else {
//line :84:1
				var tmp3 any; var or__1927000174__auto____3 any; var root_184 any = A_arbace_go_A_const_47.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_float_QMARK__A_fn_class); var ifn_186 lang.IFn


				if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { or__1927000174__auto____3 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____3 = linked_185.(*aot_arbace_core.A_arbace_core_float_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_188 any = A_arbace_go_A_const_48.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = v__0; if linked_189 == nil { or__1927000174__auto____4 = ifn_190.Invoke_O__O(arg_191) } else { or__1927000174__auto____4 = linked_189.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { var root_192 any = A_arbace_go_A_const_49.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_decimal_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*aot_arbace_core.A_arbace_core_decimal_QMARK__A).Invoke_O_O__O(root_192, arg_195) } } }
//line :84:1
				if jrt.J2g_Truth(tmp3) {


					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_50, underlying__1) { return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__0)).Ref() } else { return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__0)).Ref() } } else {
//line :84:1
						var tmp4 any; var root_196 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_198 lang.IFn



						if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = v__0; if linked_197 == nil { tmp4 = ifn_198.Invoke_O__O(arg_199) } else { tmp4 = linked_197.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_196, arg_199) }
//line :84:1
						if jrt.J2g_Truth(tmp4) { var G__1822000028__3_ any; var root_200 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_202 lang.IFn



							if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = v__0; if linked_205 == nil { arg_203 = ifn_206.Invoke_O__O(arg_207) } else { arg_203 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; if linked_201 == nil { G__1822000028__3_ = ifn_202.Invoke_O__O(arg_203) } else { G__1822000028__3_ = linked_201.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_200, arg_203) }; switch lang.Util_Hash_O__I_NoInit(G__1822000028__3_) >> 7 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_2) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_52.GetRawRoot__O()); var tmp6 any = A_arbace_go_const_value_fn__1822000029_A_New(); var tmp7 *jrt.Class
								var fncls__222 /*line :88:1*/*jrt.Class = A_arbace_go_const_value_fn__1822000029_A_fn_class

								if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_const_value_fn__1822000029_A_fn_class = fncls__222d; tmp7 = fncls__222d } else { tmp7 = fncls__222 }
//line :88:1
								var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_223 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_225 lang.IFn

								if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = v__0; if linked_224 == nil { tmp9 = ifn_225.Invoke_O__O(arg_226) } else { tmp9 = linked_224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_223, arg_226) }
//line :88:1
								return jrt.String_New_B1_String(lang.Numbers_Byte_array_O__B1_NoInit(tmp5.Invoke_O_O__O(tmp8, tmp9)), Lit_4) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_5) {



									var tmp10 any; var root_227 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = v__0; if linked_228 == nil { tmp10 = ifn_229.Invoke_O__O(arg_230) } else { tmp10 = linked_228.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_227, arg_230) }; return lang.GoInterp_Complex_D_D__O(lang.RT_DoubleCast_O__D_NoInit(tmp10), lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) }
//line :88:1
							case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_6) {
								var tmp11 any; var root_231 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = v__0; if linked_232 == nil { tmp11 = ifn_233.Invoke_O__O(arg_234) } else { tmp11 = linked_232.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_231, arg_234) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp11)).Ref() }
//line :88:1
							case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_7) {




								var tmp12 any; var root_235 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = v__0; if linked_236 == nil { tmp12 = ifn_237.Invoke_O__O(arg_238) } else { tmp12 = linked_236.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_235, arg_238) }; return jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Multiply_D_D__D_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp12), jrt.Math_Pow_D_D__D(2.0, lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))))).Ref() }
//line :88:1
							default:}; return v__0 } else {
//line :84:1
								if A_arbace_go_A_const_42 != nil { return v__0 } else { return nil
								}
							}
					}
			}
	} }
func A_arbace_go_const_value_fn__1822000029_A_New() *A_arbace_go_const_value_fn__1822000029_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_fn__1822000029_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_214 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = x__1; if linked_215 == nil { tmp1 = ifn_216.Invoke_O__O(arg_217) } else { tmp1 = linked_215.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp1) { var root_218 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = jrt.NN(jrt.String_Cast(x__1)).GetBytes_String__B1(Lit_4).Ref(); if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) } } else { return lang.Tuple_Create_O__IPersistentVector(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_UncheckedByteCast_O__B_NoInit(x__1)).Ref()) } }






func A_arbace_go_digest_info_A_New() *A_arbace_go_digest_info_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_go_digest_info_A) Ctor() {}
//line :97:1
func (t *A_arbace_go_digest_info_A) Invoke_O_O__O(self, p__0 any) any {


	var root_239 any = A_arbace_go_A_const_54.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any; var tmp1 any = A_arbace_go_digest_info_fn__1822000032_A_New(); var tmp2 *jrt.Class; var fncls__429 *jrt.Class = A_arbace_go_digest_info_fn__1822000032_A_fn_class
	if fncls__429 == nil { var fncls__429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_digest_info_fn__1822000032_A_fn_class = fncls__429d; tmp2 = fncls__429d } else { tmp2 = fncls__429 }; arg_242 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :100:1
	var arg_243 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_244 any; var root_430 any = A_arbace_go_A_const_70.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_go_digest_forms_A_fn_class); var ifn_432 lang.IFn






















	if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = p__0; if linked_431 == nil { arg_244 = ifn_432.Invoke_O__O(arg_433) } else { arg_244 = linked_431.(*A_arbace_go_digest_forms_A).Invoke_O_O__O(root_430, arg_433) }
//line :100:1
	if linked_240 == nil { return ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { return linked_240.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) } }
func A_arbace_go_digest_info_fn__1822000032_A_New() *A_arbace_go_digest_info_fn__1822000032_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_fn__1822000032_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any; var root_245 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var and__1927000168__auto____3 any; var root_249 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__2; if linked_250 == nil { and__1927000168__auto____3 = ifn_251.Invoke_O__O(arg_252) } else { and__1927000168__auto____3 = linked_250.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_253 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = f__2; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { and__1927000168__auto____4 = ifn_255.Invoke_O__O(arg_256) } else { and__1927000168__auto____4 = linked_254.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_261 any = A_arbace_go_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_265 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = f__2; if linked_266 == nil { arg_264 = ifn_267.Invoke_O__O(arg_268) } else { arg_264 = linked_266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_265, arg_268) }; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_261, arg_264) }; arg_248 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_10, tmp2)).Ref() } else { arg_248 = and__1927000168__auto____4 } } else { arg_248 = and__1927000168__auto____3 }; if linked_246 == nil { tmp1 = ifn_247.Invoke_O__O(arg_248) } else { tmp1 = linked_246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var G__1822000033__3_ any; var root_269 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_271 lang.IFn

		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_273 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = f__2; if linked_274 == nil { arg_272 = ifn_275.Invoke_O__O(arg_276) } else { arg_272 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; if linked_270 == nil { G__1822000033__3_ = ifn_271.Invoke_O__O(arg_272) } else { G__1822000033__3_ = linked_270.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_269, arg_272) }; switch lang.Util_Hash_O__I_NoInit(G__1822000033__3_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_11) { var vec__1822000034__4 any; var root_278 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_go_strip_doc_A_fn_class); var ifn_280 lang.IFn



			if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_282, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_286 any = f__2; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(A_arbace_go_A_const_59, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_282, 2, A_arbace_go_A_const_59, arg_286) }; if linked_279 == nil { vec__1822000034__4 = ifn_280.Invoke_O__O(arg_281) } else { vec__1822000034__4 = linked_279.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_278, arg_281) }
//line :104:1
			var doc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__7 any; var tmp3 any = A_arbace_go_A_const_60; var tmp4 any; var root_287 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn




			if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = xs__6; if linked_288 == nil { tmp4 = ifn_289.Invoke_O__O(arg_290) } else { tmp4 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var root_291 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_291, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_295 any = xs__6; if linked_292 == nil { xs__7 = ifn_293.Invoke_O_O__O(A_arbace_go_A_const_59, arg_295) } else { xs__7 = linked_292.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_291, 2, A_arbace_go_A_const_59, arg_295) } } else { xs__7 = xs__6 }
//line :104:1
			var pv__8 any; var root_296 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_298 lang.IFn





			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = xs__7; if linked_297 == nil { pv__8 = ifn_298.Invoke_O__O(arg_299) } else { pv__8 = linked_297.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_296, arg_299) }
//line :104:1
			var r__9 any; var root_300 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn






			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = pv__8; if linked_301 == nil { r__9 = ifn_302.Invoke_O__O(arg_303) } else { r__9 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }
//line :104:1
			var rt__10 any; var tmp5 any; var and__1927000168__auto____10 any; var root_304 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_306 lang.IFn







			if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = r__9; if linked_305 == nil { and__1927000168__auto____10 = ifn_306.Invoke_O__O(arg_307) } else { and__1927000168__auto____10 = linked_305.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp6 *lang.Keyword = A_arbace_go_A_const_38; tmp5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__9)) } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) { var tmp7 *lang.Keyword = A_arbace_go_A_const_38; rt__10 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__9)) } else { rt__10 = r__9 }
//line :104:1
			var rt__11 any; var tmp8 any; var root_308 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn








			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = rt__10; if linked_309 == nil { tmp8 = ifn_310.Invoke_O__O(arg_311) } else { tmp8 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(tmp8) { var root_312 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = rt__10; if linked_313 == nil { rt__11 = ifn_314.Invoke_O__O(arg_315) } else { rt__11 = linked_313.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_312, arg_315) } } else { rt__11 = rt__10 }
			var tmp9 any; var root_316 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = rt__11; if linked_317 == nil { tmp9 = ifn_318.Invoke_O__O(arg_319) } else { tmp9 = linked_317.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(tmp9) {
				var root_320 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = acc__1; var arg_324 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil); var tmp11 any; var root_326 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = f__2; if linked_327 == nil { tmp11 = ifn_328.Invoke_O__O(arg_329) } else { tmp11 = linked_327.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_326, arg_329) }; arg_324 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, rt__11, nil, tmp11)).Ref(); var arg_325 any; var tmp12 any = A_arbace_go_A_const_62; var tmp13 any = A_arbace_go_A_const_63; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp15 any; var root_330 any = A_arbace_go_A_const_65.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_go_params_of_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = pv__8; if linked_331 == nil { tmp15 = ifn_332.Invoke_O__O(arg_333) } else { tmp15 = linked_331.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_330, arg_333) }; arg_325 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, doc__5, tmp13, tmp14.Invoke_O__O(tmp15))); if linked_321 == nil { return ifn_322.Invoke_O_O_O__O(arg_323, arg_324, arg_325) } else { return linked_321.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_320, arg_323, arg_324, arg_325) } } else {
//line :114:1
					return acc__1 } }
//line :104:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_13) {














			var root_334 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = acc__1; var arg_338 any; var root_340 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any; var root_344 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = f__2; if linked_345 == nil { arg_343 = ifn_346.Invoke_O__O(arg_347) } else { arg_343 = linked_345.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_344, arg_347) }; if linked_341 == nil { arg_338 = ifn_342.Invoke_O__O(arg_343) } else { arg_338 = linked_341.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_340, arg_343) }; var arg_339 any; var tmp16 any = A_arbace_go_A_const_62; var tmp17 any; var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp18 any; var root_348 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = d__4; if linked_349 == nil { tmp18 = ifn_350.Invoke_O__O(arg_351) } else { tmp18 = linked_349.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_348, arg_351) }; if jrt.J2g_Truth(tmp18) { tmp17 = d__4 } else { tmp17 = nil }; arg_339 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17)); if linked_335 == nil { return ifn_336.Invoke_O_O_O__O(arg_337, arg_338, arg_339) } else { return linked_335.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_334, arg_337, arg_338, arg_339) } }
//line :104:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_14) { var n__4 any; var root_352 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_354 lang.IFn












			if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = f__2; if linked_353 == nil { n__4 = ifn_354.Invoke_O__O(arg_355) } else { n__4 = linked_353.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_352, arg_355) }
//line :104:1
			var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__4); var root_356 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_358 lang.IFn













			if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = acc__1; var arg_360 any; var root_362 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = n__4; if linked_363 == nil { arg_360 = ifn_364.Invoke_O__O(arg_365) } else { arg_360 = linked_363.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_362, arg_365) }; var arg_361 any; var tmp19 any = A_arbace_go_A_const_62; var tmp20 any = A_arbace_go_A_const_62.Invoke_O__O(m__5); var tmp21 any = A_arbace_go_A_const_66; var tmp22 any; var root_366 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_const_value_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_A_const_68.Invoke_O__O(m__5); var arg_370 any = A_arbace_go_A_const_69.Invoke_O__O(m__5); if linked_367 == nil { tmp22 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { tmp22 = linked_367.(*A_arbace_go_const_value_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; arg_361 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20, tmp21, tmp22)); if linked_357 == nil { return ifn_358.Invoke_O_O_O__O(arg_359, arg_360, arg_361) } else { return linked_357.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_356, arg_359, arg_360, arg_361) } }
//line :104:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_15) { var vec__1822000037__4 any; var root_371 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_go_strip_doc_A_fn_class); var ifn_373 lang.IFn
			if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var root_375 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_375, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_379 any = f__2; if linked_376 == nil { arg_374 = ifn_377.Invoke_O_O__O(A_arbace_go_A_const_59, arg_379) } else { arg_374 = linked_376.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_375, 2, A_arbace_go_A_const_59, arg_379) }; if linked_372 == nil { vec__1822000037__4 = ifn_373.Invoke_O__O(arg_374) } else { vec__1822000037__4 = linked_372.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_371, arg_374) }
//line :104:1
			var doc__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__4, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__7_2 any; var tmp23 any = A_arbace_go_A_const_60; var tmp24 any; var root_380 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_382 lang.IFn

			if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = xs__6_2; if linked_381 == nil { tmp24 = ifn_382.Invoke_O__O(arg_383) } else { tmp24 = linked_381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_380, arg_383) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp23, tmp24) { var root_384 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_384, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_388 any = xs__6_2; if linked_385 == nil { xs__7_2 = ifn_386.Invoke_O_O__O(A_arbace_go_A_const_59, arg_388) } else { xs__7_2 = linked_385.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_384, 2, A_arbace_go_A_const_59, arg_388) } } else { xs__7_2 = xs__6_2 }
			var root_389 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = acc__1; var arg_393 any; var root_395 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var root_399 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = f__2; if linked_400 == nil { arg_398 = ifn_401.Invoke_O__O(arg_402) } else { arg_398 = linked_400.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_399, arg_402) }; if linked_396 == nil { arg_393 = ifn_397.Invoke_O__O(arg_398) } else { arg_393 = linked_396.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_395, arg_398) }; var arg_394 any; var tmp25 any = A_arbace_go_A_const_62; var tmp26 any = A_arbace_go_A_const_63; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp28 any; var root_403 any = A_arbace_go_A_const_65.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, A_arbace_go_params_of_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var root_407 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = xs__7_2; if linked_408 == nil { arg_406 = ifn_409.Invoke_O__O(arg_410) } else { arg_406 = linked_408.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_407, arg_410) }; if linked_404 == nil { tmp28 = ifn_405.Invoke_O__O(arg_406) } else { tmp28 = linked_404.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_403, arg_406) }; arg_394 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp25, doc__5_2, tmp26, tmp27.Invoke_O__O(tmp28))); if linked_390 == nil { return ifn_391.Invoke_O_O_O__O(arg_392, arg_393, arg_394) } else { return linked_390.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_389, arg_392, arg_393, arg_394) } }
//line :104:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_16) {















			var root_411 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = acc__1; var arg_415 any; var root_417 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var root_421 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = f__2; if linked_422 == nil { arg_420 = ifn_423.Invoke_O__O(arg_424) } else { arg_420 = linked_422.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_421, arg_424) }; if linked_418 == nil { arg_415 = ifn_419.Invoke_O__O(arg_420) } else { arg_415 = linked_418.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_417, arg_420) }; var arg_416 any; var tmp29 any = A_arbace_go_A_const_62; var tmp30 *lang.Keyword = A_arbace_go_A_const_62; var tmp31 any; var root_425 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = f__2; if linked_426 == nil { tmp31 = ifn_427.Invoke_O__O(arg_428) } else { tmp31 = linked_426.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_425, arg_428) }; arg_416 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp31)))); if linked_412 == nil { return ifn_413.Invoke_O_O_O__O(arg_414, arg_415, arg_416) } else { return linked_412.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_411, arg_414, arg_415, arg_416) } }
//line :104:1
		default:}; return acc__1
	}
}





















func A_arbace_go_member_var_A_New() *A_arbace_go_member_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_member_var_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_member_var_A) Ctor() {}
//line :128:1
func (t *A_arbace_go_member_var_A) Invoke_O_O_O_O_O_O_O__O(self, ns__0, path__1, nm__2, kind__3, handle__4, info__5 any) any { var full__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, path__1, nil, nm__2)).Ref(); var m__8 any; var G__1822000042__8_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_A_const_71, kind__3, A_arbace_go_A_const_72, path__1)); var G__1822000042__9_ any; if



	jrt.J2g_Truth(A_arbace_go_A_const_62.Invoke_O__O(info__5)) {
		var root_434 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = G__1822000042__8_; var arg_438 any = A_arbace_go_A_const_62; var arg_439 any = A_arbace_go_A_const_62.Invoke_O__O(info__5); if linked_435 == nil { G__1822000042__9_ = ifn_436.Invoke_O_O_O__O(arg_437, arg_438, arg_439) } else { G__1822000042__9_ = linked_435.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_434, arg_437, arg_438, arg_439) } } else {
//line :132:1
			G__1822000042__9_ = G__1822000042__8_ }; if jrt.J2g_Truth(A_arbace_go_A_const_63.Invoke_O__O(info__5)) {

				var root_440 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = G__1822000042__9_; var arg_444 any = A_arbace_go_A_const_63; var arg_445 any = A_arbace_go_A_const_63.Invoke_O__O(info__5); if linked_441 == nil { m__8 = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { m__8 = linked_441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) } } else {
//line :132:1
					m__8 = G__1822000042__9_ }; var root_446 any =


	A_arbace_go_A_const_73.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = ns__0; var arg_450 any; var root_452 any = A_arbace_go_A_const_74.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; var root_457 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = nm__2; if linked_458 == nil { arg_455 = ifn_459.Invoke_O__O(arg_460) } else { arg_455 = linked_458.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_457, arg_460) }; var arg_456 any = m__8; if linked_453 == nil { arg_450 = ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { arg_450 = linked_453.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) }; var arg_451 any; var G__1822000043__9_ any = kind__3; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1822000043__9_) >> 3 & 7 { case 1: if any(G__1822000043__9_) == any(A_arbace_go_A_const_75) { arg_451 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 3: if any(G__1822000043__9_) == any(A_arbace_go_A_const_76) { arg_451 = lang.GoVar_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 4: if any(G__1822000043__9_) == any(A_arbace_go_A_const_77) { arg_451 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 5: if any(G__1822000043__9_) == any(A_arbace_go_A_const_66) {



		arg_451 = A_arbace_go_A_const_66.Invoke_O__O(info__5)
//line :136:1
		break L1 }; case 6: if any(G__1822000043__9_) == any(A_arbace_go_A_const_78) { arg_451 = lang.GoType_New_O(handle__4); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1822000043__9_)))))}; if /*line :135:1*/ linked_447 == nil { return ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { return linked_447.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) } }






func A_arbace_go_table_ns_BANG__A_New() *A_arbace_go_table_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_table_ns_BANG__A) Ctor() {}
//line :142:1
func (t *A_arbace_go_table_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any { var ns__2 any; var root_462 any = A_arbace_go_A_const_79.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_464 lang.IFn; if




	linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_466 any = A_arbace_go_A_const_80.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_go_path__GT_ns_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = p__0; if linked_467 == nil { arg_465 = ifn_468.Invoke_O__O(arg_469) } else { arg_465 = linked_467.(*A_arbace_go_path__GT_ns_A).Invoke_O_O__O(root_466, arg_469) }; if linked_463 == nil { ns__2 = ifn_464.Invoke_O__O(arg_465) } else { ns__2 = linked_463.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_462, arg_465) }; var ms__3 any = /*line :142:1*/lang.GoInterp_Members_String__O1(jrt.String_Cast(p__0)).Ref(); var members__4 any; var root_470 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_472 lang.IFn; if






	linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_474 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_New(); var tmp2 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class = fncls__541d; tmp2 = fncls__541d } else { tmp2 = fncls__541 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_542 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = A_arbace_go_A_const_92; var arg_546 any = ms__3; if linked_543 == nil { tmp4 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { tmp4 = linked_543.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; arg_474 = tmp3.Invoke_O__O(tmp4); if linked_471 == nil { members__4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { members__4 = linked_471.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; var info__5 any; var tmp5 any = /*line :142:1*/A_arbace_go_table_ns_BANG__fn__1822000061_A_New_O(p__0); var tmp6 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class; if







	fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class = fncls__551d; tmp6 = fncls__551d } else { tmp6 = fncls__551 }; info__5 = /*line :142:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var consts__6 any; var tmp7 any = A_arbace_go_table_ns_BANG__fn__1822000063_A_New_O_O(info__5, members__4); var tmp8 *jrt.Class; var fncls__656 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class; if








	fncls__656 == nil { var fncls__656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class = fncls__656d; tmp8 = fncls__656d } else { tmp8 = fncls__656 }; consts__6 = /*line :142:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var make__7 any; var tmp9 any = A_arbace_go_table_ns_BANG__make__1822000081_A_New_O_O_O_O_O(ns__2, info__5, consts__6, p__0, members__4); var tmp10 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class; if









	fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class = fncls__683d; tmp10 = fncls__683d } else { tmp10 = fncls__683 }; make__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var resolver__8 any; var tmp11 any = /*line :142:1*/A_arbace_go_table_ns_BANG__resolver__1822000086_A_New_O_O_O(make__7, consts__6, members__4); var tmp12 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class; if














	fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class = fncls__737d; tmp12 = fncls__737d } else { tmp12 = fncls__737 }; resolver__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil);





	jrt.NN(lang.Namespace_Cast(ns__2)).SetResolver_O__V(resolver__8); return ns__2 }
//line :149:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_New() *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A) Invoke_O_O__O(self, s__1822000046__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_New_O_O(self, s__1822000046__1); var tmp2 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class = fncls__540d; tmp2 = fncls__540d } else { tmp2 = fncls__540 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :149:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A) Ctor_O_O(c__iter__1822000045, c__s__1822000046 any) { t.F_iter__1822000045 = c__iter__1822000045; t.F_s__1822000046 = c__s__1822000046 }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A) Invoke_O__O(self any) any { { var s__1822000046__1 any; var t_ any = t.F_s__1822000046; t.F_s__1822000046 = nil; s__1822000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_475 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__1822000046__1; if linked_476 == nil { temp__1927000414__auto____2 = ifn_477.Invoke_O__O(arg_478) } else { temp__1927000414__auto____2 = linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_479 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = s__1822000046__3; if linked_480 == nil { tmp1 = ifn_481.Invoke_O__O(arg_482) } else { tmp1 = linked_480.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_483 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = s__1822000046__3; if linked_484 == nil { c__1927001037__auto____4 = ifn_485.Invoke_O__O(arg_486) } else { c__1927001037__auto____4 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_483, arg_486) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000048__6 any; var root_487 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_488 == nil { b__1822000048__6 = ifn_489.Invoke_O__O(arg_490) } else { b__1822000048__6 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_487, arg_490) }; var tmp2 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_New_O_I_O(b__1822000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__500 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class; if fncls__500 == nil { var fncls__500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class = fncls__500d; tmp3 = fncls__500d } else { tmp3 = fncls__500 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_501 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any; var root_506 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = b__1822000048__6; if linked_507 == nil { arg_504 = ifn_508.Invoke_O__O(arg_509) } else { arg_504 = linked_507.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_506, arg_509) }; var arg_505 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000045); var tmp5 any; var root_510 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = s__1822000046__3; if linked_511 == nil { tmp5 = ifn_512.Invoke_O__O(arg_513) } else { tmp5 = linked_511.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_510, arg_513) }; arg_505 = tmp4.Invoke_O__O(tmp5); if linked_502 == nil { return ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { return linked_502.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) } } else { var root_514 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var root_519 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = b__1822000048__6; if linked_520 == nil { arg_517 = ifn_521.Invoke_O__O(arg_522) } else { arg_517 = linked_520.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_519, arg_522) }; var arg_518 any; if linked_515 == nil { return ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { return linked_515.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) } } } else { var vec__1822000056__4 any; var root_523 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__1822000046__3; if linked_524 == nil { vec__1822000056__4 = ifn_525.Invoke_O__O(arg_526) } else { vec__1822000056__4 = linked_524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_523, arg_526) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_527 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp6 any; var root_532 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = k__5; if linked_533 == nil { tmp6 = ifn_534.Invoke_O__O(arg_535) } else { tmp6 = linked_533.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_532, arg_535) }; arg_530 = lang.Tuple_Create_O_O__IPersistentVector(n__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6, h__7)); var arg_531 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1822000045); var tmp8 any; var root_536 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = s__1822000046__3; if linked_537 == nil { tmp8 = ifn_538.Invoke_O__O(arg_539) } else { tmp8 = linked_537.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_536, arg_539) }; arg_531 = tmp7.Invoke_O__O(tmp8); if linked_528 == nil { return ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { return linked_528.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :149:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A) Ctor_O_I_O(c__b__1822000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000048 = c__b__1822000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A) Invoke_O__O(self any) any { { var i__1822000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000052__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000047__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_491 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = t.F_b__1822000048; var arg_495 any; var tmp2 any; var root_496 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = k__3; if linked_497 == nil { tmp2 = ifn_498.Invoke_O__O(arg_499) } else { tmp2 = linked_497.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_496, arg_499) }; arg_495 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.Tuple_Create_O_O__IPersistentVector(tmp2, h__5)); if linked_492 == nil { ifn_493.Invoke_O_O__O(arg_494, arg_495) } else { linked_492.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_491, arg_494, arg_495) }; i__1822000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__fn__1822000061_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000061_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000061_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000061_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :150:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000061_A) Invoke_O__O(self any) any { var root_547 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_go_digest_info_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var t_ any = t.F_p; t.F_p = nil; arg_550 = t_; if linked_548 == nil { return ifn_549.Invoke_O__O(arg_550) } else { return linked_548.(*A_arbace_go_digest_info_A).Invoke_O_O__O(root_547, arg_550) } }
func A_arbace_go_table_ns_BANG__fn__1822000063_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__fn__1822000063_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_A) Ctor_O_O(c__info, c__members any) { t.F_info = c__info; t.F_members = c__members }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_A) Invoke_O__O(self any) any { var root_552 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_556 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_New_O(t.F_members); var tmp2 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class = fncls__651d; tmp2 = fncls__651d } else { tmp2 = fncls__651 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_652 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var t_ any = t.F_info; t.F_info = nil; arg_655 = t_; if linked_653 == nil { tmp4 = ifn_654.Invoke_O__O(arg_655) } else { tmp4 = linked_653.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_652, arg_655) }; arg_556 = tmp3.Invoke_O__O(tmp4); if linked_553 == nil { return ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { return linked_553.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) } }
//line :151:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A) Ctor_O(c__members any) { t.F_members = c__members }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A) Invoke_O_O__O(self, s__1822000065__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_New_O_O_O(t.F_members, s__1822000065__1, self); var tmp2 *jrt.Class; var fncls__650 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class; if fncls__650 == nil { var fncls__650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class = fncls__650d; tmp2 = fncls__650d } else { tmp2 = fncls__650 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :151:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A) Ctor_O_O_O(c__members, c__s__1822000065, c__iter__1822000064 any) { t.F_members = c__members; t.F_s__1822000065 = c__s__1822000065; t.F_iter__1822000064 = c__iter__1822000064 }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A) Invoke_O__O(self any) any { { var s__1822000065__1 any; var t_ any = t.F_s__1822000065; t.F_s__1822000065 = nil; s__1822000065__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_557 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = s__1822000065__1; if linked_558 == nil { temp__1927000414__auto____2 = ifn_559.Invoke_O__O(arg_560) } else { temp__1927000414__auto____2 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000065__3 any = temp__1927000414__auto____2; var tmp1 any; var root_561 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__1822000065__3; if linked_562 == nil { tmp1 = ifn_563.Invoke_O__O(arg_564) } else { tmp1 = linked_562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_561, arg_564) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_565 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = s__1822000065__3; if linked_566 == nil { c__1927001037__auto____4 = ifn_567.Invoke_O__O(arg_568) } else { c__1927001037__auto____4 = linked_566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_565, arg_568) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000067__6 any; var root_569 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_570 == nil { b__1822000067__6 = ifn_571.Invoke_O__O(arg_572) } else { b__1822000067__6 = linked_570.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_569, arg_572) }; var tmp2 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_New_O_O_I_O(b__1822000067__6, t.F_members, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__592 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class; if fncls__592 == nil { var fncls__592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class = fncls__592d; tmp3 = fncls__592d } else { tmp3 = fncls__592 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_593 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var root_598 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = b__1822000067__6; if linked_599 == nil { arg_596 = ifn_600.Invoke_O__O(arg_601) } else { arg_596 = linked_599.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_598, arg_601) }; var arg_597 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000064); var tmp5 any; var root_602 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__1822000065__3; if linked_603 == nil { tmp5 = ifn_604.Invoke_O__O(arg_605) } else { tmp5 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_602, arg_605) }; arg_597 = tmp4.Invoke_O__O(tmp5); if linked_594 == nil { return ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { return linked_594.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) } } else { var root_606 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_611 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = b__1822000067__6; if linked_612 == nil { arg_609 = ifn_613.Invoke_O__O(arg_614) } else { arg_609 = linked_612.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_611, arg_614) }; var arg_610 any; if linked_607 == nil { return ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { return linked_607.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) } } } else { var vec__1822000075__4 any; var root_615 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = s__1822000065__3; if linked_616 == nil { vec__1822000075__4 = ifn_617.Invoke_O__O(arg_618) } else { vec__1822000075__4 = linked_616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_615, arg_618) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000075__4, lang.RT_IntCast_J__I_NoInit(0), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000075__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_619 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = i__6; var arg_623 any = A_arbace_go_A_const_66; if linked_620 == nil { tmp6 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { tmp6 = linked_620.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_624 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any; var root_628 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = t.F_members; var arg_632 any = n__5; if linked_629 == nil { arg_627 = ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { arg_627 = linked_629.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }; if linked_625 == nil { tmp7 = ifn_626.Invoke_O__O(arg_627) } else { tmp7 = linked_625.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_624, arg_627) }; if jrt.J2g_Truth(tmp7) { var root_633 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, i__6); var arg_637 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000064); var tmp9 any; var root_638 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__1822000065__3; if linked_639 == nil { tmp9 = ifn_640.Invoke_O__O(arg_641) } else { tmp9 = linked_639.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_638, arg_641) }; arg_637 = tmp8.Invoke_O__O(tmp9); if linked_634 == nil { return ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { return linked_634.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_633, arg_636, arg_637) } } else { var tmp10 any; var root_642 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = s__1822000065__3; if linked_643 == nil { tmp10 = ifn_644.Invoke_O__O(arg_645) } else { tmp10 = linked_643.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_642, arg_645) }; s__1822000065__1 = tmp10; continue L1 } } else { var tmp11 any; var root_646 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__1822000065__3; if linked_647 == nil { tmp11 = ifn_648.Invoke_O__O(arg_649) } else { tmp11 = linked_647.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_646, arg_649) }; s__1822000065__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :151:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A) Ctor_O_O_I_O(c__b__1822000067, c__members any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000067 = c__b__1822000067; t.F_members = c__members; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :151:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A) Invoke_O__O(self any) any { { var i__1822000066__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000066__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000071__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000066__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_573 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = i__4; var arg_577 any = A_arbace_go_A_const_66; if linked_574 == nil { tmp2 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { tmp2 = linked_574.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_578 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_582 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = t.F_members; var arg_586 any = n__3; if linked_583 == nil { arg_581 = ifn_584.Invoke_O_O__O(arg_585, arg_586) } else { arg_581 = linked_583.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_582, arg_585, arg_586) }; if linked_579 == nil { tmp3 = ifn_580.Invoke_O__O(arg_581) } else { tmp3 = linked_579.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(tmp3) { var root_587 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = t.F_b__1822000067; var arg_591 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, i__4); if linked_588 == nil { ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { linked_588.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } else { i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } } else { i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__make__1822000081_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_table_ns_BANG__make__1822000081_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__make__1822000081_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :152:1
func (t *A_arbace_go_table_ns_BANG__make__1822000081_A) Ctor_O_O_O_O_O(c__ns, c__info, c__consts, c__p, c__members any) { t.F_ns = c__ns; t.F_info = c__info; t.F_consts = c__consts; t.F_p = c__p; t.F_members = c__members }
//line :152:1
func (t *A_arbace_go_table_ns_BANG__make__1822000081_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_members, n__1); if
												jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1822000082__3 any = temp__1927000408__auto____2; var kind__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000082__3, lang.RT_IntCast_J__I_NoInit(0), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000082__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_657 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_go_member_var_A_fn_class); var ifn_659 lang.IFn
													if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = t.F_ns; var arg_661 any = t.F_p; var arg_662 any = n__1; var arg_663 any = kind__4; var arg_664 any = h__5; var arg_665 any; var tmp1 any; var root_666 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = t.F_info; if linked_667 == nil { tmp1 = ifn_668.Invoke_O__O(arg_669) } else { tmp1 = linked_667.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_666, arg_669) }; arg_665 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if linked_658 == nil { return ifn_659.Invoke_O_O_O_O_O_O__O(arg_660, arg_661, arg_662, arg_663, arg_664, arg_665) } else { return linked_658.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_657, arg_660, arg_661, arg_662, arg_663, arg_664, arg_665) } } else {
//line :153:1
			var temp__1927000414__auto____3 any; var tmp2 any; var root_670 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_672 lang.IFn

			if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = t.F_consts; if linked_671 == nil { tmp2 = ifn_672.Invoke_O__O(arg_673) } else { tmp2 = linked_671.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_670, arg_673) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var root_674 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_go_member_var_A_fn_class); var ifn_676 lang.IFn
				if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = t.F_ns; var arg_678 any = t.F_p; var arg_679 any = n__1; var arg_680 any = A_arbace_go_A_const_66; var arg_681 any; var arg_682 any = i__4; if linked_675 == nil { return ifn_676.Invoke_O_O_O_O_O_O__O(arg_677, arg_678, arg_679, arg_680, arg_681, arg_682) } else { return linked_675.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_674, arg_677, arg_678, arg_679, arg_680, arg_681, arg_682) } } else {
//line :155:1
					return nil } } }

func A_arbace_go_table_ns_BANG__resolver__1822000086_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__resolver__1822000086_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__resolver__1822000086_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Ctor_O_O_O(c__make, c__consts, c__members any) { t.F_make = c__make; t.F_consts = c__consts; t.F_members = c__members }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Invoke_O_O_O__O(self, ___1, sym__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(t.F_make); var tmp2 any; var root_684 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = sym__2; if linked_685 == nil { tmp2 = ifn_686.Invoke_O__O(arg_687) } else { tmp2 = linked_685.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_684, arg_687) }; return tmp1.Invoke_O__O(tmp2) }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Invoke_O_O__O(self, ___1 any) any { { var seq_1822000087__2 any; var root_688 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_690 lang.IFn

	if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_692 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var root_696 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_701 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = t.F_members; if linked_702 == nil { arg_699 = ifn_703.Invoke_O__O(arg_704) } else { arg_699 = linked_702.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_701, arg_704) }; var arg_700 any; var root_705 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any; var root_709 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = t.F_consts; if linked_710 == nil { arg_708 = ifn_711.Invoke_O__O(arg_712) } else { arg_708 = linked_710.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_709, arg_712) }; if linked_706 == nil { arg_700 = ifn_707.Invoke_O__O(arg_708) } else { arg_700 = linked_706.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_705, arg_708) }; if linked_697 == nil { arg_695 = ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { arg_695 = linked_697.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) }; if linked_693 == nil { arg_691 = ifn_694.Invoke_O__O(arg_695) } else { arg_691 = linked_693.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_692, arg_695) }; if linked_689 == nil { seq_1822000087__2 = ifn_690.Invoke_O__O(arg_691) } else { seq_1822000087__2 = linked_689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_688, arg_691) }
//line :157:1
	var chunk_1822000088__3 any; var count_1822000089__4 int64 = 0; var i_1822000090__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000090__5, count_1822000089__4) { var n__6 any = lang.Indexed_Cast(chunk_1822000088__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000090__5))
			lang.IFn_Cast(t.F_make).Invoke_O__O(n__6)
//line :159:1
			seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000090__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_713 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_1822000087__2; if linked_714 == nil { temp__1927000414__auto____6 = ifn_715.Invoke_O__O(arg_716) } else { temp__1927000414__auto____6 = linked_714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_713, arg_716) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1822000087__7 any = temp__1927000414__auto____6; var tmp1 any; var root_717 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1822000087__7; if linked_718 == nil { tmp1 = ifn_719.Invoke_O__O(arg_720) } else { tmp1 = linked_718.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_721 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seq_1822000087__7; if linked_722 == nil { c__1927000678__auto____8 = ifn_723.Invoke_O__O(arg_724) } else { c__1927000678__auto____8 = linked_722.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_721, arg_724) }; var tmp2 any; var root_729 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1822000087__7; if linked_730 == nil { tmp2 = ifn_731.Invoke_O__O(arg_732) } else { tmp2 = linked_730.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_729, arg_732) }; seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_725 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1822000087__7; if linked_726 == nil { n__8 = ifn_727.Invoke_O__O(arg_728) } else { n__8 = linked_726.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_725, arg_728) }
				lang.IFn_Cast(t.F_make).Invoke_O__O(n__8)
//line :159:1
				var tmp3 any; var root_733 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_1822000087__7; if linked_734 == nil { tmp3 = ifn_735.Invoke_O__O(arg_736) } else { tmp3 = linked_734.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_733, arg_736) }; seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :157:1*/panic("j2g: unreachable") }








func A_arbace_go_packages_A_New() *A_arbace_go_packages_A { A_arbace_go_A_Init(); t := &A_arbace_go_packages_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_go_packages_A) Ctor() {}
//line :166:1
func (t *A_arbace_go_packages_A) Invoke_O__O(self any) any {


	var root_738 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.GoInterp_Paths__O1().Ref(); if linked_739 == nil { return ifn_740.Invoke_O__O(arg_741) } else { return linked_739.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_738, arg_741)
	}
}


func A_arbace_go_new_A_New() *A_arbace_go_new_A { A_arbace_go_A_Init(); t := &A_arbace_go_new_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_new_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_new_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_NewValue_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_zero_A_New() *A_arbace_go_zero_A { A_arbace_go_A_Init(); t := &A_arbace_go_zero_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_go_zero_A) Ctor() {}
//line :179:1
func (t *A_arbace_go_zero_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_Zero_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_type_of_A_New() *A_arbace_go_type_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_of_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_type_of_A) Ctor() {}
//line :184:1
func (t *A_arbace_go_type_of_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_TypeOf_O__O(v__0)
}
func A_arbace_go_str_A_New() *A_arbace_go_str_A { A_arbace_go_A_Init(); t := &A_arbace_go_str_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_go_str_A) Ctor() {}
//line :189:1
func (t *A_arbace_go_str_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_Str_O__String(v__0).Ref()
}
func A_arbace_go_spread_A_New() *A_arbace_go_spread_A { A_arbace_go_A_Init(); t := &A_arbace_go_spread_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_go_spread_A) Ctor() {}
//line :194:1
func (t *A_arbace_go_spread_A) Invoke_O_O__O(self, xs__0 any) any {



	return lang.GoInterp_Spread_O__O(xs__0)
}
func A_arbace_go_assign_BANG__A_New() *A_arbace_go_assign_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_assign_BANG__A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_go_assign_BANG__A) Ctor() {}
//line :200:1
func (t *A_arbace_go_assign_BANG__A) Invoke_O_O_O__O(self, v__0, x__1 any) any {



	lang.GoInterp_Store_O_O__V(lang.GoVar_Cast(v__0).F_cell, x__1)
//line :200:1
	return x__1
}








func A_arbace_go_repl_fn_A_New() *A_arbace_go_repl_fn_A { A_arbace_go_A_Init(); t := &A_arbace_go_repl_fn_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_go_repl_fn_A) Ctor() {}
//line :210:1
func (t *A_arbace_go_repl_fn_A) Invoke_O_O__O(self, nm__0 any) any { var root_742 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var root_746 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = Lit_39; var arg_750 any = nm__0; if linked_747 == nil { arg_745 = ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { arg_745 = linked_747.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) }; if linked_743 == nil { return ifn_744.Invoke_O__O(arg_745) } else { return linked_743.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_742, arg_745) } }

func A_arbace_go_pos_of_A_New() *A_arbace_go_pos_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_pos_of_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_pos_of_A) Ctor() {}
//line :212:1
func (t *A_arbace_go_pos_of_A) Invoke_O_O__O(self, form__0 any) any { var root_751 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__0); var arg_755 any = A_arbace_go_A_const_101; if linked_752 == nil { return ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { return linked_752.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_751, arg_754, arg_755) } }

func A_arbace_go_package_A_New() *A_arbace_go_package_A { A_arbace_go_A_Init(); t := &A_arbace_go_package_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_package_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_package_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_756 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_767 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any; var root_771 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_102); var arg_775 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_29); if linked_772 == nil { arg_770 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { arg_770 = linked_772.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }; if linked_768 == nil { tmp3 = ifn_769.Invoke_O__O(arg_770) } else { tmp3 = linked_768.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_767, arg_770) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_776 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var root_780 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_784 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_785 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_787 lang.IFn; if


	linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = A_arbace_go_A_const_105.Get__O(); if linked_786 == nil { tmp8 = ifn_787.Invoke_O__O(arg_788) } else { tmp8 = linked_786.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_785, arg_788) }; arg_784 = /*line :214:1*/tmp7.Invoke_O__O(tmp8); if linked_781 == nil { arg_779 = ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { arg_779 = linked_781.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_780, arg_783, arg_784) }; if linked_777 == nil { tmp6 = ifn_778.Invoke_O__O(arg_779) } else { tmp6 = linked_777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_776, arg_779) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_789 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_793 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_797 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(nm__2); if linked_794 == nil { arg_792 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { arg_792 = linked_794.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if linked_790 == nil { tmp11 = ifn_791.Invoke_O__O(arg_792) } else { tmp11 = linked_790.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_789, arg_792) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp14 any; var root_798 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_802 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_806 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp16 any; var root_807 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_809 lang.IFn; if


	linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = opts__3; if linked_808 == nil { tmp16 = ifn_809.Invoke_O__O(arg_810) } else { tmp16 = linked_808.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_807, arg_810) }; arg_806 = /*line :214:1*/tmp15.Invoke_O__O(tmp16); if linked_803 == nil { arg_801 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; if linked_799 == nil { tmp14 = ifn_800.Invoke_O__O(arg_801) } else { tmp14 = linked_799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_798, arg_801) }; arg_759 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_757 == nil { return ifn_758.Invoke_O__O(arg_759) } else { return linked_757.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_756, arg_759) } }




func A_arbace_go_file_A_New() *A_arbace_go_file_A { A_arbace_go_A_Init(); t := &A_arbace_go_file_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_go_file_A) Ctor() {}
//line :219:1
func (t *A_arbace_go_file_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_811 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_822 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any; var root_826 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_106); var arg_830 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_25); if linked_827 == nil { arg_825 = ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { arg_825 = linked_827.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_826, arg_829, arg_830) }; if linked_823 == nil { tmp3 = ifn_824.Invoke_O__O(arg_825) } else { tmp3 = linked_823.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_822, arg_825) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_831 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var root_835 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_839 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_840 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_842 lang.IFn; if


	linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = A_arbace_go_A_const_105.Get__O(); if linked_841 == nil { tmp8 = ifn_842.Invoke_O__O(arg_843) } else { tmp8 = linked_841.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_840, arg_843) }; arg_839 = /*line :219:1*/tmp7.Invoke_O__O(tmp8); if linked_836 == nil { arg_834 = ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { arg_834 = linked_836.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) }; if linked_832 == nil { tmp6 = ifn_833.Invoke_O__O(arg_834) } else { tmp6 = linked_832.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_831, arg_834) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(nm__2); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp12 any; var root_844 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any; var root_848 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_852 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp14 any; var root_853 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_855 lang.IFn; if


	linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = A_arbace_go_A_const_31.GetRawRoot__O(); var arg_857 any = opts__3; if linked_854 == nil { tmp14 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { tmp14 = linked_854.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; arg_852 = /*line :219:1*/tmp13.Invoke_O__O(tmp14); if linked_849 == nil { arg_847 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { arg_847 = linked_849.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; if linked_845 == nil { tmp12 = ifn_846.Invoke_O__O(arg_847) } else { tmp12 = linked_845.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_844, arg_847) }; arg_814 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_812 == nil { return ifn_813.Invoke_O__O(arg_814) } else { return linked_812.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_811, arg_814) } }




func A_arbace_go_declare_STAR__A_New() *A_arbace_go_declare_STAR__A { A_arbace_go_A_Init(); t := &A_arbace_go_declare_STAR__A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_declare_STAR__A) Ctor() {}
//line :224:1
func (t *A_arbace_go_declare_STAR__A) Invoke_O_O_O__O(self, form__0, opts__1 any) any {


	var tmp1 any; var root_858 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, A_arbace_go_repl_fn_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = Lit_8; if linked_859 == nil { tmp1 = ifn_860.Invoke_O__O(arg_861) } else { tmp1 = linked_859.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_858, arg_861) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(form__0, opts__1)
}
func A_arbace_go_func_A_New() *A_arbace_go_func_A { A_arbace_go_A_Init(); t := &A_arbace_go_func_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_func_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_func_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_862 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_108); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_872 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any; var root_876 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_880 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_877 == nil { arg_875 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { arg_875 = linked_877.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; if linked_873 == nil { tmp4 = ifn_874.Invoke_O__O(arg_875) } else { tmp4 = linked_873.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_872, arg_875) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_881 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_885 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_889 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_890 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_892 lang.IFn; if
														linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any; var root_896 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, A_arbace_go_pos_of_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = _AMPERSAND_form__0; if linked_897 == nil { arg_893 = ifn_898.Invoke_O__O(arg_899) } else { arg_893 = linked_897.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_896, arg_899) }; var arg_894 any = A_arbace_go_A_const_110; var arg_895 any; var root_900 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = A_arbace_go_A_const_105.Get__O(); if linked_901 == nil { arg_895 = ifn_902.Invoke_O__O(arg_903) } else { arg_895 = linked_901.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_900, arg_903) }; if linked_891 == nil { tmp9 = ifn_892.Invoke_O_O_O__O(arg_893, arg_894, arg_895) } else { tmp9 = linked_891.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_890, arg_893, arg_894, arg_895) }; arg_889 = /*line :229:1*/tmp8.Invoke_O__O(tmp9); if linked_886 == nil { arg_884 = ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { arg_884 = linked_886.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_885, arg_888, arg_889) }; if linked_882 == nil { tmp7 = ifn_883.Invoke_O__O(arg_884) } else { tmp7 = linked_882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_881, arg_884) }; arg_865 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_863 == nil { return ifn_864.Invoke_O__O(arg_865) } else { return linked_863.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_862, arg_865) } }


func A_arbace_go_method_A_New() *A_arbace_go_method_A { A_arbace_go_A_Init(); t := &A_arbace_go_method_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_go_method_A) Ctor() {}
//line :232:1
func (t *A_arbace_go_method_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_904 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_111); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_914 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var root_918 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_922 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_919 == nil { arg_917 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { arg_917 = linked_919.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if linked_915 == nil { tmp4 = ifn_916.Invoke_O__O(arg_917) } else { tmp4 = linked_915.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_914, arg_917) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_923 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; var root_927 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_931 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_932 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_934 lang.IFn; if
														linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var root_938 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_go_pos_of_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = _AMPERSAND_form__0; if linked_939 == nil { arg_935 = ifn_940.Invoke_O__O(arg_941) } else { arg_935 = linked_939.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_938, arg_941) }; var arg_936 any = A_arbace_go_A_const_110; var arg_937 any; var root_942 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = A_arbace_go_A_const_105.Get__O(); if linked_943 == nil { arg_937 = ifn_944.Invoke_O__O(arg_945) } else { arg_937 = linked_943.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_942, arg_945) }; if linked_933 == nil { tmp9 = ifn_934.Invoke_O_O_O__O(arg_935, arg_936, arg_937) } else { tmp9 = linked_933.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_932, arg_935, arg_936, arg_937) }; arg_931 = /*line :232:1*/tmp8.Invoke_O__O(tmp9); if linked_928 == nil { arg_926 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { arg_926 = linked_928.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; if linked_924 == nil { tmp7 = ifn_925.Invoke_O__O(arg_926) } else { tmp7 = linked_924.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_923, arg_926) }; arg_907 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_905 == nil { return ifn_906.Invoke_O__O(arg_907) } else { return linked_905.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_904, arg_907) } }


func A_arbace_go_type_A_New() *A_arbace_go_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_go_type_A) Ctor() {}
//line :235:1
func (t *A_arbace_go_type_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_946 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_956 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var root_960 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_964 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_961 == nil { arg_959 = ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { arg_959 = linked_961.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) }; if linked_957 == nil { tmp4 = ifn_958.Invoke_O__O(arg_959) } else { tmp4 = linked_957.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_956, arg_959) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_965 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any; var root_969 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_973 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_974 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_976 lang.IFn; if
														linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any; var root_980 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_go_pos_of_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = _AMPERSAND_form__0; if linked_981 == nil { arg_977 = ifn_982.Invoke_O__O(arg_983) } else { arg_977 = linked_981.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_980, arg_983) }; var arg_978 any = A_arbace_go_A_const_110; var arg_979 any; var root_984 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = A_arbace_go_A_const_105.Get__O(); if linked_985 == nil { arg_979 = ifn_986.Invoke_O__O(arg_987) } else { arg_979 = linked_985.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_984, arg_987) }; if linked_975 == nil { tmp9 = ifn_976.Invoke_O_O_O__O(arg_977, arg_978, arg_979) } else { tmp9 = linked_975.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_974, arg_977, arg_978, arg_979) }; arg_973 = /*line :235:1*/tmp8.Invoke_O__O(tmp9); if linked_970 == nil { arg_968 = ifn_971.Invoke_O_O__O(arg_972, arg_973) } else { arg_968 = linked_970.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_969, arg_972, arg_973) }; if linked_966 == nil { tmp7 = ifn_967.Invoke_O__O(arg_968) } else { tmp7 = linked_966.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_965, arg_968) }; arg_949 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_947 == nil { return ifn_948.Invoke_O__O(arg_949) } else { return linked_947.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_946, arg_949) } }


func A_arbace_go_var_A_New() *A_arbace_go_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_var_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_go_var_A) Ctor() {}
//line :238:1
func (t *A_arbace_go_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_988 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_113); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_998 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any; var root_1002 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1006 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1003 == nil { arg_1001 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { arg_1001 = linked_1003.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; if linked_999 == nil { tmp4 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp4 = linked_999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_998, arg_1001) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1007 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any; var root_1011 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1015 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1016 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1018 lang.IFn; if
														linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any; var root_1022 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_pos_of_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = _AMPERSAND_form__0; if linked_1023 == nil { arg_1019 = ifn_1024.Invoke_O__O(arg_1025) } else { arg_1019 = linked_1023.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1022, arg_1025) }; var arg_1020 any = A_arbace_go_A_const_110; var arg_1021 any; var root_1026 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_go_A_const_105.Get__O(); if linked_1027 == nil { arg_1021 = ifn_1028.Invoke_O__O(arg_1029) } else { arg_1021 = linked_1027.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1026, arg_1029) }; if linked_1017 == nil { tmp9 = ifn_1018.Invoke_O_O_O__O(arg_1019, arg_1020, arg_1021) } else { tmp9 = linked_1017.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1016, arg_1019, arg_1020, arg_1021) }; arg_1015 = /*line :238:1*/tmp8.Invoke_O__O(tmp9); if linked_1012 == nil { arg_1010 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { arg_1010 = linked_1012.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) }; if linked_1008 == nil { tmp7 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp7 = linked_1008.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1007, arg_1010) }; arg_991 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_989 == nil { return ifn_990.Invoke_O__O(arg_991) } else { return linked_989.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_988, arg_991) } }


func A_arbace_go_const_A_New() *A_arbace_go_const_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_const_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_const_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1030 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_114); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1040 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var root_1044 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1048 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1045 == nil { arg_1043 = ifn_1046.Invoke_O_O__O(arg_1047, arg_1048) } else { arg_1043 = linked_1045.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1044, arg_1047, arg_1048) }; if linked_1041 == nil { tmp4 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp4 = linked_1041.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1040, arg_1043) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1049 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any; var root_1053 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1057 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1058 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1060 lang.IFn; if
														linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var root_1064 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_go_pos_of_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = _AMPERSAND_form__0; if linked_1065 == nil { arg_1061 = ifn_1066.Invoke_O__O(arg_1067) } else { arg_1061 = linked_1065.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1064, arg_1067) }; var arg_1062 any = A_arbace_go_A_const_110; var arg_1063 any; var root_1068 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = A_arbace_go_A_const_105.Get__O(); if linked_1069 == nil { arg_1063 = ifn_1070.Invoke_O__O(arg_1071) } else { arg_1063 = linked_1069.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1068, arg_1071) }; if linked_1059 == nil { tmp9 = ifn_1060.Invoke_O_O_O__O(arg_1061, arg_1062, arg_1063) } else { tmp9 = linked_1059.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063) }; arg_1057 = /*line :241:1*/tmp8.Invoke_O__O(tmp9); if linked_1054 == nil { arg_1052 = ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { arg_1052 = linked_1054.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) }; if linked_1050 == nil { tmp7 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp7 = linked_1050.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1049, arg_1052) }; arg_1033 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1031 == nil { return ifn_1032.Invoke_O__O(arg_1033) } else { return linked_1031.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1030, arg_1033) } }


func A_arbace_go_directive_A_New() *A_arbace_go_directive_A { A_arbace_go_A_Init(); t := &A_arbace_go_directive_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_directive_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_go_import_A_New() *A_arbace_go_import_A { A_arbace_go_A_Init(); t := &A_arbace_go_import_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_import_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_import_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, specs__2 any) any { var root_1072 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_1082 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any; var root_1086 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_115); var arg_1090 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_27); if linked_1087 == nil { arg_1085 = ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { arg_1085 = linked_1087.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090) }; if linked_1083 == nil { tmp3 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp3 = linked_1083.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1082, arg_1085) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_1091 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1095 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1099 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_1100 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1102 lang.IFn; if


	linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = A_arbace_go_A_const_105.Get__O(); if linked_1101 == nil { tmp8 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp8 = linked_1101.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1100, arg_1103) }; arg_1099 = /*line :246:1*/tmp7.Invoke_O__O(tmp8); if linked_1096 == nil { arg_1094 = ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { arg_1094 = linked_1096.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099) }; if linked_1092 == nil { tmp6 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp6 = linked_1092.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1091, arg_1094) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_1104 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any; var root_1108 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1112 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp13 any; var root_1113 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1115 lang.IFn; if


	linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = specs__2; if linked_1114 == nil { tmp13 = ifn_1115.Invoke_O__O(arg_1116) } else { tmp13 = linked_1114.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1113, arg_1116) }; arg_1112 = /*line :246:1*/tmp12.Invoke_O__O(tmp13); if linked_1109 == nil { arg_1107 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { arg_1107 = linked_1109.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }; if linked_1105 == nil { tmp11 = ifn_1106.Invoke_O__O(arg_1107) } else { tmp11 = linked_1105.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1104, arg_1107) }; arg_1075 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1073 == nil { return ifn_1074.Invoke_O__O(arg_1075) } else { return linked_1073.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1072, arg_1075) } }




func A_arbace_go_eval_A_New() *A_arbace_go_eval_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_go_eval_A) Ctor() {}
//line :251:1
func (t *A_arbace_go_eval_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, stmts__2 any) any { var root_1117 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_1127 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var root_1131 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_116); var arg_1135 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_17); if linked_1132 == nil { arg_1130 = ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { arg_1130 = linked_1132.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) }; if linked_1128 == nil { tmp3 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp3 = linked_1128.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1127, arg_1130) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_1136 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var root_1140 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1144 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_1145 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1147 lang.IFn; if



	linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = stmts__2; if linked_1146 == nil { tmp8 = ifn_1147.Invoke_O__O(arg_1148) } else { tmp8 = linked_1146.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1145, arg_1148) }; arg_1144 = /*line :251:1*/tmp7.Invoke_O__O(tmp8); if linked_1141 == nil { arg_1139 = ifn_1142.Invoke_O_O__O(arg_1143, arg_1144) } else { arg_1139 = linked_1141.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1140, arg_1143, arg_1144) }; if linked_1137 == nil { tmp6 = ifn_1138.Invoke_O__O(arg_1139) } else { tmp6 = linked_1137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1136, arg_1139) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_1149 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any; var root_1153 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_103); var arg_1157 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp13 any = A_arbace_go_A_const_110; var tmp14 any; var root_1158 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1160 lang.IFn; if



	linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = A_arbace_go_A_const_105.Get__O(); if linked_1159 == nil { tmp14 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp14 = linked_1159.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1158, arg_1161) }; arg_1157 = /*line :251:1*/tmp12.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14))); if linked_1154 == nil { arg_1152 = ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { arg_1152 = linked_1154.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) }; if linked_1150 == nil { tmp11 = ifn_1151.Invoke_O__O(arg_1152) } else { tmp11 = linked_1150.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1149, arg_1152) }; arg_1120 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1118 == nil { return ifn_1119.Invoke_O__O(arg_1120) } else { return linked_1118.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1117, arg_1120) } }





func A_arbace_go_run_main_A_New() *A_arbace_go_run_main_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_main_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_run_main_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_run_main_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1162 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, A_arbace_go_repl_fn_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = Lit_40; if linked_1163 == nil { tmp1 = ifn_1164.Invoke_O__O(arg_1165) } else { tmp1 = linked_1163.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1162, arg_1165) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1166 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_go_repl_fn_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = Lit_1; if linked_1167 == nil { tmp1 = ifn_1168.Invoke_O__O(arg_1169) } else { tmp1 = linked_1167.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1166, arg_1169) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}














































































type A_arbace_go_A struct{ jrt.Object }

var A_arbace_go_A_const_pool *jrt.RefArray

var A_arbace_go_A_const_0 *lang.Var

var A_arbace_go_A_const_1 any

var A_arbace_go_A_const_2 *lang.Keyword

var A_arbace_go_A_const_3 any

var A_arbace_go_A_const_4 *lang.Var

var A_arbace_go_A_const_5 *lang.Var

var A_arbace_go_A_const_6 *lang.Var

var A_arbace_go_A_const_7 *lang.Var

var A_arbace_go_A_const_8 any

var A_arbace_go_A_const_9 *lang.Var

var A_arbace_go_A_const_10 *lang.Var

var A_arbace_go_A_const_11 *lang.Var

var A_arbace_go_A_const_12 *lang.Var

var A_arbace_go_A_const_13 *lang.Var

var A_arbace_go_A_const_14 *jrt.Class

var A_arbace_go_A_const_15 *lang.Keyword

var A_arbace_go_A_const_16 *lang.Var

var A_arbace_go_A_const_17 *lang.Var

var A_arbace_go_A_const_18 any

var A_arbace_go_A_const_19 *lang.Keyword

var A_arbace_go_A_const_20 *lang.Keyword

var A_arbace_go_A_const_21 *lang.Var

var A_arbace_go_A_const_22 *lang.Var

var A_arbace_go_A_const_23 *lang.Var

var A_arbace_go_A_const_24 *lang.Var

var A_arbace_go_A_const_25 *lang.Var

var A_arbace_go_A_const_26 *lang.Var

var A_arbace_go_A_const_27 any

var A_arbace_go_A_const_28 *lang.Keyword

var A_arbace_go_A_const_29 *lang.Var

var A_arbace_go_A_const_30 *lang.Var

var A_arbace_go_A_const_31 *lang.Var

var A_arbace_go_A_const_32 *lang.Var

var A_arbace_go_A_const_33 *lang.Var

var A_arbace_go_A_const_34 *lang.Var

var A_arbace_go_A_const_35 any

var A_arbace_go_A_const_36 any

var A_arbace_go_A_const_37 *lang.Var

var A_arbace_go_A_const_38 *lang.Keyword

var A_arbace_go_A_const_39 *lang.Var

var A_arbace_go_A_const_40 any

var A_arbace_go_A_const_41 *lang.Var

var A_arbace_go_A_const_42 *lang.Keyword

var A_arbace_go_A_const_43 *lang.Var

var A_arbace_go_A_const_44 *lang.Var

var A_arbace_go_A_const_45 *lang.Var

var A_arbace_go_A_const_46 *lang.Var

var A_arbace_go_A_const_47 *lang.Var

var A_arbace_go_A_const_48 *lang.Var

var A_arbace_go_A_const_49 *lang.Var

var A_arbace_go_A_const_50 any

var A_arbace_go_A_const_51 *lang.Var

var A_arbace_go_A_const_52 *lang.Var

var A_arbace_go_A_const_53 *lang.Var

var A_arbace_go_A_const_54 *lang.Var

var A_arbace_go_A_const_55 *lang.Var

var A_arbace_go_A_const_56 *lang.Var

var A_arbace_go_A_const_57 *lang.Var

var A_arbace_go_A_const_58 *lang.Var

var A_arbace_go_A_const_59 any

var A_arbace_go_A_const_60 *lang.Keyword

var A_arbace_go_A_const_61 *lang.Var

var A_arbace_go_A_const_62 *lang.Keyword

var A_arbace_go_A_const_63 *lang.Keyword

var A_arbace_go_A_const_64 *lang.Var

var A_arbace_go_A_const_65 *lang.Var

var A_arbace_go_A_const_66 *lang.Keyword

var A_arbace_go_A_const_67 *lang.Var

var A_arbace_go_A_const_68 *lang.Keyword

var A_arbace_go_A_const_69 *lang.Keyword

var A_arbace_go_A_const_70 *lang.Var

var A_arbace_go_A_const_71 *lang.Keyword

var A_arbace_go_A_const_72 *lang.Keyword

var A_arbace_go_A_const_73 *lang.Var

var A_arbace_go_A_const_74 *lang.Var

var A_arbace_go_A_const_75 *lang.Keyword

var A_arbace_go_A_const_76 *lang.Keyword

var A_arbace_go_A_const_77 *lang.Keyword

var A_arbace_go_A_const_78 *lang.Keyword

var A_arbace_go_A_const_79 *lang.Var

var A_arbace_go_A_const_80 *lang.Var

var A_arbace_go_A_const_81 *lang.Var

var A_arbace_go_A_const_82 *lang.Var

var A_arbace_go_A_const_83 *lang.Var

var A_arbace_go_A_const_84 *lang.Var

var A_arbace_go_A_const_85 *lang.Var

var A_arbace_go_A_const_86 *lang.Var

var A_arbace_go_A_const_87 *lang.Var

var A_arbace_go_A_const_88 *lang.Var

var A_arbace_go_A_const_89 *lang.Var

var A_arbace_go_A_const_90 *lang.Var

var A_arbace_go_A_const_91 *lang.Var

var A_arbace_go_A_const_92 any

var A_arbace_go_A_const_93 *lang.Var

var A_arbace_go_A_const_94 *lang.Var

var A_arbace_go_A_const_95 *lang.Var

var A_arbace_go_A_const_96 *lang.Var

var A_arbace_go_A_const_97 *lang.Var

var A_arbace_go_A_const_98 *lang.Var

var A_arbace_go_A_const_99 *lang.Var

var A_arbace_go_A_const_100 *lang.Var

var A_arbace_go_A_const_101 any

var A_arbace_go_A_const_102 any

var A_arbace_go_A_const_103 any

var A_arbace_go_A_const_104 *lang.Var

var A_arbace_go_A_const_105 *lang.Var

var A_arbace_go_A_const_106 any

var A_arbace_go_A_const_107 *lang.Var

var A_arbace_go_A_const_108 any

var A_arbace_go_A_const_109 *lang.Var

var A_arbace_go_A_const_110 *lang.Keyword

var A_arbace_go_A_const_111 any

var A_arbace_go_A_const_112 any

var A_arbace_go_A_const_113 any

var A_arbace_go_A_const_114 any

var A_arbace_go_A_const_115 any

var A_arbace_go_A_const_116 any

var A_arbace_go_A_init jrt.ClassInit

func A_arbace_go_A_Init() { if !A_arbace_go_A_init.Done() { A_arbace_go_A_init.Run(A_arbace_go_A_clinit) } }

func A_arbace_go_A_clinit() { A_arbace_go_A_clinit_p0(); A_arbace_go_A_clinit_p1(); A_arbace_go_A_clinit_p2(); A_arbace_go_A_clinit_p3(); A_arbace_go_A_clinit_p4(); A_arbace_go_A_clinit_p5(); A_arbace_go_A_clinit_p6(); A_arbace_go_A_clinit_p7(); A_arbace_go_A_clinit_p8(); A_arbace_go_A_clinit_p9() }

func A_arbace_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 152); A_arbace_go_A_const_0 = lang.Var_Cast(A_arbace_go_A_const_pool.A[35]); A_arbace_go_A_const_1 = A_arbace_go_A_const_pool.A[36]; A_arbace_go_A_const_2 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[37]); A_arbace_go_A_const_3 = A_arbace_go_A_const_pool.A[38]; A_arbace_go_A_const_4 = lang.Var_Cast(A_arbace_go_A_const_pool.A[39]); A_arbace_go_A_const_5 = lang.Var_Cast(A_arbace_go_A_const_pool.A[40]); A_arbace_go_A_const_6 = lang.Var_Cast(A_arbace_go_A_const_pool.A[41]); A_arbace_go_A_const_7 = lang.Var_Cast(A_arbace_go_A_const_pool.A[42]); A_arbace_go_A_const_8 = A_arbace_go_A_const_pool.A[43]; A_arbace_go_A_const_9 = lang.Var_Cast(A_arbace_go_A_const_pool.A[44]); A_arbace_go_A_const_10 = lang.Var_Cast(A_arbace_go_A_const_pool.A[45]); A_arbace_go_A_const_11 = lang.Var_Cast(A_arbace_go_A_const_pool.A[46]) }

func A_arbace_go_A_clinit_p1() { A_arbace_go_A_const_12 = lang.Var_Cast(A_arbace_go_A_const_pool.A[47]); A_arbace_go_A_const_13 = lang.Var_Cast(A_arbace_go_A_const_pool.A[48]); A_arbace_go_A_const_14 = jrt.Class_Cast(A_arbace_go_A_const_pool.A[49]); A_arbace_go_A_const_15 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[50]); A_arbace_go_A_const_16 = lang.Var_Cast(A_arbace_go_A_const_pool.A[51]); A_arbace_go_A_const_17 = lang.Var_Cast(A_arbace_go_A_const_pool.A[52]); A_arbace_go_A_const_18 = A_arbace_go_A_const_pool.A[53]; A_arbace_go_A_const_19 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[54]); A_arbace_go_A_const_20 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[55]); A_arbace_go_A_const_21 = lang.Var_Cast(A_arbace_go_A_const_pool.A[56]); A_arbace_go_A_const_22 = lang.Var_Cast(A_arbace_go_A_const_pool.A[57]); A_arbace_go_A_const_23 = lang.Var_Cast(A_arbace_go_A_const_pool.A[58]) }

func A_arbace_go_A_clinit_p2() { A_arbace_go_A_const_24 = lang.Var_Cast(A_arbace_go_A_const_pool.A[59]); A_arbace_go_A_const_25 = lang.Var_Cast(A_arbace_go_A_const_pool.A[60]); A_arbace_go_A_const_26 = lang.Var_Cast(A_arbace_go_A_const_pool.A[61]); A_arbace_go_A_const_27 = A_arbace_go_A_const_pool.A[62]; A_arbace_go_A_const_28 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[63]); A_arbace_go_A_const_29 = lang.Var_Cast(A_arbace_go_A_const_pool.A[64]); A_arbace_go_A_const_30 = lang.Var_Cast(A_arbace_go_A_const_pool.A[65]); A_arbace_go_A_const_31 = lang.Var_Cast(A_arbace_go_A_const_pool.A[66]); A_arbace_go_A_const_32 = lang.Var_Cast(A_arbace_go_A_const_pool.A[67]); A_arbace_go_A_const_33 = lang.Var_Cast(A_arbace_go_A_const_pool.A[68]); A_arbace_go_A_const_34 = lang.Var_Cast(A_arbace_go_A_const_pool.A[69]); A_arbace_go_A_const_35 = A_arbace_go_A_const_pool.A[70] }

func A_arbace_go_A_clinit_p3() { A_arbace_go_A_const_36 = A_arbace_go_A_const_pool.A[71]; A_arbace_go_A_const_37 = lang.Var_Cast(A_arbace_go_A_const_pool.A[72]); A_arbace_go_A_const_38 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[73]); A_arbace_go_A_const_39 = lang.Var_Cast(A_arbace_go_A_const_pool.A[74]); A_arbace_go_A_const_40 = A_arbace_go_A_const_pool.A[75]; A_arbace_go_A_const_41 = lang.Var_Cast(A_arbace_go_A_const_pool.A[76]); A_arbace_go_A_const_42 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[77]); A_arbace_go_A_const_43 = lang.Var_Cast(A_arbace_go_A_const_pool.A[78]); A_arbace_go_A_const_44 = lang.Var_Cast(A_arbace_go_A_const_pool.A[79]); A_arbace_go_A_const_45 = lang.Var_Cast(A_arbace_go_A_const_pool.A[80]); A_arbace_go_A_const_46 = lang.Var_Cast(A_arbace_go_A_const_pool.A[81]); A_arbace_go_A_const_47 = lang.Var_Cast(A_arbace_go_A_const_pool.A[82]) }

func A_arbace_go_A_clinit_p4() { A_arbace_go_A_const_48 = lang.Var_Cast(A_arbace_go_A_const_pool.A[83]); A_arbace_go_A_const_49 = lang.Var_Cast(A_arbace_go_A_const_pool.A[84]); A_arbace_go_A_const_50 = A_arbace_go_A_const_pool.A[85]; A_arbace_go_A_const_51 = lang.Var_Cast(A_arbace_go_A_const_pool.A[86]); A_arbace_go_A_const_52 = lang.Var_Cast(A_arbace_go_A_const_pool.A[87]); A_arbace_go_A_const_53 = lang.Var_Cast(A_arbace_go_A_const_pool.A[88]); A_arbace_go_A_const_54 = lang.Var_Cast(A_arbace_go_A_const_pool.A[89]); A_arbace_go_A_const_55 = lang.Var_Cast(A_arbace_go_A_const_pool.A[90]); A_arbace_go_A_const_56 = lang.Var_Cast(A_arbace_go_A_const_pool.A[91]); A_arbace_go_A_const_57 = lang.Var_Cast(A_arbace_go_A_const_pool.A[92]); A_arbace_go_A_const_58 = lang.Var_Cast(A_arbace_go_A_const_pool.A[93]); A_arbace_go_A_const_59 = A_arbace_go_A_const_pool.A[94] }

func A_arbace_go_A_clinit_p5() { A_arbace_go_A_const_60 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[95]); A_arbace_go_A_const_61 = lang.Var_Cast(A_arbace_go_A_const_pool.A[96]); A_arbace_go_A_const_62 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[97]); A_arbace_go_A_const_63 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[98]); A_arbace_go_A_const_64 = lang.Var_Cast(A_arbace_go_A_const_pool.A[99]); A_arbace_go_A_const_65 = lang.Var_Cast(A_arbace_go_A_const_pool.A[100]); A_arbace_go_A_const_66 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[101]); A_arbace_go_A_const_67 = lang.Var_Cast(A_arbace_go_A_const_pool.A[102]); A_arbace_go_A_const_68 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[103]); A_arbace_go_A_const_69 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[104]); A_arbace_go_A_const_70 = lang.Var_Cast(A_arbace_go_A_const_pool.A[105]); A_arbace_go_A_const_71 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[106]) }

func A_arbace_go_A_clinit_p6() { A_arbace_go_A_const_72 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[107]); A_arbace_go_A_const_73 = lang.Var_Cast(A_arbace_go_A_const_pool.A[108]); A_arbace_go_A_const_74 = lang.Var_Cast(A_arbace_go_A_const_pool.A[109]); A_arbace_go_A_const_75 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[110]); A_arbace_go_A_const_76 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[111]); A_arbace_go_A_const_77 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[112]); A_arbace_go_A_const_78 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[113]); A_arbace_go_A_const_79 = lang.Var_Cast(A_arbace_go_A_const_pool.A[114]); A_arbace_go_A_const_80 = lang.Var_Cast(A_arbace_go_A_const_pool.A[115]); A_arbace_go_A_const_81 = lang.Var_Cast(A_arbace_go_A_const_pool.A[116]); A_arbace_go_A_const_82 = lang.Var_Cast(A_arbace_go_A_const_pool.A[117]); A_arbace_go_A_const_83 = lang.Var_Cast(A_arbace_go_A_const_pool.A[118]) }

func A_arbace_go_A_clinit_p7() { A_arbace_go_A_const_84 = lang.Var_Cast(A_arbace_go_A_const_pool.A[119]); A_arbace_go_A_const_85 = lang.Var_Cast(A_arbace_go_A_const_pool.A[120]); A_arbace_go_A_const_86 = lang.Var_Cast(A_arbace_go_A_const_pool.A[121]); A_arbace_go_A_const_87 = lang.Var_Cast(A_arbace_go_A_const_pool.A[122]); A_arbace_go_A_const_88 = lang.Var_Cast(A_arbace_go_A_const_pool.A[123]); A_arbace_go_A_const_89 = lang.Var_Cast(A_arbace_go_A_const_pool.A[124]); A_arbace_go_A_const_90 = lang.Var_Cast(A_arbace_go_A_const_pool.A[125]); A_arbace_go_A_const_91 = lang.Var_Cast(A_arbace_go_A_const_pool.A[126]); A_arbace_go_A_const_92 = A_arbace_go_A_const_pool.A[127]; A_arbace_go_A_const_93 = lang.Var_Cast(A_arbace_go_A_const_pool.A[128]); A_arbace_go_A_const_94 = lang.Var_Cast(A_arbace_go_A_const_pool.A[129]); A_arbace_go_A_const_95 = lang.Var_Cast(A_arbace_go_A_const_pool.A[130]) }

func A_arbace_go_A_clinit_p8() { A_arbace_go_A_const_96 = lang.Var_Cast(A_arbace_go_A_const_pool.A[131]); A_arbace_go_A_const_97 = lang.Var_Cast(A_arbace_go_A_const_pool.A[132]); A_arbace_go_A_const_98 = lang.Var_Cast(A_arbace_go_A_const_pool.A[133]); A_arbace_go_A_const_99 = lang.Var_Cast(A_arbace_go_A_const_pool.A[134]); A_arbace_go_A_const_100 = lang.Var_Cast(A_arbace_go_A_const_pool.A[135]); A_arbace_go_A_const_101 = A_arbace_go_A_const_pool.A[136]; A_arbace_go_A_const_102 = A_arbace_go_A_const_pool.A[137]; A_arbace_go_A_const_103 = A_arbace_go_A_const_pool.A[138]; A_arbace_go_A_const_104 = lang.Var_Cast(A_arbace_go_A_const_pool.A[139]); A_arbace_go_A_const_105 = lang.Var_Cast(A_arbace_go_A_const_pool.A[140]); A_arbace_go_A_const_106 = A_arbace_go_A_const_pool.A[141]; A_arbace_go_A_const_107 = lang.Var_Cast(A_arbace_go_A_const_pool.A[142]); A_arbace_go_A_const_108 = A_arbace_go_A_const_pool.A[143] }

func A_arbace_go_A_clinit_p9() { A_arbace_go_A_const_109 = lang.Var_Cast(A_arbace_go_A_const_pool.A[144]); A_arbace_go_A_const_110 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[145]); A_arbace_go_A_const_111 = A_arbace_go_A_const_pool.A[146]; A_arbace_go_A_const_112 = A_arbace_go_A_const_pool.A[147]; A_arbace_go_A_const_113 = A_arbace_go_A_const_pool.A[148]; A_arbace_go_A_const_114 = A_arbace_go_A_const_pool.A[149]; A_arbace_go_A_const_115 = A_arbace_go_A_const_pool.A[150]; A_arbace_go_A_const_116 = A_arbace_go_A_const_pool.A[151] }

func A_arbace_go_A_New() *A_arbace_go_A { A_arbace_go_A_Init(); t := &A_arbace_go_A{}; t.Ctor(); return t }

func (t *A_arbace_go_A) Ctor() {}

func (t *A_arbace_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_A) GetClass__Class() *jrt.Class { return A_arbace_go_A_class }

func (t *A_arbace_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_A); return ok }

func A_arbace_go_A_Cast(x any) *A_arbace_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_A_class)) }; return v }



type A_arbace_go_assign_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_assign_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_A struct{ j2g_header uint64 }

var A_arbace_go_check_A_fn_class *jrt.Class



type A_arbace_go_const_A struct{ j2g_header uint64 }

var A_arbace_go_const_A_fn_class *jrt.Class



type A_arbace_go_const_value_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_A_fn_class *jrt.Class



type A_arbace_go_const_value_fn__1822000029_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_fn__1822000029_A_fn_class *jrt.Class



type A_arbace_go_declare_STAR__A struct{ j2g_header uint64 }

var A_arbace_go_declare_STAR__A_fn_class *jrt.Class



type A_arbace_go_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_digest_info_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_A_fn_class *jrt.Class



type A_arbace_go_digest_info_fn__1822000032_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_fn__1822000032_A_fn_class *jrt.Class



type A_arbace_go_directive_A struct{ j2g_header uint64 }

var A_arbace_go_directive_A_fn_class *jrt.Class



type A_arbace_go_eval_A struct{ j2g_header uint64 }

var A_arbace_go_eval_A_fn_class *jrt.Class



type A_arbace_go_eval1822000004_A struct{ jrt.Object }

func A_arbace_go_eval1822000004_A_New() *A_arbace_go_eval1822000004_A { t := &A_arbace_go_eval1822000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000004_A) Ctor() {}

func (t *A_arbace_go_eval1822000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000004_A_class }

func (t *A_arbace_go_eval1822000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000004_A); return ok }

func A_arbace_go_eval1822000004_A_Cast(x any) *A_arbace_go_eval1822000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000004_A_class)) }; return v }



type A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class *jrt.Class



type A_arbace_go_eval1822000008_A struct{ jrt.Object }

func A_arbace_go_eval1822000008_A_New() *A_arbace_go_eval1822000008_A { t := &A_arbace_go_eval1822000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000008_A) Ctor() {}

func (t *A_arbace_go_eval1822000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000008_A_class }

func (t *A_arbace_go_eval1822000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000008_A); return ok }

func A_arbace_go_eval1822000008_A_Cast(x any) *A_arbace_go_eval1822000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000008_A_class)) }; return v }



type A_arbace_go_eval1822000008_fn__1822000009_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000008_fn__1822000009_A_fn_class *jrt.Class



type A_arbace_go_file_A struct{ j2g_header uint64 }

var A_arbace_go_file_A_fn_class *jrt.Class



type A_arbace_go_fn__1822000016_A struct{ j2g_header uint64 }

var A_arbace_go_fn__1822000016_A_fn_class *jrt.Class



type A_arbace_go_func_A struct{ j2g_header uint64 }

var A_arbace_go_func_A_fn_class *jrt.Class



type A_arbace_go_import_A struct{ j2g_header uint64 }

var A_arbace_go_import_A_fn_class *jrt.Class



type A_arbace_go_member_var_A struct{ j2g_header uint64 }

var A_arbace_go_member_var_A_fn_class *jrt.Class



type A_arbace_go_method_A struct{ j2g_header uint64 }

var A_arbace_go_method_A_fn_class *jrt.Class



type A_arbace_go_new_A struct{ j2g_header uint64 }

var A_arbace_go_new_A_fn_class *jrt.Class



type A_arbace_go_package_A struct{ j2g_header uint64 }

var A_arbace_go_package_A_fn_class *jrt.Class



type A_arbace_go_packages_A struct{ j2g_header uint64 }

var A_arbace_go_packages_A_fn_class *jrt.Class



type A_arbace_go_params_of_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_A_fn_class *jrt.Class



type A_arbace_go_params_of_fn__1822000024_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_fn__1822000024_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_fn__1822000013_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class *jrt.Class



type A_arbace_go_pos_of_A struct{ j2g_header uint64 }

var A_arbace_go_pos_of_A_fn_class *jrt.Class



type A_arbace_go_repl_fn_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn_A_fn_class *jrt.Class



type A_arbace_go_run_main_A struct{ j2g_header uint64 }

var A_arbace_go_run_main_A_fn_class *jrt.Class



type A_arbace_go_spread_A struct{ j2g_header uint64 }

var A_arbace_go_spread_A_fn_class *jrt.Class



type A_arbace_go_str_A struct{ j2g_header uint64 }

var A_arbace_go_str_A_fn_class *jrt.Class



type A_arbace_go_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_go_strip_doc_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000061_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_A struct{ j2g_header uint64; F_info, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A struct{ j2g_header uint64; F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A struct{ j2g_header uint64; F_members, F_s__1822000065, F_iter__1822000064 any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A struct{ j2g_header uint64; F_b__1822000067, F_members any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A struct{ j2g_header uint64; F_iter__1822000045, F_s__1822000046 any }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A struct{ j2g_header uint64; F_b__1822000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__make__1822000081_A struct{ j2g_header uint64; F_ns, F_info, F_consts, F_p, F_members any }

var A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__resolver__1822000086_A struct{ j2g_header uint64; F_make, F_consts, F_members any }

var A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class *jrt.Class



type A_arbace_go_type_A struct{ j2g_header uint64 }

var A_arbace_go_type_A_fn_class *jrt.Class



type A_arbace_go_type_of_A struct{ j2g_header uint64 }

var A_arbace_go_type_of_A_fn_class *jrt.Class



type A_arbace_go_var_A struct{ j2g_header uint64 }

var A_arbace_go_var_A_fn_class *jrt.Class



type A_arbace_go_zero_A struct{ j2g_header uint64 }

var A_arbace_go_zero_A_fn_class *jrt.Class
