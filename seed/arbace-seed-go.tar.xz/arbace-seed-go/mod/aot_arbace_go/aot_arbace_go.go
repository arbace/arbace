//line aot_arbace_go.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New() *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_A_const_1, A_arbace_go_A_const_2, A_arbace_go_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_eval1822000008_fn__1822000009_A_New() *A_arbace_go_eval1822000008_fn__1822000009_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000008_fn__1822000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_go_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_A_const_7.GetRawRoot__O(), A_arbace_go_A_const_8) }
















































func A_arbace_go_path__GT_ns_A_New() *A_arbace_go_path__GT_ns_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {



	var root_17 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_35, nil); var tmp2 any; var root_21 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_25 any; var root_26 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = Lit_12; var arg_30 any; var root_31 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp3 any = A_arbace_go_path__GT_ns_fn__1822000013_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *jrt.Class = A_arbace_go_A_const_14; var arg_35 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__0, tmp5, Lit_37, jrt.RefArrayOf(jrt.Object_class, Lit_38)); if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_17, arg_20) } }
//line :54:1
func A_arbace_go_path__GT_ns_fn__1822000013_A_New() *A_arbace_go_path__GT_ns_fn__1822000013_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_fn__1822000013_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Ctor() {}
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Invoke_O_O__O(self, p1__1822000012_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_go_A_const_14; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1822000012_SHARP___1, tmp1, Lit_39, jrt.RefArrayOf(jrt.Object_class, Lit_40, Lit_41)) }


func A_arbace_go_fn__1822000016_A_New() *A_arbace_go_fn__1822000016_A { A_arbace_go_A_Init(); t := &A_arbace_go_fn__1822000016_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_26); var tmp1 any = A_arbace_go_A_const_15; var tmp2 any; var root_37 any = A_arbace_go_A_const_16.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_39 lang.IFn

		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__2; var arg_45 any = A_arbace_go_A_const_18; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_37, arg_40) }
//line :58:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_A_const_19; var tmp5 any = A_arbace_go_A_const_20; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_digest_forms_A_New() *A_arbace_go_digest_forms_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_forms_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_digest_forms_A) Ctor() {}
//line :62:1
func (t *A_arbace_go_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_47 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_49 lang.IFn; if



	linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_A_const_21.GetRawRoot__O(); if linked_48 == nil { temp__1927000414__auto____2 = ifn_49.Invoke_O__O(arg_50) } else { temp__1927000414__auto____2 = linked_48.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__1822000018__3 any = temp__1927000414__auto____2; var map__1822000018__4 any; if lang.ISeq_InstanceOf(map__1822000018__3) { var tmp1 any; var root_51 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = map__1822000018__3; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_55 any = A_arbace_go_A_const_23.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = map__1822000018__3; if linked_56 == nil { tmp2 = ifn_57.Invoke_O__O(arg_58) } else { tmp2 = linked_56.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_55, arg_58) }; map__1822000018__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_59 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = map__1822000018__3; if linked_60 == nil { tmp3 = ifn_61.Invoke_O__O(arg_62) } else { tmp3 = linked_60.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_59, arg_62) }; if jrt.J2g_Truth(tmp3) { var root_63 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = map__1822000018__3; if linked_64 == nil { map__1822000018__4 = ifn_65.Invoke_O__O(arg_66) } else { map__1822000018__4 = linked_64.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_63, arg_66) } } else { map__1822000018__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1822000018__4 = map__1822000018__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_15); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_19); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_20); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__1822000020__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(1), nil); var r__12 any; var tmp4 any; var root_67 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_69 lang.IFn
			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = text__6; var arg_71 any; var na_73 any = start__7; var na_74 any = a__10; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_73); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_74) }; tmp5 = tmp6; if tmp5 { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); var n1_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var nr_77 int64 = n0_75 + n1_76; if (n0_75^nr_77)&(n1_76^nr_77) >= 0 { arg_71 = jrt.Long_ValueOf_J__Long_NoInit(nr_77).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_73); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_74) }; tmp7 = tmp8; if tmp7 { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); var n1_76_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); arg_71 = jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + n1_76_2).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } }; var arg_72 any; var na_78 any = start__7; var na_79 any = b__11; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_78); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_79) }; tmp9 = tmp10; if tmp9 { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var nr_82 int64 = n0_80 + n1_81; if (n0_80^nr_82)&(n1_81^nr_82) >= 0 { arg_72 = jrt.Long_ValueOf_J__Long_NoInit(nr_82).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_78); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_79) }; tmp11 = tmp12; if tmp11 { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); arg_72 = jrt.Double_ValueOf_D__Double_NoInit(n0_80_2 + n1_81_2).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } }; if linked_68 == nil { tmp4 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) }
//line :67:1
			r__12 = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(tmp4)))

			var root_91 any = A_arbace_go_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_A_const_32, jrt.Boolean_FALSE.Ref()); if linked_92 == nil { ifn_93.Invoke_O__O(arg_94) } else { linked_92.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_91, arg_94) }
//line :67:1
			var tmp13 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__15 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__16 any; var root_83 any = A_arbace_go_A_const_26.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_85 lang.IFn



				if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_go_A_const_27; var arg_87 any = r__12; if linked_84 == nil { f__16 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { f__16 = linked_84.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }
				if lang.Util_Equiv_O_O__Z_NoInit(f__16, A_arbace_go_A_const_28) { tmp13 = acc__15 } else { var tmp14 any; var root_100 any = A_arbace_go_A_const_7.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = acc__15; var arg_104 any = f__16; if linked_101 == nil { tmp14 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp14 = linked_101.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; acc__15 = tmp14; continue L1 }
//line :67:1
				break L1 } }; return nil }(); var root_88 any = A_arbace_go_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_90 lang.IFn

			if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; if linked_89 == nil { ifn_90.Invoke__O() } else { linked_89.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_88) }
//line :67:1
			if tmp15 != nil { panic(tmp15) }; return tmp13 } else { return nil } } else {
//line :66:1
				return nil } }







func A_arbace_go_params_of_A_New() *A_arbace_go_params_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_params_of_A) Ctor() {}
//line :74:1
func (t *A_arbace_go_params_of_A) Invoke_O_O__O(self, pv__0 any) any {


	var root_105 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_go_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp1 any = A_arbace_go_params_of_fn__1822000024_A_New(); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_params_of_fn__1822000024_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_params_of_fn__1822000024_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_113 any = pv__0; if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_105, arg_108) } }
//line :77:1
func A_arbace_go_params_of_fn__1822000024_A_New() *A_arbace_go_params_of_fn__1822000024_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_fn__1822000024_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Ctor() {}
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, x__2) } else {
												if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_114 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_116 lang.IFn

		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__2; if linked_115 == nil { and__1927000168__auto____3 = ifn_116.Invoke_O__O(arg_117) } else { and__1927000168__auto____3 = linked_115.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_118 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_go_A_const_40; var arg_122 any = x__2; if linked_119 == nil { tmp1 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_118, arg_121, arg_122) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_123 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = x__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_127, arg_130) }; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_123, arg_126) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_131 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var na_135 any = i__1; if jrt.Long_InstanceOf(na_135) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); if n0_136 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_136 + 1)) } } else { if jrt.Double_InstanceOf(na_135) { var n0_136_2 float64 = jrt.NN(jrt.Double_Cast(na_135)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_136_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } }; arg_134 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_132 == nil { return ifn_133.Invoke_O__O(arg_134) } else { return linked_132.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_131, arg_134) } } else {
//line :78:1
						return nil } } } } }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, x__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_137 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_139 lang.IFn

		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = x__2; if linked_138 == nil { and__1927000168__auto____3 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____3 = linked_138.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_141 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_go_A_const_40; var arg_145 any = x__2; if linked_142 == nil { tmp1 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_146 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_150 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = x__2; if linked_151 == nil { arg_149 = ifn_152.Invoke_O__O(arg_153) } else { arg_149 = linked_151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_150, arg_153) }; if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_146, arg_149) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_154 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var n0_158 int64 = i__1_l; if n0_158 == 9223372036854775807 { var tmp5 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp5 = i__1_b } else { tmp5 = i__1_b }; tmp4 = lang.Numbers_Inc_O__Number_NoInit(tmp5) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_158 + 1)) }; arg_157 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_155 == nil { return ifn_156.Invoke_O__O(arg_157) } else { return linked_155.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_154, arg_157) } } else {
//line :78:1
						return nil
					}
			}
	}
}

func A_arbace_go_strip_doc_A_New() *A_arbace_go_strip_doc_A { A_arbace_go_A_Init(); t := &A_arbace_go_strip_doc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_go_strip_doc_A) Ctor() {}
//line :84:1
func (t *A_arbace_go_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_160 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_164 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = xs__0; if linked_165 == nil { arg_163 = ifn_166.Invoke_O__O(arg_167) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_168 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = xs__0; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) }; var tmp3 any = tmp2; var tmp4 any; var root_172 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = xs__0; if linked_173 == nil { tmp4 = ifn_174.Invoke_O__O(arg_175) } else { tmp4 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) } }

func A_arbace_go_const_value_A_New() *A_arbace_go_const_value_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_const_value_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_const_value_A) Invoke_O_O_O__O(self, v__0, underlying__1 any) any {




	var tmp1 any; var root_176 any = A_arbace_go_A_const_45.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_178 lang.IFn
	if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = v__0; if linked_177 == nil { tmp1 = ifn_178.Invoke_O__O(arg_179) } else { tmp1 = linked_177.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_176, arg_179) }
//line :91:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var root_180 any = A_arbace_go_A_const_46.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_182 lang.IFn

		if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = v__0; if linked_181 == nil { tmp2 = ifn_182.Invoke_O__O(arg_183) } else { tmp2 = linked_181.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_180, arg_183) }
//line :91:1
		if jrt.J2g_Truth(tmp2) {

			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__0))).Ref() } else {
//line :91:1
				var tmp3 any; var or__1927000174__auto____3 any; var root_184 any = A_arbace_go_A_const_47.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_float_QMARK__A_fn_class); var ifn_186 lang.IFn


				if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { or__1927000174__auto____3 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____3 = linked_185.(*aot_arbace_core.A_arbace_core_float_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_188 any = A_arbace_go_A_const_48.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = v__0; if linked_189 == nil { or__1927000174__auto____4 = ifn_190.Invoke_O__O(arg_191) } else { or__1927000174__auto____4 = linked_189.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { var root_192 any = A_arbace_go_A_const_49.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_decimal_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*aot_arbace_core.A_arbace_core_decimal_QMARK__A).Invoke_O_O__O(root_192, arg_195) } } }
//line :91:1
				if jrt.J2g_Truth(tmp3) {


					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_50, underlying__1) { return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__0)).Ref() } else { return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__0)).Ref() } } else {
//line :91:1
						var tmp4 any; var root_196 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_198 lang.IFn



						if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = v__0; if linked_197 == nil { tmp4 = ifn_198.Invoke_O__O(arg_199) } else { tmp4 = linked_197.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_196, arg_199) }
//line :91:1
						if jrt.J2g_Truth(tmp4) { var G__1822000028__3_ any; var root_200 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_202 lang.IFn



							if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = v__0; if linked_205 == nil { arg_203 = ifn_206.Invoke_O__O(arg_207) } else { arg_203 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; if linked_201 == nil { G__1822000028__3_ = ifn_202.Invoke_O__O(arg_203) } else { G__1822000028__3_ = linked_201.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_200, arg_203) }; switch lang.Util_Hash_O__I_NoInit(G__1822000028__3_) >> 7 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_2) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_52.GetRawRoot__O()); var tmp6 any = A_arbace_go_const_value_fn__1822000029_A_New(); var tmp7 *jrt.Class
								var fncls__222 /*line :95:1*/*jrt.Class = A_arbace_go_const_value_fn__1822000029_A_fn_class

								if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_const_value_fn__1822000029_A_fn_class = fncls__222d; tmp7 = fncls__222d } else { tmp7 = fncls__222 }
//line :95:1
								var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_223 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_225 lang.IFn

								if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = v__0; if linked_224 == nil { tmp9 = ifn_225.Invoke_O__O(arg_226) } else { tmp9 = linked_224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_223, arg_226) }
//line :95:1
								return jrt.String_New_B1_String(lang.Numbers_Byte_array_O__B1_NoInit(tmp5.Invoke_O_O__O(tmp8, tmp9)), Lit_4) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_5) {



									var tmp10 any; var root_227 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = v__0; if linked_228 == nil { tmp10 = ifn_229.Invoke_O__O(arg_230) } else { tmp10 = linked_228.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_227, arg_230) }; return lang.GoInterp_Complex_D_D__O(lang.RT_DoubleCast_O__D_NoInit(tmp10), lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) }
//line :95:1
							case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_6) {
								var tmp11 any; var root_231 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = v__0; if linked_232 == nil { tmp11 = ifn_233.Invoke_O__O(arg_234) } else { tmp11 = linked_232.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_231, arg_234) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp11)).Ref() }
//line :95:1
							case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_7) {




								var tmp12 any; var root_235 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = v__0; if linked_236 == nil { tmp12 = ifn_237.Invoke_O__O(arg_238) } else { tmp12 = linked_236.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_235, arg_238) }; return jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Multiply_D_D__D_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp12), jrt.Math_Pow_D_D__D(2.0, lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))))).Ref() }
//line :95:1
							default:}; return v__0 } else {
//line :91:1
								if A_arbace_go_A_const_42 != nil { return v__0 } else { return nil
								}
							}
					}
			}
	} }
func A_arbace_go_const_value_fn__1822000029_A_New() *A_arbace_go_const_value_fn__1822000029_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_fn__1822000029_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Ctor() {}
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_214 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = x__1; if linked_215 == nil { tmp1 = ifn_216.Invoke_O__O(arg_217) } else { tmp1 = linked_215.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp1) { var root_218 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = jrt.NN(jrt.String_Cast(x__1)).GetBytes_String__B1(Lit_4).Ref(); if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) } } else { return lang.Tuple_Create_O__IPersistentVector(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_UncheckedByteCast_O__B_NoInit(x__1)).Ref()) } }






func A_arbace_go_digest_info_A_New() *A_arbace_go_digest_info_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_digest_info_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_digest_info_A) Invoke_O_O__O(self, p__0 any) any {


	var root_239 any = A_arbace_go_A_const_54.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any; var tmp1 any = A_arbace_go_digest_info_fn__1822000032_A_New(); var tmp2 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_go_digest_info_fn__1822000032_A_fn_class
	if fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_digest_info_fn__1822000032_A_fn_class = fncls__453d; tmp2 = fncls__453d } else { tmp2 = fncls__453 }; arg_242 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :107:1
	var arg_243 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_244 any; var root_454 any = A_arbace_go_A_const_72.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, A_arbace_go_digest_forms_A_fn_class); var ifn_456 lang.IFn




























	if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = p__0; if linked_455 == nil { arg_244 = ifn_456.Invoke_O__O(arg_457) } else { arg_244 = linked_455.(*A_arbace_go_digest_forms_A).Invoke_O_O__O(root_454, arg_457) }
//line :107:1
	if linked_240 == nil { return ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { return linked_240.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) } }
func A_arbace_go_digest_info_fn__1822000032_A_New() *A_arbace_go_digest_info_fn__1822000032_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_fn__1822000032_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Ctor() {}
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any; var root_245 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var and__1927000168__auto____3 any; var root_249 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__2; if linked_250 == nil { and__1927000168__auto____3 = ifn_251.Invoke_O__O(arg_252) } else { and__1927000168__auto____3 = linked_250.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_253 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = f__2; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { and__1927000168__auto____4 = ifn_255.Invoke_O__O(arg_256) } else { and__1927000168__auto____4 = linked_254.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_261 any = A_arbace_go_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_265 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = f__2; if linked_266 == nil { arg_264 = ifn_267.Invoke_O__O(arg_268) } else { arg_264 = linked_266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_265, arg_268) }; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_261, arg_264) }; arg_248 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_10, tmp2)).Ref() } else { arg_248 = and__1927000168__auto____4 } } else { arg_248 = and__1927000168__auto____3 }; if linked_246 == nil { tmp1 = ifn_247.Invoke_O__O(arg_248) } else { tmp1 = linked_246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var G__1822000033__3_ any; var root_269 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_271 lang.IFn

		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_273 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = f__2; if linked_274 == nil { arg_272 = ifn_275.Invoke_O__O(arg_276) } else { arg_272 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; if linked_270 == nil { G__1822000033__3_ = ifn_271.Invoke_O__O(arg_272) } else { G__1822000033__3_ = linked_270.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_269, arg_272) }; switch lang.Util_Hash_O__I_NoInit(G__1822000033__3_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_11) { var vec__1822000034__4 any; var root_278 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_go_strip_doc_A_fn_class); var ifn_280 lang.IFn





			if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_282, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_286 any = f__2; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(A_arbace_go_A_const_59, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_282, 2, A_arbace_go_A_const_59, arg_286) }; if linked_279 == nil { vec__1822000034__4 = ifn_280.Invoke_O__O(arg_281) } else { vec__1822000034__4 = linked_279.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_278, arg_281) }
//line :111:1
			var doc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7 bool; var tmp3 any = A_arbace_go_A_const_60; var tmp4 any; var root_287 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn






			if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = xs__6; if linked_288 == nil { tmp4 = ifn_289.Invoke_O__O(arg_290) } else { tmp4 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) }; gen__7 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)
//line :111:1
			var xs__8 any







			if gen__7 { var root_291 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_291, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_295 any = xs__6; if linked_292 == nil { xs__8 = ifn_293.Invoke_O_O__O(A_arbace_go_A_const_59, arg_295) } else { xs__8 = linked_292.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_291, 2, A_arbace_go_A_const_59, arg_295) } } else { xs__8 = xs__6 }
//line :111:1
			var pv__9 any; var root_296 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_298 lang.IFn








			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = xs__8; if linked_297 == nil { pv__9 = ifn_298.Invoke_O__O(arg_299) } else { pv__9 = linked_297.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_296, arg_299) }
//line :111:1
			var r__10 any; var root_300 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn









			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = pv__9; if linked_301 == nil { r__10 = ifn_302.Invoke_O__O(arg_303) } else { r__10 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }
//line :111:1
			var rt__11 any; var tmp5 any; var and__1927000168__auto____11 any; var root_304 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_306 lang.IFn










			if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = r__10; if linked_305 == nil { and__1927000168__auto____11 = ifn_306.Invoke_O__O(arg_307) } else { and__1927000168__auto____11 = linked_305.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp6 *lang.Keyword = A_arbace_go_A_const_38; tmp5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) { var tmp7 *lang.Keyword = A_arbace_go_A_const_38; rt__11 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { rt__11 = r__10 }
//line :111:1
			var rt__12 any; var tmp8 any; var and__1927000168__auto____12 any; var root_308 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn











			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = rt__11; if linked_309 == nil { and__1927000168__auto____12 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____12 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp9 any = A_arbace_go_A_const_61; var tmp10 any; var root_312 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = rt__11; if linked_313 == nil { tmp10 = ifn_314.Invoke_O__O(arg_315) } else { tmp10 = linked_313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_312, arg_315) }; tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10)).Ref() } else { tmp8 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp8) { var root_316 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = rt__11; if linked_317 == nil { rt__12 = ifn_318.Invoke_O__O(arg_319) } else { rt__12 = linked_317.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_316, arg_319) } } else { rt__12 = rt__11 }
//line :111:1
			var vec__1822000037__13 any; var tmp11 any; var root_320 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_322 lang.IFn













			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = rt__12; if linked_321 == nil { tmp11 = ifn_322.Invoke_O__O(arg_323) } else { tmp11 = linked_321.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(tmp11) { var tmp12 any; var root_431 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = rt__12; if linked_432 == nil { tmp12 = ifn_433.Invoke_O__O(arg_434) } else { tmp12 = linked_432.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_431, arg_434) }; vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, jrt.Boolean_TRUE.Ref()) } else { vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(rt__12, jrt.Boolean_ValueOf_Z__Boolean_NoInit(gen__7).Ref()) }
//line :111:1
			var rt__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(0), nil); var gen__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp13 any; var root_324 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_326 lang.IFn














			if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = rt__14; if linked_325 == nil { tmp13 = ifn_326.Invoke_O__O(arg_327) } else { tmp13 = linked_325.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(tmp13) {
				var root_328 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = acc__1; var arg_332 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil); var tmp15 any; var root_334 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = f__2; if linked_335 == nil { tmp15 = ifn_336.Invoke_O__O(arg_337) } else { tmp15 = linked_335.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_334, arg_337) }; arg_332 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, rt__14, nil, tmp15)).Ref(); var arg_333 any; var G__1822000040__16_ any; var tmp16 any = A_arbace_go_A_const_63; var tmp17 any = A_arbace_go_A_const_64; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp19 any; var root_344 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, A_arbace_go_params_of_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = pv__9; if linked_345 == nil { tmp19 = ifn_346.Invoke_O__O(arg_347) } else { tmp19 = linked_345.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_344, arg_347) }; G__1822000040__16_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, doc__5, tmp17, tmp18.Invoke_O__O(tmp19))); if jrt.J2g_Truth(gen__15) {
					var root_338 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = G__1822000040__16_; var arg_342 any = A_arbace_go_A_const_66; var arg_343 any = jrt.Boolean_TRUE.Ref(); if linked_339 == nil { arg_333 = ifn_340.Invoke_O_O_O__O(arg_341, arg_342, arg_343) } else { arg_333 = linked_339.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_338, arg_341, arg_342, arg_343) } } else {
//line :127:1
						arg_333 = G__1822000040__16_ }; if linked_329 == nil { return ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { return linked_329.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) } } else {
//line :126:1
							return acc__1 } }
//line :111:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_13) {




















			var root_348 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = acc__1; var arg_352 any; var root_354 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var root_358 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = f__2; if linked_359 == nil { arg_357 = ifn_360.Invoke_O__O(arg_361) } else { arg_357 = linked_359.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_358, arg_361) }; if linked_355 == nil { arg_352 = ifn_356.Invoke_O__O(arg_357) } else { arg_352 = linked_355.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_354, arg_357) }; var arg_353 any; var tmp20 any = A_arbace_go_A_const_63; var tmp21 any; var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp22 any; var root_362 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = d__4; if linked_363 == nil { tmp22 = ifn_364.Invoke_O__O(arg_365) } else { tmp22 = linked_363.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(tmp22) { tmp21 = d__4 } else { tmp21 = nil }; arg_353 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21)); if linked_349 == nil { return ifn_350.Invoke_O_O_O__O(arg_351, arg_352, arg_353) } else { return linked_349.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_348, arg_351, arg_352, arg_353) } }
//line :111:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_14) { var n__4 any; var root_366 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_368 lang.IFn


















			if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = f__2; if linked_367 == nil { n__4 = ifn_368.Invoke_O__O(arg_369) } else { n__4 = linked_367.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_366, arg_369) }
//line :111:1
			var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__4); var root_370 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_372 lang.IFn



















			if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = acc__1; var arg_374 any; var root_376 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = n__4; if linked_377 == nil { arg_374 = ifn_378.Invoke_O__O(arg_379) } else { arg_374 = linked_377.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_376, arg_379) }; var arg_375 any; var tmp23 any = A_arbace_go_A_const_63; var tmp24 any = A_arbace_go_A_const_63.Invoke_O__O(m__5); var tmp25 any = A_arbace_go_A_const_68; var tmp26 any; var root_380 any = A_arbace_go_A_const_69.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_go_const_value_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = A_arbace_go_A_const_70.Invoke_O__O(m__5); var arg_384 any = A_arbace_go_A_const_71.Invoke_O__O(m__5); if linked_381 == nil { tmp26 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { tmp26 = linked_381.(*A_arbace_go_const_value_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; arg_375 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)); if linked_371 == nil { return ifn_372.Invoke_O_O_O__O(arg_373, arg_374, arg_375) } else { return linked_371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_370, arg_373, arg_374, arg_375) } }
//line :111:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_15) { var vec__1822000041__4 any; var root_385 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, A_arbace_go_strip_doc_A_fn_class); var ifn_387 lang.IFn
			if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var root_389 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_389, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_393 any = f__2; if linked_390 == nil { arg_388 = ifn_391.Invoke_O_O__O(A_arbace_go_A_const_59, arg_393) } else { arg_388 = linked_390.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_389, 2, A_arbace_go_A_const_59, arg_393) }; if linked_386 == nil { vec__1822000041__4 = ifn_387.Invoke_O__O(arg_388) } else { vec__1822000041__4 = linked_386.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_385, arg_388) }
//line :111:1
			var doc__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7_2 bool; var tmp27 any = A_arbace_go_A_const_60; var tmp28 any; var root_394 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_396 lang.IFn

			if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = xs__6_2; if linked_395 == nil { tmp28 = ifn_396.Invoke_O__O(arg_397) } else { tmp28 = linked_395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_394, arg_397) }; gen__7_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp27, tmp28)
//line :111:1
			var xs__8_2 any


			if gen__7_2 { var root_398 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_398, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_402 any = xs__6_2; if linked_399 == nil { xs__8_2 = ifn_400.Invoke_O_O__O(A_arbace_go_A_const_59, arg_402) } else { xs__8_2 = linked_399.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_398, 2, A_arbace_go_A_const_59, arg_402) } } else { xs__8_2 = xs__6_2 }
			var root_403 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = acc__1; var arg_407 any; var root_409 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var root_413 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = f__2; if linked_414 == nil { arg_412 = ifn_415.Invoke_O__O(arg_416) } else { arg_412 = linked_414.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_413, arg_416) }; if linked_410 == nil { arg_407 = ifn_411.Invoke_O__O(arg_412) } else { arg_407 = linked_410.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_409, arg_412) }; var arg_408 any; var G__1822000044__9_ any; var tmp29 any = A_arbace_go_A_const_63; var tmp30 any = A_arbace_go_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp32 any; var root_423 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, A_arbace_go_params_of_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var root_427 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = xs__8_2; if linked_428 == nil { arg_426 = ifn_429.Invoke_O__O(arg_430) } else { arg_426 = linked_428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_427, arg_430) }; if linked_424 == nil { tmp32 = ifn_425.Invoke_O__O(arg_426) } else { tmp32 = linked_424.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_423, arg_426) }; G__1822000044__9_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, doc__5_2, tmp30, tmp31.Invoke_O__O(tmp32))); if gen__7_2 {
				var root_417 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = G__1822000044__9_; var arg_421 any = A_arbace_go_A_const_66; var arg_422 any = jrt.Boolean_TRUE.Ref(); if linked_418 == nil { arg_408 = ifn_419.Invoke_O_O_O__O(arg_420, arg_421, arg_422) } else { arg_408 = linked_418.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_417, arg_420, arg_421, arg_422) } } else {
//line :115:1
					arg_408 = G__1822000044__9_ }; if linked_404 == nil { return ifn_405.Invoke_O_O_O__O(arg_406, arg_407, arg_408) } else { return linked_404.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_403, arg_406, arg_407, arg_408) } }
//line :111:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_16) {





















			var root_435 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = acc__1; var arg_439 any; var root_441 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_445 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = f__2; if linked_446 == nil { arg_444 = ifn_447.Invoke_O__O(arg_448) } else { arg_444 = linked_446.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_445, arg_448) }; if linked_442 == nil { arg_439 = ifn_443.Invoke_O__O(arg_444) } else { arg_439 = linked_442.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_441, arg_444) }; var arg_440 any; var tmp33 any = A_arbace_go_A_const_63; var tmp34 *lang.Keyword = A_arbace_go_A_const_63; var tmp35 any; var root_449 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = f__2; if linked_450 == nil { tmp35 = ifn_451.Invoke_O__O(arg_452) } else { tmp35 = linked_450.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_449, arg_452) }; arg_440 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp35)))); if linked_436 == nil { return ifn_437.Invoke_O_O_O__O(arg_438, arg_439, arg_440) } else { return linked_436.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_435, arg_438, arg_439, arg_440) } }
//line :111:1
		default:}; return acc__1
	}
}





























func A_arbace_go_member_var_A_New() *A_arbace_go_member_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_member_var_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_member_var_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_member_var_A) Invoke_O_O_O_O_O_O_O__O(self, ns__0, path__1, nm__2, kind__3, handle__4, info__5 any) any { var full__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, path__1, nil, nm__2)).Ref(); var m__8 any; var G__1822000047__8_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_A_const_73, kind__3, A_arbace_go_A_const_74, path__1)); var G__1822000047__9_ any; if



	jrt.J2g_Truth(A_arbace_go_A_const_63.Invoke_O__O(info__5)) {
		var root_458 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = G__1822000047__8_; var arg_462 any = A_arbace_go_A_const_63; var arg_463 any = A_arbace_go_A_const_63.Invoke_O__O(info__5); if linked_459 == nil { G__1822000047__9_ = ifn_460.Invoke_O_O_O__O(arg_461, arg_462, arg_463) } else { G__1822000047__9_ = linked_459.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_458, arg_461, arg_462, arg_463) } } else {
//line :147:1
			G__1822000047__9_ = G__1822000047__8_ }; if jrt.J2g_Truth(A_arbace_go_A_const_64.Invoke_O__O(info__5)) {

				var root_464 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = G__1822000047__9_; var arg_468 any = A_arbace_go_A_const_64; var arg_469 any = A_arbace_go_A_const_64.Invoke_O__O(info__5); if linked_465 == nil { m__8 = ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { m__8 = linked_465.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } } else {
//line :147:1
					m__8 = G__1822000047__9_ }; var root_470 any =


	A_arbace_go_A_const_75.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = ns__0; var arg_474 any; var root_476 any = A_arbace_go_A_const_76.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = nm__2; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any = m__8; if linked_477 == nil { arg_474 = ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { arg_474 = linked_477.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) }; var arg_475 any; var G__1822000048__9_ any = kind__3; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1822000048__9_) >> 3 & 7 { case 1: if any(G__1822000048__9_) == any(A_arbace_go_A_const_77) { arg_475 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 3: if any(G__1822000048__9_) == any(A_arbace_go_A_const_78) { arg_475 = lang.GoVar_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 4: if any(G__1822000048__9_) == any(A_arbace_go_A_const_79) { arg_475 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 5: if any(G__1822000048__9_) == any(A_arbace_go_A_const_68) {



		arg_475 = A_arbace_go_A_const_68.Invoke_O__O(info__5)
//line :151:1
		break L1 }; case 6: if any(G__1822000048__9_) == any(A_arbace_go_A_const_80) { arg_475 = lang.GoType_New_O(handle__4); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1822000048__9_)))))}; if /*line :150:1*/ linked_471 == nil { return ifn_472.Invoke_O_O_O__O(arg_473, arg_474, arg_475) } else { return linked_471.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_470, arg_473, arg_474, arg_475) } }






func A_arbace_go_table_ns_BANG__A_New() *A_arbace_go_table_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Ctor() {}
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any { var ns__2 any; var root_486 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_488 lang.IFn; if




	linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; var root_490 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, A_arbace_go_path__GT_ns_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = p__0; if linked_491 == nil { arg_489 = ifn_492.Invoke_O__O(arg_493) } else { arg_489 = linked_491.(*A_arbace_go_path__GT_ns_A).Invoke_O_O__O(root_490, arg_493) }; if linked_487 == nil { ns__2 = ifn_488.Invoke_O__O(arg_489) } else { ns__2 = linked_487.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_486, arg_489) }; var early__3 any; var root_494 any = /*line :157:1*/A_arbace_go_A_const_33.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_496 lang.IFn; if







	linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New_O(ns__2); var tmp2 *jrt.Class; var fncls__592 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class; if fncls__592 == nil { var fncls__592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class = fncls__592d; tmp2 = fncls__592d } else { tmp2 = fncls__592 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_497 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(jrt.NN(lang.Namespace_Cast(ns__2)).GetMappings__IPersistentMap()); if linked_495 == nil { early__3 = ifn_496.Invoke_O__O(arg_497) } else { early__3 = linked_495.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_494, arg_497) }; var ms__4 any = /*line :157:1*/lang.GoInterp_Members_String__O1(jrt.String_Cast(p__0)).Ref(); var members__5 any; var root_593 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_595 lang.IFn; if











	linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_597 any; var iter__1927001039__auto____5 any; var tmp3 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_New(); var tmp4 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class = fncls__664d; tmp4 = fncls__664d } else { tmp4 = fncls__664 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp6 any; var root_665 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = A_arbace_go_A_const_96; var arg_669 any = ms__4; if linked_666 == nil { tmp6 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { tmp6 = linked_666.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; arg_597 = tmp5.Invoke_O__O(tmp6); if linked_594 == nil { members__5 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { members__5 = linked_594.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; var info__6 any; var tmp7 any = /*line :157:1*/A_arbace_go_table_ns_BANG__fn__1822000082_A_New_O(p__0); var tmp8 *jrt.Class; var fncls__674 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class; if












	fncls__674 == nil { var fncls__674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class = fncls__674d; tmp8 = fncls__674d } else { tmp8 = fncls__674 }; info__6 = /*line :157:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var consts__7 any; var tmp9 any = A_arbace_go_table_ns_BANG__fn__1822000084_A_New_O_O(info__6, members__5); var tmp10 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class; if













	fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class = fncls__779d; tmp10 = fncls__779d } else { tmp10 = fncls__779 }; consts__7 = /*line :157:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); var make__8 any; var tmp11 any = A_arbace_go_table_ns_BANG__make__1822000102_A_New_O_O_O_O_O(ns__2, info__6, consts__7, p__0, members__5); var tmp12 *jrt.Class; var fncls__818 *jrt.Class = A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class; if














	fncls__818 == nil { var fncls__818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class = fncls__818d; tmp12 = fncls__818d } else { tmp12 = fncls__818 }; make__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var resolver__9 any; var tmp13 any = /*line :157:1*/A_arbace_go_table_ns_BANG__resolver__1822000107_A_New_O_O_O(make__8, consts__7, members__5); var tmp14 *jrt.Class; var fncls__872 *jrt.Class = A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class; if























	fncls__872 == nil { var fncls__872d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class = fncls__872d; tmp14 = fncls__872d } else { tmp14 = fncls__872 }; resolver__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil);





	jrt.NN(lang.Namespace_Cast(ns__2)).SetResolver_O__V(resolver__9); var seq_1822000113__10 any; var root_873 any = /*line :157:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_875 lang.IFn; if






























	linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = early__3; if linked_874 == nil { seq_1822000113__10 = ifn_875.Invoke_O__O(arg_876) } else { seq_1822000113__10 = linked_874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_873, arg_876) }; var chunk_1822000114__11 any; var count_1822000115__12 int64 = 0; var i_1822000116__13 int64 = 0; L1:
//line :157:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000116__13, count_1822000115__12) { var n__14 any = lang.Indexed_Cast(chunk_1822000114__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000116__13)); lang.IFn_Cast(make__8).Invoke_O__O(n__14); seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000116__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_877 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = seq_1822000113__10; if linked_878 == nil { temp__1927000414__auto____14 = ifn_879.Invoke_O__O(arg_880) } else { temp__1927000414__auto____14 = linked_878.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000113__15 any = temp__1927000414__auto____14; var tmp15 any; var root_881 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = seq_1822000113__15; if linked_882 == nil { tmp15 = ifn_883.Invoke_O__O(arg_884) } else { tmp15 = linked_882.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_881, arg_884) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____16 any; var root_885 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = seq_1822000113__15; if linked_886 == nil { c__1927000678__auto____16 = ifn_887.Invoke_O__O(arg_888) } else { c__1927000678__auto____16 = linked_886.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_885, arg_888) }; var tmp16 any; var root_893 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = seq_1822000113__15; if linked_894 == nil { tmp16 = ifn_895.Invoke_O__O(arg_896) } else { tmp16 = linked_894.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_893, arg_896) }; seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = tmp16, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__16 any; var root_889 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = seq_1822000113__15; if linked_890 == nil { n__16 = ifn_891.Invoke_O__O(arg_892) } else { n__16 = linked_890.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_889, arg_892) }; lang.IFn_Cast(make__8).Invoke_O__O(n__16); var tmp17 any; var root_897 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = seq_1822000113__15; if linked_898 == nil { tmp17 = ifn_899.Invoke_O__O(arg_900) } else { tmp17 = linked_898.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_897, arg_900) }; seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = tmp17, nil, 0, 0; continue L1 } } }
//line :157:1
		break L1 }; return ns__2 }







func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A{}; t.Ctor_O(p0); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Invoke_O_O__O(self, s__1822000051__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O_O(t.F_ns, s__1822000051__1, self); var tmp2 *jrt.Class; var fncls__591 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class; if fncls__591 == nil { var fncls__591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class = fncls__591d; tmp2 = fncls__591d } else { tmp2 = fncls__591 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :165:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Ctor_O_O_O(c__ns, c__s__1822000051, c__iter__1822000050 any) { t.F_ns = c__ns; t.F_s__1822000051 = c__s__1822000051; t.F_iter__1822000050 = c__iter__1822000050 }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Invoke_O__O(self any) any { { var s__1822000051__1 any; var t_ any = t.F_s__1822000051; t.F_s__1822000051 = nil; s__1822000051__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_498 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1822000051__1; if linked_499 == nil { temp__1927000414__auto____2 = ifn_500.Invoke_O__O(arg_501) } else { temp__1927000414__auto____2 = linked_499.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_498, arg_501) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000051__3 any = temp__1927000414__auto____2; var tmp1 any; var root_502 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = s__1822000051__3; if linked_503 == nil { tmp1 = ifn_504.Invoke_O__O(arg_505) } else { tmp1 = linked_503.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_502, arg_505) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_506 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = s__1822000051__3; if linked_507 == nil { c__1927001037__auto____4 = ifn_508.Invoke_O__O(arg_509) } else { c__1927001037__auto____4 = linked_507.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_506, arg_509) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000053__6 any; var root_510 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_511 == nil { b__1822000053__6 = ifn_512.Invoke_O__O(arg_513) } else { b__1822000053__6 = linked_511.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_510, arg_513) }; var tmp2 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_O_I_O(b__1822000053__6, t.F_ns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class = fncls__535d; tmp3 = fncls__535d } else { tmp3 = fncls__535 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_536 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any; var root_541 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = b__1822000053__6; if linked_542 == nil { arg_539 = ifn_543.Invoke_O__O(arg_544) } else { arg_539 = linked_542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_541, arg_544) }; var arg_540 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp5 any; var root_545 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = s__1822000051__3; if linked_546 == nil { tmp5 = ifn_547.Invoke_O__O(arg_548) } else { tmp5 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_545, arg_548) }; arg_540 = tmp4.Invoke_O__O(tmp5); if linked_537 == nil { return ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { return linked_537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) } } else { var root_549 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any; var root_554 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = b__1822000053__6; if linked_555 == nil { arg_552 = ifn_556.Invoke_O__O(arg_557) } else { arg_552 = linked_555.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_554, arg_557) }; var arg_553 any; if linked_550 == nil { return ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { return linked_550.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_549, arg_552, arg_553) } } } else { var vec__1822000061__4 any; var root_558 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = s__1822000051__3; if linked_559 == nil { vec__1822000061__4 = ifn_560.Invoke_O__O(arg_561) } else { vec__1822000061__4 = linked_559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_558, arg_561) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_562 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_564 lang.IFn
														if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = v__6; if linked_563 == nil { and__1927000168__auto____7 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____7 = linked_563.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp7 any = t.F_ns; var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(tmp7, lang.Var_Cast(v__6).F_ns.Ref()); if and__1927000168__auto____8 { var root_566 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = lang.IFn_Cast(A_arbace_go_A_const_87.GetRawRoot__O()).Invoke_O__O(v__6); if linked_567 == nil { tmp6 = ifn_568.Invoke_O__O(arg_569) } else { tmp6 = linked_567.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_566, arg_569) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = and__1927000168__auto____7 }
//line :165:1
	if jrt.J2g_Truth(tmp6) { var root_574 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any; var root_579 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_581 lang.IFn

		if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = s__5; if linked_580 == nil { arg_577 = ifn_581.Invoke_O__O(arg_582) } else { arg_577 = linked_580.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_579, arg_582) }
//line :165:1
		var arg_578 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp9 any; var root_583 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = s__1822000051__3; if linked_584 == nil { tmp9 = ifn_585.Invoke_O__O(arg_586) } else { tmp9 = linked_584.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_583, arg_586) }; arg_578 = tmp8.Invoke_O__O(tmp9); if linked_575 == nil { return ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { return linked_575.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) } } else { var tmp10 any; var root_587 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__1822000051__3; if linked_588 == nil { tmp10 = ifn_589.Invoke_O__O(arg_590) } else { tmp10 = linked_588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_587, arg_590) }; s__1822000051__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Ctor_O_O_I_O(c__b__1822000053, c__ns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000053 = c__b__1822000053; t.F_ns = c__ns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Invoke_O__O(self any) any { { var i__1822000052__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000052__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000057__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000052__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_514 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_516 lang.IFn
																if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = v__4; if linked_515 == nil { and__1927000168__auto____5 = ifn_516.Invoke_O__O(arg_517) } else { and__1927000168__auto____5 = linked_515.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_514, arg_517) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any = t.F_ns; var and__1927000168__auto____6 bool = lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.Var_Cast(v__4).F_ns.Ref()); if and__1927000168__auto____6 { var root_518 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = lang.IFn_Cast(A_arbace_go_A_const_87.GetRawRoot__O()).Invoke_O__O(v__4); if linked_519 == nil { tmp2 = ifn_520.Invoke_O__O(arg_521) } else { tmp2 = linked_519.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_518, arg_521) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = and__1927000168__auto____5 }
//line :165:1
	if jrt.J2g_Truth(tmp2) { var root_526 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = t.F_b__1822000053; var arg_530 any; var root_531 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_533 lang.IFn

		if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = s__3; if linked_532 == nil { arg_530 = ifn_533.Invoke_O__O(arg_534) } else { arg_530 = linked_532.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_531, arg_534) }
//line :165:1
		if linked_527 == nil { ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { linked_527.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_526, arg_529, arg_530) }; i__1822000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000052__1); continue L1 } else { i__1822000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000052__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_New() *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A) Invoke_O_O__O(self, s__1822000067__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_New_O_O(s__1822000067__1, self); var tmp2 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class = fncls__663d; tmp2 = fncls__663d } else { tmp2 = fncls__663 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :169:1
func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A) Ctor_O_O(c__s__1822000067, c__iter__1822000066 any) { t.F_s__1822000067 = c__s__1822000067; t.F_iter__1822000066 = c__iter__1822000066 }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A) Invoke_O__O(self any) any { { var s__1822000067__1 any; var t_ any = t.F_s__1822000067; t.F_s__1822000067 = nil; s__1822000067__1 = t_; for { var temp__1927000414__auto____2 any; var root_598 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = s__1822000067__1; if linked_599 == nil { temp__1927000414__auto____2 = ifn_600.Invoke_O__O(arg_601) } else { temp__1927000414__auto____2 = linked_599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000067__3 any = temp__1927000414__auto____2; var tmp1 any; var root_602 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__1822000067__3; if linked_603 == nil { tmp1 = ifn_604.Invoke_O__O(arg_605) } else { tmp1 = linked_603.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_602, arg_605) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_606 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = s__1822000067__3; if linked_607 == nil { c__1927001037__auto____4 = ifn_608.Invoke_O__O(arg_609) } else { c__1927001037__auto____4 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_606, arg_609) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000069__6 any; var root_610 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_611 == nil { b__1822000069__6 = ifn_612.Invoke_O__O(arg_613) } else { b__1822000069__6 = linked_611.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_610, arg_613) }; var tmp2 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_New_O_I_O(b__1822000069__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class = fncls__623d; tmp3 = fncls__623d } else { tmp3 = fncls__623 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_624 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any; var root_629 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = b__1822000069__6; if linked_630 == nil { arg_627 = ifn_631.Invoke_O__O(arg_632) } else { arg_627 = linked_630.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_629, arg_632) }; var arg_628 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000066); var tmp5 any; var root_633 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = s__1822000067__3; if linked_634 == nil { tmp5 = ifn_635.Invoke_O__O(arg_636) } else { tmp5 = linked_634.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_633, arg_636) }; arg_628 = tmp4.Invoke_O__O(tmp5); if linked_625 == nil { return ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { return linked_625.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) } } else { var root_637 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any; var root_642 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = b__1822000069__6; if linked_643 == nil { arg_640 = ifn_644.Invoke_O__O(arg_645) } else { arg_640 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_642, arg_645) }; var arg_641 any; if linked_638 == nil { return ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { return linked_638.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) } } } else { var vec__1822000077__4 any; var root_646 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__1822000067__3; if linked_647 == nil { vec__1822000077__4 = ifn_648.Invoke_O__O(arg_649) } else { vec__1822000077__4 = linked_647.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_646, arg_649) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_650 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var tmp6 any; var root_655 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = k__5; if linked_656 == nil { tmp6 = ifn_657.Invoke_O__O(arg_658) } else { tmp6 = linked_656.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_655, arg_658) }; arg_653 = lang.Tuple_Create_O_O__IPersistentVector(n__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6, h__7)); var arg_654 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1822000066); var tmp8 any; var root_659 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = s__1822000067__3; if linked_660 == nil { tmp8 = ifn_661.Invoke_O__O(arg_662) } else { tmp8 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; arg_654 = tmp7.Invoke_O__O(tmp8); if linked_651 == nil { return ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { return linked_651.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A) Ctor_O_I_O(c__b__1822000069 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000069 = c__b__1822000069; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A) Invoke_O__O(self any) any { { var i__1822000068__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000068__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000073__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000068__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_614 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = t.F_b__1822000069; var arg_618 any; var tmp2 any; var root_619 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = k__3; if linked_620 == nil { tmp2 = ifn_621.Invoke_O__O(arg_622) } else { tmp2 = linked_620.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_619, arg_622) }; arg_618 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.Tuple_Create_O_O__IPersistentVector(tmp2, h__5)); if linked_615 == nil { ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { linked_615.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; i__1822000068__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000068__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__fn__1822000082_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000082_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000082_A{}; t.Ctor_O(p0); return t }
//line :170:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000082_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :170:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000082_A) Invoke_O__O(self any) any { var root_670 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, A_arbace_go_digest_info_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var t_ any = t.F_p; t.F_p = nil; arg_673 = t_; if linked_671 == nil { return ifn_672.Invoke_O__O(arg_673) } else { return linked_671.(*A_arbace_go_digest_info_A).Invoke_O_O__O(root_670, arg_673) } }
func A_arbace_go_table_ns_BANG__fn__1822000084_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__fn__1822000084_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_A{}; t.Ctor_O_O(p0, p1); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_A) Ctor_O_O(c__info, c__members any) { t.F_info = c__info; t.F_members = c__members }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_A) Invoke_O__O(self any) any { var root_675 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_679 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_New_O(t.F_members); var tmp2 *jrt.Class; var fncls__774 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class; if fncls__774 == nil { var fncls__774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class = fncls__774d; tmp2 = fncls__774d } else { tmp2 = fncls__774 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_775 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var t_ any = t.F_info; t.F_info = nil; arg_778 = t_; if linked_776 == nil { tmp4 = ifn_777.Invoke_O__O(arg_778) } else { tmp4 = linked_776.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_775, arg_778) }; arg_679 = tmp3.Invoke_O__O(tmp4); if linked_676 == nil { return ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { return linked_676.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) } }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A{}; t.Ctor_O(p0); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A) Ctor_O(c__members any) { t.F_members = c__members }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A) Invoke_O_O__O(self, s__1822000086__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_New_O_O_O(t.F_members, s__1822000086__1, self); var tmp2 *jrt.Class; var fncls__773 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class; if fncls__773 == nil { var fncls__773d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class = fncls__773d; tmp2 = fncls__773d } else { tmp2 = fncls__773 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A) Ctor_O_O_O(c__members, c__s__1822000086, c__iter__1822000085 any) { t.F_members = c__members; t.F_s__1822000086 = c__s__1822000086; t.F_iter__1822000085 = c__iter__1822000085 }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A) Invoke_O__O(self any) any { { var s__1822000086__1 any; var t_ any = t.F_s__1822000086; t.F_s__1822000086 = nil; s__1822000086__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_680 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = s__1822000086__1; if linked_681 == nil { temp__1927000414__auto____2 = ifn_682.Invoke_O__O(arg_683) } else { temp__1927000414__auto____2 = linked_681.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_680, arg_683) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000086__3 any = temp__1927000414__auto____2; var tmp1 any; var root_684 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = s__1822000086__3; if linked_685 == nil { tmp1 = ifn_686.Invoke_O__O(arg_687) } else { tmp1 = linked_685.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_684, arg_687) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_688 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = s__1822000086__3; if linked_689 == nil { c__1927001037__auto____4 = ifn_690.Invoke_O__O(arg_691) } else { c__1927001037__auto____4 = linked_689.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_688, arg_691) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000088__6 any; var root_692 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_693 == nil { b__1822000088__6 = ifn_694.Invoke_O__O(arg_695) } else { b__1822000088__6 = linked_693.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_692, arg_695) }; var tmp2 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_New_O_O_I_O(b__1822000088__6, t.F_members, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__715 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class; if fncls__715 == nil { var fncls__715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class = fncls__715d; tmp3 = fncls__715d } else { tmp3 = fncls__715 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_716 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var root_721 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = b__1822000088__6; if linked_722 == nil { arg_719 = ifn_723.Invoke_O__O(arg_724) } else { arg_719 = linked_722.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_721, arg_724) }; var arg_720 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000085); var tmp5 any; var root_725 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__1822000086__3; if linked_726 == nil { tmp5 = ifn_727.Invoke_O__O(arg_728) } else { tmp5 = linked_726.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_725, arg_728) }; arg_720 = tmp4.Invoke_O__O(tmp5); if linked_717 == nil { return ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { return linked_717.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_716, arg_719, arg_720) } } else { var root_729 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any; var root_734 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = b__1822000088__6; if linked_735 == nil { arg_732 = ifn_736.Invoke_O__O(arg_737) } else { arg_732 = linked_735.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_734, arg_737) }; var arg_733 any; if linked_730 == nil { return ifn_731.Invoke_O_O__O(arg_732, arg_733) } else { return linked_730.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_729, arg_732, arg_733) } } } else { var vec__1822000096__4 any; var root_738 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = s__1822000086__3; if linked_739 == nil { vec__1822000096__4 = ifn_740.Invoke_O__O(arg_741) } else { vec__1822000096__4 = linked_739.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_738, arg_741) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000096__4, lang.RT_IntCast_J__I_NoInit(0), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000096__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_742 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = i__6; var arg_746 any = A_arbace_go_A_const_68; if linked_743 == nil { tmp6 = ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { tmp6 = linked_743.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_742, arg_745, arg_746) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_747 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any; var root_751 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = t.F_members; var arg_755 any = n__5; if linked_752 == nil { arg_750 = ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { arg_750 = linked_752.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_751, arg_754, arg_755) }; if linked_748 == nil { tmp7 = ifn_749.Invoke_O__O(arg_750) } else { tmp7 = linked_748.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_747, arg_750) }; if jrt.J2g_Truth(tmp7) { var root_756 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, i__6); var arg_760 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000085); var tmp9 any; var root_761 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = s__1822000086__3; if linked_762 == nil { tmp9 = ifn_763.Invoke_O__O(arg_764) } else { tmp9 = linked_762.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_761, arg_764) }; arg_760 = tmp8.Invoke_O__O(tmp9); if linked_757 == nil { return ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { return linked_757.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) } } else { var tmp10 any; var root_765 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = s__1822000086__3; if linked_766 == nil { tmp10 = ifn_767.Invoke_O__O(arg_768) } else { tmp10 = linked_766.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_765, arg_768) }; s__1822000086__1 = tmp10; continue L1 } } else { var tmp11 any; var root_769 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = s__1822000086__3; if linked_770 == nil { tmp11 = ifn_771.Invoke_O__O(arg_772) } else { tmp11 = linked_770.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_769, arg_772) }; s__1822000086__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A) Ctor_O_O_I_O(c__b__1822000088, c__members any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000088 = c__b__1822000088; t.F_members = c__members; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A) Invoke_O__O(self any) any { { var i__1822000087__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000087__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000092__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000087__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000092__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000092__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_696 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = i__4; var arg_700 any = A_arbace_go_A_const_68; if linked_697 == nil { tmp2 = ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { tmp2 = linked_697.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_696, arg_699, arg_700) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_701 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any; var root_705 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = t.F_members; var arg_709 any = n__3; if linked_706 == nil { arg_704 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { arg_704 = linked_706.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }; if linked_702 == nil { tmp3 = ifn_703.Invoke_O__O(arg_704) } else { tmp3 = linked_702.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_701, arg_704) }; if jrt.J2g_Truth(tmp3) { var root_710 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = t.F_b__1822000088; var arg_714 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, i__4); if linked_711 == nil { ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { linked_711.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) }; i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } else { i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } } else { i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__make__1822000102_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_table_ns_BANG__make__1822000102_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__make__1822000102_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :172:1
func (t *A_arbace_go_table_ns_BANG__make__1822000102_A) Ctor_O_O_O_O_O(c__ns, c__info, c__consts, c__p, c__members any) { t.F_ns = c__ns; t.F_info = c__info; t.F_consts = c__consts; t.F_p = c__p; t.F_members = c__members }
//line :172:1
func (t *A_arbace_go_table_ns_BANG__make__1822000102_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_members, n__1); if
												jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1822000103__3 any = temp__1927000408__auto____2; var kind__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000103__3, lang.RT_IntCast_J__I_NoInit(0), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000103__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_780 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, A_arbace_go_member_var_A_fn_class); var ifn_782 lang.IFn
													if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = t.F_ns; var arg_784 any = t.F_p; var arg_785 any = n__1; var arg_786 any = kind__4; var arg_787 any = h__5; var arg_788 any; var tmp1 any; var root_789 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = t.F_info; if linked_790 == nil { tmp1 = ifn_791.Invoke_O__O(arg_792) } else { tmp1 = linked_790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_789, arg_792) }; arg_788 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if linked_781 == nil { return ifn_782.Invoke_O_O_O_O_O_O__O(arg_783, arg_784, arg_785, arg_786, arg_787, arg_788) } else { return linked_781.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_780, arg_783, arg_784, arg_785, arg_786, arg_787, arg_788) } } else {
//line :173:1
			var temp__1927000408__auto____3 any; var tmp2 any; var root_793 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_795 lang.IFn

			if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = t.F_consts; if linked_794 == nil { tmp2 = ifn_795.Invoke_O__O(arg_796) } else { tmp2 = linked_794.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_793, arg_796) }; temp__1927000408__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__1); if jrt.J2g_Truth(temp__1927000408__auto____3) { var i__4 any = temp__1927000408__auto____3; var root_797 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, A_arbace_go_member_var_A_fn_class); var ifn_799 lang.IFn
				if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = t.F_ns; var arg_801 any = t.F_p; var arg_802 any = n__1; var arg_803 any = A_arbace_go_A_const_68; var arg_804 any; var arg_805 any = i__4; if linked_798 == nil { return ifn_799.Invoke_O_O_O_O_O_O__O(arg_800, arg_801, arg_802, arg_803, arg_804, arg_805) } else { return linked_798.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_797, arg_800, arg_801, arg_802, arg_803, arg_804, arg_805) } } else {


					var tmp3 *lang.Keyword = A_arbace_go_A_const_66; var tmp4 any; var root_806 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = t.F_info; if linked_807 == nil { tmp4 = ifn_808.Invoke_O__O(arg_809) } else { tmp4 = linked_807.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_806, arg_809) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(tmp4, n__1))) {
						var tmp5 any; var root_810 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, A_arbace_go_repl_fn_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = Lit_66; if linked_811 == nil { tmp5 = ifn_812.Invoke_O__O(arg_813) } else { tmp5 = linked_811.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_810, arg_813) }; var tmp6 lang.IFn = lang.IFn_Cast(tmp5); var tmp7 any = t.F_ns; var tmp8 any = t.F_p; var tmp9 any; var root_814 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = t.F_info; if linked_815 == nil { tmp9 = ifn_816.Invoke_O__O(arg_817) } else { tmp9 = linked_815.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_814, arg_817) }; return tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, n__1, lang.RT_Get_O_O__O_NoInit(tmp9, n__1)) } else {
//line :179:1
							return nil } } } }

func A_arbace_go_table_ns_BANG__resolver__1822000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__resolver__1822000107_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__resolver__1822000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Ctor_O_O_O(c__make, c__consts, c__members any) { t.F_make = c__make; t.F_consts = c__consts; t.F_members = c__members }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Invoke_O_O_O__O(self, ___1, sym__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(t.F_make); var tmp2 any; var root_819 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = sym__2; if linked_820 == nil { tmp2 = ifn_821.Invoke_O__O(arg_822) } else { tmp2 = linked_820.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_819, arg_822) }; return tmp1.Invoke_O__O(tmp2) }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Invoke_O_O__O(self, ___1 any) any { { var seq_1822000108__2 any; var root_823 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_825 lang.IFn

	if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var root_827 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any; var root_831 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var root_836 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = t.F_members; if linked_837 == nil { arg_834 = ifn_838.Invoke_O__O(arg_839) } else { arg_834 = linked_837.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_836, arg_839) }; var arg_835 any; var root_840 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any; var root_844 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = t.F_consts; if linked_845 == nil { arg_843 = ifn_846.Invoke_O__O(arg_847) } else { arg_843 = linked_845.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_844, arg_847) }; if linked_841 == nil { arg_835 = ifn_842.Invoke_O__O(arg_843) } else { arg_835 = linked_841.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_840, arg_843) }; if linked_832 == nil { arg_830 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { arg_830 = linked_832.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; if linked_828 == nil { arg_826 = ifn_829.Invoke_O__O(arg_830) } else { arg_826 = linked_828.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_827, arg_830) }; if linked_824 == nil { seq_1822000108__2 = ifn_825.Invoke_O__O(arg_826) } else { seq_1822000108__2 = linked_824.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_823, arg_826) }
//line :181:1
	var chunk_1822000109__3 any; var count_1822000110__4 int64 = 0; var i_1822000111__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000111__5, count_1822000110__4) { var n__6 any = lang.Indexed_Cast(chunk_1822000109__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000111__5))
			lang.IFn_Cast(t.F_make).Invoke_O__O(n__6)
//line :183:1
			seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000111__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_848 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = seq_1822000108__2; if linked_849 == nil { temp__1927000414__auto____6 = ifn_850.Invoke_O__O(arg_851) } else { temp__1927000414__auto____6 = linked_849.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_848, arg_851) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1822000108__7 any = temp__1927000414__auto____6; var tmp1 any; var root_852 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = seq_1822000108__7; if linked_853 == nil { tmp1 = ifn_854.Invoke_O__O(arg_855) } else { tmp1 = linked_853.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_856 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = seq_1822000108__7; if linked_857 == nil { c__1927000678__auto____8 = ifn_858.Invoke_O__O(arg_859) } else { c__1927000678__auto____8 = linked_857.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_856, arg_859) }; var tmp2 any; var root_864 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = seq_1822000108__7; if linked_865 == nil { tmp2 = ifn_866.Invoke_O__O(arg_867) } else { tmp2 = linked_865.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_864, arg_867) }; seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_860 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = seq_1822000108__7; if linked_861 == nil { n__8 = ifn_862.Invoke_O__O(arg_863) } else { n__8 = linked_861.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_860, arg_863) }
				lang.IFn_Cast(t.F_make).Invoke_O__O(n__8)
//line :183:1
				var tmp3 any; var root_868 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = seq_1822000108__7; if linked_869 == nil { tmp3 = ifn_870.Invoke_O__O(arg_871) } else { tmp3 = linked_869.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_868, arg_871) }; seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :181:1*/panic("j2g: unreachable") }









func A_arbace_go_interpretable_ns_BANG__A_New() *A_arbace_go_interpretable_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_interpretable_ns_BANG__A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Ctor() {}
//line :191:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any {





	var tmp1 *jrt.Boolean; var tmp2 any; var root_901 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_go_repl_fn_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = Lit_29; if linked_902 == nil { tmp2 = ifn_903.Invoke_O__O(arg_904) } else { tmp2 = linked_902.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_901, arg_904) }; if jrt.J2g_Truth(lang.IFn_Cast(tmp2).Invoke_O__O(p__0)) {
		var tmp3 any; var root_905 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_go_repl_fn_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = Lit_30; if linked_906 == nil { tmp3 = ifn_907.Invoke_O__O(arg_908) } else { tmp3 = linked_906.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_905, arg_908) }; lang.IFn_Cast(tmp3).Invoke_O__O(p__0)
//line :197:1
		tmp1 = jrt.Boolean_TRUE } else { tmp1 = nil }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref())).Ref()
}


func A_arbace_go_packages_A_New() *A_arbace_go_packages_A { A_arbace_go_A_Init(); t := &A_arbace_go_packages_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_packages_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_packages_A) Invoke_O__O(self any) any {


	var root_909 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = lang.GoInterp_Paths__O1().Ref(); if linked_910 == nil { return ifn_911.Invoke_O__O(arg_912) } else { return linked_910.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_909, arg_912)
	}
}


func A_arbace_go_new_A_New() *A_arbace_go_new_A { A_arbace_go_A_Init(); t := &A_arbace_go_new_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_go_new_A) Ctor() {}
//line :209:1
func (t *A_arbace_go_new_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_NewValue_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_zero_A_New() *A_arbace_go_zero_A { A_arbace_go_A_Init(); t := &A_arbace_go_zero_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_zero_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_zero_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_Zero_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_type_of_A_New() *A_arbace_go_type_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_of_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_go_type_of_A) Ctor() {}
//line :219:1
func (t *A_arbace_go_type_of_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_TypeOf_O__O(v__0)
}
func A_arbace_go_str_A_New() *A_arbace_go_str_A { A_arbace_go_A_Init(); t := &A_arbace_go_str_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_str_A) Ctor() {}
//line :224:1
func (t *A_arbace_go_str_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_Str_O__String(v__0).Ref()
}
func A_arbace_go_spread_A_New() *A_arbace_go_spread_A { A_arbace_go_A_Init(); t := &A_arbace_go_spread_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_spread_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_spread_A) Invoke_O_O__O(self, xs__0 any) any {



	return lang.GoInterp_Spread_O__O(xs__0)
}
func A_arbace_go_assign_BANG__A_New() *A_arbace_go_assign_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_assign_BANG__A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_go_assign_BANG__A) Ctor() {}
//line :235:1
func (t *A_arbace_go_assign_BANG__A) Invoke_O_O_O__O(self, v__0, x__1 any) any {



	lang.GoInterp_Store_O_O__V(lang.GoVar_Cast(v__0).F_cell, x__1)
//line :235:1
	return x__1
}











func A_arbace_go_type_names_A_New() *A_arbace_go_type_names_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_go_type_names_A) Ctor() {}
//line :248:1
func (t *A_arbace_go_type_names_A) Invoke_O_O__O(self, ts__0 any) any { var root_913 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_917 any; var root_918 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = Lit_67; var arg_922 any; var root_923 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; var tmp1 any = A_arbace_go_type_names_fn__1822000127_A_New(); var tmp2 *jrt.Class; var fncls__928 *jrt.Class = A_arbace_go_type_names_fn__1822000127_A_fn_class; if fncls__928 == nil { var fncls__928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_type_names_fn__1822000127_A_fn_class = fncls__928d; tmp2 = fncls__928d } else { tmp2 = fncls__928 }; arg_926 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_927 any = ts__0; if linked_924 == nil { arg_922 = ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { arg_922 = linked_924.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) }; if linked_919 == nil { arg_917 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { arg_917 = linked_919.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if linked_914 == nil { return ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { return linked_914.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) } }
//line :248:1
func A_arbace_go_type_names_fn__1822000127_A_New() *A_arbace_go_type_names_fn__1822000127_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_fn__1822000127_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_go_type_names_fn__1822000127_A) Ctor() {}
//line :248:1
func (t *A_arbace_go_type_names_fn__1822000127_A) Invoke_O_O__O(self, p1__1822000126_SHARP___1 any) any { return jrt.NN(lang.GoType_Cast(p1__1822000126_SHARP___1)).GetName__String().Ref() }

func A_arbace_go_reify_type_A_New() *A_arbace_go_reify_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_type_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_reify_type_A) Ctor() {}
//line :250:1
func (t *A_arbace_go_reify_type_A) Invoke_O_O__O(self, ts__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_929 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_931 lang.IFn; if



	linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_go_A_const_104.GetRawRoot__O(); if linked_930 == nil { tmp1 = ifn_931.Invoke_O__O(arg_932) } else { tmp1 = linked_930.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_929, arg_932) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, ts__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var root_933 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_935 lang.IFn
		if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = lang.GoInterp_ReifyType_O1__O1(lang.RT_Object_array_O__O1_NoInit(ts__0)).Ref(); if linked_934 == nil { r__3 = ifn_935.Invoke_O__O(arg_936) } else { r__3 = linked_934.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_933, arg_936) }
		var root_937 any = A_arbace_go_A_const_105.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = A_arbace_go_A_const_104.GetRawRoot__O(); var arg_941 any = A_arbace_go_A_const_62.GetRawRoot__O(); var arg_942 any = ts__0; var arg_943 any = r__3; if linked_938 == nil { ifn_939.Invoke_O_O_O_O__O(arg_940, arg_941, arg_942, arg_943) } else { linked_938.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_937, arg_940, arg_941, arg_942, arg_943) }
//line :254:1
		return r__3 } }




func A_arbace_go_reify_data_A_New() *A_arbace_go_reify_data_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_reify_data_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_reify_data_A) Invoke_O_O_O_O__O(self, rt__0, ts__1, fns__2 any) any { var vec__1822000131__4 any = rt__0; var seq__1822000132__5 any; var root_944 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_946 lang.IFn; if




	linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = vec__1822000131__4; if linked_945 == nil { seq__1822000132__5 = ifn_946.Invoke_O__O(arg_947) } else { seq__1822000132__5 = linked_945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_944, arg_947) }; var first__1822000133__6 any; var root_948 any = /*line :259:1*/A_arbace_go_A_const_25.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_950 lang.IFn; if




	linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = seq__1822000132__5; if linked_949 == nil { first__1822000133__6 = ifn_950.Invoke_O__O(arg_951) } else { first__1822000133__6 = linked_949.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_948, arg_951) }; var seq__1822000132__7 any; var root_952 any = /*line :259:1*/A_arbace_go_A_const_22.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_954 lang.IFn; if




	linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = seq__1822000132__5; if linked_953 == nil { seq__1822000132__7 = ifn_954.Invoke_O__O(arg_955) } else { seq__1822000132__7 = linked_953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_952, arg_955) }; var t__8 any = first__1822000133__6; var names__9 any = seq__1822000132__7; var seq_1822000134__10 any; var root_1028 any = /*line :259:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1030 lang.IFn; if





	linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var root_1032 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = fns__2; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O__O(arg_1035) } else { arg_1031 = linked_1033.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1032, arg_1035) }; if linked_1029 == nil { seq_1822000134__10 = ifn_1030.Invoke_O__O(arg_1031) } else { seq_1822000134__10 = linked_1029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1028, arg_1031) }; var chunk_1822000135__11 any; var count_1822000136__12 int64 = 0; var i_1822000137__13 int64 = 0; L1:
//line :259:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000137__13, count_1822000136__12) { var k__14 any = lang.Indexed_Cast(chunk_1822000135__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000137__13)); var tmp1 any; var root_1052 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1054 lang.IFn
			if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__14)); var arg_1056 any = names__9; if linked_1053 == nil { tmp1 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { tmp1 = linked_1053.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp3 any; var root_1057 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, A_arbace_go_type_names_A_fn_class); var ifn_1059 lang.IFn

				if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = ts__1; if linked_1058 == nil { tmp3 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp3 = linked_1058.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1057, arg_1060) }
//line :266:1
				panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__14, nil, tmp3))))) }
//line :265:1
			seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000137__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_1036 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = seq_1822000134__10; if linked_1037 == nil { temp__1927000414__auto____14 = ifn_1038.Invoke_O__O(arg_1039) } else { temp__1927000414__auto____14 = linked_1037.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1036, arg_1039) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000134__15 any = temp__1927000414__auto____14; var tmp4 any; var root_1040 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = seq_1822000134__15; if linked_1041 == nil { tmp4 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp4 = linked_1041.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1040, arg_1043) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____16 any; var root_1044 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = seq_1822000134__15; if linked_1045 == nil { c__1927000678__auto____16 = ifn_1046.Invoke_O__O(arg_1047) } else { c__1927000678__auto____16 = linked_1045.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1044, arg_1047) }; var tmp5 any; var root_1061 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = seq_1822000134__15; if linked_1062 == nil { tmp5 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp5 = linked_1062.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1061, arg_1064) }; seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = tmp5, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__16 any; var root_1048 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = seq_1822000134__15; if linked_1049 == nil { k__16 = ifn_1050.Invoke_O__O(arg_1051) } else { k__16 = linked_1049.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1048, arg_1051) }
				var tmp6 any; var root_1065 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__16)); var arg_1069 any = names__9; if linked_1066 == nil { tmp6 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { tmp6 = linked_1066.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; if jrt.J2g_Truth(tmp6) { } else { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp8 any; var root_1070 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_go_type_names_A_fn_class); var ifn_1072 lang.IFn

					if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = ts__1; if linked_1071 == nil { tmp8 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp8 = linked_1071.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1070, arg_1073) }
//line :266:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, k__16, nil, tmp8))))) }
//line :265:1
				var tmp9 any; var root_1074 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = seq_1822000134__15; if linked_1075 == nil { tmp9 = ifn_1076.Invoke_O__O(arg_1077) } else { tmp9 = linked_1075.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1074, arg_1077) }; seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = tmp9, nil, 0, 0; continue L1 } } }
//line :259:1
		break L1 }; var tmp10 any; var root_956 any =









	A_arbace_go_A_const_92.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_958 lang.IFn; if
	linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = t__8; var arg_960 any; var iter__1927001039__auto____10 any; var tmp11 any = A_arbace_go_reify_data_iter__1822000138__1822000142_A_New_O_O(fns__2, ts__1); var tmp12 *jrt.Class; var fncls__1027 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class; if fncls__1027 == nil { var fncls__1027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class = fncls__1027d; tmp12 = fncls__1027d } else { tmp12 = fncls__1027 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_960 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(names__9); if linked_957 == nil { tmp10 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { tmp10 = linked_957.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; return /*line :269:1*/ lang.RT_Object_array_O__O1_NoInit(tmp10).Ref() }
func A_arbace_go_reify_data_iter__1822000138__1822000142_A_New_O_O(p0, p1 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_A) Ctor_O_O(c__fns, c__ts any) { t.F_fns = c__fns; t.F_ts = c__ts }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_A) Invoke_O_O__O(self, s__1822000139__1 any) any { var tmp1 any = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_New_O_O_O_O(s__1822000139__1, self, t.F_fns, t.F_ts); var tmp2 *jrt.Class; var fncls__1026 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class; if fncls__1026 == nil { var fncls__1026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class = fncls__1026d; tmp2 = fncls__1026d } else { tmp2 = fncls__1026 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :270:1
func A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A) Ctor_O_O_O_O(c__s__1822000139, c__iter__1822000138, c__fns, c__ts any) { t.F_s__1822000139 = c__s__1822000139; t.F_iter__1822000138 = c__iter__1822000138; t.F_fns = c__fns; t.F_ts = c__ts }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A) Invoke_O__O(self any) any { { var s__1822000139__1 any; var t_ any = t.F_s__1822000139; t.F_s__1822000139 = nil; s__1822000139__1 = t_; for { var temp__1927000414__auto____2 any; var root_961 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = s__1822000139__1; if linked_962 == nil { temp__1927000414__auto____2 = ifn_963.Invoke_O__O(arg_964) } else { temp__1927000414__auto____2 = linked_962.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_961, arg_964) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000139__3 any = temp__1927000414__auto____2; var tmp1 any; var root_965 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = s__1822000139__3; if linked_966 == nil { tmp1 = ifn_967.Invoke_O__O(arg_968) } else { tmp1 = linked_966.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_965, arg_968) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_969 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__1822000139__3; if linked_970 == nil { c__1927001037__auto____4 = ifn_971.Invoke_O__O(arg_972) } else { c__1927001037__auto____4 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_969, arg_972) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000141__6 any; var root_973 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_974 == nil { b__1822000141__6 = ifn_975.Invoke_O__O(arg_976) } else { b__1822000141__6 = linked_974.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_973, arg_976) }; var tmp2 any = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_New_O_O_I_O_O(b__1822000141__6, t.F_fns, size__1927001038__auto____5, t.F_ts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__986 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class; if fncls__986 == nil { var fncls__986d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class = fncls__986d; tmp3 = fncls__986d } else { tmp3 = fncls__986 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_987 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var root_992 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = b__1822000141__6; if linked_993 == nil { arg_990 = ifn_994.Invoke_O__O(arg_995) } else { arg_990 = linked_993.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_992, arg_995) }; var arg_991 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000138); var tmp5 any; var root_996 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = s__1822000139__3; if linked_997 == nil { tmp5 = ifn_998.Invoke_O__O(arg_999) } else { tmp5 = linked_997.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_996, arg_999) }; arg_991 = tmp4.Invoke_O__O(tmp5); if linked_988 == nil { return ifn_989.Invoke_O_O__O(arg_990, arg_991) } else { return linked_988.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_987, arg_990, arg_991) } } else { var root_1000 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any; var root_1005 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = b__1822000141__6; if linked_1006 == nil { arg_1003 = ifn_1007.Invoke_O__O(arg_1008) } else { arg_1003 = linked_1006.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1005, arg_1008) }; var arg_1004 any; if linked_1001 == nil { return ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { return linked_1001.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) } } } else { var n__4 any; var root_1009 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = s__1822000139__3; if linked_1010 == nil { n__4 = ifn_1011.Invoke_O__O(arg_1012) } else { n__4 = linked_1010.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1009, arg_1012) }; var root_1013 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__4)
														if jrt.J2g_Truth(or__1927000174__auto____5) { arg_1016 = or__1927000174__auto____5 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp7 any; var root_1018 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_go_type_names_A_fn_class); var ifn_1020 lang.IFn

		if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = t.F_ts; if linked_1019 == nil { tmp7 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp7 = linked_1019.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1018, arg_1021) }
//line :271:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp7, nil))))) }
//line :270:1
	var arg_1017 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000138); var tmp9 any; var root_1022 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = s__1822000139__3; if linked_1023 == nil { tmp9 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp9 = linked_1023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1022, arg_1025) }; arg_1017 = tmp8.Invoke_O__O(tmp9); if linked_1014 == nil { return ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { return linked_1014.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A) Ctor_O_O_I_O_O(c__b__1822000141, c__fns any, c__size__1927001038__auto__ int32, c__ts, c__c__1927001037__auto__ any) { t.F_b__1822000141 = c__b__1822000141; t.F_fns = c__fns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ts = c__ts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A) Invoke_O__O(self any) any { { var i__1822000140__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000140__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000140__1)); var root_977 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = t.F_b__1822000141; var arg_981 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__2)
															if jrt.J2g_Truth(or__1927000174__auto____3) { arg_981 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp3 any; var root_982 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, A_arbace_go_type_names_A_fn_class); var ifn_984 lang.IFn

		if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = t.F_ts; if linked_983 == nil { tmp3 = ifn_984.Invoke_O__O(arg_985) } else { tmp3 = linked_983.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_982, arg_985) }
//line :271:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp3, nil))))) }
//line :270:1
	if linked_978 == nil { ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { linked_978.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }; i__1822000140__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000140__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_fn_A_New() *A_arbace_go_repl_fn_A { A_arbace_go_A_Init(); t := &A_arbace_go_repl_fn_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_go_repl_fn_A) Ctor() {}
//line :278:1
func (t *A_arbace_go_repl_fn_A) Invoke_O_O__O(self, nm__0 any) any { var root_1078 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any; var root_1082 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = Lit_50; var arg_1086 any = nm__0; if linked_1083 == nil { arg_1081 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { arg_1081 = linked_1083.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; if linked_1079 == nil { return ifn_1080.Invoke_O__O(arg_1081) } else { return linked_1079.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_1078, arg_1081) } }

func A_arbace_go_pos_of_A_New() *A_arbace_go_pos_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_pos_of_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_go_pos_of_A) Ctor() {}
//line :280:1
func (t *A_arbace_go_pos_of_A) Invoke_O_O__O(self, form__0 any) any { var root_1087 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__0); var arg_1091 any = A_arbace_go_A_const_110; if linked_1088 == nil { return ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) } }

func A_arbace_go_package_A_New() *A_arbace_go_package_A { A_arbace_go_A_Init(); t := &A_arbace_go_package_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_package_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_package_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_1092 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1103 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var root_1107 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_111); var arg_1111 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_32); if linked_1108 == nil { arg_1106 = ifn_1109.Invoke_O_O__O(arg_1110, arg_1111) } else { arg_1106 = linked_1108.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1107, arg_1110, arg_1111) }; if linked_1104 == nil { tmp3 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp3 = linked_1104.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1103, arg_1106) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1112 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any; var root_1116 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1120 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1121 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1123 lang.IFn; if


	linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = A_arbace_go_A_const_114.Get__O(); if linked_1122 == nil { tmp8 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp8 = linked_1122.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1121, arg_1124) }; arg_1120 = /*line :282:1*/tmp7.Invoke_O__O(tmp8); if linked_1117 == nil { arg_1115 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { arg_1115 = linked_1117.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; if linked_1113 == nil { tmp6 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp6 = linked_1113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1112, arg_1115) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1125 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var root_1129 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1133 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); if linked_1130 == nil { arg_1128 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { arg_1128 = linked_1130.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; if linked_1126 == nil { tmp11 = ifn_1127.Invoke_O__O(arg_1128) } else { tmp11 = linked_1126.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1134 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var root_1138 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1142 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1143 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1145 lang.IFn; if


	linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = opts__3; if linked_1144 == nil { tmp16 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp16 = linked_1144.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1143, arg_1146) }; arg_1142 = /*line :282:1*/tmp15.Invoke_O__O(tmp16); if linked_1139 == nil { arg_1137 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { arg_1137 = linked_1139.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) }; if linked_1135 == nil { tmp14 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp14 = linked_1135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1134, arg_1137) }; arg_1095 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1093 == nil { return ifn_1094.Invoke_O__O(arg_1095) } else { return linked_1093.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1092, arg_1095) } }




func A_arbace_go_file_A_New() *A_arbace_go_file_A { A_arbace_go_A_Init(); t := &A_arbace_go_file_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_go_file_A) Ctor() {}
//line :287:1
func (t *A_arbace_go_file_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_1147 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1158 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1162 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_115); var arg_1166 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_25); if linked_1163 == nil { arg_1161 = ifn_1164.Invoke_O_O__O(arg_1165, arg_1166) } else { arg_1161 = linked_1163.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1162, arg_1165, arg_1166) }; if linked_1159 == nil { tmp3 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp3 = linked_1159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1158, arg_1161) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1167 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any; var root_1171 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1175 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1176 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1178 lang.IFn; if


	linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = A_arbace_go_A_const_114.Get__O(); if linked_1177 == nil { tmp8 = ifn_1178.Invoke_O__O(arg_1179) } else { tmp8 = linked_1177.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1176, arg_1179) }; arg_1175 = /*line :287:1*/tmp7.Invoke_O__O(tmp8); if linked_1172 == nil { arg_1170 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { arg_1170 = linked_1172.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }; if linked_1168 == nil { tmp6 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp6 = linked_1168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1167, arg_1170) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp12 any; var root_1180 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any; var root_1184 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1188 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1189 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1191 lang.IFn; if


	linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = A_arbace_go_A_const_31.GetRawRoot__O(); var arg_1193 any = opts__3; if linked_1190 == nil { tmp14 = ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { tmp14 = linked_1190.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) }; arg_1188 = /*line :287:1*/tmp13.Invoke_O__O(tmp14); if linked_1185 == nil { arg_1183 = ifn_1186.Invoke_O_O__O(arg_1187, arg_1188) } else { arg_1183 = linked_1185.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1184, arg_1187, arg_1188) }; if linked_1181 == nil { tmp12 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp12 = linked_1181.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1180, arg_1183) }; arg_1150 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_1148 == nil { return ifn_1149.Invoke_O__O(arg_1150) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1147, arg_1150) } }




func A_arbace_go_declare_STAR__A_New() *A_arbace_go_declare_STAR__A { A_arbace_go_A_Init(); t := &A_arbace_go_declare_STAR__A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_declare_STAR__A) Ctor() {}
//line :292:1
func (t *A_arbace_go_declare_STAR__A) Invoke_O_O_O__O(self, form__0, opts__1 any) any {


	var tmp1 any; var root_1194 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, A_arbace_go_repl_fn_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = Lit_8; if linked_1195 == nil { tmp1 = ifn_1196.Invoke_O__O(arg_1197) } else { tmp1 = linked_1195.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1194, arg_1197) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(form__0, opts__1)
}
func A_arbace_go_func_A_New() *A_arbace_go_func_A { A_arbace_go_A_Init(); t := &A_arbace_go_func_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_go_func_A) Ctor() {}
//line :297:1
func (t *A_arbace_go_func_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1198 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_116); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1208 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1212 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1216 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1213 == nil { arg_1211 = ifn_1214.Invoke_O_O__O(arg_1215, arg_1216) } else { arg_1211 = linked_1213.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1212, arg_1215, arg_1216) }; if linked_1209 == nil { tmp4 = ifn_1210.Invoke_O__O(arg_1211) } else { tmp4 = linked_1209.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1208, arg_1211) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1217 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any; var root_1221 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1225 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1226 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1228 lang.IFn; if
														linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var root_1232 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_go_pos_of_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = _AMPERSAND_form__0; if linked_1233 == nil { arg_1229 = ifn_1234.Invoke_O__O(arg_1235) } else { arg_1229 = linked_1233.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1232, arg_1235) }; var arg_1230 any = A_arbace_go_A_const_118; var arg_1231 any; var root_1236 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = A_arbace_go_A_const_114.Get__O(); if linked_1237 == nil { arg_1231 = ifn_1238.Invoke_O__O(arg_1239) } else { arg_1231 = linked_1237.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1236, arg_1239) }; if linked_1227 == nil { tmp9 = ifn_1228.Invoke_O_O_O__O(arg_1229, arg_1230, arg_1231) } else { tmp9 = linked_1227.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1226, arg_1229, arg_1230, arg_1231) }; arg_1225 = /*line :297:1*/tmp8.Invoke_O__O(tmp9); if linked_1222 == nil { arg_1220 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { arg_1220 = linked_1222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) }; if linked_1218 == nil { tmp7 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp7 = linked_1218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1217, arg_1220) }; arg_1201 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1199 == nil { return ifn_1200.Invoke_O__O(arg_1201) } else { return linked_1199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1198, arg_1201) } }


func A_arbace_go_method_A_New() *A_arbace_go_method_A { A_arbace_go_A_Init(); t := &A_arbace_go_method_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_method_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_method_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1240 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_119); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1250 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any; var root_1254 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1258 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1255 == nil { arg_1253 = ifn_1256.Invoke_O_O__O(arg_1257, arg_1258) } else { arg_1253 = linked_1255.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1254, arg_1257, arg_1258) }; if linked_1251 == nil { tmp4 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp4 = linked_1251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1250, arg_1253) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1259 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any; var root_1263 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1267 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1268 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1270 lang.IFn; if
														linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any; var root_1274 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, A_arbace_go_pos_of_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = _AMPERSAND_form__0; if linked_1275 == nil { arg_1271 = ifn_1276.Invoke_O__O(arg_1277) } else { arg_1271 = linked_1275.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1274, arg_1277) }; var arg_1272 any = A_arbace_go_A_const_118; var arg_1273 any; var root_1278 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = A_arbace_go_A_const_114.Get__O(); if linked_1279 == nil { arg_1273 = ifn_1280.Invoke_O__O(arg_1281) } else { arg_1273 = linked_1279.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1278, arg_1281) }; if linked_1269 == nil { tmp9 = ifn_1270.Invoke_O_O_O__O(arg_1271, arg_1272, arg_1273) } else { tmp9 = linked_1269.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1268, arg_1271, arg_1272, arg_1273) }; arg_1267 = /*line :300:1*/tmp8.Invoke_O__O(tmp9); if linked_1264 == nil { arg_1262 = ifn_1265.Invoke_O_O__O(arg_1266, arg_1267) } else { arg_1262 = linked_1264.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1263, arg_1266, arg_1267) }; if linked_1260 == nil { tmp7 = ifn_1261.Invoke_O__O(arg_1262) } else { tmp7 = linked_1260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1259, arg_1262) }; arg_1243 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1241 == nil { return ifn_1242.Invoke_O__O(arg_1243) } else { return linked_1241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1240, arg_1243) } }


func A_arbace_go_type_A_New() *A_arbace_go_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_type_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_type_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1282 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_120); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1292 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any; var root_1296 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1300 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1297 == nil { arg_1295 = ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { arg_1295 = linked_1297.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) }; if linked_1293 == nil { tmp4 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp4 = linked_1293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1292, arg_1295) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1301 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var root_1305 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1309 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1310 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1312 lang.IFn; if
														linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var root_1316 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, A_arbace_go_pos_of_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = _AMPERSAND_form__0; if linked_1317 == nil { arg_1313 = ifn_1318.Invoke_O__O(arg_1319) } else { arg_1313 = linked_1317.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1316, arg_1319) }; var arg_1314 any = A_arbace_go_A_const_118; var arg_1315 any; var root_1320 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = A_arbace_go_A_const_114.Get__O(); if linked_1321 == nil { arg_1315 = ifn_1322.Invoke_O__O(arg_1323) } else { arg_1315 = linked_1321.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1320, arg_1323) }; if linked_1311 == nil { tmp9 = ifn_1312.Invoke_O_O_O__O(arg_1313, arg_1314, arg_1315) } else { tmp9 = linked_1311.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1310, arg_1313, arg_1314, arg_1315) }; arg_1309 = /*line :303:1*/tmp8.Invoke_O__O(tmp9); if linked_1306 == nil { arg_1304 = ifn_1307.Invoke_O_O__O(arg_1308, arg_1309) } else { arg_1304 = linked_1306.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1305, arg_1308, arg_1309) }; if linked_1302 == nil { tmp7 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp7 = linked_1302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1301, arg_1304) }; arg_1285 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1283 == nil { return ifn_1284.Invoke_O__O(arg_1285) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1282, arg_1285) } }


func A_arbace_go_var_A_New() *A_arbace_go_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_var_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_go_var_A) Ctor() {}
//line :306:1
func (t *A_arbace_go_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1324 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_121); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1334 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any; var root_1338 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1342 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1339 == nil { arg_1337 = ifn_1340.Invoke_O_O__O(arg_1341, arg_1342) } else { arg_1337 = linked_1339.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1338, arg_1341, arg_1342) }; if linked_1335 == nil { tmp4 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp4 = linked_1335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1334, arg_1337) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1343 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any; var root_1347 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1351 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1352 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1354 lang.IFn; if
														linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any; var root_1358 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, A_arbace_go_pos_of_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = _AMPERSAND_form__0; if linked_1359 == nil { arg_1355 = ifn_1360.Invoke_O__O(arg_1361) } else { arg_1355 = linked_1359.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1358, arg_1361) }; var arg_1356 any = A_arbace_go_A_const_118; var arg_1357 any; var root_1362 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = A_arbace_go_A_const_114.Get__O(); if linked_1363 == nil { arg_1357 = ifn_1364.Invoke_O__O(arg_1365) } else { arg_1357 = linked_1363.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1362, arg_1365) }; if linked_1353 == nil { tmp9 = ifn_1354.Invoke_O_O_O__O(arg_1355, arg_1356, arg_1357) } else { tmp9 = linked_1353.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1352, arg_1355, arg_1356, arg_1357) }; arg_1351 = /*line :306:1*/tmp8.Invoke_O__O(tmp9); if linked_1348 == nil { arg_1346 = ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { arg_1346 = linked_1348.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }; if linked_1344 == nil { tmp7 = ifn_1345.Invoke_O__O(arg_1346) } else { tmp7 = linked_1344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1343, arg_1346) }; arg_1327 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1325 == nil { return ifn_1326.Invoke_O__O(arg_1327) } else { return linked_1325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1324, arg_1327) } }


func A_arbace_go_const_A_New() *A_arbace_go_const_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_go_const_A) Ctor() {}
//line :309:1
func (t *A_arbace_go_const_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1366 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_122); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1376 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any; var root_1380 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1384 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1381 == nil { arg_1379 = ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { arg_1379 = linked_1381.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) }; if linked_1377 == nil { tmp4 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp4 = linked_1377.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1376, arg_1379) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1385 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any; var root_1389 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1393 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1394 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1396 lang.IFn; if
														linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any; var root_1400 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, A_arbace_go_pos_of_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = _AMPERSAND_form__0; if linked_1401 == nil { arg_1397 = ifn_1402.Invoke_O__O(arg_1403) } else { arg_1397 = linked_1401.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1400, arg_1403) }; var arg_1398 any = A_arbace_go_A_const_118; var arg_1399 any; var root_1404 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = A_arbace_go_A_const_114.Get__O(); if linked_1405 == nil { arg_1399 = ifn_1406.Invoke_O__O(arg_1407) } else { arg_1399 = linked_1405.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1404, arg_1407) }; if linked_1395 == nil { tmp9 = ifn_1396.Invoke_O_O_O__O(arg_1397, arg_1398, arg_1399) } else { tmp9 = linked_1395.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1394, arg_1397, arg_1398, arg_1399) }; arg_1393 = /*line :309:1*/tmp8.Invoke_O__O(tmp9); if linked_1390 == nil { arg_1388 = ifn_1391.Invoke_O_O__O(arg_1392, arg_1393) } else { arg_1388 = linked_1390.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1389, arg_1392, arg_1393) }; if linked_1386 == nil { tmp7 = ifn_1387.Invoke_O__O(arg_1388) } else { tmp7 = linked_1386.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1385, arg_1388) }; arg_1369 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1367 == nil { return ifn_1368.Invoke_O__O(arg_1369) } else { return linked_1367.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1366, arg_1369) } }


func A_arbace_go_directive_A_New() *A_arbace_go_directive_A { A_arbace_go_A_Init(); t := &A_arbace_go_directive_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_go_directive_A) Ctor() {}
//line :312:1
func (t *A_arbace_go_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_go_import_A_New() *A_arbace_go_import_A { A_arbace_go_A_Init(); t := &A_arbace_go_import_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_go_import_A) Ctor() {}
//line :314:1
func (t *A_arbace_go_import_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, specs__2 any) any { var root_1408 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1418 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any; var root_1422 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_123); var arg_1426 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_27); if linked_1423 == nil { arg_1421 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { arg_1421 = linked_1423.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; if linked_1419 == nil { tmp3 = ifn_1420.Invoke_O__O(arg_1421) } else { tmp3 = linked_1419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1418, arg_1421) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1427 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any; var root_1431 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1435 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1436 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1438 lang.IFn; if


	linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = A_arbace_go_A_const_114.Get__O(); if linked_1437 == nil { tmp8 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp8 = linked_1437.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1436, arg_1439) }; arg_1435 = /*line :314:1*/tmp7.Invoke_O__O(tmp8); if linked_1432 == nil { arg_1430 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { arg_1430 = linked_1432.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }; if linked_1428 == nil { tmp6 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp6 = linked_1428.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1427, arg_1430) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1440 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any; var root_1444 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1448 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any; var root_1449 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1451 lang.IFn; if


	linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = specs__2; if linked_1450 == nil { tmp13 = ifn_1451.Invoke_O__O(arg_1452) } else { tmp13 = linked_1450.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1449, arg_1452) }; arg_1448 = /*line :314:1*/tmp12.Invoke_O__O(tmp13); if linked_1445 == nil { arg_1443 = ifn_1446.Invoke_O_O__O(arg_1447, arg_1448) } else { arg_1443 = linked_1445.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1444, arg_1447, arg_1448) }; if linked_1441 == nil { tmp11 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp11 = linked_1441.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1440, arg_1443) }; arg_1411 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1409 == nil { return ifn_1410.Invoke_O__O(arg_1411) } else { return linked_1409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1408, arg_1411) } }




func A_arbace_go_inst_A_New() *A_arbace_go_inst_A { A_arbace_go_A_Init(); t := &A_arbace_go_inst_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_go_inst_A) Ctor() {}
//line :319:1
func (t *A_arbace_go_inst_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, f__2, types__3 any) any { var root_1453 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1464 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var root_1468 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_124); var arg_1472 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_28); if linked_1469 == nil { arg_1467 = ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { arg_1467 = linked_1469.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }; if linked_1465 == nil { tmp3 = ifn_1466.Invoke_O__O(arg_1467) } else { tmp3 = linked_1465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1464, arg_1467) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1473 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any; var root_1477 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1481 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1482 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1484 lang.IFn; if







	linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = A_arbace_go_A_const_114.Get__O(); if linked_1483 == nil { tmp8 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp8 = linked_1483.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1482, arg_1485) }; arg_1481 = /*line :319:1*/tmp7.Invoke_O__O(tmp8); if linked_1478 == nil { arg_1476 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { arg_1476 = linked_1478.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; if linked_1474 == nil { tmp6 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp6 = linked_1474.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1473, arg_1476) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1486 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any; var root_1490 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1494 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1491 == nil { arg_1489 = ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { arg_1489 = linked_1491.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) }; if linked_1487 == nil { tmp11 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp11 = linked_1487.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1486, arg_1489) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1495 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any; var root_1499 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1503 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1504 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1506 lang.IFn; if







	linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = types__3; if linked_1505 == nil { tmp16 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp16 = linked_1505.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1504, arg_1507) }; arg_1503 = /*line :319:1*/tmp15.Invoke_O__O(tmp16); if linked_1500 == nil { arg_1498 = ifn_1501.Invoke_O_O__O(arg_1502, arg_1503) } else { arg_1498 = linked_1500.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1499, arg_1502, arg_1503) }; if linked_1496 == nil { tmp14 = ifn_1497.Invoke_O__O(arg_1498) } else { tmp14 = linked_1496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1495, arg_1498) }; arg_1456 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1454 == nil { return ifn_1455.Invoke_O__O(arg_1456) } else { return linked_1454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1453, arg_1456) } }









func A_arbace_go_eval_A_New() *A_arbace_go_eval_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_eval_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_eval_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, stmts__2 any) any { var root_1508 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1518 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any; var root_1522 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_125); var arg_1526 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_17); if linked_1523 == nil { arg_1521 = ifn_1524.Invoke_O_O__O(arg_1525, arg_1526) } else { arg_1521 = linked_1523.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1522, arg_1525, arg_1526) }; if linked_1519 == nil { tmp3 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp3 = linked_1519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1518, arg_1521) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1527 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any; var root_1531 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1535 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1536 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1538 lang.IFn; if



	linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = stmts__2; if linked_1537 == nil { tmp8 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp8 = linked_1537.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1536, arg_1539) }; arg_1535 = /*line :329:1*/tmp7.Invoke_O__O(tmp8); if linked_1532 == nil { arg_1530 = ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { arg_1530 = linked_1532.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) }; if linked_1528 == nil { tmp6 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp6 = linked_1528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1527, arg_1530) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1540 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var root_1544 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1548 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any = A_arbace_go_A_const_118; var tmp14 any; var root_1549 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1551 lang.IFn; if



	linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = A_arbace_go_A_const_114.Get__O(); if linked_1550 == nil { tmp14 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp14 = linked_1550.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1549, arg_1552) }; arg_1548 = /*line :329:1*/tmp12.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14))); if linked_1545 == nil { arg_1543 = ifn_1546.Invoke_O_O__O(arg_1547, arg_1548) } else { arg_1543 = linked_1545.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1544, arg_1547, arg_1548) }; if linked_1541 == nil { tmp11 = ifn_1542.Invoke_O__O(arg_1543) } else { tmp11 = linked_1541.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1540, arg_1543) }; arg_1511 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1509 == nil { return ifn_1510.Invoke_O__O(arg_1511) } else { return linked_1509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1508, arg_1511) } }





func A_arbace_go_run_main_A_New() *A_arbace_go_run_main_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_main_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_go_run_main_A) Ctor() {}
//line :335:1
func (t *A_arbace_go_run_main_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1553 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, A_arbace_go_repl_fn_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = Lit_52; if linked_1554 == nil { tmp1 = ifn_1555.Invoke_O__O(arg_1556) } else { tmp1 = linked_1554.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1553, arg_1556) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
func A_arbace_go_run_compiled_A_New() *A_arbace_go_run_compiled_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_compiled_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_go_run_compiled_A) Ctor() {}
//line :340:1
func (t *A_arbace_go_run_compiled_A) DoInvoke_O_O_O__O(self, ns_sym__0, args__1 any) any {



	var tmp1 any; var root_1557 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, A_arbace_go_repl_fn_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = Lit_51; if linked_1558 == nil { tmp1 = ifn_1559.Invoke_O__O(arg_1560) } else { tmp1 = linked_1558.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1557, arg_1560) }; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var root_1561 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = args__1; if linked_1562 == nil { tmp3 = ifn_1563.Invoke_O__O(arg_1564) } else { tmp3 = linked_1562.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1561, arg_1564) }; return tmp2.Invoke_O_O__O(ns_sym__0, tmp3)
}
func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_go_check_A) Ctor() {}
//line :346:1
func (t *A_arbace_go_check_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1565 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, A_arbace_go_repl_fn_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = Lit_1; if linked_1566 == nil { tmp1 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp1 = linked_1566.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1565, arg_1568) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
























































































type A_arbace_go_A struct{ jrt.Object }

var A_arbace_go_A_const_pool *jrt.RefArray

var A_arbace_go_A_const_0 *lang.Var

var A_arbace_go_A_const_1 any

var A_arbace_go_A_const_2 *lang.Keyword

var A_arbace_go_A_const_3 any

var A_arbace_go_A_const_4 *lang.Var

var A_arbace_go_A_const_5 *lang.Var

var A_arbace_go_A_const_6 *lang.Var

var A_arbace_go_A_const_7 *lang.Var

var A_arbace_go_A_const_8 any

var A_arbace_go_A_const_9 *lang.Var

var A_arbace_go_A_const_10 *lang.Var

var A_arbace_go_A_const_11 *lang.Var

var A_arbace_go_A_const_12 *lang.Var

var A_arbace_go_A_const_13 *lang.Var

var A_arbace_go_A_const_14 *jrt.Class

var A_arbace_go_A_const_15 *lang.Keyword

var A_arbace_go_A_const_16 *lang.Var

var A_arbace_go_A_const_17 *lang.Var

var A_arbace_go_A_const_18 any

var A_arbace_go_A_const_19 *lang.Keyword

var A_arbace_go_A_const_20 *lang.Keyword

var A_arbace_go_A_const_21 *lang.Var

var A_arbace_go_A_const_22 *lang.Var

var A_arbace_go_A_const_23 *lang.Var

var A_arbace_go_A_const_24 *lang.Var

var A_arbace_go_A_const_25 *lang.Var

var A_arbace_go_A_const_26 *lang.Var

var A_arbace_go_A_const_27 any

var A_arbace_go_A_const_28 *lang.Keyword

var A_arbace_go_A_const_29 *lang.Var

var A_arbace_go_A_const_30 *lang.Var

var A_arbace_go_A_const_31 *lang.Var

var A_arbace_go_A_const_32 *lang.Var

var A_arbace_go_A_const_33 *lang.Var

var A_arbace_go_A_const_34 *lang.Var

var A_arbace_go_A_const_35 any

var A_arbace_go_A_const_36 any

var A_arbace_go_A_const_37 *lang.Var

var A_arbace_go_A_const_38 *lang.Keyword

var A_arbace_go_A_const_39 *lang.Var

var A_arbace_go_A_const_40 any

var A_arbace_go_A_const_41 *lang.Var

var A_arbace_go_A_const_42 *lang.Keyword

var A_arbace_go_A_const_43 *lang.Var

var A_arbace_go_A_const_44 *lang.Var

var A_arbace_go_A_const_45 *lang.Var

var A_arbace_go_A_const_46 *lang.Var

var A_arbace_go_A_const_47 *lang.Var

var A_arbace_go_A_const_48 *lang.Var

var A_arbace_go_A_const_49 *lang.Var

var A_arbace_go_A_const_50 any

var A_arbace_go_A_const_51 *lang.Var

var A_arbace_go_A_const_52 *lang.Var

var A_arbace_go_A_const_53 *lang.Var

var A_arbace_go_A_const_54 *lang.Var

var A_arbace_go_A_const_55 *lang.Var

var A_arbace_go_A_const_56 *lang.Var

var A_arbace_go_A_const_57 *lang.Var

var A_arbace_go_A_const_58 *lang.Var

var A_arbace_go_A_const_59 any

var A_arbace_go_A_const_60 *lang.Keyword

var A_arbace_go_A_const_61 any

var A_arbace_go_A_const_62 *lang.Var

var A_arbace_go_A_const_63 *lang.Keyword

var A_arbace_go_A_const_64 *lang.Keyword

var A_arbace_go_A_const_65 *lang.Var

var A_arbace_go_A_const_66 *lang.Keyword

var A_arbace_go_A_const_67 *lang.Var

var A_arbace_go_A_const_68 *lang.Keyword

var A_arbace_go_A_const_69 *lang.Var

var A_arbace_go_A_const_70 *lang.Keyword

var A_arbace_go_A_const_71 *lang.Keyword

var A_arbace_go_A_const_72 *lang.Var

var A_arbace_go_A_const_73 *lang.Keyword

var A_arbace_go_A_const_74 *lang.Keyword

var A_arbace_go_A_const_75 *lang.Var

var A_arbace_go_A_const_76 *lang.Var

var A_arbace_go_A_const_77 *lang.Keyword

var A_arbace_go_A_const_78 *lang.Keyword

var A_arbace_go_A_const_79 *lang.Keyword

var A_arbace_go_A_const_80 *lang.Keyword

var A_arbace_go_A_const_81 *lang.Var

var A_arbace_go_A_const_82 *lang.Var

var A_arbace_go_A_const_83 *lang.Var

var A_arbace_go_A_const_84 *lang.Var

var A_arbace_go_A_const_85 *lang.Var

var A_arbace_go_A_const_86 *lang.Var

var A_arbace_go_A_const_87 *lang.Var

var A_arbace_go_A_const_88 *lang.Var

var A_arbace_go_A_const_89 *lang.Var

var A_arbace_go_A_const_90 *lang.Var

var A_arbace_go_A_const_91 *lang.Var

var A_arbace_go_A_const_92 *lang.Var

var A_arbace_go_A_const_93 *lang.Var

var A_arbace_go_A_const_94 *lang.Var

var A_arbace_go_A_const_95 *lang.Var

var A_arbace_go_A_const_96 any

var A_arbace_go_A_const_97 *lang.Var

var A_arbace_go_A_const_98 *lang.Var

var A_arbace_go_A_const_99 *lang.Var

var A_arbace_go_A_const_100 *lang.Var

var A_arbace_go_A_const_101 *lang.Var

var A_arbace_go_A_const_102 *lang.Var

var A_arbace_go_A_const_103 *lang.Var

var A_arbace_go_A_const_104 *lang.Var

var A_arbace_go_A_const_105 *lang.Var

var A_arbace_go_A_const_106 *lang.Var

var A_arbace_go_A_const_107 *lang.Var

var A_arbace_go_A_const_108 *lang.Var

var A_arbace_go_A_const_109 *lang.Var

var A_arbace_go_A_const_110 any

var A_arbace_go_A_const_111 any

var A_arbace_go_A_const_112 any

var A_arbace_go_A_const_113 *lang.Var

var A_arbace_go_A_const_114 *lang.Var

var A_arbace_go_A_const_115 any

var A_arbace_go_A_const_116 any

var A_arbace_go_A_const_117 *lang.Var

var A_arbace_go_A_const_118 *lang.Keyword

var A_arbace_go_A_const_119 any

var A_arbace_go_A_const_120 any

var A_arbace_go_A_const_121 any

var A_arbace_go_A_const_122 any

var A_arbace_go_A_const_123 any

var A_arbace_go_A_const_124 any

var A_arbace_go_A_const_125 any

var A_arbace_go_A_init jrt.ClassInit

func A_arbace_go_A_Init() { if !A_arbace_go_A_init.Done() { A_arbace_go_A_init.Run(A_arbace_go_A_clinit) } }

func A_arbace_go_A_clinit() { A_arbace_go_A_clinit_p0(); A_arbace_go_A_clinit_p1(); A_arbace_go_A_clinit_p2(); A_arbace_go_A_clinit_p3(); A_arbace_go_A_clinit_p4(); A_arbace_go_A_clinit_p5(); A_arbace_go_A_clinit_p6(); A_arbace_go_A_clinit_p7(); A_arbace_go_A_clinit_p8(); A_arbace_go_A_clinit_p9(); A_arbace_go_A_clinit_p10() }

func A_arbace_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_go_A_const_0 = lang.Var_Cast(A_arbace_go_A_const_pool.A[37]); A_arbace_go_A_const_1 = A_arbace_go_A_const_pool.A[38]; A_arbace_go_A_const_2 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[39]); A_arbace_go_A_const_3 = A_arbace_go_A_const_pool.A[40]; A_arbace_go_A_const_4 = lang.Var_Cast(A_arbace_go_A_const_pool.A[41]); A_arbace_go_A_const_5 = lang.Var_Cast(A_arbace_go_A_const_pool.A[42]); A_arbace_go_A_const_6 = lang.Var_Cast(A_arbace_go_A_const_pool.A[43]); A_arbace_go_A_const_7 = lang.Var_Cast(A_arbace_go_A_const_pool.A[44]); A_arbace_go_A_const_8 = A_arbace_go_A_const_pool.A[45]; A_arbace_go_A_const_9 = lang.Var_Cast(A_arbace_go_A_const_pool.A[46]); A_arbace_go_A_const_10 = lang.Var_Cast(A_arbace_go_A_const_pool.A[47]); A_arbace_go_A_const_11 = lang.Var_Cast(A_arbace_go_A_const_pool.A[48]) }

func A_arbace_go_A_clinit_p1() { A_arbace_go_A_const_12 = lang.Var_Cast(A_arbace_go_A_const_pool.A[49]); A_arbace_go_A_const_13 = lang.Var_Cast(A_arbace_go_A_const_pool.A[50]); A_arbace_go_A_const_14 = jrt.Class_Cast(A_arbace_go_A_const_pool.A[51]); A_arbace_go_A_const_15 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[52]); A_arbace_go_A_const_16 = lang.Var_Cast(A_arbace_go_A_const_pool.A[53]); A_arbace_go_A_const_17 = lang.Var_Cast(A_arbace_go_A_const_pool.A[54]); A_arbace_go_A_const_18 = A_arbace_go_A_const_pool.A[55]; A_arbace_go_A_const_19 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[56]); A_arbace_go_A_const_20 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[57]); A_arbace_go_A_const_21 = lang.Var_Cast(A_arbace_go_A_const_pool.A[58]); A_arbace_go_A_const_22 = lang.Var_Cast(A_arbace_go_A_const_pool.A[59]); A_arbace_go_A_const_23 = lang.Var_Cast(A_arbace_go_A_const_pool.A[60]) }

func A_arbace_go_A_clinit_p2() { A_arbace_go_A_const_24 = lang.Var_Cast(A_arbace_go_A_const_pool.A[61]); A_arbace_go_A_const_25 = lang.Var_Cast(A_arbace_go_A_const_pool.A[62]); A_arbace_go_A_const_26 = lang.Var_Cast(A_arbace_go_A_const_pool.A[63]); A_arbace_go_A_const_27 = A_arbace_go_A_const_pool.A[64]; A_arbace_go_A_const_28 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[65]); A_arbace_go_A_const_29 = lang.Var_Cast(A_arbace_go_A_const_pool.A[66]); A_arbace_go_A_const_30 = lang.Var_Cast(A_arbace_go_A_const_pool.A[67]); A_arbace_go_A_const_31 = lang.Var_Cast(A_arbace_go_A_const_pool.A[68]); A_arbace_go_A_const_32 = lang.Var_Cast(A_arbace_go_A_const_pool.A[69]); A_arbace_go_A_const_33 = lang.Var_Cast(A_arbace_go_A_const_pool.A[70]); A_arbace_go_A_const_34 = lang.Var_Cast(A_arbace_go_A_const_pool.A[71]); A_arbace_go_A_const_35 = A_arbace_go_A_const_pool.A[72] }

func A_arbace_go_A_clinit_p3() { A_arbace_go_A_const_36 = A_arbace_go_A_const_pool.A[73]; A_arbace_go_A_const_37 = lang.Var_Cast(A_arbace_go_A_const_pool.A[74]); A_arbace_go_A_const_38 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[75]); A_arbace_go_A_const_39 = lang.Var_Cast(A_arbace_go_A_const_pool.A[76]); A_arbace_go_A_const_40 = A_arbace_go_A_const_pool.A[77]; A_arbace_go_A_const_41 = lang.Var_Cast(A_arbace_go_A_const_pool.A[78]); A_arbace_go_A_const_42 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[79]); A_arbace_go_A_const_43 = lang.Var_Cast(A_arbace_go_A_const_pool.A[80]); A_arbace_go_A_const_44 = lang.Var_Cast(A_arbace_go_A_const_pool.A[81]); A_arbace_go_A_const_45 = lang.Var_Cast(A_arbace_go_A_const_pool.A[82]); A_arbace_go_A_const_46 = lang.Var_Cast(A_arbace_go_A_const_pool.A[83]); A_arbace_go_A_const_47 = lang.Var_Cast(A_arbace_go_A_const_pool.A[84]) }

func A_arbace_go_A_clinit_p4() { A_arbace_go_A_const_48 = lang.Var_Cast(A_arbace_go_A_const_pool.A[85]); A_arbace_go_A_const_49 = lang.Var_Cast(A_arbace_go_A_const_pool.A[86]); A_arbace_go_A_const_50 = A_arbace_go_A_const_pool.A[87]; A_arbace_go_A_const_51 = lang.Var_Cast(A_arbace_go_A_const_pool.A[88]); A_arbace_go_A_const_52 = lang.Var_Cast(A_arbace_go_A_const_pool.A[89]); A_arbace_go_A_const_53 = lang.Var_Cast(A_arbace_go_A_const_pool.A[90]); A_arbace_go_A_const_54 = lang.Var_Cast(A_arbace_go_A_const_pool.A[91]); A_arbace_go_A_const_55 = lang.Var_Cast(A_arbace_go_A_const_pool.A[92]); A_arbace_go_A_const_56 = lang.Var_Cast(A_arbace_go_A_const_pool.A[93]); A_arbace_go_A_const_57 = lang.Var_Cast(A_arbace_go_A_const_pool.A[94]); A_arbace_go_A_const_58 = lang.Var_Cast(A_arbace_go_A_const_pool.A[95]); A_arbace_go_A_const_59 = A_arbace_go_A_const_pool.A[96] }

func A_arbace_go_A_clinit_p5() { A_arbace_go_A_const_60 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[97]); A_arbace_go_A_const_61 = A_arbace_go_A_const_pool.A[98]; A_arbace_go_A_const_62 = lang.Var_Cast(A_arbace_go_A_const_pool.A[99]); A_arbace_go_A_const_63 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[100]); A_arbace_go_A_const_64 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[101]); A_arbace_go_A_const_65 = lang.Var_Cast(A_arbace_go_A_const_pool.A[102]); A_arbace_go_A_const_66 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[103]); A_arbace_go_A_const_67 = lang.Var_Cast(A_arbace_go_A_const_pool.A[104]); A_arbace_go_A_const_68 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[105]); A_arbace_go_A_const_69 = lang.Var_Cast(A_arbace_go_A_const_pool.A[106]); A_arbace_go_A_const_70 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[107]); A_arbace_go_A_const_71 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[108]) }

func A_arbace_go_A_clinit_p6() { A_arbace_go_A_const_72 = lang.Var_Cast(A_arbace_go_A_const_pool.A[109]); A_arbace_go_A_const_73 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[110]); A_arbace_go_A_const_74 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[111]); A_arbace_go_A_const_75 = lang.Var_Cast(A_arbace_go_A_const_pool.A[112]); A_arbace_go_A_const_76 = lang.Var_Cast(A_arbace_go_A_const_pool.A[113]); A_arbace_go_A_const_77 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[114]); A_arbace_go_A_const_78 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[115]); A_arbace_go_A_const_79 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[116]); A_arbace_go_A_const_80 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[117]); A_arbace_go_A_const_81 = lang.Var_Cast(A_arbace_go_A_const_pool.A[118]); A_arbace_go_A_const_82 = lang.Var_Cast(A_arbace_go_A_const_pool.A[119]); A_arbace_go_A_const_83 = lang.Var_Cast(A_arbace_go_A_const_pool.A[120]) }

func A_arbace_go_A_clinit_p7() { A_arbace_go_A_const_84 = lang.Var_Cast(A_arbace_go_A_const_pool.A[121]); A_arbace_go_A_const_85 = lang.Var_Cast(A_arbace_go_A_const_pool.A[122]); A_arbace_go_A_const_86 = lang.Var_Cast(A_arbace_go_A_const_pool.A[123]); A_arbace_go_A_const_87 = lang.Var_Cast(A_arbace_go_A_const_pool.A[124]); A_arbace_go_A_const_88 = lang.Var_Cast(A_arbace_go_A_const_pool.A[125]); A_arbace_go_A_const_89 = lang.Var_Cast(A_arbace_go_A_const_pool.A[126]); A_arbace_go_A_const_90 = lang.Var_Cast(A_arbace_go_A_const_pool.A[127]); A_arbace_go_A_const_91 = lang.Var_Cast(A_arbace_go_A_const_pool.A[128]); A_arbace_go_A_const_92 = lang.Var_Cast(A_arbace_go_A_const_pool.A[129]); A_arbace_go_A_const_93 = lang.Var_Cast(A_arbace_go_A_const_pool.A[130]); A_arbace_go_A_const_94 = lang.Var_Cast(A_arbace_go_A_const_pool.A[131]); A_arbace_go_A_const_95 = lang.Var_Cast(A_arbace_go_A_const_pool.A[132]) }

func A_arbace_go_A_clinit_p8() { A_arbace_go_A_const_96 = A_arbace_go_A_const_pool.A[133]; A_arbace_go_A_const_97 = lang.Var_Cast(A_arbace_go_A_const_pool.A[134]); A_arbace_go_A_const_98 = lang.Var_Cast(A_arbace_go_A_const_pool.A[135]); A_arbace_go_A_const_99 = lang.Var_Cast(A_arbace_go_A_const_pool.A[136]); A_arbace_go_A_const_100 = lang.Var_Cast(A_arbace_go_A_const_pool.A[137]); A_arbace_go_A_const_101 = lang.Var_Cast(A_arbace_go_A_const_pool.A[138]); A_arbace_go_A_const_102 = lang.Var_Cast(A_arbace_go_A_const_pool.A[139]); A_arbace_go_A_const_103 = lang.Var_Cast(A_arbace_go_A_const_pool.A[140]); A_arbace_go_A_const_104 = lang.Var_Cast(A_arbace_go_A_const_pool.A[141]); A_arbace_go_A_const_105 = lang.Var_Cast(A_arbace_go_A_const_pool.A[142]); A_arbace_go_A_const_106 = lang.Var_Cast(A_arbace_go_A_const_pool.A[143]); A_arbace_go_A_const_107 = lang.Var_Cast(A_arbace_go_A_const_pool.A[144]) }

func A_arbace_go_A_clinit_p9() { A_arbace_go_A_const_108 = lang.Var_Cast(A_arbace_go_A_const_pool.A[145]); A_arbace_go_A_const_109 = lang.Var_Cast(A_arbace_go_A_const_pool.A[146]); A_arbace_go_A_const_110 = A_arbace_go_A_const_pool.A[147]; A_arbace_go_A_const_111 = A_arbace_go_A_const_pool.A[148]; A_arbace_go_A_const_112 = A_arbace_go_A_const_pool.A[149]; A_arbace_go_A_const_113 = lang.Var_Cast(A_arbace_go_A_const_pool.A[150]); A_arbace_go_A_const_114 = lang.Var_Cast(A_arbace_go_A_const_pool.A[151]); A_arbace_go_A_const_115 = A_arbace_go_A_const_pool.A[152]; A_arbace_go_A_const_116 = A_arbace_go_A_const_pool.A[153]; A_arbace_go_A_const_117 = lang.Var_Cast(A_arbace_go_A_const_pool.A[154]); A_arbace_go_A_const_118 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[155]); A_arbace_go_A_const_119 = A_arbace_go_A_const_pool.A[156]; A_arbace_go_A_const_120 = A_arbace_go_A_const_pool.A[157]; A_arbace_go_A_const_121 = A_arbace_go_A_const_pool.A[158] }

func A_arbace_go_A_clinit_p10() { A_arbace_go_A_const_122 = A_arbace_go_A_const_pool.A[159]; A_arbace_go_A_const_123 = A_arbace_go_A_const_pool.A[160]; A_arbace_go_A_const_124 = A_arbace_go_A_const_pool.A[161]; A_arbace_go_A_const_125 = A_arbace_go_A_const_pool.A[162] }

func A_arbace_go_A_New() *A_arbace_go_A { A_arbace_go_A_Init(); t := &A_arbace_go_A{}; t.Ctor(); return t }

func (t *A_arbace_go_A) Ctor() {}

func (t *A_arbace_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_A) GetClass__Class() *jrt.Class { return A_arbace_go_A_class }

func (t *A_arbace_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_A); return ok }

func A_arbace_go_A_Cast(x any) *A_arbace_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_A_class)) }; return v }



type A_arbace_go_assign_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_assign_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_A struct{ j2g_header uint64 }

var A_arbace_go_check_A_fn_class *jrt.Class



type A_arbace_go_const_A struct{ j2g_header uint64 }

var A_arbace_go_const_A_fn_class *jrt.Class



type A_arbace_go_const_value_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_A_fn_class *jrt.Class



type A_arbace_go_const_value_fn__1822000029_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_fn__1822000029_A_fn_class *jrt.Class



type A_arbace_go_declare_STAR__A struct{ j2g_header uint64 }

var A_arbace_go_declare_STAR__A_fn_class *jrt.Class



type A_arbace_go_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_digest_info_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_A_fn_class *jrt.Class



type A_arbace_go_digest_info_fn__1822000032_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_fn__1822000032_A_fn_class *jrt.Class



type A_arbace_go_directive_A struct{ j2g_header uint64 }

var A_arbace_go_directive_A_fn_class *jrt.Class



type A_arbace_go_eval_A struct{ j2g_header uint64 }

var A_arbace_go_eval_A_fn_class *jrt.Class



type A_arbace_go_eval1822000004_A struct{ jrt.Object }

func A_arbace_go_eval1822000004_A_New() *A_arbace_go_eval1822000004_A { t := &A_arbace_go_eval1822000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000004_A) Ctor() {}

func (t *A_arbace_go_eval1822000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000004_A_class }

func (t *A_arbace_go_eval1822000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000004_A); return ok }

func A_arbace_go_eval1822000004_A_Cast(x any) *A_arbace_go_eval1822000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000004_A_class)) }; return v }



type A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class *jrt.Class



type A_arbace_go_eval1822000008_A struct{ jrt.Object }

func A_arbace_go_eval1822000008_A_New() *A_arbace_go_eval1822000008_A { t := &A_arbace_go_eval1822000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000008_A) Ctor() {}

func (t *A_arbace_go_eval1822000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000008_A_class }

func (t *A_arbace_go_eval1822000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000008_A); return ok }

func A_arbace_go_eval1822000008_A_Cast(x any) *A_arbace_go_eval1822000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000008_A_class)) }; return v }



type A_arbace_go_eval1822000008_fn__1822000009_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000008_fn__1822000009_A_fn_class *jrt.Class



type A_arbace_go_file_A struct{ j2g_header uint64 }

var A_arbace_go_file_A_fn_class *jrt.Class



type A_arbace_go_fn__1822000016_A struct{ j2g_header uint64 }

var A_arbace_go_fn__1822000016_A_fn_class *jrt.Class



type A_arbace_go_func_A struct{ j2g_header uint64 }

var A_arbace_go_func_A_fn_class *jrt.Class



type A_arbace_go_import_A struct{ j2g_header uint64 }

var A_arbace_go_import_A_fn_class *jrt.Class



type A_arbace_go_inst_A struct{ j2g_header uint64 }

var A_arbace_go_inst_A_fn_class *jrt.Class



type A_arbace_go_interpretable_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_interpretable_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_member_var_A struct{ j2g_header uint64 }

var A_arbace_go_member_var_A_fn_class *jrt.Class



type A_arbace_go_method_A struct{ j2g_header uint64 }

var A_arbace_go_method_A_fn_class *jrt.Class



type A_arbace_go_new_A struct{ j2g_header uint64 }

var A_arbace_go_new_A_fn_class *jrt.Class



type A_arbace_go_package_A struct{ j2g_header uint64 }

var A_arbace_go_package_A_fn_class *jrt.Class



type A_arbace_go_packages_A struct{ j2g_header uint64 }

var A_arbace_go_packages_A_fn_class *jrt.Class



type A_arbace_go_params_of_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_A_fn_class *jrt.Class



type A_arbace_go_params_of_fn__1822000024_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_fn__1822000024_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_fn__1822000013_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class *jrt.Class



type A_arbace_go_pos_of_A struct{ j2g_header uint64 }

var A_arbace_go_pos_of_A_fn_class *jrt.Class



type A_arbace_go_reify_data_A struct{ j2g_header uint64 }

var A_arbace_go_reify_data_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_A struct{ j2g_header uint64; F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A struct{ j2g_header uint64; F_s__1822000139, F_iter__1822000138, F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A struct{ j2g_header uint64; F_b__1822000141, F_fns any; F_size__1927001038__auto__ int32; F_ts, F_c__1927001037__auto__ any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class *jrt.Class



type A_arbace_go_reify_type_A struct{ j2g_header uint64 }

var A_arbace_go_reify_type_A_fn_class *jrt.Class



type A_arbace_go_repl_fn_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn_A_fn_class *jrt.Class



type A_arbace_go_run_compiled_A struct{ j2g_header uint64 }

var A_arbace_go_run_compiled_A_fn_class *jrt.Class



type A_arbace_go_run_main_A struct{ j2g_header uint64 }

var A_arbace_go_run_main_A_fn_class *jrt.Class



type A_arbace_go_spread_A struct{ j2g_header uint64 }

var A_arbace_go_spread_A_fn_class *jrt.Class



type A_arbace_go_str_A struct{ j2g_header uint64 }

var A_arbace_go_str_A_fn_class *jrt.Class



type A_arbace_go_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_go_strip_doc_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000082_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_A struct{ j2g_header uint64; F_info, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A struct{ j2g_header uint64; F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A struct{ j2g_header uint64; F_members, F_s__1822000086, F_iter__1822000085 any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A struct{ j2g_header uint64; F_b__1822000088, F_members any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A struct{ j2g_header uint64; F_ns any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A struct{ j2g_header uint64; F_ns, F_s__1822000051, F_iter__1822000050 any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A struct{ j2g_header uint64; F_b__1822000053, F_ns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A struct{ j2g_header uint64; F_s__1822000067, F_iter__1822000066 any }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A struct{ j2g_header uint64; F_b__1822000069 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__make__1822000102_A struct{ j2g_header uint64; F_ns, F_info, F_consts, F_p, F_members any }

var A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__resolver__1822000107_A struct{ j2g_header uint64; F_make, F_consts, F_members any }

var A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class *jrt.Class



type A_arbace_go_type_A struct{ j2g_header uint64 }

var A_arbace_go_type_A_fn_class *jrt.Class



type A_arbace_go_type_names_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_A_fn_class *jrt.Class



type A_arbace_go_type_names_fn__1822000127_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_fn__1822000127_A_fn_class *jrt.Class



type A_arbace_go_type_of_A struct{ j2g_header uint64 }

var A_arbace_go_type_of_A_fn_class *jrt.Class



type A_arbace_go_var_A struct{ j2g_header uint64 }

var A_arbace_go_var_A_fn_class *jrt.Class



type A_arbace_go_zero_A struct{ j2g_header uint64 }

var A_arbace_go_zero_A_fn_class *jrt.Class
