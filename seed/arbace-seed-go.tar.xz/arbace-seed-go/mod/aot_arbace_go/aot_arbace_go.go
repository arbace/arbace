//line aot_arbace_go.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New() *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_A_const_1, A_arbace_go_A_const_2, A_arbace_go_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_eval1822000008_fn__1822000009_A_New() *A_arbace_go_eval1822000008_fn__1822000009_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000008_fn__1822000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_go_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_A_const_7.GetRawRoot__O(), A_arbace_go_A_const_8) }
















































func A_arbace_go_path__GT_ns_A_New() *A_arbace_go_path__GT_ns_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {



	var root_17 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_35, nil); var tmp2 any; var root_21 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_25 any; var root_26 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = Lit_12; var arg_30 any; var root_31 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp3 any = A_arbace_go_path__GT_ns_fn__1822000013_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *jrt.Class = A_arbace_go_A_const_14; var arg_35 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__0, tmp5, Lit_37, jrt.RefArrayOf(jrt.Object_class, Lit_38)); if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_17, arg_20) } }
//line :54:1
func A_arbace_go_path__GT_ns_fn__1822000013_A_New() *A_arbace_go_path__GT_ns_fn__1822000013_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_fn__1822000013_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Ctor() {}
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Invoke_O_O__O(self, p1__1822000012_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_go_A_const_14; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1822000012_SHARP___1, tmp1, Lit_39, jrt.RefArrayOf(jrt.Object_class, Lit_40, Lit_41)) }


func A_arbace_go_fn__1822000016_A_New() *A_arbace_go_fn__1822000016_A { A_arbace_go_A_Init(); t := &A_arbace_go_fn__1822000016_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_26); var tmp1 any = A_arbace_go_A_const_15; var tmp2 any; var root_37 any = A_arbace_go_A_const_16.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_39 lang.IFn

		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__2; var arg_45 any = A_arbace_go_A_const_18; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_37, arg_40) }
//line :58:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_A_const_19; var tmp5 any = A_arbace_go_A_const_20; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_digest_forms_A_New() *A_arbace_go_digest_forms_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_forms_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_digest_forms_A) Ctor() {}
//line :62:1
func (t *A_arbace_go_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_47 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_49 lang.IFn; if



	linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_A_const_21.GetRawRoot__O(); if linked_48 == nil { temp__1927000414__auto____2 = ifn_49.Invoke_O__O(arg_50) } else { temp__1927000414__auto____2 = linked_48.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__1822000018__3 any = temp__1927000414__auto____2; var map__1822000018__4 any; if lang.ISeq_InstanceOf(map__1822000018__3) { var tmp1 any; var root_51 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = map__1822000018__3; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_55 any = A_arbace_go_A_const_23.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = map__1822000018__3; if linked_56 == nil { tmp2 = ifn_57.Invoke_O__O(arg_58) } else { tmp2 = linked_56.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_55, arg_58) }; map__1822000018__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_59 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = map__1822000018__3; if linked_60 == nil { tmp3 = ifn_61.Invoke_O__O(arg_62) } else { tmp3 = linked_60.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_59, arg_62) }; if jrt.J2g_Truth(tmp3) { var root_63 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = map__1822000018__3; if linked_64 == nil { map__1822000018__4 = ifn_65.Invoke_O__O(arg_66) } else { map__1822000018__4 = linked_64.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_63, arg_66) } } else { map__1822000018__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1822000018__4 = map__1822000018__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_15); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_19); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_20); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__1822000020__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(1), nil); var r__12 any; var tmp4 any; var root_67 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_69 lang.IFn
			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = text__6; var arg_71 any; var na_73 any = start__7; var na_74 any = a__10; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_73); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_74) }; tmp5 = tmp6; if tmp5 { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); var n1_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var nr_77 int64 = n0_75 + n1_76; if (n0_75^nr_77)&(n1_76^nr_77) >= 0 { arg_71 = jrt.Long_ValueOf_J__Long_NoInit(nr_77).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_73); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_74) }; tmp7 = tmp8; if tmp7 { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); var n1_76_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); arg_71 = jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + n1_76_2).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } }; var arg_72 any; var na_78 any = start__7; var na_79 any = b__11; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_78); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_79) }; tmp9 = tmp10; if tmp9 { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var nr_82 int64 = n0_80 + n1_81; if (n0_80^nr_82)&(n1_81^nr_82) >= 0 { arg_72 = jrt.Long_ValueOf_J__Long_NoInit(nr_82).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_78); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_79) }; tmp11 = tmp12; if tmp11 { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); arg_72 = jrt.Double_ValueOf_D__Double_NoInit(n0_80_2 + n1_81_2).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } }; if linked_68 == nil { tmp4 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) }
//line :67:1
			r__12 = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(tmp4)))

			var root_91 any = A_arbace_go_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_A_const_32, jrt.Boolean_FALSE.Ref()); if linked_92 == nil { ifn_93.Invoke_O__O(arg_94) } else { linked_92.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_91, arg_94) }
//line :67:1
			var tmp13 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__15 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__16 any; var root_83 any = A_arbace_go_A_const_26.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_85 lang.IFn



				if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_go_A_const_27; var arg_87 any = r__12; if linked_84 == nil { f__16 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { f__16 = linked_84.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }
				if lang.Util_Equiv_O_O__Z_NoInit(f__16, A_arbace_go_A_const_28) { tmp13 = acc__15 } else { var tmp14 any; var root_100 any = A_arbace_go_A_const_7.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = acc__15; var arg_104 any = f__16; if linked_101 == nil { tmp14 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp14 = linked_101.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; acc__15 = tmp14; continue L1 }
//line :67:1
				break L1 } }; return nil }(); var root_88 any = A_arbace_go_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_90 lang.IFn

			if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; if linked_89 == nil { ifn_90.Invoke__O() } else { linked_89.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_88) }
//line :67:1
			if tmp15 != nil { panic(tmp15) }; return tmp13 } else { return nil } } else {
//line :66:1
				return nil } }







func A_arbace_go_params_of_A_New() *A_arbace_go_params_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_params_of_A) Ctor() {}
//line :74:1
func (t *A_arbace_go_params_of_A) Invoke_O_O__O(self, pv__0 any) any {


	var root_105 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_go_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp1 any = A_arbace_go_params_of_fn__1822000024_A_New(); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_params_of_fn__1822000024_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_params_of_fn__1822000024_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_113 any = pv__0; if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_105, arg_108) } }
//line :77:1
func A_arbace_go_params_of_fn__1822000024_A_New() *A_arbace_go_params_of_fn__1822000024_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_fn__1822000024_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Ctor() {}
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, x__2) } else {
												if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_114 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_116 lang.IFn

		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__2; if linked_115 == nil { and__1927000168__auto____3 = ifn_116.Invoke_O__O(arg_117) } else { and__1927000168__auto____3 = linked_115.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_118 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_go_A_const_40; var arg_122 any = x__2; if linked_119 == nil { tmp1 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_118, arg_121, arg_122) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_123 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = x__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_127, arg_130) }; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_123, arg_126) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_131 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var na_135 any = i__1; if jrt.Long_InstanceOf(na_135) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); if n0_136 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_136 + 1)) } } else { if jrt.Double_InstanceOf(na_135) { var n0_136_2 float64 = jrt.NN(jrt.Double_Cast(na_135)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_136_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } }; arg_134 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_132 == nil { return ifn_133.Invoke_O__O(arg_134) } else { return linked_132.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_131, arg_134) } } else {
//line :78:1
						return nil } } } } }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, x__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_137 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_139 lang.IFn

		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = x__2; if linked_138 == nil { and__1927000168__auto____3 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____3 = linked_138.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_141 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_go_A_const_40; var arg_145 any = x__2; if linked_142 == nil { tmp1 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_146 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_150 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = x__2; if linked_151 == nil { arg_149 = ifn_152.Invoke_O__O(arg_153) } else { arg_149 = linked_151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_150, arg_153) }; if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_146, arg_149) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_154 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var n0_158 int64 = i__1_l; if n0_158 == 9223372036854775807 { var tmp5 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp5 = i__1_b } else { tmp5 = i__1_b }; tmp4 = lang.Numbers_Inc_O__Number_NoInit(tmp5) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_158 + 1)) }; arg_157 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_155 == nil { return ifn_156.Invoke_O__O(arg_157) } else { return linked_155.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_154, arg_157) } } else {
//line :78:1
						return nil
					}
			}
	}
}

func A_arbace_go_strip_doc_A_New() *A_arbace_go_strip_doc_A { A_arbace_go_A_Init(); t := &A_arbace_go_strip_doc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_go_strip_doc_A) Ctor() {}
//line :84:1
func (t *A_arbace_go_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_160 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_164 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = xs__0; if linked_165 == nil { arg_163 = ifn_166.Invoke_O__O(arg_167) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_168 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = xs__0; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) }; var tmp3 any = tmp2; var tmp4 any; var root_172 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = xs__0; if linked_173 == nil { tmp4 = ifn_174.Invoke_O__O(arg_175) } else { tmp4 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) } }

func A_arbace_go_const_value_A_New() *A_arbace_go_const_value_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_const_value_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_const_value_A) Invoke_O_O_O__O(self, v__0, underlying__1 any) any {




	var tmp1 any; var root_176 any = A_arbace_go_A_const_45.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_178 lang.IFn
	if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = v__0; if linked_177 == nil { tmp1 = ifn_178.Invoke_O__O(arg_179) } else { tmp1 = linked_177.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_176, arg_179) }
//line :91:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var root_180 any = A_arbace_go_A_const_46.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_182 lang.IFn

		if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = v__0; if linked_181 == nil { tmp2 = ifn_182.Invoke_O__O(arg_183) } else { tmp2 = linked_181.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_180, arg_183) }
//line :91:1
		if jrt.J2g_Truth(tmp2) {

			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__0))).Ref() } else {
//line :91:1
				var tmp3 any; var or__1927000174__auto____3 any; var root_184 any = A_arbace_go_A_const_47.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_float_QMARK__A_fn_class); var ifn_186 lang.IFn


				if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { or__1927000174__auto____3 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____3 = linked_185.(*aot_arbace_core.A_arbace_core_float_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_188 any = A_arbace_go_A_const_48.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = v__0; if linked_189 == nil { or__1927000174__auto____4 = ifn_190.Invoke_O__O(arg_191) } else { or__1927000174__auto____4 = linked_189.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { var root_192 any = A_arbace_go_A_const_49.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_decimal_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*aot_arbace_core.A_arbace_core_decimal_QMARK__A).Invoke_O_O__O(root_192, arg_195) } } }
//line :91:1
				if jrt.J2g_Truth(tmp3) {


					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_50, underlying__1) { return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__0)).Ref() } else { return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__0)).Ref() } } else {
//line :91:1
						var tmp4 any; var root_196 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_198 lang.IFn



						if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = v__0; if linked_197 == nil { tmp4 = ifn_198.Invoke_O__O(arg_199) } else { tmp4 = linked_197.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_196, arg_199) }
//line :91:1
						if jrt.J2g_Truth(tmp4) { var G__1822000028__3_ any; var root_200 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_202 lang.IFn



							if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = v__0; if linked_205 == nil { arg_203 = ifn_206.Invoke_O__O(arg_207) } else { arg_203 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; if linked_201 == nil { G__1822000028__3_ = ifn_202.Invoke_O__O(arg_203) } else { G__1822000028__3_ = linked_201.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_200, arg_203) }; switch lang.Util_Hash_O__I_NoInit(G__1822000028__3_) >> 7 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_2) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_52.GetRawRoot__O()); var tmp6 any = A_arbace_go_const_value_fn__1822000029_A_New(); var tmp7 *jrt.Class
								var fncls__222 /*line :95:1*/*jrt.Class = A_arbace_go_const_value_fn__1822000029_A_fn_class

								if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_const_value_fn__1822000029_A_fn_class = fncls__222d; tmp7 = fncls__222d } else { tmp7 = fncls__222 }
//line :95:1
								var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_223 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_225 lang.IFn

								if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = v__0; if linked_224 == nil { tmp9 = ifn_225.Invoke_O__O(arg_226) } else { tmp9 = linked_224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_223, arg_226) }
//line :95:1
								return jrt.String_New_B1_String(lang.Numbers_Byte_array_O__B1_NoInit(tmp5.Invoke_O_O__O(tmp8, tmp9)), Lit_4) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_5) {



									var tmp10 any; var root_227 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = v__0; if linked_228 == nil { tmp10 = ifn_229.Invoke_O__O(arg_230) } else { tmp10 = linked_228.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_227, arg_230) }; return lang.GoInterp_Complex_D_D__O(lang.RT_DoubleCast_O__D_NoInit(tmp10), lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) }
//line :95:1
							case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_6) {
								var tmp11 any; var root_231 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = v__0; if linked_232 == nil { tmp11 = ifn_233.Invoke_O__O(arg_234) } else { tmp11 = linked_232.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_231, arg_234) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp11)).Ref() }
//line :95:1
							case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_7) {




								var tmp12 any; var root_235 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = v__0; if linked_236 == nil { tmp12 = ifn_237.Invoke_O__O(arg_238) } else { tmp12 = linked_236.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_235, arg_238) }; return jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Multiply_D_D__D_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp12), jrt.Math_Pow_D_D__D(2.0, lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))))).Ref() }
//line :95:1
							default:}; return v__0 } else {
//line :91:1
								if A_arbace_go_A_const_42 != nil { return v__0 } else { return nil
								}
							}
					}
			}
	} }
func A_arbace_go_const_value_fn__1822000029_A_New() *A_arbace_go_const_value_fn__1822000029_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_fn__1822000029_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Ctor() {}
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_214 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = x__1; if linked_215 == nil { tmp1 = ifn_216.Invoke_O__O(arg_217) } else { tmp1 = linked_215.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp1) { var root_218 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = jrt.NN(jrt.String_Cast(x__1)).GetBytes_String__B1(Lit_4).Ref(); if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) } } else { return lang.Tuple_Create_O__IPersistentVector(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_UncheckedByteCast_O__B_NoInit(x__1)).Ref()) } }






func A_arbace_go_digest_info_A_New() *A_arbace_go_digest_info_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_digest_info_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_digest_info_A) Invoke_O_O__O(self, p__0 any) any {


	var root_239 any = A_arbace_go_A_const_54.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any; var tmp1 any = A_arbace_go_digest_info_fn__1822000032_A_New(); var tmp2 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_go_digest_info_fn__1822000032_A_fn_class
	if fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_digest_info_fn__1822000032_A_fn_class = fncls__453d; tmp2 = fncls__453d } else { tmp2 = fncls__453 }; arg_242 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :107:1
	var arg_243 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_244 any; var root_454 any = A_arbace_go_A_const_72.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, A_arbace_go_digest_forms_A_fn_class); var ifn_456 lang.IFn




























	if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = p__0; if linked_455 == nil { arg_244 = ifn_456.Invoke_O__O(arg_457) } else { arg_244 = linked_455.(*A_arbace_go_digest_forms_A).Invoke_O_O__O(root_454, arg_457) }
//line :107:1
	if linked_240 == nil { return ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { return linked_240.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) } }
func A_arbace_go_digest_info_fn__1822000032_A_New() *A_arbace_go_digest_info_fn__1822000032_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_fn__1822000032_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Ctor() {}
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any; var root_245 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var and__1927000168__auto____3 any; var root_249 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__2; if linked_250 == nil { and__1927000168__auto____3 = ifn_251.Invoke_O__O(arg_252) } else { and__1927000168__auto____3 = linked_250.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_253 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = f__2; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { and__1927000168__auto____4 = ifn_255.Invoke_O__O(arg_256) } else { and__1927000168__auto____4 = linked_254.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_261 any = A_arbace_go_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_265 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = f__2; if linked_266 == nil { arg_264 = ifn_267.Invoke_O__O(arg_268) } else { arg_264 = linked_266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_265, arg_268) }; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_261, arg_264) }; arg_248 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_10, tmp2)).Ref() } else { arg_248 = and__1927000168__auto____4 } } else { arg_248 = and__1927000168__auto____3 }; if linked_246 == nil { tmp1 = ifn_247.Invoke_O__O(arg_248) } else { tmp1 = linked_246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var G__1822000033__3_ any; var root_269 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_271 lang.IFn

		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_273 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = f__2; if linked_274 == nil { arg_272 = ifn_275.Invoke_O__O(arg_276) } else { arg_272 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; if linked_270 == nil { G__1822000033__3_ = ifn_271.Invoke_O__O(arg_272) } else { G__1822000033__3_ = linked_270.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_269, arg_272) }; switch lang.Util_Hash_O__I_NoInit(G__1822000033__3_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_11) { var vec__1822000034__4 any; var root_278 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_go_strip_doc_A_fn_class); var ifn_280 lang.IFn





			if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_282, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_286 any = f__2; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(A_arbace_go_A_const_59, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_282, 2, A_arbace_go_A_const_59, arg_286) }; if linked_279 == nil { vec__1822000034__4 = ifn_280.Invoke_O__O(arg_281) } else { vec__1822000034__4 = linked_279.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_278, arg_281) }
//line :111:1
			var doc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7 bool; var tmp3 any = A_arbace_go_A_const_60; var tmp4 any; var root_287 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn






			if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = xs__6; if linked_288 == nil { tmp4 = ifn_289.Invoke_O__O(arg_290) } else { tmp4 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) }; gen__7 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)
//line :111:1
			var xs__8 any







			if gen__7 { var root_291 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_291, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_295 any = xs__6; if linked_292 == nil { xs__8 = ifn_293.Invoke_O_O__O(A_arbace_go_A_const_59, arg_295) } else { xs__8 = linked_292.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_291, 2, A_arbace_go_A_const_59, arg_295) } } else { xs__8 = xs__6 }
//line :111:1
			var pv__9 any; var root_296 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_298 lang.IFn








			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = xs__8; if linked_297 == nil { pv__9 = ifn_298.Invoke_O__O(arg_299) } else { pv__9 = linked_297.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_296, arg_299) }
//line :111:1
			var r__10 any; var root_300 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn









			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = pv__9; if linked_301 == nil { r__10 = ifn_302.Invoke_O__O(arg_303) } else { r__10 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }
//line :111:1
			var rt__11 any; var tmp5 any; var and__1927000168__auto____11 any; var root_304 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_306 lang.IFn










			if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = r__10; if linked_305 == nil { and__1927000168__auto____11 = ifn_306.Invoke_O__O(arg_307) } else { and__1927000168__auto____11 = linked_305.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp6 *lang.Keyword = A_arbace_go_A_const_38; tmp5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) { var tmp7 *lang.Keyword = A_arbace_go_A_const_38; rt__11 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { rt__11 = r__10 }
//line :111:1
			var rt__12 any; var tmp8 any; var and__1927000168__auto____12 any; var root_308 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn











			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = rt__11; if linked_309 == nil { and__1927000168__auto____12 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____12 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp9 any = A_arbace_go_A_const_61; var tmp10 any; var root_312 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = rt__11; if linked_313 == nil { tmp10 = ifn_314.Invoke_O__O(arg_315) } else { tmp10 = linked_313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_312, arg_315) }; tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10)).Ref() } else { tmp8 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp8) { var root_316 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = rt__11; if linked_317 == nil { rt__12 = ifn_318.Invoke_O__O(arg_319) } else { rt__12 = linked_317.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_316, arg_319) } } else { rt__12 = rt__11 }
//line :111:1
			var vec__1822000037__13 any; var tmp11 any; var root_320 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_322 lang.IFn













			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = rt__12; if linked_321 == nil { tmp11 = ifn_322.Invoke_O__O(arg_323) } else { tmp11 = linked_321.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(tmp11) { var tmp12 any; var root_431 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = rt__12; if linked_432 == nil { tmp12 = ifn_433.Invoke_O__O(arg_434) } else { tmp12 = linked_432.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_431, arg_434) }; vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, jrt.Boolean_TRUE.Ref()) } else { vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(rt__12, jrt.Boolean_ValueOf_Z__Boolean_NoInit(gen__7).Ref()) }
//line :111:1
			var rt__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(0), nil); var gen__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp13 any; var root_324 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_326 lang.IFn














			if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = rt__14; if linked_325 == nil { tmp13 = ifn_326.Invoke_O__O(arg_327) } else { tmp13 = linked_325.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(tmp13) {
				var root_328 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = acc__1; var arg_332 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil); var tmp15 any; var root_334 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = f__2; if linked_335 == nil { tmp15 = ifn_336.Invoke_O__O(arg_337) } else { tmp15 = linked_335.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_334, arg_337) }; arg_332 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, rt__14, nil, tmp15)).Ref(); var arg_333 any; var G__1822000040__16_ any; var tmp16 any = A_arbace_go_A_const_63; var tmp17 any = A_arbace_go_A_const_64; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp19 any; var root_344 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, A_arbace_go_params_of_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = pv__9; if linked_345 == nil { tmp19 = ifn_346.Invoke_O__O(arg_347) } else { tmp19 = linked_345.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_344, arg_347) }; G__1822000040__16_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, doc__5, tmp17, tmp18.Invoke_O__O(tmp19))); if jrt.J2g_Truth(gen__15) {
					var root_338 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = G__1822000040__16_; var arg_342 any = A_arbace_go_A_const_66; var arg_343 any = jrt.Boolean_TRUE.Ref(); if linked_339 == nil { arg_333 = ifn_340.Invoke_O_O_O__O(arg_341, arg_342, arg_343) } else { arg_333 = linked_339.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_338, arg_341, arg_342, arg_343) } } else {
//line :127:1
						arg_333 = G__1822000040__16_ }; if linked_329 == nil { return ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { return linked_329.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) } } else {
//line :126:1
							return acc__1 } }
//line :111:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_13) {




















			var root_348 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = acc__1; var arg_352 any; var root_354 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var root_358 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = f__2; if linked_359 == nil { arg_357 = ifn_360.Invoke_O__O(arg_361) } else { arg_357 = linked_359.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_358, arg_361) }; if linked_355 == nil { arg_352 = ifn_356.Invoke_O__O(arg_357) } else { arg_352 = linked_355.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_354, arg_357) }; var arg_353 any; var tmp20 any = A_arbace_go_A_const_63; var tmp21 any; var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp22 any; var root_362 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = d__4; if linked_363 == nil { tmp22 = ifn_364.Invoke_O__O(arg_365) } else { tmp22 = linked_363.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(tmp22) { tmp21 = d__4 } else { tmp21 = nil }; arg_353 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21)); if linked_349 == nil { return ifn_350.Invoke_O_O_O__O(arg_351, arg_352, arg_353) } else { return linked_349.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_348, arg_351, arg_352, arg_353) } }
//line :111:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_14) { var n__4 any; var root_366 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_368 lang.IFn


















			if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = f__2; if linked_367 == nil { n__4 = ifn_368.Invoke_O__O(arg_369) } else { n__4 = linked_367.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_366, arg_369) }
//line :111:1
			var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__4); var root_370 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_372 lang.IFn



















			if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = acc__1; var arg_374 any; var root_376 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = n__4; if linked_377 == nil { arg_374 = ifn_378.Invoke_O__O(arg_379) } else { arg_374 = linked_377.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_376, arg_379) }; var arg_375 any; var tmp23 any = A_arbace_go_A_const_63; var tmp24 any = A_arbace_go_A_const_63.Invoke_O__O(m__5); var tmp25 any = A_arbace_go_A_const_68; var tmp26 any; var root_380 any = A_arbace_go_A_const_69.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_go_const_value_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = A_arbace_go_A_const_70.Invoke_O__O(m__5); var arg_384 any = A_arbace_go_A_const_71.Invoke_O__O(m__5); if linked_381 == nil { tmp26 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { tmp26 = linked_381.(*A_arbace_go_const_value_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; arg_375 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)); if linked_371 == nil { return ifn_372.Invoke_O_O_O__O(arg_373, arg_374, arg_375) } else { return linked_371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_370, arg_373, arg_374, arg_375) } }
//line :111:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_15) { var vec__1822000041__4 any; var root_385 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, A_arbace_go_strip_doc_A_fn_class); var ifn_387 lang.IFn
			if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var root_389 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_389, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_393 any = f__2; if linked_390 == nil { arg_388 = ifn_391.Invoke_O_O__O(A_arbace_go_A_const_59, arg_393) } else { arg_388 = linked_390.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_389, 2, A_arbace_go_A_const_59, arg_393) }; if linked_386 == nil { vec__1822000041__4 = ifn_387.Invoke_O__O(arg_388) } else { vec__1822000041__4 = linked_386.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_385, arg_388) }
//line :111:1
			var doc__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7_2 bool; var tmp27 any = A_arbace_go_A_const_60; var tmp28 any; var root_394 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_396 lang.IFn

			if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = xs__6_2; if linked_395 == nil { tmp28 = ifn_396.Invoke_O__O(arg_397) } else { tmp28 = linked_395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_394, arg_397) }; gen__7_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp27, tmp28)
//line :111:1
			var xs__8_2 any


			if gen__7_2 { var root_398 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_398, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_402 any = xs__6_2; if linked_399 == nil { xs__8_2 = ifn_400.Invoke_O_O__O(A_arbace_go_A_const_59, arg_402) } else { xs__8_2 = linked_399.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_398, 2, A_arbace_go_A_const_59, arg_402) } } else { xs__8_2 = xs__6_2 }
			var root_403 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = acc__1; var arg_407 any; var root_409 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var root_413 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = f__2; if linked_414 == nil { arg_412 = ifn_415.Invoke_O__O(arg_416) } else { arg_412 = linked_414.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_413, arg_416) }; if linked_410 == nil { arg_407 = ifn_411.Invoke_O__O(arg_412) } else { arg_407 = linked_410.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_409, arg_412) }; var arg_408 any; var G__1822000044__9_ any; var tmp29 any = A_arbace_go_A_const_63; var tmp30 any = A_arbace_go_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp32 any; var root_423 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, A_arbace_go_params_of_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var root_427 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = xs__8_2; if linked_428 == nil { arg_426 = ifn_429.Invoke_O__O(arg_430) } else { arg_426 = linked_428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_427, arg_430) }; if linked_424 == nil { tmp32 = ifn_425.Invoke_O__O(arg_426) } else { tmp32 = linked_424.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_423, arg_426) }; G__1822000044__9_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, doc__5_2, tmp30, tmp31.Invoke_O__O(tmp32))); if gen__7_2 {
				var root_417 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = G__1822000044__9_; var arg_421 any = A_arbace_go_A_const_66; var arg_422 any = jrt.Boolean_TRUE.Ref(); if linked_418 == nil { arg_408 = ifn_419.Invoke_O_O_O__O(arg_420, arg_421, arg_422) } else { arg_408 = linked_418.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_417, arg_420, arg_421, arg_422) } } else {
//line :115:1
					arg_408 = G__1822000044__9_ }; if linked_404 == nil { return ifn_405.Invoke_O_O_O__O(arg_406, arg_407, arg_408) } else { return linked_404.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_403, arg_406, arg_407, arg_408) } }
//line :111:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_16) {





















			var root_435 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = acc__1; var arg_439 any; var root_441 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_445 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = f__2; if linked_446 == nil { arg_444 = ifn_447.Invoke_O__O(arg_448) } else { arg_444 = linked_446.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_445, arg_448) }; if linked_442 == nil { arg_439 = ifn_443.Invoke_O__O(arg_444) } else { arg_439 = linked_442.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_441, arg_444) }; var arg_440 any; var tmp33 any = A_arbace_go_A_const_63; var tmp34 *lang.Keyword = A_arbace_go_A_const_63; var tmp35 any; var root_449 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = f__2; if linked_450 == nil { tmp35 = ifn_451.Invoke_O__O(arg_452) } else { tmp35 = linked_450.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_449, arg_452) }; arg_440 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp35)))); if linked_436 == nil { return ifn_437.Invoke_O_O_O__O(arg_438, arg_439, arg_440) } else { return linked_436.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_435, arg_438, arg_439, arg_440) } }
//line :111:1
		default:}; return acc__1
	}
}





























func A_arbace_go_member_var_A_New() *A_arbace_go_member_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_member_var_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_member_var_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_member_var_A) Invoke_O_O_O_O_O_O_O__O(self, ns__0, path__1, nm__2, kind__3, handle__4, info__5 any) any { var full__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, path__1, nil, nm__2)).Ref(); var m__8 any; var G__1822000047__8_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_A_const_73, kind__3, A_arbace_go_A_const_74, path__1)); var G__1822000047__9_ any; if



	jrt.J2g_Truth(A_arbace_go_A_const_63.Invoke_O__O(info__5)) {
		var root_458 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = G__1822000047__8_; var arg_462 any = A_arbace_go_A_const_63; var arg_463 any = A_arbace_go_A_const_63.Invoke_O__O(info__5); if linked_459 == nil { G__1822000047__9_ = ifn_460.Invoke_O_O_O__O(arg_461, arg_462, arg_463) } else { G__1822000047__9_ = linked_459.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_458, arg_461, arg_462, arg_463) } } else {
//line :147:1
			G__1822000047__9_ = G__1822000047__8_ }; if jrt.J2g_Truth(A_arbace_go_A_const_64.Invoke_O__O(info__5)) {

				var root_464 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = G__1822000047__9_; var arg_468 any = A_arbace_go_A_const_64; var arg_469 any = A_arbace_go_A_const_64.Invoke_O__O(info__5); if linked_465 == nil { m__8 = ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { m__8 = linked_465.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } } else {
//line :147:1
					m__8 = G__1822000047__9_ }; var root_470 any =


	A_arbace_go_A_const_75.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = ns__0; var arg_474 any; var root_476 any = A_arbace_go_A_const_76.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = nm__2; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any = m__8; if linked_477 == nil { arg_474 = ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { arg_474 = linked_477.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) }; var arg_475 any; var G__1822000048__9_ any = kind__3; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1822000048__9_) >> 3 & 7 { case 1: if any(G__1822000048__9_) == any(A_arbace_go_A_const_77) { arg_475 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 3: if any(G__1822000048__9_) == any(A_arbace_go_A_const_78) { arg_475 = lang.GoVar_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 4: if any(G__1822000048__9_) == any(A_arbace_go_A_const_79) { arg_475 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 5: if any(G__1822000048__9_) == any(A_arbace_go_A_const_68) {



		arg_475 = A_arbace_go_A_const_68.Invoke_O__O(info__5)
//line :151:1
		break L1 }; case 6: if any(G__1822000048__9_) == any(A_arbace_go_A_const_80) { arg_475 = lang.GoType_New_O(handle__4); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1822000048__9_)))))}; if /*line :150:1*/ linked_471 == nil { return ifn_472.Invoke_O_O_O__O(arg_473, arg_474, arg_475) } else { return linked_471.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_470, arg_473, arg_474, arg_475) } }






func A_arbace_go_table_ns_BANG__A_New() *A_arbace_go_table_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Ctor() {}
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any { var ns__2 any; var root_486 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_488 lang.IFn; if




	linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; var root_490 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, A_arbace_go_path__GT_ns_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = p__0; if linked_491 == nil { arg_489 = ifn_492.Invoke_O__O(arg_493) } else { arg_489 = linked_491.(*A_arbace_go_path__GT_ns_A).Invoke_O_O__O(root_490, arg_493) }; if linked_487 == nil { ns__2 = ifn_488.Invoke_O__O(arg_489) } else { ns__2 = linked_487.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_486, arg_489) }; var ms__3 any = /*line :157:1*/lang.GoInterp_Members_String__O1(jrt.String_Cast(p__0)).Ref(); var members__4 any; var root_494 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_496 lang.IFn; if






	linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_498 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New(); var tmp2 *jrt.Class; var fncls__565 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class; if fncls__565 == nil { var fncls__565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class = fncls__565d; tmp2 = fncls__565d } else { tmp2 = fncls__565 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_566 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = A_arbace_go_A_const_94; var arg_570 any = ms__3; if linked_567 == nil { tmp4 = ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { tmp4 = linked_567.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) }; arg_498 = tmp3.Invoke_O__O(tmp4); if linked_495 == nil { members__4 = ifn_496.Invoke_O_O__O(arg_497, arg_498) } else { members__4 = linked_495.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_494, arg_497, arg_498) }; var info__5 any; var tmp5 any = /*line :157:1*/A_arbace_go_table_ns_BANG__fn__1822000066_A_New_O(p__0); var tmp6 *jrt.Class; var fncls__575 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000066_A_fn_class; if







	fncls__575 == nil { var fncls__575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_table_ns_BANG__fn__1822000066_A_fn_class = fncls__575d; tmp6 = fncls__575d } else { tmp6 = fncls__575 }; info__5 = /*line :157:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var consts__6 any; var tmp7 any = A_arbace_go_table_ns_BANG__fn__1822000068_A_New_O_O(info__5, members__4); var tmp8 *jrt.Class; var fncls__680 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000068_A_fn_class; if








	fncls__680 == nil { var fncls__680d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_table_ns_BANG__fn__1822000068_A_fn_class = fncls__680d; tmp8 = fncls__680d } else { tmp8 = fncls__680 }; consts__6 = /*line :157:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var make__7 any; var tmp9 any = A_arbace_go_table_ns_BANG__make__1822000086_A_New_O_O_O_O_O(ns__2, info__5, consts__6, p__0, members__4); var tmp10 *jrt.Class; var fncls__719 *jrt.Class = A_arbace_go_table_ns_BANG__make__1822000086_A_fn_class; if









	fncls__719 == nil { var fncls__719d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_table_ns_BANG__make__1822000086_A_fn_class = fncls__719d; tmp10 = fncls__719d } else { tmp10 = fncls__719 }; make__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var resolver__8 any; var tmp11 any = /*line :157:1*/A_arbace_go_table_ns_BANG__resolver__1822000091_A_New_O_O_O(make__7, consts__6, members__4); var tmp12 *jrt.Class; var fncls__773 *jrt.Class = A_arbace_go_table_ns_BANG__resolver__1822000091_A_fn_class; if


















	fncls__773 == nil { var fncls__773d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_table_ns_BANG__resolver__1822000091_A_fn_class = fncls__773d; tmp12 = fncls__773d } else { tmp12 = fncls__773 }; resolver__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil);





	jrt.NN(lang.Namespace_Cast(ns__2)).SetResolver_O__V(resolver__8); return ns__2 }
//line :164:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New() *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Ctor() {}
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Invoke_O_O__O(self, s__1822000051__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O(s__1822000051__1, self); var tmp2 *jrt.Class; var fncls__564 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class; if fncls__564 == nil { var fncls__564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class = fncls__564d; tmp2 = fncls__564d } else { tmp2 = fncls__564 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :164:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Ctor_O_O(c__s__1822000051, c__iter__1822000050 any) { t.F_s__1822000051 = c__s__1822000051; t.F_iter__1822000050 = c__iter__1822000050 }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Invoke_O__O(self any) any { { var s__1822000051__1 any; var t_ any = t.F_s__1822000051; t.F_s__1822000051 = nil; s__1822000051__1 = t_; for { var temp__1927000414__auto____2 any; var root_499 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = s__1822000051__1; if linked_500 == nil { temp__1927000414__auto____2 = ifn_501.Invoke_O__O(arg_502) } else { temp__1927000414__auto____2 = linked_500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_499, arg_502) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000051__3 any = temp__1927000414__auto____2; var tmp1 any; var root_503 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = s__1822000051__3; if linked_504 == nil { tmp1 = ifn_505.Invoke_O__O(arg_506) } else { tmp1 = linked_504.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_507 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__1822000051__3; if linked_508 == nil { c__1927001037__auto____4 = ifn_509.Invoke_O__O(arg_510) } else { c__1927001037__auto____4 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_507, arg_510) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000053__6 any; var root_511 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_512 == nil { b__1822000053__6 = ifn_513.Invoke_O__O(arg_514) } else { b__1822000053__6 = linked_512.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_511, arg_514) }; var tmp2 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_I_O(b__1822000053__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class = fncls__524d; tmp3 = fncls__524d } else { tmp3 = fncls__524 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_525 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any; var root_530 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = b__1822000053__6; if linked_531 == nil { arg_528 = ifn_532.Invoke_O__O(arg_533) } else { arg_528 = linked_531.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_530, arg_533) }; var arg_529 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp5 any; var root_534 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = s__1822000051__3; if linked_535 == nil { tmp5 = ifn_536.Invoke_O__O(arg_537) } else { tmp5 = linked_535.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_534, arg_537) }; arg_529 = tmp4.Invoke_O__O(tmp5); if linked_526 == nil { return ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { return linked_526.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) } } else { var root_538 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var root_543 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = b__1822000053__6; if linked_544 == nil { arg_541 = ifn_545.Invoke_O__O(arg_546) } else { arg_541 = linked_544.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_543, arg_546) }; var arg_542 any; if linked_539 == nil { return ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { return linked_539.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) } } } else { var vec__1822000061__4 any; var root_547 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = s__1822000051__3; if linked_548 == nil { vec__1822000061__4 = ifn_549.Invoke_O__O(arg_550) } else { vec__1822000061__4 = linked_548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_547, arg_550) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_551 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var tmp6 any; var root_556 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = k__5; if linked_557 == nil { tmp6 = ifn_558.Invoke_O__O(arg_559) } else { tmp6 = linked_557.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_556, arg_559) }; arg_554 = lang.Tuple_Create_O_O__IPersistentVector(n__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6, h__7)); var arg_555 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp8 any; var root_560 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__1822000051__3; if linked_561 == nil { tmp8 = ifn_562.Invoke_O__O(arg_563) } else { tmp8 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; arg_555 = tmp7.Invoke_O__O(tmp8); if linked_552 == nil { return ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { return linked_552.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :164:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Ctor_O_I_O(c__b__1822000053 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000053 = c__b__1822000053; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Invoke_O__O(self any) any { { var i__1822000052__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000052__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000057__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000052__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_515 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = t.F_b__1822000053; var arg_519 any; var tmp2 any; var root_520 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = k__3; if linked_521 == nil { tmp2 = ifn_522.Invoke_O__O(arg_523) } else { tmp2 = linked_521.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_520, arg_523) }; arg_519 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.Tuple_Create_O_O__IPersistentVector(tmp2, h__5)); if linked_516 == nil { ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { linked_516.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }; i__1822000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000052__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__fn__1822000066_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000066_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000066_A{}; t.Ctor_O(p0); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000066_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000066_A) Invoke_O__O(self any) any { var root_571 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_go_digest_info_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any; var t_ any = t.F_p; t.F_p = nil; arg_574 = t_; if linked_572 == nil { return ifn_573.Invoke_O__O(arg_574) } else { return linked_572.(*A_arbace_go_digest_info_A).Invoke_O_O__O(root_571, arg_574) } }
func A_arbace_go_table_ns_BANG__fn__1822000068_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__fn__1822000068_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_A) Ctor_O_O(c__info, c__members any) { t.F_info = c__info; t.F_members = c__members }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_A) Invoke_O__O(self any) any { var root_576 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_580 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A_New_O(t.F_members); var tmp2 *jrt.Class; var fncls__675 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A_fn_class; if fncls__675 == nil { var fncls__675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A_fn_class = fncls__675d; tmp2 = fncls__675d } else { tmp2 = fncls__675 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_676 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var t_ any = t.F_info; t.F_info = nil; arg_679 = t_; if linked_677 == nil { tmp4 = ifn_678.Invoke_O__O(arg_679) } else { tmp4 = linked_677.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_676, arg_679) }; arg_580 = tmp3.Invoke_O__O(tmp4); if linked_577 == nil { return ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { return linked_577.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) } }
//line :166:1
func A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A) Ctor_O(c__members any) { t.F_members = c__members }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A) Invoke_O_O__O(self, s__1822000070__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A_New_O_O_O(self, s__1822000070__1, t.F_members); var tmp2 *jrt.Class; var fncls__674 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A_fn_class; if fncls__674 == nil { var fncls__674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A_fn_class = fncls__674d; tmp2 = fncls__674d } else { tmp2 = fncls__674 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :166:1
func A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A) Ctor_O_O_O(c__iter__1822000069, c__s__1822000070, c__members any) { t.F_iter__1822000069 = c__iter__1822000069; t.F_s__1822000070 = c__s__1822000070; t.F_members = c__members }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A) Invoke_O__O(self any) any { { var s__1822000070__1 any; var t_ any = t.F_s__1822000070; t.F_s__1822000070 = nil; s__1822000070__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_581 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__1822000070__1; if linked_582 == nil { temp__1927000414__auto____2 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____2 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000070__3 any = temp__1927000414__auto____2; var tmp1 any; var root_585 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__1822000070__3; if linked_586 == nil { tmp1 = ifn_587.Invoke_O__O(arg_588) } else { tmp1 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_589 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__1822000070__3; if linked_590 == nil { c__1927001037__auto____4 = ifn_591.Invoke_O__O(arg_592) } else { c__1927001037__auto____4 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000072__6 any; var root_593 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_594 == nil { b__1822000072__6 = ifn_595.Invoke_O__O(arg_596) } else { b__1822000072__6 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_593, arg_596) }; var tmp2 any = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A_New_O_I_O_O(t.F_members, size__1927001038__auto____5, b__1822000072__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__616 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A_fn_class; if fncls__616 == nil { var fncls__616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A_fn_class = fncls__616d; tmp3 = fncls__616d } else { tmp3 = fncls__616 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_617 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var root_622 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = b__1822000072__6; if linked_623 == nil { arg_620 = ifn_624.Invoke_O__O(arg_625) } else { arg_620 = linked_623.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_622, arg_625) }; var arg_621 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000069); var tmp5 any; var root_626 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = s__1822000070__3; if linked_627 == nil { tmp5 = ifn_628.Invoke_O__O(arg_629) } else { tmp5 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_626, arg_629) }; arg_621 = tmp4.Invoke_O__O(tmp5); if linked_618 == nil { return ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { return linked_618.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) } } else { var root_630 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any; var root_635 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = b__1822000072__6; if linked_636 == nil { arg_633 = ifn_637.Invoke_O__O(arg_638) } else { arg_633 = linked_636.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_635, arg_638) }; var arg_634 any; if linked_631 == nil { return ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { return linked_631.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) } } } else { var vec__1822000080__4 any; var root_639 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = s__1822000070__3; if linked_640 == nil { vec__1822000080__4 = ifn_641.Invoke_O__O(arg_642) } else { vec__1822000080__4 = linked_640.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_639, arg_642) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000080__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_643 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = i__6; var arg_647 any = A_arbace_go_A_const_68; if linked_644 == nil { tmp6 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { tmp6 = linked_644.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_648 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = t.F_members; var arg_656 any = n__5; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { tmp7 = ifn_650.Invoke_O__O(arg_651) } else { tmp7 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp7) { var root_657 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, i__6); var arg_661 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000069); var tmp9 any; var root_662 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = s__1822000070__3; if linked_663 == nil { tmp9 = ifn_664.Invoke_O__O(arg_665) } else { tmp9 = linked_663.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_662, arg_665) }; arg_661 = tmp8.Invoke_O__O(tmp9); if linked_658 == nil { return ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { return linked_658.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) } } else { var tmp10 any; var root_666 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = s__1822000070__3; if linked_667 == nil { tmp10 = ifn_668.Invoke_O__O(arg_669) } else { tmp10 = linked_667.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_666, arg_669) }; s__1822000070__1 = tmp10; continue L1 } } else { var tmp11 any; var root_670 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = s__1822000070__3; if linked_671 == nil { tmp11 = ifn_672.Invoke_O__O(arg_673) } else { tmp11 = linked_671.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_670, arg_673) }; s__1822000070__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :166:1
func A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A) Ctor_O_I_O_O(c__members any, c__size__1927001038__auto__ int32, c__b__1822000072, c__c__1927001037__auto__ any) { t.F_members = c__members; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1822000072 = c__b__1822000072; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :166:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A) Invoke_O__O(self any) any { { var i__1822000071__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000071__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000076__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000071__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000076__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000076__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_597 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = i__4; var arg_601 any = A_arbace_go_A_const_68; if linked_598 == nil { tmp2 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { tmp2 = linked_598.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_602 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any; var root_606 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_members; var arg_610 any = n__3; if linked_607 == nil { arg_605 = ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { arg_605 = linked_607.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; if linked_603 == nil { tmp3 = ifn_604.Invoke_O__O(arg_605) } else { tmp3 = linked_603.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_602, arg_605) }; if jrt.J2g_Truth(tmp3) { var root_611 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = t.F_b__1822000072; var arg_615 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, i__4); if linked_612 == nil { ifn_613.Invoke_O_O__O(arg_614, arg_615) } else { linked_612.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_611, arg_614, arg_615) }; i__1822000071__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000071__1); continue L1 } else { i__1822000071__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000071__1); continue L1 } } else { i__1822000071__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000071__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__make__1822000086_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_table_ns_BANG__make__1822000086_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__make__1822000086_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :167:1
func (t *A_arbace_go_table_ns_BANG__make__1822000086_A) Ctor_O_O_O_O_O(c__ns, c__info, c__consts, c__p, c__members any) { t.F_ns = c__ns; t.F_info = c__info; t.F_consts = c__consts; t.F_p = c__p; t.F_members = c__members }
//line :167:1
func (t *A_arbace_go_table_ns_BANG__make__1822000086_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_members, n__1); if
												jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1822000087__3 any = temp__1927000408__auto____2; var kind__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000087__3, lang.RT_IntCast_J__I_NoInit(0), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000087__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_681 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_go_member_var_A_fn_class); var ifn_683 lang.IFn
													if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = t.F_ns; var arg_685 any = t.F_p; var arg_686 any = n__1; var arg_687 any = kind__4; var arg_688 any = h__5; var arg_689 any; var tmp1 any; var root_690 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = t.F_info; if linked_691 == nil { tmp1 = ifn_692.Invoke_O__O(arg_693) } else { tmp1 = linked_691.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_690, arg_693) }; arg_689 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if linked_682 == nil { return ifn_683.Invoke_O_O_O_O_O_O__O(arg_684, arg_685, arg_686, arg_687, arg_688, arg_689) } else { return linked_682.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_681, arg_684, arg_685, arg_686, arg_687, arg_688, arg_689) } } else {
//line :168:1
			var temp__1927000408__auto____3 any; var tmp2 any; var root_694 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_696 lang.IFn

			if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = t.F_consts; if linked_695 == nil { tmp2 = ifn_696.Invoke_O__O(arg_697) } else { tmp2 = linked_695.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_694, arg_697) }; temp__1927000408__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__1); if jrt.J2g_Truth(temp__1927000408__auto____3) { var i__4 any = temp__1927000408__auto____3; var root_698 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, A_arbace_go_member_var_A_fn_class); var ifn_700 lang.IFn
				if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = t.F_ns; var arg_702 any = t.F_p; var arg_703 any = n__1; var arg_704 any = A_arbace_go_A_const_68; var arg_705 any; var arg_706 any = i__4; if linked_699 == nil { return ifn_700.Invoke_O_O_O_O_O_O__O(arg_701, arg_702, arg_703, arg_704, arg_705, arg_706) } else { return linked_699.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_698, arg_701, arg_702, arg_703, arg_704, arg_705, arg_706) } } else {


					var tmp3 *lang.Keyword = A_arbace_go_A_const_66; var tmp4 any; var root_707 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = t.F_info; if linked_708 == nil { tmp4 = ifn_709.Invoke_O__O(arg_710) } else { tmp4 = linked_708.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_707, arg_710) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(tmp4, n__1))) {
						var tmp5 any; var root_711 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_go_repl_fn_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = Lit_63; if linked_712 == nil { tmp5 = ifn_713.Invoke_O__O(arg_714) } else { tmp5 = linked_712.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_711, arg_714) }; var tmp6 lang.IFn = lang.IFn_Cast(tmp5); var tmp7 any = t.F_ns; var tmp8 any = t.F_p; var tmp9 any; var root_715 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = t.F_info; if linked_716 == nil { tmp9 = ifn_717.Invoke_O__O(arg_718) } else { tmp9 = linked_716.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_715, arg_718) }; return tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, n__1, lang.RT_Get_O_O__O_NoInit(tmp9, n__1)) } else {
//line :174:1
							return nil } } } }

func A_arbace_go_table_ns_BANG__resolver__1822000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__resolver__1822000091_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__resolver__1822000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000091_A) Ctor_O_O_O(c__make, c__consts, c__members any) { t.F_make = c__make; t.F_consts = c__consts; t.F_members = c__members }
//line :176:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000091_A) Invoke_O_O_O__O(self, ___1, sym__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(t.F_make); var tmp2 any; var root_720 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = sym__2; if linked_721 == nil { tmp2 = ifn_722.Invoke_O__O(arg_723) } else { tmp2 = linked_721.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_720, arg_723) }; return tmp1.Invoke_O__O(tmp2) }
//line :176:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000091_A) Invoke_O_O__O(self, ___1 any) any { { var seq_1822000092__2 any; var root_724 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_726 lang.IFn

	if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any; var root_728 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var root_732 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any; var root_737 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = t.F_members; if linked_738 == nil { arg_735 = ifn_739.Invoke_O__O(arg_740) } else { arg_735 = linked_738.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_737, arg_740) }; var arg_736 any; var root_741 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any; var root_745 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = t.F_consts; if linked_746 == nil { arg_744 = ifn_747.Invoke_O__O(arg_748) } else { arg_744 = linked_746.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_745, arg_748) }; if linked_742 == nil { arg_736 = ifn_743.Invoke_O__O(arg_744) } else { arg_736 = linked_742.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_741, arg_744) }; if linked_733 == nil { arg_731 = ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { arg_731 = linked_733.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_732, arg_735, arg_736) }; if linked_729 == nil { arg_727 = ifn_730.Invoke_O__O(arg_731) } else { arg_727 = linked_729.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_728, arg_731) }; if linked_725 == nil { seq_1822000092__2 = ifn_726.Invoke_O__O(arg_727) } else { seq_1822000092__2 = linked_725.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_724, arg_727) }
//line :176:1
	var chunk_1822000093__3 any; var count_1822000094__4 int64 = 0; var i_1822000095__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000095__5, count_1822000094__4) { var n__6 any = lang.Indexed_Cast(chunk_1822000093__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000095__5))
			lang.IFn_Cast(t.F_make).Invoke_O__O(n__6)
//line :178:1
			seq_1822000092__2, chunk_1822000093__3, count_1822000094__4, i_1822000095__5 = seq_1822000092__2, chunk_1822000093__3, count_1822000094__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000095__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_749 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = seq_1822000092__2; if linked_750 == nil { temp__1927000414__auto____6 = ifn_751.Invoke_O__O(arg_752) } else { temp__1927000414__auto____6 = linked_750.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1822000092__7 any = temp__1927000414__auto____6; var tmp1 any; var root_753 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = seq_1822000092__7; if linked_754 == nil { tmp1 = ifn_755.Invoke_O__O(arg_756) } else { tmp1 = linked_754.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_753, arg_756) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_757 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = seq_1822000092__7; if linked_758 == nil { c__1927000678__auto____8 = ifn_759.Invoke_O__O(arg_760) } else { c__1927000678__auto____8 = linked_758.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_757, arg_760) }; var tmp2 any; var root_765 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = seq_1822000092__7; if linked_766 == nil { tmp2 = ifn_767.Invoke_O__O(arg_768) } else { tmp2 = linked_766.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_765, arg_768) }; seq_1822000092__2, chunk_1822000093__3, count_1822000094__4, i_1822000095__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_761 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = seq_1822000092__7; if linked_762 == nil { n__8 = ifn_763.Invoke_O__O(arg_764) } else { n__8 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) }
				lang.IFn_Cast(t.F_make).Invoke_O__O(n__8)
//line :178:1
				var tmp3 any; var root_769 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = seq_1822000092__7; if linked_770 == nil { tmp3 = ifn_771.Invoke_O__O(arg_772) } else { tmp3 = linked_770.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_769, arg_772) }; seq_1822000092__2, chunk_1822000093__3, count_1822000094__4, i_1822000095__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :176:1*/panic("j2g: unreachable") }








func A_arbace_go_interpretable_ns_BANG__A_New() *A_arbace_go_interpretable_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_interpretable_ns_BANG__A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Ctor() {}
//line :185:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any {





	var tmp1 *jrt.Boolean; var tmp2 any; var root_774 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, A_arbace_go_repl_fn_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = Lit_29; if linked_775 == nil { tmp2 = ifn_776.Invoke_O__O(arg_777) } else { tmp2 = linked_775.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_774, arg_777) }; if jrt.J2g_Truth(lang.IFn_Cast(tmp2).Invoke_O__O(p__0)) {
		var tmp3 any; var root_778 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, A_arbace_go_repl_fn_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = Lit_30; if linked_779 == nil { tmp3 = ifn_780.Invoke_O__O(arg_781) } else { tmp3 = linked_779.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_778, arg_781) }; lang.IFn_Cast(tmp3).Invoke_O__O(p__0)
//line :191:1
		tmp1 = jrt.Boolean_TRUE } else { tmp1 = nil }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref())).Ref()
}


func A_arbace_go_packages_A_New() *A_arbace_go_packages_A { A_arbace_go_A_Init(); t := &A_arbace_go_packages_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_go_packages_A) Ctor() {}
//line :195:1
func (t *A_arbace_go_packages_A) Invoke_O__O(self any) any {


	var root_782 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = lang.GoInterp_Paths__O1().Ref(); if linked_783 == nil { return ifn_784.Invoke_O__O(arg_785) } else { return linked_783.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_782, arg_785)
	}
}


func A_arbace_go_new_A_New() *A_arbace_go_new_A { A_arbace_go_A_Init(); t := &A_arbace_go_new_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_go_new_A) Ctor() {}
//line :203:1
func (t *A_arbace_go_new_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_NewValue_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_zero_A_New() *A_arbace_go_zero_A { A_arbace_go_A_Init(); t := &A_arbace_go_zero_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_zero_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_zero_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_Zero_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_type_of_A_New() *A_arbace_go_type_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_of_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_type_of_A) Ctor() {}
//line :213:1
func (t *A_arbace_go_type_of_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_TypeOf_O__O(v__0)
}
func A_arbace_go_str_A_New() *A_arbace_go_str_A { A_arbace_go_A_Init(); t := &A_arbace_go_str_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_str_A) Ctor() {}
//line :218:1
func (t *A_arbace_go_str_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_Str_O__String(v__0).Ref()
}
func A_arbace_go_spread_A_New() *A_arbace_go_spread_A { A_arbace_go_A_Init(); t := &A_arbace_go_spread_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_spread_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_spread_A) Invoke_O_O__O(self, xs__0 any) any {



	return lang.GoInterp_Spread_O__O(xs__0)
}
func A_arbace_go_assign_BANG__A_New() *A_arbace_go_assign_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_assign_BANG__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_assign_BANG__A) Ctor() {}
//line :229:1
func (t *A_arbace_go_assign_BANG__A) Invoke_O_O_O__O(self, v__0, x__1 any) any {



	lang.GoInterp_Store_O_O__V(lang.GoVar_Cast(v__0).F_cell, x__1)
//line :229:1
	return x__1
}











func A_arbace_go_type_names_A_New() *A_arbace_go_type_names_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_type_names_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_type_names_A) Invoke_O_O__O(self, ts__0 any) any { var root_786 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_790 any; var root_791 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = Lit_64; var arg_795 any; var root_796 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any; var tmp1 any = A_arbace_go_type_names_fn__1822000107_A_New(); var tmp2 *jrt.Class; var fncls__801 *jrt.Class = A_arbace_go_type_names_fn__1822000107_A_fn_class; if fncls__801 == nil { var fncls__801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_type_names_fn__1822000107_A_fn_class = fncls__801d; tmp2 = fncls__801d } else { tmp2 = fncls__801 }; arg_799 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_800 any = ts__0; if linked_797 == nil { arg_795 = ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { arg_795 = linked_797.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_796, arg_799, arg_800) }; if linked_792 == nil { arg_790 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { arg_790 = linked_792.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) }; if linked_787 == nil { return ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { return linked_787.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) } }
//line :242:1
func A_arbace_go_type_names_fn__1822000107_A_New() *A_arbace_go_type_names_fn__1822000107_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_fn__1822000107_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_type_names_fn__1822000107_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_type_names_fn__1822000107_A) Invoke_O_O__O(self, p1__1822000106_SHARP___1 any) any { return jrt.NN(lang.GoType_Cast(p1__1822000106_SHARP___1)).GetName__String().Ref() }

func A_arbace_go_reify_type_A_New() *A_arbace_go_reify_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_type_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_reify_type_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_reify_type_A) Invoke_O_O__O(self, ts__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_802 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_804 lang.IFn; if



	linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = A_arbace_go_A_const_102.GetRawRoot__O(); if linked_803 == nil { tmp1 = ifn_804.Invoke_O__O(arg_805) } else { tmp1 = linked_803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_802, arg_805) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, ts__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var root_806 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_808 lang.IFn
		if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = lang.GoInterp_ReifyType_O1__O1(lang.RT_Object_array_O__O1_NoInit(ts__0)).Ref(); if linked_807 == nil { r__3 = ifn_808.Invoke_O__O(arg_809) } else { r__3 = linked_807.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_806, arg_809) }
		var root_810 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = A_arbace_go_A_const_102.GetRawRoot__O(); var arg_814 any = A_arbace_go_A_const_62.GetRawRoot__O(); var arg_815 any = ts__0; var arg_816 any = r__3; if linked_811 == nil { ifn_812.Invoke_O_O_O_O__O(arg_813, arg_814, arg_815, arg_816) } else { linked_811.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_810, arg_813, arg_814, arg_815, arg_816) }
//line :248:1
		return r__3 } }




func A_arbace_go_reify_data_A_New() *A_arbace_go_reify_data_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_go_reify_data_A) Ctor() {}
//line :253:1
func (t *A_arbace_go_reify_data_A) Invoke_O_O_O_O__O(self, rt__0, ts__1, fns__2 any) any { var vec__1822000111__4 any = rt__0; var seq__1822000112__5 any; var root_817 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_819 lang.IFn; if




	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = vec__1822000111__4; if linked_818 == nil { seq__1822000112__5 = ifn_819.Invoke_O__O(arg_820) } else { seq__1822000112__5 = linked_818.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_817, arg_820) }; var first__1822000113__6 any; var root_821 any = /*line :253:1*/A_arbace_go_A_const_25.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_823 lang.IFn; if




	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = seq__1822000112__5; if linked_822 == nil { first__1822000113__6 = ifn_823.Invoke_O__O(arg_824) } else { first__1822000113__6 = linked_822.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_821, arg_824) }; var seq__1822000112__7 any; var root_825 any = /*line :253:1*/A_arbace_go_A_const_22.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_827 lang.IFn; if




	linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = seq__1822000112__5; if linked_826 == nil { seq__1822000112__7 = ifn_827.Invoke_O__O(arg_828) } else { seq__1822000112__7 = linked_826.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_825, arg_828) }; var t__8 any = first__1822000113__6; var names__9 any = seq__1822000112__7; var seq_1822000114__10 any; var root_901 any = /*line :253:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_903 lang.IFn; if





	linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_905 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = fns__2; if linked_906 == nil { arg_904 = ifn_907.Invoke_O__O(arg_908) } else { arg_904 = linked_906.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_905, arg_908) }; if linked_902 == nil { seq_1822000114__10 = ifn_903.Invoke_O__O(arg_904) } else { seq_1822000114__10 = linked_902.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_901, arg_904) }; var chunk_1822000115__11 any; var count_1822000116__12 int64 = 0; var i_1822000117__13 int64 = 0; L1:
//line :253:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000117__13, count_1822000116__12) { var k__14 any = lang.Indexed_Cast(chunk_1822000115__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000117__13)); var tmp1 any; var root_925 any = A_arbace_go_A_const_105.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_927 lang.IFn
			if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__14)); var arg_929 any = names__9; if linked_926 == nil { tmp1 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { tmp1 = linked_926.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp3 any; var root_930 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_go_type_names_A_fn_class); var ifn_932 lang.IFn

				if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = ts__1; if linked_931 == nil { tmp3 = ifn_932.Invoke_O__O(arg_933) } else { tmp3 = linked_931.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_930, arg_933) }
//line :260:1
				panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__14, nil, tmp3))))) }
//line :259:1
			seq_1822000114__10, chunk_1822000115__11, count_1822000116__12, i_1822000117__13 = seq_1822000114__10, chunk_1822000115__11, count_1822000116__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000117__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_909 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = seq_1822000114__10; if linked_910 == nil { temp__1927000414__auto____14 = ifn_911.Invoke_O__O(arg_912) } else { temp__1927000414__auto____14 = linked_910.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_909, arg_912) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000114__15 any = temp__1927000414__auto____14; var tmp4 any; var root_913 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = seq_1822000114__15; if linked_914 == nil { tmp4 = ifn_915.Invoke_O__O(arg_916) } else { tmp4 = linked_914.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_913, arg_916) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____16 any; var root_917 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = seq_1822000114__15; if linked_918 == nil { c__1927000678__auto____16 = ifn_919.Invoke_O__O(arg_920) } else { c__1927000678__auto____16 = linked_918.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_917, arg_920) }; var tmp5 any; var root_934 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = seq_1822000114__15; if linked_935 == nil { tmp5 = ifn_936.Invoke_O__O(arg_937) } else { tmp5 = linked_935.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_934, arg_937) }; seq_1822000114__10, chunk_1822000115__11, count_1822000116__12, i_1822000117__13 = tmp5, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__16 any; var root_921 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = seq_1822000114__15; if linked_922 == nil { k__16 = ifn_923.Invoke_O__O(arg_924) } else { k__16 = linked_922.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_921, arg_924) }
				var tmp6 any; var root_938 any = A_arbace_go_A_const_105.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__16)); var arg_942 any = names__9; if linked_939 == nil { tmp6 = ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { tmp6 = linked_939.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) }; if jrt.J2g_Truth(tmp6) { } else { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp8 any; var root_943 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, A_arbace_go_type_names_A_fn_class); var ifn_945 lang.IFn

					if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = ts__1; if linked_944 == nil { tmp8 = ifn_945.Invoke_O__O(arg_946) } else { tmp8 = linked_944.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_943, arg_946) }
//line :260:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, k__16, nil, tmp8))))) }
//line :259:1
				var tmp9 any; var root_947 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = seq_1822000114__15; if linked_948 == nil { tmp9 = ifn_949.Invoke_O__O(arg_950) } else { tmp9 = linked_948.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_947, arg_950) }; seq_1822000114__10, chunk_1822000115__11, count_1822000116__12, i_1822000117__13 = tmp9, nil, 0, 0; continue L1 } } }
//line :253:1
		break L1 }; var tmp10 any; var root_829 any =









	A_arbace_go_A_const_92.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_831 lang.IFn; if
	linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = t__8; var arg_833 any; var iter__1927001039__auto____10 any; var tmp11 any = A_arbace_go_reify_data_iter__1822000118__1822000122_A_New_O_O(fns__2, ts__1); var tmp12 *jrt.Class; var fncls__900 *jrt.Class = A_arbace_go_reify_data_iter__1822000118__1822000122_A_fn_class; if fncls__900 == nil { var fncls__900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_reify_data_iter__1822000118__1822000122_A_fn_class = fncls__900d; tmp12 = fncls__900d } else { tmp12 = fncls__900 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_833 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(names__9); if linked_830 == nil { tmp10 = ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { tmp10 = linked_830.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) }; return /*line :263:1*/ lang.RT_Object_array_O__O1_NoInit(tmp10).Ref() }
func A_arbace_go_reify_data_iter__1822000118__1822000122_A_New_O_O(p0, p1 any) *A_arbace_go_reify_data_iter__1822000118__1822000122_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000118__1822000122_A{}; t.Ctor_O_O(p0, p1); return t }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_A) Ctor_O_O(c__fns, c__ts any) { t.F_fns = c__fns; t.F_ts = c__ts }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_A) Invoke_O_O__O(self, s__1822000119__1 any) any { var tmp1 any = A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A_New_O_O_O_O(s__1822000119__1, self, t.F_fns, t.F_ts); var tmp2 *jrt.Class; var fncls__899 *jrt.Class = A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A_fn_class; if fncls__899 == nil { var fncls__899d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A_fn_class = fncls__899d; tmp2 = fncls__899d } else { tmp2 = fncls__899 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :264:1
func A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A) Ctor_O_O_O_O(c__s__1822000119, c__iter__1822000118, c__fns, c__ts any) { t.F_s__1822000119 = c__s__1822000119; t.F_iter__1822000118 = c__iter__1822000118; t.F_fns = c__fns; t.F_ts = c__ts }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A) Invoke_O__O(self any) any { { var s__1822000119__1 any; var t_ any = t.F_s__1822000119; t.F_s__1822000119 = nil; s__1822000119__1 = t_; for { var temp__1927000414__auto____2 any; var root_834 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = s__1822000119__1; if linked_835 == nil { temp__1927000414__auto____2 = ifn_836.Invoke_O__O(arg_837) } else { temp__1927000414__auto____2 = linked_835.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_834, arg_837) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000119__3 any = temp__1927000414__auto____2; var tmp1 any; var root_838 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = s__1822000119__3; if linked_839 == nil { tmp1 = ifn_840.Invoke_O__O(arg_841) } else { tmp1 = linked_839.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_838, arg_841) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_842 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = s__1822000119__3; if linked_843 == nil { c__1927001037__auto____4 = ifn_844.Invoke_O__O(arg_845) } else { c__1927001037__auto____4 = linked_843.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_842, arg_845) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000121__6 any; var root_846 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_847 == nil { b__1822000121__6 = ifn_848.Invoke_O__O(arg_849) } else { b__1822000121__6 = linked_847.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_846, arg_849) }; var tmp2 any = A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A_New_O_O_I_O_O(b__1822000121__6, t.F_fns, size__1927001038__auto____5, t.F_ts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__859 *jrt.Class = A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A_fn_class; if fncls__859 == nil { var fncls__859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A_fn_class = fncls__859d; tmp3 = fncls__859d } else { tmp3 = fncls__859 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_860 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_865 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = b__1822000121__6; if linked_866 == nil { arg_863 = ifn_867.Invoke_O__O(arg_868) } else { arg_863 = linked_866.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_865, arg_868) }; var arg_864 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000118); var tmp5 any; var root_869 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__1822000119__3; if linked_870 == nil { tmp5 = ifn_871.Invoke_O__O(arg_872) } else { tmp5 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_869, arg_872) }; arg_864 = tmp4.Invoke_O__O(tmp5); if linked_861 == nil { return ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { return linked_861.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) } } else { var root_873 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var root_878 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = b__1822000121__6; if linked_879 == nil { arg_876 = ifn_880.Invoke_O__O(arg_881) } else { arg_876 = linked_879.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_878, arg_881) }; var arg_877 any; if linked_874 == nil { return ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { return linked_874.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) } } } else { var n__4 any; var root_882 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = s__1822000119__3; if linked_883 == nil { n__4 = ifn_884.Invoke_O__O(arg_885) } else { n__4 = linked_883.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_882, arg_885) }; var root_886 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__4)
														if jrt.J2g_Truth(or__1927000174__auto____5) { arg_889 = or__1927000174__auto____5 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp7 any; var root_891 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_go_type_names_A_fn_class); var ifn_893 lang.IFn

		if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = t.F_ts; if linked_892 == nil { tmp7 = ifn_893.Invoke_O__O(arg_894) } else { tmp7 = linked_892.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_891, arg_894) }
//line :265:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp7, nil))))) }
//line :264:1
	var arg_890 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000118); var tmp9 any; var root_895 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__1822000119__3; if linked_896 == nil { tmp9 = ifn_897.Invoke_O__O(arg_898) } else { tmp9 = linked_896.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_895, arg_898) }; arg_890 = tmp8.Invoke_O__O(tmp9); if linked_887 == nil { return ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { return linked_887.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :264:1
func A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A) Ctor_O_O_I_O_O(c__b__1822000121, c__fns any, c__size__1927001038__auto__ int32, c__ts, c__c__1927001037__auto__ any) { t.F_b__1822000121 = c__b__1822000121; t.F_fns = c__fns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ts = c__ts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :264:1
func (t *A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A) Invoke_O__O(self any) any { { var i__1822000120__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000120__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000120__1)); var root_850 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = t.F_b__1822000121; var arg_854 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__2)
															if jrt.J2g_Truth(or__1927000174__auto____3) { arg_854 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp3 any; var root_855 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, A_arbace_go_type_names_A_fn_class); var ifn_857 lang.IFn

		if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = t.F_ts; if linked_856 == nil { tmp3 = ifn_857.Invoke_O__O(arg_858) } else { tmp3 = linked_856.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_855, arg_858) }
//line :265:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp3, nil))))) }
//line :264:1
	if linked_851 == nil { ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { linked_851.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; i__1822000120__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000120__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_fn_A_New() *A_arbace_go_repl_fn_A { A_arbace_go_A_Init(); t := &A_arbace_go_repl_fn_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_go_repl_fn_A) Ctor() {}
//line :272:1
func (t *A_arbace_go_repl_fn_A) Invoke_O_O__O(self, nm__0 any) any { var root_951 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any; var root_955 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = Lit_50; var arg_959 any = nm__0; if linked_956 == nil { arg_954 = ifn_957.Invoke_O_O__O(arg_958, arg_959) } else { arg_954 = linked_956.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_955, arg_958, arg_959) }; if linked_952 == nil { return ifn_953.Invoke_O__O(arg_954) } else { return linked_952.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_951, arg_954) } }

func A_arbace_go_pos_of_A_New() *A_arbace_go_pos_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_pos_of_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_pos_of_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_pos_of_A) Invoke_O_O__O(self, form__0 any) any { var root_960 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__0); var arg_964 any = A_arbace_go_A_const_108; if linked_961 == nil { return ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { return linked_961.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) } }

func A_arbace_go_package_A_New() *A_arbace_go_package_A { A_arbace_go_A_Init(); t := &A_arbace_go_package_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_go_package_A) Ctor() {}
//line :276:1
func (t *A_arbace_go_package_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_965 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_976 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any; var root_980 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_109); var arg_984 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_32); if linked_981 == nil { arg_979 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { arg_979 = linked_981.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) }; if linked_977 == nil { tmp3 = ifn_978.Invoke_O__O(arg_979) } else { tmp3 = linked_977.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_976, arg_979) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_985 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any; var root_989 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_993 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_994 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_996 lang.IFn; if


	linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_go_A_const_112.Get__O(); if linked_995 == nil { tmp8 = ifn_996.Invoke_O__O(arg_997) } else { tmp8 = linked_995.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_994, arg_997) }; arg_993 = /*line :276:1*/tmp7.Invoke_O__O(tmp8); if linked_990 == nil { arg_988 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { arg_988 = linked_990.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }; if linked_986 == nil { tmp6 = ifn_987.Invoke_O__O(arg_988) } else { tmp6 = linked_986.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_985, arg_988) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_998 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any; var root_1002 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1006 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); if linked_1003 == nil { arg_1001 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { arg_1001 = linked_1003.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; if linked_999 == nil { tmp11 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp11 = linked_999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_998, arg_1001) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1007 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any; var root_1011 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1015 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1016 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1018 lang.IFn; if


	linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = opts__3; if linked_1017 == nil { tmp16 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp16 = linked_1017.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1016, arg_1019) }; arg_1015 = /*line :276:1*/tmp15.Invoke_O__O(tmp16); if linked_1012 == nil { arg_1010 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { arg_1010 = linked_1012.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) }; if linked_1008 == nil { tmp14 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp14 = linked_1008.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1007, arg_1010) }; arg_968 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_966 == nil { return ifn_967.Invoke_O__O(arg_968) } else { return linked_966.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_965, arg_968) } }




func A_arbace_go_file_A_New() *A_arbace_go_file_A { A_arbace_go_A_Init(); t := &A_arbace_go_file_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_go_file_A) Ctor() {}
//line :281:1
func (t *A_arbace_go_file_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_1020 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1031 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any; var root_1035 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_113); var arg_1039 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_25); if linked_1036 == nil { arg_1034 = ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { arg_1034 = linked_1036.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) }; if linked_1032 == nil { tmp3 = ifn_1033.Invoke_O__O(arg_1034) } else { tmp3 = linked_1032.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1031, arg_1034) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1040 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var root_1044 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1048 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1049 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1051 lang.IFn; if


	linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = A_arbace_go_A_const_112.Get__O(); if linked_1050 == nil { tmp8 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp8 = linked_1050.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1049, arg_1052) }; arg_1048 = /*line :281:1*/tmp7.Invoke_O__O(tmp8); if linked_1045 == nil { arg_1043 = ifn_1046.Invoke_O_O__O(arg_1047, arg_1048) } else { arg_1043 = linked_1045.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1044, arg_1047, arg_1048) }; if linked_1041 == nil { tmp6 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp6 = linked_1041.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1040, arg_1043) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp12 any; var root_1053 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var root_1057 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1061 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1062 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1064 lang.IFn; if


	linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = A_arbace_go_A_const_31.GetRawRoot__O(); var arg_1066 any = opts__3; if linked_1063 == nil { tmp14 = ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { tmp14 = linked_1063.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }; arg_1061 = /*line :281:1*/tmp13.Invoke_O__O(tmp14); if linked_1058 == nil { arg_1056 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { arg_1056 = linked_1058.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }; if linked_1054 == nil { tmp12 = ifn_1055.Invoke_O__O(arg_1056) } else { tmp12 = linked_1054.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1053, arg_1056) }; arg_1023 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_1021 == nil { return ifn_1022.Invoke_O__O(arg_1023) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1020, arg_1023) } }




func A_arbace_go_declare_STAR__A_New() *A_arbace_go_declare_STAR__A { A_arbace_go_A_Init(); t := &A_arbace_go_declare_STAR__A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_declare_STAR__A) Ctor() {}
//line :286:1
func (t *A_arbace_go_declare_STAR__A) Invoke_O_O_O__O(self, form__0, opts__1 any) any {


	var tmp1 any; var root_1067 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, A_arbace_go_repl_fn_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = Lit_8; if linked_1068 == nil { tmp1 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp1 = linked_1068.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1067, arg_1070) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(form__0, opts__1)
}
func A_arbace_go_func_A_New() *A_arbace_go_func_A { A_arbace_go_A_Init(); t := &A_arbace_go_func_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_func_A) Ctor() {}
//line :291:1
func (t *A_arbace_go_func_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1071 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_114); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1081 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any; var root_1085 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1089 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1086 == nil { arg_1084 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { arg_1084 = linked_1086.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; if linked_1082 == nil { tmp4 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp4 = linked_1082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1081, arg_1084) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1090 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any; var root_1094 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1098 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1099 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1101 lang.IFn; if
														linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1105 any = A_arbace_go_A_const_115.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, A_arbace_go_pos_of_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = _AMPERSAND_form__0; if linked_1106 == nil { arg_1102 = ifn_1107.Invoke_O__O(arg_1108) } else { arg_1102 = linked_1106.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1105, arg_1108) }; var arg_1103 any = A_arbace_go_A_const_116; var arg_1104 any; var root_1109 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = A_arbace_go_A_const_112.Get__O(); if linked_1110 == nil { arg_1104 = ifn_1111.Invoke_O__O(arg_1112) } else { arg_1104 = linked_1110.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1109, arg_1112) }; if linked_1100 == nil { tmp9 = ifn_1101.Invoke_O_O_O__O(arg_1102, arg_1103, arg_1104) } else { tmp9 = linked_1100.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1099, arg_1102, arg_1103, arg_1104) }; arg_1098 = /*line :291:1*/tmp8.Invoke_O__O(tmp9); if linked_1095 == nil { arg_1093 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { arg_1093 = linked_1095.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }; if linked_1091 == nil { tmp7 = ifn_1092.Invoke_O__O(arg_1093) } else { tmp7 = linked_1091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1090, arg_1093) }; arg_1074 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1072 == nil { return ifn_1073.Invoke_O__O(arg_1074) } else { return linked_1072.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1071, arg_1074) } }


func A_arbace_go_method_A_New() *A_arbace_go_method_A { A_arbace_go_A_Init(); t := &A_arbace_go_method_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_go_method_A) Ctor() {}
//line :294:1
func (t *A_arbace_go_method_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1113 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_117); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1123 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var root_1127 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1131 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1128 == nil { arg_1126 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { arg_1126 = linked_1128.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }; if linked_1124 == nil { tmp4 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp4 = linked_1124.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1123, arg_1126) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1132 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any; var root_1136 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1140 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1141 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1143 lang.IFn; if
														linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any; var root_1147 any = A_arbace_go_A_const_115.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_go_pos_of_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = _AMPERSAND_form__0; if linked_1148 == nil { arg_1144 = ifn_1149.Invoke_O__O(arg_1150) } else { arg_1144 = linked_1148.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1147, arg_1150) }; var arg_1145 any = A_arbace_go_A_const_116; var arg_1146 any; var root_1151 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = A_arbace_go_A_const_112.Get__O(); if linked_1152 == nil { arg_1146 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1146 = linked_1152.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1151, arg_1154) }; if linked_1142 == nil { tmp9 = ifn_1143.Invoke_O_O_O__O(arg_1144, arg_1145, arg_1146) } else { tmp9 = linked_1142.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1141, arg_1144, arg_1145, arg_1146) }; arg_1140 = /*line :294:1*/tmp8.Invoke_O__O(tmp9); if linked_1137 == nil { arg_1135 = ifn_1138.Invoke_O_O__O(arg_1139, arg_1140) } else { arg_1135 = linked_1137.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1136, arg_1139, arg_1140) }; if linked_1133 == nil { tmp7 = ifn_1134.Invoke_O__O(arg_1135) } else { tmp7 = linked_1133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1132, arg_1135) }; arg_1116 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1114 == nil { return ifn_1115.Invoke_O__O(arg_1116) } else { return linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) } }


func A_arbace_go_type_A_New() *A_arbace_go_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_go_type_A) Ctor() {}
//line :297:1
func (t *A_arbace_go_type_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1155 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_118); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1165 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any; var root_1169 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1173 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1170 == nil { arg_1168 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { arg_1168 = linked_1170.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }; if linked_1166 == nil { tmp4 = ifn_1167.Invoke_O__O(arg_1168) } else { tmp4 = linked_1166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1165, arg_1168) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1174 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var root_1178 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1182 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1183 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1185 lang.IFn; if
														linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var root_1189 any = A_arbace_go_A_const_115.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, A_arbace_go_pos_of_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = _AMPERSAND_form__0; if linked_1190 == nil { arg_1186 = ifn_1191.Invoke_O__O(arg_1192) } else { arg_1186 = linked_1190.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1189, arg_1192) }; var arg_1187 any = A_arbace_go_A_const_116; var arg_1188 any; var root_1193 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = A_arbace_go_A_const_112.Get__O(); if linked_1194 == nil { arg_1188 = ifn_1195.Invoke_O__O(arg_1196) } else { arg_1188 = linked_1194.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1193, arg_1196) }; if linked_1184 == nil { tmp9 = ifn_1185.Invoke_O_O_O__O(arg_1186, arg_1187, arg_1188) } else { tmp9 = linked_1184.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1183, arg_1186, arg_1187, arg_1188) }; arg_1182 = /*line :297:1*/tmp8.Invoke_O__O(tmp9); if linked_1179 == nil { arg_1177 = ifn_1180.Invoke_O_O__O(arg_1181, arg_1182) } else { arg_1177 = linked_1179.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1178, arg_1181, arg_1182) }; if linked_1175 == nil { tmp7 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp7 = linked_1175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1174, arg_1177) }; arg_1158 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1156 == nil { return ifn_1157.Invoke_O__O(arg_1158) } else { return linked_1156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1155, arg_1158) } }


func A_arbace_go_var_A_New() *A_arbace_go_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_var_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_var_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1197 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_119); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1207 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any; var root_1211 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1215 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1212 == nil { arg_1210 = ifn_1213.Invoke_O_O__O(arg_1214, arg_1215) } else { arg_1210 = linked_1212.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1211, arg_1214, arg_1215) }; if linked_1208 == nil { tmp4 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp4 = linked_1208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1207, arg_1210) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1216 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any; var root_1220 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1224 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1225 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1227 lang.IFn; if
														linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any; var root_1231 any = A_arbace_go_A_const_115.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, A_arbace_go_pos_of_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = _AMPERSAND_form__0; if linked_1232 == nil { arg_1228 = ifn_1233.Invoke_O__O(arg_1234) } else { arg_1228 = linked_1232.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1231, arg_1234) }; var arg_1229 any = A_arbace_go_A_const_116; var arg_1230 any; var root_1235 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = A_arbace_go_A_const_112.Get__O(); if linked_1236 == nil { arg_1230 = ifn_1237.Invoke_O__O(arg_1238) } else { arg_1230 = linked_1236.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1235, arg_1238) }; if linked_1226 == nil { tmp9 = ifn_1227.Invoke_O_O_O__O(arg_1228, arg_1229, arg_1230) } else { tmp9 = linked_1226.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230) }; arg_1224 = /*line :300:1*/tmp8.Invoke_O__O(tmp9); if linked_1221 == nil { arg_1219 = ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { arg_1219 = linked_1221.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) }; if linked_1217 == nil { tmp7 = ifn_1218.Invoke_O__O(arg_1219) } else { tmp7 = linked_1217.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1216, arg_1219) }; arg_1200 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1198 == nil { return ifn_1199.Invoke_O__O(arg_1200) } else { return linked_1198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1197, arg_1200) } }


func A_arbace_go_const_A_New() *A_arbace_go_const_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_const_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_const_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1239 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_120); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1249 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any; var root_1253 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1257 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1254 == nil { arg_1252 = ifn_1255.Invoke_O_O__O(arg_1256, arg_1257) } else { arg_1252 = linked_1254.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1253, arg_1256, arg_1257) }; if linked_1250 == nil { tmp4 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp4 = linked_1250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1249, arg_1252) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1258 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any; var root_1262 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1266 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1267 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1269 lang.IFn; if
														linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var root_1273 any = A_arbace_go_A_const_115.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_go_pos_of_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = _AMPERSAND_form__0; if linked_1274 == nil { arg_1270 = ifn_1275.Invoke_O__O(arg_1276) } else { arg_1270 = linked_1274.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1273, arg_1276) }; var arg_1271 any = A_arbace_go_A_const_116; var arg_1272 any; var root_1277 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = A_arbace_go_A_const_112.Get__O(); if linked_1278 == nil { arg_1272 = ifn_1279.Invoke_O__O(arg_1280) } else { arg_1272 = linked_1278.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1277, arg_1280) }; if linked_1268 == nil { tmp9 = ifn_1269.Invoke_O_O_O__O(arg_1270, arg_1271, arg_1272) } else { tmp9 = linked_1268.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1267, arg_1270, arg_1271, arg_1272) }; arg_1266 = /*line :303:1*/tmp8.Invoke_O__O(tmp9); if linked_1263 == nil { arg_1261 = ifn_1264.Invoke_O_O__O(arg_1265, arg_1266) } else { arg_1261 = linked_1263.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1262, arg_1265, arg_1266) }; if linked_1259 == nil { tmp7 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp7 = linked_1259.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1258, arg_1261) }; arg_1242 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1240 == nil { return ifn_1241.Invoke_O__O(arg_1242) } else { return linked_1240.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1239, arg_1242) } }


func A_arbace_go_directive_A_New() *A_arbace_go_directive_A { A_arbace_go_A_Init(); t := &A_arbace_go_directive_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_go_directive_A) Ctor() {}
//line :306:1
func (t *A_arbace_go_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_go_import_A_New() *A_arbace_go_import_A { A_arbace_go_A_Init(); t := &A_arbace_go_import_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_go_import_A) Ctor() {}
//line :308:1
func (t *A_arbace_go_import_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, specs__2 any) any { var root_1281 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1291 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any; var root_1295 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_121); var arg_1299 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_27); if linked_1296 == nil { arg_1294 = ifn_1297.Invoke_O_O__O(arg_1298, arg_1299) } else { arg_1294 = linked_1296.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1295, arg_1298, arg_1299) }; if linked_1292 == nil { tmp3 = ifn_1293.Invoke_O__O(arg_1294) } else { tmp3 = linked_1292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1291, arg_1294) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1300 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any; var root_1304 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1308 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1309 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1311 lang.IFn; if


	linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = A_arbace_go_A_const_112.Get__O(); if linked_1310 == nil { tmp8 = ifn_1311.Invoke_O__O(arg_1312) } else { tmp8 = linked_1310.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1309, arg_1312) }; arg_1308 = /*line :308:1*/tmp7.Invoke_O__O(tmp8); if linked_1305 == nil { arg_1303 = ifn_1306.Invoke_O_O__O(arg_1307, arg_1308) } else { arg_1303 = linked_1305.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1304, arg_1307, arg_1308) }; if linked_1301 == nil { tmp6 = ifn_1302.Invoke_O__O(arg_1303) } else { tmp6 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1313 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var root_1317 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1321 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any; var root_1322 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1324 lang.IFn; if


	linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = specs__2; if linked_1323 == nil { tmp13 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp13 = linked_1323.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1322, arg_1325) }; arg_1321 = /*line :308:1*/tmp12.Invoke_O__O(tmp13); if linked_1318 == nil { arg_1316 = ifn_1319.Invoke_O_O__O(arg_1320, arg_1321) } else { arg_1316 = linked_1318.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1317, arg_1320, arg_1321) }; if linked_1314 == nil { tmp11 = ifn_1315.Invoke_O__O(arg_1316) } else { tmp11 = linked_1314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1313, arg_1316) }; arg_1284 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1282 == nil { return ifn_1283.Invoke_O__O(arg_1284) } else { return linked_1282.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1281, arg_1284) } }




func A_arbace_go_inst_A_New() *A_arbace_go_inst_A { A_arbace_go_A_Init(); t := &A_arbace_go_inst_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_go_inst_A) Ctor() {}
//line :313:1
func (t *A_arbace_go_inst_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, f__2, types__3 any) any { var root_1326 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1337 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any; var root_1341 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_122); var arg_1345 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_28); if linked_1342 == nil { arg_1340 = ifn_1343.Invoke_O_O__O(arg_1344, arg_1345) } else { arg_1340 = linked_1342.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1341, arg_1344, arg_1345) }; if linked_1338 == nil { tmp3 = ifn_1339.Invoke_O__O(arg_1340) } else { tmp3 = linked_1338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1337, arg_1340) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1346 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any; var root_1350 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1354 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1355 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1357 lang.IFn; if







	linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = A_arbace_go_A_const_112.Get__O(); if linked_1356 == nil { tmp8 = ifn_1357.Invoke_O__O(arg_1358) } else { tmp8 = linked_1356.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1355, arg_1358) }; arg_1354 = /*line :313:1*/tmp7.Invoke_O__O(tmp8); if linked_1351 == nil { arg_1349 = ifn_1352.Invoke_O_O__O(arg_1353, arg_1354) } else { arg_1349 = linked_1351.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1350, arg_1353, arg_1354) }; if linked_1347 == nil { tmp6 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp6 = linked_1347.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1346, arg_1349) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1359 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var root_1363 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1367 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1364 == nil { arg_1362 = ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { arg_1362 = linked_1364.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) }; if linked_1360 == nil { tmp11 = ifn_1361.Invoke_O__O(arg_1362) } else { tmp11 = linked_1360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1359, arg_1362) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1368 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1372 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1376 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1377 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1379 lang.IFn; if







	linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = types__3; if linked_1378 == nil { tmp16 = ifn_1379.Invoke_O__O(arg_1380) } else { tmp16 = linked_1378.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1377, arg_1380) }; arg_1376 = /*line :313:1*/tmp15.Invoke_O__O(tmp16); if linked_1373 == nil { arg_1371 = ifn_1374.Invoke_O_O__O(arg_1375, arg_1376) } else { arg_1371 = linked_1373.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1372, arg_1375, arg_1376) }; if linked_1369 == nil { tmp14 = ifn_1370.Invoke_O__O(arg_1371) } else { tmp14 = linked_1369.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1368, arg_1371) }; arg_1329 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1327 == nil { return ifn_1328.Invoke_O__O(arg_1329) } else { return linked_1327.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1326, arg_1329) } }









func A_arbace_go_eval_A_New() *A_arbace_go_eval_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval_A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_go_eval_A) Ctor() {}
//line :323:1
func (t *A_arbace_go_eval_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, stmts__2 any) any { var root_1381 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_100.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1391 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any; var root_1395 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_123); var arg_1399 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_17); if linked_1396 == nil { arg_1394 = ifn_1397.Invoke_O_O__O(arg_1398, arg_1399) } else { arg_1394 = linked_1396.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1395, arg_1398, arg_1399) }; if linked_1392 == nil { tmp3 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp3 = linked_1392.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1391, arg_1394) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1400 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var root_1404 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1408 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1409 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1411 lang.IFn; if



	linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = stmts__2; if linked_1410 == nil { tmp8 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp8 = linked_1410.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1409, arg_1412) }; arg_1408 = /*line :323:1*/tmp7.Invoke_O__O(tmp8); if linked_1405 == nil { arg_1403 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { arg_1403 = linked_1405.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }; if linked_1401 == nil { tmp6 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp6 = linked_1401.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1400, arg_1403) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1413 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var root_1417 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_1421 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any = A_arbace_go_A_const_116; var tmp14 any; var root_1422 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1424 lang.IFn; if



	linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_go_A_const_112.Get__O(); if linked_1423 == nil { tmp14 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp14 = linked_1423.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1422, arg_1425) }; arg_1421 = /*line :323:1*/tmp12.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14))); if linked_1418 == nil { arg_1416 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { arg_1416 = linked_1418.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; if linked_1414 == nil { tmp11 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp11 = linked_1414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1413, arg_1416) }; arg_1384 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1382 == nil { return ifn_1383.Invoke_O__O(arg_1384) } else { return linked_1382.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1381, arg_1384) } }





func A_arbace_go_run_main_A_New() *A_arbace_go_run_main_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_main_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_run_main_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_run_main_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1426 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, A_arbace_go_repl_fn_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = Lit_52; if linked_1427 == nil { tmp1 = ifn_1428.Invoke_O__O(arg_1429) } else { tmp1 = linked_1427.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1426, arg_1429) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
func A_arbace_go_run_compiled_A_New() *A_arbace_go_run_compiled_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_compiled_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_go_run_compiled_A) Ctor() {}
//line :334:1
func (t *A_arbace_go_run_compiled_A) DoInvoke_O_O_O__O(self, ns_sym__0, args__1 any) any {



	var tmp1 any; var root_1430 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, A_arbace_go_repl_fn_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = Lit_51; if linked_1431 == nil { tmp1 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp1 = linked_1431.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1430, arg_1433) }; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var root_1434 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = args__1; if linked_1435 == nil { tmp3 = ifn_1436.Invoke_O__O(arg_1437) } else { tmp3 = linked_1435.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1434, arg_1437) }; return tmp2.Invoke_O_O__O(ns_sym__0, tmp3)
}
func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_go_check_A) Ctor() {}
//line :340:1
func (t *A_arbace_go_check_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1438 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, A_arbace_go_repl_fn_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = Lit_1; if linked_1439 == nil { tmp1 = ifn_1440.Invoke_O__O(arg_1441) } else { tmp1 = linked_1439.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1438, arg_1441) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}











































































type A_arbace_go_A struct{ jrt.Object }

var A_arbace_go_A_const_pool *jrt.RefArray

var A_arbace_go_A_const_0 *lang.Var

var A_arbace_go_A_const_1 any

var A_arbace_go_A_const_2 *lang.Keyword

var A_arbace_go_A_const_3 any

var A_arbace_go_A_const_4 *lang.Var

var A_arbace_go_A_const_5 *lang.Var

var A_arbace_go_A_const_6 *lang.Var

var A_arbace_go_A_const_7 *lang.Var

var A_arbace_go_A_const_8 any

var A_arbace_go_A_const_9 *lang.Var

var A_arbace_go_A_const_10 *lang.Var

var A_arbace_go_A_const_11 *lang.Var

var A_arbace_go_A_const_12 *lang.Var

var A_arbace_go_A_const_13 *lang.Var

var A_arbace_go_A_const_14 *jrt.Class

var A_arbace_go_A_const_15 *lang.Keyword

var A_arbace_go_A_const_16 *lang.Var

var A_arbace_go_A_const_17 *lang.Var

var A_arbace_go_A_const_18 any

var A_arbace_go_A_const_19 *lang.Keyword

var A_arbace_go_A_const_20 *lang.Keyword

var A_arbace_go_A_const_21 *lang.Var

var A_arbace_go_A_const_22 *lang.Var

var A_arbace_go_A_const_23 *lang.Var

var A_arbace_go_A_const_24 *lang.Var

var A_arbace_go_A_const_25 *lang.Var

var A_arbace_go_A_const_26 *lang.Var

var A_arbace_go_A_const_27 any

var A_arbace_go_A_const_28 *lang.Keyword

var A_arbace_go_A_const_29 *lang.Var

var A_arbace_go_A_const_30 *lang.Var

var A_arbace_go_A_const_31 *lang.Var

var A_arbace_go_A_const_32 *lang.Var

var A_arbace_go_A_const_33 *lang.Var

var A_arbace_go_A_const_34 *lang.Var

var A_arbace_go_A_const_35 any

var A_arbace_go_A_const_36 any

var A_arbace_go_A_const_37 *lang.Var

var A_arbace_go_A_const_38 *lang.Keyword

var A_arbace_go_A_const_39 *lang.Var

var A_arbace_go_A_const_40 any

var A_arbace_go_A_const_41 *lang.Var

var A_arbace_go_A_const_42 *lang.Keyword

var A_arbace_go_A_const_43 *lang.Var

var A_arbace_go_A_const_44 *lang.Var

var A_arbace_go_A_const_45 *lang.Var

var A_arbace_go_A_const_46 *lang.Var

var A_arbace_go_A_const_47 *lang.Var

var A_arbace_go_A_const_48 *lang.Var

var A_arbace_go_A_const_49 *lang.Var

var A_arbace_go_A_const_50 any

var A_arbace_go_A_const_51 *lang.Var

var A_arbace_go_A_const_52 *lang.Var

var A_arbace_go_A_const_53 *lang.Var

var A_arbace_go_A_const_54 *lang.Var

var A_arbace_go_A_const_55 *lang.Var

var A_arbace_go_A_const_56 *lang.Var

var A_arbace_go_A_const_57 *lang.Var

var A_arbace_go_A_const_58 *lang.Var

var A_arbace_go_A_const_59 any

var A_arbace_go_A_const_60 *lang.Keyword

var A_arbace_go_A_const_61 any

var A_arbace_go_A_const_62 *lang.Var

var A_arbace_go_A_const_63 *lang.Keyword

var A_arbace_go_A_const_64 *lang.Keyword

var A_arbace_go_A_const_65 *lang.Var

var A_arbace_go_A_const_66 *lang.Keyword

var A_arbace_go_A_const_67 *lang.Var

var A_arbace_go_A_const_68 *lang.Keyword

var A_arbace_go_A_const_69 *lang.Var

var A_arbace_go_A_const_70 *lang.Keyword

var A_arbace_go_A_const_71 *lang.Keyword

var A_arbace_go_A_const_72 *lang.Var

var A_arbace_go_A_const_73 *lang.Keyword

var A_arbace_go_A_const_74 *lang.Keyword

var A_arbace_go_A_const_75 *lang.Var

var A_arbace_go_A_const_76 *lang.Var

var A_arbace_go_A_const_77 *lang.Keyword

var A_arbace_go_A_const_78 *lang.Keyword

var A_arbace_go_A_const_79 *lang.Keyword

var A_arbace_go_A_const_80 *lang.Keyword

var A_arbace_go_A_const_81 *lang.Var

var A_arbace_go_A_const_82 *lang.Var

var A_arbace_go_A_const_83 *lang.Var

var A_arbace_go_A_const_84 *lang.Var

var A_arbace_go_A_const_85 *lang.Var

var A_arbace_go_A_const_86 *lang.Var

var A_arbace_go_A_const_87 *lang.Var

var A_arbace_go_A_const_88 *lang.Var

var A_arbace_go_A_const_89 *lang.Var

var A_arbace_go_A_const_90 *lang.Var

var A_arbace_go_A_const_91 *lang.Var

var A_arbace_go_A_const_92 *lang.Var

var A_arbace_go_A_const_93 *lang.Var

var A_arbace_go_A_const_94 any

var A_arbace_go_A_const_95 *lang.Var

var A_arbace_go_A_const_96 *lang.Var

var A_arbace_go_A_const_97 *lang.Var

var A_arbace_go_A_const_98 *lang.Var

var A_arbace_go_A_const_99 *lang.Var

var A_arbace_go_A_const_100 *lang.Var

var A_arbace_go_A_const_101 *lang.Var

var A_arbace_go_A_const_102 *lang.Var

var A_arbace_go_A_const_103 *lang.Var

var A_arbace_go_A_const_104 *lang.Var

var A_arbace_go_A_const_105 *lang.Var

var A_arbace_go_A_const_106 *lang.Var

var A_arbace_go_A_const_107 *lang.Var

var A_arbace_go_A_const_108 any

var A_arbace_go_A_const_109 any

var A_arbace_go_A_const_110 any

var A_arbace_go_A_const_111 *lang.Var

var A_arbace_go_A_const_112 *lang.Var

var A_arbace_go_A_const_113 any

var A_arbace_go_A_const_114 any

var A_arbace_go_A_const_115 *lang.Var

var A_arbace_go_A_const_116 *lang.Keyword

var A_arbace_go_A_const_117 any

var A_arbace_go_A_const_118 any

var A_arbace_go_A_const_119 any

var A_arbace_go_A_const_120 any

var A_arbace_go_A_const_121 any

var A_arbace_go_A_const_122 any

var A_arbace_go_A_const_123 any

var A_arbace_go_A_init jrt.ClassInit

func A_arbace_go_A_Init() { if !A_arbace_go_A_init.Done() { A_arbace_go_A_init.Run(A_arbace_go_A_clinit) } }

func A_arbace_go_A_clinit() { A_arbace_go_A_clinit_p0(); A_arbace_go_A_clinit_p1(); A_arbace_go_A_clinit_p2(); A_arbace_go_A_clinit_p3(); A_arbace_go_A_clinit_p4(); A_arbace_go_A_clinit_p5(); A_arbace_go_A_clinit_p6(); A_arbace_go_A_clinit_p7(); A_arbace_go_A_clinit_p8(); A_arbace_go_A_clinit_p9(); A_arbace_go_A_clinit_p10() }

func A_arbace_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 161); A_arbace_go_A_const_0 = lang.Var_Cast(A_arbace_go_A_const_pool.A[37]); A_arbace_go_A_const_1 = A_arbace_go_A_const_pool.A[38]; A_arbace_go_A_const_2 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[39]); A_arbace_go_A_const_3 = A_arbace_go_A_const_pool.A[40]; A_arbace_go_A_const_4 = lang.Var_Cast(A_arbace_go_A_const_pool.A[41]); A_arbace_go_A_const_5 = lang.Var_Cast(A_arbace_go_A_const_pool.A[42]); A_arbace_go_A_const_6 = lang.Var_Cast(A_arbace_go_A_const_pool.A[43]); A_arbace_go_A_const_7 = lang.Var_Cast(A_arbace_go_A_const_pool.A[44]); A_arbace_go_A_const_8 = A_arbace_go_A_const_pool.A[45]; A_arbace_go_A_const_9 = lang.Var_Cast(A_arbace_go_A_const_pool.A[46]); A_arbace_go_A_const_10 = lang.Var_Cast(A_arbace_go_A_const_pool.A[47]); A_arbace_go_A_const_11 = lang.Var_Cast(A_arbace_go_A_const_pool.A[48]) }

func A_arbace_go_A_clinit_p1() { A_arbace_go_A_const_12 = lang.Var_Cast(A_arbace_go_A_const_pool.A[49]); A_arbace_go_A_const_13 = lang.Var_Cast(A_arbace_go_A_const_pool.A[50]); A_arbace_go_A_const_14 = jrt.Class_Cast(A_arbace_go_A_const_pool.A[51]); A_arbace_go_A_const_15 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[52]); A_arbace_go_A_const_16 = lang.Var_Cast(A_arbace_go_A_const_pool.A[53]); A_arbace_go_A_const_17 = lang.Var_Cast(A_arbace_go_A_const_pool.A[54]); A_arbace_go_A_const_18 = A_arbace_go_A_const_pool.A[55]; A_arbace_go_A_const_19 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[56]); A_arbace_go_A_const_20 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[57]); A_arbace_go_A_const_21 = lang.Var_Cast(A_arbace_go_A_const_pool.A[58]); A_arbace_go_A_const_22 = lang.Var_Cast(A_arbace_go_A_const_pool.A[59]); A_arbace_go_A_const_23 = lang.Var_Cast(A_arbace_go_A_const_pool.A[60]) }

func A_arbace_go_A_clinit_p2() { A_arbace_go_A_const_24 = lang.Var_Cast(A_arbace_go_A_const_pool.A[61]); A_arbace_go_A_const_25 = lang.Var_Cast(A_arbace_go_A_const_pool.A[62]); A_arbace_go_A_const_26 = lang.Var_Cast(A_arbace_go_A_const_pool.A[63]); A_arbace_go_A_const_27 = A_arbace_go_A_const_pool.A[64]; A_arbace_go_A_const_28 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[65]); A_arbace_go_A_const_29 = lang.Var_Cast(A_arbace_go_A_const_pool.A[66]); A_arbace_go_A_const_30 = lang.Var_Cast(A_arbace_go_A_const_pool.A[67]); A_arbace_go_A_const_31 = lang.Var_Cast(A_arbace_go_A_const_pool.A[68]); A_arbace_go_A_const_32 = lang.Var_Cast(A_arbace_go_A_const_pool.A[69]); A_arbace_go_A_const_33 = lang.Var_Cast(A_arbace_go_A_const_pool.A[70]); A_arbace_go_A_const_34 = lang.Var_Cast(A_arbace_go_A_const_pool.A[71]); A_arbace_go_A_const_35 = A_arbace_go_A_const_pool.A[72] }

func A_arbace_go_A_clinit_p3() { A_arbace_go_A_const_36 = A_arbace_go_A_const_pool.A[73]; A_arbace_go_A_const_37 = lang.Var_Cast(A_arbace_go_A_const_pool.A[74]); A_arbace_go_A_const_38 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[75]); A_arbace_go_A_const_39 = lang.Var_Cast(A_arbace_go_A_const_pool.A[76]); A_arbace_go_A_const_40 = A_arbace_go_A_const_pool.A[77]; A_arbace_go_A_const_41 = lang.Var_Cast(A_arbace_go_A_const_pool.A[78]); A_arbace_go_A_const_42 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[79]); A_arbace_go_A_const_43 = lang.Var_Cast(A_arbace_go_A_const_pool.A[80]); A_arbace_go_A_const_44 = lang.Var_Cast(A_arbace_go_A_const_pool.A[81]); A_arbace_go_A_const_45 = lang.Var_Cast(A_arbace_go_A_const_pool.A[82]); A_arbace_go_A_const_46 = lang.Var_Cast(A_arbace_go_A_const_pool.A[83]); A_arbace_go_A_const_47 = lang.Var_Cast(A_arbace_go_A_const_pool.A[84]) }

func A_arbace_go_A_clinit_p4() { A_arbace_go_A_const_48 = lang.Var_Cast(A_arbace_go_A_const_pool.A[85]); A_arbace_go_A_const_49 = lang.Var_Cast(A_arbace_go_A_const_pool.A[86]); A_arbace_go_A_const_50 = A_arbace_go_A_const_pool.A[87]; A_arbace_go_A_const_51 = lang.Var_Cast(A_arbace_go_A_const_pool.A[88]); A_arbace_go_A_const_52 = lang.Var_Cast(A_arbace_go_A_const_pool.A[89]); A_arbace_go_A_const_53 = lang.Var_Cast(A_arbace_go_A_const_pool.A[90]); A_arbace_go_A_const_54 = lang.Var_Cast(A_arbace_go_A_const_pool.A[91]); A_arbace_go_A_const_55 = lang.Var_Cast(A_arbace_go_A_const_pool.A[92]); A_arbace_go_A_const_56 = lang.Var_Cast(A_arbace_go_A_const_pool.A[93]); A_arbace_go_A_const_57 = lang.Var_Cast(A_arbace_go_A_const_pool.A[94]); A_arbace_go_A_const_58 = lang.Var_Cast(A_arbace_go_A_const_pool.A[95]); A_arbace_go_A_const_59 = A_arbace_go_A_const_pool.A[96] }

func A_arbace_go_A_clinit_p5() { A_arbace_go_A_const_60 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[97]); A_arbace_go_A_const_61 = A_arbace_go_A_const_pool.A[98]; A_arbace_go_A_const_62 = lang.Var_Cast(A_arbace_go_A_const_pool.A[99]); A_arbace_go_A_const_63 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[100]); A_arbace_go_A_const_64 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[101]); A_arbace_go_A_const_65 = lang.Var_Cast(A_arbace_go_A_const_pool.A[102]); A_arbace_go_A_const_66 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[103]); A_arbace_go_A_const_67 = lang.Var_Cast(A_arbace_go_A_const_pool.A[104]); A_arbace_go_A_const_68 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[105]); A_arbace_go_A_const_69 = lang.Var_Cast(A_arbace_go_A_const_pool.A[106]); A_arbace_go_A_const_70 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[107]); A_arbace_go_A_const_71 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[108]) }

func A_arbace_go_A_clinit_p6() { A_arbace_go_A_const_72 = lang.Var_Cast(A_arbace_go_A_const_pool.A[109]); A_arbace_go_A_const_73 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[110]); A_arbace_go_A_const_74 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[111]); A_arbace_go_A_const_75 = lang.Var_Cast(A_arbace_go_A_const_pool.A[112]); A_arbace_go_A_const_76 = lang.Var_Cast(A_arbace_go_A_const_pool.A[113]); A_arbace_go_A_const_77 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[114]); A_arbace_go_A_const_78 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[115]); A_arbace_go_A_const_79 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[116]); A_arbace_go_A_const_80 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[117]); A_arbace_go_A_const_81 = lang.Var_Cast(A_arbace_go_A_const_pool.A[118]); A_arbace_go_A_const_82 = lang.Var_Cast(A_arbace_go_A_const_pool.A[119]); A_arbace_go_A_const_83 = lang.Var_Cast(A_arbace_go_A_const_pool.A[120]) }

func A_arbace_go_A_clinit_p7() { A_arbace_go_A_const_84 = lang.Var_Cast(A_arbace_go_A_const_pool.A[121]); A_arbace_go_A_const_85 = lang.Var_Cast(A_arbace_go_A_const_pool.A[122]); A_arbace_go_A_const_86 = lang.Var_Cast(A_arbace_go_A_const_pool.A[123]); A_arbace_go_A_const_87 = lang.Var_Cast(A_arbace_go_A_const_pool.A[124]); A_arbace_go_A_const_88 = lang.Var_Cast(A_arbace_go_A_const_pool.A[125]); A_arbace_go_A_const_89 = lang.Var_Cast(A_arbace_go_A_const_pool.A[126]); A_arbace_go_A_const_90 = lang.Var_Cast(A_arbace_go_A_const_pool.A[127]); A_arbace_go_A_const_91 = lang.Var_Cast(A_arbace_go_A_const_pool.A[128]); A_arbace_go_A_const_92 = lang.Var_Cast(A_arbace_go_A_const_pool.A[129]); A_arbace_go_A_const_93 = lang.Var_Cast(A_arbace_go_A_const_pool.A[130]); A_arbace_go_A_const_94 = A_arbace_go_A_const_pool.A[131]; A_arbace_go_A_const_95 = lang.Var_Cast(A_arbace_go_A_const_pool.A[132]) }

func A_arbace_go_A_clinit_p8() { A_arbace_go_A_const_96 = lang.Var_Cast(A_arbace_go_A_const_pool.A[133]); A_arbace_go_A_const_97 = lang.Var_Cast(A_arbace_go_A_const_pool.A[134]); A_arbace_go_A_const_98 = lang.Var_Cast(A_arbace_go_A_const_pool.A[135]); A_arbace_go_A_const_99 = lang.Var_Cast(A_arbace_go_A_const_pool.A[136]); A_arbace_go_A_const_100 = lang.Var_Cast(A_arbace_go_A_const_pool.A[137]); A_arbace_go_A_const_101 = lang.Var_Cast(A_arbace_go_A_const_pool.A[138]); A_arbace_go_A_const_102 = lang.Var_Cast(A_arbace_go_A_const_pool.A[139]); A_arbace_go_A_const_103 = lang.Var_Cast(A_arbace_go_A_const_pool.A[140]); A_arbace_go_A_const_104 = lang.Var_Cast(A_arbace_go_A_const_pool.A[141]); A_arbace_go_A_const_105 = lang.Var_Cast(A_arbace_go_A_const_pool.A[142]); A_arbace_go_A_const_106 = lang.Var_Cast(A_arbace_go_A_const_pool.A[143]); A_arbace_go_A_const_107 = lang.Var_Cast(A_arbace_go_A_const_pool.A[144]) }

func A_arbace_go_A_clinit_p9() { A_arbace_go_A_const_108 = A_arbace_go_A_const_pool.A[145]; A_arbace_go_A_const_109 = A_arbace_go_A_const_pool.A[146]; A_arbace_go_A_const_110 = A_arbace_go_A_const_pool.A[147]; A_arbace_go_A_const_111 = lang.Var_Cast(A_arbace_go_A_const_pool.A[148]); A_arbace_go_A_const_112 = lang.Var_Cast(A_arbace_go_A_const_pool.A[149]); A_arbace_go_A_const_113 = A_arbace_go_A_const_pool.A[150]; A_arbace_go_A_const_114 = A_arbace_go_A_const_pool.A[151]; A_arbace_go_A_const_115 = lang.Var_Cast(A_arbace_go_A_const_pool.A[152]); A_arbace_go_A_const_116 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[153]); A_arbace_go_A_const_117 = A_arbace_go_A_const_pool.A[154]; A_arbace_go_A_const_118 = A_arbace_go_A_const_pool.A[155]; A_arbace_go_A_const_119 = A_arbace_go_A_const_pool.A[156]; A_arbace_go_A_const_120 = A_arbace_go_A_const_pool.A[157]; A_arbace_go_A_const_121 = A_arbace_go_A_const_pool.A[158] }

func A_arbace_go_A_clinit_p10() { A_arbace_go_A_const_122 = A_arbace_go_A_const_pool.A[159]; A_arbace_go_A_const_123 = A_arbace_go_A_const_pool.A[160] }

func A_arbace_go_A_New() *A_arbace_go_A { A_arbace_go_A_Init(); t := &A_arbace_go_A{}; t.Ctor(); return t }

func (t *A_arbace_go_A) Ctor() {}

func (t *A_arbace_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_A) GetClass__Class() *jrt.Class { return A_arbace_go_A_class }

func (t *A_arbace_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_A); return ok }

func A_arbace_go_A_Cast(x any) *A_arbace_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_A_class)) }; return v }



type A_arbace_go_assign_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_assign_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_A struct{ j2g_header uint64 }

var A_arbace_go_check_A_fn_class *jrt.Class



type A_arbace_go_const_A struct{ j2g_header uint64 }

var A_arbace_go_const_A_fn_class *jrt.Class



type A_arbace_go_const_value_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_A_fn_class *jrt.Class



type A_arbace_go_const_value_fn__1822000029_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_fn__1822000029_A_fn_class *jrt.Class



type A_arbace_go_declare_STAR__A struct{ j2g_header uint64 }

var A_arbace_go_declare_STAR__A_fn_class *jrt.Class



type A_arbace_go_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_digest_info_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_A_fn_class *jrt.Class



type A_arbace_go_digest_info_fn__1822000032_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_fn__1822000032_A_fn_class *jrt.Class



type A_arbace_go_directive_A struct{ j2g_header uint64 }

var A_arbace_go_directive_A_fn_class *jrt.Class



type A_arbace_go_eval_A struct{ j2g_header uint64 }

var A_arbace_go_eval_A_fn_class *jrt.Class



type A_arbace_go_eval1822000004_A struct{ jrt.Object }

func A_arbace_go_eval1822000004_A_New() *A_arbace_go_eval1822000004_A { t := &A_arbace_go_eval1822000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000004_A) Ctor() {}

func (t *A_arbace_go_eval1822000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000004_A_class }

func (t *A_arbace_go_eval1822000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000004_A); return ok }

func A_arbace_go_eval1822000004_A_Cast(x any) *A_arbace_go_eval1822000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000004_A_class)) }; return v }



type A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class *jrt.Class



type A_arbace_go_eval1822000008_A struct{ jrt.Object }

func A_arbace_go_eval1822000008_A_New() *A_arbace_go_eval1822000008_A { t := &A_arbace_go_eval1822000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000008_A) Ctor() {}

func (t *A_arbace_go_eval1822000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000008_A_class }

func (t *A_arbace_go_eval1822000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000008_A); return ok }

func A_arbace_go_eval1822000008_A_Cast(x any) *A_arbace_go_eval1822000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000008_A_class)) }; return v }



type A_arbace_go_eval1822000008_fn__1822000009_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000008_fn__1822000009_A_fn_class *jrt.Class



type A_arbace_go_file_A struct{ j2g_header uint64 }

var A_arbace_go_file_A_fn_class *jrt.Class



type A_arbace_go_fn__1822000016_A struct{ j2g_header uint64 }

var A_arbace_go_fn__1822000016_A_fn_class *jrt.Class



type A_arbace_go_func_A struct{ j2g_header uint64 }

var A_arbace_go_func_A_fn_class *jrt.Class



type A_arbace_go_import_A struct{ j2g_header uint64 }

var A_arbace_go_import_A_fn_class *jrt.Class



type A_arbace_go_inst_A struct{ j2g_header uint64 }

var A_arbace_go_inst_A_fn_class *jrt.Class



type A_arbace_go_interpretable_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_interpretable_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_member_var_A struct{ j2g_header uint64 }

var A_arbace_go_member_var_A_fn_class *jrt.Class



type A_arbace_go_method_A struct{ j2g_header uint64 }

var A_arbace_go_method_A_fn_class *jrt.Class



type A_arbace_go_new_A struct{ j2g_header uint64 }

var A_arbace_go_new_A_fn_class *jrt.Class



type A_arbace_go_package_A struct{ j2g_header uint64 }

var A_arbace_go_package_A_fn_class *jrt.Class



type A_arbace_go_packages_A struct{ j2g_header uint64 }

var A_arbace_go_packages_A_fn_class *jrt.Class



type A_arbace_go_params_of_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_A_fn_class *jrt.Class



type A_arbace_go_params_of_fn__1822000024_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_fn__1822000024_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_fn__1822000013_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class *jrt.Class



type A_arbace_go_pos_of_A struct{ j2g_header uint64 }

var A_arbace_go_pos_of_A_fn_class *jrt.Class



type A_arbace_go_reify_data_A struct{ j2g_header uint64 }

var A_arbace_go_reify_data_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000118__1822000122_A struct{ j2g_header uint64; F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000118__1822000122_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A struct{ j2g_header uint64; F_s__1822000119, F_iter__1822000118, F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A struct{ j2g_header uint64; F_b__1822000121, F_fns any; F_size__1927001038__auto__ int32; F_ts, F_c__1927001037__auto__ any }

var A_arbace_go_reify_data_iter__1822000118__1822000122_fn__1822000123_fn__1822000124_A_fn_class *jrt.Class



type A_arbace_go_reify_type_A struct{ j2g_header uint64 }

var A_arbace_go_reify_type_A_fn_class *jrt.Class



type A_arbace_go_repl_fn_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn_A_fn_class *jrt.Class



type A_arbace_go_run_compiled_A struct{ j2g_header uint64 }

var A_arbace_go_run_compiled_A_fn_class *jrt.Class



type A_arbace_go_run_main_A struct{ j2g_header uint64 }

var A_arbace_go_run_main_A_fn_class *jrt.Class



type A_arbace_go_spread_A struct{ j2g_header uint64 }

var A_arbace_go_spread_A_fn_class *jrt.Class



type A_arbace_go_str_A struct{ j2g_header uint64 }

var A_arbace_go_str_A_fn_class *jrt.Class



type A_arbace_go_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_go_strip_doc_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000066_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_table_ns_BANG__fn__1822000066_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000068_A struct{ j2g_header uint64; F_info, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000068_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A struct{ j2g_header uint64; F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A struct{ j2g_header uint64; F_iter__1822000069, F_s__1822000070, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A struct{ j2g_header uint64; F_members any; F_size__1927001038__auto__ int32; F_b__1822000072, F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__fn__1822000068_iter__1822000069__1822000073_fn__1822000074_fn__1822000075_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A struct{ j2g_header uint64; F_s__1822000051, F_iter__1822000050 any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A struct{ j2g_header uint64; F_b__1822000053 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__make__1822000086_A struct{ j2g_header uint64; F_ns, F_info, F_consts, F_p, F_members any }

var A_arbace_go_table_ns_BANG__make__1822000086_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__resolver__1822000091_A struct{ j2g_header uint64; F_make, F_consts, F_members any }

var A_arbace_go_table_ns_BANG__resolver__1822000091_A_fn_class *jrt.Class



type A_arbace_go_type_A struct{ j2g_header uint64 }

var A_arbace_go_type_A_fn_class *jrt.Class



type A_arbace_go_type_names_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_A_fn_class *jrt.Class



type A_arbace_go_type_names_fn__1822000107_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_fn__1822000107_A_fn_class *jrt.Class



type A_arbace_go_type_of_A struct{ j2g_header uint64 }

var A_arbace_go_type_of_A_fn_class *jrt.Class



type A_arbace_go_var_A struct{ j2g_header uint64 }

var A_arbace_go_var_A_fn_class *jrt.Class



type A_arbace_go_zero_A struct{ j2g_header uint64 }

var A_arbace_go_zero_A_fn_class *jrt.Class
