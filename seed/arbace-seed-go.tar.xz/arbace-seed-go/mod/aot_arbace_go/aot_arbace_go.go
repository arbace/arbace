//line aot_arbace_go.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New() *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_A_const_1, A_arbace_go_A_const_2, A_arbace_go_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_eval1822000008_fn__1822000009_A_New() *A_arbace_go_eval1822000008_fn__1822000009_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000008_fn__1822000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_go_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_A_const_7.GetRawRoot__O(), A_arbace_go_A_const_8) }
















































func A_arbace_go_path__GT_ns_A_New() *A_arbace_go_path__GT_ns_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {



	var root_17 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_35, nil); var tmp2 any; var root_21 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_25 any; var root_26 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = Lit_12; var arg_30 any; var root_31 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var fnbody__37 any = A_arbace_go_path__GT_ns_fn__1822000013_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__37, tmp3, nil); var tmp4 *jrt.Class = A_arbace_go_A_const_14; var arg_35 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__0, tmp4, Lit_37, jrt.RefArrayOf(jrt.Object_class, Lit_38)); if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_17, arg_20) } }
//line :54:1
func A_arbace_go_path__GT_ns_fn__1822000013_A_New() *A_arbace_go_path__GT_ns_fn__1822000013_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_fn__1822000013_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Ctor() {}
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Invoke_O_O__O(self, p1__1822000012_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_go_A_const_14; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1822000012_SHARP___1, tmp1, Lit_39, jrt.RefArrayOf(jrt.Object_class, Lit_40, Lit_41)) }


func A_arbace_go_fn__1822000016_A_New() *A_arbace_go_fn__1822000016_A { A_arbace_go_A_Init(); t := &A_arbace_go_fn__1822000016_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_26); var tmp1 any = A_arbace_go_A_const_15; var tmp2 any; var root_38 any = A_arbace_go_A_const_16.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_40 lang.IFn

		if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = s__2; var arg_46 any = A_arbace_go_A_const_18; var arg_47 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_43 == nil { arg_41 = ifn_44.Invoke_O_O_O__O(arg_45, arg_46, arg_47) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_42, arg_45, arg_46, arg_47) }; if linked_39 == nil { tmp2 = ifn_40.Invoke_O__O(arg_41) } else { tmp2 = linked_39.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_38, arg_41) }
//line :58:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_A_const_19; var tmp5 any = A_arbace_go_A_const_20; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_digest_forms_A_New() *A_arbace_go_digest_forms_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_forms_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_digest_forms_A) Ctor() {}
//line :62:1
func (t *A_arbace_go_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_48 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_50 lang.IFn; if



	linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_go_A_const_21.GetRawRoot__O(); if linked_49 == nil { temp__1927000414__auto____2 = ifn_50.Invoke_O__O(arg_51) } else { temp__1927000414__auto____2 = linked_49.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_48, arg_51) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__1822000018__3 any = temp__1927000414__auto____2; var map__1822000018__4 any; if lang.ISeq_InstanceOf(map__1822000018__3) { var tmp1 any; var root_52 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = map__1822000018__3; if linked_53 == nil { tmp1 = ifn_54.Invoke_O__O(arg_55) } else { tmp1 = linked_53.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_52, arg_55) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_56 any = A_arbace_go_A_const_23.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = map__1822000018__3; if linked_57 == nil { tmp2 = ifn_58.Invoke_O__O(arg_59) } else { tmp2 = linked_57.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_56, arg_59) }; map__1822000018__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_60 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = map__1822000018__3; if linked_61 == nil { tmp3 = ifn_62.Invoke_O__O(arg_63) } else { tmp3 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; if jrt.J2g_Truth(tmp3) { var root_64 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = map__1822000018__3; if linked_65 == nil { map__1822000018__4 = ifn_66.Invoke_O__O(arg_67) } else { map__1822000018__4 = linked_65.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_64, arg_67) } } else { map__1822000018__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1822000018__4 = map__1822000018__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_15); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_19); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_20); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__1822000020__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(1), nil); var r__12 any; var tmp4 any; var root_68 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_70 lang.IFn
			if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = text__6; var arg_72 any; var na_74 any = start__7; var na_75 any = a__10; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_74); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_75) }; tmp5 = tmp6; if tmp5 { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var n1_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var nr_78 int64 = n0_76 + n1_77; if (n0_76^nr_78)&(n1_77^nr_78) >= 0 { arg_72 = jrt.Long_ValueOf_J__Long_NoInit(nr_78).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_74, na_75) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_74); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_75) }; tmp7 = tmp8; if tmp7 { var n0_76_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); var n1_77_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); arg_72 = jrt.Double_ValueOf_D__Double_NoInit(n0_76_2 + n1_77_2).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_74, na_75) } }; var arg_73 any; var na_79 any = start__7; var na_80 any = b__11; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_79); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_80) }; tmp9 = tmp10; if tmp9 { var n0_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var n1_82 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); var nr_83 int64 = n0_81 + n1_82; if (n0_81^nr_83)&(n1_82^nr_83) >= 0 { arg_73 = jrt.Long_ValueOf_J__Long_NoInit(nr_83).Ref() } else { arg_73 = lang.Numbers_Add_O_O__Number_NoInit(na_79, na_80) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_79); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_80) }; tmp11 = tmp12; if tmp11 { var n0_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); var n1_82_2 float64 = jrt.NN(jrt.Double_Cast(na_80)).DoubleValue__D(); arg_73 = jrt.Double_ValueOf_D__Double_NoInit(n0_81_2 + n1_82_2).Ref() } else { arg_73 = lang.Numbers_Add_O_O__Number_NoInit(na_79, na_80) } }; if linked_69 == nil { tmp4 = ifn_70.Invoke_O_O_O__O(arg_71, arg_72, arg_73) } else { tmp4 = linked_69.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_68, arg_71, arg_72, arg_73) }
//line :67:1
			r__12 = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(tmp4)))

			var root_92 any = A_arbace_go_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = lang.IFn_Cast(A_arbace_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_A_const_32, jrt.Boolean_FALSE.Ref()); if linked_93 == nil { ifn_94.Invoke_O__O(arg_95) } else { linked_93.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_92, arg_95) }
//line :67:1
			var tmp13 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__15 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__16 any; var root_84 any = A_arbace_go_A_const_26.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_86 lang.IFn



				if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = A_arbace_go_A_const_27; var arg_88 any = r__12; if linked_85 == nil { f__16 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { f__16 = linked_85.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }
				if lang.Util_Equiv_O_O__Z_NoInit(f__16, A_arbace_go_A_const_28) { tmp13 = acc__15 } else { var tmp14 any; var root_101 any = A_arbace_go_A_const_7.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = acc__15; var arg_105 any = f__16; if linked_102 == nil { tmp14 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { tmp14 = linked_102.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; acc__15 = tmp14; continue L1 }
//line :67:1
				break L1 } }; return nil }(); var root_89 any = A_arbace_go_A_const_29.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_91 lang.IFn

			if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { ifn_91.Invoke__O() } else { linked_90.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_89) }
//line :67:1
			if tmp15 != nil { panic(tmp15) }; return tmp13 } else { return nil } } else {
//line :66:1
				return nil } }







func A_arbace_go_params_of_A_New() *A_arbace_go_params_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_params_of_A) Ctor() {}
//line :74:1
func (t *A_arbace_go_params_of_A) Invoke_O_O__O(self, pv__0 any) any {


	var root_106 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_110 any = A_arbace_go_A_const_34.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var fnbody__161 any = A_arbace_go_params_of_fn__1822000024_A_New(); var tmp1 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_params_of_fn__1822000024_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_params_of_fn__1822000024_A_fn_class = fncls__160d; tmp1 = fncls__160d } else { tmp1 = fncls__160 }; arg_113 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__161, tmp1, nil); var arg_114 any = pv__0; if linked_111 == nil { arg_109 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { arg_109 = linked_111.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) }; if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_106, arg_109) } }
//line :77:1
func A_arbace_go_params_of_fn__1822000024_A_New() *A_arbace_go_params_of_fn__1822000024_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_fn__1822000024_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Ctor() {}
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, x__2) } else {
												if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_115 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_117 lang.IFn

		if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = x__2; if linked_116 == nil { and__1927000168__auto____3 = ifn_117.Invoke_O__O(arg_118) } else { and__1927000168__auto____3 = linked_116.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_119 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = A_arbace_go_A_const_40; var arg_123 any = x__2; if linked_120 == nil { tmp1 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp1 = linked_120.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_124 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_128 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = x__2; if linked_129 == nil { arg_127 = ifn_130.Invoke_O__O(arg_131) } else { arg_127 = linked_129.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_128, arg_131) }; if linked_125 == nil { return ifn_126.Invoke_O__O(arg_127) } else { return linked_125.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_124, arg_127) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_132 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var na_136 any = i__1; if jrt.Long_InstanceOf(na_136) { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); if n0_137 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_136) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_137 + 1)) } } else { if jrt.Double_InstanceOf(na_136) { var n0_137_2 float64 = jrt.NN(jrt.Double_Cast(na_136)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_137_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_136) } }; arg_135 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_133 == nil { return ifn_134.Invoke_O__O(arg_135) } else { return linked_133.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_132, arg_135) } } else {
//line :78:1
						return nil } } } } }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, x__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_138 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_140 lang.IFn

		if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = x__2; if linked_139 == nil { and__1927000168__auto____3 = ifn_140.Invoke_O__O(arg_141) } else { and__1927000168__auto____3 = linked_139.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_142 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_go_A_const_40; var arg_146 any = x__2; if linked_143 == nil { tmp1 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { tmp1 = linked_143.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_147 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_151 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = x__2; if linked_152 == nil { arg_150 = ifn_153.Invoke_O__O(arg_154) } else { arg_150 = linked_152.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_151, arg_154) }; if linked_148 == nil { return ifn_149.Invoke_O__O(arg_150) } else { return linked_148.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_147, arg_150) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_155 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp4 jrt.Number_I; var n0_159 int64 = i__1_l; if n0_159 == 9223372036854775807 { var tmp5 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp5 = i__1_b } else { tmp5 = i__1_b }; tmp4 = lang.Numbers_Inc_O__Number_NoInit(tmp5) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_159 + 1)) }; arg_158 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_156 == nil { return ifn_157.Invoke_O__O(arg_158) } else { return linked_156.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_155, arg_158) } } else {
//line :78:1
						return nil
					}
			}
	}
}

func A_arbace_go_strip_doc_A_New() *A_arbace_go_strip_doc_A { A_arbace_go_A_Init(); t := &A_arbace_go_strip_doc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_go_strip_doc_A) Ctor() {}
//line :84:1
func (t *A_arbace_go_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_162 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_166 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = xs__0; if linked_167 == nil { arg_165 = ifn_168.Invoke_O__O(arg_169) } else { arg_165 = linked_167.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_166, arg_169) }; if linked_163 == nil { tmp1 = ifn_164.Invoke_O__O(arg_165) } else { tmp1 = linked_163.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_170 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = xs__0; if linked_171 == nil { tmp2 = ifn_172.Invoke_O__O(arg_173) } else { tmp2 = linked_171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_170, arg_173) }; var tmp3 any = tmp2; var tmp4 any; var root_174 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = xs__0; if linked_175 == nil { tmp4 = ifn_176.Invoke_O__O(arg_177) } else { tmp4 = linked_175.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_174, arg_177) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) } }

func A_arbace_go_const_value_A_New() *A_arbace_go_const_value_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_const_value_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_const_value_A) Invoke_O_O_O__O(self, v__0, underlying__1 any) any {




	var tmp1 any; var root_178 any = A_arbace_go_A_const_45.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_180 lang.IFn
	if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = v__0; if linked_179 == nil { tmp1 = ifn_180.Invoke_O__O(arg_181) } else { tmp1 = linked_179.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_178, arg_181) }
//line :91:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var root_182 any = A_arbace_go_A_const_46.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_184 lang.IFn

		if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = v__0; if linked_183 == nil { tmp2 = ifn_184.Invoke_O__O(arg_185) } else { tmp2 = linked_183.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_182, arg_185) }
//line :91:1
		if jrt.J2g_Truth(tmp2) {

			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__0))).Ref() } else {
//line :91:1
				var tmp3 any; var or__1927000174__auto____3 any; var root_186 any = A_arbace_go_A_const_47.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_float_QMARK__A_fn_class); var ifn_188 lang.IFn


				if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = v__0; if linked_187 == nil { or__1927000174__auto____3 = ifn_188.Invoke_O__O(arg_189) } else { or__1927000174__auto____3 = linked_187.(*aot_arbace_core.A_arbace_core_float_QMARK__A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_190 any = A_arbace_go_A_const_48.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = v__0; if linked_191 == nil { or__1927000174__auto____4 = ifn_192.Invoke_O__O(arg_193) } else { or__1927000174__auto____4 = linked_191.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { var root_194 any = A_arbace_go_A_const_49.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_decimal_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = v__0; if linked_195 == nil { tmp3 = ifn_196.Invoke_O__O(arg_197) } else { tmp3 = linked_195.(*aot_arbace_core.A_arbace_core_decimal_QMARK__A).Invoke_O_O__O(root_194, arg_197) } } }
//line :91:1
				if jrt.J2g_Truth(tmp3) {


					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_50, underlying__1) { return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__0)).Ref() } else { return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__0)).Ref() } } else {
//line :91:1
						var tmp4 any; var root_198 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_200 lang.IFn



						if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = v__0; if linked_199 == nil { tmp4 = ifn_200.Invoke_O__O(arg_201) } else { tmp4 = linked_199.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_198, arg_201) }
//line :91:1
						if jrt.J2g_Truth(tmp4) { var G__1822000028__3_ any; var root_202 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_204 lang.IFn



							if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var root_206 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = v__0; if linked_207 == nil { arg_205 = ifn_208.Invoke_O__O(arg_209) } else { arg_205 = linked_207.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_206, arg_209) }; if linked_203 == nil { G__1822000028__3_ = ifn_204.Invoke_O__O(arg_205) } else { G__1822000028__3_ = linked_203.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_202, arg_205) }; switch lang.Util_Hash_O__I_NoInit(G__1822000028__3_) >> 7 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_2) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_52.GetRawRoot__O()); var tmp6 *lang.Compiler_AOTFn; var fnbody__225 any = A_arbace_go_const_value_fn__1822000029_A_New(); var tmp7 *jrt.Class
								var fncls__224 /*line :95:1*/*jrt.Class = A_arbace_go_const_value_fn__1822000029_A_fn_class

								if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_go_const_value_fn__1822000029_A_fn_class = fncls__224d; tmp7 = fncls__224d } else { tmp7 = fncls__224 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__225, tmp7, nil)
//line :95:1
								var tmp8 any = tmp6.Ref(); var tmp9 any; var root_226 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_228 lang.IFn

								if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = v__0; if linked_227 == nil { tmp9 = ifn_228.Invoke_O__O(arg_229) } else { tmp9 = linked_227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_226, arg_229) }
//line :95:1
								return jrt.String_New_B1_String(lang.Numbers_Byte_array_O__B1_NoInit(tmp5.Invoke_O_O__O(tmp8, tmp9)), Lit_4) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_5) {



									var tmp10 any; var root_230 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = v__0; if linked_231 == nil { tmp10 = ifn_232.Invoke_O__O(arg_233) } else { tmp10 = linked_231.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_230, arg_233) }; return lang.GoInterp_Complex_D_D__O(lang.RT_DoubleCast_O__D_NoInit(tmp10), lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) }
//line :95:1
							case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_6) {
								var tmp11 any; var root_234 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = v__0; if linked_235 == nil { tmp11 = ifn_236.Invoke_O__O(arg_237) } else { tmp11 = linked_235.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_234, arg_237) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp11)).Ref() }
//line :95:1
							case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_7) {




								var tmp12 any; var root_238 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = v__0; if linked_239 == nil { tmp12 = ifn_240.Invoke_O__O(arg_241) } else { tmp12 = linked_239.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_238, arg_241) }; return jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Multiply_D_D__D_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp12), jrt.Math_Pow_D_D__D(2.0, lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))))).Ref() }
//line :95:1
							default:}; return v__0 } else {
//line :91:1
								if A_arbace_go_A_const_42 != nil { return v__0 } else { return nil
								}
							}
					}
			}
	} }
func A_arbace_go_const_value_fn__1822000029_A_New() *A_arbace_go_const_value_fn__1822000029_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_fn__1822000029_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Ctor() {}
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_216 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = x__1; if linked_217 == nil { tmp1 = ifn_218.Invoke_O__O(arg_219) } else { tmp1 = linked_217.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp1) { var root_220 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = jrt.NN(jrt.String_Cast(x__1)).GetBytes_String__B1(Lit_4).Ref(); if linked_221 == nil { return ifn_222.Invoke_O__O(arg_223) } else { return linked_221.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_220, arg_223) } } else { return lang.Tuple_Create_O__IPersistentVector(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_UncheckedByteCast_O__B_NoInit(x__1)).Ref()) } }






func A_arbace_go_digest_info_A_New() *A_arbace_go_digest_info_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_digest_info_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_digest_info_A) Invoke_O_O__O(self, p__0 any) any {


	var root_242 any = A_arbace_go_A_const_54.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any; var fnbody__457 any = A_arbace_go_digest_info_fn__1822000032_A_New(); var tmp1 *jrt.Class; var fncls__456 *jrt.Class = A_arbace_go_digest_info_fn__1822000032_A_fn_class
	if fncls__456 == nil { var fncls__456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_go_digest_info_fn__1822000032_A_fn_class = fncls__456d; tmp1 = fncls__456d } else { tmp1 = fncls__456 }; arg_245 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__457, tmp1, nil)
//line :107:1
	var arg_246 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_247 any; var root_458 any = A_arbace_go_A_const_72.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_go_digest_forms_A_fn_class); var ifn_460 lang.IFn




























	if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = p__0; if linked_459 == nil { arg_247 = ifn_460.Invoke_O__O(arg_461) } else { arg_247 = linked_459.(*A_arbace_go_digest_forms_A).Invoke_O_O__O(root_458, arg_461) }
//line :107:1
	if linked_243 == nil { return ifn_244.Invoke_O_O_O__O(arg_245, arg_246, arg_247) } else { return linked_243.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_242, arg_245, arg_246, arg_247) } }
func A_arbace_go_digest_info_fn__1822000032_A_New() *A_arbace_go_digest_info_fn__1822000032_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_fn__1822000032_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Ctor() {}
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any; var root_248 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var and__1927000168__auto____3 any; var root_252 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = f__2; if linked_253 == nil { and__1927000168__auto____3 = ifn_254.Invoke_O__O(arg_255) } else { and__1927000168__auto____3 = linked_253.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_252, arg_255) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_256 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var root_260 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = f__2; if linked_261 == nil { arg_259 = ifn_262.Invoke_O__O(arg_263) } else { arg_259 = linked_261.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_260, arg_263) }; if linked_257 == nil { and__1927000168__auto____4 = ifn_258.Invoke_O__O(arg_259) } else { and__1927000168__auto____4 = linked_257.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_256, arg_259) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_264 any = A_arbace_go_A_const_56.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = f__2; if linked_269 == nil { arg_267 = ifn_270.Invoke_O__O(arg_271) } else { arg_267 = linked_269.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_268, arg_271) }; if linked_265 == nil { tmp2 = ifn_266.Invoke_O__O(arg_267) } else { tmp2 = linked_265.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_264, arg_267) }; arg_251 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_10, tmp2)).Ref() } else { arg_251 = and__1927000168__auto____4 } } else { arg_251 = and__1927000168__auto____3 }; if linked_249 == nil { tmp1 = ifn_250.Invoke_O__O(arg_251) } else { tmp1 = linked_249.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_248, arg_251) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var G__1822000033__3_ any; var root_272 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_274 lang.IFn

		if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any; var root_276 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = f__2; if linked_277 == nil { arg_275 = ifn_278.Invoke_O__O(arg_279) } else { arg_275 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) }; if linked_273 == nil { G__1822000033__3_ = ifn_274.Invoke_O__O(arg_275) } else { G__1822000033__3_ = linked_273.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_272, arg_275) }; switch lang.Util_Hash_O__I_NoInit(G__1822000033__3_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_11) { var vec__1822000034__4 any; var root_281 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, A_arbace_go_strip_doc_A_fn_class); var ifn_283 lang.IFn





			if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_285 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_285, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_289 any = f__2; if linked_286 == nil { arg_284 = ifn_287.Invoke_O_O__O(A_arbace_go_A_const_59, arg_289) } else { arg_284 = linked_286.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_285, 2, A_arbace_go_A_const_59, arg_289) }; if linked_282 == nil { vec__1822000034__4 = ifn_283.Invoke_O__O(arg_284) } else { vec__1822000034__4 = linked_282.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_281, arg_284) }
//line :111:1
			var doc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7 bool; var tmp3 any = A_arbace_go_A_const_60; var tmp4 any; var root_290 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_292 lang.IFn






			if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = xs__6; if linked_291 == nil { tmp4 = ifn_292.Invoke_O__O(arg_293) } else { tmp4 = linked_291.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_290, arg_293) }; gen__7 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)
//line :111:1
			var xs__8 any







			if gen__7 { var root_294 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_294, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_298 any = xs__6; if linked_295 == nil { xs__8 = ifn_296.Invoke_O_O__O(A_arbace_go_A_const_59, arg_298) } else { xs__8 = linked_295.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_294, 2, A_arbace_go_A_const_59, arg_298) } } else { xs__8 = xs__6 }
//line :111:1
			var pv__9 any; var root_299 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_301 lang.IFn








			if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = xs__8; if linked_300 == nil { pv__9 = ifn_301.Invoke_O__O(arg_302) } else { pv__9 = linked_300.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_299, arg_302) }
//line :111:1
			var r__10 any; var root_303 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_305 lang.IFn









			if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = pv__9; if linked_304 == nil { r__10 = ifn_305.Invoke_O__O(arg_306) } else { r__10 = linked_304.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_303, arg_306) }
//line :111:1
			var rt__11 any; var tmp5 any; var and__1927000168__auto____11 any; var root_307 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_309 lang.IFn










			if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = r__10; if linked_308 == nil { and__1927000168__auto____11 = ifn_309.Invoke_O__O(arg_310) } else { and__1927000168__auto____11 = linked_308.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_307, arg_310) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp6 *lang.Keyword = A_arbace_go_A_const_38; tmp5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) { var tmp7 *lang.Keyword = A_arbace_go_A_const_38; rt__11 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__10)) } else { rt__11 = r__10 }
//line :111:1
			var rt__12 any; var tmp8 any; var and__1927000168__auto____12 any; var root_311 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_313 lang.IFn











			if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = rt__11; if linked_312 == nil { and__1927000168__auto____12 = ifn_313.Invoke_O__O(arg_314) } else { and__1927000168__auto____12 = linked_312.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp9 any = A_arbace_go_A_const_61; var tmp10 any; var root_315 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = rt__11; if linked_316 == nil { tmp10 = ifn_317.Invoke_O__O(arg_318) } else { tmp10 = linked_316.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_315, arg_318) }; tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10)).Ref() } else { tmp8 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp8) { var root_319 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = rt__11; if linked_320 == nil { rt__12 = ifn_321.Invoke_O__O(arg_322) } else { rt__12 = linked_320.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_319, arg_322) } } else { rt__12 = rt__11 }
//line :111:1
			var vec__1822000037__13 any; var tmp11 any; var root_323 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_325 lang.IFn













			if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = rt__12; if linked_324 == nil { tmp11 = ifn_325.Invoke_O__O(arg_326) } else { tmp11 = linked_324.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_323, arg_326) }; if jrt.J2g_Truth(tmp11) { var tmp12 any; var root_434 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = rt__12; if linked_435 == nil { tmp12 = ifn_436.Invoke_O__O(arg_437) } else { tmp12 = linked_435.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_434, arg_437) }; vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, jrt.Boolean_TRUE.Ref()) } else { vec__1822000037__13 = lang.Tuple_Create_O_O__IPersistentVector(rt__12, jrt.Boolean_ValueOf_Z__Boolean_NoInit(gen__7).Ref()) }
//line :111:1
			var rt__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(0), nil); var gen__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp13 any; var root_327 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_329 lang.IFn














			if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = rt__14; if linked_328 == nil { tmp13 = ifn_329.Invoke_O__O(arg_330) } else { tmp13 = linked_328.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_327, arg_330) }; if jrt.J2g_Truth(tmp13) {
				var root_331 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = acc__1; var arg_335 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil); var tmp15 any; var root_337 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = f__2; if linked_338 == nil { tmp15 = ifn_339.Invoke_O__O(arg_340) } else { tmp15 = linked_338.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_337, arg_340) }; arg_335 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, rt__14, nil, tmp15)).Ref(); var arg_336 any; var G__1822000040__16_ any; var tmp16 any = A_arbace_go_A_const_63; var tmp17 any = A_arbace_go_A_const_64; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp19 any; var root_347 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_go_params_of_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = pv__9; if linked_348 == nil { tmp19 = ifn_349.Invoke_O__O(arg_350) } else { tmp19 = linked_348.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_347, arg_350) }; G__1822000040__16_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, doc__5, tmp17, tmp18.Invoke_O__O(tmp19))); if jrt.J2g_Truth(gen__15) {
					var root_341 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = G__1822000040__16_; var arg_345 any = A_arbace_go_A_const_66; var arg_346 any = jrt.Boolean_TRUE.Ref(); if linked_342 == nil { arg_336 = ifn_343.Invoke_O_O_O__O(arg_344, arg_345, arg_346) } else { arg_336 = linked_342.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_341, arg_344, arg_345, arg_346) } } else {
//line :127:1
						arg_336 = G__1822000040__16_ }; if linked_332 == nil { return ifn_333.Invoke_O_O_O__O(arg_334, arg_335, arg_336) } else { return linked_332.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_331, arg_334, arg_335, arg_336) } } else {
//line :126:1
							return acc__1 } }
//line :111:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_13) {




















			var root_351 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = acc__1; var arg_355 any; var root_357 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any; var root_361 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = f__2; if linked_362 == nil { arg_360 = ifn_363.Invoke_O__O(arg_364) } else { arg_360 = linked_362.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_361, arg_364) }; if linked_358 == nil { arg_355 = ifn_359.Invoke_O__O(arg_360) } else { arg_355 = linked_358.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_357, arg_360) }; var arg_356 any; var tmp20 any = A_arbace_go_A_const_63; var tmp21 any; var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp22 any; var root_365 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = d__4; if linked_366 == nil { tmp22 = ifn_367.Invoke_O__O(arg_368) } else { tmp22 = linked_366.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_365, arg_368) }; if jrt.J2g_Truth(tmp22) { tmp21 = d__4 } else { tmp21 = nil }; arg_356 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21)); if linked_352 == nil { return ifn_353.Invoke_O_O_O__O(arg_354, arg_355, arg_356) } else { return linked_352.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_351, arg_354, arg_355, arg_356) } }
//line :111:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_14) { var n__4 any; var root_369 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_371 lang.IFn


















			if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = f__2; if linked_370 == nil { n__4 = ifn_371.Invoke_O__O(arg_372) } else { n__4 = linked_370.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_369, arg_372) }
//line :111:1
			var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__4); var root_373 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_375 lang.IFn



















			if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = acc__1; var arg_377 any; var root_379 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = n__4; if linked_380 == nil { arg_377 = ifn_381.Invoke_O__O(arg_382) } else { arg_377 = linked_380.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_379, arg_382) }; var arg_378 any; var tmp23 any = A_arbace_go_A_const_63; var tmp24 any = A_arbace_go_A_const_63.Invoke_O__O(m__5); var tmp25 any = A_arbace_go_A_const_68; var tmp26 any; var root_383 any = A_arbace_go_A_const_69.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_go_const_value_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_go_A_const_70.Invoke_O__O(m__5); var arg_387 any = A_arbace_go_A_const_71.Invoke_O__O(m__5); if linked_384 == nil { tmp26 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { tmp26 = linked_384.(*A_arbace_go_const_value_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }; arg_378 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)); if linked_374 == nil { return ifn_375.Invoke_O_O_O__O(arg_376, arg_377, arg_378) } else { return linked_374.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_373, arg_376, arg_377, arg_378) } }
//line :111:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_15) { var vec__1822000041__4 any; var root_388 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, A_arbace_go_strip_doc_A_fn_class); var ifn_390 lang.IFn
			if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var root_392 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_392, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_396 any = f__2; if linked_393 == nil { arg_391 = ifn_394.Invoke_O_O__O(A_arbace_go_A_const_59, arg_396) } else { arg_391 = linked_393.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_392, 2, A_arbace_go_A_const_59, arg_396) }; if linked_389 == nil { vec__1822000041__4 = ifn_390.Invoke_O__O(arg_391) } else { vec__1822000041__4 = linked_389.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_388, arg_391) }
//line :111:1
			var doc__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000041__4, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__7_2 bool; var tmp27 any = A_arbace_go_A_const_60; var tmp28 any; var root_397 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_399 lang.IFn

			if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = xs__6_2; if linked_398 == nil { tmp28 = ifn_399.Invoke_O__O(arg_400) } else { tmp28 = linked_398.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_397, arg_400) }; gen__7_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp27, tmp28)
//line :111:1
			var xs__8_2 any


			if gen__7_2 { var root_401 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_401, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_405 any = xs__6_2; if linked_402 == nil { xs__8_2 = ifn_403.Invoke_O_O__O(A_arbace_go_A_const_59, arg_405) } else { xs__8_2 = linked_402.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_401, 2, A_arbace_go_A_const_59, arg_405) } } else { xs__8_2 = xs__6_2 }
			var root_406 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = acc__1; var arg_410 any; var root_412 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var root_416 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = f__2; if linked_417 == nil { arg_415 = ifn_418.Invoke_O__O(arg_419) } else { arg_415 = linked_417.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_416, arg_419) }; if linked_413 == nil { arg_410 = ifn_414.Invoke_O__O(arg_415) } else { arg_410 = linked_413.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_412, arg_415) }; var arg_411 any; var G__1822000044__9_ any; var tmp29 any = A_arbace_go_A_const_63; var tmp30 any = A_arbace_go_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp32 any; var root_426 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_go_params_of_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var root_430 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = xs__8_2; if linked_431 == nil { arg_429 = ifn_432.Invoke_O__O(arg_433) } else { arg_429 = linked_431.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_430, arg_433) }; if linked_427 == nil { tmp32 = ifn_428.Invoke_O__O(arg_429) } else { tmp32 = linked_427.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_426, arg_429) }; G__1822000044__9_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, doc__5_2, tmp30, tmp31.Invoke_O__O(tmp32))); if gen__7_2 {
				var root_420 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = G__1822000044__9_; var arg_424 any = A_arbace_go_A_const_66; var arg_425 any = jrt.Boolean_TRUE.Ref(); if linked_421 == nil { arg_411 = ifn_422.Invoke_O_O_O__O(arg_423, arg_424, arg_425) } else { arg_411 = linked_421.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_420, arg_423, arg_424, arg_425) } } else {
//line :115:1
					arg_411 = G__1822000044__9_ }; if linked_407 == nil { return ifn_408.Invoke_O_O_O__O(arg_409, arg_410, arg_411) } else { return linked_407.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_406, arg_409, arg_410, arg_411) } }
//line :111:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_16) {





















			var root_438 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = acc__1; var arg_442 any; var root_444 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any; var root_448 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = f__2; if linked_449 == nil { arg_447 = ifn_450.Invoke_O__O(arg_451) } else { arg_447 = linked_449.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_448, arg_451) }; if linked_445 == nil { arg_442 = ifn_446.Invoke_O__O(arg_447) } else { arg_442 = linked_445.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_444, arg_447) }; var arg_443 any; var tmp33 any = A_arbace_go_A_const_63; var tmp34 *lang.Keyword = A_arbace_go_A_const_63; var tmp35 any; var root_452 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = f__2; if linked_453 == nil { tmp35 = ifn_454.Invoke_O__O(arg_455) } else { tmp35 = linked_453.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_452, arg_455) }; arg_443 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp35)))); if linked_439 == nil { return ifn_440.Invoke_O_O_O__O(arg_441, arg_442, arg_443) } else { return linked_439.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_438, arg_441, arg_442, arg_443) } }
//line :111:1
		default:}; return acc__1
	}
}





























func A_arbace_go_member_var_A_New() *A_arbace_go_member_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_member_var_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_member_var_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_member_var_A) Invoke_O_O_O_O_O_O_O__O(self, ns__0, path__1, nm__2, kind__3, handle__4, info__5 any) any { var full__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, path__1, nil, nm__2)).Ref(); var m__8 any; var G__1822000047__8_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_A_const_73, kind__3, A_arbace_go_A_const_74, path__1)); var G__1822000047__9_ any; if



	jrt.J2g_Truth(A_arbace_go_A_const_63.Invoke_O__O(info__5)) {
		var root_462 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = G__1822000047__8_; var arg_466 any = A_arbace_go_A_const_63; var arg_467 any = A_arbace_go_A_const_63.Invoke_O__O(info__5); if linked_463 == nil { G__1822000047__9_ = ifn_464.Invoke_O_O_O__O(arg_465, arg_466, arg_467) } else { G__1822000047__9_ = linked_463.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_462, arg_465, arg_466, arg_467) } } else {
//line :147:1
			G__1822000047__9_ = G__1822000047__8_ }; if jrt.J2g_Truth(A_arbace_go_A_const_64.Invoke_O__O(info__5)) {

				var root_468 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = G__1822000047__9_; var arg_472 any = A_arbace_go_A_const_64; var arg_473 any = A_arbace_go_A_const_64.Invoke_O__O(info__5); if linked_469 == nil { m__8 = ifn_470.Invoke_O_O_O__O(arg_471, arg_472, arg_473) } else { m__8 = linked_469.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_468, arg_471, arg_472, arg_473) } } else {
//line :147:1
					m__8 = G__1822000047__9_ }; var root_474 any =


	A_arbace_go_A_const_75.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = ns__0; var arg_478 any; var root_480 any = A_arbace_go_A_const_76.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any; var root_485 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = nm__2; if linked_486 == nil { arg_483 = ifn_487.Invoke_O__O(arg_488) } else { arg_483 = linked_486.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_485, arg_488) }; var arg_484 any = m__8; if linked_481 == nil { arg_478 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { arg_478 = linked_481.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) }; var arg_479 any; var G__1822000048__9_ any = kind__3; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1822000048__9_) >> 3 & 7 { case 1: if any(G__1822000048__9_) == any(A_arbace_go_A_const_77) { arg_479 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 3: if any(G__1822000048__9_) == any(A_arbace_go_A_const_78) { arg_479 = lang.GoVar_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 4: if any(G__1822000048__9_) == any(A_arbace_go_A_const_79) { arg_479 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 5: if any(G__1822000048__9_) == any(A_arbace_go_A_const_68) {



		arg_479 = A_arbace_go_A_const_68.Invoke_O__O(info__5)
//line :151:1
		break L1 }; case 6: if any(G__1822000048__9_) == any(A_arbace_go_A_const_80) { arg_479 = lang.GoType_New_O(handle__4); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1822000048__9_)))))}; if /*line :150:1*/ linked_475 == nil { return ifn_476.Invoke_O_O_O__O(arg_477, arg_478, arg_479) } else { return linked_475.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_474, arg_477, arg_478, arg_479) } }






func A_arbace_go_table_ns_BANG__A_New() *A_arbace_go_table_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Ctor() {}
//line :157:1
func (t *A_arbace_go_table_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any { var ns__2 any; var root_490 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_492 lang.IFn; if




	linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var root_494 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, A_arbace_go_path__GT_ns_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = p__0; if linked_495 == nil { arg_493 = ifn_496.Invoke_O__O(arg_497) } else { arg_493 = linked_495.(*A_arbace_go_path__GT_ns_A).Invoke_O_O__O(root_494, arg_497) }; if linked_491 == nil { ns__2 = ifn_492.Invoke_O__O(arg_493) } else { ns__2 = linked_491.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_490, arg_493) }; var early__3 any; var root_498 any = /*line :157:1*/A_arbace_go_A_const_33.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_500 lang.IFn; if







	linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var iter__1927001039__auto____3 any; var fnbody__599 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New_O(ns__2); var tmp1 *jrt.Class; var fncls__598 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class; if fncls__598 == nil { var fncls__598d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__599); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class = fncls__598d; tmp1 = fncls__598d } else { tmp1 = fncls__598 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__599, tmp1, nil); arg_501 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(jrt.NN(lang.Namespace_Cast(ns__2)).GetMappings__IPersistentMap()); if linked_499 == nil { early__3 = ifn_500.Invoke_O__O(arg_501) } else { early__3 = linked_499.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_498, arg_501) }; var ms__4 any = /*line :157:1*/lang.GoInterp_Members_String__O1(jrt.String_Cast(p__0)).Ref(); var members__5 any; var root_600 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_602 lang.IFn; if











	linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_604 any; var iter__1927001039__auto____5 any; var fnbody__674 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_New(); var tmp2 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class = fncls__673d; tmp2 = fncls__673d } else { tmp2 = fncls__673 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__674, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_675 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = A_arbace_go_A_const_96; var arg_679 any = ms__4; if linked_676 == nil { tmp4 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { tmp4 = linked_676.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }; arg_604 = tmp3.Invoke_O__O(tmp4); if linked_601 == nil { members__5 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { members__5 = linked_601.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; var info__6 any; var tmp5 /*line :157:1*/*lang.Compiler_AOTFn; var fnbody__685 any = A_arbace_go_table_ns_BANG__fn__1822000082_A_New_O(p__0); var tmp6 *jrt.Class; var fncls__684 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class; if












	fncls__684 == nil { var fncls__684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__685); A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class = fncls__684d; tmp6 = fncls__684d } else { tmp6 = fncls__684 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__685, tmp6, nil); info__6 = /*line :157:1*/lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp5)); var consts__7 any; var tmp7 *lang.Compiler_AOTFn; var fnbody__794 any = A_arbace_go_table_ns_BANG__fn__1822000084_A_New_O_O(info__6, members__5); var tmp8 *jrt.Class; var fncls__793 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class; if













	fncls__793 == nil { var fncls__793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__794); A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class = fncls__793d; tmp8 = fncls__793d } else { tmp8 = fncls__793 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__794, tmp8, nil); consts__7 = /*line :157:1*/lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp7)); var make__8 any; var fnbody__834 any = A_arbace_go_table_ns_BANG__make__1822000102_A_New_O_O_O_O_O(ns__2, info__6, consts__7, p__0, members__5); var tmp9 *jrt.Class; var fncls__833 *jrt.Class = A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class; if














	fncls__833 == nil { var fncls__833d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__834); A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class = fncls__833d; tmp9 = fncls__833d } else { tmp9 = fncls__833 }; make__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__834, tmp9, nil); var resolver__9 any; var fnbody__889 any = /*line :157:1*/A_arbace_go_table_ns_BANG__resolver__1822000107_A_New_O_O_O(make__8, consts__7, members__5); var tmp10 *jrt.Class; var fncls__888 *jrt.Class = A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class; if























	fncls__888 == nil { var fncls__888d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__889); A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class = fncls__888d; tmp10 = fncls__888d } else { tmp10 = fncls__888 }; resolver__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__889, tmp10, nil);





	jrt.NN(lang.Namespace_Cast(ns__2)).SetResolver_O__V(resolver__9); var seq_1822000113__10 any; var root_890 any = /*line :157:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_892 lang.IFn; if






























	linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = early__3; if linked_891 == nil { seq_1822000113__10 = ifn_892.Invoke_O__O(arg_893) } else { seq_1822000113__10 = linked_891.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_890, arg_893) }; var chunk_1822000114__11 any; var count_1822000115__12 int64 = 0; var i_1822000116__13 int64 = 0; L1:
//line :157:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000116__13, count_1822000115__12) { var n__14 any = lang.Indexed_Cast(chunk_1822000114__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000116__13)); lang.IFn_Cast(make__8).Invoke_O__O(n__14); seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000116__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_894 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = seq_1822000113__10; if linked_895 == nil { temp__1927000414__auto____14 = ifn_896.Invoke_O__O(arg_897) } else { temp__1927000414__auto____14 = linked_895.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_894, arg_897) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000113__15 any = temp__1927000414__auto____14; var tmp11 any; var root_898 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = seq_1822000113__15; if linked_899 == nil { tmp11 = ifn_900.Invoke_O__O(arg_901) } else { tmp11 = linked_899.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_898, arg_901) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____16 any; var root_902 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = seq_1822000113__15; if linked_903 == nil { c__1927000678__auto____16 = ifn_904.Invoke_O__O(arg_905) } else { c__1927000678__auto____16 = linked_903.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_902, arg_905) }; var tmp12 any; var root_910 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = seq_1822000113__15; if linked_911 == nil { tmp12 = ifn_912.Invoke_O__O(arg_913) } else { tmp12 = linked_911.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_910, arg_913) }; seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = tmp12, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__16 any; var root_906 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = seq_1822000113__15; if linked_907 == nil { n__16 = ifn_908.Invoke_O__O(arg_909) } else { n__16 = linked_907.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_906, arg_909) }; lang.IFn_Cast(make__8).Invoke_O__O(n__16); var tmp13 any; var root_914 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = seq_1822000113__15; if linked_915 == nil { tmp13 = ifn_916.Invoke_O__O(arg_917) } else { tmp13 = linked_915.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_914, arg_917) }; seq_1822000113__10, chunk_1822000114__11, count_1822000115__12, i_1822000116__13 = tmp13, nil, 0, 0; continue L1 } } }
//line :157:1
		break L1 }; return ns__2 }







func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A{}; t.Ctor_O(p0); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A) Invoke_O_O__O(self, s__1822000051__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__597 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O_O(t.F_ns, s__1822000051__1, self); var tmp2 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class; if fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__597); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class = fncls__596d; tmp2 = fncls__596d } else { tmp2 = fncls__596 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__597, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :165:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Ctor_O_O_O(c__ns, c__s__1822000051, c__iter__1822000050 any) { t.F_ns = c__ns; t.F_s__1822000051 = c__s__1822000051; t.F_iter__1822000050 = c__iter__1822000050 }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A) Invoke_O__O(self any) any { { var s__1822000051__1 any; var t_ any = t.F_s__1822000051; t.F_s__1822000051 = nil; s__1822000051__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_502 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = s__1822000051__1; if linked_503 == nil { temp__1927000414__auto____2 = ifn_504.Invoke_O__O(arg_505) } else { temp__1927000414__auto____2 = linked_503.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_502, arg_505) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000051__3 any = temp__1927000414__auto____2; var tmp1 any; var root_506 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = s__1822000051__3; if linked_507 == nil { tmp1 = ifn_508.Invoke_O__O(arg_509) } else { tmp1 = linked_507.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_506, arg_509) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_510 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = s__1822000051__3; if linked_511 == nil { c__1927001037__auto____4 = ifn_512.Invoke_O__O(arg_513) } else { c__1927001037__auto____4 = linked_511.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_510, arg_513) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000053__6 any; var root_514 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_515 == nil { b__1822000053__6 = ifn_516.Invoke_O__O(arg_517) } else { b__1822000053__6 = linked_515.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_514, arg_517) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__540 any = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_O_I_O(b__1822000053__6, t.F_ns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__540); A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class = fncls__539d; tmp3 = fncls__539d } else { tmp3 = fncls__539 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__540, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_541 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any; var root_546 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = b__1822000053__6; if linked_547 == nil { arg_544 = ifn_548.Invoke_O__O(arg_549) } else { arg_544 = linked_547.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_546, arg_549) }; var arg_545 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp5 any; var root_550 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__1822000051__3; if linked_551 == nil { tmp5 = ifn_552.Invoke_O__O(arg_553) } else { tmp5 = linked_551.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_550, arg_553) }; arg_545 = tmp4.Invoke_O__O(tmp5); if linked_542 == nil { return ifn_543.Invoke_O_O__O(arg_544, arg_545) } else { return linked_542.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_541, arg_544, arg_545) } } else { var root_554 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var root_559 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = b__1822000053__6; if linked_560 == nil { arg_557 = ifn_561.Invoke_O__O(arg_562) } else { arg_557 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_559, arg_562) }; var arg_558 any; if linked_555 == nil { return ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { return linked_555.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) } } } else { var vec__1822000061__4 any; var root_563 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__1822000051__3; if linked_564 == nil { vec__1822000061__4 = ifn_565.Invoke_O__O(arg_566) } else { vec__1822000061__4 = linked_564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_563, arg_566) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_567 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_569 lang.IFn
														if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = v__6; if linked_568 == nil { and__1927000168__auto____7 = ifn_569.Invoke_O__O(arg_570) } else { and__1927000168__auto____7 = linked_568.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_567, arg_570) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp7 any = t.F_ns; var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(tmp7, lang.Var_Cast(v__6).F_ns.Ref()); if and__1927000168__auto____8 { var root_571 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = lang.IFn_Cast(A_arbace_go_A_const_87.GetRawRoot__O()).Invoke_O__O(v__6); if linked_572 == nil { tmp6 = ifn_573.Invoke_O__O(arg_574) } else { tmp6 = linked_572.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_571, arg_574) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp6 = and__1927000168__auto____7 }
//line :165:1
	if jrt.J2g_Truth(tmp6) { var root_579 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var root_584 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_586 lang.IFn

		if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__5; if linked_585 == nil { arg_582 = ifn_586.Invoke_O__O(arg_587) } else { arg_582 = linked_585.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_584, arg_587) }
//line :165:1
		var arg_583 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000050); var tmp9 any; var root_588 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = s__1822000051__3; if linked_589 == nil { tmp9 = ifn_590.Invoke_O__O(arg_591) } else { tmp9 = linked_589.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_588, arg_591) }; arg_583 = tmp8.Invoke_O__O(tmp9); if linked_580 == nil { return ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { return linked_580.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) } } else { var tmp10 any; var root_592 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = s__1822000051__3; if linked_593 == nil { tmp10 = ifn_594.Invoke_O__O(arg_595) } else { tmp10 = linked_593.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_592, arg_595) }; s__1822000051__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Ctor_O_O_I_O(c__b__1822000053, c__ns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000053 = c__b__1822000053; t.F_ns = c__ns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A) Invoke_O__O(self any) any { { var i__1822000052__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000052__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000057__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000052__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_518 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_520 lang.IFn
																if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = v__4; if linked_519 == nil { and__1927000168__auto____5 = ifn_520.Invoke_O__O(arg_521) } else { and__1927000168__auto____5 = linked_519.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_518, arg_521) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any = t.F_ns; var and__1927000168__auto____6 bool = lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.Var_Cast(v__4).F_ns.Ref()); if and__1927000168__auto____6 { var root_522 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = lang.IFn_Cast(A_arbace_go_A_const_87.GetRawRoot__O()).Invoke_O__O(v__4); if linked_523 == nil { tmp2 = ifn_524.Invoke_O__O(arg_525) } else { tmp2 = linked_523.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_522, arg_525) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp2 = and__1927000168__auto____5 }
//line :165:1
	if jrt.J2g_Truth(tmp2) { var root_530 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = t.F_b__1822000053; var arg_534 any; var root_535 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_537 lang.IFn

		if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = s__3; if linked_536 == nil { arg_534 = ifn_537.Invoke_O__O(arg_538) } else { arg_534 = linked_536.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_535, arg_538) }
//line :165:1
		if linked_531 == nil { ifn_532.Invoke_O_O__O(arg_533, arg_534) } else { linked_531.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_530, arg_533, arg_534) }; i__1822000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000052__1); continue L1 } else { i__1822000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000052__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_New() *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A) Invoke_O_O__O(self, s__1822000067__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__672 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_New_O_O(s__1822000067__1, self); var tmp2 *jrt.Class; var fncls__671 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class; if fncls__671 == nil { var fncls__671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__672); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class = fncls__671d; tmp2 = fncls__671d } else { tmp2 = fncls__671 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__672, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :169:1
func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A) Ctor_O_O(c__s__1822000067, c__iter__1822000066 any) { t.F_s__1822000067 = c__s__1822000067; t.F_iter__1822000066 = c__iter__1822000066 }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A) Invoke_O__O(self any) any { { var s__1822000067__1 any; var t_ any = t.F_s__1822000067; t.F_s__1822000067 = nil; s__1822000067__1 = t_; for { var temp__1927000414__auto____2 any; var root_605 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = s__1822000067__1; if linked_606 == nil { temp__1927000414__auto____2 = ifn_607.Invoke_O__O(arg_608) } else { temp__1927000414__auto____2 = linked_606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_605, arg_608) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000067__3 any = temp__1927000414__auto____2; var tmp1 any; var root_609 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = s__1822000067__3; if linked_610 == nil { tmp1 = ifn_611.Invoke_O__O(arg_612) } else { tmp1 = linked_610.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_609, arg_612) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_613 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = s__1822000067__3; if linked_614 == nil { c__1927001037__auto____4 = ifn_615.Invoke_O__O(arg_616) } else { c__1927001037__auto____4 = linked_614.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_613, arg_616) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000069__6 any; var root_617 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_618 == nil { b__1822000069__6 = ifn_619.Invoke_O__O(arg_620) } else { b__1822000069__6 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_617, arg_620) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__631 any = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_New_O_I_O(b__1822000069__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__631); A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class = fncls__630d; tmp3 = fncls__630d } else { tmp3 = fncls__630 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__631, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_632 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any; var root_637 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = b__1822000069__6; if linked_638 == nil { arg_635 = ifn_639.Invoke_O__O(arg_640) } else { arg_635 = linked_638.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_637, arg_640) }; var arg_636 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000066); var tmp5 any; var root_641 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = s__1822000067__3; if linked_642 == nil { tmp5 = ifn_643.Invoke_O__O(arg_644) } else { tmp5 = linked_642.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_641, arg_644) }; arg_636 = tmp4.Invoke_O__O(tmp5); if linked_633 == nil { return ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { return linked_633.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) } } else { var root_645 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any; var root_650 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = b__1822000069__6; if linked_651 == nil { arg_648 = ifn_652.Invoke_O__O(arg_653) } else { arg_648 = linked_651.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_650, arg_653) }; var arg_649 any; if linked_646 == nil { return ifn_647.Invoke_O_O__O(arg_648, arg_649) } else { return linked_646.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_645, arg_648, arg_649) } } } else { var vec__1822000077__4 any; var root_654 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = s__1822000067__3; if linked_655 == nil { vec__1822000077__4 = ifn_656.Invoke_O__O(arg_657) } else { vec__1822000077__4 = linked_655.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_654, arg_657) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000077__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_658 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var tmp6 any; var root_663 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = k__5; if linked_664 == nil { tmp6 = ifn_665.Invoke_O__O(arg_666) } else { tmp6 = linked_664.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_663, arg_666) }; arg_661 = lang.Tuple_Create_O_O__IPersistentVector(n__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6, h__7)); var arg_662 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1822000066); var tmp8 any; var root_667 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__1822000067__3; if linked_668 == nil { tmp8 = ifn_669.Invoke_O__O(arg_670) } else { tmp8 = linked_668.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_667, arg_670) }; arg_662 = tmp7.Invoke_O__O(tmp8); if linked_659 == nil { return ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { return linked_659.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A) Ctor_O_I_O(c__b__1822000069 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000069 = c__b__1822000069; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A) Invoke_O__O(self any) any { { var i__1822000068__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000068__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000073__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000068__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000073__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_621 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = t.F_b__1822000069; var arg_625 any; var tmp2 any; var root_626 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = k__3; if linked_627 == nil { tmp2 = ifn_628.Invoke_O__O(arg_629) } else { tmp2 = linked_627.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_626, arg_629) }; arg_625 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.Tuple_Create_O_O__IPersistentVector(tmp2, h__5)); if linked_622 == nil { ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { linked_622.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; i__1822000068__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000068__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__fn__1822000082_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000082_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000082_A{}; t.Ctor_O(p0); return t }
//line :170:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000082_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :170:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000082_A) Invoke_O__O(self any) any { var root_680 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, A_arbace_go_digest_info_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var t_ any = t.F_p; t.F_p = nil; arg_683 = t_; if linked_681 == nil { return ifn_682.Invoke_O__O(arg_683) } else { return linked_681.(*A_arbace_go_digest_info_A).Invoke_O_O__O(root_680, arg_683) } }
func A_arbace_go_table_ns_BANG__fn__1822000084_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__fn__1822000084_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_A{}; t.Ctor_O_O(p0, p1); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_A) Ctor_O_O(c__info, c__members any) { t.F_info = c__info; t.F_members = c__members }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_A) Invoke_O__O(self any) any { var root_686 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_690 any; var iter__1927001039__auto____1 any; var fnbody__788 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_New_O(t.F_members); var tmp1 *jrt.Class; var fncls__787 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class; if fncls__787 == nil { var fncls__787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__788); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class = fncls__787d; tmp1 = fncls__787d } else { tmp1 = fncls__787 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__788, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp3 any; var root_789 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var t_ any = t.F_info; t.F_info = nil; arg_792 = t_; if linked_790 == nil { tmp3 = ifn_791.Invoke_O__O(arg_792) } else { tmp3 = linked_790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_789, arg_792) }; arg_690 = tmp2.Invoke_O__O(tmp3); if linked_687 == nil { return ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { return linked_687.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) } }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A{}; t.Ctor_O(p0); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A) Ctor_O(c__members any) { t.F_members = c__members }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A) Invoke_O_O__O(self, s__1822000086__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__786 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_New_O_O_O(t.F_members, s__1822000086__1, self); var tmp2 *jrt.Class; var fncls__785 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class; if fncls__785 == nil { var fncls__785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__786); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class = fncls__785d; tmp2 = fncls__785d } else { tmp2 = fncls__785 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__786, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A) Ctor_O_O_O(c__members, c__s__1822000086, c__iter__1822000085 any) { t.F_members = c__members; t.F_s__1822000086 = c__s__1822000086; t.F_iter__1822000085 = c__iter__1822000085 }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A) Invoke_O__O(self any) any { { var s__1822000086__1 any; var t_ any = t.F_s__1822000086; t.F_s__1822000086 = nil; s__1822000086__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_691 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__1822000086__1; if linked_692 == nil { temp__1927000414__auto____2 = ifn_693.Invoke_O__O(arg_694) } else { temp__1927000414__auto____2 = linked_692.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_691, arg_694) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000086__3 any = temp__1927000414__auto____2; var tmp1 any; var root_695 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__1822000086__3; if linked_696 == nil { tmp1 = ifn_697.Invoke_O__O(arg_698) } else { tmp1 = linked_696.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_695, arg_698) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_699 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = s__1822000086__3; if linked_700 == nil { c__1927001037__auto____4 = ifn_701.Invoke_O__O(arg_702) } else { c__1927001037__auto____4 = linked_700.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_699, arg_702) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000088__6 any; var root_703 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_704 == nil { b__1822000088__6 = ifn_705.Invoke_O__O(arg_706) } else { b__1822000088__6 = linked_704.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_703, arg_706) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__727 any = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_New_O_O_I_O(b__1822000088__6, t.F_members, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__726 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class; if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__727); A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class = fncls__726d; tmp3 = fncls__726d } else { tmp3 = fncls__726 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__727, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_728 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var root_733 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = b__1822000088__6; if linked_734 == nil { arg_731 = ifn_735.Invoke_O__O(arg_736) } else { arg_731 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_733, arg_736) }; var arg_732 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000085); var tmp5 any; var root_737 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = s__1822000086__3; if linked_738 == nil { tmp5 = ifn_739.Invoke_O__O(arg_740) } else { tmp5 = linked_738.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_737, arg_740) }; arg_732 = tmp4.Invoke_O__O(tmp5); if linked_729 == nil { return ifn_730.Invoke_O_O__O(arg_731, arg_732) } else { return linked_729.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_728, arg_731, arg_732) } } else { var root_741 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any; var root_746 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = b__1822000088__6; if linked_747 == nil { arg_744 = ifn_748.Invoke_O__O(arg_749) } else { arg_744 = linked_747.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_746, arg_749) }; var arg_745 any; if linked_742 == nil { return ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { return linked_742.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) } } } else { var vec__1822000096__4 any; var root_750 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = s__1822000086__3; if linked_751 == nil { vec__1822000096__4 = ifn_752.Invoke_O__O(arg_753) } else { vec__1822000096__4 = linked_751.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_750, arg_753) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000096__4, lang.RT_IntCast_J__I_NoInit(0), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000096__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_754 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = i__6; var arg_758 any = A_arbace_go_A_const_68; if linked_755 == nil { tmp6 = ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { tmp6 = linked_755.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_754, arg_757, arg_758) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_759 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_763 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = t.F_members; var arg_767 any = n__5; if linked_764 == nil { arg_762 = ifn_765.Invoke_O_O__O(arg_766, arg_767) } else { arg_762 = linked_764.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_763, arg_766, arg_767) }; if linked_760 == nil { tmp7 = ifn_761.Invoke_O__O(arg_762) } else { tmp7 = linked_760.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(tmp7) { var root_768 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, i__6); var arg_772 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000085); var tmp9 any; var root_773 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = s__1822000086__3; if linked_774 == nil { tmp9 = ifn_775.Invoke_O__O(arg_776) } else { tmp9 = linked_774.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_773, arg_776) }; arg_772 = tmp8.Invoke_O__O(tmp9); if linked_769 == nil { return ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { return linked_769.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } else { var tmp10 any; var root_777 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__1822000086__3; if linked_778 == nil { tmp10 = ifn_779.Invoke_O__O(arg_780) } else { tmp10 = linked_778.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_777, arg_780) }; s__1822000086__1 = tmp10; continue L1 } } else { var tmp11 any; var root_781 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = s__1822000086__3; if linked_782 == nil { tmp11 = ifn_783.Invoke_O__O(arg_784) } else { tmp11 = linked_782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_781, arg_784) }; s__1822000086__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :171:1
func A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A) Ctor_O_O_I_O(c__b__1822000088, c__members any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000088 = c__b__1822000088; t.F_members = c__members; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :171:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A) Invoke_O__O(self any) any { { var i__1822000087__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000087__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000092__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000087__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000092__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000092__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_707 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = i__4; var arg_711 any = A_arbace_go_A_const_68; if linked_708 == nil { tmp2 = ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { tmp2 = linked_708.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_707, arg_710, arg_711) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_712 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any; var root_716 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = t.F_members; var arg_720 any = n__3; if linked_717 == nil { arg_715 = ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { arg_715 = linked_717.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; if linked_713 == nil { tmp3 = ifn_714.Invoke_O__O(arg_715) } else { tmp3 = linked_713.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_712, arg_715) }; if jrt.J2g_Truth(tmp3) { var root_721 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = t.F_b__1822000088; var arg_725 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, i__4); if linked_722 == nil { ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { linked_722.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) }; i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } else { i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } } else { i__1822000087__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000087__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__make__1822000102_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_table_ns_BANG__make__1822000102_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__make__1822000102_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :172:1
func (t *A_arbace_go_table_ns_BANG__make__1822000102_A) Ctor_O_O_O_O_O(c__ns, c__info, c__consts, c__p, c__members any) { t.F_ns = c__ns; t.F_info = c__info; t.F_consts = c__consts; t.F_p = c__p; t.F_members = c__members }
//line :172:1
func (t *A_arbace_go_table_ns_BANG__make__1822000102_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_members, n__1); if
												jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1822000103__3 any = temp__1927000408__auto____2; var kind__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000103__3, lang.RT_IntCast_J__I_NoInit(0), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000103__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_795 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_go_member_var_A_fn_class); var ifn_797 lang.IFn
													if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = t.F_ns; var arg_799 any = t.F_p; var arg_800 any = n__1; var arg_801 any = kind__4; var arg_802 any = h__5; var arg_803 any; var tmp1 any; var root_804 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = t.F_info; if linked_805 == nil { tmp1 = ifn_806.Invoke_O__O(arg_807) } else { tmp1 = linked_805.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_804, arg_807) }; arg_803 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if linked_796 == nil { return ifn_797.Invoke_O_O_O_O_O_O__O(arg_798, arg_799, arg_800, arg_801, arg_802, arg_803) } else { return linked_796.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_795, arg_798, arg_799, arg_800, arg_801, arg_802, arg_803) } } else {
//line :173:1
			var temp__1927000408__auto____3 any; var tmp2 any; var root_808 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_810 lang.IFn

			if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = t.F_consts; if linked_809 == nil { tmp2 = ifn_810.Invoke_O__O(arg_811) } else { tmp2 = linked_809.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_808, arg_811) }; temp__1927000408__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__1); if jrt.J2g_Truth(temp__1927000408__auto____3) { var i__4 any = temp__1927000408__auto____3; var root_812 any = A_arbace_go_A_const_99.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_go_member_var_A_fn_class); var ifn_814 lang.IFn
				if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = t.F_ns; var arg_816 any = t.F_p; var arg_817 any = n__1; var arg_818 any = A_arbace_go_A_const_68; var arg_819 any; var arg_820 any = i__4; if linked_813 == nil { return ifn_814.Invoke_O_O_O_O_O_O__O(arg_815, arg_816, arg_817, arg_818, arg_819, arg_820) } else { return linked_813.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_812, arg_815, arg_816, arg_817, arg_818, arg_819, arg_820) } } else {


					var tmp3 *lang.Keyword = A_arbace_go_A_const_66; var tmp4 any; var root_821 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = t.F_info; if linked_822 == nil { tmp4 = ifn_823.Invoke_O__O(arg_824) } else { tmp4 = linked_822.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_821, arg_824) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(tmp4, n__1))) {
						var tmp5 any; var root_825 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_go_repl_fn_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = Lit_66; if linked_826 == nil { tmp5 = ifn_827.Invoke_O__O(arg_828) } else { tmp5 = linked_826.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_825, arg_828) }; var tmp6 lang.IFn = lang.IFn_Cast(tmp5); var tmp7 any = t.F_ns; var tmp8 any = t.F_p; var tmp9 any; var root_829 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = t.F_info; if linked_830 == nil { tmp9 = ifn_831.Invoke_O__O(arg_832) } else { tmp9 = linked_830.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_829, arg_832) }; return tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, n__1, lang.RT_Get_O_O__O_NoInit(tmp9, n__1)) } else {
//line :179:1
							return nil } } } }

func A_arbace_go_table_ns_BANG__resolver__1822000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__resolver__1822000107_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__resolver__1822000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Ctor_O_O_O(c__make, c__consts, c__members any) { t.F_make = c__make; t.F_consts = c__consts; t.F_members = c__members }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Invoke_O_O_O__O(self, ___1, sym__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(t.F_make); var tmp2 any; var root_835 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = sym__2; if linked_836 == nil { tmp2 = ifn_837.Invoke_O__O(arg_838) } else { tmp2 = linked_836.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_835, arg_838) }; return tmp1.Invoke_O__O(tmp2) }
//line :181:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000107_A) Invoke_O_O__O(self, ___1 any) any { { var seq_1822000108__2 any; var root_839 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_841 lang.IFn

	if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_843 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any; var root_847 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any; var root_852 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = t.F_members; if linked_853 == nil { arg_850 = ifn_854.Invoke_O__O(arg_855) } else { arg_850 = linked_853.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_852, arg_855) }; var arg_851 any; var root_856 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any; var root_860 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = t.F_consts; if linked_861 == nil { arg_859 = ifn_862.Invoke_O__O(arg_863) } else { arg_859 = linked_861.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_860, arg_863) }; if linked_857 == nil { arg_851 = ifn_858.Invoke_O__O(arg_859) } else { arg_851 = linked_857.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_856, arg_859) }; if linked_848 == nil { arg_846 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { arg_846 = linked_848.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }; if linked_844 == nil { arg_842 = ifn_845.Invoke_O__O(arg_846) } else { arg_842 = linked_844.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_843, arg_846) }; if linked_840 == nil { seq_1822000108__2 = ifn_841.Invoke_O__O(arg_842) } else { seq_1822000108__2 = linked_840.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_839, arg_842) }
//line :181:1
	var chunk_1822000109__3 any; var count_1822000110__4 int64 = 0; var i_1822000111__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000111__5, count_1822000110__4) { var n__6 any = lang.Indexed_Cast(chunk_1822000109__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000111__5))
			lang.IFn_Cast(t.F_make).Invoke_O__O(n__6)
//line :183:1
			seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000111__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_864 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = seq_1822000108__2; if linked_865 == nil { temp__1927000414__auto____6 = ifn_866.Invoke_O__O(arg_867) } else { temp__1927000414__auto____6 = linked_865.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_864, arg_867) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1822000108__7 any = temp__1927000414__auto____6; var tmp1 any; var root_868 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = seq_1822000108__7; if linked_869 == nil { tmp1 = ifn_870.Invoke_O__O(arg_871) } else { tmp1 = linked_869.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_868, arg_871) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_872 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = seq_1822000108__7; if linked_873 == nil { c__1927000678__auto____8 = ifn_874.Invoke_O__O(arg_875) } else { c__1927000678__auto____8 = linked_873.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_872, arg_875) }; var tmp2 any; var root_880 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = seq_1822000108__7; if linked_881 == nil { tmp2 = ifn_882.Invoke_O__O(arg_883) } else { tmp2 = linked_881.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_880, arg_883) }; seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_876 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = seq_1822000108__7; if linked_877 == nil { n__8 = ifn_878.Invoke_O__O(arg_879) } else { n__8 = linked_877.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_876, arg_879) }
				lang.IFn_Cast(t.F_make).Invoke_O__O(n__8)
//line :183:1
				var tmp3 any; var root_884 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = seq_1822000108__7; if linked_885 == nil { tmp3 = ifn_886.Invoke_O__O(arg_887) } else { tmp3 = linked_885.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_884, arg_887) }; seq_1822000108__2, chunk_1822000109__3, count_1822000110__4, i_1822000111__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :181:1*/panic("j2g: unreachable") }









func A_arbace_go_interpretable_ns_BANG__A_New() *A_arbace_go_interpretable_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_interpretable_ns_BANG__A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Ctor() {}
//line :191:1
func (t *A_arbace_go_interpretable_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any {





	var tmp1 *jrt.Boolean; var tmp2 any; var root_918 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_go_repl_fn_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = Lit_29; if linked_919 == nil { tmp2 = ifn_920.Invoke_O__O(arg_921) } else { tmp2 = linked_919.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_918, arg_921) }; if jrt.J2g_Truth(lang.IFn_Cast(tmp2).Invoke_O__O(p__0)) {
		var tmp3 any; var root_922 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, A_arbace_go_repl_fn_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = Lit_30; if linked_923 == nil { tmp3 = ifn_924.Invoke_O__O(arg_925) } else { tmp3 = linked_923.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_922, arg_925) }; lang.IFn_Cast(tmp3).Invoke_O__O(p__0)
//line :197:1
		tmp1 = jrt.Boolean_TRUE } else { tmp1 = nil }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref())).Ref()
}


func A_arbace_go_packages_A_New() *A_arbace_go_packages_A { A_arbace_go_A_Init(); t := &A_arbace_go_packages_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_packages_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_packages_A) Invoke_O__O(self any) any {


	var root_926 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = lang.GoInterp_Paths__O1().Ref(); if linked_927 == nil { return ifn_928.Invoke_O__O(arg_929) } else { return linked_927.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_926, arg_929)
	}
}


func A_arbace_go_new_A_New() *A_arbace_go_new_A { A_arbace_go_A_Init(); t := &A_arbace_go_new_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_go_new_A) Ctor() {}
//line :209:1
func (t *A_arbace_go_new_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_NewValue_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_zero_A_New() *A_arbace_go_zero_A { A_arbace_go_A_Init(); t := &A_arbace_go_zero_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_zero_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_zero_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_Zero_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_type_of_A_New() *A_arbace_go_type_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_of_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_go_type_of_A) Ctor() {}
//line :219:1
func (t *A_arbace_go_type_of_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_TypeOf_O__O(v__0)
}
func A_arbace_go_str_A_New() *A_arbace_go_str_A { A_arbace_go_A_Init(); t := &A_arbace_go_str_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_str_A) Ctor() {}
//line :224:1
func (t *A_arbace_go_str_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_Str_O__String(v__0).Ref()
}
func A_arbace_go_spread_A_New() *A_arbace_go_spread_A { A_arbace_go_A_Init(); t := &A_arbace_go_spread_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_spread_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_spread_A) Invoke_O_O__O(self, xs__0 any) any {



	return lang.GoInterp_Spread_O__O(xs__0)
}
func A_arbace_go_assign_BANG__A_New() *A_arbace_go_assign_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_assign_BANG__A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_go_assign_BANG__A) Ctor() {}
//line :235:1
func (t *A_arbace_go_assign_BANG__A) Invoke_O_O_O__O(self, v__0, x__1 any) any {



	lang.GoInterp_Store_O_O__V(lang.GoVar_Cast(v__0).F_cell, x__1)
//line :235:1
	return x__1
}











func A_arbace_go_type_names_A_New() *A_arbace_go_type_names_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_go_type_names_A) Ctor() {}
//line :248:1
func (t *A_arbace_go_type_names_A) Invoke_O_O__O(self, ts__0 any) any { var root_930 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_934 any; var root_935 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = Lit_67; var arg_939 any; var root_940 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any; var fnbody__946 any = A_arbace_go_type_names_fn__1822000127_A_New(); var tmp1 *jrt.Class; var fncls__945 *jrt.Class = A_arbace_go_type_names_fn__1822000127_A_fn_class; if fncls__945 == nil { var fncls__945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_go_type_names_fn__1822000127_A_fn_class = fncls__945d; tmp1 = fncls__945d } else { tmp1 = fncls__945 }; arg_943 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__946, tmp1, nil); var arg_944 any = ts__0; if linked_941 == nil { arg_939 = ifn_942.Invoke_O_O__O(arg_943, arg_944) } else { arg_939 = linked_941.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_940, arg_943, arg_944) }; if linked_936 == nil { arg_934 = ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { arg_934 = linked_936.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_935, arg_938, arg_939) }; if linked_931 == nil { return ifn_932.Invoke_O_O__O(arg_933, arg_934) } else { return linked_931.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_930, arg_933, arg_934) } }
//line :248:1
func A_arbace_go_type_names_fn__1822000127_A_New() *A_arbace_go_type_names_fn__1822000127_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_fn__1822000127_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_go_type_names_fn__1822000127_A) Ctor() {}
//line :248:1
func (t *A_arbace_go_type_names_fn__1822000127_A) Invoke_O_O__O(self, p1__1822000126_SHARP___1 any) any { return jrt.NN(lang.GoType_Cast(p1__1822000126_SHARP___1)).GetName__String().Ref() }

func A_arbace_go_reify_type_A_New() *A_arbace_go_reify_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_type_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_reify_type_A) Ctor() {}
//line :250:1
func (t *A_arbace_go_reify_type_A) Invoke_O_O__O(self, ts__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_947 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_949 lang.IFn; if



	linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = A_arbace_go_A_const_104.GetRawRoot__O(); if linked_948 == nil { tmp1 = ifn_949.Invoke_O__O(arg_950) } else { tmp1 = linked_948.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_947, arg_950) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, ts__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var root_951 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_953 lang.IFn
		if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = lang.GoInterp_ReifyType_O1__O1(lang.RT_Object_array_O__O1_NoInit(ts__0)).Ref(); if linked_952 == nil { r__3 = ifn_953.Invoke_O__O(arg_954) } else { r__3 = linked_952.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_951, arg_954) }
		var root_955 any = A_arbace_go_A_const_105.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = A_arbace_go_A_const_104.GetRawRoot__O(); var arg_959 any = A_arbace_go_A_const_62.GetRawRoot__O(); var arg_960 any = ts__0; var arg_961 any = r__3; if linked_956 == nil { ifn_957.Invoke_O_O_O_O__O(arg_958, arg_959, arg_960, arg_961) } else { linked_956.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_955, arg_958, arg_959, arg_960, arg_961) }
//line :254:1
		return r__3 } }




func A_arbace_go_reify_data_A_New() *A_arbace_go_reify_data_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_reify_data_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_reify_data_A) Invoke_O_O_O_O__O(self, rt__0, ts__1, fns__2 any) any { var vec__1822000131__4 any = rt__0; var seq__1822000132__5 any; var root_962 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_964 lang.IFn; if




	linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = vec__1822000131__4; if linked_963 == nil { seq__1822000132__5 = ifn_964.Invoke_O__O(arg_965) } else { seq__1822000132__5 = linked_963.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_962, arg_965) }; var first__1822000133__6 any; var root_966 any = /*line :259:1*/A_arbace_go_A_const_25.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_968 lang.IFn; if




	linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = seq__1822000132__5; if linked_967 == nil { first__1822000133__6 = ifn_968.Invoke_O__O(arg_969) } else { first__1822000133__6 = linked_967.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_966, arg_969) }; var seq__1822000132__7 any; var root_970 any = /*line :259:1*/A_arbace_go_A_const_22.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_972 lang.IFn; if




	linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = seq__1822000132__5; if linked_971 == nil { seq__1822000132__7 = ifn_972.Invoke_O__O(arg_973) } else { seq__1822000132__7 = linked_971.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_970, arg_973) }; var t__8 any = first__1822000133__6; var names__9 any = seq__1822000132__7; var seq_1822000134__10 any; var root_1049 any = /*line :259:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1051 lang.IFn; if





	linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any; var root_1053 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = fns__2; if linked_1054 == nil { arg_1052 = ifn_1055.Invoke_O__O(arg_1056) } else { arg_1052 = linked_1054.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1053, arg_1056) }; if linked_1050 == nil { seq_1822000134__10 = ifn_1051.Invoke_O__O(arg_1052) } else { seq_1822000134__10 = linked_1050.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1049, arg_1052) }; var chunk_1822000135__11 any; var count_1822000136__12 int64 = 0; var i_1822000137__13 int64 = 0; L1:
//line :259:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000137__13, count_1822000136__12) { var k__14 any = lang.Indexed_Cast(chunk_1822000135__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000137__13)); var tmp1 any; var root_1073 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1075 lang.IFn
			if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__14)); var arg_1077 any = names__9; if linked_1074 == nil { tmp1 = ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { tmp1 = linked_1074.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp3 any; var root_1078 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, A_arbace_go_type_names_A_fn_class); var ifn_1080 lang.IFn

				if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = ts__1; if linked_1079 == nil { tmp3 = ifn_1080.Invoke_O__O(arg_1081) } else { tmp3 = linked_1079.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1078, arg_1081) }
//line :266:1
				panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__14, nil, tmp3))))) }
//line :265:1
			seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000137__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_1057 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = seq_1822000134__10; if linked_1058 == nil { temp__1927000414__auto____14 = ifn_1059.Invoke_O__O(arg_1060) } else { temp__1927000414__auto____14 = linked_1058.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1057, arg_1060) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000134__15 any = temp__1927000414__auto____14; var tmp4 any; var root_1061 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = seq_1822000134__15; if linked_1062 == nil { tmp4 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp4 = linked_1062.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1061, arg_1064) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____16 any; var root_1065 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = seq_1822000134__15; if linked_1066 == nil { c__1927000678__auto____16 = ifn_1067.Invoke_O__O(arg_1068) } else { c__1927000678__auto____16 = linked_1066.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1065, arg_1068) }; var tmp5 any; var root_1082 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = seq_1822000134__15; if linked_1083 == nil { tmp5 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp5 = linked_1083.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1082, arg_1085) }; seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = tmp5, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__16 any; var root_1069 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = seq_1822000134__15; if linked_1070 == nil { k__16 = ifn_1071.Invoke_O__O(arg_1072) } else { k__16 = linked_1070.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1069, arg_1072) }
				var tmp6 any; var root_1086 any = A_arbace_go_A_const_107.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__16)); var arg_1090 any = names__9; if linked_1087 == nil { tmp6 = ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { tmp6 = linked_1087.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090) }; if jrt.J2g_Truth(tmp6) { } else { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp8 any; var root_1091 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, A_arbace_go_type_names_A_fn_class); var ifn_1093 lang.IFn

					if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = ts__1; if linked_1092 == nil { tmp8 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp8 = linked_1092.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1091, arg_1094) }
//line :266:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, k__16, nil, tmp8))))) }
//line :265:1
				var tmp9 any; var root_1095 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = seq_1822000134__15; if linked_1096 == nil { tmp9 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp9 = linked_1096.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1095, arg_1098) }; seq_1822000134__10, chunk_1822000135__11, count_1822000136__12, i_1822000137__13 = tmp9, nil, 0, 0; continue L1 } } }
//line :259:1
		break L1 }; var tmp10 any; var root_974 any =









	A_arbace_go_A_const_92.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_976 lang.IFn; if
	linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = t__8; var arg_978 any; var iter__1927001039__auto____10 any; var fnbody__1048 any = A_arbace_go_reify_data_iter__1822000138__1822000142_A_New_O_O(fns__2, ts__1); var tmp11 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1048); A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class = fncls__1047d; tmp11 = fncls__1047d } else { tmp11 = fncls__1047 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1048, tmp11, nil); arg_978 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(names__9); if linked_975 == nil { tmp10 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { tmp10 = linked_975.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; return /*line :269:1*/ lang.RT_Object_array_O__O1_NoInit(tmp10).Ref() }
func A_arbace_go_reify_data_iter__1822000138__1822000142_A_New_O_O(p0, p1 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_A) Ctor_O_O(c__fns, c__ts any) { t.F_fns = c__fns; t.F_ts = c__ts }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_A) Invoke_O_O__O(self, s__1822000139__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1046 any = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_New_O_O_O_O(s__1822000139__1, self, t.F_fns, t.F_ts); var tmp2 *jrt.Class; var fncls__1045 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class; if fncls__1045 == nil { var fncls__1045d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1046); A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class = fncls__1045d; tmp2 = fncls__1045d } else { tmp2 = fncls__1045 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1046, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :270:1
func A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A) Ctor_O_O_O_O(c__s__1822000139, c__iter__1822000138, c__fns, c__ts any) { t.F_s__1822000139 = c__s__1822000139; t.F_iter__1822000138 = c__iter__1822000138; t.F_fns = c__fns; t.F_ts = c__ts }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A) Invoke_O__O(self any) any { { var s__1822000139__1 any; var t_ any = t.F_s__1822000139; t.F_s__1822000139 = nil; s__1822000139__1 = t_; for { var temp__1927000414__auto____2 any; var root_979 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = s__1822000139__1; if linked_980 == nil { temp__1927000414__auto____2 = ifn_981.Invoke_O__O(arg_982) } else { temp__1927000414__auto____2 = linked_980.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_979, arg_982) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000139__3 any = temp__1927000414__auto____2; var tmp1 any; var root_983 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = s__1822000139__3; if linked_984 == nil { tmp1 = ifn_985.Invoke_O__O(arg_986) } else { tmp1 = linked_984.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_983, arg_986) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_987 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = s__1822000139__3; if linked_988 == nil { c__1927001037__auto____4 = ifn_989.Invoke_O__O(arg_990) } else { c__1927001037__auto____4 = linked_988.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_987, arg_990) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000141__6 any; var root_991 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_992 == nil { b__1822000141__6 = ifn_993.Invoke_O__O(arg_994) } else { b__1822000141__6 = linked_992.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_991, arg_994) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1005 any = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_New_O_O_I_O_O(b__1822000141__6, t.F_fns, size__1927001038__auto____5, t.F_ts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1004 *jrt.Class = A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class; if fncls__1004 == nil { var fncls__1004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1005); A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class = fncls__1004d; tmp3 = fncls__1004d } else { tmp3 = fncls__1004 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1005, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1006 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any; var root_1011 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = b__1822000141__6; if linked_1012 == nil { arg_1009 = ifn_1013.Invoke_O__O(arg_1014) } else { arg_1009 = linked_1012.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1011, arg_1014) }; var arg_1010 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000138); var tmp5 any; var root_1015 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = s__1822000139__3; if linked_1016 == nil { tmp5 = ifn_1017.Invoke_O__O(arg_1018) } else { tmp5 = linked_1016.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1015, arg_1018) }; arg_1010 = tmp4.Invoke_O__O(tmp5); if linked_1007 == nil { return ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { return linked_1007.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) } } else { var root_1019 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var root_1024 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = b__1822000141__6; if linked_1025 == nil { arg_1022 = ifn_1026.Invoke_O__O(arg_1027) } else { arg_1022 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1024, arg_1027) }; var arg_1023 any; if linked_1020 == nil { return ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { return linked_1020.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) } } } else { var n__4 any; var root_1028 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = s__1822000139__3; if linked_1029 == nil { n__4 = ifn_1030.Invoke_O__O(arg_1031) } else { n__4 = linked_1029.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1028, arg_1031) }; var root_1032 any = A_arbace_go_A_const_92.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__4)
														if jrt.J2g_Truth(or__1927000174__auto____5) { arg_1035 = or__1927000174__auto____5 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp7 any; var root_1037 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, A_arbace_go_type_names_A_fn_class); var ifn_1039 lang.IFn

		if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = t.F_ts; if linked_1038 == nil { tmp7 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp7 = linked_1038.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1037, arg_1040) }
//line :271:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp7, nil))))) }
//line :270:1
	var arg_1036 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000138); var tmp9 any; var root_1041 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = s__1822000139__3; if linked_1042 == nil { tmp9 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp9 = linked_1042.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1041, arg_1044) }; arg_1036 = tmp8.Invoke_O__O(tmp9); if linked_1033 == nil { return ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { return linked_1033.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A) Ctor_O_O_I_O_O(c__b__1822000141, c__fns any, c__size__1927001038__auto__ int32, c__ts, c__c__1927001037__auto__ any) { t.F_b__1822000141 = c__b__1822000141; t.F_fns = c__fns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ts = c__ts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A) Invoke_O__O(self any) any { { var i__1822000140__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000140__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000140__1)); var root_995 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = t.F_b__1822000141; var arg_999 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__2)
															if jrt.J2g_Truth(or__1927000174__auto____3) { arg_999 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49); var tmp3 any; var root_1000 any = A_arbace_go_A_const_106.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, A_arbace_go_type_names_A_fn_class); var ifn_1002 lang.IFn

		if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = t.F_ts; if linked_1001 == nil { tmp3 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp3 = linked_1001.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_1000, arg_1003) }
//line :271:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp3, nil))))) }
//line :270:1
	if linked_996 == nil { ifn_997.Invoke_O_O__O(arg_998, arg_999) } else { linked_996.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_995, arg_998, arg_999) }; i__1822000140__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000140__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_fn_A_New() *A_arbace_go_repl_fn_A { A_arbace_go_A_Init(); t := &A_arbace_go_repl_fn_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_go_repl_fn_A) Ctor() {}
//line :278:1
func (t *A_arbace_go_repl_fn_A) Invoke_O_O__O(self, nm__0 any) any { var root_1099 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1103 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = Lit_50; var arg_1107 any = nm__0; if linked_1104 == nil { arg_1102 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { arg_1102 = linked_1104.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; if linked_1100 == nil { return ifn_1101.Invoke_O__O(arg_1102) } else { return linked_1100.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_1099, arg_1102) } }

func A_arbace_go_pos_of_A_New() *A_arbace_go_pos_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_pos_of_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_go_pos_of_A) Ctor() {}
//line :280:1
func (t *A_arbace_go_pos_of_A) Invoke_O_O__O(self, form__0 any) any { var root_1108 any = A_arbace_go_A_const_109.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__0); var arg_1112 any = A_arbace_go_A_const_110; if linked_1109 == nil { return ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { return linked_1109.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) } }

func A_arbace_go_package_A_New() *A_arbace_go_package_A { A_arbace_go_A_Init(); t := &A_arbace_go_package_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_package_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_package_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_1113 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1124 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var root_1128 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_111); var arg_1132 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_32); if linked_1129 == nil { arg_1127 = ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { arg_1127 = linked_1129.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; if linked_1125 == nil { tmp3 = ifn_1126.Invoke_O__O(arg_1127) } else { tmp3 = linked_1125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1124, arg_1127) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1133 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any; var root_1137 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1141 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1142 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1144 lang.IFn; if


	linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = A_arbace_go_A_const_114.Get__O(); if linked_1143 == nil { tmp8 = ifn_1144.Invoke_O__O(arg_1145) } else { tmp8 = linked_1143.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1142, arg_1145) }; arg_1141 = /*line :282:1*/tmp7.Invoke_O__O(tmp8); if linked_1138 == nil { arg_1136 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { arg_1136 = linked_1138.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }; if linked_1134 == nil { tmp6 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp6 = linked_1134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1133, arg_1136) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1146 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1150 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1154 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); if linked_1151 == nil { arg_1149 = ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { arg_1149 = linked_1151.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) }; if linked_1147 == nil { tmp11 = ifn_1148.Invoke_O__O(arg_1149) } else { tmp11 = linked_1147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1146, arg_1149) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1155 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var root_1159 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1163 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1164 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1166 lang.IFn; if


	linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = opts__3; if linked_1165 == nil { tmp16 = ifn_1166.Invoke_O__O(arg_1167) } else { tmp16 = linked_1165.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1164, arg_1167) }; arg_1163 = /*line :282:1*/tmp15.Invoke_O__O(tmp16); if linked_1160 == nil { arg_1158 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { arg_1158 = linked_1160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }; if linked_1156 == nil { tmp14 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp14 = linked_1156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1155, arg_1158) }; arg_1116 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1114 == nil { return ifn_1115.Invoke_O__O(arg_1116) } else { return linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) } }




func A_arbace_go_file_A_New() *A_arbace_go_file_A { A_arbace_go_A_Init(); t := &A_arbace_go_file_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_go_file_A) Ctor() {}
//line :287:1
func (t *A_arbace_go_file_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_1168 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1179 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var root_1183 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_115); var arg_1187 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_25); if linked_1184 == nil { arg_1182 = ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { arg_1182 = linked_1184.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) }; if linked_1180 == nil { tmp3 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp3 = linked_1180.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1179, arg_1182) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1188 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any; var root_1192 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1196 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1197 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1199 lang.IFn; if


	linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = A_arbace_go_A_const_114.Get__O(); if linked_1198 == nil { tmp8 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp8 = linked_1198.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1197, arg_1200) }; arg_1196 = /*line :287:1*/tmp7.Invoke_O__O(tmp8); if linked_1193 == nil { arg_1191 = ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { arg_1191 = linked_1193.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) }; if linked_1189 == nil { tmp6 = ifn_1190.Invoke_O__O(arg_1191) } else { tmp6 = linked_1189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1188, arg_1191) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(nm__2); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp12 any; var root_1201 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any; var root_1205 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1209 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1210 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1212 lang.IFn; if


	linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = A_arbace_go_A_const_31.GetRawRoot__O(); var arg_1214 any = opts__3; if linked_1211 == nil { tmp14 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { tmp14 = linked_1211.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; arg_1209 = /*line :287:1*/tmp13.Invoke_O__O(tmp14); if linked_1206 == nil { arg_1204 = ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { arg_1204 = linked_1206.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) }; if linked_1202 == nil { tmp12 = ifn_1203.Invoke_O__O(arg_1204) } else { tmp12 = linked_1202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1201, arg_1204) }; arg_1171 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_1169 == nil { return ifn_1170.Invoke_O__O(arg_1171) } else { return linked_1169.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1168, arg_1171) } }




func A_arbace_go_declare_STAR__A_New() *A_arbace_go_declare_STAR__A { A_arbace_go_A_Init(); t := &A_arbace_go_declare_STAR__A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_declare_STAR__A) Ctor() {}
//line :292:1
func (t *A_arbace_go_declare_STAR__A) Invoke_O_O_O__O(self, form__0, opts__1 any) any {


	var tmp1 any; var root_1215 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, A_arbace_go_repl_fn_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = Lit_8; if linked_1216 == nil { tmp1 = ifn_1217.Invoke_O__O(arg_1218) } else { tmp1 = linked_1216.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1215, arg_1218) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(form__0, opts__1)
}
func A_arbace_go_func_A_New() *A_arbace_go_func_A { A_arbace_go_A_Init(); t := &A_arbace_go_func_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_go_func_A) Ctor() {}
//line :297:1
func (t *A_arbace_go_func_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1219 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_116); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1229 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any; var root_1233 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1237 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1234 == nil { arg_1232 = ifn_1235.Invoke_O_O__O(arg_1236, arg_1237) } else { arg_1232 = linked_1234.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1233, arg_1236, arg_1237) }; if linked_1230 == nil { tmp4 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp4 = linked_1230.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1229, arg_1232) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1238 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any; var root_1242 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1246 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1247 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1249 lang.IFn; if
														linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any; var root_1253 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, A_arbace_go_pos_of_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = _AMPERSAND_form__0; if linked_1254 == nil { arg_1250 = ifn_1255.Invoke_O__O(arg_1256) } else { arg_1250 = linked_1254.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1253, arg_1256) }; var arg_1251 any = A_arbace_go_A_const_118; var arg_1252 any; var root_1257 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_go_A_const_114.Get__O(); if linked_1258 == nil { arg_1252 = ifn_1259.Invoke_O__O(arg_1260) } else { arg_1252 = linked_1258.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1257, arg_1260) }; if linked_1248 == nil { tmp9 = ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { tmp9 = linked_1248.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) }; arg_1246 = /*line :297:1*/tmp8.Invoke_O__O(tmp9); if linked_1243 == nil { arg_1241 = ifn_1244.Invoke_O_O__O(arg_1245, arg_1246) } else { arg_1241 = linked_1243.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1242, arg_1245, arg_1246) }; if linked_1239 == nil { tmp7 = ifn_1240.Invoke_O__O(arg_1241) } else { tmp7 = linked_1239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1238, arg_1241) }; arg_1222 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1220 == nil { return ifn_1221.Invoke_O__O(arg_1222) } else { return linked_1220.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1219, arg_1222) } }


func A_arbace_go_method_A_New() *A_arbace_go_method_A { A_arbace_go_A_Init(); t := &A_arbace_go_method_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_method_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_method_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1261 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_119); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1271 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1275 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1279 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1276 == nil { arg_1274 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { arg_1274 = linked_1276.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) }; if linked_1272 == nil { tmp4 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp4 = linked_1272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1271, arg_1274) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1280 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any; var root_1284 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1288 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1289 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1291 lang.IFn; if
														linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var root_1295 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, A_arbace_go_pos_of_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = _AMPERSAND_form__0; if linked_1296 == nil { arg_1292 = ifn_1297.Invoke_O__O(arg_1298) } else { arg_1292 = linked_1296.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1295, arg_1298) }; var arg_1293 any = A_arbace_go_A_const_118; var arg_1294 any; var root_1299 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = A_arbace_go_A_const_114.Get__O(); if linked_1300 == nil { arg_1294 = ifn_1301.Invoke_O__O(arg_1302) } else { arg_1294 = linked_1300.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1299, arg_1302) }; if linked_1290 == nil { tmp9 = ifn_1291.Invoke_O_O_O__O(arg_1292, arg_1293, arg_1294) } else { tmp9 = linked_1290.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1289, arg_1292, arg_1293, arg_1294) }; arg_1288 = /*line :300:1*/tmp8.Invoke_O__O(tmp9); if linked_1285 == nil { arg_1283 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { arg_1283 = linked_1285.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }; if linked_1281 == nil { tmp7 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp7 = linked_1281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1280, arg_1283) }; arg_1264 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1262 == nil { return ifn_1263.Invoke_O__O(arg_1264) } else { return linked_1262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1261, arg_1264) } }


func A_arbace_go_type_A_New() *A_arbace_go_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_type_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_type_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1303 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_120); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1313 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var root_1317 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1321 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1318 == nil { arg_1316 = ifn_1319.Invoke_O_O__O(arg_1320, arg_1321) } else { arg_1316 = linked_1318.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1317, arg_1320, arg_1321) }; if linked_1314 == nil { tmp4 = ifn_1315.Invoke_O__O(arg_1316) } else { tmp4 = linked_1314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1313, arg_1316) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1322 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any; var root_1326 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1330 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1331 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1333 lang.IFn; if
														linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any; var root_1337 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, A_arbace_go_pos_of_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = _AMPERSAND_form__0; if linked_1338 == nil { arg_1334 = ifn_1339.Invoke_O__O(arg_1340) } else { arg_1334 = linked_1338.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1337, arg_1340) }; var arg_1335 any = A_arbace_go_A_const_118; var arg_1336 any; var root_1341 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = A_arbace_go_A_const_114.Get__O(); if linked_1342 == nil { arg_1336 = ifn_1343.Invoke_O__O(arg_1344) } else { arg_1336 = linked_1342.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1341, arg_1344) }; if linked_1332 == nil { tmp9 = ifn_1333.Invoke_O_O_O__O(arg_1334, arg_1335, arg_1336) } else { tmp9 = linked_1332.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1331, arg_1334, arg_1335, arg_1336) }; arg_1330 = /*line :303:1*/tmp8.Invoke_O__O(tmp9); if linked_1327 == nil { arg_1325 = ifn_1328.Invoke_O_O__O(arg_1329, arg_1330) } else { arg_1325 = linked_1327.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1326, arg_1329, arg_1330) }; if linked_1323 == nil { tmp7 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp7 = linked_1323.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1322, arg_1325) }; arg_1306 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1304 == nil { return ifn_1305.Invoke_O__O(arg_1306) } else { return linked_1304.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1303, arg_1306) } }


func A_arbace_go_var_A_New() *A_arbace_go_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_var_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_go_var_A) Ctor() {}
//line :306:1
func (t *A_arbace_go_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1345 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_121); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1355 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any; var root_1359 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1363 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1360 == nil { arg_1358 = ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { arg_1358 = linked_1360.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) }; if linked_1356 == nil { tmp4 = ifn_1357.Invoke_O__O(arg_1358) } else { tmp4 = linked_1356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1355, arg_1358) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1364 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var root_1368 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1372 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1373 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1375 lang.IFn; if
														linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var root_1379 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, A_arbace_go_pos_of_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = _AMPERSAND_form__0; if linked_1380 == nil { arg_1376 = ifn_1381.Invoke_O__O(arg_1382) } else { arg_1376 = linked_1380.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1379, arg_1382) }; var arg_1377 any = A_arbace_go_A_const_118; var arg_1378 any; var root_1383 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = A_arbace_go_A_const_114.Get__O(); if linked_1384 == nil { arg_1378 = ifn_1385.Invoke_O__O(arg_1386) } else { arg_1378 = linked_1384.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1383, arg_1386) }; if linked_1374 == nil { tmp9 = ifn_1375.Invoke_O_O_O__O(arg_1376, arg_1377, arg_1378) } else { tmp9 = linked_1374.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1373, arg_1376, arg_1377, arg_1378) }; arg_1372 = /*line :306:1*/tmp8.Invoke_O__O(tmp9); if linked_1369 == nil { arg_1367 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { arg_1367 = linked_1369.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) }; if linked_1365 == nil { tmp7 = ifn_1366.Invoke_O__O(arg_1367) } else { tmp7 = linked_1365.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1364, arg_1367) }; arg_1348 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1346 == nil { return ifn_1347.Invoke_O__O(arg_1348) } else { return linked_1346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1345, arg_1348) } }


func A_arbace_go_const_A_New() *A_arbace_go_const_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_go_const_A) Ctor() {}
//line :309:1
func (t *A_arbace_go_const_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1387 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_122); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp4 any; var root_1397 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var root_1401 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1405 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1402 == nil { arg_1400 = ifn_1403.Invoke_O_O__O(arg_1404, arg_1405) } else { arg_1400 = linked_1402.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1401, arg_1404, arg_1405) }; if linked_1398 == nil { tmp4 = ifn_1399.Invoke_O__O(arg_1400) } else { tmp4 = linked_1398.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1397, arg_1400) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp7 any; var root_1406 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any; var root_1410 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1414 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp9 any; var root_1415 any = A_arbace_go_A_const_62.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1417 lang.IFn; if
														linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any; var root_1421 any = A_arbace_go_A_const_117.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, A_arbace_go_pos_of_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = _AMPERSAND_form__0; if linked_1422 == nil { arg_1418 = ifn_1423.Invoke_O__O(arg_1424) } else { arg_1418 = linked_1422.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1421, arg_1424) }; var arg_1419 any = A_arbace_go_A_const_118; var arg_1420 any; var root_1425 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = A_arbace_go_A_const_114.Get__O(); if linked_1426 == nil { arg_1420 = ifn_1427.Invoke_O__O(arg_1428) } else { arg_1420 = linked_1426.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1425, arg_1428) }; if linked_1416 == nil { tmp9 = ifn_1417.Invoke_O_O_O__O(arg_1418, arg_1419, arg_1420) } else { tmp9 = linked_1416.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1415, arg_1418, arg_1419, arg_1420) }; arg_1414 = /*line :309:1*/tmp8.Invoke_O__O(tmp9); if linked_1411 == nil { arg_1409 = ifn_1412.Invoke_O_O__O(arg_1413, arg_1414) } else { arg_1409 = linked_1411.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1410, arg_1413, arg_1414) }; if linked_1407 == nil { tmp7 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp7 = linked_1407.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1406, arg_1409) }; arg_1390 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1388 == nil { return ifn_1389.Invoke_O__O(arg_1390) } else { return linked_1388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1387, arg_1390) } }


func A_arbace_go_directive_A_New() *A_arbace_go_directive_A { A_arbace_go_A_Init(); t := &A_arbace_go_directive_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_go_directive_A) Ctor() {}
//line :312:1
func (t *A_arbace_go_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_go_import_A_New() *A_arbace_go_import_A { A_arbace_go_A_Init(); t := &A_arbace_go_import_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_go_import_A) Ctor() {}
//line :314:1
func (t *A_arbace_go_import_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, specs__2 any) any { var root_1429 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1439 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any; var root_1443 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_123); var arg_1447 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_27); if linked_1444 == nil { arg_1442 = ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { arg_1442 = linked_1444.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) }; if linked_1440 == nil { tmp3 = ifn_1441.Invoke_O__O(arg_1442) } else { tmp3 = linked_1440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1439, arg_1442) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1448 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any; var root_1452 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1456 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1457 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1459 lang.IFn; if


	linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = A_arbace_go_A_const_114.Get__O(); if linked_1458 == nil { tmp8 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp8 = linked_1458.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1457, arg_1460) }; arg_1456 = /*line :314:1*/tmp7.Invoke_O__O(tmp8); if linked_1453 == nil { arg_1451 = ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { arg_1451 = linked_1453.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }; if linked_1449 == nil { tmp6 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp6 = linked_1449.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1448, arg_1451) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1461 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any; var root_1465 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1469 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any; var root_1470 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1472 lang.IFn; if


	linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = specs__2; if linked_1471 == nil { tmp13 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp13 = linked_1471.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1470, arg_1473) }; arg_1469 = /*line :314:1*/tmp12.Invoke_O__O(tmp13); if linked_1466 == nil { arg_1464 = ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { arg_1464 = linked_1466.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) }; if linked_1462 == nil { tmp11 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp11 = linked_1462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1461, arg_1464) }; arg_1432 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1430 == nil { return ifn_1431.Invoke_O__O(arg_1432) } else { return linked_1430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1429, arg_1432) } }




func A_arbace_go_inst_A_New() *A_arbace_go_inst_A { A_arbace_go_A_Init(); t := &A_arbace_go_inst_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_go_inst_A) Ctor() {}
//line :319:1
func (t *A_arbace_go_inst_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, f__2, types__3 any) any { var root_1474 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1485 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any; var root_1489 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_124); var arg_1493 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_28); if linked_1490 == nil { arg_1488 = ifn_1491.Invoke_O_O__O(arg_1492, arg_1493) } else { arg_1488 = linked_1490.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1489, arg_1492, arg_1493) }; if linked_1486 == nil { tmp3 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp3 = linked_1486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1485, arg_1488) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1494 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any; var root_1498 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1502 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1503 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1505 lang.IFn; if







	linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = A_arbace_go_A_const_114.Get__O(); if linked_1504 == nil { tmp8 = ifn_1505.Invoke_O__O(arg_1506) } else { tmp8 = linked_1504.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1503, arg_1506) }; arg_1502 = /*line :319:1*/tmp7.Invoke_O__O(tmp8); if linked_1499 == nil { arg_1497 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { arg_1497 = linked_1499.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }; if linked_1495 == nil { tmp6 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp6 = linked_1495.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1494, arg_1497) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1507 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any; var root_1511 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1515 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1512 == nil { arg_1510 = ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { arg_1510 = linked_1512.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) }; if linked_1508 == nil { tmp11 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp11 = linked_1508.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1507, arg_1510) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp14 any; var root_1516 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any; var root_1520 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1524 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp16 any; var root_1525 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1527 lang.IFn; if







	linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = types__3; if linked_1526 == nil { tmp16 = ifn_1527.Invoke_O__O(arg_1528) } else { tmp16 = linked_1526.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1525, arg_1528) }; arg_1524 = /*line :319:1*/tmp15.Invoke_O__O(tmp16); if linked_1521 == nil { arg_1519 = ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { arg_1519 = linked_1521.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) }; if linked_1517 == nil { tmp14 = ifn_1518.Invoke_O__O(arg_1519) } else { tmp14 = linked_1517.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1516, arg_1519) }; arg_1477 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1475 == nil { return ifn_1476.Invoke_O__O(arg_1477) } else { return linked_1475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1474, arg_1477) } }









func A_arbace_go_eval_A_New() *A_arbace_go_eval_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_eval_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_eval_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, stmts__2 any) any { var root_1529 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp3 any; var root_1539 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any; var root_1543 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_125); var arg_1547 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(Lit_17); if linked_1544 == nil { arg_1542 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { arg_1542 = linked_1544.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; if linked_1540 == nil { tmp3 = ifn_1541.Invoke_O__O(arg_1542) } else { tmp3 = linked_1540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1539, arg_1542) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp6 any; var root_1548 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any; var root_1552 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1556 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp8 any; var root_1557 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1559 lang.IFn; if



	linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = stmts__2; if linked_1558 == nil { tmp8 = ifn_1559.Invoke_O__O(arg_1560) } else { tmp8 = linked_1558.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1557, arg_1560) }; arg_1556 = /*line :329:1*/tmp7.Invoke_O__O(tmp8); if linked_1553 == nil { arg_1551 = ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { arg_1551 = linked_1553.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) }; if linked_1549 == nil { tmp6 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp6 = linked_1549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1548, arg_1551) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp11 any; var root_1561 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var root_1565 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var arg_1569 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_65.GetRawRoot__O()); var tmp13 any = A_arbace_go_A_const_118; var tmp14 any; var root_1570 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1572 lang.IFn; if



	linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = A_arbace_go_A_const_114.Get__O(); if linked_1571 == nil { tmp14 = ifn_1572.Invoke_O__O(arg_1573) } else { tmp14 = linked_1571.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1570, arg_1573) }; arg_1569 = /*line :329:1*/tmp12.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14))); if linked_1566 == nil { arg_1564 = ifn_1567.Invoke_O_O__O(arg_1568, arg_1569) } else { arg_1564 = linked_1566.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1565, arg_1568, arg_1569) }; if linked_1562 == nil { tmp11 = ifn_1563.Invoke_O__O(arg_1564) } else { tmp11 = linked_1562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1561, arg_1564) }; arg_1532 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1530 == nil { return ifn_1531.Invoke_O__O(arg_1532) } else { return linked_1530.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1529, arg_1532) } }





func A_arbace_go_run_main_A_New() *A_arbace_go_run_main_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_main_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_go_run_main_A) Ctor() {}
//line :335:1
func (t *A_arbace_go_run_main_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1574 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_go_repl_fn_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = Lit_52; if linked_1575 == nil { tmp1 = ifn_1576.Invoke_O__O(arg_1577) } else { tmp1 = linked_1575.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1574, arg_1577) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
func A_arbace_go_run_compiled_A_New() *A_arbace_go_run_compiled_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_compiled_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_go_run_compiled_A) Ctor() {}
//line :340:1
func (t *A_arbace_go_run_compiled_A) DoInvoke_O_O_O__O(self, ns_sym__0, args__1 any) any {



	var tmp1 any; var root_1578 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, A_arbace_go_repl_fn_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = Lit_51; if linked_1579 == nil { tmp1 = ifn_1580.Invoke_O__O(arg_1581) } else { tmp1 = linked_1579.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1578, arg_1581) }; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var root_1582 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = args__1; if linked_1583 == nil { tmp3 = ifn_1584.Invoke_O__O(arg_1585) } else { tmp3 = linked_1583.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1582, arg_1585) }; return tmp2.Invoke_O_O__O(ns_sym__0, tmp3)
}
func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_go_check_A) Ctor() {}
//line :346:1
func (t *A_arbace_go_check_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1586 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, A_arbace_go_repl_fn_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = Lit_1; if linked_1587 == nil { tmp1 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp1 = linked_1587.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1586, arg_1589) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
























































































type A_arbace_go_A struct{ jrt.Object }

var A_arbace_go_A_const_pool *jrt.RefArray

var A_arbace_go_A_const_0 *lang.Var

var A_arbace_go_A_const_1 any

var A_arbace_go_A_const_2 *lang.Keyword

var A_arbace_go_A_const_3 any

var A_arbace_go_A_const_4 *lang.Var

var A_arbace_go_A_const_5 *lang.Var

var A_arbace_go_A_const_6 *lang.Var

var A_arbace_go_A_const_7 *lang.Var

var A_arbace_go_A_const_8 any

var A_arbace_go_A_const_9 *lang.Var

var A_arbace_go_A_const_10 *lang.Var

var A_arbace_go_A_const_11 *lang.Var

var A_arbace_go_A_const_12 *lang.Var

var A_arbace_go_A_const_13 *lang.Var

var A_arbace_go_A_const_14 *jrt.Class

var A_arbace_go_A_const_15 *lang.Keyword

var A_arbace_go_A_const_16 *lang.Var

var A_arbace_go_A_const_17 *lang.Var

var A_arbace_go_A_const_18 any

var A_arbace_go_A_const_19 *lang.Keyword

var A_arbace_go_A_const_20 *lang.Keyword

var A_arbace_go_A_const_21 *lang.Var

var A_arbace_go_A_const_22 *lang.Var

var A_arbace_go_A_const_23 *lang.Var

var A_arbace_go_A_const_24 *lang.Var

var A_arbace_go_A_const_25 *lang.Var

var A_arbace_go_A_const_26 *lang.Var

var A_arbace_go_A_const_27 any

var A_arbace_go_A_const_28 *lang.Keyword

var A_arbace_go_A_const_29 *lang.Var

var A_arbace_go_A_const_30 *lang.Var

var A_arbace_go_A_const_31 *lang.Var

var A_arbace_go_A_const_32 *lang.Var

var A_arbace_go_A_const_33 *lang.Var

var A_arbace_go_A_const_34 *lang.Var

var A_arbace_go_A_const_35 any

var A_arbace_go_A_const_36 any

var A_arbace_go_A_const_37 *lang.Var

var A_arbace_go_A_const_38 *lang.Keyword

var A_arbace_go_A_const_39 *lang.Var

var A_arbace_go_A_const_40 any

var A_arbace_go_A_const_41 *lang.Var

var A_arbace_go_A_const_42 *lang.Keyword

var A_arbace_go_A_const_43 *lang.Var

var A_arbace_go_A_const_44 *lang.Var

var A_arbace_go_A_const_45 *lang.Var

var A_arbace_go_A_const_46 *lang.Var

var A_arbace_go_A_const_47 *lang.Var

var A_arbace_go_A_const_48 *lang.Var

var A_arbace_go_A_const_49 *lang.Var

var A_arbace_go_A_const_50 any

var A_arbace_go_A_const_51 *lang.Var

var A_arbace_go_A_const_52 *lang.Var

var A_arbace_go_A_const_53 *lang.Var

var A_arbace_go_A_const_54 *lang.Var

var A_arbace_go_A_const_55 *lang.Var

var A_arbace_go_A_const_56 *lang.Var

var A_arbace_go_A_const_57 *lang.Var

var A_arbace_go_A_const_58 *lang.Var

var A_arbace_go_A_const_59 any

var A_arbace_go_A_const_60 *lang.Keyword

var A_arbace_go_A_const_61 any

var A_arbace_go_A_const_62 *lang.Var

var A_arbace_go_A_const_63 *lang.Keyword

var A_arbace_go_A_const_64 *lang.Keyword

var A_arbace_go_A_const_65 *lang.Var

var A_arbace_go_A_const_66 *lang.Keyword

var A_arbace_go_A_const_67 *lang.Var

var A_arbace_go_A_const_68 *lang.Keyword

var A_arbace_go_A_const_69 *lang.Var

var A_arbace_go_A_const_70 *lang.Keyword

var A_arbace_go_A_const_71 *lang.Keyword

var A_arbace_go_A_const_72 *lang.Var

var A_arbace_go_A_const_73 *lang.Keyword

var A_arbace_go_A_const_74 *lang.Keyword

var A_arbace_go_A_const_75 *lang.Var

var A_arbace_go_A_const_76 *lang.Var

var A_arbace_go_A_const_77 *lang.Keyword

var A_arbace_go_A_const_78 *lang.Keyword

var A_arbace_go_A_const_79 *lang.Keyword

var A_arbace_go_A_const_80 *lang.Keyword

var A_arbace_go_A_const_81 *lang.Var

var A_arbace_go_A_const_82 *lang.Var

var A_arbace_go_A_const_83 *lang.Var

var A_arbace_go_A_const_84 *lang.Var

var A_arbace_go_A_const_85 *lang.Var

var A_arbace_go_A_const_86 *lang.Var

var A_arbace_go_A_const_87 *lang.Var

var A_arbace_go_A_const_88 *lang.Var

var A_arbace_go_A_const_89 *lang.Var

var A_arbace_go_A_const_90 *lang.Var

var A_arbace_go_A_const_91 *lang.Var

var A_arbace_go_A_const_92 *lang.Var

var A_arbace_go_A_const_93 *lang.Var

var A_arbace_go_A_const_94 *lang.Var

var A_arbace_go_A_const_95 *lang.Var

var A_arbace_go_A_const_96 any

var A_arbace_go_A_const_97 *lang.Var

var A_arbace_go_A_const_98 *lang.Var

var A_arbace_go_A_const_99 *lang.Var

var A_arbace_go_A_const_100 *lang.Var

var A_arbace_go_A_const_101 *lang.Var

var A_arbace_go_A_const_102 *lang.Var

var A_arbace_go_A_const_103 *lang.Var

var A_arbace_go_A_const_104 *lang.Var

var A_arbace_go_A_const_105 *lang.Var

var A_arbace_go_A_const_106 *lang.Var

var A_arbace_go_A_const_107 *lang.Var

var A_arbace_go_A_const_108 *lang.Var

var A_arbace_go_A_const_109 *lang.Var

var A_arbace_go_A_const_110 any

var A_arbace_go_A_const_111 any

var A_arbace_go_A_const_112 any

var A_arbace_go_A_const_113 *lang.Var

var A_arbace_go_A_const_114 *lang.Var

var A_arbace_go_A_const_115 any

var A_arbace_go_A_const_116 any

var A_arbace_go_A_const_117 *lang.Var

var A_arbace_go_A_const_118 *lang.Keyword

var A_arbace_go_A_const_119 any

var A_arbace_go_A_const_120 any

var A_arbace_go_A_const_121 any

var A_arbace_go_A_const_122 any

var A_arbace_go_A_const_123 any

var A_arbace_go_A_const_124 any

var A_arbace_go_A_const_125 any

var A_arbace_go_A_init jrt.ClassInit

func A_arbace_go_A_Init() { if !A_arbace_go_A_init.Done() { A_arbace_go_A_init.Run(A_arbace_go_A_clinit) } }

func A_arbace_go_A_clinit() { A_arbace_go_A_clinit_p0(); A_arbace_go_A_clinit_p1(); A_arbace_go_A_clinit_p2(); A_arbace_go_A_clinit_p3(); A_arbace_go_A_clinit_p4(); A_arbace_go_A_clinit_p5(); A_arbace_go_A_clinit_p6(); A_arbace_go_A_clinit_p7(); A_arbace_go_A_clinit_p8(); A_arbace_go_A_clinit_p9(); A_arbace_go_A_clinit_p10() }

func A_arbace_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_go_A_const_0 = lang.Var_Cast(A_arbace_go_A_const_pool.A[37]); A_arbace_go_A_const_1 = A_arbace_go_A_const_pool.A[38]; A_arbace_go_A_const_2 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[39]); A_arbace_go_A_const_3 = A_arbace_go_A_const_pool.A[40]; A_arbace_go_A_const_4 = lang.Var_Cast(A_arbace_go_A_const_pool.A[41]); A_arbace_go_A_const_5 = lang.Var_Cast(A_arbace_go_A_const_pool.A[42]); A_arbace_go_A_const_6 = lang.Var_Cast(A_arbace_go_A_const_pool.A[43]); A_arbace_go_A_const_7 = lang.Var_Cast(A_arbace_go_A_const_pool.A[44]); A_arbace_go_A_const_8 = A_arbace_go_A_const_pool.A[45]; A_arbace_go_A_const_9 = lang.Var_Cast(A_arbace_go_A_const_pool.A[46]); A_arbace_go_A_const_10 = lang.Var_Cast(A_arbace_go_A_const_pool.A[47]); A_arbace_go_A_const_11 = lang.Var_Cast(A_arbace_go_A_const_pool.A[48]) }

func A_arbace_go_A_clinit_p1() { A_arbace_go_A_const_12 = lang.Var_Cast(A_arbace_go_A_const_pool.A[49]); A_arbace_go_A_const_13 = lang.Var_Cast(A_arbace_go_A_const_pool.A[50]); A_arbace_go_A_const_14 = jrt.Class_Cast(A_arbace_go_A_const_pool.A[51]); A_arbace_go_A_const_15 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[52]); A_arbace_go_A_const_16 = lang.Var_Cast(A_arbace_go_A_const_pool.A[53]); A_arbace_go_A_const_17 = lang.Var_Cast(A_arbace_go_A_const_pool.A[54]); A_arbace_go_A_const_18 = A_arbace_go_A_const_pool.A[55]; A_arbace_go_A_const_19 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[56]); A_arbace_go_A_const_20 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[57]); A_arbace_go_A_const_21 = lang.Var_Cast(A_arbace_go_A_const_pool.A[58]); A_arbace_go_A_const_22 = lang.Var_Cast(A_arbace_go_A_const_pool.A[59]); A_arbace_go_A_const_23 = lang.Var_Cast(A_arbace_go_A_const_pool.A[60]) }

func A_arbace_go_A_clinit_p2() { A_arbace_go_A_const_24 = lang.Var_Cast(A_arbace_go_A_const_pool.A[61]); A_arbace_go_A_const_25 = lang.Var_Cast(A_arbace_go_A_const_pool.A[62]); A_arbace_go_A_const_26 = lang.Var_Cast(A_arbace_go_A_const_pool.A[63]); A_arbace_go_A_const_27 = A_arbace_go_A_const_pool.A[64]; A_arbace_go_A_const_28 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[65]); A_arbace_go_A_const_29 = lang.Var_Cast(A_arbace_go_A_const_pool.A[66]); A_arbace_go_A_const_30 = lang.Var_Cast(A_arbace_go_A_const_pool.A[67]); A_arbace_go_A_const_31 = lang.Var_Cast(A_arbace_go_A_const_pool.A[68]); A_arbace_go_A_const_32 = lang.Var_Cast(A_arbace_go_A_const_pool.A[69]); A_arbace_go_A_const_33 = lang.Var_Cast(A_arbace_go_A_const_pool.A[70]); A_arbace_go_A_const_34 = lang.Var_Cast(A_arbace_go_A_const_pool.A[71]); A_arbace_go_A_const_35 = A_arbace_go_A_const_pool.A[72] }

func A_arbace_go_A_clinit_p3() { A_arbace_go_A_const_36 = A_arbace_go_A_const_pool.A[73]; A_arbace_go_A_const_37 = lang.Var_Cast(A_arbace_go_A_const_pool.A[74]); A_arbace_go_A_const_38 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[75]); A_arbace_go_A_const_39 = lang.Var_Cast(A_arbace_go_A_const_pool.A[76]); A_arbace_go_A_const_40 = A_arbace_go_A_const_pool.A[77]; A_arbace_go_A_const_41 = lang.Var_Cast(A_arbace_go_A_const_pool.A[78]); A_arbace_go_A_const_42 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[79]); A_arbace_go_A_const_43 = lang.Var_Cast(A_arbace_go_A_const_pool.A[80]); A_arbace_go_A_const_44 = lang.Var_Cast(A_arbace_go_A_const_pool.A[81]); A_arbace_go_A_const_45 = lang.Var_Cast(A_arbace_go_A_const_pool.A[82]); A_arbace_go_A_const_46 = lang.Var_Cast(A_arbace_go_A_const_pool.A[83]); A_arbace_go_A_const_47 = lang.Var_Cast(A_arbace_go_A_const_pool.A[84]) }

func A_arbace_go_A_clinit_p4() { A_arbace_go_A_const_48 = lang.Var_Cast(A_arbace_go_A_const_pool.A[85]); A_arbace_go_A_const_49 = lang.Var_Cast(A_arbace_go_A_const_pool.A[86]); A_arbace_go_A_const_50 = A_arbace_go_A_const_pool.A[87]; A_arbace_go_A_const_51 = lang.Var_Cast(A_arbace_go_A_const_pool.A[88]); A_arbace_go_A_const_52 = lang.Var_Cast(A_arbace_go_A_const_pool.A[89]); A_arbace_go_A_const_53 = lang.Var_Cast(A_arbace_go_A_const_pool.A[90]); A_arbace_go_A_const_54 = lang.Var_Cast(A_arbace_go_A_const_pool.A[91]); A_arbace_go_A_const_55 = lang.Var_Cast(A_arbace_go_A_const_pool.A[92]); A_arbace_go_A_const_56 = lang.Var_Cast(A_arbace_go_A_const_pool.A[93]); A_arbace_go_A_const_57 = lang.Var_Cast(A_arbace_go_A_const_pool.A[94]); A_arbace_go_A_const_58 = lang.Var_Cast(A_arbace_go_A_const_pool.A[95]); A_arbace_go_A_const_59 = A_arbace_go_A_const_pool.A[96] }

func A_arbace_go_A_clinit_p5() { A_arbace_go_A_const_60 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[97]); A_arbace_go_A_const_61 = A_arbace_go_A_const_pool.A[98]; A_arbace_go_A_const_62 = lang.Var_Cast(A_arbace_go_A_const_pool.A[99]); A_arbace_go_A_const_63 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[100]); A_arbace_go_A_const_64 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[101]); A_arbace_go_A_const_65 = lang.Var_Cast(A_arbace_go_A_const_pool.A[102]); A_arbace_go_A_const_66 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[103]); A_arbace_go_A_const_67 = lang.Var_Cast(A_arbace_go_A_const_pool.A[104]); A_arbace_go_A_const_68 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[105]); A_arbace_go_A_const_69 = lang.Var_Cast(A_arbace_go_A_const_pool.A[106]); A_arbace_go_A_const_70 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[107]); A_arbace_go_A_const_71 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[108]) }

func A_arbace_go_A_clinit_p6() { A_arbace_go_A_const_72 = lang.Var_Cast(A_arbace_go_A_const_pool.A[109]); A_arbace_go_A_const_73 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[110]); A_arbace_go_A_const_74 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[111]); A_arbace_go_A_const_75 = lang.Var_Cast(A_arbace_go_A_const_pool.A[112]); A_arbace_go_A_const_76 = lang.Var_Cast(A_arbace_go_A_const_pool.A[113]); A_arbace_go_A_const_77 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[114]); A_arbace_go_A_const_78 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[115]); A_arbace_go_A_const_79 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[116]); A_arbace_go_A_const_80 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[117]); A_arbace_go_A_const_81 = lang.Var_Cast(A_arbace_go_A_const_pool.A[118]); A_arbace_go_A_const_82 = lang.Var_Cast(A_arbace_go_A_const_pool.A[119]); A_arbace_go_A_const_83 = lang.Var_Cast(A_arbace_go_A_const_pool.A[120]) }

func A_arbace_go_A_clinit_p7() { A_arbace_go_A_const_84 = lang.Var_Cast(A_arbace_go_A_const_pool.A[121]); A_arbace_go_A_const_85 = lang.Var_Cast(A_arbace_go_A_const_pool.A[122]); A_arbace_go_A_const_86 = lang.Var_Cast(A_arbace_go_A_const_pool.A[123]); A_arbace_go_A_const_87 = lang.Var_Cast(A_arbace_go_A_const_pool.A[124]); A_arbace_go_A_const_88 = lang.Var_Cast(A_arbace_go_A_const_pool.A[125]); A_arbace_go_A_const_89 = lang.Var_Cast(A_arbace_go_A_const_pool.A[126]); A_arbace_go_A_const_90 = lang.Var_Cast(A_arbace_go_A_const_pool.A[127]); A_arbace_go_A_const_91 = lang.Var_Cast(A_arbace_go_A_const_pool.A[128]); A_arbace_go_A_const_92 = lang.Var_Cast(A_arbace_go_A_const_pool.A[129]); A_arbace_go_A_const_93 = lang.Var_Cast(A_arbace_go_A_const_pool.A[130]); A_arbace_go_A_const_94 = lang.Var_Cast(A_arbace_go_A_const_pool.A[131]); A_arbace_go_A_const_95 = lang.Var_Cast(A_arbace_go_A_const_pool.A[132]) }

func A_arbace_go_A_clinit_p8() { A_arbace_go_A_const_96 = A_arbace_go_A_const_pool.A[133]; A_arbace_go_A_const_97 = lang.Var_Cast(A_arbace_go_A_const_pool.A[134]); A_arbace_go_A_const_98 = lang.Var_Cast(A_arbace_go_A_const_pool.A[135]); A_arbace_go_A_const_99 = lang.Var_Cast(A_arbace_go_A_const_pool.A[136]); A_arbace_go_A_const_100 = lang.Var_Cast(A_arbace_go_A_const_pool.A[137]); A_arbace_go_A_const_101 = lang.Var_Cast(A_arbace_go_A_const_pool.A[138]); A_arbace_go_A_const_102 = lang.Var_Cast(A_arbace_go_A_const_pool.A[139]); A_arbace_go_A_const_103 = lang.Var_Cast(A_arbace_go_A_const_pool.A[140]); A_arbace_go_A_const_104 = lang.Var_Cast(A_arbace_go_A_const_pool.A[141]); A_arbace_go_A_const_105 = lang.Var_Cast(A_arbace_go_A_const_pool.A[142]); A_arbace_go_A_const_106 = lang.Var_Cast(A_arbace_go_A_const_pool.A[143]); A_arbace_go_A_const_107 = lang.Var_Cast(A_arbace_go_A_const_pool.A[144]) }

func A_arbace_go_A_clinit_p9() { A_arbace_go_A_const_108 = lang.Var_Cast(A_arbace_go_A_const_pool.A[145]); A_arbace_go_A_const_109 = lang.Var_Cast(A_arbace_go_A_const_pool.A[146]); A_arbace_go_A_const_110 = A_arbace_go_A_const_pool.A[147]; A_arbace_go_A_const_111 = A_arbace_go_A_const_pool.A[148]; A_arbace_go_A_const_112 = A_arbace_go_A_const_pool.A[149]; A_arbace_go_A_const_113 = lang.Var_Cast(A_arbace_go_A_const_pool.A[150]); A_arbace_go_A_const_114 = lang.Var_Cast(A_arbace_go_A_const_pool.A[151]); A_arbace_go_A_const_115 = A_arbace_go_A_const_pool.A[152]; A_arbace_go_A_const_116 = A_arbace_go_A_const_pool.A[153]; A_arbace_go_A_const_117 = lang.Var_Cast(A_arbace_go_A_const_pool.A[154]); A_arbace_go_A_const_118 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[155]); A_arbace_go_A_const_119 = A_arbace_go_A_const_pool.A[156]; A_arbace_go_A_const_120 = A_arbace_go_A_const_pool.A[157]; A_arbace_go_A_const_121 = A_arbace_go_A_const_pool.A[158] }

func A_arbace_go_A_clinit_p10() { A_arbace_go_A_const_122 = A_arbace_go_A_const_pool.A[159]; A_arbace_go_A_const_123 = A_arbace_go_A_const_pool.A[160]; A_arbace_go_A_const_124 = A_arbace_go_A_const_pool.A[161]; A_arbace_go_A_const_125 = A_arbace_go_A_const_pool.A[162] }

func A_arbace_go_A_New() *A_arbace_go_A { A_arbace_go_A_Init(); t := &A_arbace_go_A{}; t.Ctor(); return t }

func (t *A_arbace_go_A) Ctor() {}

func (t *A_arbace_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_A) GetClass__Class() *jrt.Class { return A_arbace_go_A_class }

func (t *A_arbace_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_A); return ok }

func A_arbace_go_A_Cast(x any) *A_arbace_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_A_class)) }; return v }



type A_arbace_go_assign_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_assign_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_A struct{ j2g_header uint64 }

var A_arbace_go_check_A_fn_class *jrt.Class



type A_arbace_go_const_A struct{ j2g_header uint64 }

var A_arbace_go_const_A_fn_class *jrt.Class



type A_arbace_go_const_value_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_A_fn_class *jrt.Class



type A_arbace_go_const_value_fn__1822000029_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_fn__1822000029_A_fn_class *jrt.Class



type A_arbace_go_declare_STAR__A struct{ j2g_header uint64 }

var A_arbace_go_declare_STAR__A_fn_class *jrt.Class



type A_arbace_go_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_digest_info_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_A_fn_class *jrt.Class



type A_arbace_go_digest_info_fn__1822000032_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_fn__1822000032_A_fn_class *jrt.Class



type A_arbace_go_directive_A struct{ j2g_header uint64 }

var A_arbace_go_directive_A_fn_class *jrt.Class



type A_arbace_go_eval_A struct{ j2g_header uint64 }

var A_arbace_go_eval_A_fn_class *jrt.Class



type A_arbace_go_eval1822000004_A struct{ jrt.Object }

func A_arbace_go_eval1822000004_A_New() *A_arbace_go_eval1822000004_A { t := &A_arbace_go_eval1822000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000004_A) Ctor() {}

func (t *A_arbace_go_eval1822000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000004_A_class }

func (t *A_arbace_go_eval1822000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000004_A); return ok }

func A_arbace_go_eval1822000004_A_Cast(x any) *A_arbace_go_eval1822000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000004_A_class)) }; return v }



type A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class *jrt.Class



type A_arbace_go_eval1822000008_A struct{ jrt.Object }

func A_arbace_go_eval1822000008_A_New() *A_arbace_go_eval1822000008_A { t := &A_arbace_go_eval1822000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000008_A) Ctor() {}

func (t *A_arbace_go_eval1822000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000008_A_class }

func (t *A_arbace_go_eval1822000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000008_A); return ok }

func A_arbace_go_eval1822000008_A_Cast(x any) *A_arbace_go_eval1822000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000008_A_class)) }; return v }



type A_arbace_go_eval1822000008_fn__1822000009_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000008_fn__1822000009_A_fn_class *jrt.Class



type A_arbace_go_file_A struct{ j2g_header uint64 }

var A_arbace_go_file_A_fn_class *jrt.Class



type A_arbace_go_fn__1822000016_A struct{ j2g_header uint64 }

var A_arbace_go_fn__1822000016_A_fn_class *jrt.Class



type A_arbace_go_func_A struct{ j2g_header uint64 }

var A_arbace_go_func_A_fn_class *jrt.Class



type A_arbace_go_import_A struct{ j2g_header uint64 }

var A_arbace_go_import_A_fn_class *jrt.Class



type A_arbace_go_inst_A struct{ j2g_header uint64 }

var A_arbace_go_inst_A_fn_class *jrt.Class



type A_arbace_go_interpretable_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_interpretable_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_member_var_A struct{ j2g_header uint64 }

var A_arbace_go_member_var_A_fn_class *jrt.Class



type A_arbace_go_method_A struct{ j2g_header uint64 }

var A_arbace_go_method_A_fn_class *jrt.Class



type A_arbace_go_new_A struct{ j2g_header uint64 }

var A_arbace_go_new_A_fn_class *jrt.Class



type A_arbace_go_package_A struct{ j2g_header uint64 }

var A_arbace_go_package_A_fn_class *jrt.Class



type A_arbace_go_packages_A struct{ j2g_header uint64 }

var A_arbace_go_packages_A_fn_class *jrt.Class



type A_arbace_go_params_of_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_A_fn_class *jrt.Class



type A_arbace_go_params_of_fn__1822000024_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_fn__1822000024_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_fn__1822000013_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class *jrt.Class



type A_arbace_go_pos_of_A struct{ j2g_header uint64 }

var A_arbace_go_pos_of_A_fn_class *jrt.Class



type A_arbace_go_reify_data_A struct{ j2g_header uint64 }

var A_arbace_go_reify_data_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_A struct{ j2g_header uint64; F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A struct{ j2g_header uint64; F_s__1822000139, F_iter__1822000138, F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A struct{ j2g_header uint64; F_b__1822000141, F_fns any; F_size__1927001038__auto__ int32; F_ts, F_c__1927001037__auto__ any }

var A_arbace_go_reify_data_iter__1822000138__1822000142_fn__1822000143_fn__1822000144_A_fn_class *jrt.Class



type A_arbace_go_reify_type_A struct{ j2g_header uint64 }

var A_arbace_go_reify_type_A_fn_class *jrt.Class



type A_arbace_go_repl_fn_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn_A_fn_class *jrt.Class



type A_arbace_go_run_compiled_A struct{ j2g_header uint64 }

var A_arbace_go_run_compiled_A_fn_class *jrt.Class



type A_arbace_go_run_main_A struct{ j2g_header uint64 }

var A_arbace_go_run_main_A_fn_class *jrt.Class



type A_arbace_go_spread_A struct{ j2g_header uint64 }

var A_arbace_go_spread_A_fn_class *jrt.Class



type A_arbace_go_str_A struct{ j2g_header uint64 }

var A_arbace_go_str_A_fn_class *jrt.Class



type A_arbace_go_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_go_strip_doc_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000082_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_table_ns_BANG__fn__1822000082_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_A struct{ j2g_header uint64; F_info, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000084_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A struct{ j2g_header uint64; F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A struct{ j2g_header uint64; F_members, F_s__1822000086, F_iter__1822000085 any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A struct{ j2g_header uint64; F_b__1822000088, F_members any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__fn__1822000084_iter__1822000085__1822000089_fn__1822000090_fn__1822000091_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A struct{ j2g_header uint64; F_ns any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A struct{ j2g_header uint64; F_ns, F_s__1822000051, F_iter__1822000050 any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A struct{ j2g_header uint64; F_b__1822000053, F_ns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000050__1822000054_fn__1822000055_fn__1822000056_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A struct{ j2g_header uint64; F_s__1822000067, F_iter__1822000066 any }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A struct{ j2g_header uint64; F_b__1822000069 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000066__1822000070_fn__1822000071_fn__1822000072_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__make__1822000102_A struct{ j2g_header uint64; F_ns, F_info, F_consts, F_p, F_members any }

var A_arbace_go_table_ns_BANG__make__1822000102_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__resolver__1822000107_A struct{ j2g_header uint64; F_make, F_consts, F_members any }

var A_arbace_go_table_ns_BANG__resolver__1822000107_A_fn_class *jrt.Class



type A_arbace_go_type_A struct{ j2g_header uint64 }

var A_arbace_go_type_A_fn_class *jrt.Class



type A_arbace_go_type_names_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_A_fn_class *jrt.Class



type A_arbace_go_type_names_fn__1822000127_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_fn__1822000127_A_fn_class *jrt.Class



type A_arbace_go_type_of_A struct{ j2g_header uint64 }

var A_arbace_go_type_of_A_fn_class *jrt.Class



type A_arbace_go_var_A struct{ j2g_header uint64 }

var A_arbace_go_var_A_fn_class *jrt.Class



type A_arbace_go_zero_A struct{ j2g_header uint64 }

var A_arbace_go_zero_A_fn_class *jrt.Class
