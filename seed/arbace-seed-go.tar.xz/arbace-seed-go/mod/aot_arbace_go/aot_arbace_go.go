//line aot_arbace_go.ae:1
package aot_arbace_go

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_New() *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_A_const_1, A_arbace_go_A_const_2, A_arbace_go_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_eval1822000008_fn__1822000009_A_New() *A_arbace_go_eval1822000008_fn__1822000009_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval1822000008_fn__1822000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_eval1822000008_fn__1822000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_go_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_A_const_7.GetRawRoot__O(), A_arbace_go_A_const_8) }
















































func A_arbace_go_path__GT_ns_A_New() *A_arbace_go_path__GT_ns_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {



	var root_17 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil); var tmp2 any; var root_21 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_25 any; var root_26 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = Lit_12; var arg_30 any; var root_31 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp3 any = A_arbace_go_path__GT_ns_fn__1822000013_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; arg_34 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *jrt.Class = A_arbace_go_A_const_14; var arg_35 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p__0, tmp5, Lit_34, jrt.RefArrayOf(jrt.Object_class, Lit_35)); if linked_32 == nil { arg_30 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { arg_30 = linked_32.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_17, arg_20) } }
//line :54:1
func A_arbace_go_path__GT_ns_fn__1822000013_A_New() *A_arbace_go_path__GT_ns_fn__1822000013_A { A_arbace_go_A_Init(); t := &A_arbace_go_path__GT_ns_fn__1822000013_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Ctor() {}
//line :54:1
func (t *A_arbace_go_path__GT_ns_fn__1822000013_A) Invoke_O_O__O(self, p1__1822000012_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_go_A_const_14; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1822000012_SHARP___1, tmp1, Lit_36, jrt.RefArrayOf(jrt.Object_class, Lit_37, Lit_38)) }


func A_arbace_go_fn__1822000016_A_New() *A_arbace_go_fn__1822000016_A { A_arbace_go_A_Init(); t := &A_arbace_go_fn__1822000016_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_fn__1822000016_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_26); var tmp1 any = A_arbace_go_A_const_15; var tmp2 any; var root_37 any = A_arbace_go_A_const_16.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_39 lang.IFn

		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__2; var arg_45 any = A_arbace_go_A_const_18; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_37, arg_40) }
//line :58:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_A_const_19; var tmp5 any = A_arbace_go_A_const_20; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_digest_forms_A_New() *A_arbace_go_digest_forms_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_forms_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_digest_forms_A) Ctor() {}
//line :62:1
func (t *A_arbace_go_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_47 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_49 lang.IFn; if



	linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_A_const_21.GetRawRoot__O(); if linked_48 == nil { temp__1927000414__auto____2 = ifn_49.Invoke_O__O(arg_50) } else { temp__1927000414__auto____2 = linked_48.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__1822000018__3 any = temp__1927000414__auto____2; var map__1822000018__4 any; if lang.ISeq_InstanceOf(map__1822000018__3) { var tmp1 any; var root_51 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = map__1822000018__3; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_55 any = A_arbace_go_A_const_23.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = map__1822000018__3; if linked_56 == nil { tmp2 = ifn_57.Invoke_O__O(arg_58) } else { tmp2 = linked_56.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_55, arg_58) }; map__1822000018__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_59 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = map__1822000018__3; if linked_60 == nil { tmp3 = ifn_61.Invoke_O__O(arg_62) } else { tmp3 = linked_60.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_59, arg_62) }; if jrt.J2g_Truth(tmp3) { var root_63 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = map__1822000018__3; if linked_64 == nil { map__1822000018__4 = ifn_65.Invoke_O__O(arg_66) } else { map__1822000018__4 = linked_64.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_63, arg_66) } } else { map__1822000018__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1822000018__4 = map__1822000018__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_15); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_19); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__1822000018__4, A_arbace_go_A_const_20); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__1822000020__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000020__9, lang.RT_IntCast_J__I_NoInit(1), nil); var r__12 any; var tmp4 any; var root_67 any = A_arbace_go_A_const_17.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_69 lang.IFn
			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = text__6; var arg_71 any; var na_73 any = start__7; var na_74 any = a__10; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_73); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_74) }; tmp5 = tmp6; if tmp5 { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); var n1_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var nr_77 int64 = n0_75 + n1_76; if (n0_75^nr_77)&(n1_76^nr_77) >= 0 { arg_71 = jrt.Long_ValueOf_J__Long_NoInit(nr_77).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_73); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_74) }; tmp7 = tmp8; if tmp7 { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); var n1_76_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); arg_71 = jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + n1_76_2).Ref() } else { arg_71 = lang.Numbers_Add_O_O__Number_NoInit(na_73, na_74) } }; var arg_72 any; var na_78 any = start__7; var na_79 any = b__11; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_78); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_79) }; tmp9 = tmp10; if tmp9 { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var nr_82 int64 = n0_80 + n1_81; if (n0_80^nr_82)&(n1_81^nr_82) >= 0 { arg_72 = jrt.Long_ValueOf_J__Long_NoInit(nr_82).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_78); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_79) }; tmp11 = tmp12; if tmp11 { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); arg_72 = jrt.Double_ValueOf_D__Double_NoInit(n0_80_2 + n1_81_2).Ref() } else { arg_72 = lang.Numbers_Add_O_O__Number_NoInit(na_78, na_79) } }; if linked_68 == nil { tmp4 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { tmp4 = linked_68.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72) }
//line :67:1
			r__12 = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(tmp4)))

			var root_91 any = A_arbace_go_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_A_const_32, jrt.Boolean_FALSE.Ref()); if linked_92 == nil { ifn_93.Invoke_O__O(arg_94) } else { linked_92.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_91, arg_94) }
//line :67:1
			var tmp13 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__15 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__16 any; var root_83 any = A_arbace_go_A_const_26.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_85 lang.IFn



				if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_go_A_const_27; var arg_87 any = r__12; if linked_84 == nil { f__16 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { f__16 = linked_84.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }
				if lang.Util_Equiv_O_O__Z_NoInit(f__16, A_arbace_go_A_const_28) { tmp13 = acc__15 } else { var tmp14 any; var root_100 any = A_arbace_go_A_const_7.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = acc__15; var arg_104 any = f__16; if linked_101 == nil { tmp14 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp14 = linked_101.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; acc__15 = tmp14; continue L1 }
//line :67:1
				break L1 } }; return nil }(); var root_88 any = A_arbace_go_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_90 lang.IFn

			if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; if linked_89 == nil { ifn_90.Invoke__O() } else { linked_89.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_88) }
//line :67:1
			if tmp15 != nil { panic(tmp15) }; return tmp13 } else { return nil } } else {
//line :66:1
				return nil } }







func A_arbace_go_params_of_A_New() *A_arbace_go_params_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_params_of_A) Ctor() {}
//line :74:1
func (t *A_arbace_go_params_of_A) Invoke_O_O__O(self, pv__0 any) any {


	var root_105 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_go_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp1 any = A_arbace_go_params_of_fn__1822000024_A_New(); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_params_of_fn__1822000024_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_params_of_fn__1822000024_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_113 any = pv__0; if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_105, arg_108) } }
//line :77:1
func A_arbace_go_params_of_fn__1822000024_A_New() *A_arbace_go_params_of_fn__1822000024_A { A_arbace_go_A_Init(); t := &A_arbace_go_params_of_fn__1822000024_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Ctor() {}
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, x__2) } else {
												if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_114 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_116 lang.IFn

		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__2; if linked_115 == nil { and__1927000168__auto____3 = ifn_116.Invoke_O__O(arg_117) } else { and__1927000168__auto____3 = linked_115.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_118 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_go_A_const_40; var arg_122 any = x__2; if linked_119 == nil { tmp1 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_118, arg_121, arg_122) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_123 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = x__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_127, arg_130) }; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_123, arg_126) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_131 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp4 jrt.Number_I; var na_135 any = i__1; if jrt.Long_InstanceOf(na_135) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); if n0_136 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_136 + 1)) } } else { if jrt.Double_InstanceOf(na_135) { var n0_136_2 float64 = jrt.NN(jrt.Double_Cast(na_135)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_136_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_135) } }; arg_134 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_132 == nil { return ifn_133.Invoke_O__O(arg_134) } else { return linked_132.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_131, arg_134) } } else {
//line :78:1
						return nil } } } } }
//line :77:1
func (t *A_arbace_go_params_of_fn__1822000024_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, x__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_35, x__2) { return A_arbace_go_A_const_36 } else { var tmp1 any; var and__1927000168__auto____3 any; var root_137 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_139 lang.IFn

		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = x__2; if linked_138 == nil { and__1927000168__auto____3 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____3 = linked_138.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 *lang.Keyword = A_arbace_go_A_const_38; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_141 any = A_arbace_go_A_const_39.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_go_A_const_40; var arg_145 any = x__2; if linked_142 == nil { tmp1 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :78:1
		if jrt.J2g_Truth(tmp1) {

			var root_146 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_150 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = x__2; if linked_151 == nil { arg_149 = ifn_152.Invoke_O__O(arg_153) } else { arg_149 = linked_151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_150, arg_153) }; if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_146, arg_149) } } else {
//line :78:1
				if A_arbace_go_A_const_42 != nil {


					var root_154 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp4 jrt.Number_I; var n0_158 int64 = i__1_l; if n0_158 == 9223372036854775807 { var tmp5 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp5 = i__1_b } else { tmp5 = i__1_b }; tmp4 = lang.Numbers_Inc_O__Number_NoInit(tmp5) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_158 + 1)) }; arg_157 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_155 == nil { return ifn_156.Invoke_O__O(arg_157) } else { return linked_155.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_154, arg_157) } } else {
//line :78:1
						return nil
					}
			}
	}
}

func A_arbace_go_strip_doc_A_New() *A_arbace_go_strip_doc_A { A_arbace_go_A_Init(); t := &A_arbace_go_strip_doc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_go_strip_doc_A) Ctor() {}
//line :84:1
func (t *A_arbace_go_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_160 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_164 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = xs__0; if linked_165 == nil { arg_163 = ifn_166.Invoke_O__O(arg_167) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_168 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = xs__0; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) }; var tmp3 any = tmp2; var tmp4 any; var root_172 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = xs__0; if linked_173 == nil { tmp4 = ifn_174.Invoke_O__O(arg_175) } else { tmp4 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { return lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) } }

func A_arbace_go_const_value_A_New() *A_arbace_go_const_value_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_const_value_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_const_value_A) Invoke_O_O_O__O(self, v__0, underlying__1 any) any {




	var tmp1 any; var root_176 any = A_arbace_go_A_const_45.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_178 lang.IFn
	if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = v__0; if linked_177 == nil { tmp1 = ifn_178.Invoke_O__O(arg_179) } else { tmp1 = linked_177.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_176, arg_179) }
//line :91:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var root_180 any = A_arbace_go_A_const_46.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_182 lang.IFn

		if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = v__0; if linked_181 == nil { tmp2 = ifn_182.Invoke_O__O(arg_183) } else { tmp2 = linked_181.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_180, arg_183) }
//line :91:1
		if jrt.J2g_Truth(tmp2) {

			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__0))).Ref() } else {
//line :91:1
				var tmp3 any; var or__1927000174__auto____3 any; var root_184 any = A_arbace_go_A_const_47.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_float_QMARK__A_fn_class); var ifn_186 lang.IFn


				if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { or__1927000174__auto____3 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____3 = linked_185.(*aot_arbace_core.A_arbace_core_float_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_188 any = A_arbace_go_A_const_48.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = v__0; if linked_189 == nil { or__1927000174__auto____4 = ifn_190.Invoke_O__O(arg_191) } else { or__1927000174__auto____4 = linked_189.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { var root_192 any = A_arbace_go_A_const_49.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_decimal_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*aot_arbace_core.A_arbace_core_decimal_QMARK__A).Invoke_O_O__O(root_192, arg_195) } } }
//line :91:1
				if jrt.J2g_Truth(tmp3) {


					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_A_const_50, underlying__1) { return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__0)).Ref() } else { return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__0)).Ref() } } else {
//line :91:1
						var tmp4 any; var root_196 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_198 lang.IFn



						if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = v__0; if linked_197 == nil { tmp4 = ifn_198.Invoke_O__O(arg_199) } else { tmp4 = linked_197.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_196, arg_199) }
//line :91:1
						if jrt.J2g_Truth(tmp4) { var G__1822000028__3_ any; var root_200 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_202 lang.IFn



							if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = v__0; if linked_205 == nil { arg_203 = ifn_206.Invoke_O__O(arg_207) } else { arg_203 = linked_205.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_204, arg_207) }; if linked_201 == nil { G__1822000028__3_ = ifn_202.Invoke_O__O(arg_203) } else { G__1822000028__3_ = linked_201.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_200, arg_203) }; switch lang.Util_Hash_O__I_NoInit(G__1822000028__3_) >> 7 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_2) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_52.GetRawRoot__O()); var tmp6 any = A_arbace_go_const_value_fn__1822000029_A_New(); var tmp7 *jrt.Class
								var fncls__222 /*line :95:1*/*jrt.Class = A_arbace_go_const_value_fn__1822000029_A_fn_class

								if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_const_value_fn__1822000029_A_fn_class = fncls__222d; tmp7 = fncls__222d } else { tmp7 = fncls__222 }
//line :95:1
								var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_223 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_225 lang.IFn

								if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = v__0; if linked_224 == nil { tmp9 = ifn_225.Invoke_O__O(arg_226) } else { tmp9 = linked_224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_223, arg_226) }
//line :95:1
								return jrt.String_New_B1_String(lang.Numbers_Byte_array_O__B1_NoInit(tmp5.Invoke_O_O__O(tmp8, tmp9)), Lit_4) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_5) {



									var tmp10 any; var root_227 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = v__0; if linked_228 == nil { tmp10 = ifn_229.Invoke_O__O(arg_230) } else { tmp10 = linked_228.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_227, arg_230) }; return lang.GoInterp_Complex_D_D__O(lang.RT_DoubleCast_O__D_NoInit(tmp10), lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) }
//line :95:1
							case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_6) {
								var tmp11 any; var root_231 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = v__0; if linked_232 == nil { tmp11 = ifn_233.Invoke_O__O(arg_234) } else { tmp11 = linked_232.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_231, arg_234) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp11)).Ref() }
//line :95:1
							case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000028__3_, Lit_7) {




								var tmp12 any; var root_235 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = v__0; if linked_236 == nil { tmp12 = ifn_237.Invoke_O__O(arg_238) } else { tmp12 = linked_236.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_235, arg_238) }; return jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Multiply_D_D__D_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp12), jrt.Math_Pow_D_D__D(2.0, lang.RT_DoubleCast_O__D_NoInit(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))))).Ref() }
//line :95:1
							default:}; return v__0 } else {
//line :91:1
								if A_arbace_go_A_const_42 != nil { return v__0 } else { return nil
								}
							}
					}
			}
	} }
func A_arbace_go_const_value_fn__1822000029_A_New() *A_arbace_go_const_value_fn__1822000029_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_value_fn__1822000029_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Ctor() {}
//line :97:1
func (t *A_arbace_go_const_value_fn__1822000029_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_214 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = x__1; if linked_215 == nil { tmp1 = ifn_216.Invoke_O__O(arg_217) } else { tmp1 = linked_215.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp1) { var root_218 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = jrt.NN(jrt.String_Cast(x__1)).GetBytes_String__B1(Lit_4).Ref(); if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) } } else { return lang.Tuple_Create_O__IPersistentVector(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_UncheckedByteCast_O__B_NoInit(x__1)).Ref()) } }






func A_arbace_go_digest_info_A_New() *A_arbace_go_digest_info_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_digest_info_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_digest_info_A) Invoke_O_O__O(self, p__0 any) any {


	var root_239 any = A_arbace_go_A_const_54.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any; var tmp1 any = A_arbace_go_digest_info_fn__1822000032_A_New(); var tmp2 *jrt.Class; var fncls__429 *jrt.Class = A_arbace_go_digest_info_fn__1822000032_A_fn_class
	if fncls__429 == nil { var fncls__429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_digest_info_fn__1822000032_A_fn_class = fncls__429d; tmp2 = fncls__429d } else { tmp2 = fncls__429 }; arg_242 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :107:1
	var arg_243 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_244 any; var root_430 any = A_arbace_go_A_const_70.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_go_digest_forms_A_fn_class); var ifn_432 lang.IFn






















	if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = p__0; if linked_431 == nil { arg_244 = ifn_432.Invoke_O__O(arg_433) } else { arg_244 = linked_431.(*A_arbace_go_digest_forms_A).Invoke_O_O__O(root_430, arg_433) }
//line :107:1
	if linked_240 == nil { return ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { return linked_240.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) } }
func A_arbace_go_digest_info_fn__1822000032_A_New() *A_arbace_go_digest_info_fn__1822000032_A { A_arbace_go_A_Init(); t := &A_arbace_go_digest_info_fn__1822000032_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Ctor() {}
//line :108:1
func (t *A_arbace_go_digest_info_fn__1822000032_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any; var root_245 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var and__1927000168__auto____3 any; var root_249 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__2; if linked_250 == nil { and__1927000168__auto____3 = ifn_251.Invoke_O__O(arg_252) } else { and__1927000168__auto____3 = linked_250.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_253 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = f__2; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { and__1927000168__auto____4 = ifn_255.Invoke_O__O(arg_256) } else { and__1927000168__auto____4 = linked_254.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_261 any = A_arbace_go_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_265 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = f__2; if linked_266 == nil { arg_264 = ifn_267.Invoke_O__O(arg_268) } else { arg_264 = linked_266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_265, arg_268) }; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_261, arg_264) }; arg_248 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_10, tmp2)).Ref() } else { arg_248 = and__1927000168__auto____4 } } else { arg_248 = and__1927000168__auto____3 }; if linked_246 == nil { tmp1 = ifn_247.Invoke_O__O(arg_248) } else { tmp1 = linked_246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var G__1822000033__3_ any; var root_269 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_271 lang.IFn

		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_273 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = f__2; if linked_274 == nil { arg_272 = ifn_275.Invoke_O__O(arg_276) } else { arg_272 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; if linked_270 == nil { G__1822000033__3_ = ifn_271.Invoke_O__O(arg_272) } else { G__1822000033__3_ = linked_270.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_269, arg_272) }; switch lang.Util_Hash_O__I_NoInit(G__1822000033__3_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_11) { var vec__1822000034__4 any; var root_278 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_go_strip_doc_A_fn_class); var ifn_280 lang.IFn



			if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_282, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_286 any = f__2; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(A_arbace_go_A_const_59, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_282, 2, A_arbace_go_A_const_59, arg_286) }; if linked_279 == nil { vec__1822000034__4 = ifn_280.Invoke_O__O(arg_281) } else { vec__1822000034__4 = linked_279.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_278, arg_281) }
//line :111:1
			var doc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000034__4, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__7 any; var tmp3 any = A_arbace_go_A_const_60; var tmp4 any; var root_287 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn




			if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = xs__6; if linked_288 == nil { tmp4 = ifn_289.Invoke_O__O(arg_290) } else { tmp4 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var root_291 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_291, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_295 any = xs__6; if linked_292 == nil { xs__7 = ifn_293.Invoke_O_O__O(A_arbace_go_A_const_59, arg_295) } else { xs__7 = linked_292.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_291, 2, A_arbace_go_A_const_59, arg_295) } } else { xs__7 = xs__6 }
//line :111:1
			var pv__8 any; var root_296 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_298 lang.IFn





			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = xs__7; if linked_297 == nil { pv__8 = ifn_298.Invoke_O__O(arg_299) } else { pv__8 = linked_297.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_296, arg_299) }
//line :111:1
			var r__9 any; var root_300 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn






			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = pv__8; if linked_301 == nil { r__9 = ifn_302.Invoke_O__O(arg_303) } else { r__9 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }
//line :111:1
			var rt__10 any; var tmp5 any; var and__1927000168__auto____10 any; var root_304 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_306 lang.IFn







			if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = r__9; if linked_305 == nil { and__1927000168__auto____10 = ifn_306.Invoke_O__O(arg_307) } else { and__1927000168__auto____10 = linked_305.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp6 *lang.Keyword = A_arbace_go_A_const_38; tmp5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__9)) } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) { var tmp7 *lang.Keyword = A_arbace_go_A_const_38; rt__10 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(r__9)) } else { rt__10 = r__9 }
//line :111:1
			var rt__11 any; var tmp8 any; var root_308 any = A_arbace_go_A_const_51.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn








			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = rt__10; if linked_309 == nil { tmp8 = ifn_310.Invoke_O__O(arg_311) } else { tmp8 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(tmp8) { var root_312 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = rt__10; if linked_313 == nil { rt__11 = ifn_314.Invoke_O__O(arg_315) } else { rt__11 = linked_313.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_312, arg_315) } } else { rt__11 = rt__10 }
			var tmp9 any; var root_316 any = A_arbace_go_A_const_37.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = rt__11; if linked_317 == nil { tmp9 = ifn_318.Invoke_O__O(arg_319) } else { tmp9 = linked_317.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(tmp9) {
				var root_320 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = acc__1; var arg_324 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil); var tmp11 any; var root_326 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = f__2; if linked_327 == nil { tmp11 = ifn_328.Invoke_O__O(arg_329) } else { tmp11 = linked_327.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_326, arg_329) }; arg_324 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, rt__11, nil, tmp11)).Ref(); var arg_325 any; var tmp12 any = A_arbace_go_A_const_62; var tmp13 any = A_arbace_go_A_const_63; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp15 any; var root_330 any = A_arbace_go_A_const_65.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_go_params_of_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = pv__8; if linked_331 == nil { tmp15 = ifn_332.Invoke_O__O(arg_333) } else { tmp15 = linked_331.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_330, arg_333) }; arg_325 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, doc__5, tmp13, tmp14.Invoke_O__O(tmp15))); if linked_321 == nil { return ifn_322.Invoke_O_O_O__O(arg_323, arg_324, arg_325) } else { return linked_321.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_320, arg_323, arg_324, arg_325) } } else {
//line :121:1
					return acc__1 } }
//line :111:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_13) {














			var root_334 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = acc__1; var arg_338 any; var root_340 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any; var root_344 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = f__2; if linked_345 == nil { arg_343 = ifn_346.Invoke_O__O(arg_347) } else { arg_343 = linked_345.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_344, arg_347) }; if linked_341 == nil { arg_338 = ifn_342.Invoke_O__O(arg_343) } else { arg_338 = linked_341.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_340, arg_343) }; var arg_339 any; var tmp16 any = A_arbace_go_A_const_62; var tmp17 any; var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(f__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp18 any; var root_348 any = A_arbace_go_A_const_43.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = d__4; if linked_349 == nil { tmp18 = ifn_350.Invoke_O__O(arg_351) } else { tmp18 = linked_349.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_348, arg_351) }; if jrt.J2g_Truth(tmp18) { tmp17 = d__4 } else { tmp17 = nil }; arg_339 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17)); if linked_335 == nil { return ifn_336.Invoke_O_O_O__O(arg_337, arg_338, arg_339) } else { return linked_335.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_334, arg_337, arg_338, arg_339) } }
//line :111:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_14) { var n__4 any; var root_352 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_354 lang.IFn












			if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = f__2; if linked_353 == nil { n__4 = ifn_354.Invoke_O__O(arg_355) } else { n__4 = linked_353.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_352, arg_355) }
//line :111:1
			var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__4); var root_356 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_358 lang.IFn













			if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = acc__1; var arg_360 any; var root_362 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = n__4; if linked_363 == nil { arg_360 = ifn_364.Invoke_O__O(arg_365) } else { arg_360 = linked_363.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_362, arg_365) }; var arg_361 any; var tmp19 any = A_arbace_go_A_const_62; var tmp20 any = A_arbace_go_A_const_62.Invoke_O__O(m__5); var tmp21 any = A_arbace_go_A_const_66; var tmp22 any; var root_366 any = A_arbace_go_A_const_67.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_const_value_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_A_const_68.Invoke_O__O(m__5); var arg_370 any = A_arbace_go_A_const_69.Invoke_O__O(m__5); if linked_367 == nil { tmp22 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { tmp22 = linked_367.(*A_arbace_go_const_value_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; arg_361 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20, tmp21, tmp22)); if linked_357 == nil { return ifn_358.Invoke_O_O_O__O(arg_359, arg_360, arg_361) } else { return linked_357.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_356, arg_359, arg_360, arg_361) } }
//line :111:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_15) { var vec__1822000037__4 any; var root_371 any = A_arbace_go_A_const_57.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_go_strip_doc_A_fn_class); var ifn_373 lang.IFn
			if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var root_375 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_375, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_379 any = f__2; if linked_376 == nil { arg_374 = ifn_377.Invoke_O_O__O(A_arbace_go_A_const_59, arg_379) } else { arg_374 = linked_376.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_375, 2, A_arbace_go_A_const_59, arg_379) }; if linked_372 == nil { vec__1822000037__4 = ifn_373.Invoke_O__O(arg_374) } else { vec__1822000037__4 = linked_372.(*A_arbace_go_strip_doc_A).Invoke_O_O__O(root_371, arg_374) }
//line :111:1
			var doc__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000037__4, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__7_2 any; var tmp23 any = A_arbace_go_A_const_60; var tmp24 any; var root_380 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_382 lang.IFn

			if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = xs__6_2; if linked_381 == nil { tmp24 = ifn_382.Invoke_O__O(arg_383) } else { tmp24 = linked_381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_380, arg_383) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp23, tmp24) { var root_384 any = A_arbace_go_A_const_58.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_384, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_388 any = xs__6_2; if linked_385 == nil { xs__7_2 = ifn_386.Invoke_O_O__O(A_arbace_go_A_const_59, arg_388) } else { xs__7_2 = linked_385.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_384, 2, A_arbace_go_A_const_59, arg_388) } } else { xs__7_2 = xs__6_2 }
			var root_389 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = acc__1; var arg_393 any; var root_395 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var root_399 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = f__2; if linked_400 == nil { arg_398 = ifn_401.Invoke_O__O(arg_402) } else { arg_398 = linked_400.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_399, arg_402) }; if linked_396 == nil { arg_393 = ifn_397.Invoke_O__O(arg_398) } else { arg_393 = linked_396.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_395, arg_398) }; var arg_394 any; var tmp25 any = A_arbace_go_A_const_62; var tmp26 any = A_arbace_go_A_const_63; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp28 any; var root_403 any = A_arbace_go_A_const_65.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, A_arbace_go_params_of_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var root_407 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = xs__7_2; if linked_408 == nil { arg_406 = ifn_409.Invoke_O__O(arg_410) } else { arg_406 = linked_408.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_407, arg_410) }; if linked_404 == nil { tmp28 = ifn_405.Invoke_O__O(arg_406) } else { tmp28 = linked_404.(*A_arbace_go_params_of_A).Invoke_O_O__O(root_403, arg_406) }; arg_394 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp25, doc__5_2, tmp26, tmp27.Invoke_O__O(tmp28))); if linked_390 == nil { return ifn_391.Invoke_O_O_O__O(arg_392, arg_393, arg_394) } else { return linked_390.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_389, arg_392, arg_393, arg_394) } }
//line :111:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1822000033__3_, Lit_16) {















			var root_411 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = acc__1; var arg_415 any; var root_417 any = A_arbace_go_A_const_11.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var root_421 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = f__2; if linked_422 == nil { arg_420 = ifn_423.Invoke_O__O(arg_424) } else { arg_420 = linked_422.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_421, arg_424) }; if linked_418 == nil { arg_415 = ifn_419.Invoke_O__O(arg_420) } else { arg_415 = linked_418.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_417, arg_420) }; var arg_416 any; var tmp29 any = A_arbace_go_A_const_62; var tmp30 *lang.Keyword = A_arbace_go_A_const_62; var tmp31 any; var root_425 any = A_arbace_go_A_const_53.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = f__2; if linked_426 == nil { tmp31 = ifn_427.Invoke_O__O(arg_428) } else { tmp31 = linked_426.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_425, arg_428) }; arg_416 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp31)))); if linked_412 == nil { return ifn_413.Invoke_O_O_O__O(arg_414, arg_415, arg_416) } else { return linked_412.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_411, arg_414, arg_415, arg_416) } }
//line :111:1
		default:}; return acc__1
	}
}





















func A_arbace_go_member_var_A_New() *A_arbace_go_member_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_member_var_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_go_member_var_A) Ctor() {}
//line :135:1
func (t *A_arbace_go_member_var_A) Invoke_O_O_O_O_O_O_O__O(self, ns__0, path__1, nm__2, kind__3, handle__4, info__5 any) any { var full__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, path__1, nil, nm__2)).Ref(); var m__8 any; var G__1822000042__8_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_A_const_71, kind__3, A_arbace_go_A_const_72, path__1)); var G__1822000042__9_ any; if



	jrt.J2g_Truth(A_arbace_go_A_const_62.Invoke_O__O(info__5)) {
		var root_434 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = G__1822000042__8_; var arg_438 any = A_arbace_go_A_const_62; var arg_439 any = A_arbace_go_A_const_62.Invoke_O__O(info__5); if linked_435 == nil { G__1822000042__9_ = ifn_436.Invoke_O_O_O__O(arg_437, arg_438, arg_439) } else { G__1822000042__9_ = linked_435.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_434, arg_437, arg_438, arg_439) } } else {
//line :139:1
			G__1822000042__9_ = G__1822000042__8_ }; if jrt.J2g_Truth(A_arbace_go_A_const_63.Invoke_O__O(info__5)) {

				var root_440 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = G__1822000042__9_; var arg_444 any = A_arbace_go_A_const_63; var arg_445 any = A_arbace_go_A_const_63.Invoke_O__O(info__5); if linked_441 == nil { m__8 = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { m__8 = linked_441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) } } else {
//line :139:1
					m__8 = G__1822000042__9_ }; var root_446 any =


	A_arbace_go_A_const_73.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = ns__0; var arg_450 any; var root_452 any = A_arbace_go_A_const_74.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; var root_457 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = nm__2; if linked_458 == nil { arg_455 = ifn_459.Invoke_O__O(arg_460) } else { arg_455 = linked_458.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_457, arg_460) }; var arg_456 any = m__8; if linked_453 == nil { arg_450 = ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { arg_450 = linked_453.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) }; var arg_451 any; var G__1822000043__9_ any = kind__3; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1822000043__9_) >> 3 & 7 { case 1: if any(G__1822000043__9_) == any(A_arbace_go_A_const_75) { arg_451 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 3: if any(G__1822000043__9_) == any(A_arbace_go_A_const_76) { arg_451 = lang.GoVar_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 4: if any(G__1822000043__9_) == any(A_arbace_go_A_const_77) { arg_451 = lang.GoFn_New_O_String(handle__4, jrt.String_Cast(full__7)); break L1 }; case 5: if any(G__1822000043__9_) == any(A_arbace_go_A_const_66) {



		arg_451 = A_arbace_go_A_const_66.Invoke_O__O(info__5)
//line :143:1
		break L1 }; case 6: if any(G__1822000043__9_) == any(A_arbace_go_A_const_78) { arg_451 = lang.GoType_New_O(handle__4); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1822000043__9_)))))}; if /*line :142:1*/ linked_447 == nil { return ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { return linked_447.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) } }






func A_arbace_go_table_ns_BANG__A_New() *A_arbace_go_table_ns_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_table_ns_BANG__A) Ctor() {}
//line :149:1
func (t *A_arbace_go_table_ns_BANG__A) Invoke_O_O__O(self, p__0 any) any { var ns__2 any; var root_462 any = A_arbace_go_A_const_79.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_464 lang.IFn; if




	linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_466 any = A_arbace_go_A_const_80.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_go_path__GT_ns_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = p__0; if linked_467 == nil { arg_465 = ifn_468.Invoke_O__O(arg_469) } else { arg_465 = linked_467.(*A_arbace_go_path__GT_ns_A).Invoke_O_O__O(root_466, arg_469) }; if linked_463 == nil { ns__2 = ifn_464.Invoke_O__O(arg_465) } else { ns__2 = linked_463.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_462, arg_465) }; var ms__3 any = /*line :149:1*/lang.GoInterp_Members_String__O1(jrt.String_Cast(p__0)).Ref(); var members__4 any; var root_470 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_472 lang.IFn; if






	linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_474 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_New(); var tmp2 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class = fncls__541d; tmp2 = fncls__541d } else { tmp2 = fncls__541 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_542 any = A_arbace_go_A_const_91.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = A_arbace_go_A_const_92; var arg_546 any = ms__3; if linked_543 == nil { tmp4 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { tmp4 = linked_543.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; arg_474 = tmp3.Invoke_O__O(tmp4); if linked_471 == nil { members__4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { members__4 = linked_471.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; var info__5 any; var tmp5 any = /*line :149:1*/A_arbace_go_table_ns_BANG__fn__1822000061_A_New_O(p__0); var tmp6 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class; if







	fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class = fncls__551d; tmp6 = fncls__551d } else { tmp6 = fncls__551 }; info__5 = /*line :149:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var consts__6 any; var tmp7 any = A_arbace_go_table_ns_BANG__fn__1822000063_A_New_O_O(info__5, members__4); var tmp8 *jrt.Class; var fncls__656 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class; if








	fncls__656 == nil { var fncls__656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class = fncls__656d; tmp8 = fncls__656d } else { tmp8 = fncls__656 }; consts__6 = /*line :149:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var make__7 any; var tmp9 any = A_arbace_go_table_ns_BANG__make__1822000081_A_New_O_O_O_O_O(ns__2, info__5, consts__6, p__0, members__4); var tmp10 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class; if









	fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class = fncls__683d; tmp10 = fncls__683d } else { tmp10 = fncls__683 }; make__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var resolver__8 any; var tmp11 any = /*line :149:1*/A_arbace_go_table_ns_BANG__resolver__1822000086_A_New_O_O_O(make__7, consts__6, members__4); var tmp12 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class; if














	fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class = fncls__737d; tmp12 = fncls__737d } else { tmp12 = fncls__737 }; resolver__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil);





	jrt.NN(lang.Namespace_Cast(ns__2)).SetResolver_O__V(resolver__8); return ns__2 }
//line :156:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_New() *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A) Ctor() {}
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A) Invoke_O_O__O(self, s__1822000046__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_New_O_O(self, s__1822000046__1); var tmp2 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class = fncls__540d; tmp2 = fncls__540d } else { tmp2 = fncls__540 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :156:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A) Ctor_O_O(c__iter__1822000045, c__s__1822000046 any) { t.F_iter__1822000045 = c__iter__1822000045; t.F_s__1822000046 = c__s__1822000046 }
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A) Invoke_O__O(self any) any { { var s__1822000046__1 any; var t_ any = t.F_s__1822000046; t.F_s__1822000046 = nil; s__1822000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_475 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__1822000046__1; if linked_476 == nil { temp__1927000414__auto____2 = ifn_477.Invoke_O__O(arg_478) } else { temp__1927000414__auto____2 = linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_479 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = s__1822000046__3; if linked_480 == nil { tmp1 = ifn_481.Invoke_O__O(arg_482) } else { tmp1 = linked_480.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_483 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = s__1822000046__3; if linked_484 == nil { c__1927001037__auto____4 = ifn_485.Invoke_O__O(arg_486) } else { c__1927001037__auto____4 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_483, arg_486) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000048__6 any; var root_487 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_488 == nil { b__1822000048__6 = ifn_489.Invoke_O__O(arg_490) } else { b__1822000048__6 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_487, arg_490) }; var tmp2 any = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_New_O_I_O(b__1822000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__500 *jrt.Class = A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class; if fncls__500 == nil { var fncls__500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class = fncls__500d; tmp3 = fncls__500d } else { tmp3 = fncls__500 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_501 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any; var root_506 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = b__1822000048__6; if linked_507 == nil { arg_504 = ifn_508.Invoke_O__O(arg_509) } else { arg_504 = linked_507.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_506, arg_509) }; var arg_505 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000045); var tmp5 any; var root_510 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = s__1822000046__3; if linked_511 == nil { tmp5 = ifn_512.Invoke_O__O(arg_513) } else { tmp5 = linked_511.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_510, arg_513) }; arg_505 = tmp4.Invoke_O__O(tmp5); if linked_502 == nil { return ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { return linked_502.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) } } else { var root_514 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var root_519 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = b__1822000048__6; if linked_520 == nil { arg_517 = ifn_521.Invoke_O__O(arg_522) } else { arg_517 = linked_520.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_519, arg_522) }; var arg_518 any; if linked_515 == nil { return ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { return linked_515.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) } } } else { var vec__1822000056__4 any; var root_523 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__1822000046__3; if linked_524 == nil { vec__1822000056__4 = ifn_525.Invoke_O__O(arg_526) } else { vec__1822000056__4 = linked_524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_523, arg_526) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000056__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_527 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp6 any; var root_532 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = k__5; if linked_533 == nil { tmp6 = ifn_534.Invoke_O__O(arg_535) } else { tmp6 = linked_533.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_532, arg_535) }; arg_530 = lang.Tuple_Create_O_O__IPersistentVector(n__6, lang.Tuple_Create_O_O__IPersistentVector(tmp6, h__7)); var arg_531 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1822000045); var tmp8 any; var root_536 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = s__1822000046__3; if linked_537 == nil { tmp8 = ifn_538.Invoke_O__O(arg_539) } else { tmp8 = linked_537.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_536, arg_539) }; arg_531 = tmp7.Invoke_O__O(tmp8); if linked_528 == nil { return ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { return linked_528.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :156:1
func A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A) Ctor_O_I_O(c__b__1822000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000048 = c__b__1822000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :156:1
func (t *A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A) Invoke_O__O(self any) any { { var i__1822000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000052__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000047__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000052__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_491 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = t.F_b__1822000048; var arg_495 any; var tmp2 any; var root_496 any = A_arbace_go_A_const_86.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = k__3; if linked_497 == nil { tmp2 = ifn_498.Invoke_O__O(arg_499) } else { tmp2 = linked_497.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_496, arg_499) }; arg_495 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.Tuple_Create_O_O__IPersistentVector(tmp2, h__5)); if linked_492 == nil { ifn_493.Invoke_O_O__O(arg_494, arg_495) } else { linked_492.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_491, arg_494, arg_495) }; i__1822000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__fn__1822000061_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000061_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000061_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000061_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :157:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000061_A) Invoke_O__O(self any) any { var root_547 any = A_arbace_go_A_const_93.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_go_digest_info_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var t_ any = t.F_p; t.F_p = nil; arg_550 = t_; if linked_548 == nil { return ifn_549.Invoke_O__O(arg_550) } else { return linked_548.(*A_arbace_go_digest_info_A).Invoke_O_O__O(root_547, arg_550) } }
func A_arbace_go_table_ns_BANG__fn__1822000063_A_New_O_O(p0, p1 any) *A_arbace_go_table_ns_BANG__fn__1822000063_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_A) Ctor_O_O(c__info, c__members any) { t.F_info = c__info; t.F_members = c__members }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_A) Invoke_O__O(self any) any { var root_552 any = A_arbace_go_A_const_81.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_556 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_New_O(t.F_members); var tmp2 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class = fncls__651d; tmp2 = fncls__651d } else { tmp2 = fncls__651 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_652 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var t_ any = t.F_info; t.F_info = nil; arg_655 = t_; if linked_653 == nil { tmp4 = ifn_654.Invoke_O__O(arg_655) } else { tmp4 = linked_653.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_652, arg_655) }; arg_556 = tmp3.Invoke_O__O(tmp4); if linked_553 == nil { return ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { return linked_553.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) } }
//line :158:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_New_O(p0 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A) Ctor_O(c__members any) { t.F_members = c__members }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A) Invoke_O_O__O(self, s__1822000065__1 any) any { var tmp1 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_New_O_O_O(t.F_members, s__1822000065__1, self); var tmp2 *jrt.Class; var fncls__650 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class; if fncls__650 == nil { var fncls__650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class = fncls__650d; tmp2 = fncls__650d } else { tmp2 = fncls__650 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A) Ctor_O_O_O(c__members, c__s__1822000065, c__iter__1822000064 any) { t.F_members = c__members; t.F_s__1822000065 = c__s__1822000065; t.F_iter__1822000064 = c__iter__1822000064 }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A) Invoke_O__O(self any) any { { var s__1822000065__1 any; var t_ any = t.F_s__1822000065; t.F_s__1822000065 = nil; s__1822000065__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_557 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = s__1822000065__1; if linked_558 == nil { temp__1927000414__auto____2 = ifn_559.Invoke_O__O(arg_560) } else { temp__1927000414__auto____2 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000065__3 any = temp__1927000414__auto____2; var tmp1 any; var root_561 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__1822000065__3; if linked_562 == nil { tmp1 = ifn_563.Invoke_O__O(arg_564) } else { tmp1 = linked_562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_561, arg_564) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_565 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = s__1822000065__3; if linked_566 == nil { c__1927001037__auto____4 = ifn_567.Invoke_O__O(arg_568) } else { c__1927001037__auto____4 = linked_566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_565, arg_568) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000067__6 any; var root_569 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_570 == nil { b__1822000067__6 = ifn_571.Invoke_O__O(arg_572) } else { b__1822000067__6 = linked_570.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_569, arg_572) }; var tmp2 any = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_New_O_O_I_O(b__1822000067__6, t.F_members, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__592 *jrt.Class = A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class; if fncls__592 == nil { var fncls__592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class = fncls__592d; tmp3 = fncls__592d } else { tmp3 = fncls__592 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_593 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var root_598 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = b__1822000067__6; if linked_599 == nil { arg_596 = ifn_600.Invoke_O__O(arg_601) } else { arg_596 = linked_599.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_598, arg_601) }; var arg_597 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000064); var tmp5 any; var root_602 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__1822000065__3; if linked_603 == nil { tmp5 = ifn_604.Invoke_O__O(arg_605) } else { tmp5 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_602, arg_605) }; arg_597 = tmp4.Invoke_O__O(tmp5); if linked_594 == nil { return ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { return linked_594.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) } } else { var root_606 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_611 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = b__1822000067__6; if linked_612 == nil { arg_609 = ifn_613.Invoke_O__O(arg_614) } else { arg_609 = linked_612.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_611, arg_614) }; var arg_610 any; if linked_607 == nil { return ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { return linked_607.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) } } } else { var vec__1822000075__4 any; var root_615 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = s__1822000065__3; if linked_616 == nil { vec__1822000075__4 = ifn_617.Invoke_O__O(arg_618) } else { vec__1822000075__4 = linked_616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_615, arg_618) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000075__4, lang.RT_IntCast_J__I_NoInit(0), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000075__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_619 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = i__6; var arg_623 any = A_arbace_go_A_const_66; if linked_620 == nil { tmp6 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { tmp6 = linked_620.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_624 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any; var root_628 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = t.F_members; var arg_632 any = n__5; if linked_629 == nil { arg_627 = ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { arg_627 = linked_629.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }; if linked_625 == nil { tmp7 = ifn_626.Invoke_O__O(arg_627) } else { tmp7 = linked_625.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_624, arg_627) }; if jrt.J2g_Truth(tmp7) { var root_633 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, i__6); var arg_637 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000064); var tmp9 any; var root_638 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__1822000065__3; if linked_639 == nil { tmp9 = ifn_640.Invoke_O__O(arg_641) } else { tmp9 = linked_639.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_638, arg_641) }; arg_637 = tmp8.Invoke_O__O(tmp9); if linked_634 == nil { return ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { return linked_634.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_633, arg_636, arg_637) } } else { var tmp10 any; var root_642 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = s__1822000065__3; if linked_643 == nil { tmp10 = ifn_644.Invoke_O__O(arg_645) } else { tmp10 = linked_643.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_642, arg_645) }; s__1822000065__1 = tmp10; continue L1 } } else { var tmp11 any; var root_646 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__1822000065__3; if linked_647 == nil { tmp11 = ifn_648.Invoke_O__O(arg_649) } else { tmp11 = linked_647.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_646, arg_649) }; s__1822000065__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A) Ctor_O_O_I_O(c__b__1822000067, c__members any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1822000067 = c__b__1822000067; t.F_members = c__members; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A) Invoke_O__O(self any) any { { var i__1822000066__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000066__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1822000071__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000066__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_573 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = i__4; var arg_577 any = A_arbace_go_A_const_66; if linked_574 == nil { tmp2 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { tmp2 = linked_574.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_578 any = A_arbace_go_A_const_55.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_582 any = A_arbace_go_A_const_94.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = t.F_members; var arg_586 any = n__3; if linked_583 == nil { arg_581 = ifn_584.Invoke_O_O__O(arg_585, arg_586) } else { arg_581 = linked_583.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_582, arg_585, arg_586) }; if linked_579 == nil { tmp3 = ifn_580.Invoke_O__O(arg_581) } else { tmp3 = linked_579.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(tmp3) { var root_587 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = t.F_b__1822000067; var arg_591 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, i__4); if linked_588 == nil { ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { linked_588.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } else { i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } } else { i__1822000066__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000066__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_table_ns_BANG__make__1822000081_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_table_ns_BANG__make__1822000081_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__make__1822000081_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :159:1
func (t *A_arbace_go_table_ns_BANG__make__1822000081_A) Ctor_O_O_O_O_O(c__ns, c__info, c__consts, c__p, c__members any) { t.F_ns = c__ns; t.F_info = c__info; t.F_consts = c__consts; t.F_p = c__p; t.F_members = c__members }
//line :159:1
func (t *A_arbace_go_table_ns_BANG__make__1822000081_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_members, n__1); if
												jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1822000082__3 any = temp__1927000408__auto____2; var kind__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000082__3, lang.RT_IntCast_J__I_NoInit(0), nil); var h__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1822000082__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_657 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_go_member_var_A_fn_class); var ifn_659 lang.IFn
													if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = t.F_ns; var arg_661 any = t.F_p; var arg_662 any = n__1; var arg_663 any = kind__4; var arg_664 any = h__5; var arg_665 any; var tmp1 any; var root_666 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = t.F_info; if linked_667 == nil { tmp1 = ifn_668.Invoke_O__O(arg_669) } else { tmp1 = linked_667.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_666, arg_669) }; arg_665 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if linked_658 == nil { return ifn_659.Invoke_O_O_O_O_O_O__O(arg_660, arg_661, arg_662, arg_663, arg_664, arg_665) } else { return linked_658.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_657, arg_660, arg_661, arg_662, arg_663, arg_664, arg_665) } } else {
//line :160:1
			var temp__1927000414__auto____3 any; var tmp2 any; var root_670 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_672 lang.IFn

			if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = t.F_consts; if linked_671 == nil { tmp2 = ifn_672.Invoke_O__O(arg_673) } else { tmp2 = linked_671.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_670, arg_673) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var root_674 any = A_arbace_go_A_const_95.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_go_member_var_A_fn_class); var ifn_676 lang.IFn
				if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = t.F_ns; var arg_678 any = t.F_p; var arg_679 any = n__1; var arg_680 any = A_arbace_go_A_const_66; var arg_681 any; var arg_682 any = i__4; if linked_675 == nil { return ifn_676.Invoke_O_O_O_O_O_O__O(arg_677, arg_678, arg_679, arg_680, arg_681, arg_682) } else { return linked_675.(*A_arbace_go_member_var_A).Invoke_O_O_O_O_O_O_O__O(root_674, arg_677, arg_678, arg_679, arg_680, arg_681, arg_682) } } else {
//line :162:1
					return nil } } }

func A_arbace_go_table_ns_BANG__resolver__1822000086_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_table_ns_BANG__resolver__1822000086_A { A_arbace_go_A_Init(); t := &A_arbace_go_table_ns_BANG__resolver__1822000086_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Ctor_O_O_O(c__make, c__consts, c__members any) { t.F_make = c__make; t.F_consts = c__consts; t.F_members = c__members }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Invoke_O_O_O__O(self, ___1, sym__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(t.F_make); var tmp2 any; var root_684 any = A_arbace_go_A_const_41.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = sym__2; if linked_685 == nil { tmp2 = ifn_686.Invoke_O__O(arg_687) } else { tmp2 = linked_685.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_684, arg_687) }; return tmp1.Invoke_O__O(tmp2) }
//line :164:1
func (t *A_arbace_go_table_ns_BANG__resolver__1822000086_A) Invoke_O_O__O(self, ___1 any) any { { var seq_1822000087__2 any; var root_688 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_690 lang.IFn

	if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_692 any = A_arbace_go_A_const_96.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var root_696 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_701 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = t.F_members; if linked_702 == nil { arg_699 = ifn_703.Invoke_O__O(arg_704) } else { arg_699 = linked_702.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_701, arg_704) }; var arg_700 any; var root_705 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any; var root_709 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = t.F_consts; if linked_710 == nil { arg_708 = ifn_711.Invoke_O__O(arg_712) } else { arg_708 = linked_710.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_709, arg_712) }; if linked_706 == nil { arg_700 = ifn_707.Invoke_O__O(arg_708) } else { arg_700 = linked_706.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_705, arg_708) }; if linked_697 == nil { arg_695 = ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { arg_695 = linked_697.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) }; if linked_693 == nil { arg_691 = ifn_694.Invoke_O__O(arg_695) } else { arg_691 = linked_693.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_692, arg_695) }; if linked_689 == nil { seq_1822000087__2 = ifn_690.Invoke_O__O(arg_691) } else { seq_1822000087__2 = linked_689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_688, arg_691) }
//line :164:1
	var chunk_1822000088__3 any; var count_1822000089__4 int64 = 0; var i_1822000090__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000090__5, count_1822000089__4) { var n__6 any = lang.Indexed_Cast(chunk_1822000088__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000090__5))
			lang.IFn_Cast(t.F_make).Invoke_O__O(n__6)
//line :166:1
			seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000090__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_713 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_1822000087__2; if linked_714 == nil { temp__1927000414__auto____6 = ifn_715.Invoke_O__O(arg_716) } else { temp__1927000414__auto____6 = linked_714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_713, arg_716) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1822000087__7 any = temp__1927000414__auto____6; var tmp1 any; var root_717 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1822000087__7; if linked_718 == nil { tmp1 = ifn_719.Invoke_O__O(arg_720) } else { tmp1 = linked_718.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_721 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seq_1822000087__7; if linked_722 == nil { c__1927000678__auto____8 = ifn_723.Invoke_O__O(arg_724) } else { c__1927000678__auto____8 = linked_722.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_721, arg_724) }; var tmp2 any; var root_729 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1822000087__7; if linked_730 == nil { tmp2 = ifn_731.Invoke_O__O(arg_732) } else { tmp2 = linked_730.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_729, arg_732) }; seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_725 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1822000087__7; if linked_726 == nil { n__8 = ifn_727.Invoke_O__O(arg_728) } else { n__8 = linked_726.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_725, arg_728) }
				lang.IFn_Cast(t.F_make).Invoke_O__O(n__8)
//line :166:1
				var tmp3 any; var root_733 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_1822000087__7; if linked_734 == nil { tmp3 = ifn_735.Invoke_O__O(arg_736) } else { tmp3 = linked_734.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_733, arg_736) }; seq_1822000087__2, chunk_1822000088__3, count_1822000089__4, i_1822000090__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :164:1*/panic("j2g: unreachable") }








func A_arbace_go_packages_A_New() *A_arbace_go_packages_A { A_arbace_go_A_Init(); t := &A_arbace_go_packages_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_go_packages_A) Ctor() {}
//line :173:1
func (t *A_arbace_go_packages_A) Invoke_O__O(self any) any {


	var root_738 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.GoInterp_Paths__O1().Ref(); if linked_739 == nil { return ifn_740.Invoke_O__O(arg_741) } else { return linked_739.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_738, arg_741)
	}
}


func A_arbace_go_new_A_New() *A_arbace_go_new_A { A_arbace_go_A_Init(); t := &A_arbace_go_new_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_new_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_new_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_NewValue_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_zero_A_New() *A_arbace_go_zero_A { A_arbace_go_A_Init(); t := &A_arbace_go_zero_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_zero_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_zero_A) Invoke_O_O__O(self, t__0 any) any {


	return lang.GoInterp_Zero_O__O(lang.GoType_Cast(t__0).F_handle)
}
func A_arbace_go_type_of_A_New() *A_arbace_go_type_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_of_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_type_of_A) Ctor() {}
//line :191:1
func (t *A_arbace_go_type_of_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_TypeOf_O__O(v__0)
}
func A_arbace_go_str_A_New() *A_arbace_go_str_A { A_arbace_go_A_Init(); t := &A_arbace_go_str_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_str_A) Ctor() {}
//line :196:1
func (t *A_arbace_go_str_A) Invoke_O_O__O(self, v__0 any) any {


	return lang.GoInterp_Str_O__String(v__0).Ref()
}
func A_arbace_go_spread_A_New() *A_arbace_go_spread_A { A_arbace_go_A_Init(); t := &A_arbace_go_spread_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_spread_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_spread_A) Invoke_O_O__O(self, xs__0 any) any {



	return lang.GoInterp_Spread_O__O(xs__0)
}
func A_arbace_go_assign_BANG__A_New() *A_arbace_go_assign_BANG__A { A_arbace_go_A_Init(); t := &A_arbace_go_assign_BANG__A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_assign_BANG__A) Ctor() {}
//line :207:1
func (t *A_arbace_go_assign_BANG__A) Invoke_O_O_O__O(self, v__0, x__1 any) any {



	lang.GoInterp_Store_O_O__V(lang.GoVar_Cast(v__0).F_cell, x__1)
//line :207:1
	return x__1
}











func A_arbace_go_type_names_A_New() *A_arbace_go_type_names_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_go_type_names_A) Ctor() {}
//line :220:1
func (t *A_arbace_go_type_names_A) Invoke_O_O__O(self, ts__0 any) any { var root_742 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = A_arbace_go_A_const_11.GetRawRoot__O(); var arg_746 any; var root_747 any = A_arbace_go_A_const_12.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = Lit_60; var arg_751 any; var root_752 any = A_arbace_go_A_const_13.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var tmp1 any = A_arbace_go_type_names_fn__1822000101_A_New(); var tmp2 *jrt.Class; var fncls__757 *jrt.Class = A_arbace_go_type_names_fn__1822000101_A_fn_class; if fncls__757 == nil { var fncls__757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_type_names_fn__1822000101_A_fn_class = fncls__757d; tmp2 = fncls__757d } else { tmp2 = fncls__757 }; arg_755 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_756 any = ts__0; if linked_753 == nil { arg_751 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { arg_751 = linked_753.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) }; if linked_748 == nil { arg_746 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { arg_746 = linked_748.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; if linked_743 == nil { return ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { return linked_743.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_742, arg_745, arg_746) } }
//line :220:1
func A_arbace_go_type_names_fn__1822000101_A_New() *A_arbace_go_type_names_fn__1822000101_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_names_fn__1822000101_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_go_type_names_fn__1822000101_A) Ctor() {}
//line :220:1
func (t *A_arbace_go_type_names_fn__1822000101_A) Invoke_O_O__O(self, p1__1822000100_SHARP___1 any) any { return jrt.NN(lang.GoType_Cast(p1__1822000100_SHARP___1)).GetName__String().Ref() }

func A_arbace_go_reify_type_A_New() *A_arbace_go_reify_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_type_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_go_reify_type_A) Ctor() {}
//line :222:1
func (t *A_arbace_go_reify_type_A) Invoke_O_O__O(self, ts__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_758 any = A_arbace_go_A_const_5.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_760 lang.IFn; if



	linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = A_arbace_go_A_const_99.GetRawRoot__O(); if linked_759 == nil { tmp1 = ifn_760.Invoke_O__O(arg_761) } else { tmp1 = linked_759.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_758, arg_761) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, ts__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var root_762 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_764 lang.IFn
		if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = lang.GoInterp_ReifyType_O1__O1(lang.RT_Object_array_O__O1_NoInit(ts__0)).Ref(); if linked_763 == nil { r__3 = ifn_764.Invoke_O__O(arg_765) } else { r__3 = linked_763.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_762, arg_765) }
		var root_766 any = A_arbace_go_A_const_100.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = A_arbace_go_A_const_99.GetRawRoot__O(); var arg_770 any = A_arbace_go_A_const_61.GetRawRoot__O(); var arg_771 any = ts__0; var arg_772 any = r__3; if linked_767 == nil { ifn_768.Invoke_O_O_O_O__O(arg_769, arg_770, arg_771, arg_772) } else { linked_767.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_766, arg_769, arg_770, arg_771, arg_772) }
//line :226:1
		return r__3 } }




func A_arbace_go_reify_data_A_New() *A_arbace_go_reify_data_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_go_reify_data_A) Ctor() {}
//line :231:1
func (t *A_arbace_go_reify_data_A) Invoke_O_O_O_O__O(self, rt__0, ts__1, fns__2 any) any { var vec__1822000105__4 any = rt__0; var seq__1822000106__5 any; var root_773 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_775 lang.IFn; if




	linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = vec__1822000105__4; if linked_774 == nil { seq__1822000106__5 = ifn_775.Invoke_O__O(arg_776) } else { seq__1822000106__5 = linked_774.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_773, arg_776) }; var first__1822000107__6 any; var root_777 any = /*line :231:1*/A_arbace_go_A_const_25.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_779 lang.IFn; if




	linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = seq__1822000106__5; if linked_778 == nil { first__1822000107__6 = ifn_779.Invoke_O__O(arg_780) } else { first__1822000107__6 = linked_778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_777, arg_780) }; var seq__1822000106__7 any; var root_781 any = /*line :231:1*/A_arbace_go_A_const_22.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_783 lang.IFn; if




	linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = seq__1822000106__5; if linked_782 == nil { seq__1822000106__7 = ifn_783.Invoke_O__O(arg_784) } else { seq__1822000106__7 = linked_782.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_781, arg_784) }; var t__8 any = first__1822000107__6; var names__9 any = seq__1822000106__7; var seq_1822000108__10 any; var root_857 any = /*line :231:1*/A_arbace_go_A_const_24.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_859 lang.IFn; if





	linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_go_A_const_98.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = fns__2; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_861, arg_864) }; if linked_858 == nil { seq_1822000108__10 = ifn_859.Invoke_O__O(arg_860) } else { seq_1822000108__10 = linked_858.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_857, arg_860) }; var chunk_1822000109__11 any; var count_1822000110__12 int64 = 0; var i_1822000111__13 int64 = 0; L1:
//line :231:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1822000111__13, count_1822000110__12) { var k__14 any = lang.Indexed_Cast(chunk_1822000109__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1822000111__13)); var tmp1 any; var root_881 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_883 lang.IFn
			if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__14)); var arg_885 any = names__9; if linked_882 == nil { tmp1 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp1 = linked_882.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil, Lit_40, nil); var tmp3 any; var root_886 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_go_type_names_A_fn_class); var ifn_888 lang.IFn

				if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = ts__1; if linked_887 == nil { tmp3 = ifn_888.Invoke_O__O(arg_889) } else { tmp3 = linked_887.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_886, arg_889) }
//line :238:1
				panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__14, nil, tmp3))))) }
//line :237:1
			seq_1822000108__10, chunk_1822000109__11, count_1822000110__12, i_1822000111__13 = seq_1822000108__10, chunk_1822000109__11, count_1822000110__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1822000111__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_865 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = seq_1822000108__10; if linked_866 == nil { temp__1927000414__auto____14 = ifn_867.Invoke_O__O(arg_868) } else { temp__1927000414__auto____14 = linked_866.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1822000108__15 any = temp__1927000414__auto____14; var tmp4 any; var root_869 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = seq_1822000108__15; if linked_870 == nil { tmp4 = ifn_871.Invoke_O__O(arg_872) } else { tmp4 = linked_870.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____16 any; var root_873 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = seq_1822000108__15; if linked_874 == nil { c__1927000678__auto____16 = ifn_875.Invoke_O__O(arg_876) } else { c__1927000678__auto____16 = linked_874.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_873, arg_876) }; var tmp5 any; var root_890 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = seq_1822000108__15; if linked_891 == nil { tmp5 = ifn_892.Invoke_O__O(arg_893) } else { tmp5 = linked_891.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_890, arg_893) }; seq_1822000108__10, chunk_1822000109__11, count_1822000110__12, i_1822000111__13 = tmp5, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__16 any; var root_877 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = seq_1822000108__15; if linked_878 == nil { k__16 = ifn_879.Invoke_O__O(arg_880) } else { k__16 = linked_878.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_877, arg_880) }
				var tmp6 any; var root_894 any = A_arbace_go_A_const_102.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__16)); var arg_898 any = names__9; if linked_895 == nil { tmp6 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { tmp6 = linked_895.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }; if jrt.J2g_Truth(tmp6) { } else { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil, Lit_40, nil); var tmp8 any; var root_899 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_go_type_names_A_fn_class); var ifn_901 lang.IFn

					if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = ts__1; if linked_900 == nil { tmp8 = ifn_901.Invoke_O__O(arg_902) } else { tmp8 = linked_900.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_899, arg_902) }
//line :238:1
					panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, k__16, nil, tmp8))))) }
//line :237:1
				var tmp9 any; var root_903 any = A_arbace_go_A_const_22.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = seq_1822000108__15; if linked_904 == nil { tmp9 = ifn_905.Invoke_O__O(arg_906) } else { tmp9 = linked_904.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_903, arg_906) }; seq_1822000108__10, chunk_1822000109__11, count_1822000110__12, i_1822000111__13 = tmp9, nil, 0, 0; continue L1 } } }
//line :231:1
		break L1 }; var tmp10 any; var root_785 any =









	A_arbace_go_A_const_90.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_787 lang.IFn; if
	linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = t__8; var arg_789 any; var iter__1927001039__auto____10 any; var tmp11 any = A_arbace_go_reify_data_iter__1822000112__1822000116_A_New_O_O(fns__2, ts__1); var tmp12 *jrt.Class; var fncls__856 *jrt.Class = A_arbace_go_reify_data_iter__1822000112__1822000116_A_fn_class; if fncls__856 == nil { var fncls__856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_reify_data_iter__1822000112__1822000116_A_fn_class = fncls__856d; tmp12 = fncls__856d } else { tmp12 = fncls__856 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_789 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(names__9); if linked_786 == nil { tmp10 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { tmp10 = linked_786.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; return /*line :241:1*/ lang.RT_Object_array_O__O1_NoInit(tmp10).Ref() }
func A_arbace_go_reify_data_iter__1822000112__1822000116_A_New_O_O(p0, p1 any) *A_arbace_go_reify_data_iter__1822000112__1822000116_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000112__1822000116_A{}; t.Ctor_O_O(p0, p1); return t }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_A) Ctor_O_O(c__fns, c__ts any) { t.F_fns = c__fns; t.F_ts = c__ts }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_A) Invoke_O_O__O(self, s__1822000113__1 any) any { var tmp1 any = A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_New_O_O_O_O(self, t.F_fns, s__1822000113__1, t.F_ts); var tmp2 *jrt.Class; var fncls__855 *jrt.Class = A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_fn_class; if fncls__855 == nil { var fncls__855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_fn_class = fncls__855d; tmp2 = fncls__855d } else { tmp2 = fncls__855 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :242:1
func A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A) Ctor_O_O_O_O(c__iter__1822000112, c__fns, c__s__1822000113, c__ts any) { t.F_iter__1822000112 = c__iter__1822000112; t.F_fns = c__fns; t.F_s__1822000113 = c__s__1822000113; t.F_ts = c__ts }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A) Invoke_O__O(self any) any { { var s__1822000113__1 any; var t_ any = t.F_s__1822000113; t.F_s__1822000113 = nil; s__1822000113__1 = t_; for { var temp__1927000414__auto____2 any; var root_790 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = s__1822000113__1; if linked_791 == nil { temp__1927000414__auto____2 = ifn_792.Invoke_O__O(arg_793) } else { temp__1927000414__auto____2 = linked_791.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_790, arg_793) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1822000113__3 any = temp__1927000414__auto____2; var tmp1 any; var root_794 any = A_arbace_go_A_const_82.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = s__1822000113__3; if linked_795 == nil { tmp1 = ifn_796.Invoke_O__O(arg_797) } else { tmp1 = linked_795.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_794, arg_797) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_798 any = A_arbace_go_A_const_83.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = s__1822000113__3; if linked_799 == nil { c__1927001037__auto____4 = ifn_800.Invoke_O__O(arg_801) } else { c__1927001037__auto____4 = linked_799.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_798, arg_801) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1822000115__6 any; var root_802 any = A_arbace_go_A_const_84.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_803 == nil { b__1822000115__6 = ifn_804.Invoke_O__O(arg_805) } else { b__1822000115__6 = linked_803.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_802, arg_805) }; var tmp2 any = A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_New_O_O_I_O_O(t.F_fns, b__1822000115__6, size__1927001038__auto____5, t.F_ts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__815 *jrt.Class = A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_fn_class; if fncls__815 == nil { var fncls__815d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_fn_class = fncls__815d; tmp3 = fncls__815d } else { tmp3 = fncls__815 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_816 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_821 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = b__1822000115__6; if linked_822 == nil { arg_819 = ifn_823.Invoke_O__O(arg_824) } else { arg_819 = linked_822.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_821, arg_824) }; var arg_820 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1822000112); var tmp5 any; var root_825 any = A_arbace_go_A_const_89.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = s__1822000113__3; if linked_826 == nil { tmp5 = ifn_827.Invoke_O__O(arg_828) } else { tmp5 = linked_826.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_825, arg_828) }; arg_820 = tmp4.Invoke_O__O(tmp5); if linked_817 == nil { return ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { return linked_817.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } } else { var root_829 any = A_arbace_go_A_const_87.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var root_834 any = A_arbace_go_A_const_88.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = b__1822000115__6; if linked_835 == nil { arg_832 = ifn_836.Invoke_O__O(arg_837) } else { arg_832 = linked_835.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_834, arg_837) }; var arg_833 any; if linked_830 == nil { return ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { return linked_830.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) } } } else { var n__4 any; var root_838 any = A_arbace_go_A_const_25.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = s__1822000113__3; if linked_839 == nil { n__4 = ifn_840.Invoke_O__O(arg_841) } else { n__4 = linked_839.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_838, arg_841) }; var root_842 any = A_arbace_go_A_const_90.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__4)
														if jrt.J2g_Truth(or__1927000174__auto____5) { arg_845 = or__1927000174__auto____5 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45, nil, Lit_46); var tmp7 any; var root_847 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, A_arbace_go_type_names_A_fn_class); var ifn_849 lang.IFn

		if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = t.F_ts; if linked_848 == nil { tmp7 = ifn_849.Invoke_O__O(arg_850) } else { tmp7 = linked_848.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_847, arg_850) }
//line :243:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp7, nil))))) }
//line :242:1
	var arg_846 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1822000112); var tmp9 any; var root_851 any = A_arbace_go_A_const_44.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_853 lang.IFn; if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = s__1822000113__3; if linked_852 == nil { tmp9 = ifn_853.Invoke_O__O(arg_854) } else { tmp9 = linked_852.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_851, arg_854) }; arg_846 = tmp8.Invoke_O__O(tmp9); if linked_843 == nil { return ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { return linked_843.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :242:1
func A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A { A_arbace_go_A_Init(); t := &A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A) Ctor_O_O_I_O_O(c__fns, c__b__1822000115 any, c__size__1927001038__auto__ int32, c__ts, c__c__1927001037__auto__ any) { t.F_fns = c__fns; t.F_b__1822000115 = c__b__1822000115; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ts = c__ts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :242:1
func (t *A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A) Invoke_O__O(self any) any { { var i__1822000114__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1822000114__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1822000114__1)); var root_806 any = A_arbace_go_A_const_85.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = t.F_b__1822000115; var arg_810 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_fns, n__2)
															if jrt.J2g_Truth(or__1927000174__auto____3) { arg_810 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45, nil, Lit_46); var tmp3 any; var root_811 any = A_arbace_go_A_const_101.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, A_arbace_go_type_names_A_fn_class); var ifn_813 lang.IFn

		if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = t.F_ts; if linked_812 == nil { tmp3 = ifn_813.Invoke_O__O(arg_814) } else { tmp3 = linked_812.(*A_arbace_go_type_names_A).Invoke_O_O__O(root_811, arg_814) }
//line :243:1
		panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp3, nil))))) }
//line :242:1
	if linked_807 == nil { ifn_808.Invoke_O_O__O(arg_809, arg_810) } else { linked_807.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_806, arg_809, arg_810) }; i__1822000114__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1822000114__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_fn_A_New() *A_arbace_go_repl_fn_A { A_arbace_go_A_Init(); t := &A_arbace_go_repl_fn_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_repl_fn_A) Ctor() {}
//line :250:1
func (t *A_arbace_go_repl_fn_A) Invoke_O_O__O(self, nm__0 any) any { var root_907 any = A_arbace_go_A_const_103.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any; var root_911 any = A_arbace_go_A_const_9.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = Lit_47; var arg_915 any = nm__0; if linked_912 == nil { arg_910 = ifn_913.Invoke_O_O__O(arg_914, arg_915) } else { arg_910 = linked_912.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_911, arg_914, arg_915) }; if linked_908 == nil { return ifn_909.Invoke_O__O(arg_910) } else { return linked_908.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_907, arg_910) } }

func A_arbace_go_pos_of_A_New() *A_arbace_go_pos_of_A { A_arbace_go_A_Init(); t := &A_arbace_go_pos_of_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_pos_of_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_pos_of_A) Invoke_O_O__O(self, form__0 any) any { var root_916 any = A_arbace_go_A_const_104.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__0); var arg_920 any = A_arbace_go_A_const_105; if linked_917 == nil { return ifn_918.Invoke_O_O__O(arg_919, arg_920) } else { return linked_917.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_916, arg_919, arg_920) } }

func A_arbace_go_package_A_New() *A_arbace_go_package_A { A_arbace_go_A_Init(); t := &A_arbace_go_package_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_go_package_A) Ctor() {}
//line :254:1
func (t *A_arbace_go_package_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_921 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_932 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var root_936 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_106); var arg_940 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_29); if linked_937 == nil { arg_935 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { arg_935 = linked_937.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; if linked_933 == nil { tmp3 = ifn_934.Invoke_O__O(arg_935) } else { tmp3 = linked_933.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_932, arg_935) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_941 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var root_945 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_949 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_950 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_952 lang.IFn; if


	linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = A_arbace_go_A_const_109.Get__O(); if linked_951 == nil { tmp8 = ifn_952.Invoke_O__O(arg_953) } else { tmp8 = linked_951.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_950, arg_953) }; arg_949 = /*line :254:1*/tmp7.Invoke_O__O(tmp8); if linked_946 == nil { arg_944 = ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { arg_944 = linked_946.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }; if linked_942 == nil { tmp6 = ifn_943.Invoke_O__O(arg_944) } else { tmp6 = linked_942.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_941, arg_944) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_954 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any; var root_958 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_962 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(nm__2); if linked_959 == nil { arg_957 = ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { arg_957 = linked_959.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) }; if linked_955 == nil { tmp11 = ifn_956.Invoke_O__O(arg_957) } else { tmp11 = linked_955.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_954, arg_957) }; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp14 any; var root_963 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any; var root_967 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_971 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp16 any; var root_972 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_974 lang.IFn; if


	linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = opts__3; if linked_973 == nil { tmp16 = ifn_974.Invoke_O__O(arg_975) } else { tmp16 = linked_973.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_972, arg_975) }; arg_971 = /*line :254:1*/tmp15.Invoke_O__O(tmp16); if linked_968 == nil { arg_966 = ifn_969.Invoke_O_O__O(arg_970, arg_971) } else { arg_966 = linked_968.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_967, arg_970, arg_971) }; if linked_964 == nil { tmp14 = ifn_965.Invoke_O__O(arg_966) } else { tmp14 = linked_964.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_963, arg_966) }; arg_924 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_922 == nil { return ifn_923.Invoke_O__O(arg_924) } else { return linked_922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_921, arg_924) } }




func A_arbace_go_file_A_New() *A_arbace_go_file_A { A_arbace_go_A_Init(); t := &A_arbace_go_file_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_file_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_file_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nm__2, opts__3 any) any { var root_976 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_987 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var root_991 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_110); var arg_995 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_25); if linked_992 == nil { arg_990 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { arg_990 = linked_992.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }; if linked_988 == nil { tmp3 = ifn_989.Invoke_O__O(arg_990) } else { tmp3 = linked_988.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_987, arg_990) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_996 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var root_1000 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1004 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_1005 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1007 lang.IFn; if


	linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = A_arbace_go_A_const_109.Get__O(); if linked_1006 == nil { tmp8 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp8 = linked_1006.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1005, arg_1008) }; arg_1004 = /*line :259:1*/tmp7.Invoke_O__O(tmp8); if linked_1001 == nil { arg_999 = ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { arg_999 = linked_1001.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }; if linked_997 == nil { tmp6 = ifn_998.Invoke_O__O(arg_999) } else { tmp6 = linked_997.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_996, arg_999) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(nm__2); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp12 any; var root_1009 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1013 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1017 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp14 any; var root_1018 any = A_arbace_go_A_const_10.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1020 lang.IFn; if


	linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = A_arbace_go_A_const_31.GetRawRoot__O(); var arg_1022 any = opts__3; if linked_1019 == nil { tmp14 = ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { tmp14 = linked_1019.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) }; arg_1017 = /*line :259:1*/tmp13.Invoke_O__O(tmp14); if linked_1014 == nil { arg_1012 = ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { arg_1012 = linked_1014.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; if linked_1010 == nil { tmp12 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp12 = linked_1010.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1009, arg_1012) }; arg_979 = tmp1.Invoke_O_O_O_O__O(tmp4, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_977 == nil { return ifn_978.Invoke_O__O(arg_979) } else { return linked_977.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_976, arg_979) } }




func A_arbace_go_declare_STAR__A_New() *A_arbace_go_declare_STAR__A { A_arbace_go_A_Init(); t := &A_arbace_go_declare_STAR__A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_go_declare_STAR__A) Ctor() {}
//line :264:1
func (t *A_arbace_go_declare_STAR__A) Invoke_O_O_O__O(self, form__0, opts__1 any) any {


	var tmp1 any; var root_1023 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, A_arbace_go_repl_fn_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = Lit_8; if linked_1024 == nil { tmp1 = ifn_1025.Invoke_O__O(arg_1026) } else { tmp1 = linked_1024.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1023, arg_1026) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(form__0, opts__1)
}
func A_arbace_go_func_A_New() *A_arbace_go_func_A { A_arbace_go_A_Init(); t := &A_arbace_go_func_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_go_func_A) Ctor() {}
//line :269:1
func (t *A_arbace_go_func_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1027 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_112); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1037 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var root_1041 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1045 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1042 == nil { arg_1040 = ifn_1043.Invoke_O_O__O(arg_1044, arg_1045) } else { arg_1040 = linked_1042.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1041, arg_1044, arg_1045) }; if linked_1038 == nil { tmp4 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp4 = linked_1038.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1037, arg_1040) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1046 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any; var root_1050 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1054 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1055 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1057 lang.IFn; if
														linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any; var root_1061 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_go_pos_of_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = _AMPERSAND_form__0; if linked_1062 == nil { arg_1058 = ifn_1063.Invoke_O__O(arg_1064) } else { arg_1058 = linked_1062.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1061, arg_1064) }; var arg_1059 any = A_arbace_go_A_const_114; var arg_1060 any; var root_1065 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = A_arbace_go_A_const_109.Get__O(); if linked_1066 == nil { arg_1060 = ifn_1067.Invoke_O__O(arg_1068) } else { arg_1060 = linked_1066.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1065, arg_1068) }; if linked_1056 == nil { tmp9 = ifn_1057.Invoke_O_O_O__O(arg_1058, arg_1059, arg_1060) } else { tmp9 = linked_1056.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060) }; arg_1054 = /*line :269:1*/tmp8.Invoke_O__O(tmp9); if linked_1051 == nil { arg_1049 = ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { arg_1049 = linked_1051.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; if linked_1047 == nil { tmp7 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp7 = linked_1047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1046, arg_1049) }; arg_1030 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1028 == nil { return ifn_1029.Invoke_O__O(arg_1030) } else { return linked_1028.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1027, arg_1030) } }


func A_arbace_go_method_A_New() *A_arbace_go_method_A { A_arbace_go_A_Init(); t := &A_arbace_go_method_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_go_method_A) Ctor() {}
//line :272:1
func (t *A_arbace_go_method_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1069 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_115); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1079 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var root_1083 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1087 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1084 == nil { arg_1082 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { arg_1082 = linked_1084.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) }; if linked_1080 == nil { tmp4 = ifn_1081.Invoke_O__O(arg_1082) } else { tmp4 = linked_1080.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1079, arg_1082) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1088 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any; var root_1092 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1096 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1097 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1099 lang.IFn; if
														linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any; var root_1103 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, A_arbace_go_pos_of_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = _AMPERSAND_form__0; if linked_1104 == nil { arg_1100 = ifn_1105.Invoke_O__O(arg_1106) } else { arg_1100 = linked_1104.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1103, arg_1106) }; var arg_1101 any = A_arbace_go_A_const_114; var arg_1102 any; var root_1107 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = A_arbace_go_A_const_109.Get__O(); if linked_1108 == nil { arg_1102 = ifn_1109.Invoke_O__O(arg_1110) } else { arg_1102 = linked_1108.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1107, arg_1110) }; if linked_1098 == nil { tmp9 = ifn_1099.Invoke_O_O_O__O(arg_1100, arg_1101, arg_1102) } else { tmp9 = linked_1098.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1097, arg_1100, arg_1101, arg_1102) }; arg_1096 = /*line :272:1*/tmp8.Invoke_O__O(tmp9); if linked_1093 == nil { arg_1091 = ifn_1094.Invoke_O_O__O(arg_1095, arg_1096) } else { arg_1091 = linked_1093.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1092, arg_1095, arg_1096) }; if linked_1089 == nil { tmp7 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp7 = linked_1089.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1088, arg_1091) }; arg_1072 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1070 == nil { return ifn_1071.Invoke_O__O(arg_1072) } else { return linked_1070.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1069, arg_1072) } }


func A_arbace_go_type_A_New() *A_arbace_go_type_A { A_arbace_go_A_Init(); t := &A_arbace_go_type_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_go_type_A) Ctor() {}
//line :275:1
func (t *A_arbace_go_type_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1111 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_116); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1121 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any; var root_1125 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1129 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1126 == nil { arg_1124 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { arg_1124 = linked_1126.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) }; if linked_1122 == nil { tmp4 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp4 = linked_1122.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1121, arg_1124) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1130 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any; var root_1134 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1138 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1139 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1141 lang.IFn; if
														linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1145 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, A_arbace_go_pos_of_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = _AMPERSAND_form__0; if linked_1146 == nil { arg_1142 = ifn_1147.Invoke_O__O(arg_1148) } else { arg_1142 = linked_1146.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1145, arg_1148) }; var arg_1143 any = A_arbace_go_A_const_114; var arg_1144 any; var root_1149 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_go_A_const_109.Get__O(); if linked_1150 == nil { arg_1144 = ifn_1151.Invoke_O__O(arg_1152) } else { arg_1144 = linked_1150.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1149, arg_1152) }; if linked_1140 == nil { tmp9 = ifn_1141.Invoke_O_O_O__O(arg_1142, arg_1143, arg_1144) } else { tmp9 = linked_1140.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1139, arg_1142, arg_1143, arg_1144) }; arg_1138 = /*line :275:1*/tmp8.Invoke_O__O(tmp9); if linked_1135 == nil { arg_1133 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { arg_1133 = linked_1135.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; if linked_1131 == nil { tmp7 = ifn_1132.Invoke_O__O(arg_1133) } else { tmp7 = linked_1131.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1130, arg_1133) }; arg_1114 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1112 == nil { return ifn_1113.Invoke_O__O(arg_1114) } else { return linked_1112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1111, arg_1114) } }


func A_arbace_go_var_A_New() *A_arbace_go_var_A { A_arbace_go_A_Init(); t := &A_arbace_go_var_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_go_var_A) Ctor() {}
//line :278:1
func (t *A_arbace_go_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1153 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_117); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1163 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1167 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1171 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1168 == nil { arg_1166 = ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { arg_1166 = linked_1168.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) }; if linked_1164 == nil { tmp4 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp4 = linked_1164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1163, arg_1166) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1172 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any; var root_1176 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1180 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1181 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1183 lang.IFn; if
														linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any; var root_1187 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_go_pos_of_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = _AMPERSAND_form__0; if linked_1188 == nil { arg_1184 = ifn_1189.Invoke_O__O(arg_1190) } else { arg_1184 = linked_1188.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1187, arg_1190) }; var arg_1185 any = A_arbace_go_A_const_114; var arg_1186 any; var root_1191 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = A_arbace_go_A_const_109.Get__O(); if linked_1192 == nil { arg_1186 = ifn_1193.Invoke_O__O(arg_1194) } else { arg_1186 = linked_1192.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1191, arg_1194) }; if linked_1182 == nil { tmp9 = ifn_1183.Invoke_O_O_O__O(arg_1184, arg_1185, arg_1186) } else { tmp9 = linked_1182.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1181, arg_1184, arg_1185, arg_1186) }; arg_1180 = /*line :278:1*/tmp8.Invoke_O__O(tmp9); if linked_1177 == nil { arg_1175 = ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { arg_1175 = linked_1177.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) }; if linked_1173 == nil { tmp7 = ifn_1174.Invoke_O__O(arg_1175) } else { tmp7 = linked_1173.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1172, arg_1175) }; arg_1156 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1154 == nil { return ifn_1155.Invoke_O__O(arg_1156) } else { return linked_1154.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1153, arg_1156) } }


func A_arbace_go_const_A_New() *A_arbace_go_const_A { A_arbace_go_A_Init(); t := &A_arbace_go_const_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_go_const_A) Ctor() {}
//line :281:1
func (t *A_arbace_go_const_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_1195 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_118); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp4 any; var root_1205 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any; var root_1209 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1213 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_1210 == nil { arg_1208 = ifn_1211.Invoke_O_O__O(arg_1212, arg_1213) } else { arg_1208 = linked_1210.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1209, arg_1212, arg_1213) }; if linked_1206 == nil { tmp4 = ifn_1207.Invoke_O__O(arg_1208) } else { tmp4 = linked_1206.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1205, arg_1208) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp7 any; var root_1214 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any; var root_1218 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1222 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp9 any; var root_1223 any = A_arbace_go_A_const_61.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1225 lang.IFn; if
														linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any; var root_1229 any = A_arbace_go_A_const_113.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, A_arbace_go_pos_of_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = _AMPERSAND_form__0; if linked_1230 == nil { arg_1226 = ifn_1231.Invoke_O__O(arg_1232) } else { arg_1226 = linked_1230.(*A_arbace_go_pos_of_A).Invoke_O_O__O(root_1229, arg_1232) }; var arg_1227 any = A_arbace_go_A_const_114; var arg_1228 any; var root_1233 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = A_arbace_go_A_const_109.Get__O(); if linked_1234 == nil { arg_1228 = ifn_1235.Invoke_O__O(arg_1236) } else { arg_1228 = linked_1234.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1233, arg_1236) }; if linked_1224 == nil { tmp9 = ifn_1225.Invoke_O_O_O__O(arg_1226, arg_1227, arg_1228) } else { tmp9 = linked_1224.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1223, arg_1226, arg_1227, arg_1228) }; arg_1222 = /*line :281:1*/tmp8.Invoke_O__O(tmp9); if linked_1219 == nil { arg_1217 = ifn_1220.Invoke_O_O__O(arg_1221, arg_1222) } else { arg_1217 = linked_1219.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1218, arg_1221, arg_1222) }; if linked_1215 == nil { tmp7 = ifn_1216.Invoke_O__O(arg_1217) } else { tmp7 = linked_1215.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1214, arg_1217) }; arg_1198 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_1196 == nil { return ifn_1197.Invoke_O__O(arg_1198) } else { return linked_1196.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1195, arg_1198) } }


func A_arbace_go_directive_A_New() *A_arbace_go_directive_A { A_arbace_go_A_Init(); t := &A_arbace_go_directive_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_directive_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_go_import_A_New() *A_arbace_go_import_A { A_arbace_go_A_Init(); t := &A_arbace_go_import_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_import_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_import_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, specs__2 any) any { var root_1237 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_1247 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any; var root_1251 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_119); var arg_1255 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_27); if linked_1252 == nil { arg_1250 = ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { arg_1250 = linked_1252.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) }; if linked_1248 == nil { tmp3 = ifn_1249.Invoke_O__O(arg_1250) } else { tmp3 = linked_1248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1247, arg_1250) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_1256 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1260 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1264 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_1265 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1267 lang.IFn; if


	linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = A_arbace_go_A_const_109.Get__O(); if linked_1266 == nil { tmp8 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp8 = linked_1266.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1265, arg_1268) }; arg_1264 = /*line :286:1*/tmp7.Invoke_O__O(tmp8); if linked_1261 == nil { arg_1259 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { arg_1259 = linked_1261.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) }; if linked_1257 == nil { tmp6 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp6 = linked_1257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1256, arg_1259) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_1269 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any; var root_1273 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1277 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp13 any; var root_1278 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1280 lang.IFn; if


	linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = specs__2; if linked_1279 == nil { tmp13 = ifn_1280.Invoke_O__O(arg_1281) } else { tmp13 = linked_1279.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1278, arg_1281) }; arg_1277 = /*line :286:1*/tmp12.Invoke_O__O(tmp13); if linked_1274 == nil { arg_1272 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { arg_1272 = linked_1274.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; if linked_1270 == nil { tmp11 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp11 = linked_1270.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1269, arg_1272) }; arg_1240 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1238 == nil { return ifn_1239.Invoke_O__O(arg_1240) } else { return linked_1238.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1237, arg_1240) } }




func A_arbace_go_eval_A_New() *A_arbace_go_eval_A { A_arbace_go_A_Init(); t := &A_arbace_go_eval_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_eval_A) Ctor() {}
//line :291:1
func (t *A_arbace_go_eval_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, stmts__2 any) any { var root_1282 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_97.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp3 any; var root_1292 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any; var root_1296 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_120); var arg_1300 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_17); if linked_1297 == nil { arg_1295 = ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { arg_1295 = linked_1297.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) }; if linked_1293 == nil { tmp3 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp3 = linked_1293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1292, arg_1295) }; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp6 any; var root_1301 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var root_1305 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1309 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp8 any; var root_1310 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1312 lang.IFn; if



	linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = stmts__2; if linked_1311 == nil { tmp8 = ifn_1312.Invoke_O__O(arg_1313) } else { tmp8 = linked_1311.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1310, arg_1313) }; arg_1309 = /*line :291:1*/tmp7.Invoke_O__O(tmp8); if linked_1306 == nil { arg_1304 = ifn_1307.Invoke_O_O__O(arg_1308, arg_1309) } else { arg_1304 = linked_1306.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1305, arg_1308, arg_1309) }; if linked_1302 == nil { tmp6 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp6 = linked_1302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1301, arg_1304) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp11 any; var root_1314 any = A_arbace_go_A_const_24.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any; var root_1318 any = A_arbace_go_A_const_97.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_A_const_107); var arg_1322 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_A_const_64.GetRawRoot__O()); var tmp13 any = A_arbace_go_A_const_114; var tmp14 any; var root_1323 any = A_arbace_go_A_const_108.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1325 lang.IFn; if



	linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = A_arbace_go_A_const_109.Get__O(); if linked_1324 == nil { tmp14 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp14 = linked_1324.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1323, arg_1326) }; arg_1322 = /*line :291:1*/tmp12.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14))); if linked_1319 == nil { arg_1317 = ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { arg_1317 = linked_1319.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) }; if linked_1315 == nil { tmp11 = ifn_1316.Invoke_O__O(arg_1317) } else { tmp11 = linked_1315.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1314, arg_1317) }; arg_1285 = tmp1.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1283 == nil { return ifn_1284.Invoke_O__O(arg_1285) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1282, arg_1285) } }





func A_arbace_go_run_main_A_New() *A_arbace_go_run_main_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_main_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_go_run_main_A) Ctor() {}
//line :297:1
func (t *A_arbace_go_run_main_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1327 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, A_arbace_go_repl_fn_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = Lit_49; if linked_1328 == nil { tmp1 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp1 = linked_1328.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1327, arg_1330) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}
func A_arbace_go_run_compiled_A_New() *A_arbace_go_run_compiled_A { A_arbace_go_A_Init(); t := &A_arbace_go_run_compiled_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_go_run_compiled_A) Ctor() {}
//line :302:1
func (t *A_arbace_go_run_compiled_A) DoInvoke_O_O_O__O(self, ns_sym__0, args__1 any) any {



	var tmp1 any; var root_1331 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, A_arbace_go_repl_fn_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = Lit_48; if linked_1332 == nil { tmp1 = ifn_1333.Invoke_O__O(arg_1334) } else { tmp1 = linked_1332.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1331, arg_1334) }; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var root_1335 any = A_arbace_go_A_const_33.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = args__1; if linked_1336 == nil { tmp3 = ifn_1337.Invoke_O__O(arg_1338) } else { tmp3 = linked_1336.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1335, arg_1338) }; return tmp2.Invoke_O_O__O(ns_sym__0, tmp3)
}
func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_go_check_A) Ctor() {}
//line :308:1
func (t *A_arbace_go_check_A) Invoke_O_O__O(self, ns_sym__0 any) any {


	var tmp1 any; var root_1339 any = A_arbace_go_A_const_111.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, A_arbace_go_repl_fn_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = Lit_1; if linked_1340 == nil { tmp1 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp1 = linked_1340.(*A_arbace_go_repl_fn_A).Invoke_O_O__O(root_1339, arg_1342) }; return lang.IFn_Cast(tmp1).Invoke_O__O(ns_sym__0)
}























































































type A_arbace_go_A struct{ jrt.Object }

var A_arbace_go_A_const_pool *jrt.RefArray

var A_arbace_go_A_const_0 *lang.Var

var A_arbace_go_A_const_1 any

var A_arbace_go_A_const_2 *lang.Keyword

var A_arbace_go_A_const_3 any

var A_arbace_go_A_const_4 *lang.Var

var A_arbace_go_A_const_5 *lang.Var

var A_arbace_go_A_const_6 *lang.Var

var A_arbace_go_A_const_7 *lang.Var

var A_arbace_go_A_const_8 any

var A_arbace_go_A_const_9 *lang.Var

var A_arbace_go_A_const_10 *lang.Var

var A_arbace_go_A_const_11 *lang.Var

var A_arbace_go_A_const_12 *lang.Var

var A_arbace_go_A_const_13 *lang.Var

var A_arbace_go_A_const_14 *jrt.Class

var A_arbace_go_A_const_15 *lang.Keyword

var A_arbace_go_A_const_16 *lang.Var

var A_arbace_go_A_const_17 *lang.Var

var A_arbace_go_A_const_18 any

var A_arbace_go_A_const_19 *lang.Keyword

var A_arbace_go_A_const_20 *lang.Keyword

var A_arbace_go_A_const_21 *lang.Var

var A_arbace_go_A_const_22 *lang.Var

var A_arbace_go_A_const_23 *lang.Var

var A_arbace_go_A_const_24 *lang.Var

var A_arbace_go_A_const_25 *lang.Var

var A_arbace_go_A_const_26 *lang.Var

var A_arbace_go_A_const_27 any

var A_arbace_go_A_const_28 *lang.Keyword

var A_arbace_go_A_const_29 *lang.Var

var A_arbace_go_A_const_30 *lang.Var

var A_arbace_go_A_const_31 *lang.Var

var A_arbace_go_A_const_32 *lang.Var

var A_arbace_go_A_const_33 *lang.Var

var A_arbace_go_A_const_34 *lang.Var

var A_arbace_go_A_const_35 any

var A_arbace_go_A_const_36 any

var A_arbace_go_A_const_37 *lang.Var

var A_arbace_go_A_const_38 *lang.Keyword

var A_arbace_go_A_const_39 *lang.Var

var A_arbace_go_A_const_40 any

var A_arbace_go_A_const_41 *lang.Var

var A_arbace_go_A_const_42 *lang.Keyword

var A_arbace_go_A_const_43 *lang.Var

var A_arbace_go_A_const_44 *lang.Var

var A_arbace_go_A_const_45 *lang.Var

var A_arbace_go_A_const_46 *lang.Var

var A_arbace_go_A_const_47 *lang.Var

var A_arbace_go_A_const_48 *lang.Var

var A_arbace_go_A_const_49 *lang.Var

var A_arbace_go_A_const_50 any

var A_arbace_go_A_const_51 *lang.Var

var A_arbace_go_A_const_52 *lang.Var

var A_arbace_go_A_const_53 *lang.Var

var A_arbace_go_A_const_54 *lang.Var

var A_arbace_go_A_const_55 *lang.Var

var A_arbace_go_A_const_56 *lang.Var

var A_arbace_go_A_const_57 *lang.Var

var A_arbace_go_A_const_58 *lang.Var

var A_arbace_go_A_const_59 any

var A_arbace_go_A_const_60 *lang.Keyword

var A_arbace_go_A_const_61 *lang.Var

var A_arbace_go_A_const_62 *lang.Keyword

var A_arbace_go_A_const_63 *lang.Keyword

var A_arbace_go_A_const_64 *lang.Var

var A_arbace_go_A_const_65 *lang.Var

var A_arbace_go_A_const_66 *lang.Keyword

var A_arbace_go_A_const_67 *lang.Var

var A_arbace_go_A_const_68 *lang.Keyword

var A_arbace_go_A_const_69 *lang.Keyword

var A_arbace_go_A_const_70 *lang.Var

var A_arbace_go_A_const_71 *lang.Keyword

var A_arbace_go_A_const_72 *lang.Keyword

var A_arbace_go_A_const_73 *lang.Var

var A_arbace_go_A_const_74 *lang.Var

var A_arbace_go_A_const_75 *lang.Keyword

var A_arbace_go_A_const_76 *lang.Keyword

var A_arbace_go_A_const_77 *lang.Keyword

var A_arbace_go_A_const_78 *lang.Keyword

var A_arbace_go_A_const_79 *lang.Var

var A_arbace_go_A_const_80 *lang.Var

var A_arbace_go_A_const_81 *lang.Var

var A_arbace_go_A_const_82 *lang.Var

var A_arbace_go_A_const_83 *lang.Var

var A_arbace_go_A_const_84 *lang.Var

var A_arbace_go_A_const_85 *lang.Var

var A_arbace_go_A_const_86 *lang.Var

var A_arbace_go_A_const_87 *lang.Var

var A_arbace_go_A_const_88 *lang.Var

var A_arbace_go_A_const_89 *lang.Var

var A_arbace_go_A_const_90 *lang.Var

var A_arbace_go_A_const_91 *lang.Var

var A_arbace_go_A_const_92 any

var A_arbace_go_A_const_93 *lang.Var

var A_arbace_go_A_const_94 *lang.Var

var A_arbace_go_A_const_95 *lang.Var

var A_arbace_go_A_const_96 *lang.Var

var A_arbace_go_A_const_97 *lang.Var

var A_arbace_go_A_const_98 *lang.Var

var A_arbace_go_A_const_99 *lang.Var

var A_arbace_go_A_const_100 *lang.Var

var A_arbace_go_A_const_101 *lang.Var

var A_arbace_go_A_const_102 *lang.Var

var A_arbace_go_A_const_103 *lang.Var

var A_arbace_go_A_const_104 *lang.Var

var A_arbace_go_A_const_105 any

var A_arbace_go_A_const_106 any

var A_arbace_go_A_const_107 any

var A_arbace_go_A_const_108 *lang.Var

var A_arbace_go_A_const_109 *lang.Var

var A_arbace_go_A_const_110 any

var A_arbace_go_A_const_111 *lang.Var

var A_arbace_go_A_const_112 any

var A_arbace_go_A_const_113 *lang.Var

var A_arbace_go_A_const_114 *lang.Keyword

var A_arbace_go_A_const_115 any

var A_arbace_go_A_const_116 any

var A_arbace_go_A_const_117 any

var A_arbace_go_A_const_118 any

var A_arbace_go_A_const_119 any

var A_arbace_go_A_const_120 any

var A_arbace_go_A_init jrt.ClassInit

func A_arbace_go_A_Init() { if !A_arbace_go_A_init.Done() { A_arbace_go_A_init.Run(A_arbace_go_A_clinit) } }

func A_arbace_go_A_clinit() { A_arbace_go_A_clinit_p0(); A_arbace_go_A_clinit_p1(); A_arbace_go_A_clinit_p2(); A_arbace_go_A_clinit_p3(); A_arbace_go_A_clinit_p4(); A_arbace_go_A_clinit_p5(); A_arbace_go_A_clinit_p6(); A_arbace_go_A_clinit_p7(); A_arbace_go_A_clinit_p8(); A_arbace_go_A_clinit_p9() }

func A_arbace_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_go_A_const_0 = lang.Var_Cast(A_arbace_go_A_const_pool.A[35]); A_arbace_go_A_const_1 = A_arbace_go_A_const_pool.A[36]; A_arbace_go_A_const_2 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[37]); A_arbace_go_A_const_3 = A_arbace_go_A_const_pool.A[38]; A_arbace_go_A_const_4 = lang.Var_Cast(A_arbace_go_A_const_pool.A[39]); A_arbace_go_A_const_5 = lang.Var_Cast(A_arbace_go_A_const_pool.A[40]); A_arbace_go_A_const_6 = lang.Var_Cast(A_arbace_go_A_const_pool.A[41]); A_arbace_go_A_const_7 = lang.Var_Cast(A_arbace_go_A_const_pool.A[42]); A_arbace_go_A_const_8 = A_arbace_go_A_const_pool.A[43]; A_arbace_go_A_const_9 = lang.Var_Cast(A_arbace_go_A_const_pool.A[44]); A_arbace_go_A_const_10 = lang.Var_Cast(A_arbace_go_A_const_pool.A[45]); A_arbace_go_A_const_11 = lang.Var_Cast(A_arbace_go_A_const_pool.A[46]) }

func A_arbace_go_A_clinit_p1() { A_arbace_go_A_const_12 = lang.Var_Cast(A_arbace_go_A_const_pool.A[47]); A_arbace_go_A_const_13 = lang.Var_Cast(A_arbace_go_A_const_pool.A[48]); A_arbace_go_A_const_14 = jrt.Class_Cast(A_arbace_go_A_const_pool.A[49]); A_arbace_go_A_const_15 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[50]); A_arbace_go_A_const_16 = lang.Var_Cast(A_arbace_go_A_const_pool.A[51]); A_arbace_go_A_const_17 = lang.Var_Cast(A_arbace_go_A_const_pool.A[52]); A_arbace_go_A_const_18 = A_arbace_go_A_const_pool.A[53]; A_arbace_go_A_const_19 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[54]); A_arbace_go_A_const_20 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[55]); A_arbace_go_A_const_21 = lang.Var_Cast(A_arbace_go_A_const_pool.A[56]); A_arbace_go_A_const_22 = lang.Var_Cast(A_arbace_go_A_const_pool.A[57]); A_arbace_go_A_const_23 = lang.Var_Cast(A_arbace_go_A_const_pool.A[58]) }

func A_arbace_go_A_clinit_p2() { A_arbace_go_A_const_24 = lang.Var_Cast(A_arbace_go_A_const_pool.A[59]); A_arbace_go_A_const_25 = lang.Var_Cast(A_arbace_go_A_const_pool.A[60]); A_arbace_go_A_const_26 = lang.Var_Cast(A_arbace_go_A_const_pool.A[61]); A_arbace_go_A_const_27 = A_arbace_go_A_const_pool.A[62]; A_arbace_go_A_const_28 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[63]); A_arbace_go_A_const_29 = lang.Var_Cast(A_arbace_go_A_const_pool.A[64]); A_arbace_go_A_const_30 = lang.Var_Cast(A_arbace_go_A_const_pool.A[65]); A_arbace_go_A_const_31 = lang.Var_Cast(A_arbace_go_A_const_pool.A[66]); A_arbace_go_A_const_32 = lang.Var_Cast(A_arbace_go_A_const_pool.A[67]); A_arbace_go_A_const_33 = lang.Var_Cast(A_arbace_go_A_const_pool.A[68]); A_arbace_go_A_const_34 = lang.Var_Cast(A_arbace_go_A_const_pool.A[69]); A_arbace_go_A_const_35 = A_arbace_go_A_const_pool.A[70] }

func A_arbace_go_A_clinit_p3() { A_arbace_go_A_const_36 = A_arbace_go_A_const_pool.A[71]; A_arbace_go_A_const_37 = lang.Var_Cast(A_arbace_go_A_const_pool.A[72]); A_arbace_go_A_const_38 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[73]); A_arbace_go_A_const_39 = lang.Var_Cast(A_arbace_go_A_const_pool.A[74]); A_arbace_go_A_const_40 = A_arbace_go_A_const_pool.A[75]; A_arbace_go_A_const_41 = lang.Var_Cast(A_arbace_go_A_const_pool.A[76]); A_arbace_go_A_const_42 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[77]); A_arbace_go_A_const_43 = lang.Var_Cast(A_arbace_go_A_const_pool.A[78]); A_arbace_go_A_const_44 = lang.Var_Cast(A_arbace_go_A_const_pool.A[79]); A_arbace_go_A_const_45 = lang.Var_Cast(A_arbace_go_A_const_pool.A[80]); A_arbace_go_A_const_46 = lang.Var_Cast(A_arbace_go_A_const_pool.A[81]); A_arbace_go_A_const_47 = lang.Var_Cast(A_arbace_go_A_const_pool.A[82]) }

func A_arbace_go_A_clinit_p4() { A_arbace_go_A_const_48 = lang.Var_Cast(A_arbace_go_A_const_pool.A[83]); A_arbace_go_A_const_49 = lang.Var_Cast(A_arbace_go_A_const_pool.A[84]); A_arbace_go_A_const_50 = A_arbace_go_A_const_pool.A[85]; A_arbace_go_A_const_51 = lang.Var_Cast(A_arbace_go_A_const_pool.A[86]); A_arbace_go_A_const_52 = lang.Var_Cast(A_arbace_go_A_const_pool.A[87]); A_arbace_go_A_const_53 = lang.Var_Cast(A_arbace_go_A_const_pool.A[88]); A_arbace_go_A_const_54 = lang.Var_Cast(A_arbace_go_A_const_pool.A[89]); A_arbace_go_A_const_55 = lang.Var_Cast(A_arbace_go_A_const_pool.A[90]); A_arbace_go_A_const_56 = lang.Var_Cast(A_arbace_go_A_const_pool.A[91]); A_arbace_go_A_const_57 = lang.Var_Cast(A_arbace_go_A_const_pool.A[92]); A_arbace_go_A_const_58 = lang.Var_Cast(A_arbace_go_A_const_pool.A[93]); A_arbace_go_A_const_59 = A_arbace_go_A_const_pool.A[94] }

func A_arbace_go_A_clinit_p5() { A_arbace_go_A_const_60 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[95]); A_arbace_go_A_const_61 = lang.Var_Cast(A_arbace_go_A_const_pool.A[96]); A_arbace_go_A_const_62 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[97]); A_arbace_go_A_const_63 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[98]); A_arbace_go_A_const_64 = lang.Var_Cast(A_arbace_go_A_const_pool.A[99]); A_arbace_go_A_const_65 = lang.Var_Cast(A_arbace_go_A_const_pool.A[100]); A_arbace_go_A_const_66 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[101]); A_arbace_go_A_const_67 = lang.Var_Cast(A_arbace_go_A_const_pool.A[102]); A_arbace_go_A_const_68 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[103]); A_arbace_go_A_const_69 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[104]); A_arbace_go_A_const_70 = lang.Var_Cast(A_arbace_go_A_const_pool.A[105]); A_arbace_go_A_const_71 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[106]) }

func A_arbace_go_A_clinit_p6() { A_arbace_go_A_const_72 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[107]); A_arbace_go_A_const_73 = lang.Var_Cast(A_arbace_go_A_const_pool.A[108]); A_arbace_go_A_const_74 = lang.Var_Cast(A_arbace_go_A_const_pool.A[109]); A_arbace_go_A_const_75 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[110]); A_arbace_go_A_const_76 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[111]); A_arbace_go_A_const_77 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[112]); A_arbace_go_A_const_78 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[113]); A_arbace_go_A_const_79 = lang.Var_Cast(A_arbace_go_A_const_pool.A[114]); A_arbace_go_A_const_80 = lang.Var_Cast(A_arbace_go_A_const_pool.A[115]); A_arbace_go_A_const_81 = lang.Var_Cast(A_arbace_go_A_const_pool.A[116]); A_arbace_go_A_const_82 = lang.Var_Cast(A_arbace_go_A_const_pool.A[117]); A_arbace_go_A_const_83 = lang.Var_Cast(A_arbace_go_A_const_pool.A[118]) }

func A_arbace_go_A_clinit_p7() { A_arbace_go_A_const_84 = lang.Var_Cast(A_arbace_go_A_const_pool.A[119]); A_arbace_go_A_const_85 = lang.Var_Cast(A_arbace_go_A_const_pool.A[120]); A_arbace_go_A_const_86 = lang.Var_Cast(A_arbace_go_A_const_pool.A[121]); A_arbace_go_A_const_87 = lang.Var_Cast(A_arbace_go_A_const_pool.A[122]); A_arbace_go_A_const_88 = lang.Var_Cast(A_arbace_go_A_const_pool.A[123]); A_arbace_go_A_const_89 = lang.Var_Cast(A_arbace_go_A_const_pool.A[124]); A_arbace_go_A_const_90 = lang.Var_Cast(A_arbace_go_A_const_pool.A[125]); A_arbace_go_A_const_91 = lang.Var_Cast(A_arbace_go_A_const_pool.A[126]); A_arbace_go_A_const_92 = A_arbace_go_A_const_pool.A[127]; A_arbace_go_A_const_93 = lang.Var_Cast(A_arbace_go_A_const_pool.A[128]); A_arbace_go_A_const_94 = lang.Var_Cast(A_arbace_go_A_const_pool.A[129]); A_arbace_go_A_const_95 = lang.Var_Cast(A_arbace_go_A_const_pool.A[130]) }

func A_arbace_go_A_clinit_p8() { A_arbace_go_A_const_96 = lang.Var_Cast(A_arbace_go_A_const_pool.A[131]); A_arbace_go_A_const_97 = lang.Var_Cast(A_arbace_go_A_const_pool.A[132]); A_arbace_go_A_const_98 = lang.Var_Cast(A_arbace_go_A_const_pool.A[133]); A_arbace_go_A_const_99 = lang.Var_Cast(A_arbace_go_A_const_pool.A[134]); A_arbace_go_A_const_100 = lang.Var_Cast(A_arbace_go_A_const_pool.A[135]); A_arbace_go_A_const_101 = lang.Var_Cast(A_arbace_go_A_const_pool.A[136]); A_arbace_go_A_const_102 = lang.Var_Cast(A_arbace_go_A_const_pool.A[137]); A_arbace_go_A_const_103 = lang.Var_Cast(A_arbace_go_A_const_pool.A[138]); A_arbace_go_A_const_104 = lang.Var_Cast(A_arbace_go_A_const_pool.A[139]); A_arbace_go_A_const_105 = A_arbace_go_A_const_pool.A[140]; A_arbace_go_A_const_106 = A_arbace_go_A_const_pool.A[141]; A_arbace_go_A_const_107 = A_arbace_go_A_const_pool.A[142] }

func A_arbace_go_A_clinit_p9() { A_arbace_go_A_const_108 = lang.Var_Cast(A_arbace_go_A_const_pool.A[143]); A_arbace_go_A_const_109 = lang.Var_Cast(A_arbace_go_A_const_pool.A[144]); A_arbace_go_A_const_110 = A_arbace_go_A_const_pool.A[145]; A_arbace_go_A_const_111 = lang.Var_Cast(A_arbace_go_A_const_pool.A[146]); A_arbace_go_A_const_112 = A_arbace_go_A_const_pool.A[147]; A_arbace_go_A_const_113 = lang.Var_Cast(A_arbace_go_A_const_pool.A[148]); A_arbace_go_A_const_114 = lang.Keyword_Cast(A_arbace_go_A_const_pool.A[149]); A_arbace_go_A_const_115 = A_arbace_go_A_const_pool.A[150]; A_arbace_go_A_const_116 = A_arbace_go_A_const_pool.A[151]; A_arbace_go_A_const_117 = A_arbace_go_A_const_pool.A[152]; A_arbace_go_A_const_118 = A_arbace_go_A_const_pool.A[153]; A_arbace_go_A_const_119 = A_arbace_go_A_const_pool.A[154]; A_arbace_go_A_const_120 = A_arbace_go_A_const_pool.A[155] }

func A_arbace_go_A_New() *A_arbace_go_A { A_arbace_go_A_Init(); t := &A_arbace_go_A{}; t.Ctor(); return t }

func (t *A_arbace_go_A) Ctor() {}

func (t *A_arbace_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_A) GetClass__Class() *jrt.Class { return A_arbace_go_A_class }

func (t *A_arbace_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_A); return ok }

func A_arbace_go_A_Cast(x any) *A_arbace_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_A_class)) }; return v }



type A_arbace_go_assign_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_assign_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_A struct{ j2g_header uint64 }

var A_arbace_go_check_A_fn_class *jrt.Class



type A_arbace_go_const_A struct{ j2g_header uint64 }

var A_arbace_go_const_A_fn_class *jrt.Class



type A_arbace_go_const_value_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_A_fn_class *jrt.Class



type A_arbace_go_const_value_fn__1822000029_A struct{ j2g_header uint64 }

var A_arbace_go_const_value_fn__1822000029_A_fn_class *jrt.Class



type A_arbace_go_declare_STAR__A struct{ j2g_header uint64 }

var A_arbace_go_declare_STAR__A_fn_class *jrt.Class



type A_arbace_go_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_digest_info_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_A_fn_class *jrt.Class



type A_arbace_go_digest_info_fn__1822000032_A struct{ j2g_header uint64 }

var A_arbace_go_digest_info_fn__1822000032_A_fn_class *jrt.Class



type A_arbace_go_directive_A struct{ j2g_header uint64 }

var A_arbace_go_directive_A_fn_class *jrt.Class



type A_arbace_go_eval_A struct{ j2g_header uint64 }

var A_arbace_go_eval_A_fn_class *jrt.Class



type A_arbace_go_eval1822000004_A struct{ jrt.Object }

func A_arbace_go_eval1822000004_A_New() *A_arbace_go_eval1822000004_A { t := &A_arbace_go_eval1822000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000004_A) Ctor() {}

func (t *A_arbace_go_eval1822000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000004_A_class }

func (t *A_arbace_go_eval1822000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000004_A); return ok }

func A_arbace_go_eval1822000004_A_Cast(x any) *A_arbace_go_eval1822000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000004_A_class)) }; return v }



type A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_fn_class *jrt.Class



type A_arbace_go_eval1822000008_A struct{ jrt.Object }

func A_arbace_go_eval1822000008_A_New() *A_arbace_go_eval1822000008_A { t := &A_arbace_go_eval1822000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_eval1822000008_A) Ctor() {}

func (t *A_arbace_go_eval1822000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_eval1822000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_eval1822000008_A_class }

func (t *A_arbace_go_eval1822000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_eval1822000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_eval1822000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_eval1822000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_eval1822000008_A); return ok }

func A_arbace_go_eval1822000008_A_Cast(x any) *A_arbace_go_eval1822000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_eval1822000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_eval1822000008_A_class)) }; return v }



type A_arbace_go_eval1822000008_fn__1822000009_A struct{ j2g_header uint64 }

var A_arbace_go_eval1822000008_fn__1822000009_A_fn_class *jrt.Class



type A_arbace_go_file_A struct{ j2g_header uint64 }

var A_arbace_go_file_A_fn_class *jrt.Class



type A_arbace_go_fn__1822000016_A struct{ j2g_header uint64 }

var A_arbace_go_fn__1822000016_A_fn_class *jrt.Class



type A_arbace_go_func_A struct{ j2g_header uint64 }

var A_arbace_go_func_A_fn_class *jrt.Class



type A_arbace_go_import_A struct{ j2g_header uint64 }

var A_arbace_go_import_A_fn_class *jrt.Class



type A_arbace_go_member_var_A struct{ j2g_header uint64 }

var A_arbace_go_member_var_A_fn_class *jrt.Class



type A_arbace_go_method_A struct{ j2g_header uint64 }

var A_arbace_go_method_A_fn_class *jrt.Class



type A_arbace_go_new_A struct{ j2g_header uint64 }

var A_arbace_go_new_A_fn_class *jrt.Class



type A_arbace_go_package_A struct{ j2g_header uint64 }

var A_arbace_go_package_A_fn_class *jrt.Class



type A_arbace_go_packages_A struct{ j2g_header uint64 }

var A_arbace_go_packages_A_fn_class *jrt.Class



type A_arbace_go_params_of_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_A_fn_class *jrt.Class



type A_arbace_go_params_of_fn__1822000024_A struct{ j2g_header uint64 }

var A_arbace_go_params_of_fn__1822000024_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_path__GT_ns_fn__1822000013_A struct{ j2g_header uint64 }

var A_arbace_go_path__GT_ns_fn__1822000013_A_fn_class *jrt.Class



type A_arbace_go_pos_of_A struct{ j2g_header uint64 }

var A_arbace_go_pos_of_A_fn_class *jrt.Class



type A_arbace_go_reify_data_A struct{ j2g_header uint64 }

var A_arbace_go_reify_data_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000112__1822000116_A struct{ j2g_header uint64; F_fns, F_ts any }

var A_arbace_go_reify_data_iter__1822000112__1822000116_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A struct{ j2g_header uint64; F_iter__1822000112, F_fns, F_s__1822000113, F_ts any }

var A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_fn_class *jrt.Class



type A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A struct{ j2g_header uint64; F_fns, F_b__1822000115 any; F_size__1927001038__auto__ int32; F_ts, F_c__1927001037__auto__ any }

var A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_fn_class *jrt.Class



type A_arbace_go_reify_type_A struct{ j2g_header uint64 }

var A_arbace_go_reify_type_A_fn_class *jrt.Class



type A_arbace_go_repl_fn_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn_A_fn_class *jrt.Class



type A_arbace_go_run_compiled_A struct{ j2g_header uint64 }

var A_arbace_go_run_compiled_A_fn_class *jrt.Class



type A_arbace_go_run_main_A struct{ j2g_header uint64 }

var A_arbace_go_run_main_A_fn_class *jrt.Class



type A_arbace_go_spread_A struct{ j2g_header uint64 }

var A_arbace_go_spread_A_fn_class *jrt.Class



type A_arbace_go_str_A struct{ j2g_header uint64 }

var A_arbace_go_str_A_fn_class *jrt.Class



type A_arbace_go_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_go_strip_doc_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000061_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_table_ns_BANG__fn__1822000061_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_A struct{ j2g_header uint64; F_info, F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000063_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A struct{ j2g_header uint64; F_members any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A struct{ j2g_header uint64; F_members, F_s__1822000065, F_iter__1822000064 any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A struct{ j2g_header uint64; F_b__1822000067, F_members any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A struct{ j2g_header uint64 }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A struct{ j2g_header uint64; F_iter__1822000045, F_s__1822000046 any }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A struct{ j2g_header uint64; F_b__1822000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__make__1822000081_A struct{ j2g_header uint64; F_ns, F_info, F_consts, F_p, F_members any }

var A_arbace_go_table_ns_BANG__make__1822000081_A_fn_class *jrt.Class



type A_arbace_go_table_ns_BANG__resolver__1822000086_A struct{ j2g_header uint64; F_make, F_consts, F_members any }

var A_arbace_go_table_ns_BANG__resolver__1822000086_A_fn_class *jrt.Class



type A_arbace_go_type_A struct{ j2g_header uint64 }

var A_arbace_go_type_A_fn_class *jrt.Class



type A_arbace_go_type_names_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_A_fn_class *jrt.Class



type A_arbace_go_type_names_fn__1822000101_A struct{ j2g_header uint64 }

var A_arbace_go_type_names_fn__1822000101_A_fn_class *jrt.Class



type A_arbace_go_type_of_A struct{ j2g_header uint64 }

var A_arbace_go_type_of_A_fn_class *jrt.Class



type A_arbace_go_var_A struct{ j2g_header uint64 }

var A_arbace_go_var_A_fn_class *jrt.Class



type A_arbace_go_zero_A struct{ j2g_header uint64 }

var A_arbace_go_zero_A_fn_class *jrt.Class
