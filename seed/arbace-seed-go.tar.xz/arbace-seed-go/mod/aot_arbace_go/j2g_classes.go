//line j2g_classes.ae:1
package aot_arbace_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_assign_BANG__A_class, Name: "arbace.go$assign_BANG_", Modifiers: 25, Simple: "assign_BANG_", Go: "arbace/aot_arbace_go.A_arbace_go_assign_BANG__A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_A_class, Name: "arbace.go$check", Modifiers: 25, Simple: "check", Go: "arbace/aot_arbace_go.A_arbace_go_check_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_const_A_class, Name: "arbace.go$const", Modifiers: 25, Simple: "const", Go: "arbace/aot_arbace_go.A_arbace_go_const_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_const_value_A_class, Name: "arbace.go$const_value", Modifiers: 25, Simple: "const_value", Go: "arbace/aot_arbace_go.A_arbace_go_const_value_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_const_value_fn__1822000029_A_class, Name: "arbace.go$const_value$fn__1822000029", Modifiers: 25, Simple: "fn__1822000029", Go: "arbace/aot_arbace_go.A_arbace_go_const_value_fn__1822000029_A", Source: "go.ae", Declaring: &A_arbace_go_const_value_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_declare_STAR__A_class, Name: "arbace.go$declare_STAR_", Modifiers: 25, Simple: "declare_STAR_", Go: "arbace/aot_arbace_go.A_arbace_go_declare_STAR__A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_digest_forms_A_class, Name: "arbace.go$digest_forms", Modifiers: 25, Simple: "digest_forms", Go: "arbace/aot_arbace_go.A_arbace_go_digest_forms_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_digest_info_A_class, Name: "arbace.go$digest_info", Modifiers: 25, Simple: "digest_info", Go: "arbace/aot_arbace_go.A_arbace_go_digest_info_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_digest_info_fn__1822000032_A_class, Name: "arbace.go$digest_info$fn__1822000032", Modifiers: 25, Simple: "fn__1822000032", Go: "arbace/aot_arbace_go.A_arbace_go_digest_info_fn__1822000032_A", Source: "go.ae", Declaring: &A_arbace_go_digest_info_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_directive_A_class, Name: "arbace.go$directive", Modifiers: 25, Simple: "directive", Go: "arbace/aot_arbace_go.A_arbace_go_directive_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_eval_A_class, Name: "arbace.go$eval", Modifiers: 25, Simple: "eval", Go: "arbace/aot_arbace_go.A_arbace_go_eval_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_class, Name: "arbace.go$eval1822000004$loading__1927001464__auto____1822000005", Modifiers: 25, Simple: "loading__1927001464__auto____1822000005", Go: "arbace/aot_arbace_go.A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A", Source: "go.ae", Declaring: &A_arbace_go_eval1822000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_eval1822000008_fn__1822000009_A_class, Name: "arbace.go$eval1822000008$fn__1822000009", Modifiers: 25, Simple: "fn__1822000009", Go: "arbace/aot_arbace_go.A_arbace_go_eval1822000008_fn__1822000009_A", Source: "go.ae", Declaring: &A_arbace_go_eval1822000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_file_A_class, Name: "arbace.go$file", Modifiers: 25, Simple: "file", Go: "arbace/aot_arbace_go.A_arbace_go_file_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_go_fn__1822000016_A_class, Name: "arbace.go$fn__1822000016", Modifiers: 25, Simple: "fn__1822000016", Go: "arbace/aot_arbace_go.A_arbace_go_fn__1822000016_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_func_A_class, Name: "arbace.go$func", Modifiers: 25, Simple: "func", Go: "arbace/aot_arbace_go.A_arbace_go_func_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_import_A_class, Name: "arbace.go$import", Modifiers: 25, Simple: "import", Go: "arbace/aot_arbace_go.A_arbace_go_import_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_member_var_A_class, Name: "arbace.go$member_var", Modifiers: 25, Simple: "member_var", Go: "arbace/aot_arbace_go.A_arbace_go_member_var_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_go_method_A_class, Name: "arbace.go$method", Modifiers: 25, Simple: "method", Go: "arbace/aot_arbace_go.A_arbace_go_method_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_new_A_class, Name: "arbace.go$new", Modifiers: 25, Simple: "new", Go: "arbace/aot_arbace_go.A_arbace_go_new_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_package_A_class, Name: "arbace.go$package", Modifiers: 25, Simple: "package", Go: "arbace/aot_arbace_go.A_arbace_go_package_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_go_packages_A_class, Name: "arbace.go$packages", Modifiers: 25, Simple: "packages", Go: "arbace/aot_arbace_go.A_arbace_go_packages_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_params_of_A_class, Name: "arbace.go$params_of", Modifiers: 25, Simple: "params_of", Go: "arbace/aot_arbace_go.A_arbace_go_params_of_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_params_of_fn__1822000024_A_class, Name: "arbace.go$params_of$fn__1822000024", Modifiers: 25, Simple: "fn__1822000024", Go: "arbace/aot_arbace_go.A_arbace_go_params_of_fn__1822000024_A", Source: "go.ae", Declaring: &A_arbace_go_params_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_path__GT_ns_A_class, Name: "arbace.go$path__GT_ns", Modifiers: 25, Simple: "path__GT_ns", Go: "arbace/aot_arbace_go.A_arbace_go_path__GT_ns_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_path__GT_ns_fn__1822000013_A_class, Name: "arbace.go$path__GT_ns$fn__1822000013", Modifiers: 25, Simple: "fn__1822000013", Go: "arbace/aot_arbace_go.A_arbace_go_path__GT_ns_fn__1822000013_A", Source: "go.ae", Declaring: &A_arbace_go_path__GT_ns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_pos_of_A_class, Name: "arbace.go$pos_of", Modifiers: 25, Simple: "pos_of", Go: "arbace/aot_arbace_go.A_arbace_go_pos_of_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_reify_data_A_class, Name: "arbace.go$reify_data", Modifiers: 25, Simple: "reify_data", Go: "arbace/aot_arbace_go.A_arbace_go_reify_data_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_reify_data_iter__1822000112__1822000116_A_class, Name: "arbace.go$reify_data$iter__1822000112__1822000116", Modifiers: 25, Simple: "iter__1822000112__1822000116", Go: "arbace/aot_arbace_go.A_arbace_go_reify_data_iter__1822000112__1822000116_A", Source: "go.ae", Declaring: &A_arbace_go_reify_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_class, Name: "arbace.go$reify_data$iter__1822000112__1822000116$fn__1822000117", Modifiers: 25, Simple: "fn__1822000117", Go: "arbace/aot_arbace_go.A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A", Source: "go.ae", Declaring: &A_arbace_go_reify_data_iter__1822000112__1822000116_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_class, Name: "arbace.go$reify_data$iter__1822000112__1822000116$fn__1822000117$fn__1822000118", Modifiers: 25, Simple: "fn__1822000118", Go: "arbace/aot_arbace_go.A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A", Source: "go.ae", Declaring: &A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_reify_type_A_class, Name: "arbace.go$reify_type", Modifiers: 25, Simple: "reify_type", Go: "arbace/aot_arbace_go.A_arbace_go_reify_type_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_repl_fn_A_class, Name: "arbace.go$repl_fn", Modifiers: 25, Simple: "repl_fn", Go: "arbace/aot_arbace_go.A_arbace_go_repl_fn_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_compiled_A_class, Name: "arbace.go$run_compiled", Modifiers: 25, Simple: "run_compiled", Go: "arbace/aot_arbace_go.A_arbace_go_run_compiled_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_main_A_class, Name: "arbace.go$run_main", Modifiers: 25, Simple: "run_main", Go: "arbace/aot_arbace_go.A_arbace_go_run_main_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_spread_A_class, Name: "arbace.go$spread", Modifiers: 25, Simple: "spread", Go: "arbace/aot_arbace_go.A_arbace_go_spread_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_str_A_class, Name: "arbace.go$str", Modifiers: 25, Simple: "str", Go: "arbace/aot_arbace_go.A_arbace_go_str_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_strip_doc_A_class, Name: "arbace.go$strip_doc", Modifiers: 25, Simple: "strip_doc", Go: "arbace/aot_arbace_go.A_arbace_go_strip_doc_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__A_class, Name: "arbace.go$table_ns_BANG_", Modifiers: 25, Simple: "table_ns_BANG_", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__fn__1822000061_A_class, Name: "arbace.go$table_ns_BANG_$fn__1822000061", Modifiers: 25, Simple: "fn__1822000061", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__fn__1822000061_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__fn__1822000063_A_class, Name: "arbace.go$table_ns_BANG_$fn__1822000063", Modifiers: 25, Simple: "fn__1822000063", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__fn__1822000063_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_class, Name: "arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068", Modifiers: 25, Simple: "iter__1822000064__1822000068", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__fn__1822000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_class, Name: "arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069", Modifiers: 25, Simple: "fn__1822000069", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_class, Name: "arbace.go$table_ns_BANG_$fn__1822000063$iter__1822000064__1822000068$fn__1822000069$fn__1822000070", Modifiers: 25, Simple: "fn__1822000070", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_class, Name: "arbace.go$table_ns_BANG_$iter__1822000045__1822000049", Modifiers: 25, Simple: "iter__1822000045__1822000049", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_class, Name: "arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050", Modifiers: 25, Simple: "fn__1822000050", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_class, Name: "arbace.go$table_ns_BANG_$iter__1822000045__1822000049$fn__1822000050$fn__1822000051", Modifiers: 25, Simple: "fn__1822000051", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__make__1822000081_A_class, Name: "arbace.go$table_ns_BANG_$make__1822000081", Modifiers: 25, Simple: "make__1822000081", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__make__1822000081_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_table_ns_BANG__resolver__1822000086_A_class, Name: "arbace.go$table_ns_BANG_$resolver__1822000086", Modifiers: 25, Simple: "resolver__1822000086", Go: "arbace/aot_arbace_go.A_arbace_go_table_ns_BANG__resolver__1822000086_A", Source: "go.ae", Declaring: &A_arbace_go_table_ns_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_type_A_class, Name: "arbace.go$type", Modifiers: 25, Simple: "type", Go: "arbace/aot_arbace_go.A_arbace_go_type_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_type_names_A_class, Name: "arbace.go$type_names", Modifiers: 25, Simple: "type_names", Go: "arbace/aot_arbace_go.A_arbace_go_type_names_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_type_names_fn__1822000101_A_class, Name: "arbace.go$type_names$fn__1822000101", Modifiers: 25, Simple: "fn__1822000101", Go: "arbace/aot_arbace_go.A_arbace_go_type_names_fn__1822000101_A", Source: "go.ae", Declaring: &A_arbace_go_type_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_type_of_A_class, Name: "arbace.go$type_of", Modifiers: 25, Simple: "type_of", Go: "arbace/aot_arbace_go.A_arbace_go_type_of_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_var_A_class, Name: "arbace.go$var", Modifiers: 25, Simple: "var", Go: "arbace/aot_arbace_go.A_arbace_go_var_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_zero_A_class, Name: "arbace.go$zero", Modifiers: 25, Simple: "zero", Go: "arbace/aot_arbace_go.A_arbace_go_zero_A", Source: "go.ae", Declaring: &A_arbace_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_A_New()}; return nil }

var A_arbace_go_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_A_new}

var A_arbace_go_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go.A_arbace_go_A"})

func init() { i := A_arbace_go_A_class.Info(); i.IsInstance = A_arbace_go_A_InstanceOf; i.Init = A_arbace_go_A_Init; i.Table = A_arbace_go_A_members }

var A_arbace_go_assign_BANG__A_class *jrt.Class

var A_arbace_go_check_A_class *jrt.Class

var A_arbace_go_const_A_class *jrt.Class

var A_arbace_go_const_value_A_class *jrt.Class

var A_arbace_go_const_value_fn__1822000029_A_class *jrt.Class

var A_arbace_go_declare_STAR__A_class *jrt.Class

var A_arbace_go_digest_forms_A_class *jrt.Class

var A_arbace_go_digest_info_A_class *jrt.Class

var A_arbace_go_digest_info_fn__1822000032_A_class *jrt.Class

var A_arbace_go_directive_A_class *jrt.Class

var A_arbace_go_eval_A_class *jrt.Class

func A_arbace_go_eval1822000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_eval1822000004_A_New()}; return nil }

var A_arbace_go_eval1822000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_eval1822000004_A_new}

var A_arbace_go_eval1822000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go$eval1822000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_A_class, Simple: "eval1822000004", Go: "arbace/aot_arbace_go.A_arbace_go_eval1822000004_A"})

func init() { i := A_arbace_go_eval1822000004_A_class.Info(); i.IsInstance = A_arbace_go_eval1822000004_A_InstanceOf; i.Table = A_arbace_go_eval1822000004_A_members }

var A_arbace_go_eval1822000004_loading__1927001464__auto____1822000005_A_class *jrt.Class

func A_arbace_go_eval1822000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_eval1822000008_A_New()}; return nil }

var A_arbace_go_eval1822000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_eval1822000008_A_new}

var A_arbace_go_eval1822000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go$eval1822000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_A_class, Simple: "eval1822000008", Go: "arbace/aot_arbace_go.A_arbace_go_eval1822000008_A"})

func init() { i := A_arbace_go_eval1822000008_A_class.Info(); i.IsInstance = A_arbace_go_eval1822000008_A_InstanceOf; i.Table = A_arbace_go_eval1822000008_A_members }

var A_arbace_go_eval1822000008_fn__1822000009_A_class *jrt.Class

var A_arbace_go_file_A_class *jrt.Class

var A_arbace_go_fn__1822000016_A_class *jrt.Class

var A_arbace_go_func_A_class *jrt.Class

var A_arbace_go_import_A_class *jrt.Class

var A_arbace_go_member_var_A_class *jrt.Class

var A_arbace_go_method_A_class *jrt.Class

var A_arbace_go_new_A_class *jrt.Class

var A_arbace_go_package_A_class *jrt.Class

var A_arbace_go_packages_A_class *jrt.Class

var A_arbace_go_params_of_A_class *jrt.Class

var A_arbace_go_params_of_fn__1822000024_A_class *jrt.Class

var A_arbace_go_path__GT_ns_A_class *jrt.Class

var A_arbace_go_path__GT_ns_fn__1822000013_A_class *jrt.Class

var A_arbace_go_pos_of_A_class *jrt.Class

var A_arbace_go_reify_data_A_class *jrt.Class

var A_arbace_go_reify_data_iter__1822000112__1822000116_A_class *jrt.Class

var A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_A_class *jrt.Class

var A_arbace_go_reify_data_iter__1822000112__1822000116_fn__1822000117_fn__1822000118_A_class *jrt.Class

var A_arbace_go_reify_type_A_class *jrt.Class

var A_arbace_go_repl_fn_A_class *jrt.Class

var A_arbace_go_run_compiled_A_class *jrt.Class

var A_arbace_go_run_main_A_class *jrt.Class

var A_arbace_go_spread_A_class *jrt.Class

var A_arbace_go_str_A_class *jrt.Class

var A_arbace_go_strip_doc_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__A_class *jrt.Class

var A_arbace_go_table_ns_BANG__fn__1822000061_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__fn__1822000063_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__fn__1822000063_iter__1822000064__1822000068_fn__1822000069_fn__1822000070_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__iter__1822000045__1822000049_fn__1822000050_fn__1822000051_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__make__1822000081_A_class *jrt.Class

var A_arbace_go_table_ns_BANG__resolver__1822000086_A_class *jrt.Class

var A_arbace_go_type_A_class *jrt.Class

var A_arbace_go_type_names_A_class *jrt.Class

var A_arbace_go_type_names_fn__1822000101_A_class *jrt.Class

var A_arbace_go_type_of_A_class *jrt.Class

var A_arbace_go_var_A_class *jrt.Class

var A_arbace_go_zero_A_class *jrt.Class

func A_arbace_go__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go__init_A_Load__O()}; return nil }

func A_arbace_go__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go__init_A_New()}; return nil }

var A_arbace_go__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go__init_A_invoke, New: A_arbace_go__init_A_new}

var A_arbace_go__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go.A_arbace_go__init_A", Source: "go.ae"})

func init() { i := A_arbace_go__init_A_class.Info(); i.IsInstance = A_arbace_go__init_A_InstanceOf; i.Init = A_arbace_go__init_A_Init; i.Table = A_arbace_go__init_A_members }
