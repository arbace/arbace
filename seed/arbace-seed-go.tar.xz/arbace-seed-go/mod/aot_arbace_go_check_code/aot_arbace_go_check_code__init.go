//line aot_arbace_go_check_code__init.ae:1
package aot_arbace_go_check_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_code__init_A_Unit0__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_code__init_A_const_1) }
//line :1:1
func A_arbace_go_check_code__init_A_Unit1__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_code__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_code__init_A_Unit2__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_585, false); A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_code__init_A_Unit3__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_code__init_A_const_1)).Equals_O__Z(A_arbace_go_check_code__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_code_eval181000008_fn__181000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_code_eval181000008_fn__181000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_586, false); A_arbace_go_check_code_eval181000008_fn__181000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_code__init_A_Load__O() any { A_arbace_go_check_code__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_code__init_A_Unit0__O(); A_arbace_go_check_code__init_A_Unit1__O(); A_arbace_go_check_code__init_A_Unit2__O(); A_arbace_go_check_code__init_A_Unit3__O(); A_arbace_go_check_code__init_A_Unit4__O(); A_arbace_go_check_code__init_A_Unit5__O(); A_arbace_go_check_code__init_A_Unit6__O(); A_arbace_go_check_code__init_A_Unit7__O(); A_arbace_go_check_code__init_A_Unit8__O(); A_arbace_go_check_code__init_A_Unit9__O(); A_arbace_go_check_code__init_A_Unit10__O(); A_arbace_go_check_code__init_A_Unit11__O(); A_arbace_go_check_code__init_A_Unit12__O(); A_arbace_go_check_code__init_A_Unit13__O(); A_arbace_go_check_code__init_A_Unit14__O(); A_arbace_go_check_code__init_A_Unit15__O(); A_arbace_go_check_code__init_A_Unit16__O(); A_arbace_go_check_code__init_A_Unit17__O(); A_arbace_go_check_code__init_A_Unit18__O(); A_arbace_go_check_code__init_A_Unit19__O(); A_arbace_go_check_code__init_A_Unit20__O(); A_arbace_go_check_code__init_A_Unit21__O(); A_arbace_go_check_code__init_A_Unit22__O(); A_arbace_go_check_code__init_A_Unit23__O(); A_arbace_go_check_code__init_A_Unit24__O(); A_arbace_go_check_code__init_A_Unit25__O(); A_arbace_go_check_code__init_A_Unit26__O(); A_arbace_go_check_code__init_A_Unit27__O(); A_arbace_go_check_code__init_A_Unit28__O(); A_arbace_go_check_code__init_A_Unit29__O(); A_arbace_go_check_code__init_A_Unit30__O(); A_arbace_go_check_code__init_A_Unit31__O(); A_arbace_go_check_code__init_A_Unit32__O(); A_arbace_go_check_code__init_A_Unit33__O(); A_arbace_go_check_code__init_A_Unit34__O(); A_arbace_go_check_code__init_A_Unit35__O(); A_arbace_go_check_code__init_A_Unit36__O(); A_arbace_go_check_code__init_A_Unit37__O(); A_arbace_go_check_code__init_A_Unit38__O(); A_arbace_go_check_code__init_A_Unit39__O(); A_arbace_go_check_code__init_A_Unit40__O(); A_arbace_go_check_code__init_A_Unit41__O(); A_arbace_go_check_code__init_A_Unit42__O(); A_arbace_go_check_code__init_A_Unit43__O(); A_arbace_go_check_code__init_A_Unit44__O(); A_arbace_go_check_code__init_A_Unit45__O(); A_arbace_go_check_code__init_A_Unit46__O(); A_arbace_go_check_code__init_A_Unit47__O(); A_arbace_go_check_code__init_A_Unit48__O(); A_arbace_go_check_code__init_A_Unit49__O(); A_arbace_go_check_code__init_A_Unit50__O(); A_arbace_go_check_code__init_A_Unit51__O(); A_arbace_go_check_code__init_A_Unit52__O(); A_arbace_go_check_code__init_A_Unit53__O(); A_arbace_go_check_code__init_A_Unit54__O(); A_arbace_go_check_code__init_A_Unit55__O(); A_arbace_go_check_code__init_A_Unit56__O(); A_arbace_go_check_code__init_A_Unit57__O(); A_arbace_go_check_code__init_A_Unit58__O(); A_arbace_go_check_code__init_A_Unit59__O(); A_arbace_go_check_code__init_A_Unit60__O(); A_arbace_go_check_code__init_A_Unit61__O(); A_arbace_go_check_code__init_A_Unit62__O(); A_arbace_go_check_code__init_A_Unit63__O(); A_arbace_go_check_code__init_A_Unit64__O(); A_arbace_go_check_code__init_A_Unit65__O(); A_arbace_go_check_code__init_A_Unit66__O(); A_arbace_go_check_code__init_A_Unit67__O(); A_arbace_go_check_code__init_A_Unit68__O(); A_arbace_go_check_code__init_A_Unit69__O(); A_arbace_go_check_code__init_A_Unit70__O(); A_arbace_go_check_code__init_A_Unit71__O(); A_arbace_go_check_code__init_A_Unit72__O(); A_arbace_go_check_code__init_A_Unit73__O(); A_arbace_go_check_code__init_A_Unit74__O(); A_arbace_go_check_code__init_A_Unit75__O(); A_arbace_go_check_code__init_A_Unit76__O(); A_arbace_go_check_code__init_A_Unit77__O(); A_arbace_go_check_code__init_A_Unit78__O(); A_arbace_go_check_code__init_A_Unit79__O(); A_arbace_go_check_code__init_A_Unit80__O(); A_arbace_go_check_code__init_A_Unit81__O(); A_arbace_go_check_code__init_A_Unit82__O(); return nil }










func A_arbace_go_check_code__init_A_Unit4__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_5)); return A_arbace_go_check_code__init_A_const_4 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit5__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_7)); return A_arbace_go_check_code__init_A_const_6 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit6__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_9)); return A_arbace_go_check_code__init_A_const_8 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit7__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_11)); return A_arbace_go_check_code__init_A_const_10 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit8__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_13)); return A_arbace_go_check_code__init_A_const_12 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit9__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_15)); return A_arbace_go_check_code__init_A_const_14 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit10__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_17)); return A_arbace_go_check_code__init_A_const_16 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit11__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_19)); return A_arbace_go_check_code__init_A_const_18 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit12__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_21)); return A_arbace_go_check_code__init_A_const_20 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit13__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_23)); return A_arbace_go_check_code__init_A_const_22 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit14__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_25)); return A_arbace_go_check_code__init_A_const_24 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit15__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_27)); return A_arbace_go_check_code__init_A_const_26 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit16__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_29)); return A_arbace_go_check_code__init_A_const_28 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit17__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_31)); return A_arbace_go_check_code__init_A_const_30 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit18__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_33)); return A_arbace_go_check_code__init_A_const_32 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit19__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_35)); return A_arbace_go_check_code__init_A_const_34 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit20__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_37)); return A_arbace_go_check_code__init_A_const_36 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit21__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_39)); return A_arbace_go_check_code__init_A_const_38 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit22__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_41)); return A_arbace_go_check_code__init_A_const_40 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit23__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_43)); return A_arbace_go_check_code__init_A_const_42 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit24__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_45)); return A_arbace_go_check_code__init_A_const_44 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit25__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_47)); return A_arbace_go_check_code__init_A_const_46 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit26__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_49)); return A_arbace_go_check_code__init_A_const_48 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit27__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_50; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_51)); return A_arbace_go_check_code__init_A_const_50 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit28__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_53)); return A_arbace_go_check_code__init_A_const_52 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit29__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_55)); return A_arbace_go_check_code__init_A_const_54 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit30__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_57)); return A_arbace_go_check_code__init_A_const_56 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit31__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_59)); return A_arbace_go_check_code__init_A_const_58 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit32__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_61)); return A_arbace_go_check_code__init_A_const_60 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit33__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_63)); return A_arbace_go_check_code__init_A_const_62 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit34__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_65)); return A_arbace_go_check_code__init_A_const_64 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit35__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_67)); return A_arbace_go_check_code__init_A_const_66 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit36__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_69)); return A_arbace_go_check_code__init_A_const_68 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit37__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_71)); return A_arbace_go_check_code__init_A_const_70 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit38__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_73)); return A_arbace_go_check_code__init_A_const_72 }
//line :16:1
func A_arbace_go_check_code__init_A_Unit39__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_75)); return A_arbace_go_check_code__init_A_const_74 }




func A_arbace_go_check_code__init_A_Unit40__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_go_check_code__init_A_const_76.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_77)); return A_arbace_go_check_code__init_A_const_76.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_code__init_A_Unit41__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); A_arbace_go_check_code__init_A_const_78.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_79)); return A_arbace_go_check_code__init_A_const_78.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_code__init_A_Unit42__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_go_check_code__init_A_const_80.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_81)); return A_arbace_go_check_code__init_A_const_80.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_code__init_A_Unit43__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_go_check_code__init_A_const_82.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_83)); return A_arbace_go_check_code__init_A_const_82.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_code__init_A_Unit44__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_84; var tmp2 any = A_arbace_go_check_code_head_name_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_code_head_name_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_587, false); A_arbace_go_check_code_head_name_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_85)); return A_arbace_go_check_code__init_A_const_84 }









func A_arbace_go_check_code__init_A_Unit45__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_86; var tmp2 any = A_arbace_go_check_code_go_id_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_code_go_id_QMARK__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_588, false); A_arbace_go_check_code_go_id_QMARK__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_87)); return A_arbace_go_check_code__init_A_const_86 }




func A_arbace_go_check_code__init_A_Unit46__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_88; var tmp2 any = A_arbace_go_check_code_ident_name_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_code_ident_name_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_589, false); A_arbace_go_check_code_ident_name_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_89)); return A_arbace_go_check_code__init_A_const_88 }




func A_arbace_go_check_code__init_A_Unit47__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_90; var tmp2 any = A_arbace_go_check_code_go_ident_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_code_go_ident_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_590, false); A_arbace_go_check_code_go_ident_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_91)); return A_arbace_go_check_code__init_A_const_90 }

func A_arbace_go_check_code__init_A_Unit48__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_92; var tmp2 any = A_arbace_go_check_code_fline_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_code_fline_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_591, false); A_arbace_go_check_code_fline_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_93)); return A_arbace_go_check_code__init_A_const_92 }

func A_arbace_go_check_code__init_A_Unit49__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_94; var tmp2 any = A_arbace_go_check_code_with_line_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_code_with_line_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_592, true); A_arbace_go_check_code_with_line_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_95)); return A_arbace_go_check_code__init_A_const_94 }
//line :64:1
func A_arbace_go_check_code__init_A_Unit50__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_go_check_code__init_A_const_94.SetMacro__V(); return nil }
//line :64:1
func A_arbace_go_check_code__init_A_Unit51__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); return A_arbace_go_check_code__init_A_const_94 }





func A_arbace_go_check_code__init_A_Unit52__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); A_arbace_go_check_code__init_A_const_96.BindRoot_O__V(A_arbace_go_check_code__init_A_const_97); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_98)); return A_arbace_go_check_code__init_A_const_96 }








func A_arbace_go_check_code__init_A_Unit53__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_99; var tmp2 any = A_arbace_go_check_code_lang_minor_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_code_lang_minor_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_593, false); A_arbace_go_check_code_lang_minor_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_100)); return A_arbace_go_check_code__init_A_const_99 }






func A_arbace_go_check_code__init_A_Unit54__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_101; var tmp2 any = A_arbace_go_check_code_allow_version_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_code_allow_version_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_594, false); A_arbace_go_check_code_allow_version_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_102)); return A_arbace_go_check_code__init_A_const_101 }



func A_arbace_go_check_code__init_A_Unit55__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_103; var tmp2 any = A_arbace_go_check_code_pkg_path_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_code_pkg_path_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_595, false); A_arbace_go_check_code_pkg_path_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_104)); return A_arbace_go_check_code__init_A_const_103 }

func A_arbace_go_check_code__init_A_Unit56__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_105; var tmp2 any = A_arbace_go_check_code_package_level_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_code_package_level_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_596, false); A_arbace_go_check_code_package_level_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_106)); return A_arbace_go_check_code__init_A_const_105 }

func A_arbace_go_check_code__init_A_Unit57__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_107; var tmp2 any = A_arbace_go_check_code_note_ref_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_code_note_ref_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_597, false); A_arbace_go_check_code_note_ref_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_108)); return A_arbace_go_check_code__init_A_const_107 }








func A_arbace_go_check_code__init_A_Unit58__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_109; var tmp2 any = A_arbace_go_check_code_use_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_code_use_var_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_598, false); A_arbace_go_check_code_use_var_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_110)); return A_arbace_go_check_code__init_A_const_109 }








func A_arbace_go_check_code__init_A_Unit59__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_111; var tmp2 any = A_arbace_go_check_code_resolve_name_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_code_resolve_name_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_599, false); A_arbace_go_check_code_resolve_name_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_112)); return A_arbace_go_check_code__init_A_const_111 }













func A_arbace_go_check_code__init_A_Unit60__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_113; var tmp2 any = A_arbace_go_check_code_package_by_qualifier_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_code_package_by_qualifier_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_600, false); A_arbace_go_check_code_package_by_qualifier_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_114)); return A_arbace_go_check_code__init_A_const_113 }










func A_arbace_go_check_code__init_A_Unit61__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_115; var tmp2 any = A_arbace_go_check_code_qualified_obj_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_code_qualified_obj_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_601, false); A_arbace_go_check_code_qualified_obj_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_116)); return A_arbace_go_check_code__init_A_const_115 }





















func A_arbace_go_check_code__init_A_Unit62__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_117; var tmp2 any = A_arbace_go_check_code_type_params_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_code_type_params_generic_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_602, false); A_arbace_go_check_code_type_params_generic_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_118)); return A_arbace_go_check_code__init_A_const_117 }

func A_arbace_go_check_code__init_A_Unit63__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_119; var tmp2 any = A_arbace_go_check_code_type_of_obj_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_code_type_of_obj_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_603, false); A_arbace_go_check_code_type_of_obj_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_120)); return A_arbace_go_check_code__init_A_const_119 }









func A_arbace_go_check_code__init_A_Unit64__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_121; var tmp2 any = A_arbace_go_check_code_ident_type_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_code_ident_type_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_604, false); A_arbace_go_check_code_ident_type_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_122)); return A_arbace_go_check_code__init_A_const_121 }


















func A_arbace_go_check_code__init_A_Unit65__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_123; var tmp2 any = A_arbace_go_check_code_tag_type_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_code_tag_type_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_605, false); A_arbace_go_check_code_tag_type_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_124)); return A_arbace_go_check_code__init_A_const_123 }





func A_arbace_go_check_code__init_A_Unit66__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_125; var tmp2 any = A_arbace_go_check_code_struct_field_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_code_struct_field_type_QMARK__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_606, false); A_arbace_go_check_code_struct_field_type_QMARK__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_126)); return A_arbace_go_check_code__init_A_const_125 }

func A_arbace_go_check_code__init_A_Unit67__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_127; var tmp2 any = A_arbace_go_check_code_embedded_name_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_code_embedded_name_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_607, false); A_arbace_go_check_code_embedded_name_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_128)); return A_arbace_go_check_code__init_A_const_127 }










func A_arbace_go_check_code__init_A_Unit68__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_129; var tmp2 any = A_arbace_go_check_code_struct_type_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_code_struct_type_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_608, false); A_arbace_go_check_code_struct_type_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_130)); return A_arbace_go_check_code__init_A_const_129 }

































func A_arbace_go_check_code__init_A_Unit69__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_131)); return A_arbace_go_check_code__init_A_const_52 }

func A_arbace_go_check_code__init_A_Unit70__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_132; var tmp2 any = A_arbace_go_check_code_method_elem_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_code_method_elem_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_609, false); A_arbace_go_check_code_method_elem_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_133)); return A_arbace_go_check_code__init_A_const_132 }

func A_arbace_go_check_code__init_A_Unit71__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_134; var tmp2 any = A_arbace_go_check_code_interface_type_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_check_code_interface_type_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_610, false); A_arbace_go_check_code_interface_type_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_135)); return A_arbace_go_check_code__init_A_const_134 }































func A_arbace_go_check_code__init_A_Unit72__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_136; var tmp2 any = A_arbace_go_check_code_array_length_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_code_array_length_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_611, false); A_arbace_go_check_code_array_length_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_137)); return A_arbace_go_check_code__init_A_const_136 }



















func A_arbace_go_check_code__init_A_Unit73__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_138; var tmp2 any = A_arbace_go_check_code_chan_type_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_code_chan_type_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_612, false); A_arbace_go_check_code_chan_type_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_139)); return A_arbace_go_check_code__init_A_const_138 }






func A_arbace_go_check_code__init_A_Unit74__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_16; var tmp2 any = A_arbace_go_check_code_typexpr_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_code_typexpr_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_613, false); A_arbace_go_check_code_typexpr_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_140)); return A_arbace_go_check_code__init_A_const_16 }










































func A_arbace_go_check_code__init_A_Unit75__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_18; var tmp2 any = A_arbace_go_check_code_typexpr_generic_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_code_typexpr_generic_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_614, false); A_arbace_go_check_code_typexpr_generic_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_141)); return A_arbace_go_check_code__init_A_const_18 }












func A_arbace_go_check_code__init_A_Unit76__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_142; var tmp2 any = A_arbace_go_check_code_param_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_code_param_name_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_615, false); A_arbace_go_check_code_param_name_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_143)); return A_arbace_go_check_code__init_A_const_142 }

func A_arbace_go_check_code__init_A_Unit77__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_144; var tmp2 any = A_arbace_go_check_code_params_of_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_code_params_of_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_616, false); A_arbace_go_check_code_params_of_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_145)); return A_arbace_go_check_code__init_A_const_144 }












func A_arbace_go_check_code__init_A_Unit78__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_A_const_52; var tmp2 any = A_arbace_go_check_code_signature_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_code_signature_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_617, false); A_arbace_go_check_code_signature_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_A_const_146)); return A_arbace_go_check_code__init_A_const_52 }




















func A_arbace_go_check_code__init_A_Unit79__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(398, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_A_const_147.GetRawRoot__O()).Invoke_O__O(Lit_618) }
func A_arbace_go_check_code__init_A_Unit80__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_A_const_147.GetRawRoot__O()).Invoke_O__O(Lit_619) }
func A_arbace_go_check_code__init_A_Unit81__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_A_const_147.GetRawRoot__O()).Invoke_O__O(Lit_620) }
func A_arbace_go_check_code__init_A_Unit82__O() any { A_arbace_go_check_code__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(401, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_A_const_147.GetRawRoot__O()).Invoke_O__O(Lit_621) }



type A_arbace_go_check_code__init_A struct{ jrt.Object }

var A_arbace_go_check_code__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_code__init_A_const_0 *lang.Var

var A_arbace_go_check_code__init_A_const_1 any

var A_arbace_go_check_code__init_A_const_2 any

var A_arbace_go_check_code__init_A_const_3 any

var A_arbace_go_check_code__init_A_const_4 *lang.Var

var A_arbace_go_check_code__init_A_const_5 any

var A_arbace_go_check_code__init_A_const_6 *lang.Var

var A_arbace_go_check_code__init_A_const_7 any

var A_arbace_go_check_code__init_A_const_8 *lang.Var

var A_arbace_go_check_code__init_A_const_9 any

var A_arbace_go_check_code__init_A_const_10 *lang.Var

var A_arbace_go_check_code__init_A_const_11 any

var A_arbace_go_check_code__init_A_const_12 *lang.Var

var A_arbace_go_check_code__init_A_const_13 any

var A_arbace_go_check_code__init_A_const_14 *lang.Var

var A_arbace_go_check_code__init_A_const_15 any

var A_arbace_go_check_code__init_A_const_16 *lang.Var

var A_arbace_go_check_code__init_A_const_17 any

var A_arbace_go_check_code__init_A_const_18 *lang.Var

var A_arbace_go_check_code__init_A_const_19 any

var A_arbace_go_check_code__init_A_const_20 *lang.Var

var A_arbace_go_check_code__init_A_const_21 any

var A_arbace_go_check_code__init_A_const_22 *lang.Var

var A_arbace_go_check_code__init_A_const_23 any

var A_arbace_go_check_code__init_A_const_24 *lang.Var

var A_arbace_go_check_code__init_A_const_25 any

var A_arbace_go_check_code__init_A_const_26 *lang.Var

var A_arbace_go_check_code__init_A_const_27 any

var A_arbace_go_check_code__init_A_const_28 *lang.Var

var A_arbace_go_check_code__init_A_const_29 any

var A_arbace_go_check_code__init_A_const_30 *lang.Var

var A_arbace_go_check_code__init_A_const_31 any

var A_arbace_go_check_code__init_A_const_32 *lang.Var

var A_arbace_go_check_code__init_A_const_33 any

var A_arbace_go_check_code__init_A_const_34 *lang.Var

var A_arbace_go_check_code__init_A_const_35 any

var A_arbace_go_check_code__init_A_const_36 *lang.Var

var A_arbace_go_check_code__init_A_const_37 any

var A_arbace_go_check_code__init_A_const_38 *lang.Var

var A_arbace_go_check_code__init_A_const_39 any

var A_arbace_go_check_code__init_A_const_40 *lang.Var

var A_arbace_go_check_code__init_A_const_41 any

var A_arbace_go_check_code__init_A_const_42 *lang.Var

var A_arbace_go_check_code__init_A_const_43 any

var A_arbace_go_check_code__init_A_const_44 *lang.Var

var A_arbace_go_check_code__init_A_const_45 any

var A_arbace_go_check_code__init_A_const_46 *lang.Var

var A_arbace_go_check_code__init_A_const_47 any

var A_arbace_go_check_code__init_A_const_48 *lang.Var

var A_arbace_go_check_code__init_A_const_49 any

var A_arbace_go_check_code__init_A_const_50 *lang.Var

var A_arbace_go_check_code__init_A_const_51 any

var A_arbace_go_check_code__init_A_const_52 *lang.Var

var A_arbace_go_check_code__init_A_const_53 any

var A_arbace_go_check_code__init_A_const_54 *lang.Var

var A_arbace_go_check_code__init_A_const_55 any

var A_arbace_go_check_code__init_A_const_56 *lang.Var

var A_arbace_go_check_code__init_A_const_57 any

var A_arbace_go_check_code__init_A_const_58 *lang.Var

var A_arbace_go_check_code__init_A_const_59 any

var A_arbace_go_check_code__init_A_const_60 *lang.Var

var A_arbace_go_check_code__init_A_const_61 any

var A_arbace_go_check_code__init_A_const_62 *lang.Var

var A_arbace_go_check_code__init_A_const_63 any

var A_arbace_go_check_code__init_A_const_64 *lang.Var

var A_arbace_go_check_code__init_A_const_65 any

var A_arbace_go_check_code__init_A_const_66 *lang.Var

var A_arbace_go_check_code__init_A_const_67 any

var A_arbace_go_check_code__init_A_const_68 *lang.Var

var A_arbace_go_check_code__init_A_const_69 any

var A_arbace_go_check_code__init_A_const_70 *lang.Var

var A_arbace_go_check_code__init_A_const_71 any

var A_arbace_go_check_code__init_A_const_72 *lang.Var

var A_arbace_go_check_code__init_A_const_73 any

var A_arbace_go_check_code__init_A_const_74 *lang.Var

var A_arbace_go_check_code__init_A_const_75 any

var A_arbace_go_check_code__init_A_const_76 *lang.Var

var A_arbace_go_check_code__init_A_const_77 any

var A_arbace_go_check_code__init_A_const_78 *lang.Var

var A_arbace_go_check_code__init_A_const_79 any

var A_arbace_go_check_code__init_A_const_80 *lang.Var

var A_arbace_go_check_code__init_A_const_81 any

var A_arbace_go_check_code__init_A_const_82 *lang.Var

var A_arbace_go_check_code__init_A_const_83 any

var A_arbace_go_check_code__init_A_const_84 *lang.Var

var A_arbace_go_check_code__init_A_const_85 any

var A_arbace_go_check_code__init_A_const_86 *lang.Var

var A_arbace_go_check_code__init_A_const_87 any

var A_arbace_go_check_code__init_A_const_88 *lang.Var

var A_arbace_go_check_code__init_A_const_89 any

var A_arbace_go_check_code__init_A_const_90 *lang.Var

var A_arbace_go_check_code__init_A_const_91 any

var A_arbace_go_check_code__init_A_const_92 *lang.Var

var A_arbace_go_check_code__init_A_const_93 any

var A_arbace_go_check_code__init_A_const_94 *lang.Var

var A_arbace_go_check_code__init_A_const_95 any

var A_arbace_go_check_code__init_A_const_96 *lang.Var

var A_arbace_go_check_code__init_A_const_97 any

var A_arbace_go_check_code__init_A_const_98 any

var A_arbace_go_check_code__init_A_const_99 *lang.Var

var A_arbace_go_check_code__init_A_const_100 any

var A_arbace_go_check_code__init_A_const_101 *lang.Var

var A_arbace_go_check_code__init_A_const_102 any

var A_arbace_go_check_code__init_A_const_103 *lang.Var

var A_arbace_go_check_code__init_A_const_104 any

var A_arbace_go_check_code__init_A_const_105 *lang.Var

var A_arbace_go_check_code__init_A_const_106 any

var A_arbace_go_check_code__init_A_const_107 *lang.Var

var A_arbace_go_check_code__init_A_const_108 any

var A_arbace_go_check_code__init_A_const_109 *lang.Var

var A_arbace_go_check_code__init_A_const_110 any

var A_arbace_go_check_code__init_A_const_111 *lang.Var

var A_arbace_go_check_code__init_A_const_112 any

var A_arbace_go_check_code__init_A_const_113 *lang.Var

var A_arbace_go_check_code__init_A_const_114 any

var A_arbace_go_check_code__init_A_const_115 *lang.Var

var A_arbace_go_check_code__init_A_const_116 any

var A_arbace_go_check_code__init_A_const_117 *lang.Var

var A_arbace_go_check_code__init_A_const_118 any

var A_arbace_go_check_code__init_A_const_119 *lang.Var

var A_arbace_go_check_code__init_A_const_120 any

var A_arbace_go_check_code__init_A_const_121 *lang.Var

var A_arbace_go_check_code__init_A_const_122 any

var A_arbace_go_check_code__init_A_const_123 *lang.Var

var A_arbace_go_check_code__init_A_const_124 any

var A_arbace_go_check_code__init_A_const_125 *lang.Var

var A_arbace_go_check_code__init_A_const_126 any

var A_arbace_go_check_code__init_A_const_127 *lang.Var

var A_arbace_go_check_code__init_A_const_128 any

var A_arbace_go_check_code__init_A_const_129 *lang.Var

var A_arbace_go_check_code__init_A_const_130 any

var A_arbace_go_check_code__init_A_const_131 any

var A_arbace_go_check_code__init_A_const_132 *lang.Var

var A_arbace_go_check_code__init_A_const_133 any

var A_arbace_go_check_code__init_A_const_134 *lang.Var

var A_arbace_go_check_code__init_A_const_135 any

var A_arbace_go_check_code__init_A_const_136 *lang.Var

var A_arbace_go_check_code__init_A_const_137 any

var A_arbace_go_check_code__init_A_const_138 *lang.Var

var A_arbace_go_check_code__init_A_const_139 any

var A_arbace_go_check_code__init_A_const_140 any

var A_arbace_go_check_code__init_A_const_141 any

var A_arbace_go_check_code__init_A_const_142 *lang.Var

var A_arbace_go_check_code__init_A_const_143 any

var A_arbace_go_check_code__init_A_const_144 *lang.Var

var A_arbace_go_check_code__init_A_const_145 any

var A_arbace_go_check_code__init_A_const_146 any

var A_arbace_go_check_code__init_A_const_147 *lang.Var

var A_arbace_go_check_code__init_A_init jrt.ClassInit

func A_arbace_go_check_code__init_A_Init() { if !A_arbace_go_check_code__init_A_init.Done() { A_arbace_go_check_code__init_A_init.Run(A_arbace_go_check_code__init_A_clinit) } }

func A_arbace_go_check_code__init_A_clinit() { A_arbace_go_check_code__init_A_clinit_p0(); A_arbace_go_check_code__init_A_clinit_p1(); A_arbace_go_check_code__init_A_clinit_p2(); A_arbace_go_check_code__init_A_clinit_p3(); A_arbace_go_check_code__init_A_clinit_p4(); A_arbace_go_check_code__init_A_clinit_p5(); A_arbace_go_check_code__init_A_clinit_p6(); A_arbace_go_check_code__init_A_clinit_p7(); A_arbace_go_check_code__init_A_clinit_p8(); A_arbace_go_check_code__init_A_clinit_p9(); A_arbace_go_check_code__init_A_clinit_p10(); A_arbace_go_check_code__init_A_clinit_p11() }

func A_arbace_go_check_code__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_code__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_584, 172); A_arbace_go_check_code__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[24]); A_arbace_go_check_code__init_A_const_1 = A_arbace_go_check_code__init_A_const_pool.A[25]; A_arbace_go_check_code__init_A_const_2 = A_arbace_go_check_code__init_A_const_pool.A[26]; A_arbace_go_check_code__init_A_const_3 = A_arbace_go_check_code__init_A_const_pool.A[27]; A_arbace_go_check_code__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[28]); A_arbace_go_check_code__init_A_const_5 = A_arbace_go_check_code__init_A_const_pool.A[29]; A_arbace_go_check_code__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[30]); A_arbace_go_check_code__init_A_const_7 = A_arbace_go_check_code__init_A_const_pool.A[31]; A_arbace_go_check_code__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[32]); A_arbace_go_check_code__init_A_const_9 = A_arbace_go_check_code__init_A_const_pool.A[33]; A_arbace_go_check_code__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[34]); A_arbace_go_check_code__init_A_const_11 = A_arbace_go_check_code__init_A_const_pool.A[35]; A_arbace_go_check_code__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[36]) }

func A_arbace_go_check_code__init_A_clinit_p1() { A_arbace_go_check_code__init_A_const_13 = A_arbace_go_check_code__init_A_const_pool.A[37]; A_arbace_go_check_code__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[38]); A_arbace_go_check_code__init_A_const_15 = A_arbace_go_check_code__init_A_const_pool.A[39]; A_arbace_go_check_code__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[40]); A_arbace_go_check_code__init_A_const_17 = A_arbace_go_check_code__init_A_const_pool.A[41]; A_arbace_go_check_code__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[42]); A_arbace_go_check_code__init_A_const_19 = A_arbace_go_check_code__init_A_const_pool.A[43]; A_arbace_go_check_code__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[44]); A_arbace_go_check_code__init_A_const_21 = A_arbace_go_check_code__init_A_const_pool.A[45]; A_arbace_go_check_code__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[46]); A_arbace_go_check_code__init_A_const_23 = A_arbace_go_check_code__init_A_const_pool.A[47]; A_arbace_go_check_code__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[48]); A_arbace_go_check_code__init_A_const_25 = A_arbace_go_check_code__init_A_const_pool.A[49] }

func A_arbace_go_check_code__init_A_clinit_p2() { A_arbace_go_check_code__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[50]); A_arbace_go_check_code__init_A_const_27 = A_arbace_go_check_code__init_A_const_pool.A[51]; A_arbace_go_check_code__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[52]); A_arbace_go_check_code__init_A_const_29 = A_arbace_go_check_code__init_A_const_pool.A[53]; A_arbace_go_check_code__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[54]); A_arbace_go_check_code__init_A_const_31 = A_arbace_go_check_code__init_A_const_pool.A[55]; A_arbace_go_check_code__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[56]); A_arbace_go_check_code__init_A_const_33 = A_arbace_go_check_code__init_A_const_pool.A[57]; A_arbace_go_check_code__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[58]); A_arbace_go_check_code__init_A_const_35 = A_arbace_go_check_code__init_A_const_pool.A[59]; A_arbace_go_check_code__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[60]); A_arbace_go_check_code__init_A_const_37 = A_arbace_go_check_code__init_A_const_pool.A[61]; A_arbace_go_check_code__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[62]) }

func A_arbace_go_check_code__init_A_clinit_p3() { A_arbace_go_check_code__init_A_const_39 = A_arbace_go_check_code__init_A_const_pool.A[63]; A_arbace_go_check_code__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[64]); A_arbace_go_check_code__init_A_const_41 = A_arbace_go_check_code__init_A_const_pool.A[65]; A_arbace_go_check_code__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[66]); A_arbace_go_check_code__init_A_const_43 = A_arbace_go_check_code__init_A_const_pool.A[67]; A_arbace_go_check_code__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[68]); A_arbace_go_check_code__init_A_const_45 = A_arbace_go_check_code__init_A_const_pool.A[69]; A_arbace_go_check_code__init_A_const_46 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[70]); A_arbace_go_check_code__init_A_const_47 = A_arbace_go_check_code__init_A_const_pool.A[71]; A_arbace_go_check_code__init_A_const_48 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[72]); A_arbace_go_check_code__init_A_const_49 = A_arbace_go_check_code__init_A_const_pool.A[73]; A_arbace_go_check_code__init_A_const_50 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[74]); A_arbace_go_check_code__init_A_const_51 = A_arbace_go_check_code__init_A_const_pool.A[75] }

func A_arbace_go_check_code__init_A_clinit_p4() { A_arbace_go_check_code__init_A_const_52 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[76]); A_arbace_go_check_code__init_A_const_53 = A_arbace_go_check_code__init_A_const_pool.A[77]; A_arbace_go_check_code__init_A_const_54 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[78]); A_arbace_go_check_code__init_A_const_55 = A_arbace_go_check_code__init_A_const_pool.A[79]; A_arbace_go_check_code__init_A_const_56 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[80]); A_arbace_go_check_code__init_A_const_57 = A_arbace_go_check_code__init_A_const_pool.A[81]; A_arbace_go_check_code__init_A_const_58 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[82]); A_arbace_go_check_code__init_A_const_59 = A_arbace_go_check_code__init_A_const_pool.A[83]; A_arbace_go_check_code__init_A_const_60 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[84]); A_arbace_go_check_code__init_A_const_61 = A_arbace_go_check_code__init_A_const_pool.A[85]; A_arbace_go_check_code__init_A_const_62 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[86]); A_arbace_go_check_code__init_A_const_63 = A_arbace_go_check_code__init_A_const_pool.A[87]; A_arbace_go_check_code__init_A_const_64 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[88]) }

func A_arbace_go_check_code__init_A_clinit_p5() { A_arbace_go_check_code__init_A_const_65 = A_arbace_go_check_code__init_A_const_pool.A[89]; A_arbace_go_check_code__init_A_const_66 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[90]); A_arbace_go_check_code__init_A_const_67 = A_arbace_go_check_code__init_A_const_pool.A[91]; A_arbace_go_check_code__init_A_const_68 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[92]); A_arbace_go_check_code__init_A_const_69 = A_arbace_go_check_code__init_A_const_pool.A[93]; A_arbace_go_check_code__init_A_const_70 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[94]); A_arbace_go_check_code__init_A_const_71 = A_arbace_go_check_code__init_A_const_pool.A[95]; A_arbace_go_check_code__init_A_const_72 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[96]); A_arbace_go_check_code__init_A_const_73 = A_arbace_go_check_code__init_A_const_pool.A[97]; A_arbace_go_check_code__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[98]); A_arbace_go_check_code__init_A_const_75 = A_arbace_go_check_code__init_A_const_pool.A[99]; A_arbace_go_check_code__init_A_const_76 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[100]); A_arbace_go_check_code__init_A_const_77 = A_arbace_go_check_code__init_A_const_pool.A[101] }

func A_arbace_go_check_code__init_A_clinit_p6() { A_arbace_go_check_code__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[102]); A_arbace_go_check_code__init_A_const_79 = A_arbace_go_check_code__init_A_const_pool.A[103]; A_arbace_go_check_code__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[104]); A_arbace_go_check_code__init_A_const_81 = A_arbace_go_check_code__init_A_const_pool.A[105]; A_arbace_go_check_code__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[106]); A_arbace_go_check_code__init_A_const_83 = A_arbace_go_check_code__init_A_const_pool.A[107]; A_arbace_go_check_code__init_A_const_84 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[108]); A_arbace_go_check_code__init_A_const_85 = A_arbace_go_check_code__init_A_const_pool.A[109]; A_arbace_go_check_code__init_A_const_86 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[110]); A_arbace_go_check_code__init_A_const_87 = A_arbace_go_check_code__init_A_const_pool.A[111]; A_arbace_go_check_code__init_A_const_88 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[112]); A_arbace_go_check_code__init_A_const_89 = A_arbace_go_check_code__init_A_const_pool.A[113]; A_arbace_go_check_code__init_A_const_90 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[114]) }

func A_arbace_go_check_code__init_A_clinit_p7() { A_arbace_go_check_code__init_A_const_91 = A_arbace_go_check_code__init_A_const_pool.A[115]; A_arbace_go_check_code__init_A_const_92 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[116]); A_arbace_go_check_code__init_A_const_93 = A_arbace_go_check_code__init_A_const_pool.A[117]; A_arbace_go_check_code__init_A_const_94 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[118]); A_arbace_go_check_code__init_A_const_95 = A_arbace_go_check_code__init_A_const_pool.A[119]; A_arbace_go_check_code__init_A_const_96 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[120]); A_arbace_go_check_code__init_A_const_97 = A_arbace_go_check_code__init_A_const_pool.A[121]; A_arbace_go_check_code__init_A_const_98 = A_arbace_go_check_code__init_A_const_pool.A[122]; A_arbace_go_check_code__init_A_const_99 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[123]); A_arbace_go_check_code__init_A_const_100 = A_arbace_go_check_code__init_A_const_pool.A[124]; A_arbace_go_check_code__init_A_const_101 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[125]); A_arbace_go_check_code__init_A_const_102 = A_arbace_go_check_code__init_A_const_pool.A[126]; A_arbace_go_check_code__init_A_const_103 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[127]); A_arbace_go_check_code__init_A_const_104 = A_arbace_go_check_code__init_A_const_pool.A[128] }

func A_arbace_go_check_code__init_A_clinit_p8() { A_arbace_go_check_code__init_A_const_105 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[129]); A_arbace_go_check_code__init_A_const_106 = A_arbace_go_check_code__init_A_const_pool.A[130]; A_arbace_go_check_code__init_A_const_107 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[131]); A_arbace_go_check_code__init_A_const_108 = A_arbace_go_check_code__init_A_const_pool.A[132]; A_arbace_go_check_code__init_A_const_109 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[133]); A_arbace_go_check_code__init_A_const_110 = A_arbace_go_check_code__init_A_const_pool.A[134]; A_arbace_go_check_code__init_A_const_111 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[135]); A_arbace_go_check_code__init_A_const_112 = A_arbace_go_check_code__init_A_const_pool.A[136]; A_arbace_go_check_code__init_A_const_113 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[137]); A_arbace_go_check_code__init_A_const_114 = A_arbace_go_check_code__init_A_const_pool.A[138]; A_arbace_go_check_code__init_A_const_115 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[139]); A_arbace_go_check_code__init_A_const_116 = A_arbace_go_check_code__init_A_const_pool.A[140]; A_arbace_go_check_code__init_A_const_117 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[141]) }

func A_arbace_go_check_code__init_A_clinit_p9() { A_arbace_go_check_code__init_A_const_118 = A_arbace_go_check_code__init_A_const_pool.A[142]; A_arbace_go_check_code__init_A_const_119 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[143]); A_arbace_go_check_code__init_A_const_120 = A_arbace_go_check_code__init_A_const_pool.A[144]; A_arbace_go_check_code__init_A_const_121 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[145]); A_arbace_go_check_code__init_A_const_122 = A_arbace_go_check_code__init_A_const_pool.A[146]; A_arbace_go_check_code__init_A_const_123 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[147]); A_arbace_go_check_code__init_A_const_124 = A_arbace_go_check_code__init_A_const_pool.A[148]; A_arbace_go_check_code__init_A_const_125 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[149]); A_arbace_go_check_code__init_A_const_126 = A_arbace_go_check_code__init_A_const_pool.A[150]; A_arbace_go_check_code__init_A_const_127 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[151]); A_arbace_go_check_code__init_A_const_128 = A_arbace_go_check_code__init_A_const_pool.A[152]; A_arbace_go_check_code__init_A_const_129 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[153]); A_arbace_go_check_code__init_A_const_130 = A_arbace_go_check_code__init_A_const_pool.A[154]; A_arbace_go_check_code__init_A_const_131 = A_arbace_go_check_code__init_A_const_pool.A[155] }

func A_arbace_go_check_code__init_A_clinit_p10() { A_arbace_go_check_code__init_A_const_132 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[156]); A_arbace_go_check_code__init_A_const_133 = A_arbace_go_check_code__init_A_const_pool.A[157]; A_arbace_go_check_code__init_A_const_134 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[158]); A_arbace_go_check_code__init_A_const_135 = A_arbace_go_check_code__init_A_const_pool.A[159]; A_arbace_go_check_code__init_A_const_136 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[160]); A_arbace_go_check_code__init_A_const_137 = A_arbace_go_check_code__init_A_const_pool.A[161]; A_arbace_go_check_code__init_A_const_138 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[162]); A_arbace_go_check_code__init_A_const_139 = A_arbace_go_check_code__init_A_const_pool.A[163]; A_arbace_go_check_code__init_A_const_140 = A_arbace_go_check_code__init_A_const_pool.A[164]; A_arbace_go_check_code__init_A_const_141 = A_arbace_go_check_code__init_A_const_pool.A[165]; A_arbace_go_check_code__init_A_const_142 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[166]); A_arbace_go_check_code__init_A_const_143 = A_arbace_go_check_code__init_A_const_pool.A[167]; A_arbace_go_check_code__init_A_const_144 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[168]); A_arbace_go_check_code__init_A_const_145 = A_arbace_go_check_code__init_A_const_pool.A[169] }

func A_arbace_go_check_code__init_A_clinit_p11() { A_arbace_go_check_code__init_A_const_146 = A_arbace_go_check_code__init_A_const_pool.A[170]; A_arbace_go_check_code__init_A_const_147 = lang.Var_Cast(A_arbace_go_check_code__init_A_const_pool.A[171]) }

func A_arbace_go_check_code__init_A_New() *A_arbace_go_check_code__init_A { A_arbace_go_check_code__init_A_Init(); t := &A_arbace_go_check_code__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code__init_A) Ctor() {}

func (t *A_arbace_go_check_code__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code__init_A_class }

func (t *A_arbace_go_check_code__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code__init_A); return ok }

func A_arbace_go_check_code__init_A_Cast(x any) *A_arbace_go_check_code__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code__init_A_class)) }; return v }
