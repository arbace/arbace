//line aot_arbace_go_check_code__init.ae:1
package aot_arbace_go_check_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_code__init_part0_A_Unit0__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_code__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_check_code__init_part0_A_Unit1__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_code__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_check_code__init_part0_A_Unit2__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_812, false); A_arbace_go_check_code_eval181000004_loading__1927001464__auto____181000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_code__init_part0_A_Unit3__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_code__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_check_code__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_code_eval181000008_fn__181000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_code_eval181000008_fn__181000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_813, false); A_arbace_go_check_code_eval181000008_fn__181000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_go_check_code__init_part0_A_Init__O() any { A_arbace_go_check_code__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_check_code__init_part0_A_Load__O() any { A_arbace_go_check_code__init_part0_A_Init(); A_arbace_go_check_code__init_part0_A_Unit0__O(); A_arbace_go_check_code__init_part0_A_Unit1__O(); A_arbace_go_check_code__init_part0_A_Unit2__O(); A_arbace_go_check_code__init_part0_A_Unit3__O(); A_arbace_go_check_code__init_part0_A_Unit4__O(); A_arbace_go_check_code__init_part0_A_Unit5__O(); A_arbace_go_check_code__init_part0_A_Unit6__O(); A_arbace_go_check_code__init_part0_A_Unit7__O(); A_arbace_go_check_code__init_part0_A_Unit8__O(); A_arbace_go_check_code__init_part0_A_Unit9__O(); A_arbace_go_check_code__init_part0_A_Unit10__O(); A_arbace_go_check_code__init_part0_A_Unit11__O(); A_arbace_go_check_code__init_part0_A_Unit12__O(); A_arbace_go_check_code__init_part0_A_Unit13__O(); A_arbace_go_check_code__init_part0_A_Unit14__O(); A_arbace_go_check_code__init_part0_A_Unit15__O(); A_arbace_go_check_code__init_part0_A_Unit16__O(); A_arbace_go_check_code__init_part0_A_Unit17__O(); A_arbace_go_check_code__init_part0_A_Unit18__O(); A_arbace_go_check_code__init_part0_A_Unit19__O(); A_arbace_go_check_code__init_part0_A_Unit20__O(); A_arbace_go_check_code__init_part0_A_Unit21__O(); A_arbace_go_check_code__init_part0_A_Unit22__O(); A_arbace_go_check_code__init_part0_A_Unit23__O(); A_arbace_go_check_code__init_part0_A_Unit24__O(); A_arbace_go_check_code__init_part0_A_Unit25__O(); A_arbace_go_check_code__init_part0_A_Unit26__O(); A_arbace_go_check_code__init_part0_A_Unit27__O(); A_arbace_go_check_code__init_part0_A_Unit28__O(); A_arbace_go_check_code__init_part0_A_Unit29__O(); A_arbace_go_check_code__init_part0_A_Unit30__O(); A_arbace_go_check_code__init_part0_A_Unit31__O(); A_arbace_go_check_code__init_part0_A_Unit32__O(); A_arbace_go_check_code__init_part0_A_Unit33__O(); A_arbace_go_check_code__init_part0_A_Unit34__O(); A_arbace_go_check_code__init_part0_A_Unit35__O(); A_arbace_go_check_code__init_part0_A_Unit36__O(); A_arbace_go_check_code__init_part0_A_Unit37__O(); A_arbace_go_check_code__init_part0_A_Unit38__O(); A_arbace_go_check_code__init_part0_A_Unit39__O(); A_arbace_go_check_code__init_part0_A_Unit40__O(); A_arbace_go_check_code__init_part0_A_Unit41__O(); A_arbace_go_check_code__init_part0_A_Unit42__O(); A_arbace_go_check_code__init_part0_A_Unit43__O(); A_arbace_go_check_code__init_part0_A_Unit44__O(); A_arbace_go_check_code__init_part0_A_Unit45__O(); A_arbace_go_check_code__init_part0_A_Unit46__O(); A_arbace_go_check_code__init_part0_A_Unit47__O(); A_arbace_go_check_code__init_part0_A_Unit48__O(); A_arbace_go_check_code__init_part0_A_Unit49__O(); A_arbace_go_check_code__init_part0_A_Unit50__O(); A_arbace_go_check_code__init_part0_A_Unit51__O(); A_arbace_go_check_code__init_part0_A_Unit52__O(); A_arbace_go_check_code__init_part0_A_Unit53__O(); A_arbace_go_check_code__init_part0_A_Unit54__O(); A_arbace_go_check_code__init_part0_A_Unit55__O(); A_arbace_go_check_code__init_part0_A_Unit56__O(); A_arbace_go_check_code__init_part0_A_Unit57__O(); A_arbace_go_check_code__init_part0_A_Unit58__O(); A_arbace_go_check_code__init_part0_A_Unit59__O(); A_arbace_go_check_code__init_part0_A_Unit60__O(); A_arbace_go_check_code__init_part0_A_Unit61__O(); A_arbace_go_check_code__init_part0_A_Unit62__O(); A_arbace_go_check_code__init_part0_A_Unit63__O(); A_arbace_go_check_code__init_part0_A_Unit64__O(); A_arbace_go_check_code__init_part0_A_Unit65__O(); A_arbace_go_check_code__init_part0_A_Unit66__O(); A_arbace_go_check_code__init_part0_A_Unit67__O(); A_arbace_go_check_code__init_part0_A_Unit68__O(); A_arbace_go_check_code__init_part0_A_Unit69__O(); A_arbace_go_check_code__init_part0_A_Unit70__O(); A_arbace_go_check_code__init_part0_A_Unit71__O(); A_arbace_go_check_code__init_part0_A_Unit72__O(); A_arbace_go_check_code__init_part0_A_Unit73__O(); A_arbace_go_check_code__init_part0_A_Unit74__O(); A_arbace_go_check_code__init_part0_A_Unit75__O(); A_arbace_go_check_code__init_part0_A_Unit76__O(); A_arbace_go_check_code__init_part0_A_Unit77__O(); A_arbace_go_check_code__init_part0_A_Unit78__O(); A_arbace_go_check_code__init_part0_A_Unit79__O(); A_arbace_go_check_code__init_part0_A_Unit80__O(); A_arbace_go_check_code__init_part0_A_Unit81__O(); A_arbace_go_check_code__init_part0_A_Unit82__O(); A_arbace_go_check_code__init_part0_A_Unit83__O(); A_arbace_go_check_code__init_part0_A_Unit84__O(); A_arbace_go_check_code__init_part0_A_Unit85__O(); A_arbace_go_check_code__init_part0_A_Unit86__O(); A_arbace_go_check_code__init_part0_A_Unit87__O(); A_arbace_go_check_code__init_part0_A_Unit88__O(); A_arbace_go_check_code__init_part0_A_Unit89__O(); A_arbace_go_check_code__init_part0_A_Unit90__O(); A_arbace_go_check_code__init_part0_A_Unit91__O(); A_arbace_go_check_code__init_part0_A_Unit92__O(); A_arbace_go_check_code__init_part0_A_Unit93__O(); A_arbace_go_check_code__init_part0_A_Unit94__O(); A_arbace_go_check_code__init_part0_A_Unit95__O(); A_arbace_go_check_code__init_part0_A_Unit96__O(); A_arbace_go_check_code__init_part0_A_Unit97__O(); A_arbace_go_check_code__init_part0_A_Unit98__O(); A_arbace_go_check_code__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_check_code__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_check_code__init_part0_A_Init__O(); A_arbace_go_check_code__init_part1_A_Init__O(); A_arbace_go_check_code__init_part0_A_Load__O(); A_arbace_go_check_code__init_part1_A_Load__O(); return nil }










func A_arbace_go_check_code__init_part0_A_Unit4__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_5)); return A_arbace_go_check_code__init_part0_A_const_4 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit5__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_7)); return A_arbace_go_check_code__init_part0_A_const_6 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit6__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_9)); return A_arbace_go_check_code__init_part0_A_const_8 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit7__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_11)); return A_arbace_go_check_code__init_part0_A_const_10 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit8__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_13)); return A_arbace_go_check_code__init_part0_A_const_12 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit9__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_15)); return A_arbace_go_check_code__init_part0_A_const_14 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit10__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_17)); return A_arbace_go_check_code__init_part0_A_const_16 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit11__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_19)); return A_arbace_go_check_code__init_part0_A_const_18 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit12__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_21)); return A_arbace_go_check_code__init_part0_A_const_20 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit13__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_23)); return A_arbace_go_check_code__init_part0_A_const_22 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit14__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_25)); return A_arbace_go_check_code__init_part0_A_const_24 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit15__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_27)); return A_arbace_go_check_code__init_part0_A_const_26 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit16__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_29)); return A_arbace_go_check_code__init_part0_A_const_28 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit17__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_31)); return A_arbace_go_check_code__init_part0_A_const_30 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit18__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_33)); return A_arbace_go_check_code__init_part0_A_const_32 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit19__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_35)); return A_arbace_go_check_code__init_part0_A_const_34 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit20__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_37)); return A_arbace_go_check_code__init_part0_A_const_36 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit21__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_39)); return A_arbace_go_check_code__init_part0_A_const_38 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit22__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_41)); return A_arbace_go_check_code__init_part0_A_const_40 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit23__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_43)); return A_arbace_go_check_code__init_part0_A_const_42 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit24__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_45)); return A_arbace_go_check_code__init_part0_A_const_44 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit25__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_47)); return A_arbace_go_check_code__init_part0_A_const_46 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit26__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_49)); return A_arbace_go_check_code__init_part0_A_const_48 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit27__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_50; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_51)); return A_arbace_go_check_code__init_part0_A_const_50 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit28__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_53)); return A_arbace_go_check_code__init_part0_A_const_52 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit29__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_55)); return A_arbace_go_check_code__init_part0_A_const_54 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit30__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_57)); return A_arbace_go_check_code__init_part0_A_const_56 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit31__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_59)); return A_arbace_go_check_code__init_part0_A_const_58 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit32__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_61)); return A_arbace_go_check_code__init_part0_A_const_60 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit33__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_63)); return A_arbace_go_check_code__init_part0_A_const_62 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit34__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_65)); return A_arbace_go_check_code__init_part0_A_const_64 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit35__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_67)); return A_arbace_go_check_code__init_part0_A_const_66 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit36__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_69)); return A_arbace_go_check_code__init_part0_A_const_68 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit37__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_71)); return A_arbace_go_check_code__init_part0_A_const_70 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit38__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_73)); return A_arbace_go_check_code__init_part0_A_const_72 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit39__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_75)); return A_arbace_go_check_code__init_part0_A_const_74 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit40__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_77)); return A_arbace_go_check_code__init_part0_A_const_76 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit41__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_79)); return A_arbace_go_check_code__init_part0_A_const_78 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit42__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_81)); return A_arbace_go_check_code__init_part0_A_const_80 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit43__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_83)); return A_arbace_go_check_code__init_part0_A_const_82 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit44__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_85)); return A_arbace_go_check_code__init_part0_A_const_84 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit45__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_87)); return A_arbace_go_check_code__init_part0_A_const_86 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit46__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_89)); return A_arbace_go_check_code__init_part0_A_const_88 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit47__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_91)); return A_arbace_go_check_code__init_part0_A_const_90 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit48__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_93)); return A_arbace_go_check_code__init_part0_A_const_92 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit49__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_95)); return A_arbace_go_check_code__init_part0_A_const_94 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit50__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_97)); return A_arbace_go_check_code__init_part0_A_const_96 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit51__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_99)); return A_arbace_go_check_code__init_part0_A_const_98 }
//line :16:1
func A_arbace_go_check_code__init_part0_A_Unit52__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_101)); return A_arbace_go_check_code__init_part0_A_const_100 }




func A_arbace_go_check_code__init_part0_A_Unit53__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_go_check_code__init_part0_A_const_102.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_103)); return A_arbace_go_check_code__init_part0_A_const_102.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_code__init_part0_A_Unit54__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); A_arbace_go_check_code__init_part0_A_const_104.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_105)); return A_arbace_go_check_code__init_part0_A_const_104.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_code__init_part0_A_Unit55__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_go_check_code__init_part0_A_const_106.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_106; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_107)); return A_arbace_go_check_code__init_part0_A_const_106.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_code__init_part0_A_Unit56__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_go_check_code__init_part0_A_const_108.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_109)); return A_arbace_go_check_code__init_part0_A_const_108.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_code__init_part0_A_Unit57__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_code__init_part0_A_const_110.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_111)); return A_arbace_go_check_code__init_part0_A_const_110.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_code__init_part0_A_Unit58__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_112; var tmp2 any = A_arbace_go_check_code_cycle_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_code_cycle_error_BANG__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_814, false); A_arbace_go_check_code_cycle_error_BANG__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_113)); return A_arbace_go_check_code__init_part0_A_const_112 }
















func A_arbace_go_check_code__init_part0_A_Unit59__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_114; var tmp2 any = A_arbace_go_check_code_obj_entry_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_code_obj_entry_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_815, false); A_arbace_go_check_code_obj_entry_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_115)); return A_arbace_go_check_code__init_part0_A_const_114 }




func A_arbace_go_check_code__init_part0_A_Unit60__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_116; var tmp2 any = A_arbace_go_check_code_named_entry_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_code_named_entry_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_816, false); A_arbace_go_check_code_named_entry_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_117)); return A_arbace_go_check_code__init_part0_A_const_116 }









func A_arbace_go_check_code__init_part0_A_Unit61__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_118; var tmp2 any = A_arbace_go_check_code_valid_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_code_valid_type_BANG__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_817, false); A_arbace_go_check_code_valid_type_BANG__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_119)); return A_arbace_go_check_code__init_part0_A_const_118 }













































func A_arbace_go_check_code__init_part0_A_Unit62__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); A_arbace_go_check_code__init_part0_A_const_120.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_120; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_121)); return A_arbace_go_check_code__init_part0_A_const_120.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_code__init_part0_A_Unit63__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_122; var tmp2 any = A_arbace_go_check_code_valid_type_later_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_code_valid_type_later_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_818, false); A_arbace_go_check_code_valid_type_later_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_123)); return A_arbace_go_check_code__init_part0_A_const_122 }









func A_arbace_go_check_code__init_part0_A_Unit64__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); A_arbace_go_check_code__init_part0_A_const_124.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_125)); return A_arbace_go_check_code__init_part0_A_const_124.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_code__init_part0_A_Unit65__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); A_arbace_go_check_code__init_part0_A_const_126.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_126; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_127)); return A_arbace_go_check_code__init_part0_A_const_126.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_code__init_part0_A_Unit66__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_128; var tmp2 any = A_arbace_go_check_code_anon_cycle_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_code_anon_cycle_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_819, false); A_arbace_go_check_code_anon_cycle_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_129)); return A_arbace_go_check_code__init_part0_A_const_128 }























func A_arbace_go_check_code__init_part0_A_Unit67__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_130; var tmp2 any = A_arbace_go_check_code_anon_iface_cycles_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_820, false); A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_131)); return A_arbace_go_check_code__init_part0_A_const_130 }










func A_arbace_go_check_code__init_part0_A_Unit68__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_132; var tmp2 any = A_arbace_go_check_code_head_name_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_code_head_name_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_821, false); A_arbace_go_check_code_head_name_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_133)); return A_arbace_go_check_code__init_part0_A_const_132 }









func A_arbace_go_check_code__init_part0_A_Unit69__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_134; var tmp2 any = A_arbace_go_check_code_go_id_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_code_go_id_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_822, false); A_arbace_go_check_code_go_id_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_135)); return A_arbace_go_check_code__init_part0_A_const_134 }




func A_arbace_go_check_code__init_part0_A_Unit70__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_136; var tmp2 any = A_arbace_go_check_code_ident_name_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_code_ident_name_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_823, false); A_arbace_go_check_code_ident_name_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_137)); return A_arbace_go_check_code__init_part0_A_const_136 }




func A_arbace_go_check_code__init_part0_A_Unit71__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_138; var tmp2 any = A_arbace_go_check_code_go_ident_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_code_go_ident_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_824, false); A_arbace_go_check_code_go_ident_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_139)); return A_arbace_go_check_code__init_part0_A_const_138 }

func A_arbace_go_check_code__init_part0_A_Unit72__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_140; var tmp2 any = A_arbace_go_check_code_fline_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_code_fline_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_825, false); A_arbace_go_check_code_fline_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_141)); return A_arbace_go_check_code__init_part0_A_const_140 }

func A_arbace_go_check_code__init_part0_A_Unit73__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_142; var tmp2 any = A_arbace_go_check_code_with_line_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_code_with_line_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_826, true); A_arbace_go_check_code_with_line_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_143)); return A_arbace_go_check_code__init_part0_A_const_142 }
//line :201:1
func A_arbace_go_check_code__init_part0_A_Unit74__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); A_arbace_go_check_code__init_part0_A_const_142.SetMacro__V(); return nil }
//line :201:1
func A_arbace_go_check_code__init_part0_A_Unit75__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); return A_arbace_go_check_code__init_part0_A_const_142 }





func A_arbace_go_check_code__init_part0_A_Unit76__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_144; var tmp2 any = A_arbace_go_check_code_with_elem_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_code_with_elem_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_827, true); A_arbace_go_check_code_with_elem_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_145)); return A_arbace_go_check_code__init_part0_A_const_144 }
//line :207:1
func A_arbace_go_check_code__init_part0_A_Unit77__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); A_arbace_go_check_code__init_part0_A_const_144.SetMacro__V(); return nil }
//line :207:1
func A_arbace_go_check_code__init_part0_A_Unit78__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); return A_arbace_go_check_code__init_part0_A_const_144 }













func A_arbace_go_check_code__init_part0_A_Unit79__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(221, 1); A_arbace_go_check_code__init_part0_A_const_146.BindRoot_O__V(A_arbace_go_check_code__init_part0_A_const_147); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_146; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_148)); return A_arbace_go_check_code__init_part0_A_const_146 }








func A_arbace_go_check_code__init_part0_A_Unit80__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_149; var tmp2 any = A_arbace_go_check_code_lang_minor_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_code_lang_minor_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_828, false); A_arbace_go_check_code_lang_minor_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_150)); return A_arbace_go_check_code__init_part0_A_const_149 }






func A_arbace_go_check_code__init_part0_A_Unit81__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(237, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_151; var tmp2 any = A_arbace_go_check_code_allow_version_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_code_allow_version_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_829, false); A_arbace_go_check_code_allow_version_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_152)); return A_arbace_go_check_code__init_part0_A_const_151 }



func A_arbace_go_check_code__init_part0_A_Unit82__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_100; var tmp2 any = A_arbace_go_check_code_pkg_path_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_code_pkg_path_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_830, false); A_arbace_go_check_code_pkg_path_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_153)); return A_arbace_go_check_code__init_part0_A_const_100 }

func A_arbace_go_check_code__init_part0_A_Unit83__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_154; var tmp2 any = A_arbace_go_check_code_package_level_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_code_package_level_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_831, false); A_arbace_go_check_code_package_level_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_155)); return A_arbace_go_check_code__init_part0_A_const_154 }

func A_arbace_go_check_code__init_part0_A_Unit84__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_156; var tmp2 any = A_arbace_go_check_code_note_ref_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_code_note_ref_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_832, false); A_arbace_go_check_code_note_ref_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_157)); return A_arbace_go_check_code__init_part0_A_const_156 }








func A_arbace_go_check_code__init_part0_A_Unit85__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_158; var tmp2 any = A_arbace_go_check_code_use_var_BANG__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_code_use_var_BANG__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_833, false); A_arbace_go_check_code_use_var_BANG__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_159)); return A_arbace_go_check_code__init_part0_A_const_158 }








func A_arbace_go_check_code__init_part0_A_Unit86__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_160; var tmp2 any = A_arbace_go_check_code_resolve_name_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_code_resolve_name_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_834, false); A_arbace_go_check_code_resolve_name_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_161)); return A_arbace_go_check_code__init_part0_A_const_160 }

















func A_arbace_go_check_code__init_part0_A_Unit87__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_162; var tmp2 any = A_arbace_go_check_code_object_kind_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_code_object_kind_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_835, false); A_arbace_go_check_code_object_kind_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_163)); return A_arbace_go_check_code__init_part0_A_const_162 }


















func A_arbace_go_check_code__init_part0_A_Unit88__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_164; var tmp2 any = A_arbace_go_check_code_package_by_qualifier_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_code_package_by_qualifier_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_836, false); A_arbace_go_check_code_package_by_qualifier_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_165)); return A_arbace_go_check_code__init_part0_A_const_164 }










func A_arbace_go_check_code__init_part0_A_Unit89__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_166; var tmp2 any = A_arbace_go_check_code_qualified_obj_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_check_code_qualified_obj_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_837, false); A_arbace_go_check_code_qualified_obj_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_167)); return A_arbace_go_check_code__init_part0_A_const_166 }





















func A_arbace_go_check_code__init_part0_A_Unit90__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(333, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_168; var tmp2 any = A_arbace_go_check_code_type_params_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_code_type_params_generic_BANG__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_838, false); A_arbace_go_check_code_type_params_generic_BANG__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_169)); return A_arbace_go_check_code__init_part0_A_const_168 }

func A_arbace_go_check_code__init_part0_A_Unit91__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_170; var tmp2 any = A_arbace_go_check_code_type_of_obj_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_code_type_of_obj_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_839, false); A_arbace_go_check_code_type_of_obj_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_171)); return A_arbace_go_check_code__init_part0_A_const_170 }
















func A_arbace_go_check_code__init_part0_A_Unit92__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_172; var tmp2 any = A_arbace_go_check_code_ident_type_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_code_ident_type_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_840, false); A_arbace_go_check_code_ident_type_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_173)); return A_arbace_go_check_code__init_part0_A_const_172 }



























func A_arbace_go_check_code__init_part0_A_Unit93__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(380, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_174; var tmp2 any = A_arbace_go_check_code_tag_type_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_code_tag_type_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_841, false); A_arbace_go_check_code_tag_type_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_175)); return A_arbace_go_check_code__init_part0_A_const_174 }





func A_arbace_go_check_code__init_part0_A_Unit94__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_176; var tmp2 any = A_arbace_go_check_code_struct_field_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_code_struct_field_type_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_842, false); A_arbace_go_check_code_struct_field_type_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_177)); return A_arbace_go_check_code__init_part0_A_const_176 }

func A_arbace_go_check_code__init_part0_A_Unit95__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_178; var tmp2 any = A_arbace_go_check_code_embedded_name_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_code_embedded_name_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_843, false); A_arbace_go_check_code_embedded_name_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_179)); return A_arbace_go_check_code__init_part0_A_const_178 }










func A_arbace_go_check_code__init_part0_A_Unit96__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_180; var tmp2 any = A_arbace_go_check_code_struct_type_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_code_struct_type_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_844, false); A_arbace_go_check_code_struct_type_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_181)); return A_arbace_go_check_code__init_part0_A_const_180 }








































func A_arbace_go_check_code__init_part0_A_Unit97__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(440, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_182)); return A_arbace_go_check_code__init_part0_A_const_74 }
//line :440:1
func A_arbace_go_check_code__init_part0_A_Unit98__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(440, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_183; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_184)); return A_arbace_go_check_code__init_part0_A_const_183 }

func A_arbace_go_check_code__init_part0_A_Unit99__O() any { A_arbace_go_check_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part0_A_const_185; var tmp2 any = A_arbace_go_check_code_method_elem_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_check_code_method_elem_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_845, false); A_arbace_go_check_code_method_elem_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part0_A_const_186)); return A_arbace_go_check_code__init_part0_A_const_185 }

func A_arbace_go_check_code__init_part1_A_Unit100__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_0; var tmp2 any = A_arbace_go_check_code_union_type_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_code_union_type_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_847, false); A_arbace_go_check_code_union_type_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_1)); return A_arbace_go_check_code__init_part1_A_const_0 }
//line :444:1
func A_arbace_go_check_code__init_part1_A_Init__O() any { A_arbace_go_check_code__init_part1_A_Init(); return nil }
//line :444:1
func A_arbace_go_check_code__init_part1_A_Load__O() any { A_arbace_go_check_code__init_part1_A_Init(); A_arbace_go_check_code__init_part1_A_Unit100__O(); A_arbace_go_check_code__init_part1_A_Unit101__O(); A_arbace_go_check_code__init_part1_A_Unit102__O(); A_arbace_go_check_code__init_part1_A_Unit103__O(); A_arbace_go_check_code__init_part1_A_Unit104__O(); A_arbace_go_check_code__init_part1_A_Unit105__O(); A_arbace_go_check_code__init_part1_A_Unit106__O(); A_arbace_go_check_code__init_part1_A_Unit107__O(); A_arbace_go_check_code__init_part1_A_Unit108__O(); A_arbace_go_check_code__init_part1_A_Unit109__O(); A_arbace_go_check_code__init_part1_A_Unit110__O(); A_arbace_go_check_code__init_part1_A_Unit111__O(); A_arbace_go_check_code__init_part1_A_Unit112__O(); A_arbace_go_check_code__init_part1_A_Unit113__O(); A_arbace_go_check_code__init_part1_A_Unit114__O(); A_arbace_go_check_code__init_part1_A_Unit115__O(); A_arbace_go_check_code__init_part1_A_Unit116__O(); A_arbace_go_check_code__init_part1_A_Unit117__O(); A_arbace_go_check_code__init_part1_A_Unit118__O(); A_arbace_go_check_code__init_part1_A_Unit119__O(); A_arbace_go_check_code__init_part1_A_Unit120__O(); return nil }


























func A_arbace_go_check_code__init_part1_A_Unit101__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_2; var tmp2 any = A_arbace_go_check_code_intersect_term_lists_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_code_intersect_term_lists_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_848, false); A_arbace_go_check_code_intersect_term_lists_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_3)); return A_arbace_go_check_code__init_part1_A_const_2 }








func A_arbace_go_check_code__init_part1_A_Unit102__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(480, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_5)); return A_arbace_go_check_code__init_part1_A_const_4 }

func A_arbace_go_check_code__init_part1_A_Unit103__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_6; var tmp2 any = A_arbace_go_check_code_interface_type_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_code_interface_type_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_849, false); A_arbace_go_check_code_interface_type_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_7)); return A_arbace_go_check_code__init_part1_A_const_6 }








func A_arbace_go_check_code__init_part1_A_Unit104__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(491, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_4; var tmp2 any = A_arbace_go_check_code_interface_type_STAR__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_code_interface_type_STAR__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_850, false); A_arbace_go_check_code_interface_type_STAR__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_8)); return A_arbace_go_check_code__init_part1_A_const_4 }




























































func A_arbace_go_check_code__init_part1_A_Unit105__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_9; var tmp2 any = A_arbace_go_check_code_array_length_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_code_array_length_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_851, false); A_arbace_go_check_code_array_length_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_10)); return A_arbace_go_check_code__init_part1_A_const_9 }






















func A_arbace_go_check_code__init_part1_A_Unit106__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(575, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_11; var tmp2 any = A_arbace_go_check_code_chan_type_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_code_chan_type_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_852, false); A_arbace_go_check_code_chan_type_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_12)); return A_arbace_go_check_code__init_part1_A_const_11 }






func A_arbace_go_check_code__init_part1_A_Unit107__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_13; var tmp2 any = A_arbace_go_check_code_typexpr_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_code_typexpr_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_853, false); A_arbace_go_check_code_typexpr_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_14)); return A_arbace_go_check_code__init_part1_A_const_13 }







































func A_arbace_go_check_code__init_part1_A_Unit108__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(622, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_15; var tmp2 any = A_arbace_go_check_code_generic_type_obj_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_code_generic_type_obj_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_854, false); A_arbace_go_check_code_generic_type_obj_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_16)); return A_arbace_go_check_code__init_part1_A_const_15 }










func A_arbace_go_check_code__init_part1_A_Unit109__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(633, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_17; var tmp2 any = A_arbace_go_check_code_typexpr_generic_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_code_typexpr_generic_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_855, false); A_arbace_go_check_code_typexpr_generic_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_18)); return A_arbace_go_check_code__init_part1_A_const_17 }




func A_arbace_go_check_code__init_part1_A_Unit110__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(638, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_19; var tmp2 any = A_arbace_go_check_code_instance_type_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_code_instance_type_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_856, false); A_arbace_go_check_code_instance_type_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_20)); return A_arbace_go_check_code__init_part1_A_const_19 }





















func A_arbace_go_check_code__init_part1_A_Unit111__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(660, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_21; var tmp2 any = A_arbace_go_check_code_tparam_scope_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_code_tparam_scope_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_857, false); A_arbace_go_check_code_tparam_scope_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_22)); return A_arbace_go_check_code__init_part1_A_const_21 }










































func A_arbace_go_check_code__init_part1_A_Unit112__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(703, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_23; var tmp2 any = A_arbace_go_check_code_param_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_code_param_name_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_858, false); A_arbace_go_check_code_param_name_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_24)); return A_arbace_go_check_code__init_part1_A_const_23 }

func A_arbace_go_check_code__init_part1_A_Unit113__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(705, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_25; var tmp2 any = A_arbace_go_check_code_params_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_code_params_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_859, false); A_arbace_go_check_code_params_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_26)); return A_arbace_go_check_code__init_part1_A_const_25 }












func A_arbace_go_check_code__init_part1_A_Unit114__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_27; var tmp2 any = A_arbace_go_check_code_dup_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_code_dup_params_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_860, false); A_arbace_go_check_code_dup_params_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_28)); return A_arbace_go_check_code__init_part1_A_const_27 }











func A_arbace_go_check_code__init_part1_A_Unit115__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(730, 1); var tmp1 *lang.Var = A_arbace_go_check_code__init_part1_A_const_29; var tmp2 any = A_arbace_go_check_code_signature_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_code_signature_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_861, false); A_arbace_go_check_code_signature_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code__init_part1_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code__init_part1_A_const_30)); return A_arbace_go_check_code__init_part1_A_const_29 }




















func A_arbace_go_check_code__init_part1_A_Unit116__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part1_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_862) }
func A_arbace_go_check_code__init_part1_A_Unit117__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(752, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part1_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_863) }
func A_arbace_go_check_code__init_part1_A_Unit118__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(753, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part1_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_864) }
func A_arbace_go_check_code__init_part1_A_Unit119__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part1_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_865) }
func A_arbace_go_check_code__init_part1_A_Unit120__O() any { A_arbace_go_check_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(755, 1); return lang.IFn_Cast(A_arbace_go_check_code__init_part1_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_866) }



type A_arbace_go_check_code__init_A struct{ jrt.Object }

func A_arbace_go_check_code__init_A_New() *A_arbace_go_check_code__init_A { t := &A_arbace_go_check_code__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code__init_A) Ctor() {}

func (t *A_arbace_go_check_code__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code__init_A_class }

func (t *A_arbace_go_check_code__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code__init_A); return ok }

func A_arbace_go_check_code__init_A_Cast(x any) *A_arbace_go_check_code__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code__init_A_class)) }; return v }



type A_arbace_go_check_code__init_part0_A struct{ jrt.Object }

var A_arbace_go_check_code__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_check_code__init_part0_A_const_0 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_1 any

var A_arbace_go_check_code__init_part0_A_const_2 any

var A_arbace_go_check_code__init_part0_A_const_3 any

var A_arbace_go_check_code__init_part0_A_const_4 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_5 any

var A_arbace_go_check_code__init_part0_A_const_6 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_7 any

var A_arbace_go_check_code__init_part0_A_const_8 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_9 any

var A_arbace_go_check_code__init_part0_A_const_10 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_11 any

var A_arbace_go_check_code__init_part0_A_const_12 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_13 any

var A_arbace_go_check_code__init_part0_A_const_14 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_15 any

var A_arbace_go_check_code__init_part0_A_const_16 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_17 any

var A_arbace_go_check_code__init_part0_A_const_18 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_19 any

var A_arbace_go_check_code__init_part0_A_const_20 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_21 any

var A_arbace_go_check_code__init_part0_A_const_22 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_23 any

var A_arbace_go_check_code__init_part0_A_const_24 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_25 any

var A_arbace_go_check_code__init_part0_A_const_26 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_27 any

var A_arbace_go_check_code__init_part0_A_const_28 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_29 any

var A_arbace_go_check_code__init_part0_A_const_30 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_31 any

var A_arbace_go_check_code__init_part0_A_const_32 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_33 any

var A_arbace_go_check_code__init_part0_A_const_34 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_35 any

var A_arbace_go_check_code__init_part0_A_const_36 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_37 any

var A_arbace_go_check_code__init_part0_A_const_38 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_39 any

var A_arbace_go_check_code__init_part0_A_const_40 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_41 any

var A_arbace_go_check_code__init_part0_A_const_42 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_43 any

var A_arbace_go_check_code__init_part0_A_const_44 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_45 any

var A_arbace_go_check_code__init_part0_A_const_46 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_47 any

var A_arbace_go_check_code__init_part0_A_const_48 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_49 any

var A_arbace_go_check_code__init_part0_A_const_50 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_51 any

var A_arbace_go_check_code__init_part0_A_const_52 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_53 any

var A_arbace_go_check_code__init_part0_A_const_54 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_55 any

var A_arbace_go_check_code__init_part0_A_const_56 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_57 any

var A_arbace_go_check_code__init_part0_A_const_58 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_59 any

var A_arbace_go_check_code__init_part0_A_const_60 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_61 any

var A_arbace_go_check_code__init_part0_A_const_62 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_63 any

var A_arbace_go_check_code__init_part0_A_const_64 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_65 any

var A_arbace_go_check_code__init_part0_A_const_66 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_67 any

var A_arbace_go_check_code__init_part0_A_const_68 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_69 any

var A_arbace_go_check_code__init_part0_A_const_70 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_71 any

var A_arbace_go_check_code__init_part0_A_const_72 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_73 any

var A_arbace_go_check_code__init_part0_A_const_74 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_75 any

var A_arbace_go_check_code__init_part0_A_const_76 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_77 any

var A_arbace_go_check_code__init_part0_A_const_78 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_79 any

var A_arbace_go_check_code__init_part0_A_const_80 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_81 any

var A_arbace_go_check_code__init_part0_A_const_82 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_83 any

var A_arbace_go_check_code__init_part0_A_const_84 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_85 any

var A_arbace_go_check_code__init_part0_A_const_86 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_87 any

var A_arbace_go_check_code__init_part0_A_const_88 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_89 any

var A_arbace_go_check_code__init_part0_A_const_90 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_91 any

var A_arbace_go_check_code__init_part0_A_const_92 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_93 any

var A_arbace_go_check_code__init_part0_A_const_94 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_95 any

var A_arbace_go_check_code__init_part0_A_const_96 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_97 any

var A_arbace_go_check_code__init_part0_A_const_98 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_99 any

var A_arbace_go_check_code__init_part0_A_const_100 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_101 any

var A_arbace_go_check_code__init_part0_A_const_102 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_103 any

var A_arbace_go_check_code__init_part0_A_const_104 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_105 any

var A_arbace_go_check_code__init_part0_A_const_106 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_107 any

var A_arbace_go_check_code__init_part0_A_const_108 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_109 any

var A_arbace_go_check_code__init_part0_A_const_110 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_111 any

var A_arbace_go_check_code__init_part0_A_const_112 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_113 any

var A_arbace_go_check_code__init_part0_A_const_114 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_115 any

var A_arbace_go_check_code__init_part0_A_const_116 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_117 any

var A_arbace_go_check_code__init_part0_A_const_118 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_119 any

var A_arbace_go_check_code__init_part0_A_const_120 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_121 any

var A_arbace_go_check_code__init_part0_A_const_122 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_123 any

var A_arbace_go_check_code__init_part0_A_const_124 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_125 any

var A_arbace_go_check_code__init_part0_A_const_126 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_127 any

var A_arbace_go_check_code__init_part0_A_const_128 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_129 any

var A_arbace_go_check_code__init_part0_A_const_130 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_131 any

var A_arbace_go_check_code__init_part0_A_const_132 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_133 any

var A_arbace_go_check_code__init_part0_A_const_134 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_135 any

var A_arbace_go_check_code__init_part0_A_const_136 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_137 any

var A_arbace_go_check_code__init_part0_A_const_138 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_139 any

var A_arbace_go_check_code__init_part0_A_const_140 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_141 any

var A_arbace_go_check_code__init_part0_A_const_142 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_143 any

var A_arbace_go_check_code__init_part0_A_const_144 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_145 any

var A_arbace_go_check_code__init_part0_A_const_146 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_147 any

var A_arbace_go_check_code__init_part0_A_const_148 any

var A_arbace_go_check_code__init_part0_A_const_149 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_150 any

var A_arbace_go_check_code__init_part0_A_const_151 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_152 any

var A_arbace_go_check_code__init_part0_A_const_153 any

var A_arbace_go_check_code__init_part0_A_const_154 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_155 any

var A_arbace_go_check_code__init_part0_A_const_156 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_157 any

var A_arbace_go_check_code__init_part0_A_const_158 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_159 any

var A_arbace_go_check_code__init_part0_A_const_160 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_161 any

var A_arbace_go_check_code__init_part0_A_const_162 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_163 any

var A_arbace_go_check_code__init_part0_A_const_164 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_165 any

var A_arbace_go_check_code__init_part0_A_const_166 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_167 any

var A_arbace_go_check_code__init_part0_A_const_168 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_169 any

var A_arbace_go_check_code__init_part0_A_const_170 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_171 any

var A_arbace_go_check_code__init_part0_A_const_172 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_173 any

var A_arbace_go_check_code__init_part0_A_const_174 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_175 any

var A_arbace_go_check_code__init_part0_A_const_176 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_177 any

var A_arbace_go_check_code__init_part0_A_const_178 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_179 any

var A_arbace_go_check_code__init_part0_A_const_180 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_181 any

var A_arbace_go_check_code__init_part0_A_const_182 any

var A_arbace_go_check_code__init_part0_A_const_183 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_184 any

var A_arbace_go_check_code__init_part0_A_const_185 *lang.Var

var A_arbace_go_check_code__init_part0_A_const_186 any

var A_arbace_go_check_code__init_part0_A_init jrt.ClassInit

func A_arbace_go_check_code__init_part0_A_Init() { if !A_arbace_go_check_code__init_part0_A_init.Done() { A_arbace_go_check_code__init_part0_A_init.Run(A_arbace_go_check_code__init_part0_A_clinit) } }

func A_arbace_go_check_code__init_part0_A_clinit() { A_arbace_go_check_code__init_part0_A_clinit_p0(); A_arbace_go_check_code__init_part0_A_clinit_p1(); A_arbace_go_check_code__init_part0_A_clinit_p2(); A_arbace_go_check_code__init_part0_A_clinit_p3(); A_arbace_go_check_code__init_part0_A_clinit_p4(); A_arbace_go_check_code__init_part0_A_clinit_p5(); A_arbace_go_check_code__init_part0_A_clinit_p6(); A_arbace_go_check_code__init_part0_A_clinit_p7(); A_arbace_go_check_code__init_part0_A_clinit_p8(); A_arbace_go_check_code__init_part0_A_clinit_p9(); A_arbace_go_check_code__init_part0_A_clinit_p10(); A_arbace_go_check_code__init_part0_A_clinit_p11(); A_arbace_go_check_code__init_part0_A_clinit_p12(); A_arbace_go_check_code__init_part0_A_clinit_p13(); A_arbace_go_check_code__init_part0_A_clinit_p14() }

func A_arbace_go_check_code__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_code__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_811, 216); A_arbace_go_check_code__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[29]); A_arbace_go_check_code__init_part0_A_const_1 = A_arbace_go_check_code__init_part0_A_const_pool.A[30]; A_arbace_go_check_code__init_part0_A_const_2 = A_arbace_go_check_code__init_part0_A_const_pool.A[31]; A_arbace_go_check_code__init_part0_A_const_3 = A_arbace_go_check_code__init_part0_A_const_pool.A[32]; A_arbace_go_check_code__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[33]); A_arbace_go_check_code__init_part0_A_const_5 = A_arbace_go_check_code__init_part0_A_const_pool.A[34]; A_arbace_go_check_code__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[35]); A_arbace_go_check_code__init_part0_A_const_7 = A_arbace_go_check_code__init_part0_A_const_pool.A[36]; A_arbace_go_check_code__init_part0_A_const_8 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[37]); A_arbace_go_check_code__init_part0_A_const_9 = A_arbace_go_check_code__init_part0_A_const_pool.A[38]; A_arbace_go_check_code__init_part0_A_const_10 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[39]); A_arbace_go_check_code__init_part0_A_const_11 = A_arbace_go_check_code__init_part0_A_const_pool.A[40]; A_arbace_go_check_code__init_part0_A_const_12 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[41]) }

func A_arbace_go_check_code__init_part0_A_clinit_p1() { A_arbace_go_check_code__init_part0_A_const_13 = A_arbace_go_check_code__init_part0_A_const_pool.A[42]; A_arbace_go_check_code__init_part0_A_const_14 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[43]); A_arbace_go_check_code__init_part0_A_const_15 = A_arbace_go_check_code__init_part0_A_const_pool.A[44]; A_arbace_go_check_code__init_part0_A_const_16 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[45]); A_arbace_go_check_code__init_part0_A_const_17 = A_arbace_go_check_code__init_part0_A_const_pool.A[46]; A_arbace_go_check_code__init_part0_A_const_18 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[47]); A_arbace_go_check_code__init_part0_A_const_19 = A_arbace_go_check_code__init_part0_A_const_pool.A[48]; A_arbace_go_check_code__init_part0_A_const_20 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[49]); A_arbace_go_check_code__init_part0_A_const_21 = A_arbace_go_check_code__init_part0_A_const_pool.A[50]; A_arbace_go_check_code__init_part0_A_const_22 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[51]); A_arbace_go_check_code__init_part0_A_const_23 = A_arbace_go_check_code__init_part0_A_const_pool.A[52]; A_arbace_go_check_code__init_part0_A_const_24 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[53]); A_arbace_go_check_code__init_part0_A_const_25 = A_arbace_go_check_code__init_part0_A_const_pool.A[54] }

func A_arbace_go_check_code__init_part0_A_clinit_p2() { A_arbace_go_check_code__init_part0_A_const_26 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[55]); A_arbace_go_check_code__init_part0_A_const_27 = A_arbace_go_check_code__init_part0_A_const_pool.A[56]; A_arbace_go_check_code__init_part0_A_const_28 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[57]); A_arbace_go_check_code__init_part0_A_const_29 = A_arbace_go_check_code__init_part0_A_const_pool.A[58]; A_arbace_go_check_code__init_part0_A_const_30 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[59]); A_arbace_go_check_code__init_part0_A_const_31 = A_arbace_go_check_code__init_part0_A_const_pool.A[60]; A_arbace_go_check_code__init_part0_A_const_32 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[61]); A_arbace_go_check_code__init_part0_A_const_33 = A_arbace_go_check_code__init_part0_A_const_pool.A[62]; A_arbace_go_check_code__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[63]); A_arbace_go_check_code__init_part0_A_const_35 = A_arbace_go_check_code__init_part0_A_const_pool.A[64]; A_arbace_go_check_code__init_part0_A_const_36 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[65]); A_arbace_go_check_code__init_part0_A_const_37 = A_arbace_go_check_code__init_part0_A_const_pool.A[66]; A_arbace_go_check_code__init_part0_A_const_38 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[67]) }

func A_arbace_go_check_code__init_part0_A_clinit_p3() { A_arbace_go_check_code__init_part0_A_const_39 = A_arbace_go_check_code__init_part0_A_const_pool.A[68]; A_arbace_go_check_code__init_part0_A_const_40 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[69]); A_arbace_go_check_code__init_part0_A_const_41 = A_arbace_go_check_code__init_part0_A_const_pool.A[70]; A_arbace_go_check_code__init_part0_A_const_42 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[71]); A_arbace_go_check_code__init_part0_A_const_43 = A_arbace_go_check_code__init_part0_A_const_pool.A[72]; A_arbace_go_check_code__init_part0_A_const_44 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[73]); A_arbace_go_check_code__init_part0_A_const_45 = A_arbace_go_check_code__init_part0_A_const_pool.A[74]; A_arbace_go_check_code__init_part0_A_const_46 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[75]); A_arbace_go_check_code__init_part0_A_const_47 = A_arbace_go_check_code__init_part0_A_const_pool.A[76]; A_arbace_go_check_code__init_part0_A_const_48 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[77]); A_arbace_go_check_code__init_part0_A_const_49 = A_arbace_go_check_code__init_part0_A_const_pool.A[78]; A_arbace_go_check_code__init_part0_A_const_50 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[79]); A_arbace_go_check_code__init_part0_A_const_51 = A_arbace_go_check_code__init_part0_A_const_pool.A[80] }

func A_arbace_go_check_code__init_part0_A_clinit_p4() { A_arbace_go_check_code__init_part0_A_const_52 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[81]); A_arbace_go_check_code__init_part0_A_const_53 = A_arbace_go_check_code__init_part0_A_const_pool.A[82]; A_arbace_go_check_code__init_part0_A_const_54 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[83]); A_arbace_go_check_code__init_part0_A_const_55 = A_arbace_go_check_code__init_part0_A_const_pool.A[84]; A_arbace_go_check_code__init_part0_A_const_56 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[85]); A_arbace_go_check_code__init_part0_A_const_57 = A_arbace_go_check_code__init_part0_A_const_pool.A[86]; A_arbace_go_check_code__init_part0_A_const_58 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[87]); A_arbace_go_check_code__init_part0_A_const_59 = A_arbace_go_check_code__init_part0_A_const_pool.A[88]; A_arbace_go_check_code__init_part0_A_const_60 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[89]); A_arbace_go_check_code__init_part0_A_const_61 = A_arbace_go_check_code__init_part0_A_const_pool.A[90]; A_arbace_go_check_code__init_part0_A_const_62 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[91]); A_arbace_go_check_code__init_part0_A_const_63 = A_arbace_go_check_code__init_part0_A_const_pool.A[92]; A_arbace_go_check_code__init_part0_A_const_64 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[93]) }

func A_arbace_go_check_code__init_part0_A_clinit_p5() { A_arbace_go_check_code__init_part0_A_const_65 = A_arbace_go_check_code__init_part0_A_const_pool.A[94]; A_arbace_go_check_code__init_part0_A_const_66 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[95]); A_arbace_go_check_code__init_part0_A_const_67 = A_arbace_go_check_code__init_part0_A_const_pool.A[96]; A_arbace_go_check_code__init_part0_A_const_68 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[97]); A_arbace_go_check_code__init_part0_A_const_69 = A_arbace_go_check_code__init_part0_A_const_pool.A[98]; A_arbace_go_check_code__init_part0_A_const_70 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[99]); A_arbace_go_check_code__init_part0_A_const_71 = A_arbace_go_check_code__init_part0_A_const_pool.A[100]; A_arbace_go_check_code__init_part0_A_const_72 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[101]); A_arbace_go_check_code__init_part0_A_const_73 = A_arbace_go_check_code__init_part0_A_const_pool.A[102]; A_arbace_go_check_code__init_part0_A_const_74 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[103]); A_arbace_go_check_code__init_part0_A_const_75 = A_arbace_go_check_code__init_part0_A_const_pool.A[104]; A_arbace_go_check_code__init_part0_A_const_76 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[105]); A_arbace_go_check_code__init_part0_A_const_77 = A_arbace_go_check_code__init_part0_A_const_pool.A[106] }

func A_arbace_go_check_code__init_part0_A_clinit_p6() { A_arbace_go_check_code__init_part0_A_const_78 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[107]); A_arbace_go_check_code__init_part0_A_const_79 = A_arbace_go_check_code__init_part0_A_const_pool.A[108]; A_arbace_go_check_code__init_part0_A_const_80 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[109]); A_arbace_go_check_code__init_part0_A_const_81 = A_arbace_go_check_code__init_part0_A_const_pool.A[110]; A_arbace_go_check_code__init_part0_A_const_82 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[111]); A_arbace_go_check_code__init_part0_A_const_83 = A_arbace_go_check_code__init_part0_A_const_pool.A[112]; A_arbace_go_check_code__init_part0_A_const_84 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[113]); A_arbace_go_check_code__init_part0_A_const_85 = A_arbace_go_check_code__init_part0_A_const_pool.A[114]; A_arbace_go_check_code__init_part0_A_const_86 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[115]); A_arbace_go_check_code__init_part0_A_const_87 = A_arbace_go_check_code__init_part0_A_const_pool.A[116]; A_arbace_go_check_code__init_part0_A_const_88 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[117]); A_arbace_go_check_code__init_part0_A_const_89 = A_arbace_go_check_code__init_part0_A_const_pool.A[118]; A_arbace_go_check_code__init_part0_A_const_90 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[119]) }

func A_arbace_go_check_code__init_part0_A_clinit_p7() { A_arbace_go_check_code__init_part0_A_const_91 = A_arbace_go_check_code__init_part0_A_const_pool.A[120]; A_arbace_go_check_code__init_part0_A_const_92 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[121]); A_arbace_go_check_code__init_part0_A_const_93 = A_arbace_go_check_code__init_part0_A_const_pool.A[122]; A_arbace_go_check_code__init_part0_A_const_94 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[123]); A_arbace_go_check_code__init_part0_A_const_95 = A_arbace_go_check_code__init_part0_A_const_pool.A[124]; A_arbace_go_check_code__init_part0_A_const_96 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[125]); A_arbace_go_check_code__init_part0_A_const_97 = A_arbace_go_check_code__init_part0_A_const_pool.A[126]; A_arbace_go_check_code__init_part0_A_const_98 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[127]); A_arbace_go_check_code__init_part0_A_const_99 = A_arbace_go_check_code__init_part0_A_const_pool.A[128]; A_arbace_go_check_code__init_part0_A_const_100 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[129]); A_arbace_go_check_code__init_part0_A_const_101 = A_arbace_go_check_code__init_part0_A_const_pool.A[130]; A_arbace_go_check_code__init_part0_A_const_102 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[131]); A_arbace_go_check_code__init_part0_A_const_103 = A_arbace_go_check_code__init_part0_A_const_pool.A[132] }

func A_arbace_go_check_code__init_part0_A_clinit_p8() { A_arbace_go_check_code__init_part0_A_const_104 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[133]); A_arbace_go_check_code__init_part0_A_const_105 = A_arbace_go_check_code__init_part0_A_const_pool.A[134]; A_arbace_go_check_code__init_part0_A_const_106 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[135]); A_arbace_go_check_code__init_part0_A_const_107 = A_arbace_go_check_code__init_part0_A_const_pool.A[136]; A_arbace_go_check_code__init_part0_A_const_108 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[137]); A_arbace_go_check_code__init_part0_A_const_109 = A_arbace_go_check_code__init_part0_A_const_pool.A[138]; A_arbace_go_check_code__init_part0_A_const_110 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[139]); A_arbace_go_check_code__init_part0_A_const_111 = A_arbace_go_check_code__init_part0_A_const_pool.A[140]; A_arbace_go_check_code__init_part0_A_const_112 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[141]); A_arbace_go_check_code__init_part0_A_const_113 = A_arbace_go_check_code__init_part0_A_const_pool.A[142]; A_arbace_go_check_code__init_part0_A_const_114 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[143]); A_arbace_go_check_code__init_part0_A_const_115 = A_arbace_go_check_code__init_part0_A_const_pool.A[144]; A_arbace_go_check_code__init_part0_A_const_116 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[145]) }

func A_arbace_go_check_code__init_part0_A_clinit_p9() { A_arbace_go_check_code__init_part0_A_const_117 = A_arbace_go_check_code__init_part0_A_const_pool.A[146]; A_arbace_go_check_code__init_part0_A_const_118 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[147]); A_arbace_go_check_code__init_part0_A_const_119 = A_arbace_go_check_code__init_part0_A_const_pool.A[148]; A_arbace_go_check_code__init_part0_A_const_120 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[149]); A_arbace_go_check_code__init_part0_A_const_121 = A_arbace_go_check_code__init_part0_A_const_pool.A[150]; A_arbace_go_check_code__init_part0_A_const_122 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[151]); A_arbace_go_check_code__init_part0_A_const_123 = A_arbace_go_check_code__init_part0_A_const_pool.A[152]; A_arbace_go_check_code__init_part0_A_const_124 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[153]); A_arbace_go_check_code__init_part0_A_const_125 = A_arbace_go_check_code__init_part0_A_const_pool.A[154]; A_arbace_go_check_code__init_part0_A_const_126 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[155]); A_arbace_go_check_code__init_part0_A_const_127 = A_arbace_go_check_code__init_part0_A_const_pool.A[156]; A_arbace_go_check_code__init_part0_A_const_128 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[157]); A_arbace_go_check_code__init_part0_A_const_129 = A_arbace_go_check_code__init_part0_A_const_pool.A[158] }

func A_arbace_go_check_code__init_part0_A_clinit_p10() { A_arbace_go_check_code__init_part0_A_const_130 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[159]); A_arbace_go_check_code__init_part0_A_const_131 = A_arbace_go_check_code__init_part0_A_const_pool.A[160]; A_arbace_go_check_code__init_part0_A_const_132 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[161]); A_arbace_go_check_code__init_part0_A_const_133 = A_arbace_go_check_code__init_part0_A_const_pool.A[162]; A_arbace_go_check_code__init_part0_A_const_134 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[163]); A_arbace_go_check_code__init_part0_A_const_135 = A_arbace_go_check_code__init_part0_A_const_pool.A[164]; A_arbace_go_check_code__init_part0_A_const_136 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[165]); A_arbace_go_check_code__init_part0_A_const_137 = A_arbace_go_check_code__init_part0_A_const_pool.A[166]; A_arbace_go_check_code__init_part0_A_const_138 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[167]); A_arbace_go_check_code__init_part0_A_const_139 = A_arbace_go_check_code__init_part0_A_const_pool.A[168]; A_arbace_go_check_code__init_part0_A_const_140 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[169]); A_arbace_go_check_code__init_part0_A_const_141 = A_arbace_go_check_code__init_part0_A_const_pool.A[170]; A_arbace_go_check_code__init_part0_A_const_142 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[171]) }

func A_arbace_go_check_code__init_part0_A_clinit_p11() { A_arbace_go_check_code__init_part0_A_const_143 = A_arbace_go_check_code__init_part0_A_const_pool.A[172]; A_arbace_go_check_code__init_part0_A_const_144 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[173]); A_arbace_go_check_code__init_part0_A_const_145 = A_arbace_go_check_code__init_part0_A_const_pool.A[174]; A_arbace_go_check_code__init_part0_A_const_146 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[175]); A_arbace_go_check_code__init_part0_A_const_147 = A_arbace_go_check_code__init_part0_A_const_pool.A[176]; A_arbace_go_check_code__init_part0_A_const_148 = A_arbace_go_check_code__init_part0_A_const_pool.A[177]; A_arbace_go_check_code__init_part0_A_const_149 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[178]); A_arbace_go_check_code__init_part0_A_const_150 = A_arbace_go_check_code__init_part0_A_const_pool.A[179]; A_arbace_go_check_code__init_part0_A_const_151 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[180]); A_arbace_go_check_code__init_part0_A_const_152 = A_arbace_go_check_code__init_part0_A_const_pool.A[181]; A_arbace_go_check_code__init_part0_A_const_153 = A_arbace_go_check_code__init_part0_A_const_pool.A[182]; A_arbace_go_check_code__init_part0_A_const_154 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[183]); A_arbace_go_check_code__init_part0_A_const_155 = A_arbace_go_check_code__init_part0_A_const_pool.A[184]; A_arbace_go_check_code__init_part0_A_const_156 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[185]) }

func A_arbace_go_check_code__init_part0_A_clinit_p12() { A_arbace_go_check_code__init_part0_A_const_157 = A_arbace_go_check_code__init_part0_A_const_pool.A[186]; A_arbace_go_check_code__init_part0_A_const_158 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[187]); A_arbace_go_check_code__init_part0_A_const_159 = A_arbace_go_check_code__init_part0_A_const_pool.A[188]; A_arbace_go_check_code__init_part0_A_const_160 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[189]); A_arbace_go_check_code__init_part0_A_const_161 = A_arbace_go_check_code__init_part0_A_const_pool.A[190]; A_arbace_go_check_code__init_part0_A_const_162 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[191]); A_arbace_go_check_code__init_part0_A_const_163 = A_arbace_go_check_code__init_part0_A_const_pool.A[192]; A_arbace_go_check_code__init_part0_A_const_164 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[193]); A_arbace_go_check_code__init_part0_A_const_165 = A_arbace_go_check_code__init_part0_A_const_pool.A[194]; A_arbace_go_check_code__init_part0_A_const_166 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[195]); A_arbace_go_check_code__init_part0_A_const_167 = A_arbace_go_check_code__init_part0_A_const_pool.A[196]; A_arbace_go_check_code__init_part0_A_const_168 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[197]); A_arbace_go_check_code__init_part0_A_const_169 = A_arbace_go_check_code__init_part0_A_const_pool.A[198] }

func A_arbace_go_check_code__init_part0_A_clinit_p13() { A_arbace_go_check_code__init_part0_A_const_170 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[199]); A_arbace_go_check_code__init_part0_A_const_171 = A_arbace_go_check_code__init_part0_A_const_pool.A[200]; A_arbace_go_check_code__init_part0_A_const_172 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[201]); A_arbace_go_check_code__init_part0_A_const_173 = A_arbace_go_check_code__init_part0_A_const_pool.A[202]; A_arbace_go_check_code__init_part0_A_const_174 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[203]); A_arbace_go_check_code__init_part0_A_const_175 = A_arbace_go_check_code__init_part0_A_const_pool.A[204]; A_arbace_go_check_code__init_part0_A_const_176 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[205]); A_arbace_go_check_code__init_part0_A_const_177 = A_arbace_go_check_code__init_part0_A_const_pool.A[206]; A_arbace_go_check_code__init_part0_A_const_178 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[207]); A_arbace_go_check_code__init_part0_A_const_179 = A_arbace_go_check_code__init_part0_A_const_pool.A[208]; A_arbace_go_check_code__init_part0_A_const_180 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[209]); A_arbace_go_check_code__init_part0_A_const_181 = A_arbace_go_check_code__init_part0_A_const_pool.A[210]; A_arbace_go_check_code__init_part0_A_const_182 = A_arbace_go_check_code__init_part0_A_const_pool.A[211] }

func A_arbace_go_check_code__init_part0_A_clinit_p14() { A_arbace_go_check_code__init_part0_A_const_183 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[212]); A_arbace_go_check_code__init_part0_A_const_184 = A_arbace_go_check_code__init_part0_A_const_pool.A[213]; A_arbace_go_check_code__init_part0_A_const_185 = lang.Var_Cast(A_arbace_go_check_code__init_part0_A_const_pool.A[214]); A_arbace_go_check_code__init_part0_A_const_186 = A_arbace_go_check_code__init_part0_A_const_pool.A[215] }

func A_arbace_go_check_code__init_part0_A_New() *A_arbace_go_check_code__init_part0_A { A_arbace_go_check_code__init_part0_A_Init(); t := &A_arbace_go_check_code__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code__init_part0_A) Ctor() {}

func (t *A_arbace_go_check_code__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code__init_part0_A_class }

func (t *A_arbace_go_check_code__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code__init_part0_A); return ok }

func A_arbace_go_check_code__init_part0_A_Cast(x any) *A_arbace_go_check_code__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code__init_part0_A_class)) }; return v }



type A_arbace_go_check_code__init_part1_A struct{ jrt.Object }

var A_arbace_go_check_code__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_check_code__init_part1_A_const_0 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_1 any

var A_arbace_go_check_code__init_part1_A_const_2 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_3 any

var A_arbace_go_check_code__init_part1_A_const_4 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_5 any

var A_arbace_go_check_code__init_part1_A_const_6 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_7 any

var A_arbace_go_check_code__init_part1_A_const_8 any

var A_arbace_go_check_code__init_part1_A_const_9 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_10 any

var A_arbace_go_check_code__init_part1_A_const_11 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_12 any

var A_arbace_go_check_code__init_part1_A_const_13 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_14 any

var A_arbace_go_check_code__init_part1_A_const_15 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_16 any

var A_arbace_go_check_code__init_part1_A_const_17 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_18 any

var A_arbace_go_check_code__init_part1_A_const_19 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_20 any

var A_arbace_go_check_code__init_part1_A_const_21 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_22 any

var A_arbace_go_check_code__init_part1_A_const_23 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_24 any

var A_arbace_go_check_code__init_part1_A_const_25 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_26 any

var A_arbace_go_check_code__init_part1_A_const_27 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_28 any

var A_arbace_go_check_code__init_part1_A_const_29 *lang.Var

var A_arbace_go_check_code__init_part1_A_const_30 any

var A_arbace_go_check_code__init_part1_A_const_31 *lang.Var

var A_arbace_go_check_code__init_part1_A_init jrt.ClassInit

func A_arbace_go_check_code__init_part1_A_Init() { if !A_arbace_go_check_code__init_part1_A_init.Done() { A_arbace_go_check_code__init_part1_A_init.Run(A_arbace_go_check_code__init_part1_A_clinit) } }

func A_arbace_go_check_code__init_part1_A_clinit() { A_arbace_go_check_code__init_part1_A_clinit_p0(); A_arbace_go_check_code__init_part1_A_clinit_p1() }

func A_arbace_go_check_code__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_code__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_846, 52); A_arbace_go_check_code__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[25]); A_arbace_go_check_code__init_part1_A_const_1 = A_arbace_go_check_code__init_part1_A_const_pool.A[26]; A_arbace_go_check_code__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[27]); A_arbace_go_check_code__init_part1_A_const_3 = A_arbace_go_check_code__init_part1_A_const_pool.A[28]; A_arbace_go_check_code__init_part1_A_const_4 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[29]); A_arbace_go_check_code__init_part1_A_const_5 = A_arbace_go_check_code__init_part1_A_const_pool.A[30]; A_arbace_go_check_code__init_part1_A_const_6 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[31]); A_arbace_go_check_code__init_part1_A_const_7 = A_arbace_go_check_code__init_part1_A_const_pool.A[32]; A_arbace_go_check_code__init_part1_A_const_8 = A_arbace_go_check_code__init_part1_A_const_pool.A[33]; A_arbace_go_check_code__init_part1_A_const_9 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[34]); A_arbace_go_check_code__init_part1_A_const_10 = A_arbace_go_check_code__init_part1_A_const_pool.A[35]; A_arbace_go_check_code__init_part1_A_const_11 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[36]); A_arbace_go_check_code__init_part1_A_const_12 = A_arbace_go_check_code__init_part1_A_const_pool.A[37] }

func A_arbace_go_check_code__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_go_check_code__init_part0_A_Init(); tmp1 = A_arbace_go_check_code__init_part0_A_const_38; A_arbace_go_check_code__init_part1_A_const_13 = tmp1; A_arbace_go_check_code__init_part1_A_const_14 = A_arbace_go_check_code__init_part1_A_const_pool.A[38]; A_arbace_go_check_code__init_part1_A_const_15 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[39]); A_arbace_go_check_code__init_part1_A_const_16 = A_arbace_go_check_code__init_part1_A_const_pool.A[40]; var tmp2 *lang.Var; A_arbace_go_check_code__init_part0_A_Init(); tmp2 = A_arbace_go_check_code__init_part0_A_const_40; A_arbace_go_check_code__init_part1_A_const_17 = tmp2; A_arbace_go_check_code__init_part1_A_const_18 = A_arbace_go_check_code__init_part1_A_const_pool.A[41]; var tmp3 *lang.Var; A_arbace_go_check_code__init_part0_A_Init(); tmp3 = A_arbace_go_check_code__init_part0_A_const_26; A_arbace_go_check_code__init_part1_A_const_19 = tmp3; A_arbace_go_check_code__init_part1_A_const_20 = A_arbace_go_check_code__init_part1_A_const_pool.A[42]; A_arbace_go_check_code__init_part1_A_const_21 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[43]); A_arbace_go_check_code__init_part1_A_const_22 = A_arbace_go_check_code__init_part1_A_const_pool.A[44]; A_arbace_go_check_code__init_part1_A_const_23 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[45]); A_arbace_go_check_code__init_part1_A_const_24 = A_arbace_go_check_code__init_part1_A_const_pool.A[46]; A_arbace_go_check_code__init_part1_A_const_25 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[47]); A_arbace_go_check_code__init_part1_A_const_26 = A_arbace_go_check_code__init_part1_A_const_pool.A[48]; var tmp4 *lang.Var; A_arbace_go_check_code__init_part0_A_Init(); tmp4 = A_arbace_go_check_code__init_part0_A_const_183; A_arbace_go_check_code__init_part1_A_const_27 = tmp4; A_arbace_go_check_code__init_part1_A_const_28 = A_arbace_go_check_code__init_part1_A_const_pool.A[49]; var tmp5 *lang.Var; A_arbace_go_check_code__init_part0_A_Init(); tmp5 = A_arbace_go_check_code__init_part0_A_const_74; A_arbace_go_check_code__init_part1_A_const_29 = tmp5; A_arbace_go_check_code__init_part1_A_const_30 = A_arbace_go_check_code__init_part1_A_const_pool.A[50]; A_arbace_go_check_code__init_part1_A_const_31 = lang.Var_Cast(A_arbace_go_check_code__init_part1_A_const_pool.A[51]) }

func A_arbace_go_check_code__init_part1_A_New() *A_arbace_go_check_code__init_part1_A { A_arbace_go_check_code__init_part1_A_Init(); t := &A_arbace_go_check_code__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code__init_part1_A) Ctor() {}

func (t *A_arbace_go_check_code__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code__init_part1_A_class }

func (t *A_arbace_go_check_code__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code__init_part1_A); return ok }

func A_arbace_go_check_code__init_part1_A_Cast(x any) *A_arbace_go_check_code__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code__init_part1_A_class)) }; return v }
