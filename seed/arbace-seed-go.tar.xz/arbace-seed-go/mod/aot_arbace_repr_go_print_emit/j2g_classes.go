//line j2g_classes.ae:1
package aot_arbace_repr_go_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_at_BANG__A_class, Name: "arbace.repr.go.print_emit$at_BANG_", Modifiers: 25, Simple: "at_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_at_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_bol_QMARK__A_class, Name: "arbace.repr.go.print_emit$bol_QMARK_", Modifiers: 25, Simple: "bol_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_bol_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_break_to_BANG__A_class, Name: "arbace.repr.go.print_emit$break_to_BANG_", Modifiers: 25, Simple: "break_to_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_break_to_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_chunk_state_A_class, Name: "arbace.repr.go.print_emit$chunk_state", Modifiers: 25, Simple: "chunk_state", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_chunk_state_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_close_break_BANG__A_class, Name: "arbace.repr.go.print_emit$close_break_BANG_", Modifiers: 25, Simple: "close_break_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_close_break_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_comment_line_A_class, Name: "arbace.repr.go.print_emit$comment_line", Modifiers: 25, Simple: "comment_line", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_cont_indent_A_class, Name: "arbace.repr.go.print_emit$cont_indent", Modifiers: 25, Simple: "cont_indent", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_cont_indent_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_cur_indent_A_class, Name: "arbace.repr.go.print_emit$cur_indent", Modifiers: 25, Simple: "cur_indent", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_cur_indent_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_end_of_A_class, Name: "arbace.repr.go.print_emit$end_of", Modifiers: 25, Simple: "end_of", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_end_of_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_end_of_fn__308000120_A_class, Name: "arbace.repr.go.print_emit$end_of$fn__308000120", Modifiers: 25, Simple: "fn__308000120", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_end_of_fn__308000120_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_end_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_class, Name: "arbace.repr.go.print_emit$eval308000004$loading__1927001464__auto____308000005", Modifiers: 25, Simple: "loading__1927001464__auto____308000005", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_class, Name: "arbace.repr.go.print_emit$eval308000008$fn__308000009", Modifiers: 25, Simple: "fn__308000009", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_class, Name: "arbace.repr.go.print_emit$eval308000018$lines_QMARK___308000019", Modifiers: 25, Simple: "lines_QMARK___308000019", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000018_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_class, Name: "arbace.repr.go.print_emit$eval308000029$full_QMARK___308000030", Modifiers: 25, Simple: "full_QMARK___308000030", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_class, Name: "arbace.repr.go.print_emit$eval308000040$line__308000041", Modifiers: 25, Simple: "line__308000041", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000040_line__308000041_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000040_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_class, Name: "arbace.repr.go.print_emit$eval308000051$bol_QMARK___308000052", Modifiers: 25, Simple: "bol_QMARK___308000052", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000051_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_class, Name: "arbace.repr.go.print_emit$eval308000063$target__308000064", Modifiers: 25, Simple: "target__308000064", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000063_target__308000064_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_class, Name: "arbace.repr.go.print_emit$eval308000089$cur_indent__308000090", Modifiers: 25, Simple: "cur_indent__308000090", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_eval308000089_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_QMARK__A_class, Name: "arbace.repr.go.print_emit$full_QMARK_", Modifiers: 25, Simple: "full_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_A_class, Name: "arbace.repr.go.print_emit$full_result", Modifiers: 25, Simple: "full_result", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000149_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000149", Modifiers: 25, Simple: "fn__308000149", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000149_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000152_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000152", Modifiers: 25, Simple: "fn__308000152", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000152_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000158_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000158", Modifiers: 25, Simple: "fn__308000158", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000158_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000164_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000164", Modifiers: 25, Simple: "fn__308000164", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000164_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000169_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000169", Modifiers: 25, Simple: "fn__308000169", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000169_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000169$fn__308000177", Modifiers: 25, Simple: "fn__308000177", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_fn__308000169_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000184_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000184", Modifiers: 25, Simple: "fn__308000184", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000184_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000227_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000227", Modifiers: 25, Simple: "fn__308000227", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000227_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000229_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000229", Modifiers: 25, Simple: "fn__308000229", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000229_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000231_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000231", Modifiers: 25, Simple: "fn__308000231", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000231_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000234_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000234", Modifiers: 25, Simple: "fn__308000234", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000234_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000236_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000236", Modifiers: 25, Simple: "fn__308000236", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000236_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_fn__308000238_A_class, Name: "arbace.repr.go.print_emit$full_result$fn__308000238", Modifiers: 25, Simple: "fn__308000238", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_fn__308000238_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_class, Name: "arbace.repr.go.print_emit$full_result$write_at_BANG___308000190", Modifiers: 25, Simple: "write_at_BANG___308000190", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_full_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_full_tok_A_class, Name: "arbace.repr.go.print_emit$full_tok", Modifiers: 25, Simple: "full_tok", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_full_tok_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_join_BANG__A_class, Name: "arbace.repr.go.print_emit$join_BANG_", Modifiers: 25, Simple: "join_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_line_A_class, Name: "arbace.repr.go.print_emit$line", Modifiers: 25, Simple: "line", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_line_comment_QMARK__A_class, Name: "arbace.repr.go.print_emit$line_comment_QMARK_", Modifiers: 25, Simple: "line_comment_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_comment_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_line_directive_inline_A_class, Name: "arbace.repr.go.print_emit$line_directive_inline", Modifiers: 25, Simple: "line_directive_inline", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_inline_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_line_directive_own_A_class, Name: "arbace.repr.go.print_emit$line_directive_own", Modifiers: 25, Simple: "line_directive_own", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_own_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_lines_QMARK__A_class, Name: "arbace.repr.go.print_emit$lines_QMARK_", Modifiers: 25, Simple: "lines_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_lines_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_may_combine_QMARK__A_class, Name: "arbace.repr.go.print_emit$may_combine_QMARK_", Modifiers: 25, Simple: "may_combine_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_may_combine_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_new_state_A_class, Name: "arbace.repr.go.print_emit$new_state", Modifiers: 25, Simple: "new_state", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_nl_A_class, Name: "arbace.repr.go.print_emit$nl", Modifiers: 25, Simple: "nl", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_A_class, Name: "arbace.repr.go.print_emit$place_run", Modifiers: 25, Simple: "place_run", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_fn__308000130_A_class, Name: "arbace.repr.go.print_emit$place_run$fn__308000130", Modifiers: 25, Simple: "fn__308000130", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_fn__308000130_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_fn__308000137_A_class, Name: "arbace.repr.go.print_emit$place_run$fn__308000137", Modifiers: 25, Simple: "fn__308000137", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_fn__308000137_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_fn__308000139_A_class, Name: "arbace.repr.go.print_emit$place_run$fn__308000139", Modifiers: 25, Simple: "fn__308000139", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_fn__308000139_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_fn__308000141_A_class, Name: "arbace.repr.go.print_emit$place_run$fn__308000141", Modifiers: 25, Simple: "fn__308000141", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_fn__308000141_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_fn__308000143_A_class, Name: "arbace.repr.go.print_emit$place_run$fn__308000143", Modifiers: 25, Simple: "fn__308000143", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_fn__308000143_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_place_run_natural__308000132_A_class, Name: "arbace.repr.go.print_emit$place_run$natural__308000132", Modifiers: 25, Simple: "natural__308000132", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_place_run_natural__308000132_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_place_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_pop_open_BANG__A_class, Name: "arbace.repr.go.print_emit$pop_open_BANG_", Modifiers: 25, Simple: "pop_open_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_pop_open_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_push_open_BANG__A_class, Name: "arbace.repr.go.print_emit$push_open_BANG_", Modifiers: 25, Simple: "push_open_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_push_open_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_raw_tok_A_class, Name: "arbace.repr.go.print_emit$raw_tok", Modifiers: 25, Simple: "raw_tok", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_raw_tok_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_class, Name: "arbace.repr.go.print_emit$raw_tok$fn__308000078", Modifiers: 25, Simple: "fn__308000078", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_raw_tok_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_render_A_class, Name: "arbace.repr.go.print_emit$render", Modifiers: 25, Simple: "render", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_render_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_result_A_class, Name: "arbace.repr.go.print_emit$result", Modifiers: 25, Simple: "result", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_room_QMARK__A_class, Name: "arbace.repr.go.print_emit$room_QMARK_", Modifiers: 25, Simple: "room_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_room_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_semi_after_QMARK__A_class, Name: "arbace.repr.go.print_emit$semi_after_QMARK_", Modifiers: 25, Simple: "semi_after_QMARK_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_semi_after_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_set_line_BANG__A_class, Name: "arbace.repr.go.print_emit$set_line_BANG_", Modifiers: 25, Simple: "set_line_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_set_line_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_soft_A_class, Name: "arbace.repr.go.print_emit$soft", Modifiers: 25, Simple: "soft", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_sp_A_class, Name: "arbace.repr.go.print_emit$sp", Modifiers: 25, Simple: "sp", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_start_at_BANG__A_class, Name: "arbace.repr.go.print_emit$start_at_BANG_", Modifiers: 25, Simple: "start_at_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_at_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_start_line_BANG__A_class, Name: "arbace.repr.go.print_emit$start_line_BANG_", Modifiers: 25, Simple: "start_line_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_line_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_stmt_break_BANG__A_class, Name: "arbace.repr.go.print_emit$stmt_break_BANG_", Modifiers: 25, Simple: "stmt_break_BANG_", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_stmt_break_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_class, Name: "arbace.repr.go.print_emit$stmt_break_BANG_$newline_BANG___308000107", Modifiers: 25, Simple: "newline_BANG___308000107", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_stmt_break_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_class, Name: "arbace.repr.go.print_emit$stmt_break_BANG_$same_BANG___308000109", Modifiers: 25, Simple: "same_BANG___308000109", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_stmt_break_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_target_A_class, Name: "arbace.repr.go.print_emit$target", Modifiers: 25, Simple: "target", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_target_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_tok_A_class, Name: "arbace.repr.go.print_emit$tok", Modifiers: 25, Simple: "tok", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_utf8_len_A_class, Name: "arbace.repr.go.print_emit$utf8_len", Modifiers: 25, Simple: "utf8_len", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_utf8_len_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_emit_vtab_A_class, Name: "arbace.repr.go.print_emit$vtab", Modifiers: 25, Simple: "vtab", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_vtab_A", Source: "print_emit.ae", Declaring: &A_arbace_repr_go_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_go_print_emit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_A_New()}; return nil }

var A_arbace_repr_go_print_emit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_A_new}

var A_arbace_repr_go_print_emit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_A"})

func init() { i := A_arbace_repr_go_print_emit_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_A_InstanceOf; i.Init = A_arbace_repr_go_print_emit_A_Init; i.Table = A_arbace_repr_go_print_emit_A_members }

var A_arbace_repr_go_print_emit_at_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_bol_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_break_to_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_chunk_state_A_class *jrt.Class

var A_arbace_repr_go_print_emit_close_break_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_comment_line_A_class *jrt.Class

var A_arbace_repr_go_print_emit_cont_indent_A_class *jrt.Class

var A_arbace_repr_go_print_emit_cur_indent_A_class *jrt.Class

var A_arbace_repr_go_print_emit_end_of_A_class *jrt.Class

var A_arbace_repr_go_print_emit_end_of_fn__308000120_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000004_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000004_A_new}

var A_arbace_repr_go_print_emit_eval308000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000004", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000004_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000004_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000004_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000004_A_members }

var A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000008_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000008_A_new}

var A_arbace_repr_go_print_emit_eval308000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000008", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000008_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000008_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000008_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000008_A_members }

var A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000018_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000018_A_new}

var A_arbace_repr_go_print_emit_eval308000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000018", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000018_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000018_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000018_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000018_A_members }

var A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000029_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000029_A_new}

var A_arbace_repr_go_print_emit_eval308000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000029", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000029_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000029_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000029_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000029_A_members }

var A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000040_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000040_A_new}

var A_arbace_repr_go_print_emit_eval308000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000040", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000040_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000040_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000040_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000040_A_members }

var A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000051_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000051_A_new}

var A_arbace_repr_go_print_emit_eval308000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000051", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000051_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000051_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000051_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000051_A_members }

var A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000063_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000063_A_new}

var A_arbace_repr_go_print_emit_eval308000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000063", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000063_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000063_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000063_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000063_A_members }

var A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_class *jrt.Class

func A_arbace_repr_go_print_emit_eval308000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit_eval308000089_A_New()}; return nil }

var A_arbace_repr_go_print_emit_eval308000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_emit_eval308000089_A_new}

var A_arbace_repr_go_print_emit_eval308000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit$eval308000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_emit_A_class, Simple: "eval308000089", Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_eval308000089_A"})

func init() { i := A_arbace_repr_go_print_emit_eval308000089_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit_eval308000089_A_InstanceOf; i.Table = A_arbace_repr_go_print_emit_eval308000089_A_members }

var A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000149_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000152_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000158_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000164_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000169_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000184_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000227_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000229_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000231_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000234_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000236_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_fn__308000238_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_class *jrt.Class

var A_arbace_repr_go_print_emit_full_tok_A_class *jrt.Class

var A_arbace_repr_go_print_emit_join_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_line_A_class *jrt.Class

var A_arbace_repr_go_print_emit_line_comment_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_line_directive_inline_A_class *jrt.Class

var A_arbace_repr_go_print_emit_line_directive_own_A_class *jrt.Class

var A_arbace_repr_go_print_emit_lines_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_may_combine_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_new_state_A_class *jrt.Class

var A_arbace_repr_go_print_emit_nl_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_fn__308000130_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_fn__308000137_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_fn__308000139_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_fn__308000141_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_fn__308000143_A_class *jrt.Class

var A_arbace_repr_go_print_emit_place_run_natural__308000132_A_class *jrt.Class

var A_arbace_repr_go_print_emit_pop_open_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_push_open_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_raw_tok_A_class *jrt.Class

var A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_class *jrt.Class

var A_arbace_repr_go_print_emit_render_A_class *jrt.Class

var A_arbace_repr_go_print_emit_result_A_class *jrt.Class

var A_arbace_repr_go_print_emit_room_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_semi_after_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_emit_set_line_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_soft_A_class *jrt.Class

var A_arbace_repr_go_print_emit_sp_A_class *jrt.Class

var A_arbace_repr_go_print_emit_start_at_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_start_line_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_stmt_break_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_class *jrt.Class

var A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_class *jrt.Class

var A_arbace_repr_go_print_emit_target_A_class *jrt.Class

var A_arbace_repr_go_print_emit_tok_A_class *jrt.Class

var A_arbace_repr_go_print_emit_utf8_len_A_class *jrt.Class

var A_arbace_repr_go_print_emit_vtab_A_class *jrt.Class

func A_arbace_repr_go_print_emit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit__init_A_Load__O()}; return nil }

func A_arbace_repr_go_print_emit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_emit__init_A_New()}; return nil }

var A_arbace_repr_go_print_emit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_go_print_emit__init_A_invoke, New: A_arbace_repr_go_print_emit__init_A_new}

var A_arbace_repr_go_print_emit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print_emit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit__init_A", Source: "print_emit.ae"})

func init() { i := A_arbace_repr_go_print_emit__init_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_emit__init_A_InstanceOf; i.Init = A_arbace_repr_go_print_emit__init_A_Init; i.Table = A_arbace_repr_go_print_emit__init_A_members }
