//line aot_arbace_repr_go_print_emit__init.ae:1
package aot_arbace_repr_go_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_emit__init_A_Unit0__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_print_emit__init_A_Unit1__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_print_emit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_print_emit__init_A_Unit2__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_print_emit__init_A_Unit3__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_print_emit__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_print_emit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_print_emit__init_A_Load__O() any { A_arbace_repr_go_print_emit__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_print_emit__init_A_Unit0__O(); A_arbace_repr_go_print_emit__init_A_Unit1__O(); A_arbace_repr_go_print_emit__init_A_Unit2__O(); A_arbace_repr_go_print_emit__init_A_Unit3__O(); A_arbace_repr_go_print_emit__init_A_Unit4__O(); A_arbace_repr_go_print_emit__init_A_Unit5__O(); A_arbace_repr_go_print_emit__init_A_Unit6__O(); A_arbace_repr_go_print_emit__init_A_Unit7__O(); A_arbace_repr_go_print_emit__init_A_Unit8__O(); A_arbace_repr_go_print_emit__init_A_Unit9__O(); A_arbace_repr_go_print_emit__init_A_Unit10__O(); A_arbace_repr_go_print_emit__init_A_Unit11__O(); A_arbace_repr_go_print_emit__init_A_Unit12__O(); A_arbace_repr_go_print_emit__init_A_Unit13__O(); A_arbace_repr_go_print_emit__init_A_Unit14__O(); A_arbace_repr_go_print_emit__init_A_Unit15__O(); A_arbace_repr_go_print_emit__init_A_Unit16__O(); A_arbace_repr_go_print_emit__init_A_Unit17__O(); A_arbace_repr_go_print_emit__init_A_Unit18__O(); A_arbace_repr_go_print_emit__init_A_Unit19__O(); A_arbace_repr_go_print_emit__init_A_Unit20__O(); A_arbace_repr_go_print_emit__init_A_Unit21__O(); A_arbace_repr_go_print_emit__init_A_Unit22__O(); A_arbace_repr_go_print_emit__init_A_Unit23__O(); A_arbace_repr_go_print_emit__init_A_Unit24__O(); A_arbace_repr_go_print_emit__init_A_Unit25__O(); A_arbace_repr_go_print_emit__init_A_Unit26__O(); A_arbace_repr_go_print_emit__init_A_Unit27__O(); A_arbace_repr_go_print_emit__init_A_Unit28__O(); A_arbace_repr_go_print_emit__init_A_Unit29__O(); A_arbace_repr_go_print_emit__init_A_Unit30__O(); A_arbace_repr_go_print_emit__init_A_Unit31__O(); A_arbace_repr_go_print_emit__init_A_Unit32__O(); A_arbace_repr_go_print_emit__init_A_Unit33__O(); A_arbace_repr_go_print_emit__init_A_Unit34__O(); A_arbace_repr_go_print_emit__init_A_Unit35__O(); A_arbace_repr_go_print_emit__init_A_Unit36__O(); A_arbace_repr_go_print_emit__init_A_Unit37__O(); A_arbace_repr_go_print_emit__init_A_Unit38__O(); A_arbace_repr_go_print_emit__init_A_Unit39__O(); A_arbace_repr_go_print_emit__init_A_Unit40__O(); A_arbace_repr_go_print_emit__init_A_Unit41__O(); A_arbace_repr_go_print_emit__init_A_Unit42__O(); A_arbace_repr_go_print_emit__init_A_Unit43__O(); A_arbace_repr_go_print_emit__init_A_Unit44__O(); A_arbace_repr_go_print_emit__init_A_Unit45__O(); A_arbace_repr_go_print_emit__init_A_Unit46__O(); A_arbace_repr_go_print_emit__init_A_Unit47__O(); A_arbace_repr_go_print_emit__init_A_Unit48__O(); A_arbace_repr_go_print_emit__init_A_Unit49__O(); A_arbace_repr_go_print_emit__init_A_Unit50__O(); A_arbace_repr_go_print_emit__init_A_Unit51__O(); A_arbace_repr_go_print_emit__init_A_Unit52__O(); A_arbace_repr_go_print_emit__init_A_Unit53__O(); A_arbace_repr_go_print_emit__init_A_Unit54__O(); A_arbace_repr_go_print_emit__init_A_Unit55__O(); A_arbace_repr_go_print_emit__init_A_Unit56__O(); A_arbace_repr_go_print_emit__init_A_Unit57__O(); A_arbace_repr_go_print_emit__init_A_Unit58__O(); A_arbace_repr_go_print_emit__init_A_Unit59__O(); return nil }






func A_arbace_repr_go_print_emit__init_A_Unit4__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(12, 1); A_arbace_repr_go_print_emit__init_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_5)); return A_arbace_repr_go_print_emit__init_A_const_4.SetDynamic_Z__Var(true).Ref() }

func A_arbace_repr_go_print_emit__init_A_Unit5__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); A_arbace_repr_go_print_emit__init_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_7)); return A_arbace_repr_go_print_emit__init_A_const_6.SetDynamic_Z__Var(true).Ref() }




func A_arbace_repr_go_print_emit__init_A_Unit6__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_8; var tmp2 any = A_arbace_repr_go_print_emit_new_state_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_print_emit_new_state_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_print_emit_new_state_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_9)); return A_arbace_repr_go_print_emit__init_A_const_8 }






















func A_arbace_repr_go_print_emit__init_A_Unit7__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_10; var tmp2 any = A_arbace_repr_go_print_emit_lines_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_print_emit_lines_QMARK__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_print_emit_lines_QMARK__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_11)); return A_arbace_repr_go_print_emit__init_A_const_10 }
//line :42:1
func A_arbace_repr_go_print_emit__init_A_Unit8__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_10; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_New(); var tmp6 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_fn_class = fncls__5d; tmp6 = fncls__5d } else { tmp6 = fncls__5 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :42:1
func A_arbace_repr_go_print_emit__init_A_Unit9__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); return A_arbace_repr_go_print_emit__init_A_const_10 }
func A_arbace_repr_go_print_emit__init_A_Unit10__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_15; var tmp2 any = A_arbace_repr_go_print_emit_full_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_print_emit_full_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_print_emit_full_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_16)); return A_arbace_repr_go_print_emit__init_A_const_15 }
//line :43:1
func A_arbace_repr_go_print_emit__init_A_Unit11__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_15; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_New(); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :43:1
func A_arbace_repr_go_print_emit__init_A_Unit12__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); return A_arbace_repr_go_print_emit__init_A_const_15 }
func A_arbace_repr_go_print_emit__init_A_Unit13__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_17; var tmp2 any = A_arbace_repr_go_print_emit_line_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_print_emit_line_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_print_emit_line_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_18)); return A_arbace_repr_go_print_emit__init_A_const_17 }
//line :44:1
func A_arbace_repr_go_print_emit__init_A_Unit14__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_17; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_New(); var tmp6 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_fn_class = fncls__23d; tmp6 = fncls__23d } else { tmp6 = fncls__23 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :44:1
func A_arbace_repr_go_print_emit__init_A_Unit15__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return A_arbace_repr_go_print_emit__init_A_const_17 }
func A_arbace_repr_go_print_emit__init_A_Unit16__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_19; var tmp2 any = A_arbace_repr_go_print_emit_bol_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_print_emit_bol_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_go_print_emit_bol_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_20)); return A_arbace_repr_go_print_emit__init_A_const_19 }
//line :45:1
func A_arbace_repr_go_print_emit__init_A_Unit17__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_19; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_New(); var tmp6 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_fn_class = fncls__32d; tmp6 = fncls__32d } else { tmp6 = fncls__32 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :45:1
func A_arbace_repr_go_print_emit__init_A_Unit18__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); return A_arbace_repr_go_print_emit__init_A_const_19 }

func A_arbace_repr_go_print_emit__init_A_Unit19__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_21; var tmp2 any = A_arbace_repr_go_print_emit_target_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_print_emit_target_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_go_print_emit_target_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_22)); return A_arbace_repr_go_print_emit__init_A_const_21 }
//line :47:1
func A_arbace_repr_go_print_emit__init_A_Unit20__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_21; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_New(); var tmp6 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_fn_class = fncls__41d; tmp6 = fncls__41d } else { tmp6 = fncls__41 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :47:1
func A_arbace_repr_go_print_emit__init_A_Unit21__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); return A_arbace_repr_go_print_emit__init_A_const_21 }







func A_arbace_repr_go_print_emit__init_A_Unit22__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_23; var tmp2 any = A_arbace_repr_go_print_emit_room_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_print_emit_room_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_repr_go_print_emit_room_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_24)); return A_arbace_repr_go_print_emit__init_A_const_23 }








func A_arbace_repr_go_print_emit__init_A_Unit23__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_repr_go_print_emit__init_A_const_25.BindRoot_O__V(A_arbace_repr_go_print_emit__init_A_const_26); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_27)); return A_arbace_repr_go_print_emit__init_A_const_25 }




func A_arbace_repr_go_print_emit__init_A_Unit24__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_28; var tmp2 any = A_arbace_repr_go_print_emit_semi_after_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_29)); return A_arbace_repr_go_print_emit__init_A_const_28 }










func A_arbace_repr_go_print_emit__init_A_Unit25__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_30; var tmp2 any = A_arbace_repr_go_print_emit_may_combine_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_31)); return A_arbace_repr_go_print_emit__init_A_const_30 }















func A_arbace_repr_go_print_emit__init_A_Unit26__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_32; var tmp2 any = A_arbace_repr_go_print_emit_start_line_BANG__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_33)); return A_arbace_repr_go_print_emit__init_A_const_32 }









func A_arbace_repr_go_print_emit__init_A_Unit27__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_34; var tmp2 any = A_arbace_repr_go_print_emit_at_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_go_print_emit_at_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_repr_go_print_emit_at_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_35)); return A_arbace_repr_go_print_emit__init_A_const_34 }






func A_arbace_repr_go_print_emit__init_A_Unit28__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_36; var tmp2 any = A_arbace_repr_go_print_emit_full_tok_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_repr_go_print_emit_full_tok_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_repr_go_print_emit_full_tok_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_37)); return A_arbace_repr_go_print_emit__init_A_const_36 }












func A_arbace_repr_go_print_emit__init_A_Unit29__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_38; var tmp2 any = A_arbace_repr_go_print_emit_soft_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_repr_go_print_emit_soft_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_repr_go_print_emit_soft_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_39)); return A_arbace_repr_go_print_emit__init_A_const_38 }








func A_arbace_repr_go_print_emit__init_A_Unit30__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_40; var tmp2 any = A_arbace_repr_go_print_emit_tok_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_repr_go_print_emit_tok_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_go_print_emit_tok_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_41)); return A_arbace_repr_go_print_emit__init_A_const_40 }


















func A_arbace_repr_go_print_emit__init_A_Unit31__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_42; var tmp2 any = A_arbace_repr_go_print_emit_raw_tok_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_repr_go_print_emit_raw_tok_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_repr_go_print_emit_raw_tok_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_43)); return A_arbace_repr_go_print_emit__init_A_const_42 }









func A_arbace_repr_go_print_emit__init_A_Unit32__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_44; var tmp2 any = A_arbace_repr_go_print_emit_sp_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_repr_go_print_emit_sp_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_repr_go_print_emit_sp_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_45)); return A_arbace_repr_go_print_emit__init_A_const_44 }







func A_arbace_repr_go_print_emit__init_A_Unit33__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_46; var tmp2 any = A_arbace_repr_go_print_emit_vtab_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_repr_go_print_emit_vtab_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_repr_go_print_emit_vtab_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_47)); return A_arbace_repr_go_print_emit__init_A_const_46 }









func A_arbace_repr_go_print_emit__init_A_Unit34__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_48; var tmp2 any = A_arbace_repr_go_print_emit_nl_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_repr_go_print_emit_nl_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_repr_go_print_emit_nl_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_49)); return A_arbace_repr_go_print_emit__init_A_const_48 }














func A_arbace_repr_go_print_emit__init_A_Unit35__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_50; var tmp2 any = A_arbace_repr_go_print_emit_cur_indent_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_repr_go_print_emit_cur_indent_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_repr_go_print_emit_cur_indent_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_51)); return A_arbace_repr_go_print_emit__init_A_const_50 }
//line :197:1
func A_arbace_repr_go_print_emit__init_A_Unit36__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit__init_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit__init_A_const_50; var tmp3 any = A_arbace_repr_go_print_emit__init_A_const_13.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_print_emit__init_A_const_14; var tmp5 any = A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_New(); var tmp6 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_fn_class = fncls__62d; tmp6 = fncls__62d } else { tmp6 = fncls__62 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :197:1
func A_arbace_repr_go_print_emit__init_A_Unit37__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); return A_arbace_repr_go_print_emit__init_A_const_50 }

func A_arbace_repr_go_print_emit__init_A_Unit38__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_52; var tmp2 any = A_arbace_repr_go_print_emit_push_open_BANG__A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_53)); return A_arbace_repr_go_print_emit__init_A_const_52 }





func A_arbace_repr_go_print_emit__init_A_Unit39__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_54; var tmp2 any = A_arbace_repr_go_print_emit_pop_open_BANG__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_repr_go_print_emit_pop_open_BANG__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_go_print_emit_pop_open_BANG__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_55)); return A_arbace_repr_go_print_emit__init_A_const_54 }




func A_arbace_repr_go_print_emit__init_A_Unit40__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_56; var tmp2 any = A_arbace_repr_go_print_emit_cont_indent_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_repr_go_print_emit_cont_indent_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_repr_go_print_emit_cont_indent_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_57)); return A_arbace_repr_go_print_emit__init_A_const_56 }





func A_arbace_repr_go_print_emit__init_A_Unit41__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_58; var tmp2 any = A_arbace_repr_go_print_emit_comment_line_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_repr_go_print_emit_comment_line_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_repr_go_print_emit_comment_line_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_59)); return A_arbace_repr_go_print_emit__init_A_const_58 }













func A_arbace_repr_go_print_emit__init_A_Unit42__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_60; var tmp2 any = A_arbace_repr_go_print_emit_set_line_BANG__A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_61)); return A_arbace_repr_go_print_emit__init_A_const_60 }



















func A_arbace_repr_go_print_emit__init_A_Unit43__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_62; var tmp2 any = A_arbace_repr_go_print_emit_start_at_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_63)); return A_arbace_repr_go_print_emit__init_A_const_62 }





func A_arbace_repr_go_print_emit__init_A_Unit44__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_64; var tmp2 any = A_arbace_repr_go_print_emit_chunk_state_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_repr_go_print_emit_chunk_state_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_go_print_emit_chunk_state_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_65)); return A_arbace_repr_go_print_emit__init_A_const_64 }









func A_arbace_repr_go_print_emit__init_A_Unit45__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(266, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_66; var tmp2 any = A_arbace_repr_go_print_emit_join_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_repr_go_print_emit_join_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_go_print_emit_join_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_67)); return A_arbace_repr_go_print_emit__init_A_const_66 }





















func A_arbace_repr_go_print_emit__init_A_Unit46__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_68; var tmp2 any = A_arbace_repr_go_print_emit_line_directive_inline_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_69)); return A_arbace_repr_go_print_emit__init_A_const_68 }









func A_arbace_repr_go_print_emit__init_A_Unit47__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_70; var tmp2 any = A_arbace_repr_go_print_emit_line_directive_own_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_repr_go_print_emit_line_directive_own_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_go_print_emit_line_directive_own_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_71)); return A_arbace_repr_go_print_emit__init_A_const_70 }









func A_arbace_repr_go_print_emit__init_A_Unit48__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_72; var tmp2 any = A_arbace_repr_go_print_emit_render_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_repr_go_print_emit_render_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_go_print_emit_render_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_73)); return A_arbace_repr_go_print_emit__init_A_const_72 }








func A_arbace_repr_go_print_emit__init_A_Unit49__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_74; var tmp2 any = A_arbace_repr_go_print_emit_break_to_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_repr_go_print_emit_break_to_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_go_print_emit_break_to_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_75)); return A_arbace_repr_go_print_emit__init_A_const_74 }




















func A_arbace_repr_go_print_emit__init_A_Unit50__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(338, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_76; var tmp2 any = A_arbace_repr_go_print_emit_stmt_break_BANG__A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_repr_go_print_emit_stmt_break_BANG__A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_77)); return A_arbace_repr_go_print_emit__init_A_const_76 }




















func A_arbace_repr_go_print_emit__init_A_Unit51__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_78; var tmp2 any = A_arbace_repr_go_print_emit_close_break_BANG__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_repr_go_print_emit_close_break_BANG__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_repr_go_print_emit_close_break_BANG__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_79)); return A_arbace_repr_go_print_emit__init_A_const_78 }
















func A_arbace_repr_go_print_emit__init_A_Unit52__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_81)); return A_arbace_repr_go_print_emit__init_A_const_80 }

func A_arbace_repr_go_print_emit__init_A_Unit53__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_82; var tmp2 any = A_arbace_repr_go_print_emit_result_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_repr_go_print_emit_result_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_repr_go_print_emit_result_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_83)); return A_arbace_repr_go_print_emit__init_A_const_82 }





















func A_arbace_repr_go_print_emit__init_A_Unit54__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_84; var tmp2 any = A_arbace_repr_go_print_emit_utf8_len_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_repr_go_print_emit_utf8_len_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_repr_go_print_emit_utf8_len_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_85)); return A_arbace_repr_go_print_emit__init_A_const_84 }


func A_arbace_repr_go_print_emit__init_A_Unit55__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(403, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_86; var tmp2 any = A_arbace_repr_go_print_emit_end_of_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_repr_go_print_emit_end_of_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_go_print_emit_end_of_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_87)); return A_arbace_repr_go_print_emit__init_A_const_86 }







func A_arbace_repr_go_print_emit__init_A_Unit56__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(411, 1); A_arbace_repr_go_print_emit__init_A_const_88.BindRoot_O__V(A_arbace_repr_go_print_emit__init_A_const_89); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_90)); return A_arbace_repr_go_print_emit__init_A_const_88 }

func A_arbace_repr_go_print_emit__init_A_Unit57__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_91; var tmp2 any = A_arbace_repr_go_print_emit_line_comment_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_92)); return A_arbace_repr_go_print_emit__init_A_const_91 }

func A_arbace_repr_go_print_emit__init_A_Unit58__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_93; var tmp2 any = A_arbace_repr_go_print_emit_place_run_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_repr_go_print_emit_place_run_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_repr_go_print_emit_place_run_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_94)); return A_arbace_repr_go_print_emit__init_A_const_93 }

















































func A_arbace_repr_go_print_emit__init_A_Unit59__O() any { A_arbace_repr_go_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_80; var tmp2 any = A_arbace_repr_go_print_emit_full_result_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_repr_go_print_emit_full_result_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_go_print_emit_full_result_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_emit__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_emit__init_A_const_95)); return A_arbace_repr_go_print_emit__init_A_const_80 }



type A_arbace_repr_go_print_emit__init_A struct{ jrt.Object }

var A_arbace_repr_go_print_emit__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_emit__init_A_const_0 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_1 any

var A_arbace_repr_go_print_emit__init_A_const_2 any

var A_arbace_repr_go_print_emit__init_A_const_3 any

var A_arbace_repr_go_print_emit__init_A_const_4 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_5 any

var A_arbace_repr_go_print_emit__init_A_const_6 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_7 any

var A_arbace_repr_go_print_emit__init_A_const_8 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_9 any

var A_arbace_repr_go_print_emit__init_A_const_10 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_11 any

var A_arbace_repr_go_print_emit__init_A_const_12 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_13 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_14 *lang.Keyword

var A_arbace_repr_go_print_emit__init_A_const_15 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_16 any

var A_arbace_repr_go_print_emit__init_A_const_17 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_18 any

var A_arbace_repr_go_print_emit__init_A_const_19 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_20 any

var A_arbace_repr_go_print_emit__init_A_const_21 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_22 any

var A_arbace_repr_go_print_emit__init_A_const_23 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_24 any

var A_arbace_repr_go_print_emit__init_A_const_25 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_26 any

var A_arbace_repr_go_print_emit__init_A_const_27 any

var A_arbace_repr_go_print_emit__init_A_const_28 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_29 any

var A_arbace_repr_go_print_emit__init_A_const_30 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_31 any

var A_arbace_repr_go_print_emit__init_A_const_32 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_33 any

var A_arbace_repr_go_print_emit__init_A_const_34 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_35 any

var A_arbace_repr_go_print_emit__init_A_const_36 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_37 any

var A_arbace_repr_go_print_emit__init_A_const_38 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_39 any

var A_arbace_repr_go_print_emit__init_A_const_40 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_41 any

var A_arbace_repr_go_print_emit__init_A_const_42 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_43 any

var A_arbace_repr_go_print_emit__init_A_const_44 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_45 any

var A_arbace_repr_go_print_emit__init_A_const_46 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_47 any

var A_arbace_repr_go_print_emit__init_A_const_48 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_49 any

var A_arbace_repr_go_print_emit__init_A_const_50 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_51 any

var A_arbace_repr_go_print_emit__init_A_const_52 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_53 any

var A_arbace_repr_go_print_emit__init_A_const_54 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_55 any

var A_arbace_repr_go_print_emit__init_A_const_56 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_57 any

var A_arbace_repr_go_print_emit__init_A_const_58 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_59 any

var A_arbace_repr_go_print_emit__init_A_const_60 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_61 any

var A_arbace_repr_go_print_emit__init_A_const_62 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_63 any

var A_arbace_repr_go_print_emit__init_A_const_64 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_65 any

var A_arbace_repr_go_print_emit__init_A_const_66 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_67 any

var A_arbace_repr_go_print_emit__init_A_const_68 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_69 any

var A_arbace_repr_go_print_emit__init_A_const_70 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_71 any

var A_arbace_repr_go_print_emit__init_A_const_72 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_73 any

var A_arbace_repr_go_print_emit__init_A_const_74 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_75 any

var A_arbace_repr_go_print_emit__init_A_const_76 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_77 any

var A_arbace_repr_go_print_emit__init_A_const_78 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_79 any

var A_arbace_repr_go_print_emit__init_A_const_80 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_81 any

var A_arbace_repr_go_print_emit__init_A_const_82 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_83 any

var A_arbace_repr_go_print_emit__init_A_const_84 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_85 any

var A_arbace_repr_go_print_emit__init_A_const_86 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_87 any

var A_arbace_repr_go_print_emit__init_A_const_88 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_89 any

var A_arbace_repr_go_print_emit__init_A_const_90 any

var A_arbace_repr_go_print_emit__init_A_const_91 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_92 any

var A_arbace_repr_go_print_emit__init_A_const_93 *lang.Var

var A_arbace_repr_go_print_emit__init_A_const_94 any

var A_arbace_repr_go_print_emit__init_A_const_95 any

var A_arbace_repr_go_print_emit__init_A_init jrt.ClassInit

func A_arbace_repr_go_print_emit__init_A_Init() { if !A_arbace_repr_go_print_emit__init_A_init.Done() { A_arbace_repr_go_print_emit__init_A_init.Run(A_arbace_repr_go_print_emit__init_A_clinit) } }

func A_arbace_repr_go_print_emit__init_A_clinit() { A_arbace_repr_go_print_emit__init_A_clinit_p0(); A_arbace_repr_go_print_emit__init_A_clinit_p1(); A_arbace_repr_go_print_emit__init_A_clinit_p2(); A_arbace_repr_go_print_emit__init_A_clinit_p3(); A_arbace_repr_go_print_emit__init_A_clinit_p4(); A_arbace_repr_go_print_emit__init_A_clinit_p5(); A_arbace_repr_go_print_emit__init_A_clinit_p6(); A_arbace_repr_go_print_emit__init_A_clinit_p7() }

func A_arbace_repr_go_print_emit__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_emit__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_42, 129); A_arbace_repr_go_print_emit__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[33]); A_arbace_repr_go_print_emit__init_A_const_1 = A_arbace_repr_go_print_emit__init_A_const_pool.A[34]; A_arbace_repr_go_print_emit__init_A_const_2 = A_arbace_repr_go_print_emit__init_A_const_pool.A[35]; A_arbace_repr_go_print_emit__init_A_const_3 = A_arbace_repr_go_print_emit__init_A_const_pool.A[36]; A_arbace_repr_go_print_emit__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[37]); A_arbace_repr_go_print_emit__init_A_const_5 = A_arbace_repr_go_print_emit__init_A_const_pool.A[38]; A_arbace_repr_go_print_emit__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[39]); A_arbace_repr_go_print_emit__init_A_const_7 = A_arbace_repr_go_print_emit__init_A_const_pool.A[40]; A_arbace_repr_go_print_emit__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[41]); A_arbace_repr_go_print_emit__init_A_const_9 = A_arbace_repr_go_print_emit__init_A_const_pool.A[42]; A_arbace_repr_go_print_emit__init_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[43]); A_arbace_repr_go_print_emit__init_A_const_11 = A_arbace_repr_go_print_emit__init_A_const_pool.A[44]; A_arbace_repr_go_print_emit__init_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[45]) }

func A_arbace_repr_go_print_emit__init_A_clinit_p1() { A_arbace_repr_go_print_emit__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[46]); A_arbace_repr_go_print_emit__init_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[47]); A_arbace_repr_go_print_emit__init_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[48]); A_arbace_repr_go_print_emit__init_A_const_16 = A_arbace_repr_go_print_emit__init_A_const_pool.A[49]; A_arbace_repr_go_print_emit__init_A_const_17 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[50]); A_arbace_repr_go_print_emit__init_A_const_18 = A_arbace_repr_go_print_emit__init_A_const_pool.A[51]; A_arbace_repr_go_print_emit__init_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[52]); A_arbace_repr_go_print_emit__init_A_const_20 = A_arbace_repr_go_print_emit__init_A_const_pool.A[53]; A_arbace_repr_go_print_emit__init_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[54]); A_arbace_repr_go_print_emit__init_A_const_22 = A_arbace_repr_go_print_emit__init_A_const_pool.A[55]; A_arbace_repr_go_print_emit__init_A_const_23 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[56]); A_arbace_repr_go_print_emit__init_A_const_24 = A_arbace_repr_go_print_emit__init_A_const_pool.A[57]; A_arbace_repr_go_print_emit__init_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[58]) }

func A_arbace_repr_go_print_emit__init_A_clinit_p2() { A_arbace_repr_go_print_emit__init_A_const_26 = A_arbace_repr_go_print_emit__init_A_const_pool.A[59]; A_arbace_repr_go_print_emit__init_A_const_27 = A_arbace_repr_go_print_emit__init_A_const_pool.A[60]; A_arbace_repr_go_print_emit__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[61]); A_arbace_repr_go_print_emit__init_A_const_29 = A_arbace_repr_go_print_emit__init_A_const_pool.A[62]; A_arbace_repr_go_print_emit__init_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[63]); A_arbace_repr_go_print_emit__init_A_const_31 = A_arbace_repr_go_print_emit__init_A_const_pool.A[64]; A_arbace_repr_go_print_emit__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[65]); A_arbace_repr_go_print_emit__init_A_const_33 = A_arbace_repr_go_print_emit__init_A_const_pool.A[66]; A_arbace_repr_go_print_emit__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[67]); A_arbace_repr_go_print_emit__init_A_const_35 = A_arbace_repr_go_print_emit__init_A_const_pool.A[68]; A_arbace_repr_go_print_emit__init_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[69]); A_arbace_repr_go_print_emit__init_A_const_37 = A_arbace_repr_go_print_emit__init_A_const_pool.A[70]; A_arbace_repr_go_print_emit__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[71]); A_arbace_repr_go_print_emit__init_A_const_39 = A_arbace_repr_go_print_emit__init_A_const_pool.A[72] }

func A_arbace_repr_go_print_emit__init_A_clinit_p3() { A_arbace_repr_go_print_emit__init_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[73]); A_arbace_repr_go_print_emit__init_A_const_41 = A_arbace_repr_go_print_emit__init_A_const_pool.A[74]; A_arbace_repr_go_print_emit__init_A_const_42 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[75]); A_arbace_repr_go_print_emit__init_A_const_43 = A_arbace_repr_go_print_emit__init_A_const_pool.A[76]; A_arbace_repr_go_print_emit__init_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[77]); A_arbace_repr_go_print_emit__init_A_const_45 = A_arbace_repr_go_print_emit__init_A_const_pool.A[78]; A_arbace_repr_go_print_emit__init_A_const_46 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[79]); A_arbace_repr_go_print_emit__init_A_const_47 = A_arbace_repr_go_print_emit__init_A_const_pool.A[80]; A_arbace_repr_go_print_emit__init_A_const_48 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[81]); A_arbace_repr_go_print_emit__init_A_const_49 = A_arbace_repr_go_print_emit__init_A_const_pool.A[82]; A_arbace_repr_go_print_emit__init_A_const_50 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[83]); A_arbace_repr_go_print_emit__init_A_const_51 = A_arbace_repr_go_print_emit__init_A_const_pool.A[84]; A_arbace_repr_go_print_emit__init_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[85]) }

func A_arbace_repr_go_print_emit__init_A_clinit_p4() { A_arbace_repr_go_print_emit__init_A_const_53 = A_arbace_repr_go_print_emit__init_A_const_pool.A[86]; A_arbace_repr_go_print_emit__init_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[87]); A_arbace_repr_go_print_emit__init_A_const_55 = A_arbace_repr_go_print_emit__init_A_const_pool.A[88]; A_arbace_repr_go_print_emit__init_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[89]); A_arbace_repr_go_print_emit__init_A_const_57 = A_arbace_repr_go_print_emit__init_A_const_pool.A[90]; A_arbace_repr_go_print_emit__init_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[91]); A_arbace_repr_go_print_emit__init_A_const_59 = A_arbace_repr_go_print_emit__init_A_const_pool.A[92]; A_arbace_repr_go_print_emit__init_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[93]); A_arbace_repr_go_print_emit__init_A_const_61 = A_arbace_repr_go_print_emit__init_A_const_pool.A[94]; A_arbace_repr_go_print_emit__init_A_const_62 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[95]); A_arbace_repr_go_print_emit__init_A_const_63 = A_arbace_repr_go_print_emit__init_A_const_pool.A[96]; A_arbace_repr_go_print_emit__init_A_const_64 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[97]); A_arbace_repr_go_print_emit__init_A_const_65 = A_arbace_repr_go_print_emit__init_A_const_pool.A[98] }

func A_arbace_repr_go_print_emit__init_A_clinit_p5() { A_arbace_repr_go_print_emit__init_A_const_66 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[99]); A_arbace_repr_go_print_emit__init_A_const_67 = A_arbace_repr_go_print_emit__init_A_const_pool.A[100]; A_arbace_repr_go_print_emit__init_A_const_68 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[101]); A_arbace_repr_go_print_emit__init_A_const_69 = A_arbace_repr_go_print_emit__init_A_const_pool.A[102]; A_arbace_repr_go_print_emit__init_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[103]); A_arbace_repr_go_print_emit__init_A_const_71 = A_arbace_repr_go_print_emit__init_A_const_pool.A[104]; A_arbace_repr_go_print_emit__init_A_const_72 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[105]); A_arbace_repr_go_print_emit__init_A_const_73 = A_arbace_repr_go_print_emit__init_A_const_pool.A[106]; A_arbace_repr_go_print_emit__init_A_const_74 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[107]); A_arbace_repr_go_print_emit__init_A_const_75 = A_arbace_repr_go_print_emit__init_A_const_pool.A[108]; A_arbace_repr_go_print_emit__init_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[109]); A_arbace_repr_go_print_emit__init_A_const_77 = A_arbace_repr_go_print_emit__init_A_const_pool.A[110]; A_arbace_repr_go_print_emit__init_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[111]) }

func A_arbace_repr_go_print_emit__init_A_clinit_p6() { A_arbace_repr_go_print_emit__init_A_const_79 = A_arbace_repr_go_print_emit__init_A_const_pool.A[112]; A_arbace_repr_go_print_emit__init_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[113]); A_arbace_repr_go_print_emit__init_A_const_81 = A_arbace_repr_go_print_emit__init_A_const_pool.A[114]; A_arbace_repr_go_print_emit__init_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[115]); A_arbace_repr_go_print_emit__init_A_const_83 = A_arbace_repr_go_print_emit__init_A_const_pool.A[116]; A_arbace_repr_go_print_emit__init_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[117]); A_arbace_repr_go_print_emit__init_A_const_85 = A_arbace_repr_go_print_emit__init_A_const_pool.A[118]; A_arbace_repr_go_print_emit__init_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[119]); A_arbace_repr_go_print_emit__init_A_const_87 = A_arbace_repr_go_print_emit__init_A_const_pool.A[120]; A_arbace_repr_go_print_emit__init_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[121]); A_arbace_repr_go_print_emit__init_A_const_89 = A_arbace_repr_go_print_emit__init_A_const_pool.A[122]; A_arbace_repr_go_print_emit__init_A_const_90 = A_arbace_repr_go_print_emit__init_A_const_pool.A[123]; A_arbace_repr_go_print_emit__init_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[124]); A_arbace_repr_go_print_emit__init_A_const_92 = A_arbace_repr_go_print_emit__init_A_const_pool.A[125] }

func A_arbace_repr_go_print_emit__init_A_clinit_p7() { A_arbace_repr_go_print_emit__init_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_emit__init_A_const_pool.A[126]); A_arbace_repr_go_print_emit__init_A_const_94 = A_arbace_repr_go_print_emit__init_A_const_pool.A[127]; A_arbace_repr_go_print_emit__init_A_const_95 = A_arbace_repr_go_print_emit__init_A_const_pool.A[128] }

func A_arbace_repr_go_print_emit__init_A_New() *A_arbace_repr_go_print_emit__init_A { A_arbace_repr_go_print_emit__init_A_Init(); t := &A_arbace_repr_go_print_emit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit__init_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit__init_A_class }

func (t *A_arbace_repr_go_print_emit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit__init_A); return ok }

func A_arbace_repr_go_print_emit__init_A_Cast(x any) *A_arbace_repr_go_print_emit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit__init_A_class)) }; return v }
