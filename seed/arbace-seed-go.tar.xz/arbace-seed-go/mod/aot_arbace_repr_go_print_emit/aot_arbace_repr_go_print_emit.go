//line aot_arbace_repr_go_print_emit.ae:1
package aot_arbace_repr_go_print_emit

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_New() *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_1, A_arbace_repr_go_print_emit_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_New() *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_repr_go_print_emit_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(), A_arbace_repr_go_print_emit_A_const_9) }

















func A_arbace_repr_go_print_emit_new_state_A_New() *A_arbace_repr_go_print_emit_new_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_new_state_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Invoke_O_O__O(self, opts__0 any) any { var tmp1 any = A_arbace_repr_go_print_emit_A_const_10; var tmp2 any = jrt.StringBuilder_New(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_11; var tmp4 any; var temp__1927000414__auto____2 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(opts__0); if







	jrt.J2g_Truth(temp__1927000414__auto____2) { var f__3 any = temp__1927000414__auto____2; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_emit_A_const_13; var tmp7 any = jrt.ArrayList_New(); var tmp8 any = A_arbace_repr_go_print_emit_A_const_14; var tmp9 any; var root_28 any = A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn
		if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any; if linked_29 == nil { tmp9 = ifn_30.Invoke_O__O(arg_31) } else { tmp9 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; tmp4 = tmp5.Invoke_O_O_O_O_O__O(f__3, tmp6, tmp7, tmp8, tmp9) } else {
//line :27:1
			tmp4 = nil }; var tmp10 any = tmp4; var tmp11 any = A_arbace_repr_go_print_emit_A_const_16; var tmp12 any; var root_32 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_34 lang.IFn; if









	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_repr_go_print_emit_A_const_17; if linked_33 == nil { tmp12 = ifn_34.Invoke_O__O(arg_35) } else { tmp12 = linked_33.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_32, arg_35) }; var tmp13 any = tmp12; var tmp14 any = A_arbace_repr_go_print_emit_A_const_18; var tmp15 any; var root_36 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_38 lang.IFn; if










	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = jrt.Boolean_TRUE.Ref(); if linked_37 == nil { tmp15 = ifn_38.Invoke_O__O(arg_39) } else { tmp15 = linked_37.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_36, arg_39) }; var tmp16 any = tmp15; var tmp17 any = A_arbace_repr_go_print_emit_A_const_19; var tmp18 any; var root_40 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_42 lang.IFn; if











	linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_repr_go_print_emit_A_const_20; if linked_41 == nil { tmp18 = ifn_42.Invoke_O__O(arg_43) } else { tmp18 = linked_41.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_40, arg_43) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_repr_go_print_emit_A_const_21; var tmp21 any; var root_44 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_46 lang.IFn; if












	linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_repr_go_print_emit_A_const_20; if linked_45 == nil { tmp21 = ifn_46.Invoke_O__O(arg_47) } else { tmp21 = linked_45.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_44, arg_47) }; var tmp22 any = tmp21; var tmp23 any = A_arbace_repr_go_print_emit_A_const_22; var tmp24 any; var root_48 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_50 lang.IFn; if













	linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = Lit_2; if linked_49 == nil { tmp24 = ifn_50.Invoke_O__O(arg_51) } else { tmp24 = linked_49.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_48, arg_51) }; var tmp25 any = tmp24; var tmp26 any = A_arbace_repr_go_print_emit_A_const_23; var tmp27 any; var root_52 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_54 lang.IFn; if














	linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = jrt.Boolean_FALSE.Ref(); if linked_53 == nil { tmp27 = ifn_54.Invoke_O__O(arg_55) } else { tmp27 = linked_53.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_52, arg_55) }; var tmp28 any = tmp27; var tmp29 any = A_arbace_repr_go_print_emit_A_const_24; var tmp30 any; var root_56 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_58 lang.IFn; if















	linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any; if linked_57 == nil { tmp30 = ifn_58.Invoke_O__O(arg_59) } else { tmp30 = linked_57.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_56, arg_59) }; var tmp31 any = tmp30; var tmp32 any = A_arbace_repr_go_print_emit_A_const_25; var tmp33 any; var root_60 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_62 lang.IFn; if
















	linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.PersistentVector_EMPTY.Ref(); if linked_61 == nil { tmp33 = ifn_62.Invoke_O__O(arg_63) } else { tmp33 = linked_61.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_60, arg_63) }; var tmp34 any = tmp33; var tmp35 any = A_arbace_repr_go_print_emit_A_const_26; var tmp36 any; var root_64 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_66 lang.IFn; if

















	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_repr_go_print_emit_A_const_20; if linked_65 == nil { tmp36 = ifn_66.Invoke_O__O(arg_67) } else { tmp36 = linked_65.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_64, arg_67) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_repr_go_print_emit_A_const_27; var tmp39 any; var root_68 any = /*line :19:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_70 lang.IFn; if


















	linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_repr_go_print_emit_A_const_17; if linked_69 == nil { tmp39 = ifn_70.Invoke_O__O(arg_71) } else { tmp39 = linked_69.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_68, arg_71) }; var tmp40 any = tmp39; var tmp41 any = A_arbace_repr_go_print_emit_A_const_28; var tmp42 any = /*line :19:1*/jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(opts__0))).Ref(); var tmp43 any = A_arbace_repr_go_print_emit_A_const_29; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp22, tmp23, tmp25, tmp26, tmp28, tmp29, tmp31, tmp32, tmp34, tmp35, tmp37, tmp38, tmp40, tmp41, tmp42, tmp43, A_arbace_repr_go_print_emit_A_const_30.Invoke_O_O__O(opts__0, jrt.Boolean_TRUE.Ref()))) }






















func A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_New() *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Invoke_O__O(self any) any { var root_72 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any; var root_76 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_28); var arg_80 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_35); if linked_77 == nil { arg_75 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { arg_75 = linked_77.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) }; if linked_73 == nil { return ifn_74.Invoke_O__O(arg_75) } else { return linked_73.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_72, arg_75) } }
//line :42:1
func A_arbace_repr_go_print_emit_lines_QMARK__A_New() *A_arbace_repr_go_print_emit_lines_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_lines_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_New() *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Invoke_O__O(self any) any { var root_81 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_85 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_11); var arg_89 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_36); if linked_86 == nil { arg_84 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_84 = linked_86.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if linked_82 == nil { return ifn_83.Invoke_O__O(arg_84) } else { return linked_82.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_81, arg_84) } }
//line :43:1
func A_arbace_repr_go_print_emit_full_QMARK__A_New() *A_arbace_repr_go_print_emit_full_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_QMARK__A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_New() *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000040_line__308000041_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Invoke_O__O(self any) any { var root_94 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_98 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37); var arg_102 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp2 any; var root_103 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var root_107 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16); var arg_111 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_38); if linked_108 == nil { arg_106 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { arg_106 = linked_108.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; if linked_104 == nil { tmp2 = ifn_105.Invoke_O__O(arg_106) } else { tmp2 = linked_104.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_103, arg_106) }; arg_102 = tmp1.Invoke_O__O(tmp2); if linked_99 == nil { arg_97 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }; if linked_95 == nil { return ifn_96.Invoke_O__O(arg_97) } else { return linked_95.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_94, arg_97) } }
//line :44:1
func A_arbace_repr_go_print_emit_line_A_New() *A_arbace_repr_go_print_emit_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Invoke_O__O(self any) any { var root_90 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_93 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_90, arg_93) } }
func A_arbace_repr_go_print_emit_bol_QMARK__A_New() *A_arbace_repr_go_print_emit_bol_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_bol_QMARK__A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Invoke_O__O(self any) any { var root_112 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_115 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_113 == nil { return ifn_114.Invoke_O__O(arg_115) } else { return linked_113.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_112, arg_115) } }
//line :45:1
func A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_New() *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Invoke_O__O(self any) any { var root_116 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_120 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37); var arg_124 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp2 any; var root_125 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_129 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18); var arg_133 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_39); if linked_130 == nil { arg_128 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { arg_128 = linked_130.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if linked_126 == nil { tmp2 = ifn_127.Invoke_O__O(arg_128) } else { tmp2 = linked_126.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_125, arg_128) }; arg_124 = tmp1.Invoke_O__O(tmp2); if linked_121 == nil { arg_119 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { arg_119 = linked_121.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) }; if linked_117 == nil { return ifn_118.Invoke_O__O(arg_119) } else { return linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) } }

func A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_New() *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000063_target__308000064_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Invoke_O_O__O(self, f__1 any) any { var root_138 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_41); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp4 any; var root_148 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_152 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_42); if linked_153 == nil { arg_151 = ifn_154.Invoke_O__O(arg_155) } else { arg_151 = linked_153.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_152, arg_155) }; if linked_149 == nil { tmp4 = ifn_150.Invoke_O__O(arg_151) } else { tmp4 = linked_149.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_148, arg_151) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp7 any; var root_156 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_43); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp11 any; var root_166 any = A_arbace_repr_go_print_emit_A_const_44.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(); var arg_170 any; var root_171 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_175 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46); var arg_179 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp13 any; var root_180 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_184 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16); var arg_188 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp15 any; var root_189 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any; var root_193 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_47); var arg_197 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(f__1); if linked_194 == nil { arg_192 = ifn_195.Invoke_O_O__O(arg_196, arg_197) } else { arg_192 = linked_194.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_193, arg_196, arg_197) }; if linked_190 == nil { tmp15 = ifn_191.Invoke_O__O(arg_192) } else { tmp15 = linked_190.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_189, arg_192) }; arg_188 = tmp14.Invoke_O__O(tmp15); if linked_185 == nil { arg_183 = ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { arg_183 = linked_185.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) }; if linked_181 == nil { tmp13 = ifn_182.Invoke_O__O(arg_183) } else { tmp13 = linked_181.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_180, arg_183) }; arg_179 = tmp12.Invoke_O__O(tmp13); if linked_176 == nil { arg_174 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { arg_174 = linked_176.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if linked_172 == nil { arg_170 = ifn_173.Invoke_O__O(arg_174) } else { arg_170 = linked_172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_171, arg_174) }; if linked_167 == nil { tmp11 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { tmp11 = linked_167.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) }; var tmp16 any = tmp10.Invoke_O__O(tmp11); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp18 any; var root_198 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp20 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_48); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp22 any; var root_208 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_212 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_49); var arg_216 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46); if linked_213 == nil { arg_211 = ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { arg_211 = linked_213.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) }; if linked_209 == nil { tmp22 = ifn_210.Invoke_O__O(arg_211) } else { tmp22 = linked_209.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_208, arg_211) }; var tmp23 any = tmp21.Invoke_O__O(tmp22); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp25 any; var root_217 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_221 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_50); var arg_225 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46); if linked_222 == nil { arg_220 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { arg_220 = linked_222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; if linked_218 == nil { tmp25 = ifn_219.Invoke_O__O(arg_220) } else { tmp25 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; arg_201 = tmp19.Invoke_O_O_O__O(tmp20, tmp23, tmp24.Invoke_O__O(tmp25)); if linked_199 == nil { tmp18 = ifn_200.Invoke_O__O(arg_201) } else { tmp18 = linked_199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_198, arg_201) }; arg_159 = tmp8.Invoke_O_O_O__O(tmp9, tmp16, tmp17.Invoke_O__O(tmp18)); if linked_157 == nil { tmp7 = ifn_158.Invoke_O__O(arg_159) } else { tmp7 = linked_157.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_156, arg_159) }; arg_141 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_139 == nil { return ifn_140.Invoke_O__O(arg_141) } else { return linked_139.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_138, arg_141) } }
//line :47:1
func A_arbace_repr_go_print_emit_target_A_New() *A_arbace_repr_go_print_emit_target_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_target_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp3 any; var root_134 any = A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = l__308000057__auto____2; if linked_135 == nil { tmp3 = ifn_136.Invoke_O__O(arg_137) } else { tmp3 = linked_135.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp3) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }







func A_arbace_repr_go_print_emit_room_QMARK__A_New() *A_arbace_repr_go_print_emit_room_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_room_QMARK__A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_226 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_228 lang.IFn; if



	linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; var arg_229 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_227 == nil { or__1927000174__auto____2 = ifn_228.Invoke_O__O(arg_229) } else { or__1927000174__auto____2 = linked_227.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_52.Get__O(), nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp2 bool; var na_230 int64 = lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_52.Get__O()); var na_231 any; var na_232 any; var root_234 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_237 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_235 == nil { na_232 = ifn_236.Invoke_O__O(arg_237) } else { na_232 = linked_235.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_234, arg_237) }; var na_233 int64 = lang.RT_LongCast_O__J_NoInit(n__0); if jrt.Long_InstanceOf(na_232) { var n0_238 int64 = jrt.NN(jrt.Long_Cast(na_232)).LongValue__J(); var n1_239 int64 = na_233; var nr_240 int64 = n0_238 + n1_239; if (n0_238^nr_240)&(n1_239^nr_240) >= 0 { na_231 = jrt.Long_ValueOf_J__Long_NoInit(nr_240).Ref() } else { na_231 = lang.Numbers_Add_O_J__Number_NoInit(na_232, na_233) } } else { na_231 = lang.Numbers_Add_O_J__Number_NoInit(na_232, na_233) }; if jrt.Long_InstanceOf(na_231) { var n0_241 int64 = na_230; var n1_242 int64 = jrt.NN(jrt.Long_Cast(na_231)).LongValue__J(); tmp2 = n0_241 > n1_242 } else { tmp2 = lang.Numbers_Gt_J_O__Z_NoInit(na_230, na_231) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } } }









func A_arbace_repr_go_print_emit_semi_after_QMARK__A_New() *A_arbace_repr_go_print_emit_semi_after_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_semi_after_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_53).Invoke_O__O(s__0)) { return jrt.Boolean_TRUE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(s__0)) { return jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { var c__2 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())))); var or__1927000174__auto____3 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(c__2)




		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_57)).CharValue__C()); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_58)).CharValue__C()); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_59)).CharValue__C()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else {
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_IntCast_C__I_NoInit(c__2)), 127)).Ref() } } } } } } else {
//line :72:1
				return nil
			}
	}
	}
	}
}


func A_arbace_repr_go_print_emit_may_combine_QMARK__A_New() *A_arbace_repr_go_print_emit_may_combine_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_may_combine_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Invoke_O_O_O__O(self, prev__0, next__1 any) any {



	var tmp1 bool; var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())); if and__1927000168__auto____3 { tmp1 = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(next__1)).Length__I())) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var p__3 uint16 = jrt.NN(jrt.String_Cast(prev__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())))); var n__4 uint16 = jrt.NN(jrt.String_Cast(next__1)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); var or__1927000174__auto____5 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_28)


		if and__1927000168__auto____5 { or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_60)).CharValue__C()) } else { or__1927000174__auto____5 = and__1927000168__auto____5 }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_29)
			if and__1927000168__auto____6 { or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :87:1
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C())

				if and__1927000168__auto____7 { var or__1927000174__auto____8 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_63)).CharValue__C()); if or__1927000174__auto____8 { or__1927000174__auto____7 = or__1927000174__auto____8 } else { or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C()) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :87:1
				if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8_2 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_30)


					if and__1927000168__auto____8 { var or__1927000174__auto____9 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()); if or__1927000174__auto____9 { or__1927000174__auto____8_2 = or__1927000174__auto____9 } else { or__1927000174__auto____8_2 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_64)).CharValue__C()) } } else { or__1927000174__auto____8_2 = and__1927000168__auto____8 }
//line :87:1
					if or__1927000174__auto____8_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8_2).Ref() } else { var or__1927000174__auto____9_2 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_31)



						if and__1927000168__auto____9 { var or__1927000174__auto____10 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_65)).CharValue__C()); if or__1927000174__auto____10 { or__1927000174__auto____9_2 = or__1927000174__auto____10 } else { or__1927000174__auto____9_2 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_66)).CharValue__C()) } } else { or__1927000174__auto____9_2 = and__1927000168__auto____9 }
//line :87:1
						if or__1927000174__auto____9_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9_2).Ref() } else { var or__1927000174__auto____10_2 any; var and__1927000168__auto____10 bool = jrt.Character_IsDigit_C__Z_NoInit(p__3)




							if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_67)).CharValue__C()); if and__1927000168__auto____11 { var root_244 any = A_arbace_repr_go_print_emit_A_const_68.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = A_arbace_repr_go_print_emit_A_const_69; var arg_248 any = prev__0; if linked_245 == nil { or__1927000174__auto____10_2 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { or__1927000174__auto____10_2 = linked_245.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }
//line :87:1
							if jrt.J2g_Truth(or__1927000174__auto____10_2) { return or__1927000174__auto____10_2 } else { var and__1927000168__auto____11_2 bool; var or__1927000174__auto____11 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(p__3)





								if or__1927000174__auto____11 { and__1927000168__auto____11_2 = or__1927000174__auto____11 } else { and__1927000168__auto____11_2 = lang.Util_Equiv_C_C__Z_NoInit(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()) }; if and__1927000168__auto____11_2 { var or__1927000174__auto____12 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(n__4)
									if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C())).Ref() } } else {
//line :93:1
										return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() } } } } } } } } else {
//line :84:1
											return nil
										}
}









func A_arbace_repr_go_print_emit_start_line_BANG__A_New() *A_arbace_repr_go_print_emit_start_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_line_BANG__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var tmp1 any; var root_249 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_251 lang.IFn; if

	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__1); if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { var n__2 int64; var tmp2 any; var root_253 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_255 lang.IFn
		if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__1); if linked_254 == nil { tmp2 = ifn_255.Invoke_O__O(arg_256) } else { tmp2 = linked_254.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_253, arg_256) }; n__2 = lang.Numbers_Max_J_J__J_NoInit(0, lang.RT_LongCast_O__J_NoInit(tmp2))
//line :98:1
		var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J_NoInit(n__2); var ___5 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(___5, n__1927000701__auto____4) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___5 = lang.Numbers_Unchecked_inc_J__J_NoInit(___5); continue L1 }
//line :98:1
			break L1
		}


		var root_262 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__1); var arg_266 any = jrt.Long_ValueOf_J__Long_NoInit(n__2).Ref(); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }
		var root_267 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__1); var arg_271 any = jrt.Boolean_FALSE.Ref(); if linked_268 == nil { ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { linked_268.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_267, arg_270, arg_271) }
		var root_257 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__1); var arg_261 any; if linked_258 == nil { return ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { return linked_258.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_257, arg_260, arg_261) } } else {
//line :98:1
			return nil } }







func A_arbace_repr_go_print_emit_at_BANG__A_New() *A_arbace_repr_go_print_emit_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_at_BANG__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Invoke_O_O__O(self, pos__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var fs__3 any = temp__1927000414__auto____2
		if jrt.J2g_Truth(pos__0) { var root_272 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = A_arbace_repr_go_print_emit_A_const_14.Invoke_O__O(fs__3); var arg_276 any = pos__0; if linked_273 == nil { ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { linked_273.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_272, arg_275, arg_276) } }
//line :109:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_full_tok_A_New() *A_arbace_repr_go_print_emit_full_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_tok_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Invoke_O_O__O(self, s__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var fs__3 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(p__2); var pos__4 any; var root_277 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_279 lang.IFn; if



	linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = A_arbace_repr_go_print_emit_A_const_14.Invoke_O__O(fs__3); if linked_278 == nil { pos__4 = ifn_279.Invoke_O__O(arg_280) } else { pos__4 = linked_278.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_277, arg_280) }; var root_281 any =

	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = A_arbace_repr_go_print_emit_A_const_14.Invoke_O__O(fs__3); var arg_285 any; if linked_282 == nil { ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { linked_282.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_281, arg_284, arg_285) }; var tmp1 /*line :120:1*/*jrt.ArrayList = jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(fs__3)); var tmp2 any = A_arbace_repr_go_print_emit_A_const_72; var tmp3 any = A_arbace_repr_go_print_emit_A_const_73; var tmp4 any = A_arbace_repr_go_print_emit_A_const_74; var tmp5 any; var or__1927000174__auto____5 any; var root_286 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_288 lang.IFn; if
	linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); if linked_287 == nil { or__1927000174__auto____5 = ifn_288.Invoke_O__O(arg_289) } else { or__1927000174__auto____5 = linked_287.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { var root_290 any = A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var root_295 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__2); if linked_296 == nil { arg_293 = ifn_297.Invoke_O__O(arg_298) } else { arg_293 = linked_296.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_295, arg_298) }; var arg_294 any = s__0; if linked_291 == nil { tmp5 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { tmp5 = linked_291.(*A_arbace_repr_go_print_emit_may_combine_QMARK__A).Invoke_O_O_O__O(root_290, arg_293, arg_294) } }; /*line :120:1*/jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(tmp1).Add_O__Z(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, s__0, tmp3, pos__4, tmp4, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref())))); var root_299 any =

	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); var arg_303 any; if linked_300 == nil { ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { linked_300.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }; var root_304 any =
	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__2); var arg_308 any = s__0; if linked_305 == nil { ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { linked_305.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }; return nil }


func A_arbace_repr_go_print_emit_soft_A_New() *A_arbace_repr_go_print_emit_soft_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_soft_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Invoke_O_O_O__O(self, kind__0, s__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____3 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if




	jrt.J2g_Truth(temp__1927000414__auto____3) { var fs__4 any = temp__1927000414__auto____3
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(fs__4))).Add_O__Z(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_emit_A_const_76, kind__0, A_arbace_repr_go_print_emit_A_const_72, s__1))))
//line :131:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_tok_A_New() *A_arbace_repr_go_print_emit_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_tok_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_309 any = A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, A_arbace_repr_go_print_emit_full_tok_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__0; if linked_310 == nil { return ifn_311.Invoke_O__O(arg_312) } else { return linked_310.(*A_arbace_repr_go_print_emit_full_tok_A).Invoke_O_O__O(root_309, arg_312) } } else {
//line :138:1
			var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2); var at_bol__4 any; var root_313 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_315 lang.IFn

			if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2); if linked_314 == nil { at_bol__4 = ifn_315.Invoke_O__O(arg_316) } else { at_bol__4 = linked_314.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_313, arg_316)
			}
			var root_317 any = A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; if linked_318 == nil { ifn_319.Invoke__O() } else { linked_318.(*A_arbace_repr_go_print_emit_start_line_BANG__A).Invoke_O__O(root_317) }
//line :138:1
			var ws__5 any; var root_320 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_322 lang.IFn




			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); if linked_321 == nil { ws__5 = ifn_322.Invoke_O__O(arg_323) } else { ws__5 = linked_321.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_320, arg_323) }
			if jrt.J2g_Truth(at_bol__4) { } else { if jrt.J2g_Truth(ws__5) {

				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(ws__5)) } else {
//line :144:1
					var tmp2 any; var root_324 any = A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class); var ifn_326 lang.IFn


					if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_329 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__2); if linked_330 == nil { arg_327 = ifn_331.Invoke_O__O(arg_332) } else { arg_327 = linked_330.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_329, arg_332) }; var arg_328 any = s__0; if linked_325 == nil { tmp2 = ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { tmp2 = linked_325.(*A_arbace_repr_go_print_emit_may_combine_QMARK__A).Invoke_O_O_O__O(root_324, arg_327, arg_328) }
//line :144:1
					if jrt.J2g_Truth(tmp2) {


						jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } }
			var root_333 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); var arg_337 any; if linked_334 == nil { ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { linked_334.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_333, arg_336, arg_337) }
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(s__0))
			var root_338 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__2); var arg_342 any = s__0; if linked_339 == nil { ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { linked_339.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }
			var root_343 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__2); var arg_347 any; var root_348 any = A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = s__0; if linked_349 == nil { arg_347 = ifn_350.Invoke_O__O(arg_351) } else { arg_347 = linked_349.(*A_arbace_repr_go_print_emit_semi_after_QMARK__A).Invoke_O_O__O(root_348, arg_351) }; if linked_344 == nil { ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { linked_344.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }
//line :138:1
			return nil
		}
}













func A_arbace_repr_go_print_emit_raw_tok_A_New() *A_arbace_repr_go_print_emit_raw_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Ctor() {}
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_352 any = A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, A_arbace_repr_go_print_emit_full_tok_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = s__0; if linked_353 == nil { return ifn_354.Invoke_O__O(arg_355) } else { return linked_353.(*A_arbace_repr_go_print_emit_full_tok_A).Invoke_O_O__O(root_352, arg_355) } } else {
			var root_361 any = A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any; var root_365 any = A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_escape_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = s__0; if linked_366 == nil { arg_364 = ifn_367.Invoke_O__O(arg_368) } else { arg_364 = linked_366.(*aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_escape_A).Invoke_O_O__O(root_365, arg_368) }; if linked_362 == nil { ifn_363.Invoke_O__O(arg_364) } else { linked_362.(*A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_361, arg_364) }
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var tmp3 *lang.Volatile = lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp4 jrt.Number_I; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var na_369 any = jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); var na_370 int64; var tmp6 any; var root_371 any = A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp7 any = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New(); var tmp8 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class = fncls__376d; tmp8 = fncls__376d } else { tmp8 = fncls__376 }; arg_374 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_375 any = s__0; if linked_372 == nil { tmp6 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp6 = linked_372.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; na_370 = int64(lang.RT_Count_O__I_NoInit(tmp6)); if jrt.Long_InstanceOf(na_369) { var n0_377 int64 = jrt.NN(jrt.Long_Cast(na_369)).LongValue__J(); var n1_378 int64 = na_370; var nr_379 int64 = n0_377 + n1_378; if (n0_377^nr_379)&(n1_378^nr_379) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_379)) } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_369, na_370) } } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_369, na_370) }; jrt.NN(tmp3).Reset_O__O(tmp4)
			var root_356 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; var arg_359 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_360 any = jrt.Boolean_TRUE.Ref(); if linked_357 == nil { return ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { return linked_357.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_356, arg_359, arg_360) } } }
//line :161:1
func A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New() *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Invoke_O_O__O(self, p1__308000077_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__308000077_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }


func A_arbace_repr_go_print_emit_sp_A_New() *A_arbace_repr_go_print_emit_sp_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_sp_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Ctor() {}
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_380 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_383 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_384 any = A_arbace_repr_go_print_emit_A_const_79; if linked_381 == nil { return ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { return linked_381.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_380, arg_383, arg_384) } } else {
			var tmp3 any; var root_385 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_388 any = tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_386 == nil { tmp3 = ifn_387.Invoke_O__O(arg_388) } else { tmp3 = linked_386.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_385, arg_388) }; if jrt.J2g_Truth(tmp3) { return nil } else {
				var tmp5 any = A_arbace_repr_go_print_emit_A_const_85; var tmp6 any; var root_389 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_392 any = tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_390 == nil { tmp6 = ifn_391.Invoke_O__O(arg_392) } else { tmp6 = linked_390.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_389, arg_392) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) { return nil } else { var root_393 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var tmp8 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_396 any = tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_397 any = A_arbace_repr_go_print_emit_A_const_79; if linked_394 == nil { return ifn_395.Invoke_O_O__O(arg_396, arg_397) } else { return linked_394.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_393, arg_396, arg_397)
				} } } } }
func A_arbace_repr_go_print_emit_vtab_A_New() *A_arbace_repr_go_print_emit_vtab_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_vtab_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_398 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_401 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_402 any = A_arbace_repr_go_print_emit_A_const_79; if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } } else {
			var tmp3 any; var root_403 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_406 any = tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_404 == nil { tmp3 = ifn_405.Invoke_O__O(arg_406) } else { tmp3 = linked_404.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_403, arg_406) }; if jrt.J2g_Truth(tmp3) { return nil } else {

				var tmp5 any = A_arbace_repr_go_print_emit_A_const_85; var tmp6 any; var root_412 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_415 any = tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_413 == nil { tmp6 = ifn_414.Invoke_O__O(arg_415) } else { tmp6 = linked_413.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_412, arg_415) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) { var tmp8 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; jrt.NN(jrt.StringBuilder_Cast(tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(11)) }
				var root_407 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_410 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_411 any = jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(11)).Ref(); if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_407, arg_410, arg_411)
				} } } }
func A_arbace_repr_go_print_emit_nl_A_New() *A_arbace_repr_go_print_emit_nl_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_nl_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Ctor() {}
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O_O__O(self, indent__0, form_feed_QMARK___1 any) any {




	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_416 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_419 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_420 any; if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else {
//line :187:1
			var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3); var root_421 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_423 lang.IFn


			if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__3); var arg_425 any; if linked_422 == nil { ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { linked_422.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) }
			var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp4 uint16; if jrt.J2g_Truth(form_feed_QMARK___1) { tmp4 = lang.RT_CharCast_J__C_NoInit(12) } else { tmp4 = lang.RT_CharCast_J__C_NoInit(10) }; jrt.NN(tmp3).Append_C__StringBuilder(tmp4)
			var tmp5 *lang.Volatile = lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3)); var tmp6 jrt.Number_I; var na_426 any = jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3))).Deref__O(); if jrt.Long_InstanceOf(na_426) { var n0_427 int64 = jrt.NN(jrt.Long_Cast(na_426)).LongValue__J(); if n0_427 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_426) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_427 + 1)) } } else { if jrt.Double_InstanceOf(na_426) { var n0_427_2 float64 = jrt.NN(jrt.Double_Cast(na_426)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_427_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_426) } }; jrt.NN(tmp5).Reset_O__O(tmp6)
			var root_428 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3); var arg_432 any = jrt.Boolean_TRUE.Ref(); if linked_429 == nil { ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { linked_429.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }
			var root_433 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3); var arg_437 any = indent__0; if linked_434 == nil { ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { linked_434.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }
//line :187:1
			return nil } }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O__O(self, indent__0 any) any {


	var root_438 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = indent__0; var arg_442 any = jrt.Boolean_FALSE.Ref(); if linked_439 == nil { return ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { return linked_439.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_438, arg_441, arg_442)
	}
}









func A_arbace_repr_go_print_emit_cur_indent_A_New() *A_arbace_repr_go_print_emit_cur_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cur_indent_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Invoke_O__O(self any) any { var root_443 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var arg_446 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_444 == nil { return ifn_445.Invoke_O__O(arg_446) } else { return linked_444.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_443, arg_446) } }
//line :197:1
func A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_New() *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Invoke_O__O(self any) any { var root_447 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var root_451 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37); var arg_455 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()); var tmp2 any; var root_456 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_460 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_21); var arg_464 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_87); if linked_461 == nil { arg_459 = ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { arg_459 = linked_461.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_460, arg_463, arg_464) }; if linked_457 == nil { tmp2 = ifn_458.Invoke_O__O(arg_459) } else { tmp2 = linked_457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_456, arg_459) }; arg_455 = tmp1.Invoke_O__O(tmp2); if linked_452 == nil { arg_450 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { arg_450 = linked_452.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; if linked_448 == nil { return ifn_449.Invoke_O__O(arg_450) } else { return linked_448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_447, arg_450) } }

func A_arbace_repr_go_print_emit_push_open_BANG__A_New() *A_arbace_repr_go_print_emit_push_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_push_open_BANG__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O_O__O(self, indent__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var tmp2 *lang.Volatile = lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp3 any; var root_465 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var arg_468 any = jrt.NN(lang.Volatile_Cast(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); var arg_469 any = indent__0; if linked_466 == nil { tmp3 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { tmp3 = linked_466.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }; jrt.NN(tmp2).Reset_O__O(tmp3)
//line :199:1
	return nil }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O__O(self any) any {


	var root_470 any = A_arbace_repr_go_print_emit_A_const_88.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var tmp1 any; var root_474 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_477 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_475 == nil { tmp1 = ifn_476.Invoke_O__O(arg_477) } else { tmp1 = linked_475.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_474, arg_477) }; if jrt.J2g_Truth(tmp1) { var root_478 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var arg_481 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_479 == nil { arg_473 = ifn_480.Invoke_O__O(arg_481) } else { arg_473 = linked_479.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_478, arg_481) } } else { var root_482 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var arg_485 any = tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_483 == nil { arg_473 = ifn_484.Invoke_O__O(arg_485) } else { arg_473 = linked_483.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_482, arg_485) } }; if linked_471 == nil { return ifn_472.Invoke_O__O(arg_473) } else { return linked_471.(*A_arbace_repr_go_print_emit_push_open_BANG__A).Invoke_O_O__O(root_470, arg_473)
	}
}
func A_arbace_repr_go_print_emit_pop_open_BANG__A_New() *A_arbace_repr_go_print_emit_pop_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_pop_open_BANG__A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Ctor() {}
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Invoke_O__O(self any) any { var o__1 any; var root_486 any = A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_488 lang.IFn; if
											linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; var root_490 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var arg_493 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_491 == nil { arg_489 = ifn_492.Invoke_O__O(arg_493) } else { arg_489 = linked_491.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_490, arg_493) }; if linked_487 == nil { o__1 = ifn_488.Invoke_O__O(arg_489) } else { o__1 = linked_487.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_486, arg_489) }; var tmp2 /*line :207:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var tmp3 *lang.Volatile = lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp4 any; var root_494 any = A_arbace_repr_go_print_emit_A_const_90.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var arg_497 any = jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); if linked_495 == nil { tmp4 = ifn_496.Invoke_O__O(arg_497) } else { tmp4 = linked_495.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_494, arg_497) }; jrt.NN(tmp3).Reset_O__O(tmp4); return o__1 }


func A_arbace_repr_go_print_emit_cont_indent_A_New() *A_arbace_repr_go_print_emit_cont_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cont_indent_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Ctor() {}
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Invoke_O__O(self any) any { var o__1 any; var root_498 any = A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_500 lang.IFn; if


	linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var root_502 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; var arg_505 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_503 == nil { arg_501 = ifn_504.Invoke_O__O(arg_505) } else { arg_501 = linked_503.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_502, arg_505) }; if linked_499 == nil { o__1 = ifn_500.Invoke_O__O(arg_501) } else { o__1 = linked_499.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_498, arg_501) }; var tmp2 any; var or__1927000174__auto____2 any = o__1; if
	jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_repr_go_print_emit_A_const_20 }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(tmp2))).Ref() }

func A_arbace_repr_go_print_emit_comment_line_A_New() *A_arbace_repr_go_print_emit_comment_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_comment_line_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Ctor() {}
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Invoke_O_O_O__O(self, s__0, indent__1 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return nil } else { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3); var tmp2 any; var root_510 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_512 lang.IFn

		if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_513 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_511 == nil { tmp2 = ifn_512.Invoke_O__O(arg_513) } else { tmp2 = linked_511.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(tmp2) { } else { var root_514 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = indent__1; if linked_515 == nil { ifn_516.Invoke_O__O(arg_517) } else { linked_515.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_514, arg_517) } }
		var root_518 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3); var arg_522 any; var tmp4 any; var root_523 any = A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__0; var arg_527 any = Lit_1; if linked_524 == nil { tmp4 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp4 = linked_524.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if jrt.J2g_Truth(tmp4) { arg_522 = A_arbace_repr_go_print_emit_A_const_20 } else { arg_522 = indent__1 }; if linked_519 == nil { ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { linked_519.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }
		var root_528 any = A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; if linked_529 == nil { ifn_530.Invoke__O() } else { linked_529.(*A_arbace_repr_go_print_emit_start_line_BANG__A).Invoke_O__O(root_528) }
		var tmp5 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp6 any; var root_531 any = A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_escape_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = s__0; if linked_532 == nil { tmp6 = ifn_533.Invoke_O__O(arg_534) } else { tmp6 = linked_532.(*aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_escape_A).Invoke_O_O__O(root_531, arg_534) }; jrt.NN(tmp5).Append_String__StringBuilder(jrt.String_Cast(tmp6))
		var root_535 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3); var arg_539 any = Lit_2; if linked_536 == nil { ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { linked_536.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_535, arg_538, arg_539) }
		var root_540 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3); var arg_544 any = jrt.Boolean_FALSE.Ref(); if linked_541 == nil { ifn_542.Invoke_O_O__O(arg_543, arg_544) } else { linked_541.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_540, arg_543, arg_544) }
		var root_506 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = indent__1; if linked_507 == nil { return ifn_508.Invoke_O__O(arg_509) } else { return linked_507.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_506, arg_509)
		} } }
func A_arbace_repr_go_print_emit_set_line_BANG__A_New() *A_arbace_repr_go_print_emit_set_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_set_line_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var root_545 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_548 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_549 any = l__0; if linked_546 == nil { ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { linked_546.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }
	var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_27; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_27; return jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Min_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J_NoInit(l__0)))
}














func A_arbace_repr_go_print_emit_start_at_BANG__A_New() *A_arbace_repr_go_print_emit_start_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_at_BANG__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Ctor() {}
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var root_555 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_558 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_559 any = l__0; if linked_556 == nil { ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { linked_556.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }
	var root_550 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_27; var arg_553 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_554 any = l__0; if linked_551 == nil { return ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { return linked_551.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_550, arg_553, arg_554)
	} }
func A_arbace_repr_go_print_emit_chunk_state_A_New() *A_arbace_repr_go_print_emit_chunk_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_chunk_state_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var tmp1 any = A_arbace_repr_go_print_emit_A_const_92; var tmp2 any = jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1))).ToString__String().Ref(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_16; var tmp4 any; var root_560 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_562 lang.IFn; if



	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__1); if linked_561 == nil { tmp4 = ifn_562.Invoke_O__O(arg_563) } else { tmp4 = linked_561.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_560, arg_563) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_repr_go_print_emit_A_const_18; var tmp7 any; var root_564 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_566 lang.IFn; if



	linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__1); if linked_565 == nil { tmp7 = ifn_566.Invoke_O__O(arg_567) } else { tmp7 = linked_565.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_564, arg_567) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_repr_go_print_emit_A_const_19; var tmp10 any; var root_568 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_570 lang.IFn; if



	linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__1); if linked_569 == nil { tmp10 = ifn_570.Invoke_O__O(arg_571) } else { tmp10 = linked_569.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_568, arg_571) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_repr_go_print_emit_A_const_21; var tmp13 any; var root_572 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_574 lang.IFn; if



	linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__1); if linked_573 == nil { tmp13 = ifn_574.Invoke_O__O(arg_575) } else { tmp13 = linked_573.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_572, arg_575) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_print_emit_A_const_22; var tmp16 any; var root_576 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_578 lang.IFn; if



	linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__1); if linked_577 == nil { tmp16 = ifn_578.Invoke_O__O(arg_579) } else { tmp16 = linked_577.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_576, arg_579) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_repr_go_print_emit_A_const_23; var tmp19 any; var root_580 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_582 lang.IFn; if



	linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__1); if linked_581 == nil { tmp19 = ifn_582.Invoke_O__O(arg_583) } else { tmp19 = linked_581.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_580, arg_583) }; var tmp20 any = tmp19; var tmp21 any = A_arbace_repr_go_print_emit_A_const_24; var tmp22 any; var root_584 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_586 lang.IFn; if



	linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__1); if linked_585 == nil { tmp22 = ifn_586.Invoke_O__O(arg_587) } else { tmp22 = linked_585.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_584, arg_587) }; var tmp23 any = tmp22; var tmp24 any = A_arbace_repr_go_print_emit_A_const_25; var tmp25 any; var root_588 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_590 lang.IFn; if



	linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_repr_go_print_emit_A_const_25.Invoke_O__O(p__1); if linked_589 == nil { tmp25 = ifn_590.Invoke_O__O(arg_591) } else { tmp25 = linked_589.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_588, arg_591) }; var tmp26 any = tmp25; var tmp27 any = A_arbace_repr_go_print_emit_A_const_26; var tmp28 any; var root_592 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_594 lang.IFn; if



	linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = A_arbace_repr_go_print_emit_A_const_26.Invoke_O__O(p__1); if linked_593 == nil { tmp28 = ifn_594.Invoke_O__O(arg_595) } else { tmp28 = linked_593.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_592, arg_595) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_repr_go_print_emit_A_const_27; var tmp31 any; var root_596 any = /*line :256:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_598 lang.IFn; if



	linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(p__1); if linked_597 == nil { tmp31 = ifn_598.Invoke_O__O(arg_599) } else { tmp31 = linked_597.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_596, arg_599) }; return /*line :256:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp23, tmp24, tmp26, tmp27, tmp29, tmp30, tmp31)) }









func A_arbace_repr_go_print_emit_join_BANG__A_New() *A_arbace_repr_go_print_emit_join_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_join_BANG__A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Ctor() {}
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var l__4 int64 = lang.RT_LongCast_O__J_NoInit(l__1); var tmp1 any; var and__1927000168__auto____5 any; var root_600 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_602 lang.IFn; if





	linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3); if linked_601 == nil { and__1927000168__auto____5 = ifn_602.Invoke_O__O(arg_603) } else { and__1927000168__auto____5 = linked_601.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_600, arg_603) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp2 any; var root_604 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3); if linked_605 == nil { tmp2 = ifn_606.Invoke_O__O(arg_607) } else { tmp2 = linked_605.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_604, arg_607) }; and__1927000168__auto____6 = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp2), l__4); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp3 any; var root_608 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3); if linked_609 == nil { tmp3 = ifn_610.Invoke_O__O(arg_611) } else { tmp3 = linked_609.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_608, arg_611) }; and__1927000168__auto____7 = lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp3)); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp4 any; var root_612 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__3); if linked_613 == nil { tmp4 = ifn_614.Invoke_O__O(arg_615) } else { tmp4 = linked_613.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_612, arg_615) }; and__1927000168__auto____8 = lang.Util_Identical_O_O__Z_NoInit(tmp4, nil); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_616 any = A_arbace_repr_go_print_emit_A_const_93.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_618 lang.IFn
		if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_620 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = A_arbace_repr_go_print_emit_A_const_25.Invoke_O__O(p__3); if linked_621 == nil { arg_619 = ifn_622.Invoke_O__O(arg_623) } else { arg_619 = linked_621.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_620, arg_623) }; if linked_617 == nil { and__1927000168__auto____9 = ifn_618.Invoke_O__O(arg_619) } else { and__1927000168__auto____9 = linked_617.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_616, arg_619) }
//line :272:1
		if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp5 any; var root_624 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_626 lang.IFn
			if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = A_arbace_repr_go_print_emit_A_const_26.Invoke_O__O(p__3); if linked_625 == nil { tmp5 = ifn_626.Invoke_O__O(arg_627) } else { tmp5 = linked_625.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_624, arg_627) }; and__1927000168__auto____10 = lang.Numbers_Lt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp5), l__4)
//line :272:1
			if and__1927000168__auto____10 {
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(c__0)), l__4)).Ref() } else {
//line :272:1
					tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {

						jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3))).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_92.Invoke_O__O(c__0)))
						var root_628 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3); var arg_632 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(c__0); if linked_629 == nil { ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { linked_629.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }
						var root_633 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3); var arg_637 any = A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(c__0); if linked_634 == nil { ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { linked_634.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }
						var root_638 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3); var arg_642 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(c__0); if linked_639 == nil { ifn_640.Invoke_O_O__O(arg_641, arg_642) } else { linked_639.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_638, arg_641, arg_642) }
						var root_643 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__3); var arg_647 any = A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(c__0); if linked_644 == nil { ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { linked_644.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }
						var root_648 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3); var arg_652 any = A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(c__0); if linked_649 == nil { ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { linked_649.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_648, arg_651, arg_652) }
						var root_653 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3); var arg_657 any = A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(c__0); if linked_654 == nil { ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { linked_654.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_653, arg_656, arg_657) }
						var root_658 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__3); var arg_662 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(c__0); if linked_659 == nil { ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { linked_659.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }
						var root_663 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = A_arbace_repr_go_print_emit_A_const_25.Invoke_O__O(p__3); var arg_667 any = A_arbace_repr_go_print_emit_A_const_25.Invoke_O__O(c__0); if linked_664 == nil { ifn_665.Invoke_O_O__O(arg_666, arg_667) } else { linked_664.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_663, arg_666, arg_667) }
						jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_26.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Max_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_26.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_26.Invoke_O__O(c__0))))
						jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Min_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(c__0))))
//line :272:1
						return jrt.Boolean_TRUE.Ref() } else { return jrt.Boolean_FALSE.Ref() } }















func A_arbace_repr_go_print_emit_line_directive_inline_A_New() *A_arbace_repr_go_print_emit_line_directive_inline_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_inline_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Ctor() {}
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Invoke_O_O__O(self, n__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2); var root_672 any = A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class); var ifn_674 lang.IFn; if



	linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; if linked_673 == nil { ifn_674.Invoke__O() } else { linked_673.(*A_arbace_repr_go_print_emit_start_line_BANG__A).Invoke_O__O(root_672) }; var temp__1927000414__auto____4 any; var root_675 any = /*line :288:1*/A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_677 lang.IFn; if




	linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); if linked_676 == nil { temp__1927000414__auto____4 = ifn_677.Invoke_O__O(arg_678) } else { temp__1927000414__auto____4 = linked_676.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var ws__5 any = temp__1927000414__auto____4; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(ws__5)) };
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil))); var root_679 any =
	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(p__2); var arg_683 any; if linked_680 == nil { ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { linked_680.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; var root_668 any =
	A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = n__0; if linked_669 == nil { return ifn_670.Invoke_O__O(arg_671) } else { return linked_669.(*A_arbace_repr_go_print_emit_set_line_BANG__A).Invoke_O_O__O(root_668, arg_671) } }

func A_arbace_repr_go_print_emit_line_directive_own_A_New() *A_arbace_repr_go_print_emit_line_directive_own_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_own_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Ctor() {}
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Invoke_O_O__O(self, n__0 any) any { var ind__2 any; var root_684 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_686 lang.IFn; if


	linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var arg_687 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_685 == nil { ind__2 = ifn_686.Invoke_O__O(arg_687) } else { ind__2 = linked_685.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_684, arg_687) }; var root_692 any =
	A_arbace_repr_go_print_emit_A_const_95.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var arg_696 any = ind__2; if linked_693 == nil { ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { linked_693.(*A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; var root_688 any =
	A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = n__0; if linked_689 == nil { return ifn_690.Invoke_O__O(arg_691) } else { return linked_689.(*A_arbace_repr_go_print_emit_set_line_BANG__A).Invoke_O_O__O(root_688, arg_691) } }




func A_arbace_repr_go_print_emit_render_A_New() *A_arbace_repr_go_print_emit_render_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_render_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Ctor() {}
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Invoke_O_O__O(self, f__0 any) any {



	var root_700 any = A_arbace_repr_go_print_emit_A_const_97.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_98.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_A_const_31; var tmp3 any; var root_711 any = A_arbace_repr_go_print_emit_A_const_99.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = A_arbace_repr_go_print_emit_A_const_100; if linked_712 == nil { tmp3 = ifn_713.Invoke_O__O(arg_714) } else { tmp3 = linked_712.(*A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_711, arg_714) }; arg_703 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, A_arbace_repr_go_print_emit_A_const_52, nil); if linked_701 == nil { ifn_702.Invoke_O__O(arg_703) } else { linked_701.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_700, arg_703) }
//line :308:1
	var tmp4 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		lang.IFn_Cast(f__0).Invoke__O()
		{ var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; tmp4 = jrt.NN(jrt.StringBuilder_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref() }
//line :308:1
		return nil }(); var root_697 any = A_arbace_repr_go_print_emit_A_const_96.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_699 lang.IFn



	if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; if linked_698 == nil { ifn_699.Invoke__O() } else { linked_698.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_697) }
//line :308:1
	if tmp6 != nil { panic(tmp6) }; return tmp4
}







func A_arbace_repr_go_print_emit_break_to_BANG__A_New() *A_arbace_repr_go_print_emit_break_to_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_break_to_BANG__A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Invoke_O_O__O(self, t__0 any) any {



	{ var tmp1 any; var and__1927000168__auto____2 any = t__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_715 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var arg_718 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_716 == nil { tmp1 = ifn_717.Invoke_O__O(arg_718) } else { tmp1 = linked_716.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_715, arg_718) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_26; var mark__2 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var brk_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_repr_go_print_emit_A_const_101); var t__4 any





		if brk_QMARK___3 { var tmp4 any; var root_719 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_722 any = tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_720 == nil { tmp4 = ifn_721.Invoke_O__O(arg_722) } else { tmp4 = linked_720.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_719, arg_722) }; if jrt.J2g_Truth(tmp4) { var root_723 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_726 any = tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_724 == nil { t__4 = ifn_725.Invoke_O__O(arg_726) } else { t__4 = linked_724.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_723, arg_726) } } else { var tmp7 any; var root_727 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = mark__2; if linked_728 == nil { tmp7 = ifn_729.Invoke_O__O(arg_730) } else { tmp7 = linked_728.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_727, arg_730) }; var tmp8 int64 = lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(tmp7)); var tmp9 any; var root_731 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_734 any = tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_732 == nil { tmp9 = ifn_733.Invoke_O__O(arg_734) } else { tmp9 = linked_732.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_731, arg_734) }; t__4 = lang.Numbers_Max_J_O__O_NoInit(tmp8, tmp9) } } else { t__4 = t__0 }
		jrt.NN(lang.Volatile_Cast(mark__2)).Reset_O__O(lang.Numbers_Max_O_O__O_NoInit(jrt.NN(lang.Volatile_Cast(mark__2)).Deref__O(), t__4))
		var tmp11 bool; var na_735 any = t__4; var na_736 any; var root_737 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_739 lang.IFn
		if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_740 any = tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_738 == nil { na_736 = ifn_739.Invoke_O__O(arg_740) } else { na_736 = linked_738.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_737, arg_740) }; var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(na_735); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_736) }; tmp13 = tmp14; if tmp13 { var n0_741 int64 = jrt.NN(jrt.Long_Cast(na_735)).LongValue__J(); var n1_742 int64 = jrt.NN(jrt.Long_Cast(na_736)).LongValue__J(); tmp11 = n0_741 > n1_742 } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_735); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_736) }; tmp15 = tmp16; if tmp15 { var n0_741_2 float64 = jrt.NN(jrt.Double_Cast(na_735)).DoubleValue__D(); var n1_742_2 float64 = jrt.NN(jrt.Double_Cast(na_736)).DoubleValue__D(); tmp11 = n1_742_2 < n0_741_2 } else { tmp11 = lang.Numbers_Gt_O_O__Z_NoInit(na_735, na_736) } }
//line :329:1
		if tmp11 {

			var tmp17 any; var and__1927000168__auto____5 any; var root_744 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var tmp18 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; var arg_747 any = tmp18.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_745 == nil { and__1927000168__auto____5 = ifn_746.Invoke_O__O(arg_747) } else { and__1927000168__auto____5 = linked_745.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_744, arg_747) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_748 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var root_752 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var tmp19 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_755 any = tmp19.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_753 == nil { arg_751 = ifn_754.Invoke_O__O(arg_755) } else { arg_751 = linked_753.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_752, arg_755) }; if linked_749 == nil { tmp17 = ifn_750.Invoke_O__O(arg_751) } else { tmp17 = linked_749.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_748, arg_751) } } else { tmp17 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp17) {
				var tmp20 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_29; if jrt.J2g_Truth(tmp20.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var root_756 any = A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = t__4; if linked_757 == nil { return ifn_758.Invoke_O__O(arg_759) } else { return linked_757.(*A_arbace_repr_go_print_emit_line_directive_inline_A).Invoke_O_O__O(root_756, arg_759) } } else { return nil } } else {
//line :331:1
					var ci__5 any; var root_760 any = A_arbace_repr_go_print_emit_A_const_103.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, A_arbace_repr_go_print_emit_cont_indent_A_fn_class); var ifn_762 lang.IFn

					if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; if linked_761 == nil { ci__5 = ifn_762.Invoke__O() } else { ci__5 = linked_761.(*A_arbace_repr_go_print_emit_cont_indent_A).Invoke_O__O(root_760) }
//line :331:1
				L1: for {


					var tmp21 bool; var na_763 any; var root_765 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var tmp22 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_768 any = tmp22.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_766 == nil { na_763 = ifn_767.Invoke_O__O(arg_768) } else { na_763 = linked_766.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_765, arg_768) }; var na_764 any = t__4; var tmp23 bool; var tmp24 bool; tmp24 = jrt.Long_InstanceOf(na_763); if tmp24 { tmp24 = jrt.Long_InstanceOf(na_764) }; tmp23 = tmp24; if tmp23 { var n0_769 int64 = jrt.NN(jrt.Long_Cast(na_763)).LongValue__J(); var n1_770 int64 = jrt.NN(jrt.Long_Cast(na_764)).LongValue__J(); tmp21 = n0_769 < n1_770 } else { var tmp25 bool; var tmp26 bool; tmp26 = jrt.Double_InstanceOf(na_763); if tmp26 { tmp26 = jrt.Double_InstanceOf(na_764) }; tmp25 = tmp26; if tmp25 { var n0_769_2 float64 = jrt.NN(jrt.Double_Cast(na_763)).DoubleValue__D(); var n1_770_2 float64 = jrt.NN(jrt.Double_Cast(na_764)).DoubleValue__D(); tmp21 = n0_769_2 < n1_770_2 } else { tmp21 = lang.Numbers_Lt_O_O__Z_NoInit(na_763, na_764) } }; if tmp21 { var root_785 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = ci__5; if linked_786 == nil { ifn_787.Invoke_O__O(arg_788) } else { linked_786.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_785, arg_788) }; continue L1 } else { return nil } } } } else {
//line :329:1
						var tmp27 any; var and__1927000168__auto____5_2 bool; var na_772 any = t__4; var na_773 any; var root_774 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_776 lang.IFn





						if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var tmp28 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_777 any = tmp28.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_775 == nil { na_773 = ifn_776.Invoke_O__O(arg_777) } else { na_773 = linked_775.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_774, arg_777) }; var tmp29 bool; var tmp30 bool; tmp30 = jrt.Long_InstanceOf(na_772); if tmp30 { tmp30 = jrt.Long_InstanceOf(na_773) }; tmp29 = tmp30; if tmp29 { var n0_778 int64 = jrt.NN(jrt.Long_Cast(na_772)).LongValue__J(); var n1_779 int64 = jrt.NN(jrt.Long_Cast(na_773)).LongValue__J(); and__1927000168__auto____5_2 = n0_778 < n1_779 } else { var tmp31 bool; var tmp32 bool; tmp32 = jrt.Double_InstanceOf(na_772); if tmp32 { tmp32 = jrt.Double_InstanceOf(na_773) }; tmp31 = tmp32; if tmp31 { var n0_778_2 float64 = jrt.NN(jrt.Double_Cast(na_772)).DoubleValue__D(); var n1_779_2 float64 = jrt.NN(jrt.Double_Cast(na_773)).DoubleValue__D(); and__1927000168__auto____5_2 = n0_778_2 < n1_779_2 } else { and__1927000168__auto____5_2 = lang.Numbers_Lt_O_O__Z_NoInit(na_772, na_773) } }; if and__1927000168__auto____5_2 { var tmp33 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_29; tmp27 = tmp33.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) } else { tmp27 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }
//line :329:1
						if jrt.J2g_Truth(tmp27) {






							var root_781 any = A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = t__4; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*A_arbace_repr_go_print_emit_line_directive_inline_A).Invoke_O_O__O(root_781, arg_784) } } else {
//line :329:1
								return nil } } } else {
//line :321:1
									return nil } }
//line :317:1
	panic("j2g: unreachable")
}



















func A_arbace_repr_go_print_emit_stmt_break_BANG__A_New() *A_arbace_repr_go_print_emit_stmt_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Ctor() {}
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Invoke_O_O_O_O_O__O(self, t__0, first_QMARK___1, sep__2, indent__3 any) any { var newline_BANG___5 any; var tmp1 any = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(indent__3); var tmp2 *jrt.Class; var fncls__797 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class; if





	fncls__797 == nil { var fncls__797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class = fncls__797d; tmp2 = fncls__797d } else { tmp2 = fncls__797 }; newline_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var same_BANG___6 any; var tmp3 any = /*line :338:1*/A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(first_QMARK___1, sep__2); var tmp4 *jrt.Class; var fncls__808 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class; if






	fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class = fncls__808d; tmp4 = fncls__808d } else { tmp4 = fncls__808 }; same_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any; var root_834 any =
	A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = t__0; if linked_835 == nil { tmp5 = ifn_836.Invoke_O__O(arg_837) } else { tmp5 = linked_835.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_834, arg_837) }; if jrt.J2g_Truth(tmp5) { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_26; var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_26; jrt.NN(lang.Volatile_Cast(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Max_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J_NoInit(t__0))) }; var tmp8 /*line :347:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp9 any; var and__1927000168__auto____7 any = sep__2; if jrt.J2g_Truth(and__1927000168__auto____7) { var root_838 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = first_QMARK___1; if linked_839 == nil { tmp9 = ifn_840.Invoke_O__O(arg_841) } else { tmp9 = linked_839.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_838, arg_841) } } else { tmp9 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp9) { var root_842 any = A_arbace_repr_go_print_emit_A_const_106.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = A_arbace_repr_go_print_emit_A_const_107; var arg_846 any = sep__2; if linked_843 == nil { ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { linked_843.(*A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) } }; var root_847 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var arg_850 any = tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_851 any = A_arbace_repr_go_print_emit_A_const_79; if linked_848 == nil { ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { linked_848.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }
//line :347:1
		return jrt.Boolean_FALSE.Ref() } else { var tmp11 any; var root_809 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_811 lang.IFn

			if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_18; var arg_812 any = tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_810 == nil { tmp11 = ifn_811.Invoke_O__O(arg_812) } else { tmp11 = linked_810.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_809, arg_812) }
//line :347:1
			if jrt.J2g_Truth(tmp11) {

				var root_852 any = A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var tmp13 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var arg_855 any = tmp13.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var arg_856 any = indent__3; if linked_853 == nil { ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { linked_853.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }
//line :347:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp14 any; var root_813 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_815 lang.IFn


					if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var tmp15 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; var arg_816 any = tmp15.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_814 == nil { tmp14 = ifn_815.Invoke_O__O(arg_816) } else { tmp14 = linked_814.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_813, arg_816) }
//line :347:1
					if jrt.J2g_Truth(tmp14) {


						return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17) } else {
//line :347:1
							if lang.Util_Identical_O_O__Z_NoInit(t__0, nil) {



								var tmp16 any; var root_817 any = A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, A_arbace_repr_go_print_emit_room_QMARK__A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = A_arbace_repr_go_print_emit_A_const_17; if linked_818 == nil { tmp16 = ifn_819.Invoke_O__O(arg_820) } else { tmp16 = linked_818.(*A_arbace_repr_go_print_emit_room_QMARK__A).Invoke_O_O__O(root_817, arg_820) }; if jrt.J2g_Truth(tmp16) { return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17) } else { return lang.IFn_Cast(same_BANG___6).Invoke__O() } } else {
//line :347:1
									if lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_repr_go_print_emit_A_const_101) {




										return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17) } else {
//line :347:1
											var tmp17 bool; var na_821 int64 = lang.RT_LongCast_O__J_NoInit(t__0); var na_822 any; var root_823 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_825 lang.IFn





											if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var tmp18 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_826 any = tmp18.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_824 == nil { na_822 = ifn_825.Invoke_O__O(arg_826) } else { na_822 = linked_824.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_823, arg_826) }; if jrt.Long_InstanceOf(na_822) { var n0_827 int64 = na_821; var n1_828 int64 = jrt.NN(jrt.Long_Cast(na_822)).LongValue__J(); tmp17 = n0_827 > n1_828 } else { tmp17 = lang.Numbers_Gt_J_O__Z_NoInit(na_821, na_822) }
//line :347:1
											if tmp17 {





												var tmp19 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp20 jrt.Number_I; var na_857 int64 = lang.RT_LongCast_O__J_NoInit(t__0); var na_858 any; var root_859 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var tmp21 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_862 any = tmp21.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_860 == nil { na_858 = ifn_861.Invoke_O__O(arg_862) } else { na_858 = linked_860.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_859, arg_862) }; if jrt.Long_InstanceOf(na_858) { var n0_863 int64 = na_857; var n1_864 int64 = jrt.NN(jrt.Long_Cast(na_858)).LongValue__J(); var nr_865 int64 = n0_863 - n1_864; var tmp22 bool; var tmp23 bool; tmp23 = !(n1_864 == -9223372036854775808); if tmp23 { tmp23 = (n0_863^n1_864)&(n0_863^nr_865) >= 0 }; tmp22 = tmp23; if tmp22 { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_865)) } else { tmp20 = lang.Numbers_Minus_J_O__Number_NoInit(na_857, na_858) } } else { tmp20 = lang.Numbers_Minus_J_O__Number_NoInit(na_857, na_858) }; return tmp19.Invoke_O__O(tmp20) } else {
//line :347:1
													var tmp24 int64 = lang.RT_LongCast_O__J_NoInit(t__0); var tmp25 any; var root_830 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_832 lang.IFn






													if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var tmp26 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_833 any = tmp26.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_831 == nil { tmp25 = ifn_832.Invoke_O__O(arg_833) } else { tmp25 = linked_831.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_830, arg_833) }
//line :347:1
													if lang.Util_Equiv_J_O__Z_NoInit(tmp24, tmp25) {






														return lang.IFn_Cast(same_BANG___6).Invoke__O() } else {
//line :347:1
															if A_arbace_repr_go_print_emit_A_const_55 != nil {







																lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17)
																var tmp27 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_29; if jrt.J2g_Truth(tmp27.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var root_866 any = A_arbace_repr_go_print_emit_A_const_108.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_repr_go_print_emit_line_directive_own_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = t__0; if linked_867 == nil { ifn_868.Invoke_O__O(arg_869) } else { linked_867.(*A_arbace_repr_go_print_emit_line_directive_own_A).Invoke_O_O__O(root_866, arg_869) } }
//line :347:1
																return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } } } } }
//line :344:1
func A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(p0 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Ctor_O(c__indent any) { t.F_indent = c__indent }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Invoke_O_O__O(self, n__1 any) any { var n__1927000701__auto____2 int64 = lang.RT_LongCast_O__J_NoInit(lang.Numbers_Max_J_O__O_NoInit(1, n__1)); var ___3 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(___3, n__1927000701__auto____2) { var root_793 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = t.F_indent; if linked_794 == nil { ifn_795.Invoke_O__O(arg_796) } else { linked_794.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_793, arg_796) }; ___3 = lang.Numbers_Unchecked_inc_J__J_NoInit(___3); continue L1 }; break L1 }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_26; var tmp2 *lang.Volatile = lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_26; var tmp4 any = jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); var tmp5 any; var root_789 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_792 any = tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_790 == nil { tmp5 = ifn_791.Invoke_O__O(arg_792) } else { tmp5 = linked_790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_789, arg_792) }; jrt.NN(tmp2).Reset_O__O(lang.Numbers_Max_O_O__O_NoInit(tmp4, tmp5)); return jrt.Boolean_TRUE.Ref() }
func A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A{}; t.Ctor_O_O(p0, p1); return t }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Ctor_O_O(c__first_QMARK_, c__sep any) { t.F_first_QMARK_ = c__first_QMARK_; t.F_sep = c__sep }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Invoke_O__O(self any) any { if jrt.J2g_Truth(t.F_first_QMARK_) { var root_798 any = A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; if linked_799 == nil { ifn_800.Invoke__O() } else { linked_799.(*A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_798) } } else { if jrt.J2g_Truth(t.F_sep) { var root_804 any = A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = t.F_sep; if linked_805 == nil { ifn_806.Invoke_O__O(arg_807) } else { linked_805.(*A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_804, arg_807) } }; var root_801 any = A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; if linked_802 == nil { ifn_803.Invoke__O() } else { linked_802.(*A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_801) } }; return jrt.Boolean_FALSE.Ref() }













func A_arbace_repr_go_print_emit_close_break_BANG__A_New() *A_arbace_repr_go_print_emit_close_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_close_break_BANG__A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Ctor() {}
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Invoke_O_O_O_O_O__O(self, end__0, multiline_QMARK___1, always_QMARK___2, indent__3 any) any {





	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; var and__1927000168__auto____5 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())

		if jrt.J2g_Truth(and__1927000168__auto____5) { var root_870 any = A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = end__0; if linked_871 == nil { tmp2 = ifn_872.Invoke_O__O(arg_873) } else { tmp2 = linked_871.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_870, arg_873) } } else { tmp2 = and__1927000168__auto____5 }
//line :365:1
		if jrt.J2g_Truth(tmp2) {


			var tmp4 bool; var na_874 int64 = lang.RT_LongCast_O__J_NoInit(end__0); var na_875 any; var root_876 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_878 lang.IFn
			if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_879 any = tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_877 == nil { na_875 = ifn_878.Invoke_O__O(arg_879) } else { na_875 = linked_877.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_876, arg_879) }; if jrt.Long_InstanceOf(na_875) { var n0_880 int64 = na_874; var n1_881 int64 = jrt.NN(jrt.Long_Cast(na_875)).LongValue__J(); tmp4 = n0_880 > n1_881 } else { tmp4 = lang.Numbers_Gt_J_O__Z_NoInit(na_874, na_875) }
//line :368:1
			if tmp4 { L1: for {
				var tmp6 bool; var na_891 any; var root_893 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_896 any = tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_894 == nil { na_891 = ifn_895.Invoke_O__O(arg_896) } else { na_891 = linked_894.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_893, arg_896) }; var na_892 int64 = lang.RT_LongCast_O__J_NoInit(end__0); if jrt.Long_InstanceOf(na_891) { var n0_897 int64 = jrt.NN(jrt.Long_Cast(na_891)).LongValue__J(); var n1_898 int64 = na_892; tmp6 = n0_897 < n1_898 } else { tmp6 = lang.Numbers_Lt_O_J__Z_NoInit(na_891, na_892) }; if tmp6 { var root_900 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = indent__3; if linked_901 == nil { ifn_902.Invoke_O__O(arg_903) } else { linked_901.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_900, arg_903) }; continue L1 }
//line :368:1
				break L1 }; return jrt.Boolean_TRUE.Ref() } else { var tmp8 int64 = lang.RT_LongCast_O__J_NoInit(end__0); var tmp9 any; var root_883 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_885 lang.IFn

					if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var arg_886 any = tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if linked_884 == nil { tmp9 = ifn_885.Invoke_O__O(arg_886) } else { tmp9 = linked_884.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_883, arg_886) }
//line :368:1
					if lang.Util_Equiv_J_O__Z_NoInit(tmp8, tmp9) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil {


						var tmp11 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_29; if jrt.J2g_Truth(tmp11.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var root_904 any = A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = end__0; if linked_905 == nil { ifn_906.Invoke_O__O(arg_907) } else { linked_905.(*A_arbace_repr_go_print_emit_line_directive_inline_A).Invoke_O_O__O(root_904, arg_907) } }
//line :368:1
						return jrt.Boolean_FALSE.Ref() } else { return nil } } } } else {
//line :365:1
							var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_28; if jrt.J2g_Truth(tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {






								var tmp13 any; var and__1927000168__auto____5_2 any; var or__1927000174__auto____5 any = multiline_QMARK___1; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5_2 = or__1927000174__auto____5 } else { and__1927000168__auto____5_2 = always_QMARK___2 }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { var root_887 any = A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, A_arbace_repr_go_print_emit_room_QMARK__A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = A_arbace_repr_go_print_emit_A_const_17; if linked_888 == nil { tmp13 = ifn_889.Invoke_O__O(arg_890) } else { tmp13 = linked_888.(*A_arbace_repr_go_print_emit_room_QMARK__A).Invoke_O_O__O(root_887, arg_890) } } else { tmp13 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp13) { var root_908 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = indent__3; if linked_909 == nil { ifn_910.Invoke_O__O(arg_911) } else { linked_909.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_908, arg_911) }; return jrt.Boolean_TRUE.Ref() } else { return jrt.Boolean_FALSE.Ref() } } else {
//line :365:1
									if jrt.J2g_Truth(always_QMARK___2) {







										var root_912 any = A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = indent__3; if linked_913 == nil { ifn_914.Invoke_O__O(arg_915) } else { linked_913.(*A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_912, arg_915) }
//line :365:1
										return jrt.Boolean_TRUE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
										}
										}
								}
						}
	}
}






func A_arbace_repr_go_print_emit_result_A_New() *A_arbace_repr_go_print_emit_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_result_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Ctor() {}
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var root_916 any = A_arbace_repr_go_print_emit_A_const_109.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, A_arbace_repr_go_print_emit_full_result_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; if linked_917 == nil { return ifn_918.Invoke__O() } else { return linked_917.(*A_arbace_repr_go_print_emit_full_result_A).Invoke_O__O(root_916) } } else {
//line :381:1
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; var s__1 any = jrt.NN(jrt.StringBuilder_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref(); var s__2 any; var root_919 any = A_arbace_repr_go_print_emit_A_const_110.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_921 lang.IFn


			if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__1; var arg_923 any = A_arbace_repr_go_print_emit_A_const_111; var arg_924 any = Lit_3; if linked_920 == nil { s__2 = ifn_921.Invoke_O_O_O__O(arg_922, arg_923, arg_924) } else { s__2 = linked_920.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_919, arg_922, arg_923, arg_924) }
			var root_925 any = A_arbace_repr_go_print_emit_A_const_112.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_align_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any; var tmp3 any; var root_929 any = A_arbace_repr_go_print_emit_A_const_113.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = s__2; var arg_933 any = Lit_3; if linked_930 == nil { tmp3 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { tmp3 = linked_930.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; if jrt.J2g_Truth(tmp3) { arg_928 = s__2 } else { arg_928 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() }; if linked_926 == nil { return ifn_927.Invoke_O__O(arg_928) } else { return linked_926.(*aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_align_A).Invoke_O_O__O(root_925, arg_928)
			}
		}
}











func A_arbace_repr_go_print_emit_utf8_len_A_New() *A_arbace_repr_go_print_emit_utf8_len_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_utf8_len_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Ctor() {}
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) InvokePrim_O_O__J(self, s__0 any) int64 { return int64(lang.RT_Alength_B1__I_NoInit(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))) }
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, s__0)).Ref() }


func A_arbace_repr_go_print_emit_end_of_A_New() *A_arbace_repr_go_print_emit_end_of_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Ctor() {}
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Invoke_O_O_O__O(self, p__308000116__0, s__1 any) any { var vec__308000117__3 any = p__308000116__0; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000117__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000117__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(s__1)).LastIndexOf_String__I(Lit_3); if



	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)) { var tmp1 int64 = lang.RT_LongCast_O__J_NoInit(c__5); var tmp2 int64; var root_934 any = A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_934, A_arbace_repr_go_print_emit_utf8_len_A_fn_class); var ifn_936 lang.IFn
		if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = s__1; if linked_935 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_936.Invoke_O__O(arg_937)) } else { tmp2 = linked_935.(*A_arbace_repr_go_print_emit_utf8_len_A).InvokePrim_O_O__J(root_934, arg_937) }
//line :407:1
		return lang.Tuple_Create_O_O__IPersistentVector(l__4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp1, tmp2)).Ref()) } else { var tmp3 int64 = lang.RT_LongCast_O__J_NoInit(l__4); var tmp4 any; var root_938 any = A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_940 lang.IFn

			if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var tmp5 any = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New(); var tmp6 *jrt.Class; var fncls__943 *jrt.Class = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class; if fncls__943 == nil { var fncls__943d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class = fncls__943d; tmp6 = fncls__943d } else { tmp6 = fncls__943 }; arg_941 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_942 any = s__1; if linked_939 == nil { tmp4 = ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { tmp4 = linked_939.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) }
//line :407:1
			var tmp7 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp3, int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); var tmp8 int64; var root_944 any = A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_944, A_arbace_repr_go_print_emit_utf8_len_A_fn_class); var ifn_946 lang.IFn

			if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any; var root_948 any = A_arbace_repr_go_print_emit_A_const_115.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__1; var arg_952 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__6))).Ref(); if linked_949 == nil { arg_947 = ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { arg_947 = linked_949.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_948, arg_951, arg_952) }; if linked_945 == nil { tmp8 = lang.RT_LongCast_O__J_NoInit(ifn_946.Invoke_O__O(arg_947)) } else { tmp8 = linked_945.(*A_arbace_repr_go_print_emit_utf8_len_A).InvokePrim_O_O__J(root_944, arg_947) }
//line :407:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(tmp8)).Ref()) } }

func A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New() *A_arbace_repr_go_print_emit_end_of_fn__308000120_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_fn__308000120_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Ctor() {}
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Invoke_O_O__O(self, p1__308000115_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__308000115_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }



func A_arbace_repr_go_print_emit_line_comment_QMARK__A_New() *A_arbace_repr_go_print_emit_line_comment_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_comment_QMARK__A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Ctor() {}
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Invoke_O_O__O(self, it__0 any) any { var and__1927000168__auto____2 any = A_arbace_repr_go_print_emit_A_const_116.Invoke_O__O(it__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var root_953 any = A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__0); var arg_957 any = Lit_23; if linked_954 == nil { return ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { return linked_954.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_953, arg_956, arg_957) } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_emit_place_run_A_New() *A_arbace_repr_go_print_emit_place_run_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Ctor() {}
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Invoke_O_O_O_O_O__O(self, run__0, cur__1, prev_item__2, nxt__3 any) any { { var vec__308000127__5 any = cur__1; var cl__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000127__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000127__5, lang.RT_IntCast_J__I_NoInit(1), nil); var n__8 int32 = lang.RT_Count_O__I_NoInit(run__0); var lens__9 any; var root_958 any = A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_960 lang.IFn





	if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var tmp1 any = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New(); var tmp2 *jrt.Class; var fncls__967 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class; if fncls__967 == nil { var fncls__967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class = fncls__967d; tmp2 = fncls__967d } else { tmp2 = fncls__967 }; arg_961 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_962 any = run__0; if linked_959 == nil { lens__9 = ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { lens__9 = linked_959.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) }
//line :415:1
	var natural__10 any; var tmp3 any = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(cl__6, n__8, run__0, lens__9, cc__7); var tmp4 *jrt.Class
	var fncls__973 /*line :415:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class






	if fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class = fncls__973d; tmp4 = fncls__973d } else { tmp4 = fncls__973 }; natural__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)





	var tmp5 any; var and__1927000168__auto____11 any; var root_974 any = A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class); var ifn_976 lang.IFn

	if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = prev_item__2; if linked_975 == nil { and__1927000168__auto____11 = ifn_976.Invoke_O__O(arg_977) } else { and__1927000168__auto____11 = linked_975.(*A_arbace_repr_go_print_emit_line_comment_QMARK__A).Invoke_O_O__O(root_974, arg_977) }; if jrt.J2g_Truth(and__1927000168__auto____11) { tmp5 = nxt__3 } else { tmp5 = and__1927000168__auto____11 }
//line :428:1
	if jrt.J2g_Truth(tmp5) { var vec__308000134__11 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3); var nl__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000134__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ncol__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000134__11, lang.RT_IntCast_J__I_NoInit(1), nil); var i__14 int64 = lang.Numbers_Dec_J__J_NoInit(int64(n__8)); var c__15 int64; var tmp6 int64 = lang.RT_LongCast_O__J_NoInit(ncol__13); var tmp7 int64



		if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3)) { tmp7 = 1 } else { tmp7 = 0 }; c__15 = lang.Numbers_Minus_J_J__J_NoInit(tmp6, tmp7)
//line :428:1
		var acc__16 any = lang.PersistentList_EMPTY.Ref(); L1: for {




			if lang.Numbers_IsNeg_J__Z_NoInit(i__14) {
				var root_978 any = A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = acc__16; if linked_979 == nil { return ifn_980.Invoke_O__O(arg_981) } else { return linked_979.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_978, arg_981) } } else {
//line :433:1
					var c__17 int64 = lang.Numbers_Minus_J_J__J_NoInit(c__15, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lens__9, lang.RT_IntCast_J__I_NoInit(i__14)))); var tmp8 int64 = lang.Numbers_Dec_J__J_NoInit(i__14); var tmp9 int64
					var tmp10 /*line :433:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_74


					if jrt.J2g_Truth(tmp10.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(run__0, lang.RT_IntCast_J__I_NoInit(i__14)))) { tmp9 = 1 } else { tmp9 = 0 }; var tmp11 int64 = lang.Numbers_Minus_J_J__J_NoInit(c__17, tmp9); var tmp12 any; var root_1117 any = A_arbace_repr_go_print_emit_A_const_130.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = lang.Tuple_Create_O_O__IPersistentVector(nl__12, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(1, c__17)).Ref()); var arg_1121 any = acc__16; if linked_1118 == nil { tmp12 = ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { tmp12 = linked_1118.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) }; i__14, c__15, acc__16 = tmp8, tmp11, tmp12; continue L1 } } } else {
//line :428:1
						var tmp13 any; var or__1927000174__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(nxt__3, nil)








						if or__1927000174__auto____11 { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var or__1927000174__auto____12 bool; var tmp14 any; var root_982 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3); if linked_983 == nil { tmp14 = ifn_984.Invoke_O__O(arg_985) } else { tmp14 = linked_983.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_982, arg_985) }; or__1927000174__auto____12 = lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp14), lang.RT_LongCast_O__J_NoInit(cl__6)); if or__1927000174__auto____12 { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { var root_986 any = A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = prev_item__2; if linked_987 == nil { tmp13 = ifn_988.Invoke_O__O(arg_989) } else { tmp13 = linked_987.(*A_arbace_repr_go_print_emit_line_comment_QMARK__A).Invoke_O_O__O(root_986, arg_989) } } }
//line :428:1
						if jrt.J2g_Truth(tmp13) {









							return lang.IFn_Cast(natural__10).Invoke__O() } else {
//line :428:1
								if A_arbace_repr_go_print_emit_A_const_55 != nil { var ncol__11 int64; var tmp15 any; var root_990 any = A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_992 lang.IFn











									if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3); if linked_991 == nil { tmp15 = ifn_992.Invoke_O__O(arg_993) } else { tmp15 = linked_991.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_990, arg_993) }; ncol__11 = lang.RT_LongCast_O__J_NoInit(tmp15)
//line :428:1
									var need__12 any; var na_994 int64 = lang.Numbers_Minus_J_J__J_NoInit(ncol__11, lang.RT_LongCast_O__J_NoInit(cc__7)); var na_995 any; var root_996 any = A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_998 lang.IFn












									if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O(); var arg_1000 any = lens__9; if linked_997 == nil { na_995 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { na_995 = linked_997.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }; if jrt.Long_InstanceOf(na_995) { var n0_1001 int64 = na_994; var n1_1002 int64 = jrt.NN(jrt.Long_Cast(na_995)).LongValue__J(); var nr_1003 int64 = n0_1001 - n1_1002; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_1002 == -9223372036854775808); if tmp17 { tmp17 = (n0_1001^n1_1002)&(n0_1001^nr_1003) >= 0 }; tmp16 = tmp17; if tmp16 { need__12 = jrt.Long_ValueOf_J__Long_NoInit(nr_1003).Ref() } else { need__12 = lang.Numbers_Minus_J_O__Number_NoInit(na_994, na_995) } } else { need__12 = lang.Numbers_Minus_J_O__Number_NoInit(na_994, na_995) }
//line :428:1
									var slots__13 any; var root_1004 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1006 lang.IFn













									if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var root_1009 any = A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = A_arbace_repr_go_print_emit_A_const_74; var arg_1013 any = run__0; if linked_1010 == nil { arg_1007 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { arg_1007 = linked_1010.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }; var arg_1008 any = A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3); if linked_1005 == nil { slots__13 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { slots__13 = linked_1005.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }
//line :428:1
									var nat__14 any; var root_1014 any = A_arbace_repr_go_print_emit_A_const_124.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_1016 lang.IFn














									if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any; var tmp18 any = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New(); var tmp19 *jrt.Class; var fncls__1019 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class; if fncls__1019 == nil { var fncls__1019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class = fncls__1019d; tmp19 = fncls__1019d } else { tmp19 = fncls__1019 }; arg_1017 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var arg_1018 any = slots__13; if linked_1015 == nil { nat__14 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { nat__14 = linked_1015.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }
//line :428:1
									var nnat__15 int32 = lang.RT_Count_O__I_NoInit(nat__14); var spaces__16 any; var tmp20 bool
									var na_1020 any = need__12
















									if jrt.Long_InstanceOf(na_1020) { var n0_1021 int64 = jrt.NN(jrt.Long_Cast(na_1020)).LongValue__J(); tmp20 = n0_1021 < 0 } else { if jrt.Double_InstanceOf(na_1020) { var n0_1021_2 float64 = jrt.NN(jrt.Double_Cast(na_1020)).DoubleValue__D(); tmp20 = n0_1021_2 < 0.0 } else { tmp20 = lang.Numbers_IsNeg_O__Z_NoInit(na_1020) } }
//line :445:1
									if tmp20 {
										var root_1022 any = A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var tmp21 any = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New(); var tmp22 *jrt.Class; var fncls__1027 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class; if fncls__1027 == nil { var fncls__1027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class = fncls__1027d; tmp22 = fncls__1027d } else { tmp22 = fncls__1027 }; arg_1025 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); var arg_1026 any = slots__13; if linked_1023 == nil { spaces__16 = ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { spaces__16 = linked_1023.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) } } else {
//line :445:1
											var tmp23 bool; var na_1028 any = need__12; var na_1029 int64 = int64(nnat__15)

											if jrt.Long_InstanceOf(na_1028) { var n0_1030 int64 = jrt.NN(jrt.Long_Cast(na_1028)).LongValue__J(); var n1_1031 int64 = na_1029; tmp23 = n0_1030 >= n1_1031 } else { tmp23 = lang.Numbers_Gte_O_J__Z_NoInit(na_1028, na_1029) }
//line :445:1
											if tmp23 { var extra__16 any; var na_1033 any = need__12; var na_1034 int64 = int64(nnat__15)


												if jrt.Long_InstanceOf(na_1033) { var n0_1035 int64 = jrt.NN(jrt.Long_Cast(na_1033)).LongValue__J(); var n1_1036 int64 = na_1034; var nr_1037 int64 = n0_1035 - n1_1036; var tmp24 bool; var tmp25 bool; tmp25 = !(n1_1036 == -9223372036854775808); if tmp25 { tmp25 = (n0_1035^n1_1036)&(n0_1035^nr_1037) >= 0 }; tmp24 = tmp25; if tmp24 { extra__16 = jrt.Long_ValueOf_J__Long_NoInit(nr_1037).Ref() } else { extra__16 = lang.Numbers_Minus_O_J__Number_NoInit(na_1033, na_1034) } } else { extra__16 = lang.Numbers_Minus_O_J__Number_NoInit(na_1033, na_1034) }
//line :445:1
												var base__17 any; var root_1038 any = A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1040 lang.IFn



												if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var tmp26 any = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New(); var tmp27 *jrt.Class; var fncls__1043 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class; if fncls__1043 == nil { var fncls__1043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class = fncls__1043d; tmp27 = fncls__1043d } else { tmp27 = fncls__1043 }; arg_1041 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_1042 any = slots__13; if linked_1039 == nil { base__17 = ifn_1040.Invoke_O_O__O(arg_1041, arg_1042) } else { base__17 = linked_1039.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1038, arg_1041, arg_1042) }
												var tmp28 bool; var na_1044 any = extra__16
												if jrt.Long_InstanceOf(na_1044) { var n0_1045 int64 = jrt.NN(jrt.Long_Cast(na_1044)).LongValue__J(); tmp28 = n0_1045 == 0 } else { if jrt.Double_InstanceOf(na_1044) { var n0_1045_2 float64 = jrt.NN(jrt.Double_Cast(na_1044)).DoubleValue__D(); tmp28 = n0_1045_2 == 0.0 } else { tmp28 = lang.Numbers_IsZero_O__Z_NoInit(na_1044) } }
//line :450:1
												if tmp28 { spaces__16 = base__17 } else { var tmp29 any; var root_1046 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1048 lang.IFn

													if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = nat__14; if linked_1047 == nil { tmp29 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp29 = linked_1047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1046, arg_1049) }
//line :450:1
													if jrt.J2g_Truth(tmp29) {

														var root_1050 any = A_arbace_repr_go_print_emit_A_const_125.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = base__17; var arg_1054 any; var root_1057 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = nat__14; if linked_1058 == nil { arg_1054 = ifn_1059.Invoke_O__O(arg_1060) } else { arg_1054 = linked_1058.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1057, arg_1060) }; var arg_1055 any = A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O(); var arg_1056 any = extra__16; if linked_1051 == nil { spaces__16 = ifn_1052.Invoke_O_O_O_O__O(arg_1053, arg_1054, arg_1055, arg_1056) } else { spaces__16 = linked_1051.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1050, arg_1053, arg_1054, arg_1055, arg_1056) } } else {
//line :450:1
															var tmp30 any; var and__1927000168__auto____18 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(n__8), 1)


															if and__1927000168__auto____18 { var and__1927000168__auto____19 any; var root_1061 any = A_arbace_repr_go_print_emit_A_const_126.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_even_QMARK__A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = extra__16; if linked_1062 == nil { and__1927000168__auto____19 = ifn_1063.Invoke_O__O(arg_1064) } else { and__1927000168__auto____19 = linked_1062.(*aot_arbace_core.A_arbace_core_even_QMARK__A).Invoke_O_O__O(root_1061, arg_1064) }; if jrt.J2g_Truth(and__1927000168__auto____19) { var tmp31 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_72; var tmp32 any; var root_1065 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = run__0; if linked_1066 == nil { tmp32 = ifn_1067.Invoke_O__O(arg_1068) } else { tmp32 = linked_1066.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1065, arg_1068) }; tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_37, tmp31.Invoke_O__O(tmp32))).Ref() } else { tmp30 = and__1927000168__auto____19 } } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____18).Ref() }
//line :450:1
															if jrt.J2g_Truth(tmp30) {



																var root_1069 any = A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any; var root_1075 any = A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = base__17; var arg_1079 any = A_arbace_repr_go_print_emit_A_const_20; var arg_1080 any; var na_1081 any = extra__16; var na_1082 int64 = 2; if jrt.Long_InstanceOf(na_1081) { var n0_1083 int64 = jrt.NN(jrt.Long_Cast(na_1081)).LongValue__J(); var n1_1084 int64 = na_1082; if n1_1084 == 0 { arg_1080 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1081, na_1082) } else { arg_1080 = jrt.Long_ValueOf_J__Long_NoInit(n0_1083 / n1_1084).Ref() } } else { arg_1080 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1081, na_1082) }; if linked_1076 == nil { arg_1072 = ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { arg_1072 = linked_1076.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) }; var arg_1073 any = A_arbace_repr_go_print_emit_A_const_17; var arg_1074 any; var na_1086 any = extra__16; var na_1087 int64 = 2; if jrt.Long_InstanceOf(na_1086) { var n0_1088 int64 = jrt.NN(jrt.Long_Cast(na_1086)).LongValue__J(); var n1_1089 int64 = na_1087; if n1_1089 == 0 { arg_1074 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1086, na_1087) } else { arg_1074 = jrt.Long_ValueOf_J__Long_NoInit(n0_1088 / n1_1089).Ref() } } else { arg_1074 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1086, na_1087) }; if linked_1070 == nil { spaces__16 = ifn_1071.Invoke_O_O_O__O(arg_1072, arg_1073, arg_1074) } else { spaces__16 = linked_1070.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1069, arg_1072, arg_1073, arg_1074) } } else {
//line :450:1
																	if A_arbace_repr_go_print_emit_A_const_55 != nil {




																		var root_1091 any = A_arbace_repr_go_print_emit_A_const_125.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = base__17; var arg_1095 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__8).Ref(); var arg_1096 any = A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O(); var arg_1097 any = extra__16; if linked_1092 == nil { spaces__16 = ifn_1093.Invoke_O_O_O_O__O(arg_1094, arg_1095, arg_1096, arg_1097) } else { spaces__16 = linked_1092.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1091, arg_1094, arg_1095, arg_1096, arg_1097) } } else {
//line :450:1
																			spaces__16 = nil } } } } } else {
//line :445:1
																				if A_arbace_repr_go_print_emit_A_const_55 != nil { var keep__16 any; var root_1098 any = A_arbace_repr_go_print_emit_A_const_127.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1100 lang.IFn











																					if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any; var root_1102 any = A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_take_last_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = need__12; var arg_1106 any = nat__14; if linked_1103 == nil { arg_1101 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { arg_1101 = linked_1103.(*aot_arbace_core.A_arbace_core_take_last_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; if linked_1099 == nil { keep__16 = ifn_1100.Invoke_O__O(arg_1101) } else { keep__16 = linked_1099.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1098, arg_1101) }
																					var root_1107 any = A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any; var root_1111 any = A_arbace_repr_go_print_emit_A_const_129.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var tmp33 any = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(keep__16); var tmp34 *jrt.Class; var fncls__1116 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class; if fncls__1116 == nil { var fncls__1116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class = fncls__1116d; tmp34 = fncls__1116d } else { tmp34 = fncls__1116 }; arg_1114 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_1115 any = slots__13; if linked_1112 == nil { arg_1110 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { arg_1110 = linked_1112.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }; if linked_1108 == nil { spaces__16 = ifn_1109.Invoke_O__O(arg_1110) } else { spaces__16 = linked_1108.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1107, arg_1110) } } else {
//line :445:1
																						spaces__16 = nil } } }
//line :428:1
									var i__17 int64 = 0; var c__18 int64 = lang.RT_LongCast_O__J_NoInit(cc__7); var acc__19 any = lang.PersistentVector_EMPTY.Ref(); L2: for {































										if lang.Numbers_Lt_J_J__Z_NoInit(i__17, int64(n__8)) { var c__20 int64 = lang.Numbers_Add_J_J__J_NoInit(c__18, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(spaces__16, lang.RT_IntCast_J__I_NoInit(i__17)))); var tmp35 int64 = lang.Numbers_Inc_J__J_NoInit(i__17); var tmp36 int64 = lang.Numbers_Add_J_J__J_NoInit(c__20, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lens__9, lang.RT_IntCast_J__I_NoInit(i__17)))); var tmp37 any; var root_1122 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1124 lang.IFn

											if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = acc__19; var arg_1126 any = lang.Tuple_Create_O_O__IPersistentVector(cl__6, jrt.Long_ValueOf_J__Long_NoInit(c__20).Ref()); if linked_1123 == nil { tmp37 = ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { tmp37 = linked_1123.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126) }; i__17, c__18, acc__19 = tmp35, tmp36, tmp37; continue L2 } else {
//line :460:1
												return acc__19 } } } else {
//line :428:1
													return nil } } } }; /*line :415:1*/panic("j2g: unreachable") }





func A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000130_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000130_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Ctor() {}
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Invoke_O_O__O(self, p1__308000124_SHARP___1 any) any { var root_963 any = A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_963, A_arbace_repr_go_print_emit_utf8_len_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000124_SHARP___1); if linked_964 == nil { return ifn_965.Invoke_O__O(arg_966) } else { return jrt.Long_ValueOf_J__Long_NoInit(linked_964.(*A_arbace_repr_go_print_emit_utf8_len_A).InvokePrim_O_O__J(root_963, arg_966)).Ref() } }
func A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_repr_go_print_emit_place_run_natural__308000132_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_natural__308000132_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Ctor_O_I_O_O_O(c__cl any, c__n int32, c__run, c__lens, c__cc any) { t.F_cl = c__cl; t.F_n = c__n; t.F_run = c__run; t.F_lens = c__lens; t.F_cc = c__cc }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var c__2 int64 = lang.RT_LongCast_O__J_NoInit(t.F_cc); var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var c__4 int64; var tmp1 int64; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_74; var tmp3 any = t.F_run
		if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(i__1)))) { tmp1 = 1 } else { tmp1 = 0 }; c__4 = lang.Numbers_Add_J_J__J_NoInit(c__2, tmp1)
		var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any = t.F_lens; var tmp6 int64 = lang.Numbers_Add_J_J__J_NoInit(c__4, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)))); var tmp7 any; var root_968 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = acc__3; var tmp8 any = t.F_cl; var arg_972 any = lang.Tuple_Create_O_O__IPersistentVector(tmp8, jrt.Long_ValueOf_J__Long_NoInit(c__4).Ref()); if linked_969 == nil { tmp7 = ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { tmp7 = linked_969.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) }; i__1, c__2, acc__3 = tmp4, tmp6, tmp7; continue L1 } else {
//line :424:1
			return acc__3 } } }; /*line :422:1*/panic("j2g: unreachable") }




















func A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000137_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000137_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Ctor() {}
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if jrt.J2g_Truth(s__2) { return i__1 } else { return nil } }


func A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000139_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000139_A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Ctor() {}
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Invoke_O_O__O(self, p1__308000125_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000125_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_17 } else { return A_arbace_repr_go_print_emit_A_const_20 } }


func A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000141_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000141_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Ctor() {}
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Invoke_O_O__O(self, p1__308000126_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000126_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_17 } else { return A_arbace_repr_go_print_emit_A_const_20 } }








func A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(p0 any) *A_arbace_repr_go_print_emit_place_run_fn__308000143_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000143_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Ctor_O(c__keep any) { t.F_keep = c__keep }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_keep).Invoke_O__O(i__1)) { return A_arbace_repr_go_print_emit_A_const_17 } else { return A_arbace_repr_go_print_emit_A_const_20 } }






func A_arbace_repr_go_print_emit_full_result_A_New() *A_arbace_repr_go_print_emit_full_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Ctor() {}
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var fs__1 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var items__2 any; if





	jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1)) {
		var root_1127 any = A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = lang.PersistentVector_EMPTY.Ref(); var arg_1131 any; var root_1133 any = A_arbace_repr_go_print_emit_A_const_133.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any; var tmp2 any = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New(); var tmp3 *jrt.Class; var fncls__1137 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class; if fncls__1137 == nil { var fncls__1137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class = fncls__1137d; tmp3 = fncls__1137d } else { tmp3 = fncls__1137 }; arg_1136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_1134 == nil { arg_1131 = ifn_1135.Invoke_O__O(arg_1136) } else { arg_1131 = linked_1134.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_1133, arg_1136) }; var arg_1132 any = A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(fs__1); if linked_1128 == nil { items__2 = ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { items__2 = linked_1128.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) } } else {


			var root_1138 any = A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(fs__1); if linked_1139 == nil { items__2 = ifn_1140.Invoke_O__O(arg_1141) } else { items__2 = linked_1139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1138, arg_1141) } }; var extras__3 any; var root_1142 any = /*line :465:1*/A_arbace_repr_go_print_emit_A_const_136.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1144 lang.IFn; if










	linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any; var tmp4 any = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New(); var tmp5 *jrt.Class; var fncls__1147 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class; if fncls__1147 == nil { var fncls__1147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class = fncls__1147d; tmp5 = fncls__1147d } else { tmp5 = fncls__1147 }; arg_1145 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1146 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_emit_A_const_137.Invoke_O__O(fs__1); var tmp8 any; var root_1154 any = A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1156 lang.IFn; if
	linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any; var tmp9 any = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New(); var tmp10 *jrt.Class; var fncls__1159 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class; if fncls__1159 == nil { var fncls__1159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class = fncls__1159d; tmp10 = fncls__1159d } else { tmp10 = fncls__1159 }; arg_1157 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1158 any = A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1); if linked_1155 == nil { tmp8 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { tmp8 = linked_1155.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }; var tmp11 any = tmp8; var tmp12 any; var root_1160 any = A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1162 lang.IFn; if
	linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any; var tmp13 any = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New(); var tmp14 *jrt.Class; var fncls__1165 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class; if fncls__1165 == nil { var fncls__1165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class = fncls__1165d; tmp14 = fncls__1165d } else { tmp14 = fncls__1165 }; arg_1163 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_1164 any = A_arbace_repr_go_print_emit_A_const_139.Invoke_O__O(fs__1); if linked_1161 == nil { tmp12 = ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { tmp12 = linked_1161.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) }; arg_1146 = /*line :477:1*/tmp6.Invoke_O_O_O__O(tmp7, tmp11, tmp12); if /*line :476:1*/ linked_1143 == nil { extras__3 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { extras__3 = linked_1143.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; var merged__4 any; var tmp15 any = /*line :465:1*/A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(extras__3, items__2); var tmp16 *jrt.Class; var fncls__1224 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class; if














	fncls__1224 == nil { var fncls__1224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class = fncls__1224d; tmp16 = fncls__1224d } else { tmp16 = fncls__1224 }; merged__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O(); var n__5 int32 = /*line :465:1*/lang.RT_Count_O__I_NoInit(merged__4); var space__6 any; var root_1225 any = A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1227 lang.IFn; if




























	linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1229 any; var root_1231 any = A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any; var tmp17 any = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New(); var tmp18 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class = fncls__1239d; tmp18 = fncls__1239d } else { tmp18 = fncls__1239 }; arg_1234 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1232 == nil { arg_1229 = ifn_1233.Invoke_O__O(arg_1234) } else { arg_1229 = linked_1232.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1231, arg_1234) }; var arg_1230 any = A_arbace_repr_go_print_emit_A_const_145.Invoke_O__O(fs__1); if linked_1226 == nil { space__6 = ifn_1227.Invoke_O_O_O__O(arg_1228, arg_1229, arg_1230) } else { space__6 = linked_1226.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230) }; var sb__7 any = /*line :465:1*/jrt.StringBuilder_New(); var cur__8 any; var root_1240 any = A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1242 lang.IFn; if






























	linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_repr_go_print_emit_A_const_146; if linked_1241 == nil { cur__8 = ifn_1242.Invoke_O__O(arg_1243) } else { cur__8 = linked_1241.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1240, arg_1243) }; var last_s__9 any; var root_1244 any = /*line :465:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1246 lang.IFn; if































	linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = Lit_2; if linked_1245 == nil { last_s__9 = ifn_1246.Invoke_O__O(arg_1247) } else { last_s__9 = linked_1245.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1244, arg_1247) }; var prev_item__10 any; var root_1248 any = /*line :465:1*/A_arbace_repr_go_print_emit_A_const_15.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1250 lang.IFn; if
































	linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; if linked_1249 == nil { prev_item__10 = ifn_1250.Invoke_O__O(arg_1251) } else { prev_item__10 = linked_1249.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1248, arg_1251) }; var write_at_BANG___11 any; var tmp19 any = /*line :465:1*/A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(space__6, last_s__9, sb__7, prev_item__10, cur__8); var tmp20 *jrt.Class; var fncls__1294 *jrt.Class = A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class; if


































	fncls__1294 == nil { var fncls__1294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class = fncls__1294d; tmp20 = fncls__1294d } else { tmp20 = fncls__1294 }; write_at_BANG___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var i__12 any = /*line :465:1*/lang.RT_Box_J__Number_NoInit(0); L1: for {






























































		var tmp21 bool; var na_1295 any = i__12; var na_1296 int64 = int64(n__5); if jrt.Long_InstanceOf(na_1295) { var n0_1297 int64 = jrt.NN(jrt.Long_Cast(na_1295)).LongValue__J(); var n1_1298 int64 = na_1296; tmp21 = n0_1297 < n1_1298 } else { tmp21 = lang.Numbers_Lt_O_J__Z_NoInit(na_1295, na_1296) }; if tmp21 { var it__13 any = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(i__12))

			if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)) {
				lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(it__13, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)); var tmp22 jrt.Number_I; var na_1455 any = i__12; if jrt.Long_InstanceOf(na_1455) { var n0_1456 int64 = jrt.NN(jrt.Long_Cast(na_1455)).LongValue__J(); if n0_1456 == 9223372036854775807 { tmp22 = lang.Numbers_Inc_O__Number_NoInit(na_1455) } else { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1456 + 1)) } } else { if jrt.Double_InstanceOf(na_1455) { var n0_1456_2 float64 = jrt.NN(jrt.Double_Cast(na_1455)).DoubleValue__D(); tmp22 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1456_2 + 1.0)) } else { tmp22 = lang.Numbers_Inc_O__Number_NoInit(na_1455) } }; i__12 = tmp22; continue L1 } else {
//line :530:1
					var j__14 any; var tmp23 any = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(merged__4, n__5, i__12); var tmp24 *jrt.Class
					var fncls__1307 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class



					if fncls__1307 == nil { var fncls__1307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class = fncls__1307d; tmp24 = fncls__1307d } else { tmp24 = fncls__1307 }; j__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()
//line :530:1
					var t__15 any; var tmp25 any = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(merged__4, n__5, j__14); var tmp26 *jrt.Class
					var fncls__1315 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class




					if fncls__1315 == nil { var fncls__1315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class = fncls__1315d; tmp26 = fncls__1315d } else { tmp26 = fncls__1315 }; t__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O()
//line :530:1
					var tok_STAR___16 any; var tmp27 bool; var na_1316 any = t__15; var na_1317 int64 = int64(n__5)





					if jrt.Long_InstanceOf(na_1316) { var n0_1318 int64 = jrt.NN(jrt.Long_Cast(na_1316)).LongValue__J(); var n1_1319 int64 = na_1317; tmp27 = n0_1318 < n1_1319 } else { tmp27 = lang.Numbers_Lt_O_J__Z_NoInit(na_1316, na_1317) }; if tmp27 { tok_STAR___16 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(t__15)) } else { tok_STAR___16 = nil }
//line :530:1
					var vec__308000224__17 any; var root_1321 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1323 lang.IFn



					if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = cur__8; if linked_1322 == nil { vec__308000224__17 = ifn_1323.Invoke_O__O(arg_1324) } else { vec__308000224__17 = linked_1322.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1321, arg_1324) }
//line :530:1
					var cl__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000224__17, lang.RT_IntCast_J__I_NoInit(0), nil); var ___19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000224__17, lang.RT_IntCast_J__I_NoInit(1), nil); var same_line_QMARK___20 any; var and__1927000168__auto____20 any = tok_STAR___16; _ = ___19







					if jrt.J2g_Truth(and__1927000168__auto____20) { var tmp28 any; var root_1325 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(tok_STAR___16); if linked_1326 == nil { tmp28 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp28 = linked_1326.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1325, arg_1328) }; same_line_QMARK___20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp28), lang.RT_LongCast_O__J_NoInit(cl__18))).Ref() } else { same_line_QMARK___20 = and__1927000168__auto____20 }
//line :530:1
					var run__21 any; var tmp29 any = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(last_s__9, merged__4, tok_STAR___16, j__14, i__12, same_line_QMARK___20); var tmp30 *jrt.Class
					var fncls__1372 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class








					if fncls__1372 == nil { var fncls__1372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class = fncls__1372d; tmp30 = fncls__1372d } else { tmp30 = fncls__1372 }; run__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil).Invoke__O()
//line :530:1
					var obstacles__22 any; var root_1373 any = A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1375 lang.IFn






















					if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var root_1377 any = A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var root_1382 any = A_arbace_repr_go_print_emit_A_const_149.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any; var tmp31 any = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(cl__18); var tmp32 *jrt.Class; var fncls__1391 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class; if fncls__1391 == nil { var fncls__1391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class = fncls__1391d; tmp32 = fncls__1391d } else { tmp32 = fncls__1391 }; arg_1385 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var arg_1386 any; var root_1392 any = A_arbace_repr_go_print_emit_A_const_150.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = merged__4; var arg_1396 any = j__14; var arg_1397 any = t__15; if linked_1393 == nil { arg_1386 = ifn_1394.Invoke_O_O_O__O(arg_1395, arg_1396, arg_1397) } else { arg_1386 = linked_1393.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1392, arg_1395, arg_1396, arg_1397) }; if linked_1383 == nil { arg_1380 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { arg_1380 = linked_1383.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }; var arg_1381 any
					if jrt.J2g_Truth(same_line_QMARK___20) { arg_1381 = lang.Tuple_Create_O__IPersistentVector(tok_STAR___16) } else { arg_1381 = nil }
//line :553:1
					if linked_1378 == nil { arg_1376 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { arg_1376 = linked_1378.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) }; if linked_1374 == nil { obstacles__22 = ifn_1375.Invoke_O__O(arg_1376) } else { obstacles__22 = linked_1374.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1373, arg_1376) }
//line :530:1
					var width__23 any; var root_1398 any = A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1400 lang.IFn
























					if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O(); var arg_1402 any; var root_1403 any = A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any; var tmp33 any = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New(); var tmp34 *jrt.Class; var fncls__1412 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class; if fncls__1412 == nil { var fncls__1412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class = fncls__1412d; tmp34 = fncls__1412d } else { tmp34 = fncls__1412 }; arg_1406 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_1407 any = run__21; if linked_1404 == nil { arg_1402 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { arg_1402 = linked_1404.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; if linked_1399 == nil { width__23 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { width__23 = linked_1399.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }
//line :530:1
					var k__24 any; var tmp35 any = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(obstacles__22, width__23, cur__8); var tmp36 *jrt.Class
					var fncls__1444 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class

























					if fncls__1444 == nil { var fncls__1444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class = fncls__1444d; tmp36 = fncls__1444d } else { tmp36 = fncls__1444 }; k__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O()
//line :530:1
					var k__25 any; var tmp37 any; var root_1445 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1447 lang.IFn

































					if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = run__21; if linked_1446 == nil { tmp37 = ifn_1447.Invoke_O__O(arg_1448) } else { tmp37 = linked_1446.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1445, arg_1448) }; if jrt.J2g_Truth(tmp37) { var tmp38 any; var root_1449 any = A_arbace_repr_go_print_emit_A_const_150.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = merged__4; var arg_1453 any = j__14; var arg_1454 any = t__15; if linked_1450 == nil { tmp38 = ifn_1451.Invoke_O_O_O__O(arg_1452, arg_1453, arg_1454) } else { tmp38 = linked_1450.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1449, arg_1452, arg_1453, arg_1454) }; k__25 = lang.Numbers_Min_O_J__O_NoInit(k__24, int64(lang.RT_Count_O__I_NoInit(tmp38))) } else { k__25 = A_arbace_repr_go_print_emit_A_const_20 }
//line :530:1
					var n__1927000701__auto____26 int64 = lang.RT_LongCast_O__J_NoInit(k__25); var q__27 int64 = 0; L2: for {


































						if lang.Numbers_Lt_J_J__Z_NoInit(q__27, n__1927000701__auto____26) { var o__28 any; var tmp39 jrt.Number_I; var na_1513 any = j__14; var na_1514 int64 = q__27; if jrt.Long_InstanceOf(na_1513) { var n0_1515 int64 = jrt.NN(jrt.Long_Cast(na_1513)).LongValue__J(); var n1_1516 int64 = na_1514; var nr_1517 int64 = n0_1515 + n1_1516; if (n0_1515^nr_1517)&(n1_1516^nr_1517) >= 0 { tmp39 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1517)) } else { tmp39 = lang.Numbers_Add_O_J__Number_NoInit(na_1513, na_1514) } } else { tmp39 = lang.Numbers_Add_O_J__Number_NoInit(na_1513, na_1514) }; o__28 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(tmp39)); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(o__28, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__28)); q__27 = lang.Numbers_Unchecked_inc_J__J_NoInit(q__27); continue L2 }
//line :530:1
						break L2 }; var nxt__26 any; var tmp40 bool; var na_1457 any; var na_1459 any = j__14; var na_1460 any = k__25; var tmp41 bool; var tmp42 bool



































					tmp42 = jrt.Long_InstanceOf(na_1459); if tmp42 { tmp42 = jrt.Long_InstanceOf(na_1460) }; tmp41 = tmp42; if tmp41 { var n0_1461 int64 = jrt.NN(jrt.Long_Cast(na_1459)).LongValue__J(); var n1_1462 int64 = jrt.NN(jrt.Long_Cast(na_1460)).LongValue__J(); var nr_1463 int64 = n0_1461 + n1_1462; if (n0_1461^nr_1463)&(n1_1462^nr_1463) >= 0 { na_1457 = jrt.Long_ValueOf_J__Long_NoInit(nr_1463).Ref() } else { na_1457 = lang.Numbers_Add_O_O__Number_NoInit(na_1459, na_1460) } } else { var tmp43 bool; var tmp44 bool; tmp44 = jrt.Double_InstanceOf(na_1459); if tmp44 { tmp44 = jrt.Double_InstanceOf(na_1460) }; tmp43 = tmp44; if tmp43 { var n0_1461_2 float64 = jrt.NN(jrt.Double_Cast(na_1459)).DoubleValue__D(); var n1_1462_2 float64 = jrt.NN(jrt.Double_Cast(na_1460)).DoubleValue__D(); na_1457 = jrt.Double_ValueOf_D__Double_NoInit(n0_1461_2 + n1_1462_2).Ref() } else { na_1457 = lang.Numbers_Add_O_O__Number_NoInit(na_1459, na_1460) } }; var na_1458 int64 = int64(n__5); if jrt.Long_InstanceOf(na_1457) { var n0_1464 int64 = jrt.NN(jrt.Long_Cast(na_1457)).LongValue__J(); var n1_1465 int64 = na_1458; tmp40 = n0_1464 < n1_1465 } else { tmp40 = lang.Numbers_Lt_O_J__Z_NoInit(na_1457, na_1458) }; if tmp40 { var tmp45 jrt.Number_I; var na_1467 any = j__14; var na_1468 any = k__25; var tmp46 bool; var tmp47 bool; tmp47 = jrt.Long_InstanceOf(na_1467); if tmp47 { tmp47 = jrt.Long_InstanceOf(na_1468) }; tmp46 = tmp47; if tmp46 { var n0_1469 int64 = jrt.NN(jrt.Long_Cast(na_1467)).LongValue__J(); var n1_1470 int64 = jrt.NN(jrt.Long_Cast(na_1468)).LongValue__J(); var nr_1471 int64 = n0_1469 + n1_1470; if (n0_1469^nr_1471)&(n1_1470^nr_1471) >= 0 { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1471)) } else { tmp45 = lang.Numbers_Add_O_O__Number_NoInit(na_1467, na_1468) } } else { var tmp48 bool; var tmp49 bool; tmp49 = jrt.Double_InstanceOf(na_1467); if tmp49 { tmp49 = jrt.Double_InstanceOf(na_1468) }; tmp48 = tmp49; if tmp48 { var n0_1469_2 float64 = jrt.NN(jrt.Double_Cast(na_1467)).DoubleValue__D(); var n1_1470_2 float64 = jrt.NN(jrt.Double_Cast(na_1468)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1469_2 + n1_1470_2)) } else { tmp45 = lang.Numbers_Add_O_O__Number_NoInit(na_1467, na_1468) } }; nxt__26 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(tmp45)) } else { nxt__26 = nil }
//line :530:1
					var ps__27 any; var root_1472 any = A_arbace_repr_go_print_emit_A_const_152.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, A_arbace_repr_go_print_emit_place_run_A_fn_class); var ifn_1474 lang.IFn




































					if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = run__21; var arg_1476 any; var root_1479 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = cur__8; if linked_1480 == nil { arg_1476 = ifn_1481.Invoke_O__O(arg_1482) } else { arg_1476 = linked_1480.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1479, arg_1482) }; var arg_1477 any; var root_1483 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = prev_item__10; if linked_1484 == nil { arg_1477 = ifn_1485.Invoke_O__O(arg_1486) } else { arg_1477 = linked_1484.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1483, arg_1486) }; var arg_1478 any = nxt__26; if linked_1473 == nil { ps__27 = ifn_1474.Invoke_O_O_O_O__O(arg_1475, arg_1476, arg_1477, arg_1478) } else { ps__27 = linked_1473.(*A_arbace_repr_go_print_emit_place_run_A).Invoke_O_O_O_O_O__O(root_1472, arg_1475, arg_1476, arg_1477, arg_1478) }
//line :530:1
					var seq_308000240__28 any; var root_1487 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1489 lang.IFn





































					if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any; var root_1491 any = A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(); var arg_1495 any = run__21; var arg_1496 any = ps__27; if linked_1492 == nil { arg_1490 = ifn_1493.Invoke_O_O_O__O(arg_1494, arg_1495, arg_1496) } else { arg_1490 = linked_1492.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1491, arg_1494, arg_1495, arg_1496) }; if linked_1488 == nil { seq_308000240__28 = ifn_1489.Invoke_O__O(arg_1490) } else { seq_308000240__28 = linked_1488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1487, arg_1490) }
//line :530:1
					var chunk_308000241__29 any; var count_308000242__30 int64 = 0; var i_308000243__31 int64 = 0; L3: for {





































						if lang.Numbers_Lt_J_J__Z_NoInit(i_308000243__31, count_308000242__30) { var vec__308000244__32 any = lang.Indexed_Cast(chunk_308000241__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_308000243__31)); var x__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000244__32, lang.RT_IntCast_J__I_NoInit(0), nil); var p__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000244__32, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__33, p__34); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = seq_308000240__28, chunk_308000241__29, count_308000242__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_308000243__31); continue L3 } else { var temp__1927000414__auto____32 any; var root_1497 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = seq_308000240__28; if linked_1498 == nil { temp__1927000414__auto____32 = ifn_1499.Invoke_O__O(arg_1500) } else { temp__1927000414__auto____32 = linked_1498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1497, arg_1500) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_308000240__33 any = temp__1927000414__auto____32; var tmp50 any; var root_1501 any = A_arbace_repr_go_print_emit_A_const_153.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = seq_308000240__33; if linked_1502 == nil { tmp50 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp50 = linked_1502.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1501, arg_1504) }; if jrt.J2g_Truth(tmp50) { var c__1927000678__auto____34 any; var root_1505 any = A_arbace_repr_go_print_emit_A_const_154.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = seq_308000240__33; if linked_1506 == nil { c__1927000678__auto____34 = ifn_1507.Invoke_O__O(arg_1508) } else { c__1927000678__auto____34 = linked_1506.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1505, arg_1508) }; var tmp51 any; var root_1518 any = A_arbace_repr_go_print_emit_A_const_155.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = seq_308000240__33; if linked_1519 == nil { tmp51 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp51 = linked_1519.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1518, arg_1521) }; seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = tmp51, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__308000247__34 any; var root_1509 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = seq_308000240__33; if linked_1510 == nil { vec__308000247__34 = ifn_1511.Invoke_O__O(arg_1512) } else { vec__308000247__34 = linked_1510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1509, arg_1512) }; var x__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000247__34, lang.RT_IntCast_J__I_NoInit(0), nil); var p__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000247__34, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__35, p__36); var tmp52 any; var root_1522 any = A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = seq_308000240__33; if linked_1523 == nil { tmp52 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp52 = linked_1523.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1522, arg_1525) }; seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = tmp52, nil, 0, 0; continue L3 } } }
//line :530:1
						break L3
					}





































					var tmp53 jrt.Number_I; var na_1526 any = j__14; var na_1527 any = k__25; var tmp54 bool; var tmp55 bool; tmp55 = jrt.Long_InstanceOf(na_1526); if tmp55 { tmp55 = jrt.Long_InstanceOf(na_1527) }; tmp54 = tmp55; if tmp54 { var n0_1528 int64 = jrt.NN(jrt.Long_Cast(na_1526)).LongValue__J(); var n1_1529 int64 = jrt.NN(jrt.Long_Cast(na_1527)).LongValue__J(); var nr_1530 int64 = n0_1528 + n1_1529; if (n0_1528^nr_1530)&(n1_1529^nr_1530) >= 0 { tmp53 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1530)) } else { tmp53 = lang.Numbers_Add_O_O__Number_NoInit(na_1526, na_1527) } } else { var tmp56 bool; var tmp57 bool; tmp57 = jrt.Double_InstanceOf(na_1526); if tmp57 { tmp57 = jrt.Double_InstanceOf(na_1527) }; tmp56 = tmp57; if tmp56 { var n0_1528_2 float64 = jrt.NN(jrt.Double_Cast(na_1526)).DoubleValue__D(); var n1_1529_2 float64 = jrt.NN(jrt.Double_Cast(na_1527)).DoubleValue__D(); tmp53 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1528_2 + n1_1529_2)) } else { tmp53 = lang.Numbers_Add_O_O__Number_NoInit(na_1526, na_1527) } }; i__12 = tmp53; continue L1 } }
//line :465:1
		break L1 }; var tmp58 /*line :570:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__7); var tmp59 any; var or__1927000174__auto____12 any = A_arbace_repr_go_print_emit_A_const_151.Invoke_O__O(fs__1); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp59 = or__1927000174__auto____12 } else { tmp59 = Lit_3 }; jrt.NN(tmp58).Append_O__StringBuilder(tmp59); return /*line :571:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__7)).ToString__String().Ref() }
//line :472:1
func A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000149_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000149_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Ctor() {}
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Invoke_O_O__O(self, p1__308000146_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_134); var and__1927000168__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000146_SHARP___1), nil); if and__1927000168__auto____3 { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_18, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1))
															if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var tmp2 any = A_arbace_repr_go_print_emit_A_const_135; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(p1__308000146_SHARP___1)); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { return A_arbace_repr_go_print_emit_A_const_135.Invoke_O__O(p1__308000146_SHARP___1) } } } else {
//line :472:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000152_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000152_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Ctor() {}
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Invoke_O_O__O(self, p__308000151__1 any) any { var vec__308000153__2 any = p__308000151__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000153__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000153__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }
func A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000158_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000158_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Ctor() {}
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Invoke_O_O__O(self, p__308000157__1 any) any { var vec__308000159__2 any = p__308000157__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000159__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000159__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_18, A_arbace_repr_go_print_emit_A_const_23) }
func A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000164_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000164_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Ctor() {}
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Invoke_O_O__O(self, p__308000163__1 any) any { var vec__308000165__2 any = p__308000163__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_19, A_arbace_repr_go_print_emit_A_const_23) }

func A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_full_result_fn__308000169_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_A{}; t.Ctor_O_O(p0, p1); return t }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Ctor_O_O(c__extras, c__items any) { t.F_extras = c__extras; t.F_items = c__items }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var cs__2 any; var root_1166 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any; var t_ any = t.F_extras; t.F_extras = nil; arg_1169 = t_; if linked_1167 == nil { cs__2 = ifn_1168.Invoke_O__O(arg_1169) } else { cs__2 = linked_1167.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1166, arg_1169) }; var acc__3 any; var root_1170 any = A_arbace_repr_go_print_emit_A_const_140.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = lang.PersistentVector_EMPTY.Ref(); if linked_1171 == nil { acc__3 = ifn_1172.Invoke_O__O(arg_1173) } else { acc__3 = linked_1171.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_1170, arg_1173) }; L1: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_items))) { var tmp1 any = t.F_items; var it__4 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)); var pos__5 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__4); var tmp2 any
													var and__1927000168__auto____6 any = pos__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1174 any = A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = cs__2; if linked_1175 == nil { and__1927000168__auto____7 = ifn_1176.Invoke_O__O(arg_1177) } else { and__1927000168__auto____7 = linked_1175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1174, arg_1177) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 lang.IPersistentVector; var vec__308000170__8 any; var root_1178 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = cs__2; if linked_1179 == nil { vec__308000170__8 = ifn_1180.Invoke_O__O(arg_1181) } else { vec__308000170__8 = linked_1179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1178, arg_1181) }; var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000170__8, lang.RT_IntCast_J__I_NoInit(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000170__8, lang.RT_IntCast_J__I_NoInit(1), nil); tmp3 = lang.Tuple_Create_O_O__IPersistentVector(l__9, c__10); tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp3, pos__5)))).Ref() } else { tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var vec__308000173__6 any; var root_1182 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1184 lang.IFn
			if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = cs__2; if linked_1183 == nil { vec__308000173__6 = ifn_1184.Invoke_O__O(arg_1185) } else { vec__308000173__6 = linked_1183.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1182, arg_1185) }
//line :484:1
			var l__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(1), nil); var t__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(2), nil); var semi__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp4 any; var root_1206 any = A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1208 lang.IFn

			if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = cs__2; if linked_1207 == nil { tmp4 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp4 = linked_1207.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1206, arg_1209) }; var tmp5 any = tmp4; var tmp6 any; var root_1210 any = A_arbace_repr_go_print_emit_A_const_142.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = acc__3; var arg_1214 any; if jrt.J2g_Truth(semi__10) { var tmp7 any = A_arbace_repr_go_print_emit_A_const_72; var tmp8 any = A_arbace_repr_go_print_emit_A_const_73; arg_1214 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, t__9, tmp8, lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8))) } else { var tmp9 any = A_arbace_repr_go_print_emit_A_const_72; var tmp10 any; var root_1215 any = A_arbace_repr_go_print_emit_A_const_143.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1217 lang.IFn
				if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = t__9; if linked_1216 == nil { tmp10 = ifn_1217.Invoke_O__O(arg_1218) } else { tmp10 = linked_1216.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1215, arg_1218) }
//line :486:1
				var tmp11 any = tmp10; var tmp12 any = A_arbace_repr_go_print_emit_A_const_73; arg_1214 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp12, lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8), A_arbace_repr_go_print_emit_A_const_116, jrt.Boolean_TRUE.Ref())) }; if linked_1211 == nil { tmp6 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { tmp6 = linked_1211.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; i__1, cs__2, acc__3 = i__1, tmp5, tmp6; continue L1 } else {

					var tmp13 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp14 any; var root_1219 any = A_arbace_repr_go_print_emit_A_const_142.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = acc__3; var arg_1223 any = it__4; if linked_1220 == nil { tmp14 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { tmp14 = linked_1220.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) }; i__1, cs__2, acc__3 = tmp13, cs__2, tmp14; continue L1 } } else {
						var root_1186 any = A_arbace_repr_go_print_emit_A_const_141.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var root_1190 any = A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var tmp15 any = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New(); var tmp16 *jrt.Class; var fncls__1205 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class; if fncls__1205 == nil { var fncls__1205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class = fncls__1205d; tmp16 = fncls__1205d } else { tmp16 = fncls__1205 }; arg_1193 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1194 any = acc__3; var arg_1195 any = cs__2; if linked_1191 == nil { arg_1189 = ifn_1192.Invoke_O_O_O__O(arg_1193, arg_1194, arg_1195) } else { arg_1189 = linked_1191.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1190, arg_1193, arg_1194, arg_1195) }; if linked_1187 == nil { return ifn_1188.Invoke_O__O(arg_1189) } else { return linked_1187.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_1186, arg_1189) } } } }; /*line :480:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Ctor() {}
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Invoke_O_O_O__O(self, a__1, p__308000176__2 any) any { var vec__308000178__3 any = p__308000176__2; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(1), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(2), nil); var semi__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(3), nil); var root_1196 any = A_arbace_repr_go_print_emit_A_const_142.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1198 lang.IFn; if
																	linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = a__1; var arg_1200 any; if jrt.J2g_Truth(semi__7) { var tmp1 any = A_arbace_repr_go_print_emit_A_const_72; var tmp2 any = A_arbace_repr_go_print_emit_A_const_73; arg_1200 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, t__6, tmp2, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5))) } else { var tmp3 any = A_arbace_repr_go_print_emit_A_const_72; var tmp4 any; var root_1201 any = A_arbace_repr_go_print_emit_A_const_143.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1203 lang.IFn
																		if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = t__6; if linked_1202 == nil { tmp4 = ifn_1203.Invoke_O__O(arg_1204) } else { tmp4 = linked_1202.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1201, arg_1204) }
//line :490:1
		var tmp5 any = tmp4; var tmp6 any = A_arbace_repr_go_print_emit_A_const_73; arg_1200 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5), A_arbace_repr_go_print_emit_A_const_116, jrt.Boolean_TRUE.Ref())) }; if linked_1197 == nil { return ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { return linked_1197.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) } }



func A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000184_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000184_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Ctor() {}
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Invoke_O_O__O(self, p__308000183__1 any) any { var vec__308000185__2 any = p__308000183__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(1), nil); var w__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any = lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4); var tmp2 any; var root_1235 any = A_arbace_repr_go_print_emit_A_const_143.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = w__5; if linked_1236 == nil { tmp2 = ifn_1237.Invoke_O__O(arg_1238) } else { tmp2 = linked_1236.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1235, arg_1238) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }





func A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Ctor_O_O_O_O_O(c__space, c__last_s, c__sb, c__prev_item, c__cur any) { t.F_space = c__space; t.F_last_s = c__last_s; t.F_sb = c__sb; t.F_prev_item = c__prev_item; t.F_cur = c__cur }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Invoke_O_O_O__O(self, it__1, p__308000189__2 any) any { var vec__308000191__3 any = p__308000189__2; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000191__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000191__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__308000194__6 any; var root_1252 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1254 lang.IFn; if
																	linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = t.F_cur; if linked_1253 == nil { vec__308000194__6 = ifn_1254.Invoke_O__O(arg_1255) } else { vec__308000194__6 = linked_1253.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1252, arg_1255) }; var cl__7 any = /*line :500:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__308000194__6, lang.RT_IntCast_J__I_NoInit(0), nil); var cc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000194__6, lang.RT_IntCast_J__I_NoInit(1), nil); var l__9 int64 = lang.RT_LongCast_O__J_NoInit(l__4); var c__10 int64 = lang.RT_LongCast_O__J_NoInit(c__5); var cl__11 int64 = lang.RT_LongCast_O__J_NoInit(cl__7); var cc__12 int64 = lang.RT_LongCast_O__J_NoInit(cc__8); if


	lang.Numbers_Gt_J_J__Z_NoInit(l__9, cl__11) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____13 any = tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(cl__11).Ref(), jrt.Long_ValueOf_J__Long_NoInit(cc__12).Ref()))

		if jrt.J2g_Truth(temp__1927000414__auto____13) { var w__14 any = temp__1927000414__auto____13; var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(w__14)) }
//line :503:1
		var k__13 int64 = cl__11; L1: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(k__13, l__9) {
				jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_84)
				if lang.Numbers_Lt_J_J__Z_NoInit(k__13, lang.Numbers_Dec_J__J_NoInit(l__9)) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____14 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__13)).Ref(), A_arbace_repr_go_print_emit_A_const_17))
					if jrt.J2g_Truth(temp__1927000414__auto____14) { var w__15 any = temp__1927000414__auto____14; var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp4).Append_String__StringBuilder(jrt.String_Cast(w__15)) } }
				k__13 = lang.Numbers_Inc_J__J_NoInit(k__13); continue L1 }
//line :503:1
			break L1 }; var tmp5 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13 any = tmp5.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), A_arbace_repr_go_print_emit_A_const_17))








		if jrt.J2g_Truth(temp__1927000408__auto____13) { var w__14_2 any = temp__1927000408__auto____13; var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
			jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(w__14_2)) } else {
//line :512:1
				var n__1927000701__auto____14 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Dec_J__J_NoInit(c__10)); var ___15 int64 = 0; L2: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(___15, n__1927000701__auto____14) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___15 = lang.Numbers_Unchecked_inc_J__J_NoInit(___15); continue L2 }
//line :512:1
					break L2 } } } else {
//line :503:1
						var tmp7 bool; var and__1927000168__auto____13 bool = lang.Util_Equiv_J_J__Z_NoInit(l__9, cl__11)











						if and__1927000168__auto____13 { tmp7 = lang.Numbers_Gte_J_J__Z_NoInit(c__10, cc__12) } else { tmp7 = and__1927000168__auto____13 }
//line :503:1
						if tmp7 { var tmp8 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13_2 any = tmp8.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), jrt.Long_ValueOf_J__Long_NoInit(cc__12).Ref()))












							if jrt.J2g_Truth(temp__1927000408__auto____13_2) { var w__14_3 any = temp__1927000408__auto____13_2; var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
								jrt.NN(tmp9).Append_String__StringBuilder(jrt.String_Cast(w__14_3)) } else {
//line :516:1
									var n__1927000701__auto____14_2 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(c__10, cc__12)); var ___15_2 int64 = 0; L3: for {

										if lang.Numbers_Lt_J_J__Z_NoInit(___15_2, n__1927000701__auto____14_2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79); ___15_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(___15_2); continue L3 }
//line :516:1
										break L3 } } } else {
//line :503:1
											if A_arbace_repr_go_print_emit_A_const_55 != nil {
















												var tmp10 any; var or__1927000174__auto____13 any = A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(it__1); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp10 = or__1927000174__auto____13 } else { var root_1261 any = A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1266 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = t.F_last_s; if linked_1267 == nil { arg_1264 = ifn_1268.Invoke_O__O(arg_1269) } else { arg_1264 = linked_1267.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1266, arg_1269) }; var arg_1265 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1); if linked_1262 == nil { tmp10 = ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { tmp10 = linked_1262.(*A_arbace_repr_go_print_emit_may_combine_QMARK__A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265) } }; if jrt.J2g_Truth(tmp10) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } } }; var tmp11 /*line :521:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))); var root_1270 any =
	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = t.F_cur; var arg_1274 any; var tmp12 bool; var or__1927000174__auto____13_2 bool = lang.Numbers_Gt_J_J__Z_NoInit(l__9, cl__11); if or__1927000174__auto____13_2 { tmp12 = or__1927000174__auto____13_2 } else { var and__1927000168__auto____14 bool = lang.Util_Equiv_J_J__Z_NoInit(l__9, cl__11); if and__1927000168__auto____14 { tmp12 = lang.Numbers_Gte_J_J__Z_NoInit(c__10, cc__12) } else { tmp12 = and__1927000168__auto____14 } }; if tmp12 {
		var root_1275 any = A_arbace_repr_go_print_emit_A_const_147.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_repr_go_print_emit_end_of_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), jrt.Long_ValueOf_J__Long_NoInit(c__10).Ref()); var arg_1279 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1); if linked_1276 == nil { arg_1274 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { arg_1274 = linked_1276.(*A_arbace_repr_go_print_emit_end_of_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) } } else {
			var root_1280 any = A_arbace_repr_go_print_emit_A_const_147.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, A_arbace_repr_go_print_emit_end_of_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any; var root_1285 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = t.F_cur; if linked_1286 == nil { arg_1283 = ifn_1287.Invoke_O__O(arg_1288) } else { arg_1283 = linked_1286.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1285, arg_1288) }; var arg_1284 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))).Ref(); if linked_1281 == nil { arg_1274 = ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { arg_1274 = linked_1281.(*A_arbace_repr_go_print_emit_end_of_A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) } }; if /*line :522:1*/ linked_1271 == nil { ifn_1272.Invoke_O_O__O(arg_1273, arg_1274) } else { linked_1271.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1270, arg_1273, arg_1274) }; var root_1289 any =


	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t.F_last_s; var arg_1293 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1); if linked_1290 == nil { ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { linked_1290.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var root_1256 any =
	A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = t.F_prev_item; var arg_1260 any = it__1; if linked_1257 == nil { return ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { return linked_1257.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) } }







func A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000227_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000227_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Ctor_O_I_O(c__merged any, c__n int32, c__i any) { t.F_merged = c__merged; t.F_n = c__n; t.F_i = c__i }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_1300 any = j__1; var na_1301 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1300) { var n0_1302 int64 = jrt.NN(jrt.Long_Cast(na_1300)).LongValue__J(); var n1_1303 int64 = na_1301; and__1927000168__auto____2 = n0_1302 < n1_1303 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1300, na_1301) }; if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_73; var tmp3 any = t.F_merged; tmp1 = lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1))), nil) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_1305 any = j__1; if jrt.Long_InstanceOf(na_1305) { var n0_1306 int64 = jrt.NN(jrt.Long_Cast(na_1305)).LongValue__J(); if n0_1306 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1305) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1306 + 1)) } } else { if jrt.Double_InstanceOf(na_1305) { var n0_1306_2 float64 = jrt.NN(jrt.Double_Cast(na_1305)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1306_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1305) } }; j__1 = tmp4; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000229_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Ctor_O_I_O(c__merged any, c__n int32, c__j any) { t.F_merged = c__merged; t.F_n = c__n; t.F_j = c__j }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Invoke_O__O(self any) any { { var t__1 any; var t_ any = t.F_j; t.F_j = nil; t__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool; var na_1308 any = t__1; var na_1309 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1308) { var n0_1310 int64 = jrt.NN(jrt.Long_Cast(na_1308)).LongValue__J(); var n1_1311 int64 = na_1309; and__1927000168__auto____2 = n0_1310 < n1_1311 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1308, na_1309) }; if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_116; var tmp3 any = t.F_merged; tmp1 = tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(t__1))) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp4 jrt.Number_I; var na_1313 any = t__1; if jrt.Long_InstanceOf(na_1313) { var n0_1314 int64 = jrt.NN(jrt.Long_Cast(na_1313)).LongValue__J(); if n0_1314 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1313) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1314 + 1)) } } else { if jrt.Double_InstanceOf(na_1313) { var n0_1314_2 float64 = jrt.NN(jrt.Double_Cast(na_1313)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1314_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1313) } }; t__1 = tmp4; continue L1 } else { return t__1 } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_print_emit_full_result_fn__308000231_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000231_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Ctor_O_O_O_O_O_O(c__last_s, c__merged, c__tok_STAR_, c__j, c__i, c__same_line_QMARK_ any) { t.F_last_s = c__last_s; t.F_merged = c__merged; t.F_tok_STAR_ = c__tok_STAR_; t.F_j = c__j; t.F_i = c__i; t.F_same_line_QMARK_ = c__same_line_QMARK_ }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Invoke_O__O(self any) any { { var k__1 any; var t_ any = t.F_i; t.F_i = nil; k__1 = t_; var ls__2 any; var root_1329 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any; var t__2 any = t.F_last_s; t.F_last_s = nil; arg_1332 = t__2; if linked_1330 == nil { ls__2 = ifn_1331.Invoke_O__O(arg_1332) } else { ls__2 = linked_1330.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1329, arg_1332) }; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 bool; var na_1333 any = k__1; var na_1334 any = t.F_j; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1333); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1334) }; tmp2 = tmp3; if tmp2 { var n0_1335 int64 = jrt.NN(jrt.Long_Cast(na_1333)).LongValue__J(); var n1_1336 int64 = jrt.NN(jrt.Long_Cast(na_1334)).LongValue__J(); tmp1 = n0_1335 < n1_1336 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_1333); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_1334) }; tmp4 = tmp5; if tmp4 { var n0_1335_2 float64 = jrt.NN(jrt.Double_Cast(na_1333)).DoubleValue__D(); var n1_1336_2 float64 = jrt.NN(jrt.Double_Cast(na_1334)).DoubleValue__D(); tmp1 = n0_1335_2 < n1_1336_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_1333, na_1334) } }; if tmp1 { var tmp6 any = t.F_merged; var x__4 any = lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(k__1)); var temp__1927000408__auto____5 any = A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(x__4)

		if jrt.J2g_Truth(temp__1927000408__auto____5) { var kind__6 any = temp__1927000408__auto____5; var keep_QMARK___7 any; var G__308000232__7_ any = kind__6
		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__308000232__7_) >> 1 & 1 { case 0: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_135) { var and__1927000168__auto____8 any; var root_1339 any = A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1341 lang.IFn

			if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = t.F_same_line_QMARK_; if linked_1340 == nil { and__1927000168__auto____8 = ifn_1341.Invoke_O__O(arg_1342) } else { and__1927000168__auto____8 = linked_1340.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1339, arg_1342) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = t.F_tok_STAR_; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1343 any = A_arbace_repr_go_print_emit_A_const_148.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = ls__2; var arg_1347 any = Lit_19; if linked_1344 == nil { and__1927000168__auto____10 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { and__1927000168__auto____10 = linked_1344.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_1348 any = A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = ls__2; if linked_1349 == nil { keep_QMARK___7 = ifn_1350.Invoke_O__O(arg_1351) } else { keep_QMARK___7 = linked_1349.(*A_arbace_repr_go_print_emit_semi_after_QMARK__A).Invoke_O_O__O(root_1348, arg_1351) } } else { keep_QMARK___7 = and__1927000168__auto____10 } } else { keep_QMARK___7 = and__1927000168__auto____9 } } else { keep_QMARK___7 = and__1927000168__auto____8 }
//line :543:1
			break L2 }; case 1: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_107) { var and__1927000168__auto____8_2 any = t.F_same_line_QMARK_
				if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_1352 any = A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = ls__2; if linked_1353 == nil { keep_QMARK___7 = ifn_1354.Invoke_O__O(arg_1355) } else { keep_QMARK___7 = linked_1353.(*A_arbace_repr_go_print_emit_semi_after_QMARK__A).Invoke_O_O__O(root_1352, arg_1355) } } else { keep_QMARK___7 = and__1927000168__auto____8_2 }
//line :543:1
				break L2 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__308000232__7_)))))
		}

			if jrt.J2g_Truth(keep_QMARK___7) {
				var tmp7 jrt.Number_I; var na_1356 any = k__1; if jrt.Long_InstanceOf(na_1356) { var n0_1357 int64 = jrt.NN(jrt.Long_Cast(na_1356)).LongValue__J(); if n0_1357 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1356) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1357 + 1)) } } else { if jrt.Double_InstanceOf(na_1356) { var n0_1357_2 float64 = jrt.NN(jrt.Double_Cast(na_1356)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1357_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1356) } }; var tmp8 any = tmp7; var tmp9 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4); var tmp10 any; var root_1358 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = acc__3; var tmp11 any = A_arbace_repr_go_print_emit_A_const_72; var arg_1362 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4), A_arbace_repr_go_print_emit_A_const_74, jrt.Boolean_FALSE.Ref())); if linked_1359 == nil { tmp10 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { tmp10 = linked_1359.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; k__1, ls__2, acc__3 = tmp8, tmp9, tmp10; continue L1 } else {
					var tmp12 jrt.Number_I; var na_1363 any = k__1; if jrt.Long_InstanceOf(na_1363) { var n0_1364 int64 = jrt.NN(jrt.Long_Cast(na_1363)).LongValue__J(); if n0_1364 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1363) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1364 + 1)) } } else { if jrt.Double_InstanceOf(na_1363) { var n0_1364_2 float64 = jrt.NN(jrt.Double_Cast(na_1363)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1364_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1363) } }; k__1, ls__2, acc__3 = tmp12, ls__2, acc__3; continue L1 } } else {
						var tmp13 jrt.Number_I; var na_1365 any = k__1; if jrt.Long_InstanceOf(na_1365) { var n0_1366 int64 = jrt.NN(jrt.Long_Cast(na_1365)).LongValue__J(); if n0_1366 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_1365) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1366 + 1)) } } else { if jrt.Double_InstanceOf(na_1365) { var n0_1366_2 float64 = jrt.NN(jrt.Double_Cast(na_1365)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1366_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_1365) } }; var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4); var tmp16 any; var root_1367 any = A_arbace_repr_go_print_emit_A_const_8.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = acc__3; var arg_1371 any = x__4; if linked_1368 == nil { tmp16 = ifn_1369.Invoke_O_O__O(arg_1370, arg_1371) } else { tmp16 = linked_1368.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1367, arg_1370, arg_1371) }; k__1, ls__2, acc__3 = tmp14, tmp15, tmp16; continue L1 } } else {
//line :540:1
							return acc__3 } } }; /*line :539:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(p0 any) *A_arbace_repr_go_print_emit_full_result_fn__308000234_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000234_A{}; t.Ctor_O(p0); return t }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Invoke_O_O__O(self, p1__308000147_SHARP___1 any) any { var tmp1 any; var root_1387 any = A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000147_SHARP___1); if linked_1388 == nil { tmp1 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp1 = linked_1388.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1387, arg_1390) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp1), lang.RT_LongCast_O__J_NoInit(t.F_cl))).Ref() }

func A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000236_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000236_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Ctor() {}
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Invoke_O_O__O(self, p1__308000148_SHARP___1 any) any { var root_1408 any = A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1408, A_arbace_repr_go_print_emit_utf8_len_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000148_SHARP___1); if linked_1409 == nil { return ifn_1410.Invoke_O__O(arg_1411) } else { return jrt.Long_ValueOf_J__Long_NoInit(linked_1409.(*A_arbace_repr_go_print_emit_utf8_len_A).InvokePrim_O_O__J(root_1408, arg_1411)).Ref() } }
func A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000238_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000238_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Ctor_O_O_O(c__obstacles, c__width, c__cur any) { t.F_obstacles = c__obstacles; t.F_width = c__width; t.F_cur = c__cur }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Invoke_O__O(self any) any { { var k__1 int64 = 0; var c__2 int64; var tmp1 any; var root_1413 any = A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var root_1417 any = A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var t_ any = t.F_cur; t.F_cur = nil; arg_1420 = t_; if linked_1418 == nil { arg_1416 = ifn_1419.Invoke_O__O(arg_1420) } else { arg_1416 = linked_1418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1417, arg_1420) }; if linked_1414 == nil { tmp1 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp1 = linked_1414.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1413, arg_1416) }; c__2 = lang.RT_LongCast_O__J_NoInit(tmp1); L1: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(k__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_obstacles)))) { var tmp2 any = t.F_obstacles; var o__3 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(k__1)); var oc__4 int64; var tmp3 any; var root_1421 any = A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1423 lang.IFn

		if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3); if linked_1422 == nil { tmp3 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp3 = linked_1422.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1421, arg_1424) }; oc__4 = lang.RT_LongCast_O__J_NoInit(tmp3)
		var tmp4 bool; var na_1425 int64 = lang.Numbers_Minus_J_J__J_NoInit(oc__4, c__2); var na_1426 any; var na_1427 any = t.F_width; var na_1428 int64 = 1; if jrt.Long_InstanceOf(na_1427) { var n0_1429 int64 = jrt.NN(jrt.Long_Cast(na_1427)).LongValue__J(); var n1_1430 int64 = na_1428; var nr_1431 int64 = n0_1429 + n1_1430; if (n0_1429^nr_1431)&(n1_1430^nr_1431) >= 0 { na_1426 = jrt.Long_ValueOf_J__Long_NoInit(nr_1431).Ref() } else { na_1426 = lang.Numbers_Add_O_J__Number_NoInit(na_1427, na_1428) } } else { na_1426 = lang.Numbers_Add_O_J__Number_NoInit(na_1427, na_1428) }; if jrt.Long_InstanceOf(na_1426) { var n0_1432 int64 = na_1425; var n1_1433 int64 = jrt.NN(jrt.Long_Cast(na_1426)).LongValue__J(); tmp4 = n0_1432 >= n1_1433 } else { tmp4 = lang.Numbers_Gte_J_O__Z_NoInit(na_1425, na_1426) }; if tmp4 { return jrt.Long_ValueOf_J__Long_NoInit(k__1).Ref() } else {

			var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(k__1); var tmp6 any; var root_1435 any = A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any; var root_1439 any = A_arbace_repr_go_print_emit_A_const_147.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, A_arbace_repr_go_print_emit_end_of_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3); var arg_1443 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(o__3); if linked_1440 == nil { arg_1438 = ifn_1441.Invoke_O_O__O(arg_1442, arg_1443) } else { arg_1438 = linked_1440.(*A_arbace_repr_go_print_emit_end_of_A).Invoke_O_O_O__O(root_1439, arg_1442, arg_1443) }; if linked_1436 == nil { tmp6 = ifn_1437.Invoke_O__O(arg_1438) } else { tmp6 = linked_1436.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1435, arg_1438) }; k__1, c__2 = tmp5, lang.RT_LongCast_O__J_NoInit(tmp6); continue L1 } } else {
				return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(0, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_obstacles))))).Ref() } } }; /*line :556:1*/panic("j2g: unreachable") }
















type A_arbace_repr_go_print_emit_A struct{ jrt.Object }

var A_arbace_repr_go_print_emit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_emit_A_const_0 *lang.Var

var A_arbace_repr_go_print_emit_A_const_1 any

var A_arbace_repr_go_print_emit_A_const_2 any

var A_arbace_repr_go_print_emit_A_const_3 *lang.Var

var A_arbace_repr_go_print_emit_A_const_4 any

var A_arbace_repr_go_print_emit_A_const_5 *lang.Var

var A_arbace_repr_go_print_emit_A_const_6 *lang.Var

var A_arbace_repr_go_print_emit_A_const_7 *lang.Var

var A_arbace_repr_go_print_emit_A_const_8 *lang.Var

var A_arbace_repr_go_print_emit_A_const_9 any

var A_arbace_repr_go_print_emit_A_const_10 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_11 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_12 *lang.Var

var A_arbace_repr_go_print_emit_A_const_13 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_14 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_15 *lang.Var

var A_arbace_repr_go_print_emit_A_const_16 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_17 any

var A_arbace_repr_go_print_emit_A_const_18 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_19 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_20 any

var A_arbace_repr_go_print_emit_A_const_21 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_23 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_24 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_25 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_26 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_27 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_29 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_30 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_31 *lang.Var

var A_arbace_repr_go_print_emit_A_const_32 *lang.Var

var A_arbace_repr_go_print_emit_A_const_33 *lang.Var

var A_arbace_repr_go_print_emit_A_const_34 *lang.Var

var A_arbace_repr_go_print_emit_A_const_35 any

var A_arbace_repr_go_print_emit_A_const_36 any

var A_arbace_repr_go_print_emit_A_const_37 any

var A_arbace_repr_go_print_emit_A_const_38 any

var A_arbace_repr_go_print_emit_A_const_39 any

var A_arbace_repr_go_print_emit_A_const_40 *lang.Var

var A_arbace_repr_go_print_emit_A_const_41 any

var A_arbace_repr_go_print_emit_A_const_42 any

var A_arbace_repr_go_print_emit_A_const_43 any

var A_arbace_repr_go_print_emit_A_const_44 *lang.Var

var A_arbace_repr_go_print_emit_A_const_45 *lang.Var

var A_arbace_repr_go_print_emit_A_const_46 any

var A_arbace_repr_go_print_emit_A_const_47 any

var A_arbace_repr_go_print_emit_A_const_48 any

var A_arbace_repr_go_print_emit_A_const_49 any

var A_arbace_repr_go_print_emit_A_const_50 any

var A_arbace_repr_go_print_emit_A_const_51 *lang.Var

var A_arbace_repr_go_print_emit_A_const_52 *lang.Var

var A_arbace_repr_go_print_emit_A_const_53 any

var A_arbace_repr_go_print_emit_A_const_54 *lang.Var

var A_arbace_repr_go_print_emit_A_const_55 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_56 any

var A_arbace_repr_go_print_emit_A_const_57 any

var A_arbace_repr_go_print_emit_A_const_58 any

var A_arbace_repr_go_print_emit_A_const_59 any

var A_arbace_repr_go_print_emit_A_const_60 any

var A_arbace_repr_go_print_emit_A_const_61 any

var A_arbace_repr_go_print_emit_A_const_62 any

var A_arbace_repr_go_print_emit_A_const_63 any

var A_arbace_repr_go_print_emit_A_const_64 any

var A_arbace_repr_go_print_emit_A_const_65 any

var A_arbace_repr_go_print_emit_A_const_66 any

var A_arbace_repr_go_print_emit_A_const_67 any

var A_arbace_repr_go_print_emit_A_const_68 *lang.Var

var A_arbace_repr_go_print_emit_A_const_69 any

var A_arbace_repr_go_print_emit_A_const_70 *lang.Var

var A_arbace_repr_go_print_emit_A_const_71 any

var A_arbace_repr_go_print_emit_A_const_72 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_73 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_74 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_75 *lang.Var

var A_arbace_repr_go_print_emit_A_const_76 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_77 *lang.Var

var A_arbace_repr_go_print_emit_A_const_78 *lang.Var

var A_arbace_repr_go_print_emit_A_const_79 any

var A_arbace_repr_go_print_emit_A_const_80 *lang.Var

var A_arbace_repr_go_print_emit_A_const_81 *lang.Var

var A_arbace_repr_go_print_emit_A_const_82 *lang.Var

var A_arbace_repr_go_print_emit_A_const_83 *lang.Var

var A_arbace_repr_go_print_emit_A_const_84 any

var A_arbace_repr_go_print_emit_A_const_85 any

var A_arbace_repr_go_print_emit_A_const_86 *lang.Var

var A_arbace_repr_go_print_emit_A_const_87 any

var A_arbace_repr_go_print_emit_A_const_88 *lang.Var

var A_arbace_repr_go_print_emit_A_const_89 *lang.Var

var A_arbace_repr_go_print_emit_A_const_90 *lang.Var

var A_arbace_repr_go_print_emit_A_const_91 *lang.Var

var A_arbace_repr_go_print_emit_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_93 *lang.Var

var A_arbace_repr_go_print_emit_A_const_94 *lang.Var

var A_arbace_repr_go_print_emit_A_const_95 *lang.Var

var A_arbace_repr_go_print_emit_A_const_96 *lang.Var

var A_arbace_repr_go_print_emit_A_const_97 *lang.Var

var A_arbace_repr_go_print_emit_A_const_98 *lang.Var

var A_arbace_repr_go_print_emit_A_const_99 *lang.Var

var A_arbace_repr_go_print_emit_A_const_100 any

var A_arbace_repr_go_print_emit_A_const_101 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_102 *lang.Var

var A_arbace_repr_go_print_emit_A_const_103 *lang.Var

var A_arbace_repr_go_print_emit_A_const_104 *lang.Var

var A_arbace_repr_go_print_emit_A_const_105 *lang.Var

var A_arbace_repr_go_print_emit_A_const_106 *lang.Var

var A_arbace_repr_go_print_emit_A_const_107 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_108 *lang.Var

var A_arbace_repr_go_print_emit_A_const_109 *lang.Var

var A_arbace_repr_go_print_emit_A_const_110 *lang.Var

var A_arbace_repr_go_print_emit_A_const_111 any

var A_arbace_repr_go_print_emit_A_const_112 *lang.Var

var A_arbace_repr_go_print_emit_A_const_113 *lang.Var

var A_arbace_repr_go_print_emit_A_const_114 *lang.Var

var A_arbace_repr_go_print_emit_A_const_115 *lang.Var

var A_arbace_repr_go_print_emit_A_const_116 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_117 *lang.Var

var A_arbace_repr_go_print_emit_A_const_118 *lang.Var

var A_arbace_repr_go_print_emit_A_const_119 *lang.Var

var A_arbace_repr_go_print_emit_A_const_120 *lang.Var

var A_arbace_repr_go_print_emit_A_const_121 *lang.Var

var A_arbace_repr_go_print_emit_A_const_122 *lang.Var

var A_arbace_repr_go_print_emit_A_const_123 *lang.Var

var A_arbace_repr_go_print_emit_A_const_124 *lang.Var

var A_arbace_repr_go_print_emit_A_const_125 *lang.Var

var A_arbace_repr_go_print_emit_A_const_126 *lang.Var

var A_arbace_repr_go_print_emit_A_const_127 *lang.Var

var A_arbace_repr_go_print_emit_A_const_128 *lang.Var

var A_arbace_repr_go_print_emit_A_const_129 *lang.Var

var A_arbace_repr_go_print_emit_A_const_130 *lang.Var

var A_arbace_repr_go_print_emit_A_const_131 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_132 *lang.Var

var A_arbace_repr_go_print_emit_A_const_133 *lang.Var

var A_arbace_repr_go_print_emit_A_const_134 any

var A_arbace_repr_go_print_emit_A_const_135 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_136 *lang.Var

var A_arbace_repr_go_print_emit_A_const_137 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_138 *lang.Var

var A_arbace_repr_go_print_emit_A_const_139 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_140 *lang.Var

var A_arbace_repr_go_print_emit_A_const_141 *lang.Var

var A_arbace_repr_go_print_emit_A_const_142 *lang.Var

var A_arbace_repr_go_print_emit_A_const_143 *lang.Var

var A_arbace_repr_go_print_emit_A_const_144 *lang.Var

var A_arbace_repr_go_print_emit_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_146 any

var A_arbace_repr_go_print_emit_A_const_147 *lang.Var

var A_arbace_repr_go_print_emit_A_const_148 *lang.Var

var A_arbace_repr_go_print_emit_A_const_149 *lang.Var

var A_arbace_repr_go_print_emit_A_const_150 *lang.Var

var A_arbace_repr_go_print_emit_A_const_151 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_152 *lang.Var

var A_arbace_repr_go_print_emit_A_const_153 *lang.Var

var A_arbace_repr_go_print_emit_A_const_154 *lang.Var

var A_arbace_repr_go_print_emit_A_const_155 *lang.Var

var A_arbace_repr_go_print_emit_A_init jrt.ClassInit

func A_arbace_repr_go_print_emit_A_Init() { if !A_arbace_repr_go_print_emit_A_init.Done() { A_arbace_repr_go_print_emit_A_init.Run(A_arbace_repr_go_print_emit_A_clinit) } }

func A_arbace_repr_go_print_emit_A_clinit() { A_arbace_repr_go_print_emit_A_clinit_p0(); A_arbace_repr_go_print_emit_A_clinit_p1(); A_arbace_repr_go_print_emit_A_clinit_p2(); A_arbace_repr_go_print_emit_A_clinit_p3(); A_arbace_repr_go_print_emit_A_clinit_p4(); A_arbace_repr_go_print_emit_A_clinit_p5(); A_arbace_repr_go_print_emit_A_clinit_p6(); A_arbace_repr_go_print_emit_A_clinit_p7(); A_arbace_repr_go_print_emit_A_clinit_p8(); A_arbace_repr_go_print_emit_A_clinit_p9(); A_arbace_repr_go_print_emit_A_clinit_p10(); A_arbace_repr_go_print_emit_A_clinit_p11(); A_arbace_repr_go_print_emit_A_clinit_p12() }

func A_arbace_repr_go_print_emit_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 204); A_arbace_repr_go_print_emit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[48]); A_arbace_repr_go_print_emit_A_const_1 = A_arbace_repr_go_print_emit_A_const_pool.A[49]; A_arbace_repr_go_print_emit_A_const_2 = A_arbace_repr_go_print_emit_A_const_pool.A[50]; A_arbace_repr_go_print_emit_A_const_3 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[51]); A_arbace_repr_go_print_emit_A_const_4 = A_arbace_repr_go_print_emit_A_const_pool.A[52]; A_arbace_repr_go_print_emit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[53]); A_arbace_repr_go_print_emit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[54]); A_arbace_repr_go_print_emit_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[55]); A_arbace_repr_go_print_emit_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[56]); A_arbace_repr_go_print_emit_A_const_9 = A_arbace_repr_go_print_emit_A_const_pool.A[57]; A_arbace_repr_go_print_emit_A_const_10 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[58]); A_arbace_repr_go_print_emit_A_const_11 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[59]) }

func A_arbace_repr_go_print_emit_A_clinit_p1() { A_arbace_repr_go_print_emit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[60]); A_arbace_repr_go_print_emit_A_const_13 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[61]); A_arbace_repr_go_print_emit_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[62]); A_arbace_repr_go_print_emit_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[63]); A_arbace_repr_go_print_emit_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[64]); A_arbace_repr_go_print_emit_A_const_17 = A_arbace_repr_go_print_emit_A_const_pool.A[65]; A_arbace_repr_go_print_emit_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[66]); A_arbace_repr_go_print_emit_A_const_19 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[67]); A_arbace_repr_go_print_emit_A_const_20 = A_arbace_repr_go_print_emit_A_const_pool.A[68]; A_arbace_repr_go_print_emit_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[69]); A_arbace_repr_go_print_emit_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[70]); A_arbace_repr_go_print_emit_A_const_23 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[71]) }

func A_arbace_repr_go_print_emit_A_clinit_p2() { A_arbace_repr_go_print_emit_A_const_24 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[72]); A_arbace_repr_go_print_emit_A_const_25 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[73]); A_arbace_repr_go_print_emit_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[74]); A_arbace_repr_go_print_emit_A_const_27 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[75]); A_arbace_repr_go_print_emit_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[76]); A_arbace_repr_go_print_emit_A_const_29 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[77]); A_arbace_repr_go_print_emit_A_const_30 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[78]); A_arbace_repr_go_print_emit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[79]); A_arbace_repr_go_print_emit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[80]); A_arbace_repr_go_print_emit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[81]); A_arbace_repr_go_print_emit_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[82]); A_arbace_repr_go_print_emit_A_const_35 = A_arbace_repr_go_print_emit_A_const_pool.A[83] }

func A_arbace_repr_go_print_emit_A_clinit_p3() { A_arbace_repr_go_print_emit_A_const_36 = A_arbace_repr_go_print_emit_A_const_pool.A[84]; A_arbace_repr_go_print_emit_A_const_37 = A_arbace_repr_go_print_emit_A_const_pool.A[85]; A_arbace_repr_go_print_emit_A_const_38 = A_arbace_repr_go_print_emit_A_const_pool.A[86]; A_arbace_repr_go_print_emit_A_const_39 = A_arbace_repr_go_print_emit_A_const_pool.A[87]; A_arbace_repr_go_print_emit_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[88]); A_arbace_repr_go_print_emit_A_const_41 = A_arbace_repr_go_print_emit_A_const_pool.A[89]; A_arbace_repr_go_print_emit_A_const_42 = A_arbace_repr_go_print_emit_A_const_pool.A[90]; A_arbace_repr_go_print_emit_A_const_43 = A_arbace_repr_go_print_emit_A_const_pool.A[91]; A_arbace_repr_go_print_emit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[92]); A_arbace_repr_go_print_emit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[93]); A_arbace_repr_go_print_emit_A_const_46 = A_arbace_repr_go_print_emit_A_const_pool.A[94]; A_arbace_repr_go_print_emit_A_const_47 = A_arbace_repr_go_print_emit_A_const_pool.A[95]; A_arbace_repr_go_print_emit_A_const_48 = A_arbace_repr_go_print_emit_A_const_pool.A[96]; A_arbace_repr_go_print_emit_A_const_49 = A_arbace_repr_go_print_emit_A_const_pool.A[97]; A_arbace_repr_go_print_emit_A_const_50 = A_arbace_repr_go_print_emit_A_const_pool.A[98] }

func A_arbace_repr_go_print_emit_A_clinit_p4() { A_arbace_repr_go_print_emit_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[99]); A_arbace_repr_go_print_emit_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[100]); A_arbace_repr_go_print_emit_A_const_53 = A_arbace_repr_go_print_emit_A_const_pool.A[101]; A_arbace_repr_go_print_emit_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[102]); A_arbace_repr_go_print_emit_A_const_55 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[103]); A_arbace_repr_go_print_emit_A_const_56 = A_arbace_repr_go_print_emit_A_const_pool.A[104]; A_arbace_repr_go_print_emit_A_const_57 = A_arbace_repr_go_print_emit_A_const_pool.A[105]; A_arbace_repr_go_print_emit_A_const_58 = A_arbace_repr_go_print_emit_A_const_pool.A[106]; A_arbace_repr_go_print_emit_A_const_59 = A_arbace_repr_go_print_emit_A_const_pool.A[107]; A_arbace_repr_go_print_emit_A_const_60 = A_arbace_repr_go_print_emit_A_const_pool.A[108]; A_arbace_repr_go_print_emit_A_const_61 = A_arbace_repr_go_print_emit_A_const_pool.A[109]; A_arbace_repr_go_print_emit_A_const_62 = A_arbace_repr_go_print_emit_A_const_pool.A[110]; A_arbace_repr_go_print_emit_A_const_63 = A_arbace_repr_go_print_emit_A_const_pool.A[111]; A_arbace_repr_go_print_emit_A_const_64 = A_arbace_repr_go_print_emit_A_const_pool.A[112] }

func A_arbace_repr_go_print_emit_A_clinit_p5() { A_arbace_repr_go_print_emit_A_const_65 = A_arbace_repr_go_print_emit_A_const_pool.A[113]; A_arbace_repr_go_print_emit_A_const_66 = A_arbace_repr_go_print_emit_A_const_pool.A[114]; A_arbace_repr_go_print_emit_A_const_67 = A_arbace_repr_go_print_emit_A_const_pool.A[115]; A_arbace_repr_go_print_emit_A_const_68 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[116]); A_arbace_repr_go_print_emit_A_const_69 = A_arbace_repr_go_print_emit_A_const_pool.A[117]; A_arbace_repr_go_print_emit_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[118]); A_arbace_repr_go_print_emit_A_const_71 = A_arbace_repr_go_print_emit_A_const_pool.A[119]; A_arbace_repr_go_print_emit_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[120]); A_arbace_repr_go_print_emit_A_const_73 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[121]); A_arbace_repr_go_print_emit_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[122]); A_arbace_repr_go_print_emit_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[123]); A_arbace_repr_go_print_emit_A_const_76 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[124]); A_arbace_repr_go_print_emit_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[125]) }

func A_arbace_repr_go_print_emit_A_clinit_p6() { A_arbace_repr_go_print_emit_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[126]); A_arbace_repr_go_print_emit_A_const_79 = A_arbace_repr_go_print_emit_A_const_pool.A[127]; A_arbace_repr_go_print_emit_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[128]); A_arbace_repr_go_print_emit_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[129]); A_arbace_repr_go_print_emit_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[130]); A_arbace_repr_go_print_emit_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[131]); A_arbace_repr_go_print_emit_A_const_84 = A_arbace_repr_go_print_emit_A_const_pool.A[132]; A_arbace_repr_go_print_emit_A_const_85 = A_arbace_repr_go_print_emit_A_const_pool.A[133]; A_arbace_repr_go_print_emit_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[134]); A_arbace_repr_go_print_emit_A_const_87 = A_arbace_repr_go_print_emit_A_const_pool.A[135]; A_arbace_repr_go_print_emit_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[136]); A_arbace_repr_go_print_emit_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[137]); A_arbace_repr_go_print_emit_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[138]) }

func A_arbace_repr_go_print_emit_A_clinit_p7() { A_arbace_repr_go_print_emit_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[139]); A_arbace_repr_go_print_emit_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[140]); A_arbace_repr_go_print_emit_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[141]); A_arbace_repr_go_print_emit_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[142]); A_arbace_repr_go_print_emit_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[143]); A_arbace_repr_go_print_emit_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[144]); A_arbace_repr_go_print_emit_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[145]); A_arbace_repr_go_print_emit_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[146]); A_arbace_repr_go_print_emit_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[147]); A_arbace_repr_go_print_emit_A_const_100 = A_arbace_repr_go_print_emit_A_const_pool.A[148]; A_arbace_repr_go_print_emit_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[149]); A_arbace_repr_go_print_emit_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[150]) }

func A_arbace_repr_go_print_emit_A_clinit_p8() { A_arbace_repr_go_print_emit_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[151]); A_arbace_repr_go_print_emit_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[152]); A_arbace_repr_go_print_emit_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[153]); A_arbace_repr_go_print_emit_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[154]); A_arbace_repr_go_print_emit_A_const_107 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[155]); A_arbace_repr_go_print_emit_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[156]); A_arbace_repr_go_print_emit_A_const_109 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[157]); A_arbace_repr_go_print_emit_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[158]); A_arbace_repr_go_print_emit_A_const_111 = A_arbace_repr_go_print_emit_A_const_pool.A[159]; A_arbace_repr_go_print_emit_A_const_112 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[160]); A_arbace_repr_go_print_emit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[161]); A_arbace_repr_go_print_emit_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[162]) }

func A_arbace_repr_go_print_emit_A_clinit_p9() { A_arbace_repr_go_print_emit_A_const_115 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[163]); A_arbace_repr_go_print_emit_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[164]); A_arbace_repr_go_print_emit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[165]); A_arbace_repr_go_print_emit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[166]); A_arbace_repr_go_print_emit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[167]); A_arbace_repr_go_print_emit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[168]); A_arbace_repr_go_print_emit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[169]); A_arbace_repr_go_print_emit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[170]); A_arbace_repr_go_print_emit_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[171]); A_arbace_repr_go_print_emit_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[172]); A_arbace_repr_go_print_emit_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[173]); A_arbace_repr_go_print_emit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[174]) }

func A_arbace_repr_go_print_emit_A_clinit_p10() { A_arbace_repr_go_print_emit_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[175]); A_arbace_repr_go_print_emit_A_const_128 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[176]); A_arbace_repr_go_print_emit_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[177]); A_arbace_repr_go_print_emit_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[178]); A_arbace_repr_go_print_emit_A_const_131 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[179]); A_arbace_repr_go_print_emit_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[180]); A_arbace_repr_go_print_emit_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[181]); A_arbace_repr_go_print_emit_A_const_134 = A_arbace_repr_go_print_emit_A_const_pool.A[182]; A_arbace_repr_go_print_emit_A_const_135 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[183]); A_arbace_repr_go_print_emit_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[184]); A_arbace_repr_go_print_emit_A_const_137 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[185]); A_arbace_repr_go_print_emit_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[186]) }

func A_arbace_repr_go_print_emit_A_clinit_p11() { A_arbace_repr_go_print_emit_A_const_139 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[187]); A_arbace_repr_go_print_emit_A_const_140 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[188]); A_arbace_repr_go_print_emit_A_const_141 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[189]); A_arbace_repr_go_print_emit_A_const_142 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[190]); A_arbace_repr_go_print_emit_A_const_143 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[191]); A_arbace_repr_go_print_emit_A_const_144 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[192]); A_arbace_repr_go_print_emit_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[193]); A_arbace_repr_go_print_emit_A_const_146 = A_arbace_repr_go_print_emit_A_const_pool.A[194]; A_arbace_repr_go_print_emit_A_const_147 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[195]); A_arbace_repr_go_print_emit_A_const_148 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[196]); A_arbace_repr_go_print_emit_A_const_149 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[197]); A_arbace_repr_go_print_emit_A_const_150 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[198]) }

func A_arbace_repr_go_print_emit_A_clinit_p12() { A_arbace_repr_go_print_emit_A_const_151 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[199]); A_arbace_repr_go_print_emit_A_const_152 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[200]); A_arbace_repr_go_print_emit_A_const_153 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[201]); A_arbace_repr_go_print_emit_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[202]); A_arbace_repr_go_print_emit_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[203]) }

func A_arbace_repr_go_print_emit_A_New() *A_arbace_repr_go_print_emit_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_A_class }

func (t *A_arbace_repr_go_print_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_A); return ok }

func A_arbace_repr_go_print_emit_A_Cast(x any) *A_arbace_repr_go_print_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_A_class)) }; return v }



type A_arbace_repr_go_print_emit_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_bol_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_bol_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_break_to_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_break_to_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_chunk_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_chunk_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_close_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_close_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_comment_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_comment_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cont_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cont_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cur_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cur_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_fn__308000120_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000004_A_New() *A_arbace_repr_go_print_emit_eval308000004_A { t := &A_arbace_repr_go_print_emit_eval308000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000004_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); return ok }

func A_arbace_repr_go_print_emit_eval308000004_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000004_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000008_A_New() *A_arbace_repr_go_print_emit_eval308000008_A { t := &A_arbace_repr_go_print_emit_eval308000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000008_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); return ok }

func A_arbace_repr_go_print_emit_eval308000008_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000008_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000018_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000018_A_New() *A_arbace_repr_go_print_emit_eval308000018_A { t := &A_arbace_repr_go_print_emit_eval308000018_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000018_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); return ok }

func A_arbace_repr_go_print_emit_eval308000018_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000018_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000029_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000029_A_New() *A_arbace_repr_go_print_emit_eval308000029_A { t := &A_arbace_repr_go_print_emit_eval308000029_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000029_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); return ok }

func A_arbace_repr_go_print_emit_eval308000029_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000029_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000040_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000040_A_New() *A_arbace_repr_go_print_emit_eval308000040_A { t := &A_arbace_repr_go_print_emit_eval308000040_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000040_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); return ok }

func A_arbace_repr_go_print_emit_eval308000040_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000040_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000040_line__308000041_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000051_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000051_A_New() *A_arbace_repr_go_print_emit_eval308000051_A { t := &A_arbace_repr_go_print_emit_eval308000051_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000051_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); return ok }

func A_arbace_repr_go_print_emit_eval308000051_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000051_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000063_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000063_A_New() *A_arbace_repr_go_print_emit_eval308000063_A { t := &A_arbace_repr_go_print_emit_eval308000063_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000063_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); return ok }

func A_arbace_repr_go_print_emit_eval308000063_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000063_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000063_target__308000064_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000089_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000089_A_New() *A_arbace_repr_go_print_emit_eval308000089_A { t := &A_arbace_repr_go_print_emit_eval308000089_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000089_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); return ok }

func A_arbace_repr_go_print_emit_eval308000089_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000089_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000149_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000152_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000158_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000164_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_A struct{ j2g_header uint64; F_extras, F_items any }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000184_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000227_A struct{ j2g_header uint64; F_merged any; F_n int32; F_i any }

var A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000229_A struct{ j2g_header uint64; F_merged any; F_n int32; F_j any }

var A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000231_A struct{ j2g_header uint64; F_last_s, F_merged, F_tok_STAR_, F_j, F_i, F_same_line_QMARK_ any }

var A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000234_A struct{ j2g_header uint64; F_cl any }

var A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000236_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000238_A struct{ j2g_header uint64; F_obstacles, F_width, F_cur any }

var A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A struct{ j2g_header uint64; F_space, F_last_s, F_sb, F_prev_item, F_cur any }

var A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_join_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_join_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_comment_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_inline_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_own_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_own_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_lines_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_lines_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_may_combine_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_new_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_new_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_nl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_nl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000130_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000137_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000139_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000141_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000143_A struct{ j2g_header uint64; F_keep any }

var A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_natural__308000132_A struct{ j2g_header uint64; F_cl any; F_n int32; F_run, F_lens, F_cc any }

var A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_pop_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_pop_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_push_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_render_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_render_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_room_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_room_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_semi_after_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_set_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_soft_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_soft_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_sp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_sp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_stmt_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A struct{ j2g_header uint64; F_indent any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A struct{ j2g_header uint64; F_first_QMARK_, F_sep any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_utf8_len_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_utf8_len_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_vtab_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_vtab_A_fn_class *jrt.Class
