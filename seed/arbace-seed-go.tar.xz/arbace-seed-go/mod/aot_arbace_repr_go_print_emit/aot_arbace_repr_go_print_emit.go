//line aot_arbace_repr_go_print_emit.ae:1
package aot_arbace_repr_go_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_New() *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_3, A_arbace_repr_go_print_emit_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_New() *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_9), A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O(), A_arbace_repr_go_print_emit_A_const_8) }

















func A_arbace_repr_go_print_emit_new_state_A_New() *A_arbace_repr_go_print_emit_new_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_new_state_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Invoke_O_O__O(self, opts__0 any) any { var tmp1 any = A_arbace_repr_go_print_emit_A_const_10; var tmp2 any = jrt.StringBuilder_New(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_11; var tmp4 any; var temp__1927000414__auto____2 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(opts__0); if







	jrt.J2g_Truth(temp__1927000414__auto____2) { var f__3 any = temp__1927000414__auto____2; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_emit_A_const_27; var tmp7 any = jrt.ArrayList_New(); var tmp8 any = A_arbace_repr_go_print_emit_A_const_28
		tmp4 = tmp5.Invoke_O_O_O_O_O__O(f__3, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil)) } else {
//line :27:1
			tmp4 = nil }; var tmp9 any = tmp4; var tmp10 any = A_arbace_repr_go_print_emit_A_const_13; var tmp11 any = /*line :19:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29); var tmp12 any = A_arbace_repr_go_print_emit_A_const_15; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp13.Invoke_O__O(tmp14.Ref()); var tmp16 any = A_arbace_repr_go_print_emit_A_const_16; var tmp17 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp18 any = A_arbace_repr_go_print_emit_A_const_17; var tmp19 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp20 any = A_arbace_repr_go_print_emit_A_const_18; var tmp21 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_2); var tmp22 any = A_arbace_repr_go_print_emit_A_const_19; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_FALSE; var tmp25 any = tmp23.Invoke_O__O(tmp24.Ref()); var tmp26 any = A_arbace_repr_go_print_emit_A_const_20; var tmp27 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil); var tmp28 any = A_arbace_repr_go_print_emit_A_const_21; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()); var tmp30 *lang.PersistentVector; lang.PersistentVector_Init(); tmp30 = lang.PersistentVector_EMPTY; var tmp31 any = tmp29.Invoke_O__O(tmp30.Ref()); var tmp32 any = A_arbace_repr_go_print_emit_A_const_22; var tmp33 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp34 any = A_arbace_repr_go_print_emit_A_const_23; var tmp35 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29); var tmp36 any = A_arbace_repr_go_print_emit_A_const_24; var tmp37 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(opts__0))).Ref(); var tmp38 any = A_arbace_repr_go_print_emit_A_const_25; var tmp39 lang.IFn = A_arbace_repr_go_print_emit_A_const_26; var tmp40 *jrt.Boolean; jrt.Boolean_Init(); tmp40 = jrt.Boolean_TRUE; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp9, tmp10, tmp11, tmp12, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp25, tmp26, tmp27, tmp28, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39.Invoke_O_O__O(opts__0, tmp40.Ref()))) }






















func A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_New() *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_24), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_35))) }
//line :42:1
func A_arbace_repr_go_print_emit_lines_QMARK__A_New() *A_arbace_repr_go_print_emit_lines_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_lines_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_New() *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_11), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_36))) }
//line :43:1
func A_arbace_repr_go_print_emit_full_QMARK__A_New() *A_arbace_repr_go_print_emit_full_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_QMARK__A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_New() *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000040_line__308000041_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_38)))))) }
//line :44:1
func A_arbace_repr_go_print_emit_line_A_New() *A_arbace_repr_go_print_emit_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
func A_arbace_repr_go_print_emit_bol_QMARK__A_New() *A_arbace_repr_go_print_emit_bol_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_bol_QMARK__A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
//line :45:1
func A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_New() *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_39)))))) }

func A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_New() *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000063_target__308000064_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Invoke_O_O__O(self, f__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_41), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_42)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_43), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_47), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(f__1))))))))))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_48), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_49), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_50), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46)))))))))))) }
//line :47:1
func A_arbace_repr_go_print_emit_target_A_New() *A_arbace_repr_go_print_emit_target_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_target_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }







func A_arbace_repr_go_print_emit_room_QMARK__A_New() *A_arbace_repr_go_print_emit_room_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_room_QMARK__A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); if



	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(A_arbace_repr_go_print_emit_A_const_52.Get__O(), nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(A_arbace_repr_go_print_emit_A_const_52.Get__O()), lang.Numbers_Add_O_J__Number(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())), lang.RT_LongCast_O__J(n__0)))).Ref() } } }









func A_arbace_repr_go_print_emit_semi_after_QMARK__A_New() *A_arbace_repr_go_print_emit_semi_after_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_semi_after_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_53).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { var c__2 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())))); var or__1927000174__auto____3 bool = jrt.Character_IsLetterOrDigit_C__Z(c__2)




		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_57)).CharValue__C()); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_58)).CharValue__C()); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_59)).CharValue__C()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else {
			return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_IntCast_C__I(c__2)), 127)).Ref() } } } } } } else {
//line :72:1
				return nil
			}
	}
	}
	}
}


func A_arbace_repr_go_print_emit_may_combine_QMARK__A_New() *A_arbace_repr_go_print_emit_may_combine_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_may_combine_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Invoke_O_O_O__O(self, prev__0, next__1 any) any {



	var tmp1 bool; var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())); if and__1927000168__auto____3 { tmp1 = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(next__1)).Length__I())) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var p__3 uint16 = jrt.NN(jrt.String_Cast(prev__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())))); var n__4 uint16 = jrt.NN(jrt.String_Cast(next__1)).CharAt_I__C(lang.RT_IntCast_J__I(0)); var or__1927000174__auto____5 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_28)


		if and__1927000168__auto____5 { or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_60)).CharValue__C()) } else { or__1927000174__auto____5 = and__1927000168__auto____5 }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_29)
			if and__1927000168__auto____6 { or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :87:1
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C())

				if and__1927000168__auto____7 { var or__1927000174__auto____8 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_63)).CharValue__C()); if or__1927000174__auto____8 { or__1927000174__auto____7 = or__1927000174__auto____8 } else { or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C()) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :87:1
				if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8_2 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_30)


					if and__1927000168__auto____8 { var or__1927000174__auto____9 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()); if or__1927000174__auto____9 { or__1927000174__auto____8_2 = or__1927000174__auto____9 } else { or__1927000174__auto____8_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_64)).CharValue__C()) } } else { or__1927000174__auto____8_2 = and__1927000168__auto____8 }
//line :87:1
					if or__1927000174__auto____8_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8_2).Ref() } else { var or__1927000174__auto____9_2 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_31)



						if and__1927000168__auto____9 { var or__1927000174__auto____10 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_65)).CharValue__C()); if or__1927000174__auto____10 { or__1927000174__auto____9_2 = or__1927000174__auto____10 } else { or__1927000174__auto____9_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_66)).CharValue__C()) } } else { or__1927000174__auto____9_2 = and__1927000168__auto____9 }
//line :87:1
						if or__1927000174__auto____9_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9_2).Ref() } else { var or__1927000174__auto____10_2 any; var and__1927000168__auto____10 bool = jrt.Character_IsDigit_C__Z(p__3)




							if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_67)).CharValue__C()); if and__1927000168__auto____11 { or__1927000174__auto____10_2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_68.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_69, prev__0) } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }
//line :87:1
							if jrt.J2g_Truth(or__1927000174__auto____10_2) { return or__1927000174__auto____10_2 } else { var and__1927000168__auto____11_2 bool; var or__1927000174__auto____11 bool = jrt.Character_IsLetterOrDigit_C__Z(p__3)





								if or__1927000174__auto____11 { and__1927000168__auto____11_2 = or__1927000174__auto____11 } else { and__1927000168__auto____11_2 = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()) }; if and__1927000168__auto____11_2 { var or__1927000174__auto____12 bool = jrt.Character_IsLetterOrDigit_C__Z(n__4)
									if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C())).Ref() } } else {
//line :93:1
										return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11_2).Ref() } } } } } } } } else {
//line :84:1
											return nil
										}
}









func A_arbace_repr_go_print_emit_start_line_BANG__A_New() *A_arbace_repr_go_print_emit_start_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_line_BANG__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1))) { var n__2 int64 = lang.Numbers_Max_J_J__J(0, lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__1)))); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J(n__2); var ___5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(___5, n__1927000701__auto____4) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___5 = lang.Numbers_Unchecked_inc_J__J(___5); continue L1 }
//line :98:1
		break L1
	}


		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__1), jrt.Long_ValueOf_J__Long(n__2).Ref())
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__1), nil) } else {
//line :98:1
			return nil } }







func A_arbace_repr_go_print_emit_at_BANG__A_New() *A_arbace_repr_go_print_emit_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_at_BANG__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Invoke_O_O__O(self, pos__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var fs__3 any = temp__1927000414__auto____2
		if jrt.J2g_Truth(pos__0) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3), pos__0) }
//line :109:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_full_tok_A_New() *A_arbace_repr_go_print_emit_full_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_tok_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Invoke_O_O__O(self, s__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var fs__3 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(p__2); var pos__4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3));





	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3), nil); var tmp1 /*line :120:1*/*jrt.ArrayList = jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__3)); var tmp2 any = A_arbace_repr_go_print_emit_A_const_72; var tmp3 any = A_arbace_repr_go_print_emit_A_const_73; var tmp4 any = A_arbace_repr_go_print_emit_A_const_74; var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2)); if
	jrt.J2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2)), s__0) }; /*line :120:1*/jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp1).Add_O__Z(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, s__0, tmp3, pos__4, tmp4, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp5)).Ref()))));

	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil);
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2), s__0); return nil }


func A_arbace_repr_go_print_emit_soft_A_New() *A_arbace_repr_go_print_emit_soft_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_soft_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Invoke_O_O_O__O(self, kind__0, s__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____3 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if




	jrt.J2g_Truth(temp__1927000414__auto____3) { var fs__4 any = temp__1927000414__auto____3
		jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__4))).Add_O__Z(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_emit_A_const_76, kind__0, A_arbace_repr_go_print_emit_A_const_72, s__1))))
//line :131:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_tok_A_New() *A_arbace_repr_go_print_emit_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_tok_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O()).Invoke_O__O(s__0) } else {
//line :138:1
			var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2); var at_bol__4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__2))



			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O()
//line :138:1
			var ws__5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2))





			if jrt.J2g_Truth(at_bol__4) { } else { if jrt.J2g_Truth(ws__5) {

				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) } else {
//line :144:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2)), s__0)) {


						jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } }
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil)
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(s__0))
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2), s__0)
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(s__0))
//line :138:1
			return nil
		}
}













func A_arbace_repr_go_print_emit_raw_tok_A_New() *A_arbace_repr_go_print_emit_raw_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Ctor() {}
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O()).Invoke_O__O(s__0) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(s__0))
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var tmp3 *lang.Volatile = lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var tmp5 any = jrt.NN(lang.Volatile_Cast(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New(); var tmp8 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class = fncls__1d; tmp8 = fncls__1d } else { tmp8 = fncls__1 }; jrt.NN(tmp3).Reset_O__O(lang.Numbers_Add_O_J__Number(tmp5, int64(lang.RT_Count_O__I(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), s__0)))))
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var tmp11 any = tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; return tmp9.Invoke_O_O__O(tmp11, tmp12.Ref()) } }
//line :161:1
func A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New() *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Invoke_O_O__O(self, p1__308000077_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__308000077_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }


func A_arbace_repr_go_print_emit_sp_A_New() *A_arbace_repr_go_print_emit_sp_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_sp_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Ctor() {}
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79) } else {
			var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else {
				var tmp4 any = A_arbace_repr_go_print_emit_A_const_85; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79)
				} } } }
func A_arbace_repr_go_print_emit_vtab_A_New() *A_arbace_repr_go_print_emit_vtab_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_vtab_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79) } else {
			var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else {

				var tmp4 any = A_arbace_repr_go_print_emit_A_const_85; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; jrt.NN(jrt.StringBuilder_Cast(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Append_C__StringBuilder(lang.RT_CharCast_J__C(11)) }
				var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(11)).Ref())
			} } }
func A_arbace_repr_go_print_emit_nl_A_New() *A_arbace_repr_go_print_emit_nl_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_nl_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Ctor() {}
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O_O__O(self, indent__0, form_feed_QMARK___1 any) any {




	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), nil) } else {
//line :187:1
			var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3)


			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3), nil)
			var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp4 uint16; if jrt.J2g_Truth(form_feed_QMARK___1) { tmp4 = lang.RT_CharCast_J__C(12) } else { tmp4 = lang.RT_CharCast_J__C(10) }; jrt.NN(tmp3).Append_C__StringBuilder(tmp4)
			jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3))).Deref__O()))
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3), indent__0)
//line :187:1
			return nil } }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O__O(self, indent__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(indent__0, tmp2.Ref())
}










func A_arbace_repr_go_print_emit_cur_indent_A_New() *A_arbace_repr_go_print_emit_cur_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cur_indent_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_17; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
//line :197:1
func A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_New() *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_87)))))) }

func A_arbace_repr_go_print_emit_push_open_BANG__A_New() *A_arbace_repr_go_print_emit_push_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_push_open_BANG__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O_O__O(self, indent__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), indent__0))
//line :199:1
	return nil }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_88.GetRawRoot__O()); var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_17; tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }; return tmp1.Invoke_O__O(tmp2)
}

func A_arbace_repr_go_print_emit_pop_open_BANG__A_New() *A_arbace_repr_go_print_emit_pop_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_pop_open_BANG__A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Ctor() {}
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var o__1 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))); var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21;

	jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_90.GetRawRoot__O()).Invoke_O__O(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O())); return o__1 }


func A_arbace_repr_go_print_emit_cont_indent_A_New() *A_arbace_repr_go_print_emit_cont_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cont_indent_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Ctor() {}
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var o__1 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))); var tmp2 any; var or__1927000174__auto____2 any = o__1; if



	jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_repr_go_print_emit_A_const_30 }; return jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(tmp2))).Ref() }

func A_arbace_repr_go_print_emit_comment_line_A_New() *A_arbace_repr_go_print_emit_comment_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_comment_line_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Ctor() {}
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Invoke_O_O_O__O(self, s__0, indent__1 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return nil } else { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3)
		var tmp2 /*line :220:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_15

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__1) }
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3); var tmp5 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_1)) { tmp5 = A_arbace_repr_go_print_emit_A_const_30 } else { tmp5 = indent__1 }; tmp3.Invoke_O_O__O(tmp4, tmp5)
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O()
		jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(s__0)))
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3), Lit_2)
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; tmp6.Invoke_O_O__O(tmp7, tmp8.Ref())
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__1)
	} }
func A_arbace_repr_go_print_emit_set_line_BANG__A_New() *A_arbace_repr_go_print_emit_set_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_set_line_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; return jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Min_O_J__O(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J(l__0)))
}














func A_arbace_repr_go_print_emit_start_at_BANG__A_New() *A_arbace_repr_go_print_emit_start_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_at_BANG__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Ctor() {}
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
}
func A_arbace_repr_go_print_emit_chunk_state_A_New() *A_arbace_repr_go_print_emit_chunk_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_chunk_state_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var tmp1 any = A_arbace_repr_go_print_emit_A_const_92; var tmp2 any = jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1))).ToString__String().Ref(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_13; var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__1)); var tmp5 any = A_arbace_repr_go_print_emit_A_const_15; var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1)); var tmp7 any = A_arbace_repr_go_print_emit_A_const_16; var tmp8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__1)); var tmp9 any = A_arbace_repr_go_print_emit_A_const_17; var tmp10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__1)); var tmp11 any = A_arbace_repr_go_print_emit_A_const_18; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__1)); var tmp13 any = A_arbace_repr_go_print_emit_A_const_19; var tmp14 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__1)); var tmp15 any = A_arbace_repr_go_print_emit_A_const_20; var tmp16 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__1)); var tmp17 any = A_arbace_repr_go_print_emit_A_const_21; var tmp18 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__1)); var tmp19 any = A_arbace_repr_go_print_emit_A_const_22; var tmp20 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__1)); var tmp21 any = A_arbace_repr_go_print_emit_A_const_23; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__1)))) }









func A_arbace_repr_go_print_emit_join_BANG__A_New() *A_arbace_repr_go_print_emit_join_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_join_BANG__A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Ctor() {}
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var l__4 int64 = lang.RT_LongCast_O__J(l__1); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3)); if





	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool = lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3)))); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3)), nil); if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_93.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__3))); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Numbers_Lt_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____10 {
		tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_J__Z(lang.RT_LongCast_O__J(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(c__0)), l__4)).Ref() } else {
//line :272:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {

				jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3))).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_92.Invoke_O__O(c__0)))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(c__0))
				jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Max_O_J__O(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(c__0))))
				jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Min_O_J__O(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(c__0))))
//line :272:1
				jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } }















func A_arbace_repr_go_print_emit_line_directive_inline_A_New() *A_arbace_repr_go_print_emit_line_directive_inline_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_inline_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Ctor() {}
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Invoke_O_O__O(self, n__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2);



	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O(); var temp__1927000414__auto____4 any = /*line :288:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var ws__5 any = temp__1927000414__auto____4; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) };
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)));
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil); return /*line :296:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_repr_go_print_emit_line_directive_own_A_New() *A_arbace_repr_go_print_emit_line_directive_own_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_own_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Ctor() {}
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var ind__2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()));



	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), ind__2); return /*line :303:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(n__0) }




func A_arbace_repr_go_print_emit_render_A_New() *A_arbace_repr_go_print_emit_render_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_render_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Ctor() {}
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_98.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_A_const_31; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_99.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_100), A_arbace_repr_go_print_emit_A_const_52, nil))
//line :308:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		lang.IFn_Cast(f__0).Invoke__O()
		{ var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; tmp3 = jrt.NN(jrt.StringBuilder_Cast(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref() }
//line :308:1
		return nil
	}()


	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_96.GetRawRoot__O()).Invoke__O()
//line :308:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}







func A_arbace_repr_go_print_emit_break_to_BANG__A_New() *A_arbace_repr_go_print_emit_break_to_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_break_to_BANG__A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Invoke_O_O__O(self, t__0 any) any {



	{ var tmp1 any; var and__1927000168__auto____2 any = t__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var mark__2 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var brk_QMARK___3 bool = lang.Util_Equiv_O_O__Z(t__0, A_arbace_repr_go_print_emit_A_const_101); var t__4 any





		if brk_QMARK___3 { var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; t__4 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; t__4 = lang.Numbers_Max_J_O__O(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(mark__2))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) } } else { t__4 = t__0 }
		jrt.NN(lang.Volatile_Cast(mark__2)).Reset_O__O(lang.Numbers_Max_O_O__O(jrt.NN(lang.Volatile_Cast(mark__2)).Deref__O(), t__4))
		var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Numbers_Gt_O_O__Z(t__4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {

			var tmp8 any; var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) } else { tmp8 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp8) {
				var tmp11 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp11.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(t__4) } else { return nil } } else {
//line :331:1
					var ci__5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_103.GetRawRoot__O()).Invoke__O(); L1: for {


						var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Numbers_Lt_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())), t__4) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(ci__5); continue L1 } else { return nil } } } } else {
//line :329:1
							var tmp13 any; var tmp14 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var and__1927000168__auto____5_2 bool = lang.Numbers_Lt_O_O__Z(t__4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())))





							if and__1927000168__auto____5_2 { var tmp15 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; tmp13 = tmp15.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }
//line :329:1
							if jrt.J2g_Truth(tmp13) {






								return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(t__4) } else {
//line :329:1
									return nil } } } else {
//line :321:1
										return nil } }
//line :317:1
	panic("j2g: unreachable")
}



















func A_arbace_repr_go_print_emit_stmt_break_BANG__A_New() *A_arbace_repr_go_print_emit_stmt_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Ctor() {}
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Invoke_O_O_O_O_O__O(self, t__0, first_QMARK___1, sep__2, indent__3 any) any { var newline_BANG___5 any; var tmp1 any = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(indent__3); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class; if





	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; newline_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var same_BANG___6 any; var tmp3 any = /*line :338:1*/A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(first_QMARK___1, sep__2); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class; if






	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; same_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(t__0)) { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Max_O_J__O(jrt.NN(lang.Volatile_Cast(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J(t__0))) }; var tmp7 /*line :347:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp8 any; var and__1927000168__auto____7 any = sep__2; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(first_QMARK___1) } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_107, sep__2) }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79)
//line :347:1
		jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {

			var tmp11 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), indent__3)
//line :347:1
			jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {


				return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else {
//line :347:1
					if lang.Util_Identical_O_O__Z(t__0, nil) {



						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29)) { return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else { return lang.IFn_Cast(same_BANG___6).Invoke__O() } } else {
//line :347:1
							if lang.Util_Equiv_O_O__Z(t__0, A_arbace_repr_go_print_emit_A_const_101) {




								return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else {
//line :347:1
									var tmp13 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {





										var tmp14 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(lang.Numbers_Minus_J_O__Number(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())))) } else {
//line :347:1
											var tmp15 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Util_Equiv_J_O__Z(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {






												return lang.IFn_Cast(same_BANG___6).Invoke__O() } else {
//line :347:1
													if A_arbace_repr_go_print_emit_A_const_55 != nil {







														lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29)
														var tmp16 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp16.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_108.GetRawRoot__O()).Invoke_O__O(t__0) }
//line :347:1
														jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } } } } }
//line :344:1
func A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(p0 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Ctor_O(c__indent any) { t.F_indent = c__indent }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Invoke_O_O__O(self, n__1 any) any { var n__1927000701__auto____2 int64 = lang.RT_LongCast_O__J(lang.Numbers_Max_J_O__O(1, n__1)); var ___3 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(___3, n__1927000701__auto____2) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(t.F_indent); ___3 = lang.Numbers_Unchecked_inc_J__J(___3); continue L1 }; break L1 }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Max_O_O__O(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())))); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }
func A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A{}; t.Ctor_O_O(p0, p1); return t }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Ctor_O_O(c__first_QMARK_, c__sep any) { t.F_first_QMARK_ = c__first_QMARK_; t.F_sep = c__sep }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Invoke_O__O(self any) any { if jrt.J2g_Truth(t.F_first_QMARK_) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O()).Invoke__O() } else { if jrt.J2g_Truth(t.F_sep) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O()).Invoke_O__O(t.F_sep) }; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O()).Invoke__O() }; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }













func A_arbace_repr_go_print_emit_close_break_BANG__A_New() *A_arbace_repr_go_print_emit_close_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_close_break_BANG__A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Ctor() {}
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Invoke_O_O_O_O_O__O(self, end__0, multiline_QMARK___1, always_QMARK___2, indent__3 any) any {





	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var and__1927000168__auto____5 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())

		if jrt.J2g_Truth(and__1927000168__auto____5) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(end__0) } else { tmp2 = and__1927000168__auto____5 }
//line :365:1
		if jrt.J2g_Truth(tmp2) {


			var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(end__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { L1: for {
				var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Numbers_Lt_O_J__Z(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())), lang.RT_LongCast_O__J(end__0)) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3); continue L1 }
//line :368:1
				break L1 }; jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Util_Equiv_J_O__Z(lang.RT_LongCast_O__J(end__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil {


					var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(end__0) }
//line :368:1
					jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } else {
//line :365:1
						var tmp8 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {






							var tmp9 any; var and__1927000168__auto____5_2 any; var or__1927000174__auto____5 any = multiline_QMARK___1; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5_2 = or__1927000174__auto____5 } else { and__1927000168__auto____5_2 = always_QMARK___2 }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else { tmp9 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp9) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } } else {
//line :365:1
								if jrt.J2g_Truth(always_QMARK___2) {







									lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3)
//line :365:1
									jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
									}
									}
							}
					}
	}
}






func A_arbace_repr_go_print_emit_result_A_New() *A_arbace_repr_go_print_emit_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_result_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Ctor() {}
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_109.GetRawRoot__O()).Invoke__O() } else {
//line :381:1
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; var s__1 any = jrt.NN(jrt.StringBuilder_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref(); var s__2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_110.GetRawRoot__O()).Invoke_O_O_O__O(s__1, A_arbace_repr_go_print_emit_A_const_112, Lit_3); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_111.GetRawRoot__O()); var tmp4 any



			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_113.GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_3)) { tmp4 = s__2 } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() }; return tmp3.Invoke_O__O(tmp4)
		}
}












func A_arbace_repr_go_print_emit_utf8_len_A_New() *A_arbace_repr_go_print_emit_utf8_len_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_utf8_len_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Ctor() {}
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long(int64(lang.RT_Alength_B1__I(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)))).Ref() }


func A_arbace_repr_go_print_emit_end_of_A_New() *A_arbace_repr_go_print_emit_end_of_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Ctor() {}
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Invoke_O_O_O__O(self, p__308000116__0, s__1 any) any { var vec__308000117__3 any = p__308000116__0; var l__4 any = lang.RT_Nth_O_I_O__O(vec__308000117__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__308000117__3, lang.RT_IntCast_J__I(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(s__1)).LastIndexOf_String__I(Lit_3); if



	lang.Numbers_IsNeg_J__Z(int64(i__6)) { return lang.Tuple_Create_O_O__IPersistentVector(l__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(lang.RT_LongCast_O__J(c__5), lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(s__1)))).Ref()) } else { var tmp1 int64 = lang.RT_LongCast_O__J(l__4); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New(); var tmp4 *jrt.Class
		var fncls__4 /*line :407:1*/*jrt.Class = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class

		if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }
//line :407:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(tmp1, int64(lang.RT_Count_O__I(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), s__1))))).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_115.GetRawRoot__O()).Invoke_O_O__O(s__1, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__6))).Ref()))))).Ref()) } }

func A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New() *A_arbace_repr_go_print_emit_end_of_fn__308000120_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_fn__308000120_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Ctor() {}
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Invoke_O_O__O(self, p1__308000115_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__308000115_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }



func A_arbace_repr_go_print_emit_line_comment_QMARK__A_New() *A_arbace_repr_go_print_emit_line_comment_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_comment_QMARK__A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Ctor() {}
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Invoke_O_O__O(self, it__0 any) any { var and__1927000168__auto____2 any = A_arbace_repr_go_print_emit_A_const_116.Invoke_O__O(it__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__0), Lit_23) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_emit_place_run_A_New() *A_arbace_repr_go_print_emit_place_run_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Ctor() {}
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Invoke_O_O_O_O_O__O(self, run__0, cur__1, prev_item__2, nxt__3 any) any { { var vec__308000127__5 any = cur__1; var cl__6 any = lang.RT_Nth_O_I_O__O(vec__308000127__5, lang.RT_IntCast_J__I(0), nil); var cc__7 any = lang.RT_Nth_O_I_O__O(vec__308000127__5, lang.RT_IntCast_J__I(1), nil); var n__8 int32 = lang.RT_Count_O__I(run__0); var lens__9 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New(); var tmp3 *jrt.Class
																var fncls__6 /*line :415:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class





	if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; lens__9 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), run__0)
//line :415:1
	var natural__10 any; var tmp4 any = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(cl__6, n__8, run__0, lens__9, cc__7); var tmp5 *jrt.Class
	var fncls__5 /*line :415:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class






	if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class = fncls__5d; tmp5 = fncls__5d } else { tmp5 = fncls__5 }; natural__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)





	var tmp6 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O()).Invoke_O__O(prev_item__2)

	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp6 = nxt__3 } else { tmp6 = and__1927000168__auto____11 }
//line :428:1
	if jrt.J2g_Truth(tmp6) { var vec__308000134__11 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3); var nl__12 any = lang.RT_Nth_O_I_O__O(vec__308000134__11, lang.RT_IntCast_J__I(0), nil); var ncol__13 any = lang.RT_Nth_O_I_O__O(vec__308000134__11, lang.RT_IntCast_J__I(1), nil); var i__14 int64 = lang.Numbers_Dec_J__J(int64(n__8)); var c__15 int64; var tmp7 int64 = lang.RT_LongCast_O__J(ncol__13); var tmp8 int64



		if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3)) { tmp8 = 1 } else { tmp8 = 0 }; c__15 = lang.Numbers_Minus_J_J__J(tmp7, tmp8)
//line :428:1
		var acc__16 any; lang.PersistentList_Init(); acc__16 = lang.PersistentList_EMPTY.Ref(); L1: for {




			if lang.Numbers_IsNeg_J__Z(i__14) {
				return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()).Invoke_O__O(acc__16) } else {
//line :433:1
					var c__17 int64 = lang.Numbers_Minus_J_J__J(c__15, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lens__9, lang.RT_IntCast_J__I(i__14)))); var tmp9 int64 = lang.Numbers_Dec_J__J(i__14); var tmp10 int64
					var tmp11 /*line :433:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_74


					if jrt.J2g_Truth(tmp11.Invoke_O__O(lang.RT_Nth_O_I__O(run__0, lang.RT_IntCast_J__I(i__14)))) { tmp10 = 1 } else { tmp10 = 0 }; i__14, c__15, acc__16 = tmp9, lang.Numbers_Minus_J_J__J(c__17, tmp10), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_127.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(nl__12, jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(1, c__17)).Ref()), acc__16); continue L1 } } } else {
//line :428:1
						var tmp12 any; var or__1927000174__auto____11 bool = lang.Util_Identical_O_O__Z(nxt__3, nil)








						if or__1927000174__auto____11 { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { var or__1927000174__auto____12 bool = lang.Numbers_Gt_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3))), lang.RT_LongCast_O__J(cl__6)); if or__1927000174__auto____12 { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { tmp12 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O()).Invoke_O__O(prev_item__2) } }
//line :428:1
						if jrt.J2g_Truth(tmp12) {









							return lang.IFn_Cast(natural__10).Invoke__O() } else {
//line :428:1
								if A_arbace_repr_go_print_emit_A_const_55 != nil { var ncol__11 int64 = lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3))); var need__12 any = lang.Numbers_Minus_J_O__Number(lang.Numbers_Minus_J_J__J(ncol__11, lang.RT_LongCast_O__J(cc__7)), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), lens__9)); var slots__13 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_74, run__0), A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3)); var nat__14 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New(); var tmp15 *jrt.Class
									var fncls__7 /*line :428:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class














									if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class = fncls__7d; tmp15 = fncls__7d } else { tmp15 = fncls__7 }; nat__14 = tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), slots__13)
//line :428:1
									var nnat__15 int32 = lang.RT_Count_O__I(nat__14); var spaces__16 any
















									if lang.Numbers_IsNeg_O__Z(need__12) {
										var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New(); var tmp18 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class = fncls__8d; tmp18 = fncls__8d } else { tmp18 = fncls__8 }; spaces__16 = tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), slots__13) } else {
//line :445:1
											if lang.Numbers_Gte_O_J__Z(need__12, int64(nnat__15)) { var extra__16 any = lang.Numbers_Minus_O_J__Number(need__12, int64(nnat__15)); var base__17 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New(); var tmp21 *jrt.Class
												var fncls__9 /*line :445:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class



												if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class = fncls__9d; tmp21 = fncls__9d } else { tmp21 = fncls__9 }; base__17 = tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), slots__13)
												if lang.Numbers_IsZero_O__Z(extra__16) { spaces__16 = base__17 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(nat__14)) {

													spaces__16 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(base__17, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(nat__14), A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), extra__16) } else {
//line :450:1
														var tmp22 any; var and__1927000168__auto____18 bool = lang.Util_Equiv_J_J__Z(int64(n__8), 1)


														if and__1927000168__auto____18 { var and__1927000168__auto____19 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_125.GetRawRoot__O()).Invoke_O__O(extra__16); if jrt.J2g_Truth(and__1927000168__auto____19) { var tmp23 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_72; tmp22 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_37, tmp23.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(run__0)))).Ref() } else { tmp22 = and__1927000168__auto____19 } } else { tmp22 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____18).Ref() }
//line :450:1
														if jrt.J2g_Truth(tmp22) {



															var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp26 any = A_arbace_repr_go_print_emit_A_const_30; var tmp27 any = tmp25.Invoke_O_O_O__O(base__17, tmp26, lang.Numbers_Quotient_O_J__Number(extra__16, 2)); var tmp28 any = A_arbace_repr_go_print_emit_A_const_29; spaces__16 = tmp24.Invoke_O_O_O__O(tmp27, tmp28, lang.Numbers_Quotient_O_J__Number(extra__16, 2)) } else {
//line :450:1
																if A_arbace_repr_go_print_emit_A_const_55 != nil {




																	spaces__16 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(base__17, jrt.Integer_ValueOf_I__Integer(n__8).Ref(), A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), extra__16) } else {
//line :450:1
																		spaces__16 = nil } } } } } else {
//line :445:1
																			if A_arbace_repr_go_print_emit_A_const_55 != nil { var keep__16 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_126.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_129.GetRawRoot__O()).Invoke_O_O__O(need__12, nat__14)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_130.GetRawRoot__O()); var tmp31 any = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(keep__16); var tmp32 *jrt.Class
																				var fncls__10 /*line :445:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class












																				if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class = fncls__10d; tmp32 = fncls__10d } else { tmp32 = fncls__10 }; spaces__16 = tmp29.Invoke_O__O(tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), slots__13)) } else {
//line :445:1
																					spaces__16 = nil } } }
//line :428:1
									var i__17 int64 = 0; var c__18 int64 = lang.RT_LongCast_O__J(cc__7); var acc__19 any; lang.PersistentVector_Init(); acc__19 = lang.PersistentVector_EMPTY.Ref(); L2: for {































										if lang.Numbers_Lt_J_J__Z(i__17, int64(n__8)) { var c__20 int64 = lang.Numbers_Add_J_J__J(c__18, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(spaces__16, lang.RT_IntCast_J__I(i__17))))

											i__17, c__18, acc__19 = lang.Numbers_Inc_J__J(i__17), lang.Numbers_Add_J_J__J(c__20, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lens__9, lang.RT_IntCast_J__I(i__17)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__19, lang.Tuple_Create_O_O__IPersistentVector(cl__6, jrt.Long_ValueOf_J__Long(c__20).Ref())); continue L2 } else {
//line :460:1
												return acc__19 } } } else {
//line :428:1
													return nil } } } }; /*line :415:1*/panic("j2g: unreachable") }





func A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000130_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000130_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Ctor() {}
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Invoke_O_O__O(self, p1__308000124_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000124_SHARP___1)) }
func A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_repr_go_print_emit_place_run_natural__308000132_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_natural__308000132_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Ctor_O_I_O_O_O(c__cl any, c__n int32, c__run, c__lens, c__cc any) { t.F_cl = c__cl; t.F_n = c__n; t.F_run = c__run; t.F_lens = c__lens; t.F_cc = c__cc }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var c__2 int64 = lang.RT_LongCast_O__J(t.F_cc); var acc__3 any; lang.PersistentVector_Init(); acc__3 = lang.PersistentVector_EMPTY.Ref(); L1: for {

	if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) { var c__4 int64; var tmp1 int64; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_74; var tmp3 any = t.F_run
		if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_J__I(i__1)))) { tmp1 = 1 } else { tmp1 = 0 }; c__4 = lang.Numbers_Add_J_J__J(c__2, tmp1)
		var tmp4 any = t.F_lens; var tmp5 any = t.F_cl; i__1, c__2, acc__3 = lang.Numbers_Inc_J__J(i__1), lang.Numbers_Add_J_J__J(c__4, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(tmp4, lang.RT_IntCast_J__I(i__1)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__3, lang.Tuple_Create_O_O__IPersistentVector(tmp5, jrt.Long_ValueOf_J__Long(c__4).Ref())); continue L1 } else {
//line :424:1
			return acc__3 } } }; /*line :422:1*/panic("j2g: unreachable") }




















func A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000137_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000137_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Ctor() {}
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if jrt.J2g_Truth(s__2) { return i__1 } else { return nil } }


func A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000139_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000139_A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Ctor() {}
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Invoke_O_O__O(self, p1__308000125_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000125_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }


func A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000141_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000141_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Ctor() {}
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Invoke_O_O__O(self, p1__308000126_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000126_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }








func A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(p0 any) *A_arbace_repr_go_print_emit_place_run_fn__308000143_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000143_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Ctor_O(c__keep any) { t.F_keep = c__keep }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_keep).Invoke_O__O(i__1)) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }






func A_arbace_repr_go_print_emit_full_result_A_New() *A_arbace_repr_go_print_emit_full_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Ctor() {}
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var fs__1 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var items__2 any; if





	jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1)) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_140.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New(); var tmp7 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class = fncls__14d; tmp7 = fncls__14d } else { tmp7 = fncls__14 }; items__2 = tmp2.Invoke_O_O_O__O(tmp4, tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)), A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__1)) } else {


			items__2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__1)) }; var extras__3 any; var tmp8 lang.IFn = /*line :465:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_133.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New(); var tmp10 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class; if










	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class = fncls__15d; tmp10 = fncls__15d } else { tmp10 = fncls__15 }; var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_print_emit_A_const_143.Invoke_O__O(fs__1); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New(); var tmp16 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class; if
	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class = fncls__16d; tmp16 = fncls__16d } else { tmp16 = fncls__16 }; var tmp17 any = /*line :476:1*/tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1)); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New(); var tmp20 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class; if

	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class = fncls__17d; tmp20 = fncls__17d } else { tmp20 = fncls__17 }; extras__3 = /*line :476:1*/tmp8.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp17, tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), A_arbace_repr_go_print_emit_A_const_145.Invoke_O__O(fs__1)))); var merged__4 any; var tmp21 any = /*line :465:1*/A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(extras__3, items__2); var tmp22 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class; if














	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class = fncls__12d; tmp22 = fncls__12d } else { tmp22 = fncls__12 }; merged__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O(); var n__5 int32 = /*line :465:1*/lang.RT_Count_O__I(merged__4); var space__6 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O()); var tmp24 *lang.PersistentArrayMap;




























	lang.PersistentArrayMap_Init(); tmp24 = lang.PersistentArrayMap_EMPTY; var tmp25 any = tmp24.Ref(); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp27 any = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New(); var tmp28 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class = fncls__18d; tmp28 = fncls__18d } else { tmp28 = fncls__18 }; space__6 = tmp23.Invoke_O_O_O__O(tmp25, tmp26.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil)), A_arbace_repr_go_print_emit_A_const_146.Invoke_O__O(fs__1)); var sb__7 any = /*line :465:1*/jrt.StringBuilder_New(); var cur__8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_147); var last_s__9 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_2); var prev_item__10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil); var write_at_BANG___11 any; var tmp29 any = A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(space__6, last_s__9, sb__7, prev_item__10, cur__8); var tmp30 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class; if


































	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class = fncls__13d; tmp30 = fncls__13d } else { tmp30 = fncls__13 }; write_at_BANG___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var i__12 any = /*line :465:1*/lang.RT_Box_J__Number(0); L1: for {






























































		if lang.Numbers_Lt_O_J__Z(i__12, int64(n__5)) { var it__13 any = lang.RT_Nth_O_I__O(merged__4, lang.RT_IntCast_O__I(i__12))

			if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)) {
				lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(it__13, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)); i__12 = lang.Numbers_Inc_O__Number(i__12); continue L1 } else {
//line :530:1
					var j__14 any; var tmp31 any = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(merged__4, n__5, i__12); var tmp32 *jrt.Class
					var fncls__19 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class



					if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class = fncls__19d; tmp32 = fncls__19d } else { tmp32 = fncls__19 }; j__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :530:1
					var t__15 any; var tmp33 any = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(merged__4, n__5, j__14); var tmp34 *jrt.Class
					var fncls__20 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class




					if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class = fncls__20d; tmp34 = fncls__20d } else { tmp34 = fncls__20 }; t__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O()
//line :530:1
					var tok_STAR___16 any





					if lang.Numbers_Lt_O_J__Z(t__15, int64(n__5)) { tok_STAR___16 = lang.RT_Nth_O_I__O(merged__4, lang.RT_IntCast_O__I(t__15)) } else { tok_STAR___16 = nil }
//line :530:1
					var vec__308000224__17 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(cur__8); var cl__18 any = lang.RT_Nth_O_I_O__O(vec__308000224__17, lang.RT_IntCast_J__I(0), nil); var ___19 any = lang.RT_Nth_O_I_O__O(vec__308000224__17, lang.RT_IntCast_J__I(1), nil); var same_line_QMARK___20 any; var and__1927000168__auto____20 any = tok_STAR___16; _ = ___19







					if jrt.J2g_Truth(and__1927000168__auto____20) { same_line_QMARK___20 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(tok_STAR___16))), lang.RT_LongCast_O__J(cl__18))).Ref() } else { same_line_QMARK___20 = and__1927000168__auto____20 }
//line :530:1
					var run__21 any; var tmp35 any = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(last_s__9, merged__4, tok_STAR___16, j__14, i__12, same_line_QMARK___20); var tmp36 *jrt.Class
					var fncls__22 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class








					if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class = fncls__22d; tmp36 = fncls__22d } else { tmp36 = fncls__22 }; run__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O()
//line :530:1
					var obstacles__22 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_151.GetRawRoot__O()); var tmp40 any = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(cl__18); var tmp41 *jrt.Class
					var fncls__24 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class






















					if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class = fncls__24d; tmp41 = fncls__24d } else { tmp41 = fncls__24 }; var tmp42 any = tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(merged__4, j__14, t__15)); var tmp43 lang.IPersistentVector
					if jrt.J2g_Truth(same_line_QMARK___20) { tmp43 = lang.Tuple_Create_O__IPersistentVector(tok_STAR___16) } else { tmp43 = nil }
//line :553:1
					obstacles__22 = tmp37.Invoke_O__O(tmp38.Invoke_O_O__O(tmp42, tmp43))
//line :530:1
					var width__23 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()); var tmp45 any = A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp47 any = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New(); var tmp48 *jrt.Class
					var fncls__25 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class
























					if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class = fncls__25d; tmp48 = fncls__25d } else { tmp48 = fncls__25 }; width__23 = tmp44.Invoke_O_O__O(tmp45, tmp46.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil), run__21))
//line :530:1
					var k__24 any; var tmp49 any = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(obstacles__22, width__23, cur__8); var tmp50 *jrt.Class
					var fncls__23 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class

























					if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class = fncls__23d; tmp50 = fncls__23d } else { tmp50 = fncls__23 }; k__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil).Invoke__O()
//line :530:1
					var k__25 any

































					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(run__21)) { k__25 = lang.Numbers_Min_O_J__O(k__24, int64(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(merged__4, j__14, t__15)))) } else { k__25 = A_arbace_repr_go_print_emit_A_const_30 }
//line :530:1
					var n__1927000701__auto____26 int64 = lang.RT_LongCast_O__J(k__25); var q__27 int64 = 0; L2: for {


































						if lang.Numbers_Lt_J_J__Z(q__27, n__1927000701__auto____26) { var o__28 any = lang.RT_Nth_O_I__O(merged__4, lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(j__14, q__27))); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(o__28, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__28)); q__27 = lang.Numbers_Unchecked_inc_J__J(q__27); continue L2 }
//line :530:1
						break L2 }; var nxt__26 any



































					if lang.Numbers_Lt_O_J__Z(lang.Numbers_Add_O_O__Number(j__14, k__25), int64(n__5)) { nxt__26 = lang.RT_Nth_O_I__O(merged__4, lang.RT_IntCast_O__I(lang.Numbers_Add_O_O__Number(j__14, k__25))) } else { nxt__26 = nil }
//line :530:1
					var ps__27 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_152.GetRawRoot__O()).Invoke_O_O_O_O__O(run__21, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(cur__8), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(prev_item__10), nxt__26); var seq_308000240__28 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(), run__21, ps__27)); var chunk_308000241__29 any; var count_308000242__30 int64 = 0; var i_308000243__31 int64 = 0; L3: for {





































						if lang.Numbers_Lt_J_J__Z(i_308000243__31, count_308000242__30) { var vec__308000244__32 any = lang.Indexed_Cast(chunk_308000241__29).Nth_I__O(lang.RT_IntCast_J__I(i_308000243__31)); var x__33 any = lang.RT_Nth_O_I_O__O(vec__308000244__32, lang.RT_IntCast_J__I(0), nil); var p__34 any = lang.RT_Nth_O_I_O__O(vec__308000244__32, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__33, p__34); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = seq_308000240__28, chunk_308000241__29, count_308000242__30, lang.Numbers_Unchecked_inc_J__J(i_308000243__31); continue L3 } else { var temp__1927000414__auto____32 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_308000240__28); if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_308000240__33 any = temp__1927000414__auto____32; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_153.GetRawRoot__O()).Invoke_O__O(seq_308000240__33)) { var c__1927000678__auto____34 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_308000240__33); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_308000240__33), c__1927000678__auto____34, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__308000247__34 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(seq_308000240__33); var x__35 any = lang.RT_Nth_O_I_O__O(vec__308000247__34, lang.RT_IntCast_J__I(0), nil); var p__36 any = lang.RT_Nth_O_I_O__O(vec__308000247__34, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__35, p__36); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_308000240__33), nil, 0, 0; continue L3 } } }
//line :530:1
						break L3
					}





































					i__12 = lang.Numbers_Add_O_O__Number(j__14, k__25); continue L1 } }
//line :465:1
		break L1 }; var tmp51 /*line :570:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__7); var tmp52 any; var or__1927000174__auto____12 any = A_arbace_repr_go_print_emit_A_const_150.Invoke_O__O(fs__1); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp52 = or__1927000174__auto____12 } else { tmp52 = Lit_3 }; jrt.NN(tmp51).Append_O__StringBuilder(tmp52); return /*line :571:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__7)).ToString__String().Ref() }
//line :472:1
func A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000149_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000149_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Ctor() {}
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Invoke_O_O__O(self, p1__308000146_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_141); var and__1927000168__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Identical_O_O__Z(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000146_SHARP___1), nil); if and__1927000168__auto____3 { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(Lit_18, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1))
															if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var tmp2 any = A_arbace_repr_go_print_emit_A_const_142; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(p1__308000146_SHARP___1)); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { return A_arbace_repr_go_print_emit_A_const_142.Invoke_O__O(p1__308000146_SHARP___1) } } } else {
//line :472:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000152_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000152_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Ctor() {}
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Invoke_O_O__O(self, p__308000151__1 any) any { var vec__308000153__2 any = p__308000151__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__308000153__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__308000153__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }
func A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000158_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000158_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Ctor() {}
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Invoke_O_O__O(self, p__308000157__1 any) any { var vec__308000159__2 any = p__308000157__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__308000159__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__308000159__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_18, A_arbace_repr_go_print_emit_A_const_19) }
func A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000164_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000164_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Ctor() {}
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Invoke_O_O__O(self, p__308000163__1 any) any { var vec__308000165__2 any = p__308000163__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__308000165__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__308000165__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_19, A_arbace_repr_go_print_emit_A_const_19) }

func A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_full_result_fn__308000169_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_A{}; t.Ctor_O_O(p0, p1); return t }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Ctor_O_O(c__extras, c__items any) { t.F_extras = c__extras; t.F_items = c__items }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var cs__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_extras; t.F_extras = nil; tmp2 = t_; cs__2 = tmp1.Invoke_O__O(tmp2); var acc__3 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_134.GetRawRoot__O()); var tmp4 *lang.PersistentVector; lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; acc__3 = tmp3.Invoke_O__O(tmp4.Ref()); L1: for {
												if lang.Numbers_Lt_J_J__Z(i__1, int64(lang.RT_Count_O__I(t.F_items))) { var tmp5 any = t.F_items; var it__4 any = lang.RT_Nth_O_I__O(tmp5, lang.RT_IntCast_J__I(i__1)); var pos__5 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__4); var tmp6 any
													var and__1927000168__auto____6 any = pos__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(cs__2); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp7 lang.IPersistentVector; var vec__308000170__8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(cs__2); var l__9 any = lang.RT_Nth_O_I_O__O(vec__308000170__8, lang.RT_IntCast_J__I(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O(vec__308000170__8, lang.RT_IntCast_J__I(1), nil); tmp7 = lang.Tuple_Create_O_O__IPersistentVector(l__9, c__10); tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(tmp7, pos__5)))).Ref() } else { tmp6 = and__1927000168__auto____7 } } else { tmp6 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp6) { var vec__308000173__6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(cs__2); var l__7 any = lang.RT_Nth_O_I_O__O(vec__308000173__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__308000173__6, lang.RT_IntCast_J__I(1), nil); var t__9 any = lang.RT_Nth_O_I_O__O(vec__308000173__6, lang.RT_IntCast_J__I(2), nil); var semi__10 any = lang.RT_Nth_O_I_O__O(vec__308000173__6, lang.RT_IntCast_J__I(3), nil); var tmp8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_136.GetRawRoot__O()).Invoke_O__O(cs__2); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()); var tmp10 lang.IPersistentMap

			if jrt.J2g_Truth(semi__10) { var tmp11 any = A_arbace_repr_go_print_emit_A_const_72; var tmp12 any = A_arbace_repr_go_print_emit_A_const_73; tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, t__9, tmp12, lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8))) } else { var tmp13 any = A_arbace_repr_go_print_emit_A_const_72; var tmp14 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(t__9); var tmp15 any = A_arbace_repr_go_print_emit_A_const_73; var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8); var tmp17 any = A_arbace_repr_go_print_emit_A_const_116; var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18.Ref())) }; i__1, cs__2, acc__3 = i__1, tmp8, tmp9.Invoke_O_O__O(acc__3, tmp10); continue L1 } else {

				i__1, cs__2, acc__3 = lang.Numbers_Inc_J__J(i__1), cs__2, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()).Invoke_O_O__O(acc__3, it__4); continue L1 } } else {
					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_135.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New(); var tmp22 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class = fncls__11d; tmp22 = fncls__11d } else { tmp22 = fncls__11 }; return tmp19.Invoke_O__O(tmp20.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), acc__3, cs__2)) } } }; /*line :480:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Ctor() {}
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Invoke_O_O_O__O(self, a__1, p__308000176__2 any) any { var vec__308000178__3 any = p__308000176__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__308000178__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__308000178__3, lang.RT_IntCast_J__I(1), nil); var t__6 any = lang.RT_Nth_O_I_O__O(vec__308000178__3, lang.RT_IntCast_J__I(2), nil); var semi__7 any = lang.RT_Nth_O_I_O__O(vec__308000178__3, lang.RT_IntCast_J__I(3), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()); var tmp2 lang.IPersistentMap; if
																	jrt.J2g_Truth(semi__7) { var tmp3 any = A_arbace_repr_go_print_emit_A_const_72; var tmp4 any = A_arbace_repr_go_print_emit_A_const_73; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, t__6, tmp4, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5))) } else { var tmp5 any = A_arbace_repr_go_print_emit_A_const_72; var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(t__6); var tmp7 any = A_arbace_repr_go_print_emit_A_const_73; var tmp8 any = lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5); var tmp9 any = A_arbace_repr_go_print_emit_A_const_116; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10.Ref())) }; return tmp1.Invoke_O_O__O(a__1, tmp2) }



func A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000184_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000184_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Ctor() {}
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Invoke_O_O__O(self, p__308000183__1 any) any { var vec__308000185__2 any = p__308000183__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__308000185__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__308000185__2, lang.RT_IntCast_J__I(1), nil); var w__5 any = lang.RT_Nth_O_I_O__O(vec__308000185__2, lang.RT_IntCast_J__I(2), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(w__5)) }





func A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Ctor_O_O_O_O_O(c__space, c__last_s, c__sb, c__prev_item, c__cur any) { t.F_space = c__space; t.F_last_s = c__last_s; t.F_sb = c__sb; t.F_prev_item = c__prev_item; t.F_cur = c__cur }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Invoke_O_O_O__O(self, it__1, p__308000189__2 any) any { var vec__308000191__3 any = p__308000189__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__308000191__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__308000191__3, lang.RT_IntCast_J__I(1), nil); var vec__308000194__6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_cur); var cl__7 any = lang.RT_Nth_O_I_O__O(vec__308000194__6, lang.RT_IntCast_J__I(0), nil); var cc__8 any = lang.RT_Nth_O_I_O__O(vec__308000194__6, lang.RT_IntCast_J__I(1), nil); var l__9 int64 = lang.RT_LongCast_O__J(l__4); var c__10 int64 = lang.RT_LongCast_O__J(c__5); var cl__11 int64 = lang.RT_LongCast_O__J(cl__7); var cc__12 int64 = lang.RT_LongCast_O__J(cc__8); if


	lang.Numbers_Gt_J_J__Z(l__9, cl__11) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____13 any = tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(cl__11).Ref(), jrt.Long_ValueOf_J__Long(cc__12).Ref()))

		if jrt.J2g_Truth(temp__1927000414__auto____13) { var w__14 any = temp__1927000414__auto____13; var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(w__14)) }
//line :503:1
		var k__13 int64 = cl__11; L1: for {



			if lang.Numbers_Lt_J_J__Z(k__13, l__9) {
				jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_84)
				if lang.Numbers_Lt_J_J__Z(k__13, lang.Numbers_Dec_J__J(l__9)) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____14 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(k__13)).Ref(), A_arbace_repr_go_print_emit_A_const_29))
					if jrt.J2g_Truth(temp__1927000414__auto____14) { var w__15 any = temp__1927000414__auto____14; var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp4).Append_String__StringBuilder(jrt.String_Cast(w__15)) } }
				k__13 = lang.Numbers_Inc_J__J(k__13); continue L1 }
//line :503:1
			break L1 }; var tmp5 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13 any = tmp5.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(l__9).Ref(), A_arbace_repr_go_print_emit_A_const_29))








		if jrt.J2g_Truth(temp__1927000408__auto____13) { var w__14_2 any = temp__1927000408__auto____13; var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
			jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(w__14_2)) } else {
//line :512:1
				var n__1927000701__auto____14 int64 = lang.RT_LongCast_J__J(lang.Numbers_Dec_J__J(c__10)); var ___15 int64 = 0; L2: for {

					if lang.Numbers_Lt_J_J__Z(___15, n__1927000701__auto____14) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___15 = lang.Numbers_Unchecked_inc_J__J(___15); continue L2 }
//line :512:1
					break L2 } } } else {
//line :503:1
						var tmp7 bool; var and__1927000168__auto____13 bool = lang.Util_Equiv_J_J__Z(l__9, cl__11)











						if and__1927000168__auto____13 { tmp7 = lang.Numbers_Gte_J_J__Z(c__10, cc__12) } else { tmp7 = and__1927000168__auto____13 }
//line :503:1
						if tmp7 { var tmp8 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13_2 any = tmp8.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(l__9).Ref(), jrt.Long_ValueOf_J__Long(cc__12).Ref()))












							if jrt.J2g_Truth(temp__1927000408__auto____13_2) { var w__14_3 any = temp__1927000408__auto____13_2; var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
								jrt.NN(tmp9).Append_String__StringBuilder(jrt.String_Cast(w__14_3)) } else {
//line :516:1
									var n__1927000701__auto____14_2 int64 = lang.RT_LongCast_J__J(lang.Numbers_Minus_J_J__J(c__10, cc__12)); var ___15_2 int64 = 0; L3: for {

										if lang.Numbers_Lt_J_J__Z(___15_2, n__1927000701__auto____14_2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79); ___15_2 = lang.Numbers_Unchecked_inc_J__J(___15_2); continue L3 }
//line :516:1
										break L3 } } } else {
//line :503:1
											if A_arbace_repr_go_print_emit_A_const_55 != nil {
















												var tmp10 any; var or__1927000174__auto____13 any = A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(it__1); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp10 = or__1927000174__auto____13 } else { tmp10 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_last_s), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)) }; if jrt.J2g_Truth(tmp10) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } } }; var tmp11 /*line :521:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))); var tmp12 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp13 any = t.F_cur; var tmp14 any; var tmp15 bool; var or__1927000174__auto____13_2 bool = lang.Numbers_Gt_J_J__Z(l__9, cl__11); if or__1927000174__auto____13_2 { tmp15 = or__1927000174__auto____13_2 } else { var and__1927000168__auto____14 bool = lang.Util_Equiv_J_J__Z(l__9, cl__11); if and__1927000168__auto____14 { tmp15 = lang.Numbers_Gte_J_J__Z(c__10, cc__12) } else { tmp15 = and__1927000168__auto____14 } }; if tmp15 {
		tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(l__9).Ref(), jrt.Long_ValueOf_J__Long(c__10).Ref()), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)) } else {
			tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_cur), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))).Ref()) }; /*line :522:1*/tmp12.Invoke_O_O__O(tmp13, tmp14); var tmp16 lang.IFn =


	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp17 any = t.F_last_s; tmp16.Invoke_O_O__O(tmp17, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)); return /*line :526:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_prev_item, it__1) }







func A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000227_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000227_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Ctor_O_I_O(c__merged any, c__n int32, c__i any) { t.F_merged = c__merged; t.F_n = c__n; t.F_i = c__i }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_73; var tmp3 any = t.F_merged; tmp1 = lang.Util_Identical_O_O__Z(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(j__1))), nil) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000229_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Ctor_O_I_O(c__merged any, c__n int32, c__j any) { t.F_merged = c__merged; t.F_n = c__n; t.F_j = c__j }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Invoke_O__O(self any) any { { var t__1 any; var t_ any = t.F_j; t.F_j = nil; t__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(t__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_116; var tmp3 any = t.F_merged; tmp1 = tmp2.Invoke_O__O(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(t__1))) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { t__1 = lang.Numbers_Inc_O__Number(t__1); continue L1 } else { return t__1 } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_print_emit_full_result_fn__308000231_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000231_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Ctor_O_O_O_O_O_O(c__last_s, c__merged, c__tok_STAR_, c__j, c__i, c__same_line_QMARK_ any) { t.F_last_s = c__last_s; t.F_merged = c__merged; t.F_tok_STAR_ = c__tok_STAR_; t.F_j = c__j; t.F_i = c__i; t.F_same_line_QMARK_ = c__same_line_QMARK_ }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Invoke_O__O(self any) any { { var k__1 any; var t_ any = t.F_i; t.F_i = nil; k__1 = t_; var ls__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()); var tmp2 any; var t__2 any = t.F_last_s; t.F_last_s = nil; tmp2 = t__2; ls__2 = tmp1.Invoke_O__O(tmp2); var acc__3 any; lang.PersistentVector_Init(); acc__3 = lang.PersistentVector_EMPTY.Ref(); L1: for {
												if lang.Numbers_Lt_O_O__Z(k__1, t.F_j) { var tmp3 any = t.F_merged; var x__4 any = lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(k__1)); var temp__1927000408__auto____5 any = A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(x__4)

		if jrt.J2g_Truth(temp__1927000408__auto____5) { var kind__6 any = temp__1927000408__auto____5; var keep_QMARK___7 any; var G__308000232__7_ any = kind__6
		L2: switch { default: switch lang.Util_Hash_O__I(G__308000232__7_) >> 1 & 1 { case 0: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_142) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_same_line_QMARK_)

			if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = t.F_tok_STAR_; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_148.GetRawRoot__O()).Invoke_O_O__O(ls__2, Lit_19); if jrt.J2g_Truth(and__1927000168__auto____10) { keep_QMARK___7 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(ls__2) } else { keep_QMARK___7 = and__1927000168__auto____10 } } else { keep_QMARK___7 = and__1927000168__auto____9 } } else { keep_QMARK___7 = and__1927000168__auto____8 }
//line :543:1
			break L2 }; case 1: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_107) { var and__1927000168__auto____8_2 any = t.F_same_line_QMARK_
				if jrt.J2g_Truth(and__1927000168__auto____8_2) { keep_QMARK___7 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(ls__2) } else { keep_QMARK___7 = and__1927000168__auto____8_2 }
//line :543:1
				break L2 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__308000232__7_)))))
		}

			if jrt.J2g_Truth(keep_QMARK___7) {
				var tmp4 any = lang.Numbers_Inc_O__Number(k__1); var tmp5 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_emit_A_const_72; var tmp8 any = A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4); var tmp9 any = A_arbace_repr_go_print_emit_A_const_74; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; k__1, ls__2, acc__3 = tmp4, tmp5, tmp6.Invoke_O_O__O(acc__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10.Ref()))); continue L1 } else {
					k__1, ls__2, acc__3 = lang.Numbers_Inc_O__Number(k__1), ls__2, acc__3; continue L1 } } else {
						k__1, ls__2, acc__3 = lang.Numbers_Inc_O__Number(k__1), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__3, x__4); continue L1 } } else {
//line :540:1
							return acc__3 } } }; /*line :539:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(p0 any) *A_arbace_repr_go_print_emit_full_result_fn__308000234_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000234_A{}; t.Ctor_O(p0); return t }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Invoke_O_O__O(self, p1__308000147_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000147_SHARP___1))), lang.RT_LongCast_O__J(t.F_cl))).Ref() }

func A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000236_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000236_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Ctor() {}
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Invoke_O_O__O(self, p1__308000148_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000148_SHARP___1)) }
func A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000238_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000238_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Ctor_O_O_O(c__obstacles, c__width, c__cur any) { t.F_obstacles = c__obstacles; t.F_width = c__width; t.F_cur = c__cur }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Invoke_O__O(self any) any { { var k__1 int64 = 0; var c__2 int64; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cur; t.F_cur = nil; tmp3 = t_; c__2 = lang.RT_LongCast_O__J(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3))); L1: for {
												if lang.Numbers_Lt_J_J__Z(k__1, lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(t.F_obstacles)))) { var tmp4 any = t.F_obstacles; var o__3 any = lang.RT_Nth_O_I__O(tmp4, lang.RT_IntCast_J__I(k__1)); var oc__4 int64 = lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3)))


		if lang.Numbers_Gte_J_O__Z(lang.Numbers_Minus_J_J__J(oc__4, c__2), lang.Numbers_Add_O_J__Number(t.F_width, 1)) { return jrt.Long_ValueOf_J__Long(k__1).Ref() } else {

			k__1, c__2 = lang.Numbers_Inc_J__J(k__1), lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(o__3)))); continue L1 } } else {
				return jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(t.F_obstacles))))).Ref() } } }; /*line :556:1*/panic("j2g: unreachable") }
















type A_arbace_repr_go_print_emit_A struct{ jrt.Object }

var A_arbace_repr_go_print_emit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_emit_A_const_0 *lang.Var

var A_arbace_repr_go_print_emit_A_const_1 *lang.Var

var A_arbace_repr_go_print_emit_A_const_2 any

var A_arbace_repr_go_print_emit_A_const_3 any

var A_arbace_repr_go_print_emit_A_const_4 any

var A_arbace_repr_go_print_emit_A_const_5 *lang.Var

var A_arbace_repr_go_print_emit_A_const_6 *lang.Var

var A_arbace_repr_go_print_emit_A_const_7 *lang.Var

var A_arbace_repr_go_print_emit_A_const_8 any

var A_arbace_repr_go_print_emit_A_const_9 *lang.Var

var A_arbace_repr_go_print_emit_A_const_10 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_11 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_12 *lang.Var

var A_arbace_repr_go_print_emit_A_const_13 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_14 *lang.Var

var A_arbace_repr_go_print_emit_A_const_15 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_16 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_17 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_18 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_19 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_20 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_21 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_23 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_24 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_25 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_26 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_27 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_29 any

var A_arbace_repr_go_print_emit_A_const_30 any

var A_arbace_repr_go_print_emit_A_const_31 *lang.Var

var A_arbace_repr_go_print_emit_A_const_32 *lang.Var

var A_arbace_repr_go_print_emit_A_const_33 *lang.Var

var A_arbace_repr_go_print_emit_A_const_34 *lang.Var

var A_arbace_repr_go_print_emit_A_const_35 any

var A_arbace_repr_go_print_emit_A_const_36 any

var A_arbace_repr_go_print_emit_A_const_37 any

var A_arbace_repr_go_print_emit_A_const_38 any

var A_arbace_repr_go_print_emit_A_const_39 any

var A_arbace_repr_go_print_emit_A_const_40 *lang.Var

var A_arbace_repr_go_print_emit_A_const_41 any

var A_arbace_repr_go_print_emit_A_const_42 any

var A_arbace_repr_go_print_emit_A_const_43 any

var A_arbace_repr_go_print_emit_A_const_44 *lang.Var

var A_arbace_repr_go_print_emit_A_const_45 *lang.Var

var A_arbace_repr_go_print_emit_A_const_46 any

var A_arbace_repr_go_print_emit_A_const_47 any

var A_arbace_repr_go_print_emit_A_const_48 any

var A_arbace_repr_go_print_emit_A_const_49 any

var A_arbace_repr_go_print_emit_A_const_50 any

var A_arbace_repr_go_print_emit_A_const_51 *lang.Var

var A_arbace_repr_go_print_emit_A_const_52 *lang.Var

var A_arbace_repr_go_print_emit_A_const_53 any

var A_arbace_repr_go_print_emit_A_const_54 *lang.Var

var A_arbace_repr_go_print_emit_A_const_55 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_56 any

var A_arbace_repr_go_print_emit_A_const_57 any

var A_arbace_repr_go_print_emit_A_const_58 any

var A_arbace_repr_go_print_emit_A_const_59 any

var A_arbace_repr_go_print_emit_A_const_60 any

var A_arbace_repr_go_print_emit_A_const_61 any

var A_arbace_repr_go_print_emit_A_const_62 any

var A_arbace_repr_go_print_emit_A_const_63 any

var A_arbace_repr_go_print_emit_A_const_64 any

var A_arbace_repr_go_print_emit_A_const_65 any

var A_arbace_repr_go_print_emit_A_const_66 any

var A_arbace_repr_go_print_emit_A_const_67 any

var A_arbace_repr_go_print_emit_A_const_68 *lang.Var

var A_arbace_repr_go_print_emit_A_const_69 any

var A_arbace_repr_go_print_emit_A_const_70 *lang.Var

var A_arbace_repr_go_print_emit_A_const_71 any

var A_arbace_repr_go_print_emit_A_const_72 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_73 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_74 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_75 *lang.Var

var A_arbace_repr_go_print_emit_A_const_76 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_77 *lang.Var

var A_arbace_repr_go_print_emit_A_const_78 *lang.Var

var A_arbace_repr_go_print_emit_A_const_79 any

var A_arbace_repr_go_print_emit_A_const_80 *lang.Var

var A_arbace_repr_go_print_emit_A_const_81 *lang.Var

var A_arbace_repr_go_print_emit_A_const_82 *lang.Var

var A_arbace_repr_go_print_emit_A_const_83 *lang.Var

var A_arbace_repr_go_print_emit_A_const_84 any

var A_arbace_repr_go_print_emit_A_const_85 any

var A_arbace_repr_go_print_emit_A_const_86 *lang.Var

var A_arbace_repr_go_print_emit_A_const_87 any

var A_arbace_repr_go_print_emit_A_const_88 *lang.Var

var A_arbace_repr_go_print_emit_A_const_89 *lang.Var

var A_arbace_repr_go_print_emit_A_const_90 *lang.Var

var A_arbace_repr_go_print_emit_A_const_91 *lang.Var

var A_arbace_repr_go_print_emit_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_93 *lang.Var

var A_arbace_repr_go_print_emit_A_const_94 *lang.Var

var A_arbace_repr_go_print_emit_A_const_95 *lang.Var

var A_arbace_repr_go_print_emit_A_const_96 *lang.Var

var A_arbace_repr_go_print_emit_A_const_97 *lang.Var

var A_arbace_repr_go_print_emit_A_const_98 *lang.Var

var A_arbace_repr_go_print_emit_A_const_99 *lang.Var

var A_arbace_repr_go_print_emit_A_const_100 any

var A_arbace_repr_go_print_emit_A_const_101 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_102 *lang.Var

var A_arbace_repr_go_print_emit_A_const_103 *lang.Var

var A_arbace_repr_go_print_emit_A_const_104 *lang.Var

var A_arbace_repr_go_print_emit_A_const_105 *lang.Var

var A_arbace_repr_go_print_emit_A_const_106 *lang.Var

var A_arbace_repr_go_print_emit_A_const_107 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_108 *lang.Var

var A_arbace_repr_go_print_emit_A_const_109 *lang.Var

var A_arbace_repr_go_print_emit_A_const_110 *lang.Var

var A_arbace_repr_go_print_emit_A_const_111 *lang.Var

var A_arbace_repr_go_print_emit_A_const_112 any

var A_arbace_repr_go_print_emit_A_const_113 *lang.Var

var A_arbace_repr_go_print_emit_A_const_114 *lang.Var

var A_arbace_repr_go_print_emit_A_const_115 *lang.Var

var A_arbace_repr_go_print_emit_A_const_116 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_117 *lang.Var

var A_arbace_repr_go_print_emit_A_const_118 *lang.Var

var A_arbace_repr_go_print_emit_A_const_119 *lang.Var

var A_arbace_repr_go_print_emit_A_const_120 *lang.Var

var A_arbace_repr_go_print_emit_A_const_121 *lang.Var

var A_arbace_repr_go_print_emit_A_const_122 *lang.Var

var A_arbace_repr_go_print_emit_A_const_123 *lang.Var

var A_arbace_repr_go_print_emit_A_const_124 *lang.Var

var A_arbace_repr_go_print_emit_A_const_125 *lang.Var

var A_arbace_repr_go_print_emit_A_const_126 *lang.Var

var A_arbace_repr_go_print_emit_A_const_127 *lang.Var

var A_arbace_repr_go_print_emit_A_const_128 *lang.Var

var A_arbace_repr_go_print_emit_A_const_129 *lang.Var

var A_arbace_repr_go_print_emit_A_const_130 *lang.Var

var A_arbace_repr_go_print_emit_A_const_131 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_132 *lang.Var

var A_arbace_repr_go_print_emit_A_const_133 *lang.Var

var A_arbace_repr_go_print_emit_A_const_134 *lang.Var

var A_arbace_repr_go_print_emit_A_const_135 *lang.Var

var A_arbace_repr_go_print_emit_A_const_136 *lang.Var

var A_arbace_repr_go_print_emit_A_const_137 *lang.Var

var A_arbace_repr_go_print_emit_A_const_138 *lang.Var

var A_arbace_repr_go_print_emit_A_const_139 *lang.Var

var A_arbace_repr_go_print_emit_A_const_140 *lang.Var

var A_arbace_repr_go_print_emit_A_const_141 any

var A_arbace_repr_go_print_emit_A_const_142 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_143 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_144 *lang.Var

var A_arbace_repr_go_print_emit_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_146 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_147 any

var A_arbace_repr_go_print_emit_A_const_148 *lang.Var

var A_arbace_repr_go_print_emit_A_const_149 *lang.Var

var A_arbace_repr_go_print_emit_A_const_150 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_151 *lang.Var

var A_arbace_repr_go_print_emit_A_const_152 *lang.Var

var A_arbace_repr_go_print_emit_A_const_153 *lang.Var

var A_arbace_repr_go_print_emit_A_const_154 *lang.Var

var A_arbace_repr_go_print_emit_A_const_155 *lang.Var

var A_arbace_repr_go_print_emit_A_init jrt.ClassInit

func A_arbace_repr_go_print_emit_A_Init() { if !A_arbace_repr_go_print_emit_A_init.Done() { A_arbace_repr_go_print_emit_A_init.Run(A_arbace_repr_go_print_emit_A_clinit) } }

func A_arbace_repr_go_print_emit_A_clinit() { A_arbace_repr_go_print_emit_A_clinit_p0(); A_arbace_repr_go_print_emit_A_clinit_p1(); A_arbace_repr_go_print_emit_A_clinit_p2(); A_arbace_repr_go_print_emit_A_clinit_p3(); A_arbace_repr_go_print_emit_A_clinit_p4(); A_arbace_repr_go_print_emit_A_clinit_p5(); A_arbace_repr_go_print_emit_A_clinit_p6(); A_arbace_repr_go_print_emit_A_clinit_p7(); A_arbace_repr_go_print_emit_A_clinit_p8(); A_arbace_repr_go_print_emit_A_clinit_p9(); A_arbace_repr_go_print_emit_A_clinit_p10(); A_arbace_repr_go_print_emit_A_clinit_p11(); A_arbace_repr_go_print_emit_A_clinit_p12() }

func A_arbace_repr_go_print_emit_A_clinit_p0() { A_arbace_repr_go_print_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 204); A_arbace_repr_go_print_emit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[48]); A_arbace_repr_go_print_emit_A_const_1 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[49]); A_arbace_repr_go_print_emit_A_const_2 = A_arbace_repr_go_print_emit_A_const_pool.A[50]; A_arbace_repr_go_print_emit_A_const_3 = A_arbace_repr_go_print_emit_A_const_pool.A[51]; A_arbace_repr_go_print_emit_A_const_4 = A_arbace_repr_go_print_emit_A_const_pool.A[52]; A_arbace_repr_go_print_emit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[53]); A_arbace_repr_go_print_emit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[54]); A_arbace_repr_go_print_emit_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[55]); A_arbace_repr_go_print_emit_A_const_8 = A_arbace_repr_go_print_emit_A_const_pool.A[56]; A_arbace_repr_go_print_emit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[57]); A_arbace_repr_go_print_emit_A_const_10 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[58]); A_arbace_repr_go_print_emit_A_const_11 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[59]) }

func A_arbace_repr_go_print_emit_A_clinit_p1() { A_arbace_repr_go_print_emit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[60]); A_arbace_repr_go_print_emit_A_const_13 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[61]); A_arbace_repr_go_print_emit_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[62]); A_arbace_repr_go_print_emit_A_const_15 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[63]); A_arbace_repr_go_print_emit_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[64]); A_arbace_repr_go_print_emit_A_const_17 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[65]); A_arbace_repr_go_print_emit_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[66]); A_arbace_repr_go_print_emit_A_const_19 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[67]); A_arbace_repr_go_print_emit_A_const_20 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[68]); A_arbace_repr_go_print_emit_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[69]); A_arbace_repr_go_print_emit_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[70]); A_arbace_repr_go_print_emit_A_const_23 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[71]) }

func A_arbace_repr_go_print_emit_A_clinit_p2() { A_arbace_repr_go_print_emit_A_const_24 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[72]); A_arbace_repr_go_print_emit_A_const_25 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[73]); A_arbace_repr_go_print_emit_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[74]); A_arbace_repr_go_print_emit_A_const_27 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[75]); A_arbace_repr_go_print_emit_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[76]); A_arbace_repr_go_print_emit_A_const_29 = A_arbace_repr_go_print_emit_A_const_pool.A[77]; A_arbace_repr_go_print_emit_A_const_30 = A_arbace_repr_go_print_emit_A_const_pool.A[78]; A_arbace_repr_go_print_emit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[79]); A_arbace_repr_go_print_emit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[80]); A_arbace_repr_go_print_emit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[81]); A_arbace_repr_go_print_emit_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[82]); A_arbace_repr_go_print_emit_A_const_35 = A_arbace_repr_go_print_emit_A_const_pool.A[83]; A_arbace_repr_go_print_emit_A_const_36 = A_arbace_repr_go_print_emit_A_const_pool.A[84] }

func A_arbace_repr_go_print_emit_A_clinit_p3() { A_arbace_repr_go_print_emit_A_const_37 = A_arbace_repr_go_print_emit_A_const_pool.A[85]; A_arbace_repr_go_print_emit_A_const_38 = A_arbace_repr_go_print_emit_A_const_pool.A[86]; A_arbace_repr_go_print_emit_A_const_39 = A_arbace_repr_go_print_emit_A_const_pool.A[87]; A_arbace_repr_go_print_emit_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[88]); A_arbace_repr_go_print_emit_A_const_41 = A_arbace_repr_go_print_emit_A_const_pool.A[89]; A_arbace_repr_go_print_emit_A_const_42 = A_arbace_repr_go_print_emit_A_const_pool.A[90]; A_arbace_repr_go_print_emit_A_const_43 = A_arbace_repr_go_print_emit_A_const_pool.A[91]; A_arbace_repr_go_print_emit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[92]); A_arbace_repr_go_print_emit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[93]); A_arbace_repr_go_print_emit_A_const_46 = A_arbace_repr_go_print_emit_A_const_pool.A[94]; A_arbace_repr_go_print_emit_A_const_47 = A_arbace_repr_go_print_emit_A_const_pool.A[95]; A_arbace_repr_go_print_emit_A_const_48 = A_arbace_repr_go_print_emit_A_const_pool.A[96]; A_arbace_repr_go_print_emit_A_const_49 = A_arbace_repr_go_print_emit_A_const_pool.A[97]; A_arbace_repr_go_print_emit_A_const_50 = A_arbace_repr_go_print_emit_A_const_pool.A[98] }

func A_arbace_repr_go_print_emit_A_clinit_p4() { A_arbace_repr_go_print_emit_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[99]); A_arbace_repr_go_print_emit_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[100]); A_arbace_repr_go_print_emit_A_const_53 = A_arbace_repr_go_print_emit_A_const_pool.A[101]; A_arbace_repr_go_print_emit_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[102]); A_arbace_repr_go_print_emit_A_const_55 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[103]); A_arbace_repr_go_print_emit_A_const_56 = A_arbace_repr_go_print_emit_A_const_pool.A[104]; A_arbace_repr_go_print_emit_A_const_57 = A_arbace_repr_go_print_emit_A_const_pool.A[105]; A_arbace_repr_go_print_emit_A_const_58 = A_arbace_repr_go_print_emit_A_const_pool.A[106]; A_arbace_repr_go_print_emit_A_const_59 = A_arbace_repr_go_print_emit_A_const_pool.A[107]; A_arbace_repr_go_print_emit_A_const_60 = A_arbace_repr_go_print_emit_A_const_pool.A[108]; A_arbace_repr_go_print_emit_A_const_61 = A_arbace_repr_go_print_emit_A_const_pool.A[109]; A_arbace_repr_go_print_emit_A_const_62 = A_arbace_repr_go_print_emit_A_const_pool.A[110]; A_arbace_repr_go_print_emit_A_const_63 = A_arbace_repr_go_print_emit_A_const_pool.A[111]; A_arbace_repr_go_print_emit_A_const_64 = A_arbace_repr_go_print_emit_A_const_pool.A[112] }

func A_arbace_repr_go_print_emit_A_clinit_p5() { A_arbace_repr_go_print_emit_A_const_65 = A_arbace_repr_go_print_emit_A_const_pool.A[113]; A_arbace_repr_go_print_emit_A_const_66 = A_arbace_repr_go_print_emit_A_const_pool.A[114]; A_arbace_repr_go_print_emit_A_const_67 = A_arbace_repr_go_print_emit_A_const_pool.A[115]; A_arbace_repr_go_print_emit_A_const_68 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[116]); A_arbace_repr_go_print_emit_A_const_69 = A_arbace_repr_go_print_emit_A_const_pool.A[117]; A_arbace_repr_go_print_emit_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[118]); A_arbace_repr_go_print_emit_A_const_71 = A_arbace_repr_go_print_emit_A_const_pool.A[119]; A_arbace_repr_go_print_emit_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[120]); A_arbace_repr_go_print_emit_A_const_73 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[121]); A_arbace_repr_go_print_emit_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[122]); A_arbace_repr_go_print_emit_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[123]); A_arbace_repr_go_print_emit_A_const_76 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[124]); A_arbace_repr_go_print_emit_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[125]) }

func A_arbace_repr_go_print_emit_A_clinit_p6() { A_arbace_repr_go_print_emit_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[126]); A_arbace_repr_go_print_emit_A_const_79 = A_arbace_repr_go_print_emit_A_const_pool.A[127]; A_arbace_repr_go_print_emit_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[128]); A_arbace_repr_go_print_emit_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[129]); A_arbace_repr_go_print_emit_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[130]); A_arbace_repr_go_print_emit_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[131]); A_arbace_repr_go_print_emit_A_const_84 = A_arbace_repr_go_print_emit_A_const_pool.A[132]; A_arbace_repr_go_print_emit_A_const_85 = A_arbace_repr_go_print_emit_A_const_pool.A[133]; A_arbace_repr_go_print_emit_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[134]); A_arbace_repr_go_print_emit_A_const_87 = A_arbace_repr_go_print_emit_A_const_pool.A[135]; A_arbace_repr_go_print_emit_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[136]); A_arbace_repr_go_print_emit_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[137]); A_arbace_repr_go_print_emit_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[138]) }

func A_arbace_repr_go_print_emit_A_clinit_p7() { A_arbace_repr_go_print_emit_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[139]); A_arbace_repr_go_print_emit_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[140]); A_arbace_repr_go_print_emit_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[141]); A_arbace_repr_go_print_emit_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[142]); A_arbace_repr_go_print_emit_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[143]); A_arbace_repr_go_print_emit_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[144]); A_arbace_repr_go_print_emit_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[145]); A_arbace_repr_go_print_emit_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[146]); A_arbace_repr_go_print_emit_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[147]); A_arbace_repr_go_print_emit_A_const_100 = A_arbace_repr_go_print_emit_A_const_pool.A[148]; A_arbace_repr_go_print_emit_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[149]); A_arbace_repr_go_print_emit_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[150]) }

func A_arbace_repr_go_print_emit_A_clinit_p8() { A_arbace_repr_go_print_emit_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[151]); A_arbace_repr_go_print_emit_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[152]); A_arbace_repr_go_print_emit_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[153]); A_arbace_repr_go_print_emit_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[154]); A_arbace_repr_go_print_emit_A_const_107 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[155]); A_arbace_repr_go_print_emit_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[156]); A_arbace_repr_go_print_emit_A_const_109 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[157]); A_arbace_repr_go_print_emit_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[158]); A_arbace_repr_go_print_emit_A_const_111 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[159]); A_arbace_repr_go_print_emit_A_const_112 = A_arbace_repr_go_print_emit_A_const_pool.A[160]; A_arbace_repr_go_print_emit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[161]); A_arbace_repr_go_print_emit_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[162]) }

func A_arbace_repr_go_print_emit_A_clinit_p9() { A_arbace_repr_go_print_emit_A_const_115 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[163]); A_arbace_repr_go_print_emit_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[164]); A_arbace_repr_go_print_emit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[165]); A_arbace_repr_go_print_emit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[166]); A_arbace_repr_go_print_emit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[167]); A_arbace_repr_go_print_emit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[168]); A_arbace_repr_go_print_emit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[169]); A_arbace_repr_go_print_emit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[170]); A_arbace_repr_go_print_emit_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[171]); A_arbace_repr_go_print_emit_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[172]); A_arbace_repr_go_print_emit_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[173]); A_arbace_repr_go_print_emit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[174]) }

func A_arbace_repr_go_print_emit_A_clinit_p10() { A_arbace_repr_go_print_emit_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[175]); A_arbace_repr_go_print_emit_A_const_128 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[176]); A_arbace_repr_go_print_emit_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[177]); A_arbace_repr_go_print_emit_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[178]); A_arbace_repr_go_print_emit_A_const_131 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[179]); A_arbace_repr_go_print_emit_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[180]); A_arbace_repr_go_print_emit_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[181]); A_arbace_repr_go_print_emit_A_const_134 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[182]); A_arbace_repr_go_print_emit_A_const_135 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[183]); A_arbace_repr_go_print_emit_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[184]); A_arbace_repr_go_print_emit_A_const_137 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[185]); A_arbace_repr_go_print_emit_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[186]) }

func A_arbace_repr_go_print_emit_A_clinit_p11() { A_arbace_repr_go_print_emit_A_const_139 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[187]); A_arbace_repr_go_print_emit_A_const_140 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[188]); A_arbace_repr_go_print_emit_A_const_141 = A_arbace_repr_go_print_emit_A_const_pool.A[189]; A_arbace_repr_go_print_emit_A_const_142 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[190]); A_arbace_repr_go_print_emit_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[191]); A_arbace_repr_go_print_emit_A_const_144 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[192]); A_arbace_repr_go_print_emit_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[193]); A_arbace_repr_go_print_emit_A_const_146 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[194]); A_arbace_repr_go_print_emit_A_const_147 = A_arbace_repr_go_print_emit_A_const_pool.A[195]; A_arbace_repr_go_print_emit_A_const_148 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[196]); A_arbace_repr_go_print_emit_A_const_149 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[197]); A_arbace_repr_go_print_emit_A_const_150 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[198]) }

func A_arbace_repr_go_print_emit_A_clinit_p12() { A_arbace_repr_go_print_emit_A_const_151 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[199]); A_arbace_repr_go_print_emit_A_const_152 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[200]); A_arbace_repr_go_print_emit_A_const_153 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[201]); A_arbace_repr_go_print_emit_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[202]); A_arbace_repr_go_print_emit_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[203]) }

func A_arbace_repr_go_print_emit_A_New() *A_arbace_repr_go_print_emit_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_A_class }

func (t *A_arbace_repr_go_print_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_A); return ok }

func A_arbace_repr_go_print_emit_A_Cast(x any) *A_arbace_repr_go_print_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_A_class)) }; return v }



type A_arbace_repr_go_print_emit_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_bol_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_bol_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_break_to_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_break_to_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_chunk_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_chunk_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_close_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_close_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_comment_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_comment_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cont_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cont_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cur_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cur_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_fn__308000120_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000004_A_New() *A_arbace_repr_go_print_emit_eval308000004_A { t := &A_arbace_repr_go_print_emit_eval308000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000004_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); return ok }

func A_arbace_repr_go_print_emit_eval308000004_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000004_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000008_A_New() *A_arbace_repr_go_print_emit_eval308000008_A { t := &A_arbace_repr_go_print_emit_eval308000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000008_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); return ok }

func A_arbace_repr_go_print_emit_eval308000008_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000008_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000018_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000018_A_New() *A_arbace_repr_go_print_emit_eval308000018_A { t := &A_arbace_repr_go_print_emit_eval308000018_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000018_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); return ok }

func A_arbace_repr_go_print_emit_eval308000018_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000018_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000029_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000029_A_New() *A_arbace_repr_go_print_emit_eval308000029_A { t := &A_arbace_repr_go_print_emit_eval308000029_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000029_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); return ok }

func A_arbace_repr_go_print_emit_eval308000029_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000029_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000040_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000040_A_New() *A_arbace_repr_go_print_emit_eval308000040_A { t := &A_arbace_repr_go_print_emit_eval308000040_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000040_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); return ok }

func A_arbace_repr_go_print_emit_eval308000040_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000040_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000040_line__308000041_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000051_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000051_A_New() *A_arbace_repr_go_print_emit_eval308000051_A { t := &A_arbace_repr_go_print_emit_eval308000051_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000051_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); return ok }

func A_arbace_repr_go_print_emit_eval308000051_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000051_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000063_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000063_A_New() *A_arbace_repr_go_print_emit_eval308000063_A { t := &A_arbace_repr_go_print_emit_eval308000063_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000063_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); return ok }

func A_arbace_repr_go_print_emit_eval308000063_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000063_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000063_target__308000064_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000089_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000089_A_New() *A_arbace_repr_go_print_emit_eval308000089_A { t := &A_arbace_repr_go_print_emit_eval308000089_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000089_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); return ok }

func A_arbace_repr_go_print_emit_eval308000089_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000089_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000149_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000152_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000158_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000164_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_A struct{ j2g_header uint64; F_extras, F_items any }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000184_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000227_A struct{ j2g_header uint64; F_merged any; F_n int32; F_i any }

var A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000229_A struct{ j2g_header uint64; F_merged any; F_n int32; F_j any }

var A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000231_A struct{ j2g_header uint64; F_last_s, F_merged, F_tok_STAR_, F_j, F_i, F_same_line_QMARK_ any }

var A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000234_A struct{ j2g_header uint64; F_cl any }

var A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000236_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000238_A struct{ j2g_header uint64; F_obstacles, F_width, F_cur any }

var A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A struct{ j2g_header uint64; F_space, F_last_s, F_sb, F_prev_item, F_cur any }

var A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_join_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_join_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_comment_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_inline_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_own_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_own_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_lines_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_lines_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_may_combine_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_new_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_new_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_nl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_nl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000130_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000137_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000139_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000141_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000143_A struct{ j2g_header uint64; F_keep any }

var A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_natural__308000132_A struct{ j2g_header uint64; F_cl any; F_n int32; F_run, F_lens, F_cc any }

var A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_pop_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_pop_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_push_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_render_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_render_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_room_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_room_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_semi_after_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_set_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_soft_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_soft_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_sp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_sp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_stmt_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A struct{ j2g_header uint64; F_indent any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A struct{ j2g_header uint64; F_first_QMARK_, F_sep any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_utf8_len_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_utf8_len_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_vtab_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_vtab_A_fn_class *jrt.Class
