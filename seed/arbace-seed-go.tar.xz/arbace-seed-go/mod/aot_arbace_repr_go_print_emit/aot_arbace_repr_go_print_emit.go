//line aot_arbace_repr_go_print_emit.ae:1
package aot_arbace_repr_go_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_New() *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_3, A_arbace_repr_go_print_emit_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_New() *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_9), A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O(), A_arbace_repr_go_print_emit_A_const_8) }

















func A_arbace_repr_go_print_emit_new_state_A_New() *A_arbace_repr_go_print_emit_new_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_new_state_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_print_emit_new_state_A) Invoke_O_O__O(self, opts__0 any) any { var tmp1 any = A_arbace_repr_go_print_emit_A_const_10; var tmp2 any = jrt.StringBuilder_New(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_11; var tmp4 any; var temp__1927000414__auto____2 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(opts__0); if







	jrt.J2g_Truth(temp__1927000414__auto____2) { var f__3 any = temp__1927000414__auto____2; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_emit_A_const_27; var tmp7 any = jrt.ArrayList_New(); var tmp8 any = A_arbace_repr_go_print_emit_A_const_28
		tmp4 = tmp5.Invoke_O_O_O_O_O__O(f__3, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil)) } else {
//line :27:1
			tmp4 = nil }; var tmp9 any = tmp4; var tmp10 any = A_arbace_repr_go_print_emit_A_const_13; var tmp11 any = /*line :19:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29); var tmp12 any = A_arbace_repr_go_print_emit_A_const_15; var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()); var tmp14 any = A_arbace_repr_go_print_emit_A_const_16; var tmp15 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp16 any = A_arbace_repr_go_print_emit_A_const_17; var tmp17 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp18 any = A_arbace_repr_go_print_emit_A_const_18; var tmp19 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_2); var tmp20 any = A_arbace_repr_go_print_emit_A_const_19; var tmp21 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_FALSE.Ref()); var tmp22 any = A_arbace_repr_go_print_emit_A_const_20; var tmp23 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil); var tmp24 any = A_arbace_repr_go_print_emit_A_const_21; var tmp25 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); var tmp26 any = A_arbace_repr_go_print_emit_A_const_22; var tmp27 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_30); var tmp28 any = A_arbace_repr_go_print_emit_A_const_23; var tmp29 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29); var tmp30 any = A_arbace_repr_go_print_emit_A_const_24; var tmp31 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_24.Invoke_O__O(opts__0))).Ref(); var tmp32 any = A_arbace_repr_go_print_emit_A_const_25; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, A_arbace_repr_go_print_emit_A_const_26.Invoke_O_O__O(opts__0, jrt.Boolean_TRUE.Ref()))) }






















func A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_New() *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_24), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_35))) }
//line :42:1
func A_arbace_repr_go_print_emit_lines_QMARK__A_New() *A_arbace_repr_go_print_emit_lines_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_lines_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_emit_lines_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_New() *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_11), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_36))) }
//line :43:1
func A_arbace_repr_go_print_emit_full_QMARK__A_New() *A_arbace_repr_go_print_emit_full_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_QMARK__A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_go_print_emit_full_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; return tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) }
func A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_New() *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000040_line__308000041_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_eval308000040_line__308000041_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_38)))))) }
//line :44:1
func A_arbace_repr_go_print_emit_line_A_New() *A_arbace_repr_go_print_emit_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_print_emit_line_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
func A_arbace_repr_go_print_emit_bol_QMARK__A_New() *A_arbace_repr_go_print_emit_bol_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_bol_QMARK__A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_bol_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
//line :45:1
func A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_New() *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_39)))))) }

func A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_New() *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000063_target__308000064_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_eval308000063_target__308000064_A) Invoke_O_O__O(self, f__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_41), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_42)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_43), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_47), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(f__1))))))))))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_48), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_49), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_50), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_46)))))))))))) }
//line :47:1
func A_arbace_repr_go_print_emit_target_A_New() *A_arbace_repr_go_print_emit_target_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_target_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_emit_target_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____2)) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }







func A_arbace_repr_go_print_emit_room_QMARK__A_New() *A_arbace_repr_go_print_emit_room_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_room_QMARK__A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_emit_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); if



	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_52.Get__O(), nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp2 bool; var na_1 int64 = lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_52.Get__O()); var na_2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_3 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var na_4 int64 = lang.RT_LongCast_O__J_NoInit(n__0); if jrt.Long_InstanceOf(na_3) { var n0_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); var n1_6 int64 = na_4; var nr_7 int64 = n0_5 + n1_6; if (n0_5^nr_7)&(n1_6^nr_7) >= 0 { na_2 = jrt.Long_ValueOf_J__Long_NoInit(nr_7).Ref() } else { na_2 = lang.Numbers_Add_O_J__Number_NoInit(na_3, na_4) } } else { na_2 = lang.Numbers_Add_O_J__Number_NoInit(na_3, na_4) }; if jrt.Long_InstanceOf(na_2) { var n0_8 int64 = na_1; var n1_9 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); tmp2 = n0_8 > n1_9 } else { tmp2 = lang.Numbers_Gt_J_O__Z_NoInit(na_1, na_2) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } } }









func A_arbace_repr_go_print_emit_semi_after_QMARK__A_New() *A_arbace_repr_go_print_emit_semi_after_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_semi_after_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_repr_go_print_emit_semi_after_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_53).Invoke_O__O(s__0)) { return jrt.Boolean_TRUE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(s__0)) { return jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { var c__2 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())))); var or__1927000174__auto____3 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(c__2)




		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_57)).CharValue__C()); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_58)).CharValue__C()); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__2, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_59)).CharValue__C()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else {
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_IntCast_C__I_NoInit(c__2)), 127)).Ref() } } } } } } else {
//line :72:1
				return nil
			}
	}
	}
	}
}


func A_arbace_repr_go_print_emit_may_combine_QMARK__A_New() *A_arbace_repr_go_print_emit_may_combine_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_may_combine_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_repr_go_print_emit_may_combine_QMARK__A) Invoke_O_O_O__O(self, prev__0, next__1 any) any {



	var tmp1 bool; var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())); if and__1927000168__auto____3 { tmp1 = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(next__1)).Length__I())) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var p__3 uint16 = jrt.NN(jrt.String_Cast(prev__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())))); var n__4 uint16 = jrt.NN(jrt.String_Cast(next__1)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); var or__1927000174__auto____5 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_28)


		if and__1927000168__auto____5 { or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_60)).CharValue__C()) } else { or__1927000174__auto____5 = and__1927000168__auto____5 }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_29)
			if and__1927000168__auto____6 { or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :87:1
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C())

				if and__1927000168__auto____7 { var or__1927000174__auto____8 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_63)).CharValue__C()); if or__1927000174__auto____8 { or__1927000174__auto____7 = or__1927000174__auto____8 } else { or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_62)).CharValue__C()) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :87:1
				if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8_2 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_30)


					if and__1927000168__auto____8 { var or__1927000174__auto____9 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_61)).CharValue__C()); if or__1927000174__auto____9 { or__1927000174__auto____8_2 = or__1927000174__auto____9 } else { or__1927000174__auto____8_2 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_64)).CharValue__C()) } } else { or__1927000174__auto____8_2 = and__1927000168__auto____8 }
//line :87:1
					if or__1927000174__auto____8_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8_2).Ref() } else { var or__1927000174__auto____9_2 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(prev__0, Lit_31)



						if and__1927000168__auto____9 { var or__1927000174__auto____10 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_65)).CharValue__C()); if or__1927000174__auto____10 { or__1927000174__auto____9_2 = or__1927000174__auto____10 } else { or__1927000174__auto____9_2 = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_66)).CharValue__C()) } } else { or__1927000174__auto____9_2 = and__1927000168__auto____9 }
//line :87:1
						if or__1927000174__auto____9_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9_2).Ref() } else { var or__1927000174__auto____10_2 any; var and__1927000168__auto____10 bool = jrt.Character_IsDigit_C__Z_NoInit(p__3)




							if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_67)).CharValue__C()); if and__1927000168__auto____11 { or__1927000174__auto____10_2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_68.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_69, prev__0) } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }
//line :87:1
							if jrt.J2g_Truth(or__1927000174__auto____10_2) { return or__1927000174__auto____10_2 } else { var and__1927000168__auto____11_2 bool; var or__1927000174__auto____11 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(p__3)





								if or__1927000174__auto____11 { and__1927000168__auto____11_2 = or__1927000174__auto____11 } else { and__1927000168__auto____11_2 = lang.Util_Equiv_C_C__Z_NoInit(p__3, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C()) }; if and__1927000168__auto____11_2 { var or__1927000174__auto____12 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(n__4)
									if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_C_C__Z_NoInit(n__4, jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_emit_A_const_56)).CharValue__C())).Ref() } } else {
//line :93:1
										return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() } } } } } } } } else {
//line :84:1
											return nil
										}
}









func A_arbace_repr_go_print_emit_start_line_BANG__A_New() *A_arbace_repr_go_print_emit_start_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_line_BANG__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_print_emit_start_line_BANG__A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1))) { var n__2 int64 = lang.Numbers_Max_J_J__J_NoInit(0, lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__1)))); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J_NoInit(n__2); var ___5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(___5, n__1927000701__auto____4) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___5 = lang.Numbers_Unchecked_inc_J__J_NoInit(___5); continue L1 }
//line :98:1
		break L1
	}


		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__1), jrt.Long_ValueOf_J__Long_NoInit(n__2).Ref())
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1), jrt.Boolean_FALSE.Ref())
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__1), nil) } else {
//line :98:1
			return nil } }







func A_arbace_repr_go_print_emit_at_BANG__A_New() *A_arbace_repr_go_print_emit_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_at_BANG__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_print_emit_at_BANG__A) Invoke_O_O__O(self, pos__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var fs__3 any = temp__1927000414__auto____2
		if jrt.J2g_Truth(pos__0) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3), pos__0) }
//line :109:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_full_tok_A_New() *A_arbace_repr_go_print_emit_full_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_tok_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_emit_full_tok_A) Invoke_O_O__O(self, s__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var fs__3 any = A_arbace_repr_go_print_emit_A_const_11.Invoke_O__O(p__2); var pos__4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3));





	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_28.Invoke_O__O(fs__3), nil); var tmp1 /*line :120:1*/*jrt.ArrayList = jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__3)); var tmp2 any = A_arbace_repr_go_print_emit_A_const_72; var tmp3 any = A_arbace_repr_go_print_emit_A_const_73; var tmp4 any = A_arbace_repr_go_print_emit_A_const_74; var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2)); if
	jrt.J2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2)), s__0) }; /*line :120:1*/jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(tmp1).Add_O__Z(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, s__0, tmp3, pos__4, tmp4, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref()))));

	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil);
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2), s__0); return nil }


func A_arbace_repr_go_print_emit_soft_A_New() *A_arbace_repr_go_print_emit_soft_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_soft_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_go_print_emit_soft_A) Invoke_O_O_O__O(self, kind__0, s__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var temp__1927000414__auto____3 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); if




	jrt.J2g_Truth(temp__1927000414__auto____3) { var fs__4 any = temp__1927000414__auto____3
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__4))).Add_O__Z(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_emit_A_const_76, kind__0, A_arbace_repr_go_print_emit_A_const_72, s__1))))
//line :131:1
		return nil } else { return nil } }



func A_arbace_repr_go_print_emit_tok_A_New() *A_arbace_repr_go_print_emit_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_tok_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_print_emit_tok_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O()).Invoke_O__O(s__0) } else {
//line :138:1
			var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2); var at_bol__4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__2))



			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O()
//line :138:1
			var ws__5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2))





			if jrt.J2g_Truth(at_bol__4) { } else { if jrt.J2g_Truth(ws__5) {

				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(ws__5)) } else {
//line :144:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2)), s__0)) {


						jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } }
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil)
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(s__0))
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__2), s__0)
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(s__0))
//line :138:1
			return nil
		}
}













func A_arbace_repr_go_print_emit_raw_tok_A_New() *A_arbace_repr_go_print_emit_raw_tok_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Ctor() {}
//line :154:1
func (t *A_arbace_repr_go_print_emit_raw_tok_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_77.GetRawRoot__O()).Invoke_O__O(s__0) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(s__0))
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var tmp3 *lang.Volatile = lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp4 jrt.Number_I; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_11 any = jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(); var na_12 int64; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New(); var tmp8 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class = fncls__16d; tmp8 = fncls__16d } else { tmp8 = fncls__16 }; na_12 = int64(lang.RT_Count_O__I_NoInit(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), s__0))); if jrt.Long_InstanceOf(na_11) { var n0_13 int64 = jrt.NN(jrt.Long_Cast(na_11)).LongValue__J(); var n1_14 int64 = na_12; var nr_15 int64 = n0_13 + n1_14; if (n0_13^nr_15)&(n1_14^nr_15) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_15)) } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_11, na_12) } } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_11, na_12) }; jrt.NN(tmp3).Reset_O__O(tmp4)
			var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), jrt.Boolean_TRUE.Ref()) } }
//line :161:1
func A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_New() *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A) Invoke_O_O__O(self, p1__308000077_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__308000077_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }


func A_arbace_repr_go_print_emit_sp_A_New() *A_arbace_repr_go_print_emit_sp_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_sp_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Ctor() {}
//line :164:1
func (t *A_arbace_repr_go_print_emit_sp_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79) } else {
			var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else {
				var tmp4 any = A_arbace_repr_go_print_emit_A_const_85; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79)
				} } } }
func A_arbace_repr_go_print_emit_vtab_A_New() *A_arbace_repr_go_print_emit_vtab_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_vtab_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_print_emit_vtab_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79) } else {
			var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return nil } else {

				var tmp4 any = A_arbace_repr_go_print_emit_A_const_85; var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; jrt.NN(jrt.StringBuilder_Cast(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(11)) }
				var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(11)).Ref())
			} } }
func A_arbace_repr_go_print_emit_nl_A_New() *A_arbace_repr_go_print_emit_nl_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_nl_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Ctor() {}
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O_O__O(self, indent__0, form_feed_QMARK___1 any) any {




	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), nil) } else {
//line :187:1
			var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3)


			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3), nil)
			var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp4 uint16; if jrt.J2g_Truth(form_feed_QMARK___1) { tmp4 = lang.RT_CharCast_J__C_NoInit(12) } else { tmp4 = lang.RT_CharCast_J__C_NoInit(10) }; jrt.NN(tmp3).Append_C__StringBuilder(tmp4)
			var tmp5 *lang.Volatile = lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3)); var tmp6 jrt.Number_I; var na_17 any = jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3))).Deref__O(); if jrt.Long_InstanceOf(na_17) { var n0_18 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); if n0_18 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_17) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_18 + 1)) } } else { if jrt.Double_InstanceOf(na_17) { var n0_18_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_18_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_17) } }; jrt.NN(tmp5).Reset_O__O(tmp6)
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3), jrt.Boolean_TRUE.Ref())
			lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3), indent__0)
//line :187:1
			return nil } }
//line :182:1
func (t *A_arbace_repr_go_print_emit_nl_A) Invoke_O_O__O(self, indent__0 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O_O__O(indent__0, jrt.Boolean_FALSE.Ref())
}










func A_arbace_repr_go_print_emit_cur_indent_A_New() *A_arbace_repr_go_print_emit_cur_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cur_indent_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_cur_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_17; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }
//line :197:1
func A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_New() *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_37), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_87)))))) }

func A_arbace_repr_go_print_emit_push_open_BANG__A_New() *A_arbace_repr_go_print_emit_push_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_push_open_BANG__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O_O__O(self, indent__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), indent__0))
//line :199:1
	return nil }
//line :199:1
func (t *A_arbace_repr_go_print_emit_push_open_BANG__A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_88.GetRawRoot__O()); var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_17; tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) }; return tmp1.Invoke_O__O(tmp2)
}

func A_arbace_repr_go_print_emit_pop_open_BANG__A_New() *A_arbace_repr_go_print_emit_pop_open_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_pop_open_BANG__A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Ctor() {}
//line :205:1
func (t *A_arbace_repr_go_print_emit_pop_open_BANG__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var o__1 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))); var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21;

	jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_90.GetRawRoot__O()).Invoke_O__O(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O())); return o__1 }


func A_arbace_repr_go_print_emit_cont_indent_A_New() *A_arbace_repr_go_print_emit_cont_indent_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_cont_indent_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Ctor() {}
//line :210:1
func (t *A_arbace_repr_go_print_emit_cont_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_21; var o__1 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))); var tmp2 any; var or__1927000174__auto____2 any = o__1; if



	jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_repr_go_print_emit_A_const_30 }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(tmp2))).Ref() }

func A_arbace_repr_go_print_emit_comment_line_A_New() *A_arbace_repr_go_print_emit_comment_line_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_comment_line_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Ctor() {}
//line :216:1
func (t *A_arbace_repr_go_print_emit_comment_line_A) Invoke_O_O_O__O(self, s__0, indent__1 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return nil } else { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__4 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3)
		var tmp2 /*line :220:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_15

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__1) }
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3); var tmp5 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_1)) { tmp5 = A_arbace_repr_go_print_emit_A_const_30 } else { tmp5 = indent__1 }; tmp3.Invoke_O_O__O(tmp4, tmp5)
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O()
		jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(s__0)))
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3), Lit_2)
		lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3), jrt.Boolean_FALSE.Ref())
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__1)
	} }
func A_arbace_repr_go_print_emit_set_line_BANG__A_New() *A_arbace_repr_go_print_emit_set_line_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_set_line_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_repr_go_print_emit_set_line_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; return jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Min_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J_NoInit(l__0)))
}














func A_arbace_repr_go_print_emit_start_at_BANG__A_New() *A_arbace_repr_go_print_emit_start_at_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_start_at_BANG__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Ctor() {}
//line :250:1
func (t *A_arbace_repr_go_print_emit_start_at_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_23; return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), l__0)
}
func A_arbace_repr_go_print_emit_chunk_state_A_New() *A_arbace_repr_go_print_emit_chunk_state_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_chunk_state_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_print_emit_chunk_state_A) Invoke_O__O(self any) any { var p__1 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var tmp1 any = A_arbace_repr_go_print_emit_A_const_92; var tmp2 any = jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__1))).ToString__String().Ref(); var tmp3 any = A_arbace_repr_go_print_emit_A_const_13; var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__1)); var tmp5 any = A_arbace_repr_go_print_emit_A_const_15; var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__1)); var tmp7 any = A_arbace_repr_go_print_emit_A_const_16; var tmp8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__1)); var tmp9 any = A_arbace_repr_go_print_emit_A_const_17; var tmp10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__1)); var tmp11 any = A_arbace_repr_go_print_emit_A_const_18; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__1)); var tmp13 any = A_arbace_repr_go_print_emit_A_const_19; var tmp14 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__1)); var tmp15 any = A_arbace_repr_go_print_emit_A_const_20; var tmp16 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__1)); var tmp17 any = A_arbace_repr_go_print_emit_A_const_21; var tmp18 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__1)); var tmp19 any = A_arbace_repr_go_print_emit_A_const_22; var tmp20 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__1)); var tmp21 any = A_arbace_repr_go_print_emit_A_const_23; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__1)))) }









func A_arbace_repr_go_print_emit_join_BANG__A_New() *A_arbace_repr_go_print_emit_join_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_join_BANG__A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Ctor() {}
//line :266:1
func (t *A_arbace_repr_go_print_emit_join_BANG__A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var p__3 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var l__4 int64 = lang.RT_LongCast_O__J_NoInit(l__1); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3)); if





	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool = lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3)))); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3)), nil); if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_93.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__3))); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____10 {
		tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(c__0)), l__4)).Ref() } else {
//line :272:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {

				jrt.NN(jrt.StringBuilder_Cast(A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__3))).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_92.Invoke_O__O(c__0)))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_13.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_15.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_16.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_17.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_18.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_19.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(p__3), A_arbace_repr_go_print_emit_A_const_21.Invoke_O__O(c__0))
				jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Max_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_22.Invoke_O__O(c__0))))
				jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Min_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J_NoInit(A_arbace_repr_go_print_emit_A_const_23.Invoke_O__O(c__0))))
//line :272:1
				return jrt.Boolean_TRUE.Ref() } else { return jrt.Boolean_FALSE.Ref() } }















func A_arbace_repr_go_print_emit_line_directive_inline_A_New() *A_arbace_repr_go_print_emit_line_directive_inline_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_inline_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Ctor() {}
//line :288:1
func (t *A_arbace_repr_go_print_emit_line_directive_inline_A) Invoke_O_O__O(self, n__0 any) any { var p__2 any = A_arbace_repr_go_print_emit_A_const_31.Get__O(); var sb__3 any = A_arbace_repr_go_print_emit_A_const_10.Invoke_O__O(p__2);



	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_78.GetRawRoot__O()).Invoke__O(); var temp__1927000414__auto____4 any = /*line :288:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var ws__5 any = temp__1927000414__auto____4; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(ws__5)) };
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)));
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_20.Invoke_O__O(p__2), nil); return /*line :296:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_repr_go_print_emit_line_directive_own_A_New() *A_arbace_repr_go_print_emit_line_directive_own_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_directive_own_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Ctor() {}
//line :298:1
func (t *A_arbace_repr_go_print_emit_line_directive_own_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; var ind__2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()));



	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), ind__2); return /*line :303:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(n__0) }




func A_arbace_repr_go_print_emit_render_A_New() *A_arbace_repr_go_print_emit_render_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_render_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Ctor() {}
//line :308:1
func (t *A_arbace_repr_go_print_emit_render_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_98.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_A_const_31; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_99.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_100), A_arbace_repr_go_print_emit_A_const_52, nil))
//line :308:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		lang.IFn_Cast(f__0).Invoke__O()
		{ var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; tmp3 = jrt.NN(jrt.StringBuilder_Cast(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref() }
//line :308:1
		return nil
	}()


	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_96.GetRawRoot__O()).Invoke__O()
//line :308:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}







func A_arbace_repr_go_print_emit_break_to_BANG__A_New() *A_arbace_repr_go_print_emit_break_to_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_break_to_BANG__A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_go_print_emit_break_to_BANG__A) Invoke_O_O__O(self, t__0 any) any {



	{ var tmp1 any; var and__1927000168__auto____2 any = t__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var mark__2 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var brk_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_repr_go_print_emit_A_const_101); var t__4 any





		if brk_QMARK___3 { var tmp4 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; t__4 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; t__4 = lang.Numbers_Max_J_O__O_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(mark__2))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) } } else { t__4 = t__0 }
		jrt.NN(lang.Volatile_Cast(mark__2)).Reset_O__O(lang.Numbers_Max_O_O__O_NoInit(jrt.NN(lang.Volatile_Cast(mark__2)).Deref__O(), t__4))
		var tmp7 bool; var na_19 any = t__4; var tmp8 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_20 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp9 bool; var tmp10 bool
		tmp10 = jrt.Long_InstanceOf(na_19); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_20) }; tmp9 = tmp10; if tmp9 { var n0_21 int64 = jrt.NN(jrt.Long_Cast(na_19)).LongValue__J(); var n1_22 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); tmp7 = n0_21 > n1_22 } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_19); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_20) }; tmp11 = tmp12; if tmp11 { var n0_21_2 float64 = jrt.NN(jrt.Double_Cast(na_19)).DoubleValue__D(); var n1_22_2 float64 = jrt.NN(jrt.Double_Cast(na_20)).DoubleValue__D(); tmp7 = n1_22_2 < n0_21_2 } else { tmp7 = lang.Numbers_Gt_O_O__Z_NoInit(na_19, na_20) } }
//line :329:1
		if tmp7 {

			var tmp13 any; var tmp14 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_19; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp15 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; tmp13 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) } else { tmp13 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp13) {
				var tmp16 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp16.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(t__4) } else { return nil } } else {
//line :331:1
					var ci__5 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_103.GetRawRoot__O()).Invoke__O(); L1: for {


						var tmp17 bool; var tmp18 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_24 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var na_25 any = t__4; var tmp19 bool; var tmp20 bool; tmp20 = jrt.Long_InstanceOf(na_24); if tmp20 { tmp20 = jrt.Long_InstanceOf(na_25) }; tmp19 = tmp20; if tmp19 { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); var n1_27 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); tmp17 = n0_26 < n1_27 } else { var tmp21 bool; var tmp22 bool; tmp22 = jrt.Double_InstanceOf(na_24); if tmp22 { tmp22 = jrt.Double_InstanceOf(na_25) }; tmp21 = tmp22; if tmp21 { var n0_26_2 float64 = jrt.NN(jrt.Double_Cast(na_24)).DoubleValue__D(); var n1_27_2 float64 = jrt.NN(jrt.Double_Cast(na_25)).DoubleValue__D(); tmp17 = n0_26_2 < n1_27_2 } else { tmp17 = lang.Numbers_Lt_O_O__Z_NoInit(na_24, na_25) } }; if tmp17 { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(ci__5); continue L1 } else { return nil } } } } else {
//line :329:1
							var tmp23 any; var and__1927000168__auto____5_2 bool; var na_29 any = t__4; var tmp24 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_30 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp24.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var tmp25 bool; var tmp26 bool





							tmp26 = jrt.Long_InstanceOf(na_29); if tmp26 { tmp26 = jrt.Long_InstanceOf(na_30) }; tmp25 = tmp26; if tmp25 { var n0_31 int64 = jrt.NN(jrt.Long_Cast(na_29)).LongValue__J(); var n1_32 int64 = jrt.NN(jrt.Long_Cast(na_30)).LongValue__J(); and__1927000168__auto____5_2 = n0_31 < n1_32 } else { var tmp27 bool; var tmp28 bool; tmp28 = jrt.Double_InstanceOf(na_29); if tmp28 { tmp28 = jrt.Double_InstanceOf(na_30) }; tmp27 = tmp28; if tmp27 { var n0_31_2 float64 = jrt.NN(jrt.Double_Cast(na_29)).DoubleValue__D(); var n1_32_2 float64 = jrt.NN(jrt.Double_Cast(na_30)).DoubleValue__D(); and__1927000168__auto____5_2 = n0_31_2 < n1_32_2 } else { and__1927000168__auto____5_2 = lang.Numbers_Lt_O_O__Z_NoInit(na_29, na_30) } }; if and__1927000168__auto____5_2 { var tmp29 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; tmp23 = tmp29.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()) } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }
//line :329:1
							if jrt.J2g_Truth(tmp23) {






								return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(t__4) } else {
//line :329:1
									return nil } } } else {
//line :321:1
										return nil } }
//line :317:1
	panic("j2g: unreachable")
}



















func A_arbace_repr_go_print_emit_stmt_break_BANG__A_New() *A_arbace_repr_go_print_emit_stmt_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Ctor() {}
//line :338:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__A) Invoke_O_O_O_O_O__O(self, t__0, first_QMARK___1, sep__2, indent__3 any) any { var newline_BANG___5 any; var tmp1 any = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(indent__3); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class; if





	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; newline_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var same_BANG___6 any; var tmp3 any = /*line :338:1*/A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(first_QMARK___1, sep__2); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class; if






	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; same_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(t__0)) { var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp6 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Max_O_J__O_NoInit(jrt.NN(lang.Volatile_Cast(tmp6.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.RT_LongCast_O__J_NoInit(t__0))) }; var tmp7 /*line :347:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		var tmp8 any; var and__1927000168__auto____7 any = sep__2; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(first_QMARK___1) } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_106.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_107, sep__2) }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_20; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), A_arbace_repr_go_print_emit_A_const_79)
//line :347:1
		return jrt.Boolean_FALSE.Ref() } else { var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {

			var tmp11 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_16; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()), indent__3)
//line :347:1
			return jrt.Boolean_FALSE.Ref() } else { var tmp12 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {


				return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else {
//line :347:1
					if lang.Util_Identical_O_O__Z_NoInit(t__0, nil) {



						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29)) { return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else { return lang.IFn_Cast(same_BANG___6).Invoke__O() } } else {
//line :347:1
							if lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_repr_go_print_emit_A_const_101) {




								return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else {
//line :347:1
									var tmp13 bool; var na_36 int64 = lang.RT_LongCast_O__J_NoInit(t__0); var tmp14 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_37 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))





									if jrt.Long_InstanceOf(na_37) { var n0_38 int64 = na_36; var n1_39 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); tmp13 = n0_38 > n1_39 } else { tmp13 = lang.Numbers_Gt_J_O__Z_NoInit(na_36, na_37) }
//line :347:1
									if tmp13 {





										var tmp15 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp16 jrt.Number_I; var na_41 int64 = lang.RT_LongCast_O__J_NoInit(t__0); var tmp17 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_42 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp17.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); if jrt.Long_InstanceOf(na_42) { var n0_43 int64 = na_41; var n1_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); var nr_45 int64 = n0_43 - n1_44; var tmp18 bool; var tmp19 bool; tmp19 = !(n1_44 == -9223372036854775808); if tmp19 { tmp19 = (n0_43^n1_44)&(n0_43^nr_45) >= 0 }; tmp18 = tmp19; if tmp18 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_45)) } else { tmp16 = lang.Numbers_Minus_J_O__Number_NoInit(na_41, na_42) } } else { tmp16 = lang.Numbers_Minus_J_O__Number_NoInit(na_41, na_42) }; return tmp15.Invoke_O__O(tmp16) } else {
//line :347:1
											var tmp20 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Util_Equiv_J_O__Z_NoInit(lang.RT_LongCast_O__J_NoInit(t__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) {






												return lang.IFn_Cast(same_BANG___6).Invoke__O() } else {
//line :347:1
													if A_arbace_repr_go_print_emit_A_const_55 != nil {







														lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29)
														var tmp21 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp21.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_108.GetRawRoot__O()).Invoke_O__O(t__0) }
//line :347:1
														return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } } } } }
//line :344:1
func A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_New_O(p0 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Ctor_O(c__indent any) { t.F_indent = c__indent }
//line :344:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A) Invoke_O_O__O(self, n__1 any) any { var n__1927000701__auto____2 int64 = lang.RT_LongCast_O__J_NoInit(lang.Numbers_Max_J_O__O_NoInit(1, n__1)); var ___3 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(___3, n__1927000701__auto____2) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(t.F_indent); ___3 = lang.Numbers_Unchecked_inc_J__J_NoInit(___3); continue L1 }; break L1 }; var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_22; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Reset_O__O(lang.Numbers_Max_O_O__O_NoInit(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).Deref__O(), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())))); return jrt.Boolean_TRUE.Ref() }
func A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A{}; t.Ctor_O_O(p0, p1); return t }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Ctor_O_O(c__first_QMARK_, c__sep any) { t.F_first_QMARK_ = c__first_QMARK_; t.F_sep = c__sep }
//line :345:1
func (t *A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A) Invoke_O__O(self any) any { if jrt.J2g_Truth(t.F_first_QMARK_) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O()).Invoke__O() } else { if jrt.J2g_Truth(t.F_sep) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_81.GetRawRoot__O()).Invoke_O__O(t.F_sep) }; lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_104.GetRawRoot__O()).Invoke__O() }; return jrt.Boolean_FALSE.Ref() }













func A_arbace_repr_go_print_emit_close_break_BANG__A_New() *A_arbace_repr_go_print_emit_close_break_BANG__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_close_break_BANG__A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Ctor() {}
//line :359:1
func (t *A_arbace_repr_go_print_emit_close_break_BANG__A) Invoke_O_O_O_O_O__O(self, end__0, multiline_QMARK___1, always_QMARK___2, indent__3 any) any {





	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; var and__1927000168__auto____5 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())

		if jrt.J2g_Truth(and__1927000168__auto____5) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(end__0) } else { tmp2 = and__1927000168__auto____5 }
//line :365:1
		if jrt.J2g_Truth(tmp2) {


			var tmp4 bool; var na_46 int64 = lang.RT_LongCast_O__J_NoInit(end__0); var tmp5 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_47 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))
			if jrt.Long_InstanceOf(na_47) { var n0_48 int64 = na_46; var n1_49 int64 = jrt.NN(jrt.Long_Cast(na_47)).LongValue__J(); tmp4 = n0_48 > n1_49 } else { tmp4 = lang.Numbers_Gt_J_O__Z_NoInit(na_46, na_47) }
//line :368:1
			if tmp4 { L1: for {
				var tmp6 bool; var tmp7 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; var na_51 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())); var na_52 int64 = lang.RT_LongCast_O__J_NoInit(end__0); if jrt.Long_InstanceOf(na_51) { var n0_53 int64 = jrt.NN(jrt.Long_Cast(na_51)).LongValue__J(); var n1_54 int64 = na_52; tmp6 = n0_53 < n1_54 } else { tmp6 = lang.Numbers_Lt_O_J__Z_NoInit(na_51, na_52) }; if tmp6 { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3); continue L1 }
//line :368:1
				break L1 }; return jrt.Boolean_TRUE.Ref() } else { var tmp8 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_13; if lang.Util_Equiv_J_O__Z_NoInit(lang.RT_LongCast_O__J_NoInit(end__0), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil {


					var tmp9 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_25; if jrt.J2g_Truth(tmp9.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_102.GetRawRoot__O()).Invoke_O__O(end__0) }
//line :368:1
					return jrt.Boolean_FALSE.Ref() } else { return nil } } } } else {
//line :365:1
						var tmp10 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_24; if jrt.J2g_Truth(tmp10.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {






							var tmp11 any; var and__1927000168__auto____5_2 any; var or__1927000174__auto____5 any = multiline_QMARK___1; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5_2 = or__1927000174__auto____5 } else { and__1927000168__auto____5_2 = always_QMARK___2 }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { tmp11 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_29) } else { tmp11 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp11) { lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3); return jrt.Boolean_TRUE.Ref() } else { return jrt.Boolean_FALSE.Ref() } } else {
//line :365:1
								if jrt.J2g_Truth(always_QMARK___2) {







									lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(indent__3)
//line :365:1
									return jrt.Boolean_TRUE.Ref() } else { if A_arbace_repr_go_print_emit_A_const_55 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
									}
									}
							}
					}
	}
}






func A_arbace_repr_go_print_emit_result_A_New() *A_arbace_repr_go_print_emit_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_result_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Ctor() {}
//line :378:1
func (t *A_arbace_repr_go_print_emit_result_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_109.GetRawRoot__O()).Invoke__O() } else {
//line :381:1
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_10; var s__1 any = jrt.NN(jrt.StringBuilder_Cast(tmp2.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()))).ToString__String().Ref(); var s__2 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_110.GetRawRoot__O()).Invoke_O_O_O__O(s__1, A_arbace_repr_go_print_emit_A_const_112, Lit_3); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_111.GetRawRoot__O()); var tmp4 any



			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_113.GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_3)) { tmp4 = s__2 } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() }; return tmp3.Invoke_O__O(tmp4)
		}
}












func A_arbace_repr_go_print_emit_utf8_len_A_New() *A_arbace_repr_go_print_emit_utf8_len_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_utf8_len_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Ctor() {}
//line :400:1
func (t *A_arbace_repr_go_print_emit_utf8_len_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)))).Ref() }


func A_arbace_repr_go_print_emit_end_of_A_New() *A_arbace_repr_go_print_emit_end_of_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Ctor() {}
//line :403:1
func (t *A_arbace_repr_go_print_emit_end_of_A) Invoke_O_O_O__O(self, p__308000116__0, s__1 any) any { var vec__308000117__3 any = p__308000116__0; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000117__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000117__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(s__1)).LastIndexOf_String__I(Lit_3); if



	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__6)) { return lang.Tuple_Create_O_O__IPersistentVector(l__4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(c__5), lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(s__1)))).Ref()) } else { var tmp1 int64 = lang.RT_LongCast_O__J_NoInit(l__4); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New(); var tmp4 *jrt.Class
		var fncls__56 /*line :407:1*/*jrt.Class = A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class

		if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }
//line :407:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp1, int64(lang.RT_Count_O__I_NoInit(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), s__1))))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_115.GetRawRoot__O()).Invoke_O_O__O(s__1, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__6))).Ref()))))).Ref()) } }

func A_arbace_repr_go_print_emit_end_of_fn__308000120_A_New() *A_arbace_repr_go_print_emit_end_of_fn__308000120_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_end_of_fn__308000120_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Ctor() {}
//line :409:1
func (t *A_arbace_repr_go_print_emit_end_of_fn__308000120_A) Invoke_O_O__O(self, p1__308000115_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__308000115_SHARP___1, A_arbace_repr_go_print_emit_A_const_84)).Ref() }



func A_arbace_repr_go_print_emit_line_comment_QMARK__A_New() *A_arbace_repr_go_print_emit_line_comment_QMARK__A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_line_comment_QMARK__A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Ctor() {}
//line :413:1
func (t *A_arbace_repr_go_print_emit_line_comment_QMARK__A) Invoke_O_O__O(self, it__0 any) any { var and__1927000168__auto____2 any = A_arbace_repr_go_print_emit_A_const_116.Invoke_O__O(it__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_91.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__0), Lit_23) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_emit_place_run_A_New() *A_arbace_repr_go_print_emit_place_run_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Ctor() {}
//line :415:1
func (t *A_arbace_repr_go_print_emit_place_run_A) Invoke_O_O_O_O_O__O(self, run__0, cur__1, prev_item__2, nxt__3 any) any { { var vec__308000127__5 any = cur__1; var cl__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000127__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000127__5, lang.RT_IntCast_J__I_NoInit(1), nil); var n__8 int32 = lang.RT_Count_O__I_NoInit(run__0); var lens__9 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New(); var tmp3 *jrt.Class
																var fncls__77 /*line :415:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class





	if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; lens__9 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), run__0)
//line :415:1
	var natural__10 any; var tmp4 any = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(cl__6, n__8, run__0, lens__9, cc__7); var tmp5 *jrt.Class
	var fncls__57 /*line :415:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class






	if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class = fncls__57d; tmp5 = fncls__57d } else { tmp5 = fncls__57 }; natural__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)





	var tmp6 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O()).Invoke_O__O(prev_item__2)

	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp6 = nxt__3 } else { tmp6 = and__1927000168__auto____11 }
//line :428:1
	if jrt.J2g_Truth(tmp6) { var vec__308000134__11 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3); var nl__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000134__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ncol__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000134__11, lang.RT_IntCast_J__I_NoInit(1), nil); var i__14 int64 = lang.Numbers_Dec_J__J_NoInit(int64(n__8)); var c__15 int64; var tmp7 int64 = lang.RT_LongCast_O__J_NoInit(ncol__13); var tmp8 int64



		if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3)) { tmp8 = 1 } else { tmp8 = 0 }; c__15 = lang.Numbers_Minus_J_J__J_NoInit(tmp7, tmp8)
//line :428:1
		var acc__16 any = lang.PersistentList_EMPTY.Ref(); L1: for {




			if lang.Numbers_IsNeg_J__Z_NoInit(i__14) {
				return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()).Invoke_O__O(acc__16) } else {
//line :433:1
					var c__17 int64 = lang.Numbers_Minus_J_J__J_NoInit(c__15, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lens__9, lang.RT_IntCast_J__I_NoInit(i__14)))); var tmp9 int64 = lang.Numbers_Dec_J__J_NoInit(i__14); var tmp10 int64
					var tmp11 /*line :433:1*/*lang.Keyword = A_arbace_repr_go_print_emit_A_const_74


					if jrt.J2g_Truth(tmp11.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(run__0, lang.RT_IntCast_J__I_NoInit(i__14)))) { tmp10 = 1 } else { tmp10 = 0 }; i__14, c__15, acc__16 = tmp9, lang.Numbers_Minus_J_J__J_NoInit(c__17, tmp10), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_127.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(nl__12, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(1, c__17)).Ref()), acc__16); continue L1 } } } else {
//line :428:1
						var tmp12 any; var or__1927000174__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(nxt__3, nil)








						if or__1927000174__auto____11 { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var or__1927000174__auto____12 bool = lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3))), lang.RT_LongCast_O__J_NoInit(cl__6)); if or__1927000174__auto____12 { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { tmp12 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_118.GetRawRoot__O()).Invoke_O__O(prev_item__2) } }
//line :428:1
						if jrt.J2g_Truth(tmp12) {









							return lang.IFn_Cast(natural__10).Invoke__O() } else {
//line :428:1
								if A_arbace_repr_go_print_emit_A_const_55 != nil { var ncol__11 int64 = lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(nxt__3))); var need__12 any; var na_58 int64 = lang.Numbers_Minus_J_J__J_NoInit(ncol__11, lang.RT_LongCast_O__J_NoInit(cc__7)); var na_59 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), lens__9)












									if jrt.Long_InstanceOf(na_59) { var n0_60 int64 = na_58; var n1_61 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); var nr_62 int64 = n0_60 - n1_61; var tmp13 bool; var tmp14 bool; tmp14 = !(n1_61 == -9223372036854775808); if tmp14 { tmp14 = (n0_60^n1_61)&(n0_60^nr_62) >= 0 }; tmp13 = tmp14; if tmp13 { need__12 = jrt.Long_ValueOf_J__Long_NoInit(nr_62).Ref() } else { need__12 = lang.Numbers_Minus_J_O__Number_NoInit(na_58, na_59) } } else { need__12 = lang.Numbers_Minus_J_O__Number_NoInit(na_58, na_59) }
//line :428:1
									var slots__13 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_74, run__0), A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(nxt__3)); var nat__14 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_123.GetRawRoot__O()); var tmp16 any = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New(); var tmp17 *jrt.Class
									var fncls__78 /*line :428:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class














									if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class = fncls__78d; tmp17 = fncls__78d } else { tmp17 = fncls__78 }; nat__14 = tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), slots__13)
//line :428:1
									var nnat__15 int32 = lang.RT_Count_O__I_NoInit(nat__14); var spaces__16 any; var tmp18 bool
									var na_63 any = need__12
















									if jrt.Long_InstanceOf(na_63) { var n0_64 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); tmp18 = n0_64 < 0 } else { if jrt.Double_InstanceOf(na_63) { var n0_64_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); tmp18 = n0_64_2 < 0.0 } else { tmp18 = lang.Numbers_IsNeg_O__Z_NoInit(na_63) } }
//line :445:1
									if tmp18 {
										var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New(); var tmp21 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class = fncls__79d; tmp21 = fncls__79d } else { tmp21 = fncls__79 }; spaces__16 = tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), slots__13) } else {
//line :445:1
											var tmp22 bool; var na_65 any = need__12; var na_66 int64 = int64(nnat__15)

											if jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; tmp22 = n0_67 >= n1_68 } else { tmp22 = lang.Numbers_Gte_O_J__Z_NoInit(na_65, na_66) }
//line :445:1
											if tmp22 { var extra__16 any; var na_70 any = need__12; var na_71 int64 = int64(nnat__15)


												if jrt.Long_InstanceOf(na_70) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); var n1_73 int64 = na_71; var nr_74 int64 = n0_72 - n1_73; var tmp23 bool; var tmp24 bool; tmp24 = !(n1_73 == -9223372036854775808); if tmp24 { tmp24 = (n0_72^n1_73)&(n0_72^nr_74) >= 0 }; tmp23 = tmp24; if tmp23 { extra__16 = jrt.Long_ValueOf_J__Long_NoInit(nr_74).Ref() } else { extra__16 = lang.Numbers_Minus_O_J__Number_NoInit(na_70, na_71) } } else { extra__16 = lang.Numbers_Minus_O_J__Number_NoInit(na_70, na_71) }
//line :445:1
												var base__17 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_117.GetRawRoot__O()); var tmp26 any = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New(); var tmp27 *jrt.Class
												var fncls__80 /*line :445:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class



												if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class = fncls__80d; tmp27 = fncls__80d } else { tmp27 = fncls__80 }; base__17 = tmp25.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), slots__13)
												var tmp28 bool; var na_75 any = extra__16
												if jrt.Long_InstanceOf(na_75) { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); tmp28 = n0_76 == 0 } else { if jrt.Double_InstanceOf(na_75) { var n0_76_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); tmp28 = n0_76_2 == 0.0 } else { tmp28 = lang.Numbers_IsZero_O__Z_NoInit(na_75) } }
//line :450:1
												if tmp28 { spaces__16 = base__17 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(nat__14)) {

													spaces__16 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(base__17, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(nat__14), A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), extra__16) } else {
//line :450:1
														var tmp29 any; var and__1927000168__auto____18 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(n__8), 1)


														if and__1927000168__auto____18 { var and__1927000168__auto____19 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_125.GetRawRoot__O()).Invoke_O__O(extra__16); if jrt.J2g_Truth(and__1927000168__auto____19) { var tmp30 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_72; tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_37, tmp30.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(run__0)))).Ref() } else { tmp29 = and__1927000168__auto____19 } } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____18).Ref() }
//line :450:1
														if jrt.J2g_Truth(tmp29) {



															var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_12.GetRawRoot__O()); var tmp33 any = A_arbace_repr_go_print_emit_A_const_30; var tmp34 jrt.Number_I; var na_86 any = extra__16; var na_87 int64 = 2; if jrt.Long_InstanceOf(na_86) { var n0_88 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); var n1_89 int64 = na_87; if n1_89 == 0 { tmp34 = lang.Numbers_Quotient_O_J__Number_NoInit(na_86, na_87) } else { tmp34 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_88 / n1_89)) } } else { tmp34 = lang.Numbers_Quotient_O_J__Number_NoInit(na_86, na_87) }; var tmp35 any = tmp32.Invoke_O_O_O__O(base__17, tmp33, tmp34); var tmp36 any = A_arbace_repr_go_print_emit_A_const_29; var tmp37 jrt.Number_I; var na_81 any = extra__16; var na_82 int64 = 2; if jrt.Long_InstanceOf(na_81) { var n0_83 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); var n1_84 int64 = na_82; if n1_84 == 0 { tmp37 = lang.Numbers_Quotient_O_J__Number_NoInit(na_81, na_82) } else { tmp37 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_83 / n1_84)) } } else { tmp37 = lang.Numbers_Quotient_O_J__Number_NoInit(na_81, na_82) }; spaces__16 = tmp31.Invoke_O_O_O__O(tmp35, tmp36, tmp37) } else {
//line :450:1
																if A_arbace_repr_go_print_emit_A_const_55 != nil {




																	spaces__16 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(base__17, jrt.Integer_ValueOf_I__Integer_NoInit(n__8).Ref(), A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(), extra__16) } else {
//line :450:1
																		spaces__16 = nil } } } } } else {
//line :445:1
																			if A_arbace_repr_go_print_emit_A_const_55 != nil { var keep__16 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_126.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_129.GetRawRoot__O()).Invoke_O_O__O(need__12, nat__14)); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_130.GetRawRoot__O()); var tmp40 any = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(keep__16); var tmp41 *jrt.Class
																				var fncls__91 /*line :445:1*/*jrt.Class = A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class












																				if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class = fncls__91d; tmp41 = fncls__91d } else { tmp41 = fncls__91 }; spaces__16 = tmp38.Invoke_O__O(tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), slots__13)) } else {
//line :445:1
																					spaces__16 = nil } } }
//line :428:1
									var i__17 int64 = 0; var c__18 int64 = lang.RT_LongCast_O__J_NoInit(cc__7); var acc__19 any = lang.PersistentVector_EMPTY.Ref(); L2: for {































										if lang.Numbers_Lt_J_J__Z_NoInit(i__17, int64(n__8)) { var c__20 int64 = lang.Numbers_Add_J_J__J_NoInit(c__18, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(spaces__16, lang.RT_IntCast_J__I_NoInit(i__17))))

											i__17, c__18, acc__19 = lang.Numbers_Inc_J__J_NoInit(i__17), lang.Numbers_Add_J_J__J_NoInit(c__20, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lens__9, lang.RT_IntCast_J__I_NoInit(i__17)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__19, lang.Tuple_Create_O_O__IPersistentVector(cl__6, jrt.Long_ValueOf_J__Long_NoInit(c__20).Ref())); continue L2 } else {
//line :460:1
												return acc__19 } } } else {
//line :428:1
													return nil } } } }; /*line :415:1*/panic("j2g: unreachable") }





func A_arbace_repr_go_print_emit_place_run_fn__308000130_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000130_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000130_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Ctor() {}
//line :421:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000130_A) Invoke_O_O__O(self, p1__308000124_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000124_SHARP___1)) }
func A_arbace_repr_go_print_emit_place_run_natural__308000132_A_New_O_I_O_O_O(p0 any, p1 int32, p2, p3, p4 any) *A_arbace_repr_go_print_emit_place_run_natural__308000132_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_natural__308000132_A{}; t.Ctor_O_I_O_O_O(p0, p1, p2, p3, p4); return t }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Ctor_O_I_O_O_O(c__cl any, c__n int32, c__run, c__lens, c__cc any) { t.F_cl = c__cl; t.F_n = c__n; t.F_run = c__run; t.F_lens = c__lens; t.F_cc = c__cc }
//line :422:1
func (t *A_arbace_repr_go_print_emit_place_run_natural__308000132_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var c__2 int64 = lang.RT_LongCast_O__J_NoInit(t.F_cc); var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var c__4 int64; var tmp1 int64; var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_74; var tmp3 any = t.F_run
		if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(i__1)))) { tmp1 = 1 } else { tmp1 = 0 }; c__4 = lang.Numbers_Add_J_J__J_NoInit(c__2, tmp1)
		var tmp4 any = t.F_lens; var tmp5 any = t.F_cl; i__1, c__2, acc__3 = lang.Numbers_Inc_J__J_NoInit(i__1), lang.Numbers_Add_J_J__J_NoInit(c__4, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1)))), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__3, lang.Tuple_Create_O_O__IPersistentVector(tmp5, jrt.Long_ValueOf_J__Long_NoInit(c__4).Ref())); continue L1 } else {
//line :424:1
			return acc__3 } } }; /*line :422:1*/panic("j2g: unreachable") }




















func A_arbace_repr_go_print_emit_place_run_fn__308000137_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000137_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000137_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Ctor() {}
//line :443:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000137_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if jrt.J2g_Truth(s__2) { return i__1 } else { return nil } }


func A_arbace_repr_go_print_emit_place_run_fn__308000139_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000139_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000139_A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Ctor() {}
//line :446:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000139_A) Invoke_O_O__O(self, p1__308000125_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000125_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }


func A_arbace_repr_go_print_emit_place_run_fn__308000141_A_New() *A_arbace_repr_go_print_emit_place_run_fn__308000141_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000141_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Ctor() {}
//line :449:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000141_A) Invoke_O_O__O(self, p1__308000126_SHARP___1 any) any { if jrt.J2g_Truth(p1__308000126_SHARP___1) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }








func A_arbace_repr_go_print_emit_place_run_fn__308000143_A_New_O(p0 any) *A_arbace_repr_go_print_emit_place_run_fn__308000143_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_place_run_fn__308000143_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Ctor_O(c__keep any) { t.F_keep = c__keep }
//line :458:1
func (t *A_arbace_repr_go_print_emit_place_run_fn__308000143_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_keep).Invoke_O__O(i__1)) { return A_arbace_repr_go_print_emit_A_const_29 } else { return A_arbace_repr_go_print_emit_A_const_30 } }






func A_arbace_repr_go_print_emit_full_result_A_New() *A_arbace_repr_go_print_emit_full_result_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Ctor() {}
//line :465:1
func (t *A_arbace_repr_go_print_emit_full_result_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_11; var fs__1 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_31.Get__O()); var items__2 any; if





	jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1)) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O()); var tmp3 any = lang.PersistentVector_EMPTY.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_140.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New(); var tmp6 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class = fncls__95d; tmp6 = fncls__95d } else { tmp6 = fncls__95 }; items__2 = tmp2.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)), A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__1)) } else {


			items__2 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_27.Invoke_O__O(fs__1)) }; var extras__3 any; var tmp7 lang.IFn = /*line :465:1*/lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_133.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New(); var tmp9 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class; if










	fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class = fncls__96d; tmp9 = fncls__96d } else { tmp9 = fncls__96 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_print_emit_A_const_143.Invoke_O__O(fs__1); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New(); var tmp15 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class; if
	fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class = fncls__97d; tmp15 = fncls__97d } else { tmp15 = fncls__97 }; var tmp16 any = /*line :476:1*/tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), A_arbace_repr_go_print_emit_A_const_131.Invoke_O__O(fs__1)); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New(); var tmp19 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class; if

	fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class = fncls__98d; tmp19 = fncls__98d } else { tmp19 = fncls__98 }; extras__3 = /*line :476:1*/tmp7.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp16, tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), A_arbace_repr_go_print_emit_A_const_145.Invoke_O__O(fs__1)))); var merged__4 any; var tmp20 any = /*line :465:1*/A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(extras__3, items__2); var tmp21 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class; if














	fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class = fncls__93d; tmp21 = fncls__93d } else { tmp21 = fncls__93 }; merged__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O(); var n__5 int32 = /*line :465:1*/lang.RT_Count_O__I_NoInit(merged__4); var space__6 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_132.GetRawRoot__O()); var tmp23 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New(); var tmp26 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class; if




























	fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class = fncls__99d; tmp26 = fncls__99d } else { tmp26 = fncls__99 }; space__6 = tmp22.Invoke_O_O_O__O(tmp23, tmp24.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil)), A_arbace_repr_go_print_emit_A_const_146.Invoke_O__O(fs__1)); var sb__7 any = /*line :465:1*/jrt.StringBuilder_New(); var cur__8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_147); var last_s__9 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_2); var prev_item__10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_14.GetRawRoot__O()).Invoke_O__O(nil); var write_at_BANG___11 any; var tmp27 any = A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(space__6, last_s__9, sb__7, prev_item__10, cur__8); var tmp28 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class; if


































	fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class = fncls__94d; tmp28 = fncls__94d } else { tmp28 = fncls__94 }; write_at_BANG___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var i__12 any = /*line :465:1*/lang.RT_Box_J__Number_NoInit(0); L1: for {






























































		var tmp29 bool; var na_100 any = i__12; var na_101 int64 = int64(n__5); if jrt.Long_InstanceOf(na_100) { var n0_102 int64 = jrt.NN(jrt.Long_Cast(na_100)).LongValue__J(); var n1_103 int64 = na_101; tmp29 = n0_102 < n1_103 } else { tmp29 = lang.Numbers_Lt_O_J__Z_NoInit(na_100, na_101) }; if tmp29 { var it__13 any = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(i__12))

			if jrt.J2g_Truth(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)) {
				lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(it__13, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__13)); var tmp30 jrt.Number_I; var na_150 any = i__12; if jrt.Long_InstanceOf(na_150) { var n0_151 int64 = jrt.NN(jrt.Long_Cast(na_150)).LongValue__J(); if n0_151 == 9223372036854775807 { tmp30 = lang.Numbers_Inc_O__Number_NoInit(na_150) } else { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_151 + 1)) } } else { if jrt.Double_InstanceOf(na_150) { var n0_151_2 float64 = jrt.NN(jrt.Double_Cast(na_150)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_151_2 + 1.0)) } else { tmp30 = lang.Numbers_Inc_O__Number_NoInit(na_150) } }; i__12 = tmp30; continue L1 } else {
//line :530:1
					var j__14 any; var tmp31 any = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(merged__4, n__5, i__12); var tmp32 *jrt.Class
					var fncls__112 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class



					if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class = fncls__112d; tmp32 = fncls__112d } else { tmp32 = fncls__112 }; j__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :530:1
					var t__15 any; var tmp33 any = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(merged__4, n__5, j__14); var tmp34 *jrt.Class
					var fncls__120 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class




					if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class = fncls__120d; tmp34 = fncls__120d } else { tmp34 = fncls__120 }; t__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O()
//line :530:1
					var tok_STAR___16 any; var tmp35 bool; var na_121 any = t__15; var na_122 int64 = int64(n__5)





					if jrt.Long_InstanceOf(na_121) { var n0_123 int64 = jrt.NN(jrt.Long_Cast(na_121)).LongValue__J(); var n1_124 int64 = na_122; tmp35 = n0_123 < n1_124 } else { tmp35 = lang.Numbers_Lt_O_J__Z_NoInit(na_121, na_122) }; if tmp35 { tok_STAR___16 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(t__15)) } else { tok_STAR___16 = nil }
//line :530:1
					var vec__308000224__17 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(cur__8); var cl__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000224__17, lang.RT_IntCast_J__I_NoInit(0), nil); var ___19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000224__17, lang.RT_IntCast_J__I_NoInit(1), nil); var same_line_QMARK___20 any; var and__1927000168__auto____20 any = tok_STAR___16; _ = ___19







					if jrt.J2g_Truth(and__1927000168__auto____20) { same_line_QMARK___20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(tok_STAR___16))), lang.RT_LongCast_O__J_NoInit(cl__18))).Ref() } else { same_line_QMARK___20 = and__1927000168__auto____20 }
//line :530:1
					var run__21 any; var tmp36 any = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(last_s__9, merged__4, tok_STAR___16, j__14, i__12, same_line_QMARK___20); var tmp37 *jrt.Class
					var fncls__138 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class








					if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class = fncls__138d; tmp37 = fncls__138d } else { tmp37 = fncls__138 }; run__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil).Invoke__O()
//line :530:1
					var obstacles__22 any; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_119.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_33.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_151.GetRawRoot__O()); var tmp41 any = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(cl__18); var tmp42 *jrt.Class
					var fncls__152 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class






















					if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class = fncls__152d; tmp42 = fncls__152d } else { tmp42 = fncls__152 }; var tmp43 any = tmp40.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(merged__4, j__14, t__15)); var tmp44 lang.IPersistentVector
					if jrt.J2g_Truth(same_line_QMARK___20) { tmp44 = lang.Tuple_Create_O__IPersistentVector(tok_STAR___16) } else { tmp44 = nil }
//line :553:1
					obstacles__22 = tmp38.Invoke_O__O(tmp39.Invoke_O_O__O(tmp43, tmp44))
//line :530:1
					var width__23 any; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()); var tmp46 any = A_arbace_repr_go_print_emit_A_const_128.GetRawRoot__O(); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()); var tmp48 any = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New(); var tmp49 *jrt.Class
					var fncls__153 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class
























					if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class = fncls__153d; tmp49 = fncls__153d } else { tmp49 = fncls__153 }; width__23 = tmp45.Invoke_O_O__O(tmp46, tmp47.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil), run__21))
//line :530:1
					var k__24 any; var tmp50 any = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(obstacles__22, width__23, cur__8); var tmp51 *jrt.Class
					var fncls__149 /*line :530:1*/*jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class

























					if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class = fncls__149d; tmp51 = fncls__149d } else { tmp51 = fncls__149 }; k__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil).Invoke__O()
//line :530:1
					var k__25 any

































					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(run__21)) { k__25 = lang.Numbers_Min_O_J__O_NoInit(k__24, int64(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(merged__4, j__14, t__15)))) } else { k__25 = A_arbace_repr_go_print_emit_A_const_30 }
//line :530:1
					var n__1927000701__auto____26 int64 = lang.RT_LongCast_O__J_NoInit(k__25); var q__27 int64 = 0; L2: for {


































						if lang.Numbers_Lt_J_J__Z_NoInit(q__27, n__1927000701__auto____26) { var o__28 any; var tmp52 jrt.Number_I; var na_169 any = j__14; var na_170 int64 = q__27; if jrt.Long_InstanceOf(na_169) { var n0_171 int64 = jrt.NN(jrt.Long_Cast(na_169)).LongValue__J(); var n1_172 int64 = na_170; var nr_173 int64 = n0_171 + n1_172; if (n0_171^nr_173)&(n1_172^nr_173) >= 0 { tmp52 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_173)) } else { tmp52 = lang.Numbers_Add_O_J__Number_NoInit(na_169, na_170) } } else { tmp52 = lang.Numbers_Add_O_J__Number_NoInit(na_169, na_170) }; o__28 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(tmp52)); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(o__28, A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__28)); q__27 = lang.Numbers_Unchecked_inc_J__J_NoInit(q__27); continue L2 }
//line :530:1
						break L2 }; var nxt__26 any; var tmp53 bool; var na_154 any; var na_156 any = j__14; var na_157 any = k__25; var tmp54 bool; var tmp55 bool



































					tmp55 = jrt.Long_InstanceOf(na_156); if tmp55 { tmp55 = jrt.Long_InstanceOf(na_157) }; tmp54 = tmp55; if tmp54 { var n0_158 int64 = jrt.NN(jrt.Long_Cast(na_156)).LongValue__J(); var n1_159 int64 = jrt.NN(jrt.Long_Cast(na_157)).LongValue__J(); var nr_160 int64 = n0_158 + n1_159; if (n0_158^nr_160)&(n1_159^nr_160) >= 0 { na_154 = jrt.Long_ValueOf_J__Long_NoInit(nr_160).Ref() } else { na_154 = lang.Numbers_Add_O_O__Number_NoInit(na_156, na_157) } } else { var tmp56 bool; var tmp57 bool; tmp57 = jrt.Double_InstanceOf(na_156); if tmp57 { tmp57 = jrt.Double_InstanceOf(na_157) }; tmp56 = tmp57; if tmp56 { var n0_158_2 float64 = jrt.NN(jrt.Double_Cast(na_156)).DoubleValue__D(); var n1_159_2 float64 = jrt.NN(jrt.Double_Cast(na_157)).DoubleValue__D(); na_154 = jrt.Double_ValueOf_D__Double_NoInit(n0_158_2 + n1_159_2).Ref() } else { na_154 = lang.Numbers_Add_O_O__Number_NoInit(na_156, na_157) } }; var na_155 int64 = int64(n__5); if jrt.Long_InstanceOf(na_154) { var n0_161 int64 = jrt.NN(jrt.Long_Cast(na_154)).LongValue__J(); var n1_162 int64 = na_155; tmp53 = n0_161 < n1_162 } else { tmp53 = lang.Numbers_Lt_O_J__Z_NoInit(na_154, na_155) }; if tmp53 { var tmp58 jrt.Number_I; var na_164 any = j__14; var na_165 any = k__25; var tmp59 bool; var tmp60 bool; tmp60 = jrt.Long_InstanceOf(na_164); if tmp60 { tmp60 = jrt.Long_InstanceOf(na_165) }; tmp59 = tmp60; if tmp59 { var n0_166 int64 = jrt.NN(jrt.Long_Cast(na_164)).LongValue__J(); var n1_167 int64 = jrt.NN(jrt.Long_Cast(na_165)).LongValue__J(); var nr_168 int64 = n0_166 + n1_167; if (n0_166^nr_168)&(n1_167^nr_168) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_168)) } else { tmp58 = lang.Numbers_Add_O_O__Number_NoInit(na_164, na_165) } } else { var tmp61 bool; var tmp62 bool; tmp62 = jrt.Double_InstanceOf(na_164); if tmp62 { tmp62 = jrt.Double_InstanceOf(na_165) }; tmp61 = tmp62; if tmp61 { var n0_166_2 float64 = jrt.NN(jrt.Double_Cast(na_164)).DoubleValue__D(); var n1_167_2 float64 = jrt.NN(jrt.Double_Cast(na_165)).DoubleValue__D(); tmp58 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_166_2 + n1_167_2)) } else { tmp58 = lang.Numbers_Add_O_O__Number_NoInit(na_164, na_165) } }; nxt__26 = lang.RT_Nth_O_I__O_NoInit(merged__4, lang.RT_IntCast_O__I_NoInit(tmp58)) } else { nxt__26 = nil }
//line :530:1
					var ps__27 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_152.GetRawRoot__O()).Invoke_O_O_O_O__O(run__21, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(cur__8), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(prev_item__10), nxt__26); var seq_308000240__28 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_emit_A_const_45.GetRawRoot__O(), run__21, ps__27)); var chunk_308000241__29 any; var count_308000242__30 int64 = 0; var i_308000243__31 int64 = 0; L3: for {





































						if lang.Numbers_Lt_J_J__Z_NoInit(i_308000243__31, count_308000242__30) { var vec__308000244__32 any = lang.Indexed_Cast(chunk_308000241__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_308000243__31)); var x__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000244__32, lang.RT_IntCast_J__I_NoInit(0), nil); var p__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000244__32, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__33, p__34); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = seq_308000240__28, chunk_308000241__29, count_308000242__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_308000243__31); continue L3 } else { var temp__1927000414__auto____32 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_308000240__28); if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_308000240__33 any = temp__1927000414__auto____32; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_153.GetRawRoot__O()).Invoke_O__O(seq_308000240__33)) { var c__1927000678__auto____34 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_308000240__33); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_308000240__33), c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__308000247__34 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(seq_308000240__33); var x__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000247__34, lang.RT_IntCast_J__I_NoInit(0), nil); var p__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000247__34, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(write_at_BANG___11).Invoke_O_O__O(x__35, p__36); seq_308000240__28, chunk_308000241__29, count_308000242__30, i_308000243__31 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_136.GetRawRoot__O()).Invoke_O__O(seq_308000240__33), nil, 0, 0; continue L3 } } }
//line :530:1
						break L3
					}





































					var tmp63 jrt.Number_I; var na_174 any = j__14; var na_175 any = k__25; var tmp64 bool; var tmp65 bool; tmp65 = jrt.Long_InstanceOf(na_174); if tmp65 { tmp65 = jrt.Long_InstanceOf(na_175) }; tmp64 = tmp65; if tmp64 { var n0_176 int64 = jrt.NN(jrt.Long_Cast(na_174)).LongValue__J(); var n1_177 int64 = jrt.NN(jrt.Long_Cast(na_175)).LongValue__J(); var nr_178 int64 = n0_176 + n1_177; if (n0_176^nr_178)&(n1_177^nr_178) >= 0 { tmp63 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_178)) } else { tmp63 = lang.Numbers_Add_O_O__Number_NoInit(na_174, na_175) } } else { var tmp66 bool; var tmp67 bool; tmp67 = jrt.Double_InstanceOf(na_174); if tmp67 { tmp67 = jrt.Double_InstanceOf(na_175) }; tmp66 = tmp67; if tmp66 { var n0_176_2 float64 = jrt.NN(jrt.Double_Cast(na_174)).DoubleValue__D(); var n1_177_2 float64 = jrt.NN(jrt.Double_Cast(na_175)).DoubleValue__D(); tmp63 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_176_2 + n1_177_2)) } else { tmp63 = lang.Numbers_Add_O_O__Number_NoInit(na_174, na_175) } }; i__12 = tmp63; continue L1 } }
//line :465:1
		break L1 }; var tmp68 /*line :570:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__7); var tmp69 any; var or__1927000174__auto____12 any = A_arbace_repr_go_print_emit_A_const_150.Invoke_O__O(fs__1); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp69 = or__1927000174__auto____12 } else { tmp69 = Lit_3 }; jrt.NN(tmp68).Append_O__StringBuilder(tmp69); return /*line :571:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__7)).ToString__String().Ref() }
//line :472:1
func A_arbace_repr_go_print_emit_full_result_fn__308000149_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000149_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000149_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Ctor() {}
//line :472:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000149_A) Invoke_O_O__O(self, p1__308000146_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_141); var and__1927000168__auto____2 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000146_SHARP___1), nil); if and__1927000168__auto____3 { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_18, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000146_SHARP___1))
															if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var tmp2 any = A_arbace_repr_go_print_emit_A_const_142; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(p1__308000146_SHARP___1)); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { return A_arbace_repr_go_print_emit_A_const_142.Invoke_O__O(p1__308000146_SHARP___1) } } } else {
//line :472:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_emit_full_result_fn__308000152_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000152_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000152_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Ctor() {}
//line :476:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000152_A) Invoke_O_O__O(self, p__308000151__1 any) any { var vec__308000153__2 any = p__308000151__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000153__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000153__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }
func A_arbace_repr_go_print_emit_full_result_fn__308000158_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000158_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000158_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Ctor() {}
//line :477:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000158_A) Invoke_O_O__O(self, p__308000157__1 any) any { var vec__308000159__2 any = p__308000157__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000159__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000159__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_18, A_arbace_repr_go_print_emit_A_const_19) }
func A_arbace_repr_go_print_emit_full_result_fn__308000164_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000164_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000164_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Ctor() {}
//line :478:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000164_A) Invoke_O_O__O(self, p__308000163__1 any) any { var vec__308000165__2 any = p__308000163__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(l__3, c__4, Lit_19, A_arbace_repr_go_print_emit_A_const_19) }

func A_arbace_repr_go_print_emit_full_result_fn__308000169_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_emit_full_result_fn__308000169_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_A{}; t.Ctor_O_O(p0, p1); return t }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Ctor_O_O(c__extras, c__items any) { t.F_extras = c__extras; t.F_items = c__items }
//line :480:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var cs__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_extras; t.F_extras = nil; tmp2 = t_; cs__2 = tmp1.Invoke_O__O(tmp2); var acc__3 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_134.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); L1: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_items))) { var tmp3 any = t.F_items; var it__4 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(i__1)); var pos__5 any = A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(it__4); var tmp4 any
													var and__1927000168__auto____6 any = pos__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_32.GetRawRoot__O()).Invoke_O__O(cs__2); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 lang.IPersistentVector; var vec__308000170__8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(cs__2); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000170__8, lang.RT_IntCast_J__I_NoInit(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000170__8, lang.RT_IntCast_J__I_NoInit(1), nil); tmp5 = lang.Tuple_Create_O_O__IPersistentVector(l__9, c__10); tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp5, pos__5)))).Ref() } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var vec__308000173__6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(cs__2); var l__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(1), nil); var t__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(2), nil); var semi__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000173__6, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_136.GetRawRoot__O()).Invoke_O__O(cs__2); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()); var tmp8 lang.IPersistentMap

			if jrt.J2g_Truth(semi__10) { var tmp9 any = A_arbace_repr_go_print_emit_A_const_72; var tmp10 any = A_arbace_repr_go_print_emit_A_const_73; tmp8 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, t__9, tmp10, lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8))) } else { var tmp11 any = A_arbace_repr_go_print_emit_A_const_72; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(t__9); var tmp13 any = A_arbace_repr_go_print_emit_A_const_73; tmp8 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, lang.Tuple_Create_O_O__IPersistentVector(l__7, c__8), A_arbace_repr_go_print_emit_A_const_116, jrt.Boolean_TRUE.Ref())) }; i__1, cs__2, acc__3 = i__1, tmp6, tmp7.Invoke_O_O__O(acc__3, tmp8); continue L1 } else {

				i__1, cs__2, acc__3 = lang.Numbers_Inc_J__J_NoInit(i__1), cs__2, lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()).Invoke_O_O__O(acc__3, it__4); continue L1 } } else {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_135.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_122.GetRawRoot__O()); var tmp16 any = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New(); var tmp17 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class = fncls__92d; tmp17 = fncls__92d } else { tmp17 = fncls__92 }; return tmp14.Invoke_O__O(tmp15.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), acc__3, cs__2)) } } }; /*line :480:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Ctor() {}
//line :489:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A) Invoke_O_O_O__O(self, a__1, p__308000176__2 any) any { var vec__308000178__3 any = p__308000176__2; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(1), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(2), nil); var semi__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000178__3, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_137.GetRawRoot__O()); var tmp2 lang.IPersistentMap; if
																	jrt.J2g_Truth(semi__7) { var tmp3 any = A_arbace_repr_go_print_emit_A_const_72; var tmp4 any = A_arbace_repr_go_print_emit_A_const_73; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, t__6, tmp4, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5))) } else { var tmp5 any = A_arbace_repr_go_print_emit_A_const_72; var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(t__6); var tmp7 any = A_arbace_repr_go_print_emit_A_const_73; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5), A_arbace_repr_go_print_emit_A_const_116, jrt.Boolean_TRUE.Ref())) }; return tmp1.Invoke_O_O__O(a__1, tmp2) }



func A_arbace_repr_go_print_emit_full_result_fn__308000184_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000184_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000184_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Ctor() {}
//line :494:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000184_A) Invoke_O_O__O(self, p__308000183__1 any) any { var vec__308000185__2 any = p__308000183__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(1), nil); var w__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000185__2, lang.RT_IntCast_J__I_NoInit(2), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_138.GetRawRoot__O()).Invoke_O__O(w__5)) }





func A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Ctor_O_O_O_O_O(c__space, c__last_s, c__sb, c__prev_item, c__cur any) { t.F_space = c__space; t.F_last_s = c__last_s; t.F_sb = c__sb; t.F_prev_item = c__prev_item; t.F_cur = c__cur }
//line :500:1
func (t *A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A) Invoke_O_O_O__O(self, it__1, p__308000189__2 any) any { var vec__308000191__3 any = p__308000189__2; var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000191__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000191__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__308000194__6 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_cur); var cl__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000194__6, lang.RT_IntCast_J__I_NoInit(0), nil); var cc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__308000194__6, lang.RT_IntCast_J__I_NoInit(1), nil); var l__9 int64 = lang.RT_LongCast_O__J_NoInit(l__4); var c__10 int64 = lang.RT_LongCast_O__J_NoInit(c__5); var cl__11 int64 = lang.RT_LongCast_O__J_NoInit(cl__7); var cc__12 int64 = lang.RT_LongCast_O__J_NoInit(cc__8); if


	lang.Numbers_Gt_J_J__Z_NoInit(l__9, cl__11) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____13 any = tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(cl__11).Ref(), jrt.Long_ValueOf_J__Long_NoInit(cc__12).Ref()))

		if jrt.J2g_Truth(temp__1927000414__auto____13) { var w__14 any = temp__1927000414__auto____13; var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(w__14)) }
//line :503:1
		var k__13 int64 = cl__11; L1: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(k__13, l__9) {
				jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_84)
				if lang.Numbers_Lt_J_J__Z_NoInit(k__13, lang.Numbers_Dec_J__J_NoInit(l__9)) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000414__auto____14 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__13)).Ref(), A_arbace_repr_go_print_emit_A_const_29))
					if jrt.J2g_Truth(temp__1927000414__auto____14) { var w__15 any = temp__1927000414__auto____14; var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp4).Append_String__StringBuilder(jrt.String_Cast(w__15)) } }
				k__13 = lang.Numbers_Inc_J__J_NoInit(k__13); continue L1 }
//line :503:1
			break L1 }; var tmp5 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13 any = tmp5.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), A_arbace_repr_go_print_emit_A_const_29))








		if jrt.J2g_Truth(temp__1927000408__auto____13) { var w__14_2 any = temp__1927000408__auto____13; var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
			jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(w__14_2)) } else {
//line :512:1
				var n__1927000701__auto____14 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Dec_J__J_NoInit(c__10)); var ___15 int64 = 0; L2: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(___15, n__1927000701__auto____14) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_71); ___15 = lang.Numbers_Unchecked_inc_J__J_NoInit(___15); continue L2 }
//line :512:1
					break L2 } } } else {
//line :503:1
						var tmp7 bool; var and__1927000168__auto____13 bool = lang.Util_Equiv_J_J__Z_NoInit(l__9, cl__11)











						if and__1927000168__auto____13 { tmp7 = lang.Numbers_Gte_J_J__Z_NoInit(c__10, cc__12) } else { tmp7 = and__1927000168__auto____13 }
//line :503:1
						if tmp7 { var tmp8 lang.IFn = lang.IFn_Cast(t.F_space); var temp__1927000408__auto____13_2 any = tmp8.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), jrt.Long_ValueOf_J__Long_NoInit(cc__12).Ref()))












							if jrt.J2g_Truth(temp__1927000408__auto____13_2) { var w__14_3 any = temp__1927000408__auto____13_2; var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb)
								jrt.NN(tmp9).Append_String__StringBuilder(jrt.String_Cast(w__14_3)) } else {
//line :516:1
									var n__1927000701__auto____14_2 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(c__10, cc__12)); var ___15_2 int64 = 0; L3: for {

										if lang.Numbers_Lt_J_J__Z_NoInit(___15_2, n__1927000701__auto____14_2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79); ___15_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(___15_2); continue L3 }
//line :516:1
										break L3 } } } else {
//line :503:1
											if A_arbace_repr_go_print_emit_A_const_55 != nil {
















												var tmp10 any; var or__1927000174__auto____13 any = A_arbace_repr_go_print_emit_A_const_74.Invoke_O__O(it__1); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp10 = or__1927000174__auto____13 } else { tmp10 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_last_s), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)) }; if jrt.J2g_Truth(tmp10) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_repr_go_print_emit_A_const_79) } } } }; var tmp11 /*line :521:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))); var tmp12 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp13 any = t.F_cur; var tmp14 any; var tmp15 bool; var or__1927000174__auto____13_2 bool = lang.Numbers_Gt_J_J__Z_NoInit(l__9, cl__11); if or__1927000174__auto____13_2 { tmp15 = or__1927000174__auto____13_2 } else { var and__1927000168__auto____14 bool = lang.Util_Equiv_J_J__Z_NoInit(l__9, cl__11); if and__1927000168__auto____14 { tmp15 = lang.Numbers_Gte_J_J__Z_NoInit(c__10, cc__12) } else { tmp15 = and__1927000168__auto____14 } }; if tmp15 {
		tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(l__9).Ref(), jrt.Long_ValueOf_J__Long_NoInit(c__10).Ref()), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)) } else {
			tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_cur), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1))).Ref()) }; /*line :522:1*/tmp12.Invoke_O_O__O(tmp13, tmp14); var tmp16 lang.IFn =


	lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()); var tmp17 any = t.F_last_s; tmp16.Invoke_O_O__O(tmp17, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(it__1)); return /*line :526:1*/ lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_prev_item, it__1) }







func A_arbace_repr_go_print_emit_full_result_fn__308000227_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000227_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000227_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Ctor_O_I_O(c__merged any, c__n int32, c__i any) { t.F_merged = c__merged; t.F_n = c__n; t.F_i = c__i }
//line :534:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000227_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_105 any = j__1; var na_106 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_105) { var n0_107 int64 = jrt.NN(jrt.Long_Cast(na_105)).LongValue__J(); var n1_108 int64 = na_106; and__1927000168__auto____2 = n0_107 < n1_108 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_105, na_106) }; if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_73; var tmp3 any = t.F_merged; tmp1 = lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1))), nil) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_110 any = j__1; if jrt.Long_InstanceOf(na_110) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); if n0_111 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_110) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_111 + 1)) } } else { if jrt.Double_InstanceOf(na_110) { var n0_111_2 float64 = jrt.NN(jrt.Double_Cast(na_110)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_111_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_110) } }; j__1 = tmp4; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_print_emit_full_result_fn__308000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000229_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Ctor_O_I_O(c__merged any, c__n int32, c__j any) { t.F_merged = c__merged; t.F_n = c__n; t.F_j = c__j }
//line :535:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000229_A) Invoke_O__O(self any) any { { var t__1 any; var t_ any = t.F_j; t.F_j = nil; t__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool; var na_113 any = t__1; var na_114 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_113) { var n0_115 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); var n1_116 int64 = na_114; and__1927000168__auto____2 = n0_115 < n1_116 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_113, na_114) }; if and__1927000168__auto____2 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_emit_A_const_116; var tmp3 any = t.F_merged; tmp1 = tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(t__1))) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp4 jrt.Number_I; var na_118 any = t__1; if jrt.Long_InstanceOf(na_118) { var n0_119 int64 = jrt.NN(jrt.Long_Cast(na_118)).LongValue__J(); if n0_119 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_118) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_119 + 1)) } } else { if jrt.Double_InstanceOf(na_118) { var n0_119_2 float64 = jrt.NN(jrt.Double_Cast(na_118)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_119_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_118) } }; t__1 = tmp4; continue L1 } else { return t__1 } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_print_emit_full_result_fn__308000231_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_print_emit_full_result_fn__308000231_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000231_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Ctor_O_O_O_O_O_O(c__last_s, c__merged, c__tok_STAR_, c__j, c__i, c__same_line_QMARK_ any) { t.F_last_s = c__last_s; t.F_merged = c__merged; t.F_tok_STAR_ = c__tok_STAR_; t.F_j = c__j; t.F_i = c__i; t.F_same_line_QMARK_ = c__same_line_QMARK_ }
//line :539:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000231_A) Invoke_O__O(self any) any { { var k__1 any; var t_ any = t.F_i; t.F_i = nil; k__1 = t_; var ls__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()); var tmp2 any; var t__2 any = t.F_last_s; t.F_last_s = nil; tmp2 = t__2; ls__2 = tmp1.Invoke_O__O(tmp2); var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp3 bool; var na_126 any = k__1; var na_127 any = t.F_j; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_126); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_127) }; tmp4 = tmp5; if tmp4 { var n0_128 int64 = jrt.NN(jrt.Long_Cast(na_126)).LongValue__J(); var n1_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); tmp3 = n0_128 < n1_129 } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_126); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_127) }; tmp6 = tmp7; if tmp6 { var n0_128_2 float64 = jrt.NN(jrt.Double_Cast(na_126)).DoubleValue__D(); var n1_129_2 float64 = jrt.NN(jrt.Double_Cast(na_127)).DoubleValue__D(); tmp3 = n0_128_2 < n1_129_2 } else { tmp3 = lang.Numbers_Lt_O_O__Z_NoInit(na_126, na_127) } }; if tmp3 { var tmp8 any = t.F_merged; var x__4 any = lang.RT_Nth_O_I__O_NoInit(tmp8, lang.RT_IntCast_O__I_NoInit(k__1)); var temp__1927000408__auto____5 any = A_arbace_repr_go_print_emit_A_const_76.Invoke_O__O(x__4)

		if jrt.J2g_Truth(temp__1927000408__auto____5) { var kind__6 any = temp__1927000408__auto____5; var keep_QMARK___7 any; var G__308000232__7_ any = kind__6
		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__308000232__7_) >> 1 & 1 { case 0: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_142) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_same_line_QMARK_)

			if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = t.F_tok_STAR_; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_148.GetRawRoot__O()).Invoke_O_O__O(ls__2, Lit_19); if jrt.J2g_Truth(and__1927000168__auto____10) { keep_QMARK___7 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(ls__2) } else { keep_QMARK___7 = and__1927000168__auto____10 } } else { keep_QMARK___7 = and__1927000168__auto____9 } } else { keep_QMARK___7 = and__1927000168__auto____8 }
//line :543:1
			break L2 }; case 1: if any(G__308000232__7_) == any(A_arbace_repr_go_print_emit_A_const_107) { var and__1927000168__auto____8_2 any = t.F_same_line_QMARK_
				if jrt.J2g_Truth(and__1927000168__auto____8_2) { keep_QMARK___7 = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(ls__2) } else { keep_QMARK___7 = and__1927000168__auto____8_2 }
//line :543:1
				break L2 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__308000232__7_)))))
		}

			if jrt.J2g_Truth(keep_QMARK___7) {
				var tmp9 jrt.Number_I; var na_132 any = k__1; if jrt.Long_InstanceOf(na_132) { var n0_133 int64 = jrt.NN(jrt.Long_Cast(na_132)).LongValue__J(); if n0_133 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_132) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_133 + 1)) } } else { if jrt.Double_InstanceOf(na_132) { var n0_133_2 float64 = jrt.NN(jrt.Double_Cast(na_132)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_133_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_132) } }; var tmp10 any = A_arbace_repr_go_print_emit_A_const_72; k__1, ls__2, acc__3 = tmp9, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4), A_arbace_repr_go_print_emit_A_const_74, jrt.Boolean_FALSE.Ref()))); continue L1 } else {
					var tmp11 jrt.Number_I; var na_134 any = k__1; if jrt.Long_InstanceOf(na_134) { var n0_135 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); if n0_135 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_134) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_135 + 1)) } } else { if jrt.Double_InstanceOf(na_134) { var n0_135_2 float64 = jrt.NN(jrt.Double_Cast(na_134)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_135_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_134) } }; k__1, ls__2, acc__3 = tmp11, ls__2, acc__3; continue L1 } } else {
						var tmp12 jrt.Number_I; var na_136 any = k__1; if jrt.Long_InstanceOf(na_136) { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); if n0_137 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_136) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_137 + 1)) } } else { if jrt.Double_InstanceOf(na_136) { var n0_137_2 float64 = jrt.NN(jrt.Double_Cast(na_136)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_137_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_136) } }; k__1, ls__2, acc__3 = tmp12, A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(x__4), lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__3, x__4); continue L1 } } else {
//line :540:1
							return acc__3 } } }; /*line :539:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_emit_full_result_fn__308000234_A_New_O(p0 any) *A_arbace_repr_go_print_emit_full_result_fn__308000234_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000234_A{}; t.Ctor_O(p0); return t }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :553:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000234_A) Invoke_O_O__O(self, p1__308000147_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(p1__308000147_SHARP___1))), lang.RT_LongCast_O__J_NoInit(t.F_cl))).Ref() }

func A_arbace_repr_go_print_emit_full_result_fn__308000236_A_New() *A_arbace_repr_go_print_emit_full_result_fn__308000236_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000236_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Ctor() {}
//line :555:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000236_A) Invoke_O_O__O(self, p1__308000148_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(p1__308000148_SHARP___1)) }
func A_arbace_repr_go_print_emit_full_result_fn__308000238_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_emit_full_result_fn__308000238_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_full_result_fn__308000238_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Ctor_O_O_O(c__obstacles, c__width, c__cur any) { t.F_obstacles = c__obstacles; t.F_width = c__width; t.F_cur = c__cur }
//line :556:1
func (t *A_arbace_repr_go_print_emit_full_result_fn__308000238_A) Invoke_O__O(self any) any { { var k__1 int64 = 0; var c__2 int64; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_6.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cur; t.F_cur = nil; tmp3 = t_; c__2 = lang.RT_LongCast_O__J_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3))); L1: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(k__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_obstacles)))) { var tmp4 any = t.F_obstacles; var o__3 any = lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(k__1)); var oc__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3))); var tmp5 bool; var na_139 int64 = lang.Numbers_Minus_J_J__J_NoInit(oc__4, c__2); var na_140 any; var na_141 any = t.F_width
													var na_142 int64 = 1

		if jrt.Long_InstanceOf(na_141) { var n0_143 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var n1_144 int64 = na_142; var nr_145 int64 = n0_143 + n1_144; if (n0_143^nr_145)&(n1_144^nr_145) >= 0 { na_140 = jrt.Long_ValueOf_J__Long_NoInit(nr_145).Ref() } else { na_140 = lang.Numbers_Add_O_J__Number_NoInit(na_141, na_142) } } else { na_140 = lang.Numbers_Add_O_J__Number_NoInit(na_141, na_142) }; if jrt.Long_InstanceOf(na_140) { var n0_146 int64 = na_139; var n1_147 int64 = jrt.NN(jrt.Long_Cast(na_140)).LongValue__J(); tmp5 = n0_146 >= n1_147 } else { tmp5 = lang.Numbers_Gte_J_O__Z_NoInit(na_139, na_140) }; if tmp5 { return jrt.Long_ValueOf_J__Long_NoInit(k__1).Ref() } else {

			k__1, c__2 = lang.Numbers_Inc_J__J_NoInit(k__1), lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_121.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_emit_A_const_139.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_emit_A_const_73.Invoke_O__O(o__3), A_arbace_repr_go_print_emit_A_const_72.Invoke_O__O(o__3)))); continue L1 } } else {
				return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(0, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_obstacles))))).Ref() } } }; /*line :556:1*/panic("j2g: unreachable") }
















type A_arbace_repr_go_print_emit_A struct{ jrt.Object }

var A_arbace_repr_go_print_emit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_emit_A_const_0 *lang.Var

var A_arbace_repr_go_print_emit_A_const_1 *lang.Var

var A_arbace_repr_go_print_emit_A_const_2 any

var A_arbace_repr_go_print_emit_A_const_3 any

var A_arbace_repr_go_print_emit_A_const_4 any

var A_arbace_repr_go_print_emit_A_const_5 *lang.Var

var A_arbace_repr_go_print_emit_A_const_6 *lang.Var

var A_arbace_repr_go_print_emit_A_const_7 *lang.Var

var A_arbace_repr_go_print_emit_A_const_8 any

var A_arbace_repr_go_print_emit_A_const_9 *lang.Var

var A_arbace_repr_go_print_emit_A_const_10 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_11 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_12 *lang.Var

var A_arbace_repr_go_print_emit_A_const_13 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_14 *lang.Var

var A_arbace_repr_go_print_emit_A_const_15 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_16 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_17 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_18 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_19 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_20 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_21 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_23 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_24 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_25 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_26 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_27 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_29 any

var A_arbace_repr_go_print_emit_A_const_30 any

var A_arbace_repr_go_print_emit_A_const_31 *lang.Var

var A_arbace_repr_go_print_emit_A_const_32 *lang.Var

var A_arbace_repr_go_print_emit_A_const_33 *lang.Var

var A_arbace_repr_go_print_emit_A_const_34 *lang.Var

var A_arbace_repr_go_print_emit_A_const_35 any

var A_arbace_repr_go_print_emit_A_const_36 any

var A_arbace_repr_go_print_emit_A_const_37 any

var A_arbace_repr_go_print_emit_A_const_38 any

var A_arbace_repr_go_print_emit_A_const_39 any

var A_arbace_repr_go_print_emit_A_const_40 *lang.Var

var A_arbace_repr_go_print_emit_A_const_41 any

var A_arbace_repr_go_print_emit_A_const_42 any

var A_arbace_repr_go_print_emit_A_const_43 any

var A_arbace_repr_go_print_emit_A_const_44 *lang.Var

var A_arbace_repr_go_print_emit_A_const_45 *lang.Var

var A_arbace_repr_go_print_emit_A_const_46 any

var A_arbace_repr_go_print_emit_A_const_47 any

var A_arbace_repr_go_print_emit_A_const_48 any

var A_arbace_repr_go_print_emit_A_const_49 any

var A_arbace_repr_go_print_emit_A_const_50 any

var A_arbace_repr_go_print_emit_A_const_51 *lang.Var

var A_arbace_repr_go_print_emit_A_const_52 *lang.Var

var A_arbace_repr_go_print_emit_A_const_53 any

var A_arbace_repr_go_print_emit_A_const_54 *lang.Var

var A_arbace_repr_go_print_emit_A_const_55 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_56 any

var A_arbace_repr_go_print_emit_A_const_57 any

var A_arbace_repr_go_print_emit_A_const_58 any

var A_arbace_repr_go_print_emit_A_const_59 any

var A_arbace_repr_go_print_emit_A_const_60 any

var A_arbace_repr_go_print_emit_A_const_61 any

var A_arbace_repr_go_print_emit_A_const_62 any

var A_arbace_repr_go_print_emit_A_const_63 any

var A_arbace_repr_go_print_emit_A_const_64 any

var A_arbace_repr_go_print_emit_A_const_65 any

var A_arbace_repr_go_print_emit_A_const_66 any

var A_arbace_repr_go_print_emit_A_const_67 any

var A_arbace_repr_go_print_emit_A_const_68 *lang.Var

var A_arbace_repr_go_print_emit_A_const_69 any

var A_arbace_repr_go_print_emit_A_const_70 *lang.Var

var A_arbace_repr_go_print_emit_A_const_71 any

var A_arbace_repr_go_print_emit_A_const_72 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_73 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_74 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_75 *lang.Var

var A_arbace_repr_go_print_emit_A_const_76 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_77 *lang.Var

var A_arbace_repr_go_print_emit_A_const_78 *lang.Var

var A_arbace_repr_go_print_emit_A_const_79 any

var A_arbace_repr_go_print_emit_A_const_80 *lang.Var

var A_arbace_repr_go_print_emit_A_const_81 *lang.Var

var A_arbace_repr_go_print_emit_A_const_82 *lang.Var

var A_arbace_repr_go_print_emit_A_const_83 *lang.Var

var A_arbace_repr_go_print_emit_A_const_84 any

var A_arbace_repr_go_print_emit_A_const_85 any

var A_arbace_repr_go_print_emit_A_const_86 *lang.Var

var A_arbace_repr_go_print_emit_A_const_87 any

var A_arbace_repr_go_print_emit_A_const_88 *lang.Var

var A_arbace_repr_go_print_emit_A_const_89 *lang.Var

var A_arbace_repr_go_print_emit_A_const_90 *lang.Var

var A_arbace_repr_go_print_emit_A_const_91 *lang.Var

var A_arbace_repr_go_print_emit_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_93 *lang.Var

var A_arbace_repr_go_print_emit_A_const_94 *lang.Var

var A_arbace_repr_go_print_emit_A_const_95 *lang.Var

var A_arbace_repr_go_print_emit_A_const_96 *lang.Var

var A_arbace_repr_go_print_emit_A_const_97 *lang.Var

var A_arbace_repr_go_print_emit_A_const_98 *lang.Var

var A_arbace_repr_go_print_emit_A_const_99 *lang.Var

var A_arbace_repr_go_print_emit_A_const_100 any

var A_arbace_repr_go_print_emit_A_const_101 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_102 *lang.Var

var A_arbace_repr_go_print_emit_A_const_103 *lang.Var

var A_arbace_repr_go_print_emit_A_const_104 *lang.Var

var A_arbace_repr_go_print_emit_A_const_105 *lang.Var

var A_arbace_repr_go_print_emit_A_const_106 *lang.Var

var A_arbace_repr_go_print_emit_A_const_107 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_108 *lang.Var

var A_arbace_repr_go_print_emit_A_const_109 *lang.Var

var A_arbace_repr_go_print_emit_A_const_110 *lang.Var

var A_arbace_repr_go_print_emit_A_const_111 *lang.Var

var A_arbace_repr_go_print_emit_A_const_112 any

var A_arbace_repr_go_print_emit_A_const_113 *lang.Var

var A_arbace_repr_go_print_emit_A_const_114 *lang.Var

var A_arbace_repr_go_print_emit_A_const_115 *lang.Var

var A_arbace_repr_go_print_emit_A_const_116 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_117 *lang.Var

var A_arbace_repr_go_print_emit_A_const_118 *lang.Var

var A_arbace_repr_go_print_emit_A_const_119 *lang.Var

var A_arbace_repr_go_print_emit_A_const_120 *lang.Var

var A_arbace_repr_go_print_emit_A_const_121 *lang.Var

var A_arbace_repr_go_print_emit_A_const_122 *lang.Var

var A_arbace_repr_go_print_emit_A_const_123 *lang.Var

var A_arbace_repr_go_print_emit_A_const_124 *lang.Var

var A_arbace_repr_go_print_emit_A_const_125 *lang.Var

var A_arbace_repr_go_print_emit_A_const_126 *lang.Var

var A_arbace_repr_go_print_emit_A_const_127 *lang.Var

var A_arbace_repr_go_print_emit_A_const_128 *lang.Var

var A_arbace_repr_go_print_emit_A_const_129 *lang.Var

var A_arbace_repr_go_print_emit_A_const_130 *lang.Var

var A_arbace_repr_go_print_emit_A_const_131 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_132 *lang.Var

var A_arbace_repr_go_print_emit_A_const_133 *lang.Var

var A_arbace_repr_go_print_emit_A_const_134 *lang.Var

var A_arbace_repr_go_print_emit_A_const_135 *lang.Var

var A_arbace_repr_go_print_emit_A_const_136 *lang.Var

var A_arbace_repr_go_print_emit_A_const_137 *lang.Var

var A_arbace_repr_go_print_emit_A_const_138 *lang.Var

var A_arbace_repr_go_print_emit_A_const_139 *lang.Var

var A_arbace_repr_go_print_emit_A_const_140 *lang.Var

var A_arbace_repr_go_print_emit_A_const_141 any

var A_arbace_repr_go_print_emit_A_const_142 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_143 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_144 *lang.Var

var A_arbace_repr_go_print_emit_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_146 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_147 any

var A_arbace_repr_go_print_emit_A_const_148 *lang.Var

var A_arbace_repr_go_print_emit_A_const_149 *lang.Var

var A_arbace_repr_go_print_emit_A_const_150 *lang.Keyword

var A_arbace_repr_go_print_emit_A_const_151 *lang.Var

var A_arbace_repr_go_print_emit_A_const_152 *lang.Var

var A_arbace_repr_go_print_emit_A_const_153 *lang.Var

var A_arbace_repr_go_print_emit_A_const_154 *lang.Var

var A_arbace_repr_go_print_emit_A_const_155 *lang.Var

var A_arbace_repr_go_print_emit_A_init jrt.ClassInit

func A_arbace_repr_go_print_emit_A_Init() { if !A_arbace_repr_go_print_emit_A_init.Done() { A_arbace_repr_go_print_emit_A_init.Run(A_arbace_repr_go_print_emit_A_clinit) } }

func A_arbace_repr_go_print_emit_A_clinit() { A_arbace_repr_go_print_emit_A_clinit_p0(); A_arbace_repr_go_print_emit_A_clinit_p1(); A_arbace_repr_go_print_emit_A_clinit_p2(); A_arbace_repr_go_print_emit_A_clinit_p3(); A_arbace_repr_go_print_emit_A_clinit_p4(); A_arbace_repr_go_print_emit_A_clinit_p5(); A_arbace_repr_go_print_emit_A_clinit_p6(); A_arbace_repr_go_print_emit_A_clinit_p7(); A_arbace_repr_go_print_emit_A_clinit_p8(); A_arbace_repr_go_print_emit_A_clinit_p9(); A_arbace_repr_go_print_emit_A_clinit_p10(); A_arbace_repr_go_print_emit_A_clinit_p11(); A_arbace_repr_go_print_emit_A_clinit_p12() }

func A_arbace_repr_go_print_emit_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 204); A_arbace_repr_go_print_emit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[48]); A_arbace_repr_go_print_emit_A_const_1 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[49]); A_arbace_repr_go_print_emit_A_const_2 = A_arbace_repr_go_print_emit_A_const_pool.A[50]; A_arbace_repr_go_print_emit_A_const_3 = A_arbace_repr_go_print_emit_A_const_pool.A[51]; A_arbace_repr_go_print_emit_A_const_4 = A_arbace_repr_go_print_emit_A_const_pool.A[52]; A_arbace_repr_go_print_emit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[53]); A_arbace_repr_go_print_emit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[54]); A_arbace_repr_go_print_emit_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[55]); A_arbace_repr_go_print_emit_A_const_8 = A_arbace_repr_go_print_emit_A_const_pool.A[56]; A_arbace_repr_go_print_emit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[57]); A_arbace_repr_go_print_emit_A_const_10 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[58]); A_arbace_repr_go_print_emit_A_const_11 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[59]) }

func A_arbace_repr_go_print_emit_A_clinit_p1() { A_arbace_repr_go_print_emit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[60]); A_arbace_repr_go_print_emit_A_const_13 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[61]); A_arbace_repr_go_print_emit_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[62]); A_arbace_repr_go_print_emit_A_const_15 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[63]); A_arbace_repr_go_print_emit_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[64]); A_arbace_repr_go_print_emit_A_const_17 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[65]); A_arbace_repr_go_print_emit_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[66]); A_arbace_repr_go_print_emit_A_const_19 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[67]); A_arbace_repr_go_print_emit_A_const_20 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[68]); A_arbace_repr_go_print_emit_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[69]); A_arbace_repr_go_print_emit_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[70]); A_arbace_repr_go_print_emit_A_const_23 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[71]) }

func A_arbace_repr_go_print_emit_A_clinit_p2() { A_arbace_repr_go_print_emit_A_const_24 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[72]); A_arbace_repr_go_print_emit_A_const_25 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[73]); A_arbace_repr_go_print_emit_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[74]); A_arbace_repr_go_print_emit_A_const_27 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[75]); A_arbace_repr_go_print_emit_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[76]); A_arbace_repr_go_print_emit_A_const_29 = A_arbace_repr_go_print_emit_A_const_pool.A[77]; A_arbace_repr_go_print_emit_A_const_30 = A_arbace_repr_go_print_emit_A_const_pool.A[78]; A_arbace_repr_go_print_emit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[79]); A_arbace_repr_go_print_emit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[80]); A_arbace_repr_go_print_emit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[81]); A_arbace_repr_go_print_emit_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[82]); A_arbace_repr_go_print_emit_A_const_35 = A_arbace_repr_go_print_emit_A_const_pool.A[83]; A_arbace_repr_go_print_emit_A_const_36 = A_arbace_repr_go_print_emit_A_const_pool.A[84] }

func A_arbace_repr_go_print_emit_A_clinit_p3() { A_arbace_repr_go_print_emit_A_const_37 = A_arbace_repr_go_print_emit_A_const_pool.A[85]; A_arbace_repr_go_print_emit_A_const_38 = A_arbace_repr_go_print_emit_A_const_pool.A[86]; A_arbace_repr_go_print_emit_A_const_39 = A_arbace_repr_go_print_emit_A_const_pool.A[87]; A_arbace_repr_go_print_emit_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[88]); A_arbace_repr_go_print_emit_A_const_41 = A_arbace_repr_go_print_emit_A_const_pool.A[89]; A_arbace_repr_go_print_emit_A_const_42 = A_arbace_repr_go_print_emit_A_const_pool.A[90]; A_arbace_repr_go_print_emit_A_const_43 = A_arbace_repr_go_print_emit_A_const_pool.A[91]; A_arbace_repr_go_print_emit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[92]); A_arbace_repr_go_print_emit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[93]); A_arbace_repr_go_print_emit_A_const_46 = A_arbace_repr_go_print_emit_A_const_pool.A[94]; A_arbace_repr_go_print_emit_A_const_47 = A_arbace_repr_go_print_emit_A_const_pool.A[95]; A_arbace_repr_go_print_emit_A_const_48 = A_arbace_repr_go_print_emit_A_const_pool.A[96]; A_arbace_repr_go_print_emit_A_const_49 = A_arbace_repr_go_print_emit_A_const_pool.A[97]; A_arbace_repr_go_print_emit_A_const_50 = A_arbace_repr_go_print_emit_A_const_pool.A[98] }

func A_arbace_repr_go_print_emit_A_clinit_p4() { A_arbace_repr_go_print_emit_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[99]); A_arbace_repr_go_print_emit_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[100]); A_arbace_repr_go_print_emit_A_const_53 = A_arbace_repr_go_print_emit_A_const_pool.A[101]; A_arbace_repr_go_print_emit_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[102]); A_arbace_repr_go_print_emit_A_const_55 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[103]); A_arbace_repr_go_print_emit_A_const_56 = A_arbace_repr_go_print_emit_A_const_pool.A[104]; A_arbace_repr_go_print_emit_A_const_57 = A_arbace_repr_go_print_emit_A_const_pool.A[105]; A_arbace_repr_go_print_emit_A_const_58 = A_arbace_repr_go_print_emit_A_const_pool.A[106]; A_arbace_repr_go_print_emit_A_const_59 = A_arbace_repr_go_print_emit_A_const_pool.A[107]; A_arbace_repr_go_print_emit_A_const_60 = A_arbace_repr_go_print_emit_A_const_pool.A[108]; A_arbace_repr_go_print_emit_A_const_61 = A_arbace_repr_go_print_emit_A_const_pool.A[109]; A_arbace_repr_go_print_emit_A_const_62 = A_arbace_repr_go_print_emit_A_const_pool.A[110]; A_arbace_repr_go_print_emit_A_const_63 = A_arbace_repr_go_print_emit_A_const_pool.A[111]; A_arbace_repr_go_print_emit_A_const_64 = A_arbace_repr_go_print_emit_A_const_pool.A[112] }

func A_arbace_repr_go_print_emit_A_clinit_p5() { A_arbace_repr_go_print_emit_A_const_65 = A_arbace_repr_go_print_emit_A_const_pool.A[113]; A_arbace_repr_go_print_emit_A_const_66 = A_arbace_repr_go_print_emit_A_const_pool.A[114]; A_arbace_repr_go_print_emit_A_const_67 = A_arbace_repr_go_print_emit_A_const_pool.A[115]; A_arbace_repr_go_print_emit_A_const_68 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[116]); A_arbace_repr_go_print_emit_A_const_69 = A_arbace_repr_go_print_emit_A_const_pool.A[117]; A_arbace_repr_go_print_emit_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[118]); A_arbace_repr_go_print_emit_A_const_71 = A_arbace_repr_go_print_emit_A_const_pool.A[119]; A_arbace_repr_go_print_emit_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[120]); A_arbace_repr_go_print_emit_A_const_73 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[121]); A_arbace_repr_go_print_emit_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[122]); A_arbace_repr_go_print_emit_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[123]); A_arbace_repr_go_print_emit_A_const_76 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[124]); A_arbace_repr_go_print_emit_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[125]) }

func A_arbace_repr_go_print_emit_A_clinit_p6() { A_arbace_repr_go_print_emit_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[126]); A_arbace_repr_go_print_emit_A_const_79 = A_arbace_repr_go_print_emit_A_const_pool.A[127]; A_arbace_repr_go_print_emit_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[128]); A_arbace_repr_go_print_emit_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[129]); A_arbace_repr_go_print_emit_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[130]); A_arbace_repr_go_print_emit_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[131]); A_arbace_repr_go_print_emit_A_const_84 = A_arbace_repr_go_print_emit_A_const_pool.A[132]; A_arbace_repr_go_print_emit_A_const_85 = A_arbace_repr_go_print_emit_A_const_pool.A[133]; A_arbace_repr_go_print_emit_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[134]); A_arbace_repr_go_print_emit_A_const_87 = A_arbace_repr_go_print_emit_A_const_pool.A[135]; A_arbace_repr_go_print_emit_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[136]); A_arbace_repr_go_print_emit_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[137]); A_arbace_repr_go_print_emit_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[138]) }

func A_arbace_repr_go_print_emit_A_clinit_p7() { A_arbace_repr_go_print_emit_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[139]); A_arbace_repr_go_print_emit_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[140]); A_arbace_repr_go_print_emit_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[141]); A_arbace_repr_go_print_emit_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[142]); A_arbace_repr_go_print_emit_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[143]); A_arbace_repr_go_print_emit_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[144]); A_arbace_repr_go_print_emit_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[145]); A_arbace_repr_go_print_emit_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[146]); A_arbace_repr_go_print_emit_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[147]); A_arbace_repr_go_print_emit_A_const_100 = A_arbace_repr_go_print_emit_A_const_pool.A[148]; A_arbace_repr_go_print_emit_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[149]); A_arbace_repr_go_print_emit_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[150]) }

func A_arbace_repr_go_print_emit_A_clinit_p8() { A_arbace_repr_go_print_emit_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[151]); A_arbace_repr_go_print_emit_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[152]); A_arbace_repr_go_print_emit_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[153]); A_arbace_repr_go_print_emit_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[154]); A_arbace_repr_go_print_emit_A_const_107 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[155]); A_arbace_repr_go_print_emit_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[156]); A_arbace_repr_go_print_emit_A_const_109 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[157]); A_arbace_repr_go_print_emit_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[158]); A_arbace_repr_go_print_emit_A_const_111 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[159]); A_arbace_repr_go_print_emit_A_const_112 = A_arbace_repr_go_print_emit_A_const_pool.A[160]; A_arbace_repr_go_print_emit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[161]); A_arbace_repr_go_print_emit_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[162]) }

func A_arbace_repr_go_print_emit_A_clinit_p9() { A_arbace_repr_go_print_emit_A_const_115 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[163]); A_arbace_repr_go_print_emit_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[164]); A_arbace_repr_go_print_emit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[165]); A_arbace_repr_go_print_emit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[166]); A_arbace_repr_go_print_emit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[167]); A_arbace_repr_go_print_emit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[168]); A_arbace_repr_go_print_emit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[169]); A_arbace_repr_go_print_emit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[170]); A_arbace_repr_go_print_emit_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[171]); A_arbace_repr_go_print_emit_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[172]); A_arbace_repr_go_print_emit_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[173]); A_arbace_repr_go_print_emit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[174]) }

func A_arbace_repr_go_print_emit_A_clinit_p10() { A_arbace_repr_go_print_emit_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[175]); A_arbace_repr_go_print_emit_A_const_128 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[176]); A_arbace_repr_go_print_emit_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[177]); A_arbace_repr_go_print_emit_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[178]); A_arbace_repr_go_print_emit_A_const_131 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[179]); A_arbace_repr_go_print_emit_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[180]); A_arbace_repr_go_print_emit_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[181]); A_arbace_repr_go_print_emit_A_const_134 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[182]); A_arbace_repr_go_print_emit_A_const_135 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[183]); A_arbace_repr_go_print_emit_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[184]); A_arbace_repr_go_print_emit_A_const_137 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[185]); A_arbace_repr_go_print_emit_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[186]) }

func A_arbace_repr_go_print_emit_A_clinit_p11() { A_arbace_repr_go_print_emit_A_const_139 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[187]); A_arbace_repr_go_print_emit_A_const_140 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[188]); A_arbace_repr_go_print_emit_A_const_141 = A_arbace_repr_go_print_emit_A_const_pool.A[189]; A_arbace_repr_go_print_emit_A_const_142 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[190]); A_arbace_repr_go_print_emit_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[191]); A_arbace_repr_go_print_emit_A_const_144 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[192]); A_arbace_repr_go_print_emit_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[193]); A_arbace_repr_go_print_emit_A_const_146 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[194]); A_arbace_repr_go_print_emit_A_const_147 = A_arbace_repr_go_print_emit_A_const_pool.A[195]; A_arbace_repr_go_print_emit_A_const_148 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[196]); A_arbace_repr_go_print_emit_A_const_149 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[197]); A_arbace_repr_go_print_emit_A_const_150 = lang.Keyword_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[198]) }

func A_arbace_repr_go_print_emit_A_clinit_p12() { A_arbace_repr_go_print_emit_A_const_151 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[199]); A_arbace_repr_go_print_emit_A_const_152 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[200]); A_arbace_repr_go_print_emit_A_const_153 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[201]); A_arbace_repr_go_print_emit_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[202]); A_arbace_repr_go_print_emit_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_emit_A_const_pool.A[203]) }

func A_arbace_repr_go_print_emit_A_New() *A_arbace_repr_go_print_emit_A { A_arbace_repr_go_print_emit_A_Init(); t := &A_arbace_repr_go_print_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_A_class }

func (t *A_arbace_repr_go_print_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_A); return ok }

func A_arbace_repr_go_print_emit_A_Cast(x any) *A_arbace_repr_go_print_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_A_class)) }; return v }



type A_arbace_repr_go_print_emit_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_bol_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_bol_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_break_to_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_break_to_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_chunk_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_chunk_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_close_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_close_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_comment_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_comment_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cont_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cont_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_cur_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_cur_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_end_of_fn__308000120_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_end_of_fn__308000120_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000004_A_New() *A_arbace_repr_go_print_emit_eval308000004_A { t := &A_arbace_repr_go_print_emit_eval308000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000004_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); return ok }

func A_arbace_repr_go_print_emit_eval308000004_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000004_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000004_loading__1927001464__auto____308000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000008_A_New() *A_arbace_repr_go_print_emit_eval308000008_A { t := &A_arbace_repr_go_print_emit_eval308000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000008_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); return ok }

func A_arbace_repr_go_print_emit_eval308000008_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000008_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000008_fn__308000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000018_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000018_A_New() *A_arbace_repr_go_print_emit_eval308000018_A { t := &A_arbace_repr_go_print_emit_eval308000018_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000018_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); return ok }

func A_arbace_repr_go_print_emit_eval308000018_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000018_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000018_lines_QMARK___308000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000029_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000029_A_New() *A_arbace_repr_go_print_emit_eval308000029_A { t := &A_arbace_repr_go_print_emit_eval308000029_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000029_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); return ok }

func A_arbace_repr_go_print_emit_eval308000029_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000029_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000029_full_QMARK___308000030_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000040_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000040_A_New() *A_arbace_repr_go_print_emit_eval308000040_A { t := &A_arbace_repr_go_print_emit_eval308000040_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000040_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); return ok }

func A_arbace_repr_go_print_emit_eval308000040_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000040_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000040_line__308000041_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000040_line__308000041_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000051_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000051_A_New() *A_arbace_repr_go_print_emit_eval308000051_A { t := &A_arbace_repr_go_print_emit_eval308000051_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000051_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); return ok }

func A_arbace_repr_go_print_emit_eval308000051_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000051_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000051_bol_QMARK___308000052_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000063_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000063_A_New() *A_arbace_repr_go_print_emit_eval308000063_A { t := &A_arbace_repr_go_print_emit_eval308000063_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000063_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); return ok }

func A_arbace_repr_go_print_emit_eval308000063_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000063_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000063_target__308000064_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000063_target__308000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_eval308000089_A struct{ jrt.Object }

func A_arbace_repr_go_print_emit_eval308000089_A_New() *A_arbace_repr_go_print_emit_eval308000089_A { t := &A_arbace_repr_go_print_emit_eval308000089_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ctor() {}

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_emit_eval308000089_A_class }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_emit_eval308000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_emit_eval308000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); return ok }

func A_arbace_repr_go_print_emit_eval308000089_A_Cast(x any) *A_arbace_repr_go_print_emit_eval308000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_emit_eval308000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_emit_eval308000089_A_class)) }; return v }



type A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_eval308000089_cur_indent__308000090_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000149_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000149_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000152_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000152_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000158_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000158_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000164_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000164_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_A struct{ j2g_header uint64; F_extras, F_items any }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000169_fn__308000177_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000184_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000184_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000227_A struct{ j2g_header uint64; F_merged any; F_n int32; F_i any }

var A_arbace_repr_go_print_emit_full_result_fn__308000227_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000229_A struct{ j2g_header uint64; F_merged any; F_n int32; F_j any }

var A_arbace_repr_go_print_emit_full_result_fn__308000229_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000231_A struct{ j2g_header uint64; F_last_s, F_merged, F_tok_STAR_, F_j, F_i, F_same_line_QMARK_ any }

var A_arbace_repr_go_print_emit_full_result_fn__308000231_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000234_A struct{ j2g_header uint64; F_cl any }

var A_arbace_repr_go_print_emit_full_result_fn__308000234_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000236_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_result_fn__308000236_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_fn__308000238_A struct{ j2g_header uint64; F_obstacles, F_width, F_cur any }

var A_arbace_repr_go_print_emit_full_result_fn__308000238_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A struct{ j2g_header uint64; F_space, F_last_s, F_sb, F_prev_item, F_cur any }

var A_arbace_repr_go_print_emit_full_result_write_at_BANG___308000190_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_full_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_full_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_join_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_join_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_comment_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_comment_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_inline_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_inline_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_line_directive_own_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_line_directive_own_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_lines_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_lines_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_may_combine_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_may_combine_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_new_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_new_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_nl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_nl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000130_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000130_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000137_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000137_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000139_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000139_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000141_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_place_run_fn__308000141_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_fn__308000143_A struct{ j2g_header uint64; F_keep any }

var A_arbace_repr_go_print_emit_place_run_fn__308000143_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_place_run_natural__308000132_A struct{ j2g_header uint64; F_cl any; F_n int32; F_run, F_lens, F_cc any }

var A_arbace_repr_go_print_emit_place_run_natural__308000132_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_pop_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_pop_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_push_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_push_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_raw_tok_fn__308000078_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_render_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_render_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_result_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_result_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_room_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_room_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_semi_after_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_semi_after_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_set_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_soft_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_soft_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_sp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_sp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_at_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_start_line_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_start_line_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_stmt_break_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A struct{ j2g_header uint64; F_indent any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__newline_BANG___308000107_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A struct{ j2g_header uint64; F_first_QMARK_, F_sep any }

var A_arbace_repr_go_print_emit_stmt_break_BANG__same_BANG___308000109_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_utf8_len_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_utf8_len_A_fn_class *jrt.Class



type A_arbace_repr_go_print_emit_vtab_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_emit_vtab_A_fn_class *jrt.Class
