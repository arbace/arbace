//line j2g_strings.ae:1
package aot_arbace_repr_go_print_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn25,arbace.repr.go.print-textkn2,asyn4,textyn13,arbace.stringyn3,stryn11,arbace.corekn3,dockn2,sbkn4,fullkn5,itemskn4,pendkn4,linekn3,bolkn6,indentkn10,cur-indentkn4,lastkn4,semikn2,wskn5,openskn4,markkn8,min-linekn6,lines?kn11,directives?kn16,line-directives?ys25,arbace.repr.go.print-emit3,*p*ys11,arbace.core5,derefys11,arbace.core4,whenys25,arbace.repr.go.print-emit6,lines?ys11,arbace.core3,letyn20,l__308000057__auto__ys11,arbace.core4,metays11,arbace.core8,integer?ys11,arbace.core4,longkn4,elsekn1,skn3,poskn2,spkn4,softkn4,textkn5,breakkn3,sepkn7,commentkn5,semiskn5,trailkn8,commentskn6,trailskn5,spacekn4,tailv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn25,arbace.repr.go.print-emitm2,R6,s435,The emitter of repr/go's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.R7,R8,v11,arbace.core5,assocR9,R10,v11,arbace.core9,volatile!R11,l1,R12,R13,l0,R14,R15,R16,R17,R18,R19,R20,R21,R22,R23,v25,arbace.repr.go.print-emit3,*p*v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR24,R24,R25,R24,R24,v11,arbace.core8,integer?R26,R27,R28,v11,arbace.core5,applyv11,arbace.core6,vectorR29,R30,R26,R31,R32,v11,arbace.core3,notv25,arbace.repr.go.print-emit6,*next*S9,s1,]s1,)s2,++s6,returns11,fallthroughs5,breaks2,--s8,continues1,}v25,arbace.repr.go.print-emit8,keywordsR33,c95,c34,c39,c96,c43,c45,c47,c42,c60,c38,c94,c46,v11,arbace.core10,re-matchesp6,[0-9]+v11,arbace.core7,vreset!c9,R34,R35,R36,v25,arbace.repr.go.print-emit12,may-combine?R37,v25,arbace.repr.go.print-emit8,full-tokv25,arbace.repr.go.print-emit11,start-line!c32,v25,arbace.repr.go.print-emit11,semi-after?v25,arbace.repr.go.print-emit3,tokv25,arbace.repr.go.print-text6,escapev11,arbace.core6,filterc10,c11,v25,arbace.repr.go.print-emit2,nlR24,v25,arbace.repr.go.print-emit10,push-open!v11,arbace.core4,peekv11,arbace.core3,popv13,arbace.string12,starts-with?R38,v11,arbace.core6,empty?v25,arbace.repr.go.print-emit9,set-line!v25,arbace.repr.go.print-emit12,comment-linev11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv25,arbace.repr.go.print-emit9,new-statem4,R21,FR23,FR39,v25,arbace.repr.go.print-emit21,line-directive-inlinev25,arbace.repr.go.print-emit11,cont-indentv25,arbace.repr.go.print-emit2,spv25,arbace.repr.go.print-emit5,room?v25,arbace.repr.go.print-emit4,softR40,v25,arbace.repr.go.print-emit18,line-directive-ownv25,arbace.repr.go.print-emit11,full-resultv13,arbace.string7,replacep10,[ \\x0B]+\\nv25,arbace.repr.go.print-text5,alignv13,arbace.string10,ends-with?v25,arbace.repr.go.print-emit8,utf8-lenv11,arbace.core4,subsR41,v11,arbace.core4,mapvv25,arbace.repr.go.print-emit13,line-comment?v11,arbace.core3,vecv11,arbace.core5,firstv11,arbace.core6,secondv11,arbace.core6,reducev11,arbace.core1,+v11,arbace.core12,keep-indexedv11,arbace.core6,updatev11,arbace.core5,even?v11,arbace.core3,setv11,arbace.core9,take-lastv11,arbace.core11,map-indexedv11,arbace.core4,consR42,v11,arbace.core4,intov11,arbace.core6,removeS2,s1,;s1,,R43,v11,arbace.core7,sort-byR44,v11,arbace.core3,mapR45,v11,arbace.core9,transientv11,arbace.core11,persistent!v11,arbace.core5,conj!v11,arbace.core3,strv11,arbace.core4,nextR46,V2,l1,l1,v25,arbace.repr.go.print-emit6,end-ofv11,arbace.core4,not=v11,arbace.core10,take-whilev11,arbace.core6,subvecR47,v25,arbace.repr.go.print-emit9,place-runv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core10,chunk-rest")

var Lit_1 *jrt.String = jrt.Intern("//line ")

var Lit_2 *jrt.String = jrt.Intern("")

var Lit_3 *jrt.String = jrt.Intern("\n")

var Lit_4 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$end_of$fn__308000120")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000149")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000152")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000158")

var Lit_8 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000164")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000169")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000184")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$write_at_BANG___308000190")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000227")

var Lit_13 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000229")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000231")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000234")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000236")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000238")

var Lit_18 *jrt.String = jrt.Intern(";")

var Lit_19 *jrt.String = jrt.Intern(",")

var Lit_20 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result$fn__308000169$fn__308000177")

var Lit_21 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_22 *jrt.String = jrt.Intern(" ")

var Lit_23 *jrt.String = jrt.Intern("//")

var Lit_24 *jrt.String = jrt.Intern("/*line :")

var Lit_25 *jrt.String = jrt.Intern(":1*/")

var Lit_26 *jrt.String = jrt.Intern("//line :")

var Lit_27 *jrt.String = jrt.Intern(":1")

var Lit_28 *jrt.String = jrt.Intern("+")

var Lit_29 *jrt.String = jrt.Intern("-")

var Lit_30 *jrt.String = jrt.Intern("<")

var Lit_31 *jrt.String = jrt.Intern("&")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$fn__308000130")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$natural__308000132")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$fn__308000137")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$fn__308000139")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$fn__308000141")

var Lit_37 *jrt.String = jrt.Intern(":")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run$fn__308000143")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$raw_tok$fn__308000078")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$stmt_break_BANG_$newline_BANG___308000107")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$stmt_break_BANG_$same_BANG___308000109")

var Lit_42 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn4,optskn6,inlineyn1,fyn1,nkn7,privatekn3,tagyn6,Stringyn3,posyn4,kindyn6,indentyn10,form-feed?yn1,lyn1,cyn1,tyn6,first?yn3,sepyn3,endyn10,multiline?yn7,always?kn8,declaredyn4,longyn2,ityn3,runyn3,curyn9,prev-itemyn3,nxtv11,arbace.core5,in-nsMyn25,arbace.repr.go.print-emitm2,R0,s435,The emitter of repr/go's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.m2,R0,s435,The emitter of repr/go's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.R1,v25,arbace.repr.go.print-emit3,*p*m8,R2,TR3,i12,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,*next*m10,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_emit.aeR0,s155,The line of what follows the construct being printed, when known: the room a closing\n  brace or a statement without a recorded line may take (mode :lines).v25,arbace.repr.go.print-emit9,new-statem10,R6,L1,V1,R7,R0,s387,opts: :lines? (place forms on their recorded lines), :line-directives? (write //line or\n  /*line*/ directives where a recorded line cannot be reached by layout), :full (mode :full,\n  SPEC §10.2, §12.3: tokens are collected with their positions and laid out at the end; a map\n  {:comments [[line col text] ...] :space [[line col ws] ...] :tail ws} of the file's text\n  beyond its tokens).R3,i19,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,lines?m8,R6,L1,V0,R3,i42,R4,i1,R5,s28,arbace/repr/go/print_emit.aev11,arbace.core11,alter-meta!v11,arbace.core5,assocR8,v25,arbace.repr.go.print-emit5,full?m8,R6,L1,V0,R3,i43,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit4,linem8,R6,L1,V0,R3,i44,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit4,bol?m8,R6,L1,V0,R3,i45,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,targetm10,R6,L1,V1,R9,R0,s118,The recorded line of a form (mode :lines): :line metadata on lists, and on symbols and\n  vectors that begin a Go line.R3,i47,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit5,room?m10,R6,L1,V1,R10,R0,s92,Whether n more lines fit before *next* (always, when it is unknown or out of mode\n  :lines).R3,i55,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit8,keywordsS25,s4,elses4,funcs3,maps5,ranges4,chans7,packages9,interfaces5,defers3,vars6,returns3,fors11,fallthroughs2,ifs6,imports2,gos6,switchs5,consts6,selects4,cases5,breaks8,continues4,types6,structs7,defaults4,gotom6,R3,i64,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,semi-after?m12,R11,TR6,L1,V1,Myn1,sm2,R12,R13,R0,s67,Go's semicolon rule: a newline after this token ends the statement.R3,i69,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit12,may-combine?m12,R11,TR6,L1,V2,Myn4,prevm2,R12,R13,Myn4,nextm2,R12,R13,R0,s96,go/printer's mayCombine, extended: the two tokens would scan as other tokens unless\n  separated.R3,i80,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,start-line!m10,R11,TR6,L1,V0,R3,i96,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit3,at!m10,R6,L1,V1,R14,R0,s66,Mode :full: the position [line col] of the next token (nil: none).R3,i106,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit8,full-tokm12,R11,TR6,L1,V1,Myn1,sm2,R12,R13,R0,s106,Mode :full: collects a token, its position (at!) and whether gofmt's layout would put a\n  blank before it.R3,i113,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit4,softm10,R6,L1,V2,R15,Myn1,sm2,R12,R13,R0,s213,Mode :full: a separator the layout decides: kind :sep (\";\" or \",\" between elements, kept\n  when the next token follows on the line) or :trail (a trailing comma, kept when the closing\n  bracket is on a later line).R3,i126,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit3,tokm10,R6,L1,V1,Myn1,sm2,R12,R13,R0,s15,Writes a token.R3,i135,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit7,raw-tokm10,R6,L1,V1,Myn1,sm2,R12,R13,R0,s106,Writes a token that may span lines (a raw string): its line breaks count, and alignment\n  leaves it whole.R3,i154,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit2,spm10,R6,L1,V0,R0,s43,A blank before the next token on this line.R3,i164,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit4,vtabm10,R6,L1,V0,R0,s60,An alignment separator before the next token (gofmt's vtab).R3,i172,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit2,nlm10,R6,L2,V1,R16,V2,R16,R17,R0,s97,Ends the line; the next line is indented by indent. form-feed? ends the alignment\n  sections too.R3,i182,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit10,cur-indentm8,R6,L1,V0,R3,i197,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit10,push-open!m10,R6,L2,V0,V1,R16,R0,s119,Records an open bracket (or a statement) whose continuation lines indent one more than\n  indent (default: this line's).R3,i199,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,pop-open!m8,R6,L1,V0,R3,i205,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,cont-indentm10,R6,L1,V0,R0,s39,The indentation of a continuation line.R3,i210,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit12,comment-linem10,R6,L1,V2,Myn1,sm2,R12,R13,R16,R0,s141,Writes a whole-line comment (doc comment line, directive) at indent and ends the line.\n  //line directives start at column 1, as gc requires.R3,i216,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,set-line!m10,R6,L1,V1,R18,R0,s73,Sets the line of the cursor as gc will see it (after a //line directive).R3,i230,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,start-at!m10,R6,L1,V1,R18,R0,s66,Starts a chunk's state at line l (start of a line, indentation 0).R3,i250,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,chunk-statem10,R6,L1,V0,R0,s94,The state after a chunk was printed (in its own state, *p*): its text and its emitter\n  state.R3,i256,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit5,join!m10,R6,L1,V2,R19,R18,R0,s198,Appends the chunk c (chunk-state), printed from line l (start-at!), to *p* when *p*'s state\n  is where c's printing assumed it: true when joined, false when the chunk must be printed\n  again in *p*.R3,i266,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit21,line-directive-inlinem10,R6,L1,V1,R10,R0,s89,/*line :N:1*/ before the next token: gc puts it on line N (a column keeps the file name).R3,i288,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit18,line-directive-ownm10,R6,L1,V1,R10,R0,s81,//line :N:1 on a line of its own, at the start of a line: the line after it is N.R3,i298,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,renderm10,R6,L1,V1,R9,R0,s119,The text f (a function of no arguments that prints) writes on a fresh line, without\n  positions: go/printer's nodeSize.R3,i308,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,break-to!m10,R6,L1,V1,R20,R0,s142,Inside an expression, before a form recorded at line t (or :break, a new line): line\n  breaks where Go allows them, else a /*line*/ directive.R3,i317,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,stmt-break!m10,R6,L1,V4,R20,R21,R22,R16,R0,s298,Before a statement, a declaration or another element of a list whose elements may be\n  separated by a line break or by sep (\";\" or \",\"): moves to its line t (nil: unknown).\n  first? when it follows the opening bracket. indent is the element's indentation. Returns\n  true when a line break was made.R3,i338,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit12,close-break!m10,R6,L1,V4,R23,R24,R25,R16,R0,s277,Before a closing bracket: end, its recorded line (or nil); multiline?, whether the\n  construct already spans lines; always?, whether gofmt's layout puts it on a line of its\n  own. Returns true when the bracket goes on a new line (indented as the line of its\n  opening, indent).R3,i359,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit11,full-resultm8,R26,TR3,i376,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,resultm10,R6,L1,V0,R0,s26,The text written, aligned.R3,i378,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit8,utf8-lenm10,R11,TR6,L1,MV1,Myn1,sm2,R12,R13,m2,R12,R27,R3,i400,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit6,end-ofm12,R11,TR6,L1,V2,V2,R18,R19,Myn1,sm2,R12,R13,R0,s43,The position after text s written at [l c].R3,i403,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,glue-leftS9,s3,...s1,]s1,)s2,++s2,--s1,:s1,;s1,,s1,}m8,R11,TR3,i411,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit13,line-comment?m10,R11,TR6,L1,V1,R28,R3,i413,R4,i1,R5,s28,arbace/repr/go/print_emit.aev25,arbace.repr.go.print-emit9,place-runm12,R11,TR6,L1,V4,R29,R30,R31,R32,R0,s168,Positions for the unpositioned tokens run (each {:s :sp}) after the cursor cur (the end of\n  the token before them, prev-item), before the positioned item nxt (or nil).R3,i415,R4,i1,R5,s28,arbace/repr/go/print_emit.aem10,R6,L1,V0,R0,s76,The text of the tokens collected in mode :full, laid out at their positions.R3,i465,R4,i1,R5,s28,arbace/repr/go/print_emit.ae")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000004$loading__1927001464__auto____308000005")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000008$fn__308000009")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$new_state")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$lines_QMARK_")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000018$lines_QMARK___308000019")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_QMARK_")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000029$full_QMARK___308000030")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$line")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000040$line__308000041")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$bol_QMARK_")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000051$bol_QMARK___308000052")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$target")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000063$target__308000064")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$room_QMARK_")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$semi_after_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$may_combine_QMARK_")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$start_line_BANG_")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$at_BANG_")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_tok")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$soft")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$tok")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$raw_tok")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$sp")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$vtab")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$nl")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$cur_indent")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$eval308000089$cur_indent__308000090")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$push_open_BANG_")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$pop_open_BANG_")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$cont_indent")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$comment_line")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$set_line_BANG_")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$start_at_BANG_")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$chunk_state")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$join_BANG_")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$line_directive_inline")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$line_directive_own")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$render")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$break_to_BANG_")

var Lit_82 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$stmt_break_BANG_")

var Lit_83 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$close_break_BANG_")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$result")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$utf8_len")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$end_of")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$line_comment_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$place_run")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.print_emit$full_result")
