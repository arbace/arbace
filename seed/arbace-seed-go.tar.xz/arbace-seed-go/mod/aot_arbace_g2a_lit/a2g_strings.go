//line a2g_strings.ae:1
package aot_arbace_g2a_lit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.lit")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Go literals and constant values as Clojure literals (doc/go/SPEC.md §8): integers, exact\n  floats (doubles, BigDecimals, ratios), runes, strings and byte strings, and the\n  representation of constant values (:val, §8.2) from the helper's exact values and go/types'\n  types.\n\n  A literal is a Lit: the text written into the forms and the value the reader reads back.\n  Composite spellings ((rune n), (imaginary x), (byte-string ...), (complex re im)) are lists.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("into")

var Lit_14 *jrt.String = jrt.Intern("->Lit")

var Lit_15 *jrt.String = jrt.Intern("not")

var Lit_16 *jrt.String = jrt.Intern("<=")

var Lit_17 *jrt.String = jrt.Intern("contains?")

var Lit_18 *jrt.String = jrt.Intern("printable?")

var Lit_19 *jrt.String = jrt.Intern("format")

var Lit_20 *jrt.String = jrt.Intern("else")

var Lit_21 *jrt.String = jrt.Intern("seq")

var Lit_22 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_23 *jrt.String = jrt.Intern("chunk-first")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("chunk-rest")

var Lit_26 *jrt.String = jrt.Intern("next")

var Lit_27 *jrt.String = jrt.Intern("char-names")

var Lit_28 *jrt.String = jrt.Intern("replace")

var Lit_29 *jrt.String = jrt.Intern("lower-case")

var Lit_30 *jrt.String = jrt.Intern("starts-with?")

var Lit_31 *jrt.String = jrt.Intern("bigint")

var Lit_32 *jrt.String = jrt.Intern("lit")

var Lit_33 *jrt.String = jrt.Intern("subs")

var Lit_34 *jrt.String = jrt.Intern("biginteger")

var Lit_35 *jrt.String = jrt.Intern("integer-text")

var Lit_36 *jrt.String = jrt.Intern("some")

var Lit_37 *jrt.String = jrt.Intern("ratio?")

var Lit_38 *jrt.String = jrt.Intern("numerator")

var Lit_39 *jrt.String = jrt.Intern("denominator")

var Lit_40 *jrt.String = jrt.Intern("pow5-exponent")

var Lit_41 *jrt.String = jrt.Intern("rationalize")

var Lit_42 *jrt.String = jrt.Intern("includes?")

var Lit_43 *jrt.String = jrt.Intern("to-array")

var Lit_44 *jrt.String = jrt.Intern("prefer-ratio")

var Lit_45 *jrt.String = jrt.Intern("double-exact-text")

var Lit_46 *jrt.String = jrt.Intern("decimal-text")

var Lit_47 *jrt.String = jrt.Intern("num-den")

var Lit_48 *jrt.String = jrt.Intern("terminating-decimal")

var Lit_49 *jrt.String = jrt.Intern("max-decimal-length")

var Lit_50 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_51 *jrt.String = jrt.Intern("float-lit")

var Lit_52 *jrt.String = jrt.Intern("index-of")

var Lit_53 *jrt.String = jrt.Intern("empty?")

var Lit_54 *jrt.String = jrt.Intern("rational")

var Lit_55 *jrt.String = jrt.Intern("pow2")

var Lit_56 *jrt.String = jrt.Intern("hex-float-value")

var Lit_57 *jrt.String = jrt.Intern("float-value")

var Lit_58 *jrt.String = jrt.Intern("re-matches")

var Lit_59 *jrt.String = jrt.Intern("int-lit")

var Lit_60 *jrt.String = jrt.Intern("float-text-lit")

var Lit_61 *jrt.String = jrt.Intern("[0-9]+")

var Lit_62 *jrt.String = jrt.Intern("0[xob].*")

var Lit_63 *jrt.String = jrt.Intern("not=")

var Lit_64 *jrt.String = jrt.Intern("hexv")

var Lit_65 *jrt.String = jrt.Intern("unescape")

var Lit_66 *jrt.String = jrt.Intern("decode-rune")

var Lit_67 *jrt.String = jrt.Intern("list")

var Lit_68 *jrt.String = jrt.Intern("char-text")

var Lit_69 *jrt.String = jrt.Intern("rune")

var Lit_70 *jrt.String = jrt.Intern("utf8-parts")

var Lit_71 *jrt.String = jrt.Intern("every?")

var Lit_72 *jrt.String = jrt.Intern("apply")

var Lit_73 *jrt.String = jrt.Intern("string?")

var Lit_74 *jrt.String = jrt.Intern("string-text")

var Lit_75 *jrt.String = jrt.Intern("byte-string")

var Lit_76 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_77 *jrt.String = jrt.Intern("chunk-append")

var Lit_78 *jrt.String = jrt.Intern("chunk-cons")

var Lit_79 *jrt.String = jrt.Intern("cons")

var Lit_80 *jrt.String = jrt.Intern("chunk")

var Lit_81 *jrt.String = jrt.Intern("rest")

var Lit_82 *jrt.String = jrt.Intern("integer?")

var Lit_83 *jrt.String = jrt.Intern("seq?")

var Lit_84 *jrt.String = jrt.Intern("float")

var Lit_85 *jrt.String = jrt.Intern("second")

var Lit_86 *jrt.String = jrt.Intern("ex-info")

var Lit_87 *jrt.String = jrt.Intern("pr-str")

var Lit_88 *jrt.String = jrt.Intern("v")

var Lit_89 *jrt.String = jrt.Intern("binary-float")

var Lit_90 *jrt.String = jrt.Intern("integer-lit")

var Lit_91 *jrt.String = jrt.Intern("val-rational")

var Lit_92 *jrt.String = jrt.Intern("boolean?")

var Lit_93 *jrt.String = jrt.Intern("bool")

var Lit_94 *jrt.String = jrt.Intern("string")

var Lit_95 *jrt.String = jrt.Intern("bytes")

var Lit_96 *jrt.String = jrt.Intern("int")

var Lit_97 *jrt.String = jrt.Intern("complex")

var Lit_98 *jrt.String = jrt.Intern("untyped-float")

var Lit_99 *jrt.String = jrt.Intern("untyped-float-form")

var Lit_100 *jrt.String = jrt.Intern("untyped-complex")

var Lit_101 *jrt.String = jrt.Intern("double-lit")

var Lit_102 *jrt.String = jrt.Intern("rune-form")

var Lit_103 *jrt.String = jrt.Intern("bytes-form")

var Lit_104 *jrt.String = jrt.Intern("map")

var Lit_105 *jrt.String = jrt.Intern("unchecked-byte")

var Lit_106 *jrt.String = jrt.Intern("arbace.g2a.lit$bytes_form")

var Lit_107 *jrt.String = jrt.Intern("arbace.g2a.lit$bytes_form$iter__1426000088__1426000092")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.lit$bytes_form$iter__1426000088__1426000092$fn__1426000093")

var Lit_109 *jrt.String = jrt.Intern("0x%02x")

var Lit_110 *jrt.String = jrt.Intern("arbace.g2a.lit$bytes_form$iter__1426000088__1426000092$fn__1426000093$fn__1426000094")

var Lit_111 *jrt.String = jrt.Intern("arbace.g2a.lit$char_text")

var Lit_112 *jrt.String = jrt.Intern("\\")

var Lit_113 *jrt.String = jrt.Intern("\\u%04x")

var Lit_114 *jrt.String = jrt.Intern("arbace.g2a.lit$const_form")

var Lit_115 *jrt.String = jrt.Intern("integer constant with value ")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.lit$decimal_text")

var Lit_117 *jrt.String = jrt.Intern(".")

var Lit_118 *jrt.String = jrt.Intern("E")

var Lit_119 *jrt.String = jrt.Intern(".0")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.lit$decode_rune")

var Lit_121 *jrt.String = jrt.Intern("arbace.g2a.lit$decode_rune$b__1426000073")

var Lit_122 *jrt.String = jrt.Intern("arbace.g2a.lit$decode_rune$cont_QMARK___1426000075")

var Lit_123 *jrt.String = jrt.Intern("arbace.g2a.lit$double_exact_text")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.lit$double_lit")

var Lit_125 *jrt.String = jrt.Intern("##NaN")

var Lit_126 *jrt.String = jrt.Intern("##Inf")

var Lit_127 *jrt.String = jrt.Intern("##-Inf")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.lit$eval1426000004$loading__1927001464__auto____1426000005")

var Lit_129 *jrt.String = jrt.Intern("java.math.BigInteger")

var Lit_130 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.lit$eval1426000008$fn__1426000009")

var Lit_132 *jrt.String = jrt.Intern("arbace.g2a.lit$eval1426000013$__GT_Lit__1426000023")

var Lit_133 *jrt.String = jrt.Intern("arbace.g2a.lit$eval1426000013$map__GT_Lit__1426000025")

var Lit_134 *jrt.String = jrt.Intern("arbace.g2a.lit$float_lit")

var Lit_135 *jrt.String = jrt.Intern("M")

var Lit_136 *jrt.String = jrt.Intern("/")

var Lit_137 *jrt.String = jrt.Intern("arbace.g2a.lit$float_text_lit")

var Lit_138 *jrt.String = jrt.Intern("0x")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.lit$float_value")

var Lit_140 *jrt.String = jrt.Intern("_")

var Lit_141 *jrt.String = jrt.Intern("")

var Lit_142 *jrt.String = jrt.Intern("arbace.g2a.lit$hex_float_value")

var Lit_143 *jrt.String = jrt.Intern("p")

var Lit_144 *jrt.String = jrt.Intern("+")

var Lit_145 *jrt.String = jrt.Intern("arbace.g2a.lit$hexv")

var Lit_146 *jrt.String = jrt.Intern("arbace.g2a.lit$imag_inner")

var Lit_147 *jrt.String = jrt.Intern("arbace.g2a.lit$int_lit")

var Lit_148 *jrt.String = jrt.Intern("0o")

var Lit_149 *jrt.String = jrt.Intern("0")

var Lit_150 *jrt.String = jrt.Intern("0b")

var Lit_151 *jrt.String = jrt.Intern("2r")

var Lit_152 *jrt.String = jrt.Intern("arbace.g2a.lit$integer_lit")

var Lit_153 *jrt.String = jrt.Intern("arbace.g2a.lit$integer_text")

var Lit_154 *jrt.String = jrt.Intern("N")

var Lit_155 *jrt.String = jrt.Intern("arbace.g2a.lit$lit")

var Lit_156 *jrt.String = jrt.Intern("arbace.g2a.lit$lit_QMARK_")

var Lit_157 *jrt.String = jrt.Intern("arbace.g2a.lit$num_den")

var Lit_158 *jrt.String = jrt.Intern("arbace.g2a.lit$pow2")

var Lit_159 *jrt.String = jrt.Intern("arbace.g2a.lit$pow5_exponent")

var Lit_160 *jrt.String = jrt.Intern("arbace.g2a.lit$pow5_exponent$fn__1426000046")

var Lit_161 *jrt.String = jrt.Intern("arbace.g2a.lit$printable_QMARK_")

var Lit_162 *jrt.String = jrt.Intern("arbace.g2a.lit$rational")

var Lit_163 *jrt.String = jrt.Intern("arbace.g2a.lit$rune_form")

var Lit_164 *jrt.String = jrt.Intern("0x%X")

var Lit_165 *jrt.String = jrt.Intern("arbace.g2a.lit$rune_value")

var Lit_166 *jrt.String = jrt.Intern("arbace.g2a.lit$string_bytes")

var Lit_167 *jrt.String = jrt.Intern("`")

var Lit_168 *jrt.String = jrt.Intern("\r")

var Lit_169 *jrt.String = jrt.Intern("arbace.g2a.lit$string_text")

var Lit_170 *jrt.String = jrt.Intern("\"")

var Lit_171 *jrt.String = jrt.Intern("\\b")

var Lit_172 *jrt.String = jrt.Intern("\\t")

var Lit_173 *jrt.String = jrt.Intern("\\n")

var Lit_174 *jrt.String = jrt.Intern("\\f")

var Lit_175 *jrt.String = jrt.Intern("\\r")

var Lit_176 *jrt.String = jrt.Intern("\\\"")

var Lit_177 *jrt.String = jrt.Intern("\\\\")

var Lit_178 *jrt.String = jrt.Intern("arbace.g2a.lit$terminating_decimal")

var Lit_179 *jrt.String = jrt.Intern("arbace.g2a.lit$unescape")

var Lit_180 *jrt.String = jrt.Intern("arbace.g2a.lit$unescape$put_cp__1426000066")

var Lit_181 *jrt.String = jrt.Intern("arbace.g2a.lit$untyped_float_form")

var Lit_182 *jrt.String = jrt.Intern("arbace.g2a.lit$utf8_parts")

var Lit_183 *jrt.String = jrt.Intern("arbace.g2a.lit$val_rational")

var Lit_184 *jrt.String = jrt.Intern("not a numeric value: ")

var Lit_185 *jrt.String = jrt.Intern("text")

var Lit_186 *jrt.String = jrt.Intern("value")

var Lit_187 *jrt.String = jrt.Intern("class")

var Lit_188 *jrt.String = jrt.Intern("imap-cons")

var Lit_189 *jrt.String = jrt.Intern("concat")

var Lit_190 *jrt.String = jrt.Intern("identical?")

var Lit_191 *jrt.String = jrt.Intern("assoc")

var Lit_192 *jrt.String = jrt.Intern("dissoc")

var Lit_193 *jrt.String = jrt.Intern("not-empty")

var Lit_194 *jrt.String = jrt.Intern("with-meta")

var Lit_195 *jrt.String = jrt.Intern("vals")

var Lit_196 *jrt.String = jrt.Intern("set")

var Lit_197 *jrt.String = jrt.Intern("keys")

var Lit_198 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_199 *jrt.String = jrt.Intern("arbace.g2a.lit.Lit")

var Lit_200 *jrt.String = jrt.Intern("in-ns")

var Lit_201 *jrt.String = jrt.Intern("declared")

var Lit_202 *jrt.String = jrt.Intern("line")

var Lit_203 *jrt.String = jrt.Intern("column")

var Lit_204 *jrt.String = jrt.Intern("file")

var Lit_205 *jrt.String = jrt.Intern("arbace/g2a/lit.ae")

var Lit_206 *jrt.String = jrt.Intern("map->Lit")

var Lit_207 *jrt.String = jrt.Intern("arglists")

var Lit_208 *jrt.String = jrt.Intern("Positional factory function for class arbace.g2a.lit.Lit.")

var Lit_209 *jrt.String = jrt.Intern("m__231000174__auto__")

var Lit_210 *jrt.String = jrt.Intern("Factory function for class arbace.g2a.lit.Lit, taking a map of keywords to field values.")

var Lit_211 *jrt.String = jrt.Intern("lit?")

var Lit_212 *jrt.String = jrt.Intern("x")

var Lit_213 *jrt.String = jrt.Intern("newline")

var Lit_214 *jrt.String = jrt.Intern("space")

var Lit_215 *jrt.String = jrt.Intern("tab")

var Lit_216 *jrt.String = jrt.Intern("backspace")

var Lit_217 *jrt.String = jrt.Intern("formfeed")

var Lit_218 *jrt.String = jrt.Intern("return")

var Lit_219 *jrt.String = jrt.Intern("private")

var Lit_220 *jrt.String = jrt.Intern("cp")

var Lit_221 *jrt.String = jrt.Intern("Whether the code point prints as itself in Clojure text.")

var Lit_222 *jrt.String = jrt.Intern("s")

var Lit_223 *jrt.String = jrt.Intern("tag")

var Lit_224 *jrt.String = jrt.Intern("String")

var Lit_225 *jrt.String = jrt.Intern("The Clojure string literal text of s.")

var Lit_226 *jrt.String = jrt.Intern("Clojure character literal text for the BMP code point cp (not a surrogate).")

var Lit_227 *jrt.String = jrt.Intern("A Go integer literal's text as a Lit: the radix kept where Clojure has it (0x, 0 octal,\n  2r for binary), underscores dropped.")

var Lit_228 *jrt.String = jrt.Intern("Decimal text of an integer value (long or BigInt), as the reader reads it back.")

var Lit_229 *jrt.String = jrt.Intern("num")

var Lit_230 *jrt.String = jrt.Intern("BigInteger")

var Lit_231 *jrt.String = jrt.Intern("den")

var Lit_232 *jrt.String = jrt.Intern("An exact rational (Long, BigInt, Ratio) from num/den BigIntegers.")

var Lit_233 *jrt.String = jrt.Intern("n")

var Lit_234 *jrt.String = jrt.Intern("d")

var Lit_235 *jrt.String = jrt.Intern("k when the odd number d is 5^k, else nil.")

var Lit_236 *jrt.String = jrt.Intern("r")

var Lit_237 *jrt.String = jrt.Intern("Above this length a non-integral value with a terminating expansion is written as a\n  ratio, which is then shorter.")

var Lit_238 *jrt.String = jrt.Intern("The exact BigDecimal of num/den when den has only the prime factors 2 and 5, else nil.")

var Lit_239 *jrt.String = jrt.Intern("Double/toString of the value's nearest double when that text denotes exactly the value\n  (a BigDecimal or an exact rational), else nil.")

var Lit_240 *jrt.String = jrt.Intern("bd")

var Lit_241 *jrt.String = jrt.Intern("BigDecimal")

var Lit_242 *jrt.String = jrt.Intern("The text of BigDecimal bd as a float literal: stripped, with a decimal point or exponent.")

var Lit_243 *jrt.String = jrt.Intern("An exact value v (a BigDecimal, or a rational: Long, BigInt, Ratio) as a float-kind\n  Clojure literal (§8.1): a double when its shortest text denotes v exactly, else a\n  BigDecimal (M) when v has a terminating decimal expansion of reasonable length (always when\n  v is an integer), else a ratio. opts :prefer-ratio (hex floats): a ratio unless v is an\n  integer.")

var Lit_244 *jrt.String = jrt.Intern("A typed float value (float32/float64, already rounded): always a double (§8.2).")

var Lit_245 *jrt.String = jrt.Intern("t")

var Lit_246 *jrt.String = jrt.Intern("The exact value of a Go hexadecimal float literal (underscores removed): 0xH.Hp±E.")

var Lit_247 *jrt.String = jrt.Intern("The exact value of a Go float literal's text: a BigDecimal, or a rational for a\n  hexadecimal float.")

var Lit_248 *jrt.String = jrt.Intern("A Go float literal's text as a Lit (§8.1): hexadecimal floats exact as a ratio (or a\n  BigDecimal when integral).")

var Lit_249 *jrt.String = jrt.Intern("imag-inner")

var Lit_250 *jrt.String = jrt.Intern("The literal inside (imaginary x) for a Go imaginary literal's text: an integer for an\n  integer literal (decimal digits are decimal even with a leading 0), else a float.")

var Lit_251 *jrt.String = jrt.Intern("body")

var Lit_252 *jrt.String = jrt.Intern("Decodes the Go escapes of a literal's body into bytes (a ByteArrayOutputStream).")

var Lit_253 *jrt.String = jrt.Intern("string-bytes")

var Lit_254 *jrt.String = jrt.Intern("The bytes of a Go string literal's source text (interpreted or raw).")

var Lit_255 *jrt.String = jrt.Intern("rune-value")

var Lit_256 *jrt.String = jrt.Intern("The code point of a Go rune literal's source text.")

var Lit_257 *jrt.String = jrt.Intern("bs")

var Lit_258 *jrt.String = jrt.Intern("i")

var Lit_259 *jrt.String = jrt.Intern("Go's utf8.DecodeRune on bs at i: [rune width], rune -1 when invalid (width 1).")

var Lit_260 *jrt.String = jrt.Intern("Splits bytes into maximal valid UTF-8 runs (strings) and single invalid bytes (integers).")

var Lit_261 *jrt.String = jrt.Intern("A rune value (code point) as a character Lit, or (rune n) above the Basic Multilingual\n  Plane, in the surrogates or negative.")

var Lit_262 *jrt.String = jrt.Intern("Go string bytes as a string Lit, or (byte-string part ...) when not valid UTF-8.")

var Lit_263 *jrt.String = jrt.Intern("The exact rational of a helper value: an integer, (:float R) or (:float M E).")

var Lit_264 *jrt.String = jrt.Intern("An untyped float value of the helper: a float literal (§8.1), or (binary-float M E) for\n  M·2^E when go/types holds it as a big.Float beyond a rational's range (its decimal or ratio\n  would have up to hundreds of millions of digits: proposed amendment).")

var Lit_265 *jrt.String = jrt.Intern("const-form")

var Lit_266 *jrt.String = jrt.Intern("k")

var Lit_267 *jrt.String = jrt.Intern("The representation (§8.2) of the helper's exact value v at the constant kind k: :bool,\n  :string, :int, :rune, :float, :untyped-float, :complex, :untyped-complex (typed :float and\n  :complex are rounded doubles), or nil when the kind is not known (then v's own kind).")
