//line a2g_up.ae:1
package aot_arbace_g2a_lit

import "arbace/lang"


func Up_A_arbace_g2a_lit_Lit_A_IPersistentMap(p *A_arbace_g2a_lit_Lit_A) lang.IPersistentMap { if p == nil { return nil }; return p }

func Up_MapEntry_IMapEntry(p *lang.MapEntry) lang.IMapEntry { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Var_IFn(p *lang.Var) lang.IFn { if p == nil { return nil }; return p }
