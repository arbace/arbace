//line a2g_classes.ae:1
package aot_arbace_g2a_lit

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_A_New()}; return nil }

var A_arbace_g2a_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_lit_A_new}

var A_arbace_g2a_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_A"})

func init() { i := A_arbace_g2a_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_A_Init; i.Table = A_arbace_g2a_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_A]()) }

func A_arbace_g2a_lit_bytes_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_bytes_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_bytes_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_bytes_form_A_New()}; return nil }

func A_arbace_g2a_lit_bytes_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_bytes_form_A_fn_class)}; return nil }

var A_arbace_g2a_lit_bytes_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_bytes_form_A_invoke, New: A_arbace_g2a_lit_bytes_form_A_new, Get: A_arbace_g2a_lit_bytes_form_A_get}

var A_arbace_g2a_lit_bytes_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$bytes_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "bytes_form", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_bytes_form_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_bytes_form_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_bytes_form_A_InstanceOf; i.Init = A_arbace_g2a_lit_bytes_form_A_Init; i.Table = A_arbace_g2a_lit_bytes_form_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_bytes_form_A_class, reflect.TypeFor[A_arbace_g2a_lit_bytes_form_A]()) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_New()}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_fn_class)}; return nil }

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_invoke, New: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_new, Get: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_get}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$bytes_form$iter__1426000088__1426000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_bytes_form_A_class, Simple: "iter__1426000088__1426000092", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_InstanceOf; i.Init = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_Init; i.Table = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class, reflect.TypeFor[A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A]()) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_fn_class)}; return nil }

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_invoke, New: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_new, Get: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_get}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$bytes_form$iter__1426000088__1426000092$fn__1426000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class, Simple: "fn__1426000093", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_InstanceOf; i.Init = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_Init; i.Table = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class, reflect.TypeFor[A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A]()) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_fn_class)}; return nil }

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_invoke, New: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_new, Get: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_get}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$bytes_form$iter__1426000088__1426000092$fn__1426000093$fn__1426000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class, Simple: "fn__1426000094", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_InstanceOf; i.Init = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_Init; i.Table = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_class, reflect.TypeFor[A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A]()) }

func A_arbace_g2a_lit_char_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_char_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_char_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_char_text_A_New()}; return nil }

func A_arbace_g2a_lit_char_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_char_text_A_fn_class)}; return nil }

var A_arbace_g2a_lit_char_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_char_text_A_invoke, New: A_arbace_g2a_lit_char_text_A_new, Get: A_arbace_g2a_lit_char_text_A_get}

var A_arbace_g2a_lit_char_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$char_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "char_text", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_char_text_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_char_text_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_char_text_A_InstanceOf; i.Init = A_arbace_g2a_lit_char_text_A_Init; i.Table = A_arbace_g2a_lit_char_text_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_char_text_A_class, reflect.TypeFor[A_arbace_g2a_lit_char_text_A]()) }

func A_arbace_g2a_lit_const_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_const_form_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_const_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_const_form_A_New()}; return nil }

func A_arbace_g2a_lit_const_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_const_form_A_fn_class)}; return nil }

var A_arbace_g2a_lit_const_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_const_form_A_invoke, New: A_arbace_g2a_lit_const_form_A_new, Get: A_arbace_g2a_lit_const_form_A_get}

var A_arbace_g2a_lit_const_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$const_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "const_form", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_const_form_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_const_form_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_const_form_A_InstanceOf; i.Init = A_arbace_g2a_lit_const_form_A_Init; i.Table = A_arbace_g2a_lit_const_form_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_const_form_A_class, reflect.TypeFor[A_arbace_g2a_lit_const_form_A]()) }

func A_arbace_g2a_lit_decimal_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_decimal_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_decimal_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_decimal_text_A_New()}; return nil }

func A_arbace_g2a_lit_decimal_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_decimal_text_A_fn_class)}; return nil }

var A_arbace_g2a_lit_decimal_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_decimal_text_A_invoke, New: A_arbace_g2a_lit_decimal_text_A_new, Get: A_arbace_g2a_lit_decimal_text_A_get}

var A_arbace_g2a_lit_decimal_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$decimal_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "decimal_text", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_decimal_text_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_decimal_text_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_decimal_text_A_InstanceOf; i.Init = A_arbace_g2a_lit_decimal_text_A_Init; i.Table = A_arbace_g2a_lit_decimal_text_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_decimal_text_A_class, reflect.TypeFor[A_arbace_g2a_lit_decimal_text_A]()) }

func A_arbace_g2a_lit_decode_rune_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_decode_rune_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_lit_decode_rune_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_decode_rune_A_New()}; return nil }

func A_arbace_g2a_lit_decode_rune_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_decode_rune_A_fn_class)}; return nil }

var A_arbace_g2a_lit_decode_rune_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_decode_rune_A_invoke, New: A_arbace_g2a_lit_decode_rune_A_new, Get: A_arbace_g2a_lit_decode_rune_A_get}

var A_arbace_g2a_lit_decode_rune_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$decode_rune", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "decode_rune", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_decode_rune_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_decode_rune_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_decode_rune_A_InstanceOf; i.Init = A_arbace_g2a_lit_decode_rune_A_Init; i.Table = A_arbace_g2a_lit_decode_rune_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_decode_rune_A_class, reflect.TypeFor[A_arbace_g2a_lit_decode_rune_A]()) }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_decode_rune_b__1426000073_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_decode_rune_b__1426000073_A_New_O(args[0])}; return nil }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_decode_rune_b__1426000073_A_fn_class)}; return nil }

var A_arbace_g2a_lit_decode_rune_b__1426000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_decode_rune_b__1426000073_A_invoke, New: A_arbace_g2a_lit_decode_rune_b__1426000073_A_new, Get: A_arbace_g2a_lit_decode_rune_b__1426000073_A_get}

var A_arbace_g2a_lit_decode_rune_b__1426000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$decode_rune$b__1426000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_decode_rune_A_class, Simple: "b__1426000073", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_decode_rune_b__1426000073_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_decode_rune_b__1426000073_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_decode_rune_b__1426000073_A_InstanceOf; i.Init = A_arbace_g2a_lit_decode_rune_b__1426000073_A_Init; i.Table = A_arbace_g2a_lit_decode_rune_b__1426000073_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_decode_rune_b__1426000073_A_class, reflect.TypeFor[A_arbace_g2a_lit_decode_rune_b__1426000073_A]()) }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_fn_class)}; return nil }

var A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_invoke, New: A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_new, Get: A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_get}

var A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$decode_rune$cont_QMARK___1426000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_decode_rune_A_class, Simple: "cont_QMARK___1426000075", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_InstanceOf; i.Init = A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_Init; i.Table = A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_class, reflect.TypeFor[A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A]()) }

func A_arbace_g2a_lit_double_exact_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_double_exact_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_double_exact_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_double_exact_text_A_New()}; return nil }

func A_arbace_g2a_lit_double_exact_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_double_exact_text_A_fn_class)}; return nil }

var A_arbace_g2a_lit_double_exact_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_double_exact_text_A_invoke, New: A_arbace_g2a_lit_double_exact_text_A_new, Get: A_arbace_g2a_lit_double_exact_text_A_get}

var A_arbace_g2a_lit_double_exact_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$double_exact_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "double_exact_text", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_double_exact_text_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_double_exact_text_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_double_exact_text_A_InstanceOf; i.Init = A_arbace_g2a_lit_double_exact_text_A_Init; i.Table = A_arbace_g2a_lit_double_exact_text_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_double_exact_text_A_class, reflect.TypeFor[A_arbace_g2a_lit_double_exact_text_A]()) }

func A_arbace_g2a_lit_double_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_double_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_double_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_double_lit_A_New()}; return nil }

func A_arbace_g2a_lit_double_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_double_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_double_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_double_lit_A_invoke, New: A_arbace_g2a_lit_double_lit_A_new, Get: A_arbace_g2a_lit_double_lit_A_get}

var A_arbace_g2a_lit_double_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$double_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "double_lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_double_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_double_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_double_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_double_lit_A_Init; i.Table = A_arbace_g2a_lit_double_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_double_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_double_lit_A]()) }

func A_arbace_g2a_lit_eval1426000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000004_A_New()}; return nil }

var A_arbace_g2a_lit_eval1426000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_lit_eval1426000004_A_new}

var A_arbace_g2a_lit_eval1426000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_lit_A_class, Simple: "eval1426000004", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000004_A"})

func init() { i := A_arbace_g2a_lit_eval1426000004_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000004_A_InstanceOf; i.Table = A_arbace_g2a_lit_eval1426000004_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000004_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000004_A]()) }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_New()}; return nil }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_fn_class)}; return nil }

var A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_invoke, New: A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_new, Get: A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_get}

var A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000004$loading__1927001464__auto____1426000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_lit_eval1426000004_A_class, Simple: "loading__1927001464__auto____1426000005", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_InstanceOf; i.Init = A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_Init; i.Table = A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A]()) }

func A_arbace_g2a_lit_eval1426000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000008_A_New()}; return nil }

var A_arbace_g2a_lit_eval1426000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_lit_eval1426000008_A_new}

var A_arbace_g2a_lit_eval1426000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_lit_A_class, Simple: "eval1426000008", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000008_A"})

func init() { i := A_arbace_g2a_lit_eval1426000008_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000008_A_InstanceOf; i.Table = A_arbace_g2a_lit_eval1426000008_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000008_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000008_A]()) }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_eval1426000008_fn__1426000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_New()}; return nil }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_fn_class)}; return nil }

var A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_invoke, New: A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_new, Get: A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_get}

var A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000008$fn__1426000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_lit_eval1426000008_A_class, Simple: "fn__1426000009", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000008_fn__1426000009_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_InstanceOf; i.Init = A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_Init; i.Table = A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000008_fn__1426000009_A]()) }

func A_arbace_g2a_lit_eval1426000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000013_A_New()}; return nil }

var A_arbace_g2a_lit_eval1426000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_lit_eval1426000013_A_new}

var A_arbace_g2a_lit_eval1426000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_lit_A_class, Simple: "eval1426000013", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000013_A"})

func init() { i := A_arbace_g2a_lit_eval1426000013_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000013_A_InstanceOf; i.Table = A_arbace_g2a_lit_eval1426000013_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000013_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000013_A]()) }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_New()}; return nil }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_fn_class)}; return nil }

var A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_invoke, New: A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_new, Get: A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_get}

var A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000013$__GT_Lit__1426000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_lit_eval1426000013_A_class, Simple: "__GT_Lit__1426000023", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_InstanceOf; i.Init = A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_Init; i.Table = A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A]()) }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_New()}; return nil }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_fn_class)}; return nil }

var A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_invoke, New: A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_new, Get: A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_get}

var A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$eval1426000013$map__GT_Lit__1426000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_eval1426000013_A_class, Simple: "map__GT_Lit__1426000025", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_InstanceOf; i.Init = A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_Init; i.Table = A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_class, reflect.TypeFor[A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A]()) }

func A_arbace_g2a_lit_float_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_float_lit_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_g2a_lit_float_lit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_float_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_float_lit_A_New()}; return nil }

func A_arbace_g2a_lit_float_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_float_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_float_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_float_lit_A_invoke, New: A_arbace_g2a_lit_float_lit_A_new, Get: A_arbace_g2a_lit_float_lit_A_get}

var A_arbace_g2a_lit_float_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$float_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "float_lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_float_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_float_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_float_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_float_lit_A_Init; i.Table = A_arbace_g2a_lit_float_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_float_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_float_lit_A]()) }

func A_arbace_g2a_lit_float_text_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_float_text_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_float_text_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_float_text_lit_A_New()}; return nil }

func A_arbace_g2a_lit_float_text_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_float_text_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_float_text_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_float_text_lit_A_invoke, New: A_arbace_g2a_lit_float_text_lit_A_new, Get: A_arbace_g2a_lit_float_text_lit_A_get}

var A_arbace_g2a_lit_float_text_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$float_text_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "float_text_lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_float_text_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_float_text_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_float_text_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_float_text_lit_A_Init; i.Table = A_arbace_g2a_lit_float_text_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_float_text_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_float_text_lit_A]()) }

func A_arbace_g2a_lit_float_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_float_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_float_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_float_value_A_New()}; return nil }

func A_arbace_g2a_lit_float_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_float_value_A_fn_class)}; return nil }

var A_arbace_g2a_lit_float_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_float_value_A_invoke, New: A_arbace_g2a_lit_float_value_A_new, Get: A_arbace_g2a_lit_float_value_A_get}

var A_arbace_g2a_lit_float_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$float_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "float_value", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_float_value_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_float_value_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_float_value_A_InstanceOf; i.Init = A_arbace_g2a_lit_float_value_A_Init; i.Table = A_arbace_g2a_lit_float_value_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_float_value_A_class, reflect.TypeFor[A_arbace_g2a_lit_float_value_A]()) }

func A_arbace_g2a_lit_hex_float_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_hex_float_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_hex_float_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_hex_float_value_A_New()}; return nil }

func A_arbace_g2a_lit_hex_float_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_hex_float_value_A_fn_class)}; return nil }

var A_arbace_g2a_lit_hex_float_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_hex_float_value_A_invoke, New: A_arbace_g2a_lit_hex_float_value_A_new, Get: A_arbace_g2a_lit_hex_float_value_A_get}

var A_arbace_g2a_lit_hex_float_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$hex_float_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "hex_float_value", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_hex_float_value_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_hex_float_value_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_hex_float_value_A_InstanceOf; i.Init = A_arbace_g2a_lit_hex_float_value_A_Init; i.Table = A_arbace_g2a_lit_hex_float_value_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_hex_float_value_A_class, reflect.TypeFor[A_arbace_g2a_lit_hex_float_value_A]()) }

func A_arbace_g2a_lit_hexv_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_hexv_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_hexv_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_hexv_A_New()}; return nil }

func A_arbace_g2a_lit_hexv_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_hexv_A_fn_class)}; return nil }

var A_arbace_g2a_lit_hexv_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_hexv_A_invoke, New: A_arbace_g2a_lit_hexv_A_new, Get: A_arbace_g2a_lit_hexv_A_get}

var A_arbace_g2a_lit_hexv_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$hexv", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "hexv", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_hexv_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_hexv_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_hexv_A_InstanceOf; i.Init = A_arbace_g2a_lit_hexv_A_Init; i.Table = A_arbace_g2a_lit_hexv_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_hexv_A_class, reflect.TypeFor[A_arbace_g2a_lit_hexv_A]()) }

func A_arbace_g2a_lit_imag_inner_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_imag_inner_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_imag_inner_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_imag_inner_A_New()}; return nil }

func A_arbace_g2a_lit_imag_inner_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_imag_inner_A_fn_class)}; return nil }

var A_arbace_g2a_lit_imag_inner_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_imag_inner_A_invoke, New: A_arbace_g2a_lit_imag_inner_A_new, Get: A_arbace_g2a_lit_imag_inner_A_get}

var A_arbace_g2a_lit_imag_inner_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$imag_inner", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "imag_inner", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_imag_inner_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_imag_inner_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_imag_inner_A_InstanceOf; i.Init = A_arbace_g2a_lit_imag_inner_A_Init; i.Table = A_arbace_g2a_lit_imag_inner_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_imag_inner_A_class, reflect.TypeFor[A_arbace_g2a_lit_imag_inner_A]()) }

func A_arbace_g2a_lit_int_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_int_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_int_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_int_lit_A_New()}; return nil }

func A_arbace_g2a_lit_int_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_int_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_int_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_int_lit_A_invoke, New: A_arbace_g2a_lit_int_lit_A_new, Get: A_arbace_g2a_lit_int_lit_A_get}

var A_arbace_g2a_lit_int_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$int_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "int_lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_int_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_int_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_int_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_int_lit_A_Init; i.Table = A_arbace_g2a_lit_int_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_int_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_int_lit_A]()) }

func A_arbace_g2a_lit_integer_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_integer_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_integer_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_integer_lit_A_New()}; return nil }

func A_arbace_g2a_lit_integer_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_integer_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_integer_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_integer_lit_A_invoke, New: A_arbace_g2a_lit_integer_lit_A_new, Get: A_arbace_g2a_lit_integer_lit_A_get}

var A_arbace_g2a_lit_integer_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$integer_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "integer_lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_integer_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_integer_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_integer_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_integer_lit_A_Init; i.Table = A_arbace_g2a_lit_integer_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_integer_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_integer_lit_A]()) }

func A_arbace_g2a_lit_integer_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_integer_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_integer_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_integer_text_A_New()}; return nil }

func A_arbace_g2a_lit_integer_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_integer_text_A_fn_class)}; return nil }

var A_arbace_g2a_lit_integer_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_integer_text_A_invoke, New: A_arbace_g2a_lit_integer_text_A_new, Get: A_arbace_g2a_lit_integer_text_A_get}

var A_arbace_g2a_lit_integer_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$integer_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "integer_text", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_integer_text_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_integer_text_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_integer_text_A_InstanceOf; i.Init = A_arbace_g2a_lit_integer_text_A_Init; i.Table = A_arbace_g2a_lit_integer_text_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_integer_text_A_class, reflect.TypeFor[A_arbace_g2a_lit_integer_text_A]()) }

func A_arbace_g2a_lit_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_lit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_lit_A_New()}; return nil }

func A_arbace_g2a_lit_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_lit_A_fn_class)}; return nil }

var A_arbace_g2a_lit_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_lit_A_invoke, New: A_arbace_g2a_lit_lit_A_new, Get: A_arbace_g2a_lit_lit_A_get}

var A_arbace_g2a_lit_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "lit", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_lit_A_Init; i.Table = A_arbace_g2a_lit_lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_lit_A]()) }

func A_arbace_g2a_lit_lit_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_lit_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_lit_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_lit_QMARK__A_New()}; return nil }

func A_arbace_g2a_lit_lit_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_lit_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_lit_lit_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_lit_QMARK__A_invoke, New: A_arbace_g2a_lit_lit_QMARK__A_new, Get: A_arbace_g2a_lit_lit_QMARK__A_get}

var A_arbace_g2a_lit_lit_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$lit_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "lit_QMARK_", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_lit_QMARK__A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_lit_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_lit_lit_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_lit_lit_QMARK__A_Init; i.Table = A_arbace_g2a_lit_lit_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_lit_lit_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_lit_lit_QMARK__A]()) }

func A_arbace_g2a_lit_num_den_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_num_den_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_num_den_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_num_den_A_New()}; return nil }

func A_arbace_g2a_lit_num_den_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_num_den_A_fn_class)}; return nil }

var A_arbace_g2a_lit_num_den_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_num_den_A_invoke, New: A_arbace_g2a_lit_num_den_A_new, Get: A_arbace_g2a_lit_num_den_A_get}

var A_arbace_g2a_lit_num_den_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$num_den", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "num_den", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_num_den_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_num_den_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_num_den_A_InstanceOf; i.Init = A_arbace_g2a_lit_num_den_A_Init; i.Table = A_arbace_g2a_lit_num_den_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_num_den_A_class, reflect.TypeFor[A_arbace_g2a_lit_num_den_A]()) }

func A_arbace_g2a_lit_pow2_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_pow2_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_pow2_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_pow2_A_New()}; return nil }

func A_arbace_g2a_lit_pow2_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_pow2_A_fn_class)}; return nil }

var A_arbace_g2a_lit_pow2_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_pow2_A_invoke, New: A_arbace_g2a_lit_pow2_A_new, Get: A_arbace_g2a_lit_pow2_A_get}

var A_arbace_g2a_lit_pow2_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$pow2", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "pow2", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_pow2_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_pow2_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_pow2_A_InstanceOf; i.Init = A_arbace_g2a_lit_pow2_A_Init; i.Table = A_arbace_g2a_lit_pow2_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_pow2_A_class, reflect.TypeFor[A_arbace_g2a_lit_pow2_A]()) }

func A_arbace_g2a_lit_pow5_exponent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_pow5_exponent_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_pow5_exponent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_pow5_exponent_A_New()}; return nil }

func A_arbace_g2a_lit_pow5_exponent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_pow5_exponent_A_fn_class)}; return nil }

var A_arbace_g2a_lit_pow5_exponent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_pow5_exponent_A_invoke, New: A_arbace_g2a_lit_pow5_exponent_A_new, Get: A_arbace_g2a_lit_pow5_exponent_A_get}

var A_arbace_g2a_lit_pow5_exponent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$pow5_exponent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "pow5_exponent", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_pow5_exponent_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_pow5_exponent_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_pow5_exponent_A_InstanceOf; i.Init = A_arbace_g2a_lit_pow5_exponent_A_Init; i.Table = A_arbace_g2a_lit_pow5_exponent_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_pow5_exponent_A_class, reflect.TypeFor[A_arbace_g2a_lit_pow5_exponent_A]()) }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_fn_class)}; return nil }

var A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_invoke, New: A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_new, Get: A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_get}

var A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$pow5_exponent$fn__1426000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_pow5_exponent_A_class, Simple: "fn__1426000046", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_InstanceOf; i.Init = A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_Init; i.Table = A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_class, reflect.TypeFor[A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A]()) }

func A_arbace_g2a_lit_printable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_printable_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_printable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_printable_QMARK__A_New()}; return nil }

func A_arbace_g2a_lit_printable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_printable_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_lit_printable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_printable_QMARK__A_invoke, New: A_arbace_g2a_lit_printable_QMARK__A_new, Get: A_arbace_g2a_lit_printable_QMARK__A_get}

var A_arbace_g2a_lit_printable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$printable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "printable_QMARK_", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_printable_QMARK__A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_printable_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_lit_printable_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_lit_printable_QMARK__A_Init; i.Table = A_arbace_g2a_lit_printable_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_lit_printable_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_lit_printable_QMARK__A]()) }

func A_arbace_g2a_lit_rational_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_rational_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_rational_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_rational_A_New()}; return nil }

func A_arbace_g2a_lit_rational_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_rational_A_fn_class)}; return nil }

var A_arbace_g2a_lit_rational_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_rational_A_invoke, New: A_arbace_g2a_lit_rational_A_new, Get: A_arbace_g2a_lit_rational_A_get}

var A_arbace_g2a_lit_rational_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$rational", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "rational", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_rational_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_rational_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_rational_A_InstanceOf; i.Init = A_arbace_g2a_lit_rational_A_Init; i.Table = A_arbace_g2a_lit_rational_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_rational_A_class, reflect.TypeFor[A_arbace_g2a_lit_rational_A]()) }

func A_arbace_g2a_lit_rune_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_rune_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_rune_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_rune_form_A_New()}; return nil }

func A_arbace_g2a_lit_rune_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_rune_form_A_fn_class)}; return nil }

var A_arbace_g2a_lit_rune_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_rune_form_A_invoke, New: A_arbace_g2a_lit_rune_form_A_new, Get: A_arbace_g2a_lit_rune_form_A_get}

var A_arbace_g2a_lit_rune_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$rune_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "rune_form", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_rune_form_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_rune_form_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_rune_form_A_InstanceOf; i.Init = A_arbace_g2a_lit_rune_form_A_Init; i.Table = A_arbace_g2a_lit_rune_form_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_rune_form_A_class, reflect.TypeFor[A_arbace_g2a_lit_rune_form_A]()) }

func A_arbace_g2a_lit_rune_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_rune_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_rune_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_rune_value_A_New()}; return nil }

func A_arbace_g2a_lit_rune_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_rune_value_A_fn_class)}; return nil }

var A_arbace_g2a_lit_rune_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_rune_value_A_invoke, New: A_arbace_g2a_lit_rune_value_A_new, Get: A_arbace_g2a_lit_rune_value_A_get}

var A_arbace_g2a_lit_rune_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$rune_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "rune_value", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_rune_value_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_rune_value_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_rune_value_A_InstanceOf; i.Init = A_arbace_g2a_lit_rune_value_A_Init; i.Table = A_arbace_g2a_lit_rune_value_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_rune_value_A_class, reflect.TypeFor[A_arbace_g2a_lit_rune_value_A]()) }

func A_arbace_g2a_lit_string_bytes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_string_bytes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_string_bytes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_string_bytes_A_New()}; return nil }

func A_arbace_g2a_lit_string_bytes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_string_bytes_A_fn_class)}; return nil }

var A_arbace_g2a_lit_string_bytes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_string_bytes_A_invoke, New: A_arbace_g2a_lit_string_bytes_A_new, Get: A_arbace_g2a_lit_string_bytes_A_get}

var A_arbace_g2a_lit_string_bytes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$string_bytes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "string_bytes", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_string_bytes_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_string_bytes_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_string_bytes_A_InstanceOf; i.Init = A_arbace_g2a_lit_string_bytes_A_Init; i.Table = A_arbace_g2a_lit_string_bytes_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_string_bytes_A_class, reflect.TypeFor[A_arbace_g2a_lit_string_bytes_A]()) }

func A_arbace_g2a_lit_string_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_string_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_string_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_string_text_A_New()}; return nil }

func A_arbace_g2a_lit_string_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_string_text_A_fn_class)}; return nil }

var A_arbace_g2a_lit_string_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_string_text_A_invoke, New: A_arbace_g2a_lit_string_text_A_new, Get: A_arbace_g2a_lit_string_text_A_get}

var A_arbace_g2a_lit_string_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$string_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "string_text", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_string_text_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_string_text_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_string_text_A_InstanceOf; i.Init = A_arbace_g2a_lit_string_text_A_Init; i.Table = A_arbace_g2a_lit_string_text_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_string_text_A_class, reflect.TypeFor[A_arbace_g2a_lit_string_text_A]()) }

func A_arbace_g2a_lit_terminating_decimal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_terminating_decimal_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_lit_terminating_decimal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_terminating_decimal_A_New()}; return nil }

func A_arbace_g2a_lit_terminating_decimal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_terminating_decimal_A_fn_class)}; return nil }

var A_arbace_g2a_lit_terminating_decimal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_terminating_decimal_A_invoke, New: A_arbace_g2a_lit_terminating_decimal_A_new, Get: A_arbace_g2a_lit_terminating_decimal_A_get}

var A_arbace_g2a_lit_terminating_decimal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$terminating_decimal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "terminating_decimal", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_terminating_decimal_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_terminating_decimal_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_terminating_decimal_A_InstanceOf; i.Init = A_arbace_g2a_lit_terminating_decimal_A_Init; i.Table = A_arbace_g2a_lit_terminating_decimal_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_terminating_decimal_A_class, reflect.TypeFor[A_arbace_g2a_lit_terminating_decimal_A]()) }

func A_arbace_g2a_lit_unescape_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_unescape_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_unescape_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_unescape_A_New()}; return nil }

func A_arbace_g2a_lit_unescape_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_unescape_A_fn_class)}; return nil }

var A_arbace_g2a_lit_unescape_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_unescape_A_invoke, New: A_arbace_g2a_lit_unescape_A_new, Get: A_arbace_g2a_lit_unescape_A_get}

var A_arbace_g2a_lit_unescape_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$unescape", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "unescape", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_unescape_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_unescape_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_unescape_A_InstanceOf; i.Init = A_arbace_g2a_lit_unescape_A_Init; i.Table = A_arbace_g2a_lit_unescape_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_unescape_A_class, reflect.TypeFor[A_arbace_g2a_lit_unescape_A]()) }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_unescape_put_cp__1426000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_unescape_put_cp__1426000066_A_New_O(args[0])}; return nil }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_unescape_put_cp__1426000066_A_fn_class)}; return nil }

var A_arbace_g2a_lit_unescape_put_cp__1426000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_unescape_put_cp__1426000066_A_invoke, New: A_arbace_g2a_lit_unescape_put_cp__1426000066_A_new, Get: A_arbace_g2a_lit_unescape_put_cp__1426000066_A_get}

var A_arbace_g2a_lit_unescape_put_cp__1426000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$unescape$put_cp__1426000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_unescape_A_class, Simple: "put_cp__1426000066", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_unescape_put_cp__1426000066_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_unescape_put_cp__1426000066_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_unescape_put_cp__1426000066_A_InstanceOf; i.Init = A_arbace_g2a_lit_unescape_put_cp__1426000066_A_Init; i.Table = A_arbace_g2a_lit_unescape_put_cp__1426000066_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_unescape_put_cp__1426000066_A_class, reflect.TypeFor[A_arbace_g2a_lit_unescape_put_cp__1426000066_A]()) }

func A_arbace_g2a_lit_untyped_float_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_untyped_float_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_untyped_float_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_untyped_float_form_A_New()}; return nil }

func A_arbace_g2a_lit_untyped_float_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_untyped_float_form_A_fn_class)}; return nil }

var A_arbace_g2a_lit_untyped_float_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_untyped_float_form_A_invoke, New: A_arbace_g2a_lit_untyped_float_form_A_new, Get: A_arbace_g2a_lit_untyped_float_form_A_get}

var A_arbace_g2a_lit_untyped_float_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$untyped_float_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "untyped_float_form", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_untyped_float_form_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_untyped_float_form_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_untyped_float_form_A_InstanceOf; i.Init = A_arbace_g2a_lit_untyped_float_form_A_Init; i.Table = A_arbace_g2a_lit_untyped_float_form_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_untyped_float_form_A_class, reflect.TypeFor[A_arbace_g2a_lit_untyped_float_form_A]()) }

func A_arbace_g2a_lit_utf8_parts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_utf8_parts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_utf8_parts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_utf8_parts_A_New()}; return nil }

func A_arbace_g2a_lit_utf8_parts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_utf8_parts_A_fn_class)}; return nil }

var A_arbace_g2a_lit_utf8_parts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_utf8_parts_A_invoke, New: A_arbace_g2a_lit_utf8_parts_A_new, Get: A_arbace_g2a_lit_utf8_parts_A_get}

var A_arbace_g2a_lit_utf8_parts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$utf8_parts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "utf8_parts", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_utf8_parts_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_utf8_parts_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_utf8_parts_A_InstanceOf; i.Init = A_arbace_g2a_lit_utf8_parts_A_Init; i.Table = A_arbace_g2a_lit_utf8_parts_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_utf8_parts_A_class, reflect.TypeFor[A_arbace_g2a_lit_utf8_parts_A]()) }

func A_arbace_g2a_lit_val_rational_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_val_rational_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_lit_val_rational_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_val_rational_A_New()}; return nil }

func A_arbace_g2a_lit_val_rational_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_lit_val_rational_A_fn_class)}; return nil }

var A_arbace_g2a_lit_val_rational_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_lit_val_rational_A_invoke, New: A_arbace_g2a_lit_val_rational_A_new, Get: A_arbace_g2a_lit_val_rational_A_get}

var A_arbace_g2a_lit_val_rational_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit$val_rational", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_lit_A_class, Simple: "val_rational", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_val_rational_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_val_rational_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_val_rational_A_InstanceOf; i.Init = A_arbace_g2a_lit_val_rational_A_Init; i.Table = A_arbace_g2a_lit_val_rational_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_val_rational_A_class, reflect.TypeFor[A_arbace_g2a_lit_val_rational_A]()) }

func A_arbace_g2a_lit_Lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_Lit_A).Assoc_O_O__Associative(args[0], args[1]); case 1: return this.(*A_arbace_g2a_lit_Lit_A).Assoc_O_O__IPersistentMap(args[0], args[1]); case 2: this.(*A_arbace_g2a_lit_Lit_A).Clear__V(); return nil; case 3: return this.(*A_arbace_g2a_lit_Lit_A).Cons_O__IPersistentCollection(args[0]); case 4: return this.(*A_arbace_g2a_lit_Lit_A).ContainsKey_O__Z(args[0]); case 5: return this.(*A_arbace_g2a_lit_Lit_A).ContainsValue_O__Z(args[0]); case 6: return this.(*A_arbace_g2a_lit_Lit_A).Count__I(); case 7: return jrt.A2g_RefP(A_arbace_g2a_lit_Lit_A_Create_IPersistentMap__A_arbace_g2a_lit_Lit_A(jrt.As[lang.IPersistentMap](args[0]))); case 8: return this.(*A_arbace_g2a_lit_Lit_A).Empty__IPersistentCollection(); case 9: return this.(*A_arbace_g2a_lit_Lit_A).EntryAt_O__IMapEntry(args[0]); case 10: return this.(*A_arbace_g2a_lit_Lit_A).EntrySet__Set(); case 11: return this.(*A_arbace_g2a_lit_Lit_A).Equals_O__Z(args[0]); case 12: return this.(*A_arbace_g2a_lit_Lit_A).Equiv_O__Z(args[0]); case 13: return this.(*A_arbace_g2a_lit_Lit_A).Get_O__O(args[0]); case 14: return A_arbace_g2a_lit_Lit_A_GetBasis__IPersistentVector(); case 15: return this.(*A_arbace_g2a_lit_Lit_A).GetLookupThunk_Keyword__ILookupThunk(jrt.As[*lang.Keyword](args[0])); case 16: return this.(*A_arbace_g2a_lit_Lit_A).HashCode__I(); case 17: return this.(*A_arbace_g2a_lit_Lit_A).Hasheq__I(); case 18: return this.(*A_arbace_g2a_lit_Lit_A).IsEmpty__Z(); case 19: return this.(*A_arbace_g2a_lit_Lit_A).Iterator__Iterator(); case 20: return this.(*A_arbace_g2a_lit_Lit_A).KeySet__Set(); case 21: return this.(*A_arbace_g2a_lit_Lit_A).Meta__IPersistentMap(); case 22: return this.(*A_arbace_g2a_lit_Lit_A).Put_O_O__O(args[0], args[1]); case 23: this.(*A_arbace_g2a_lit_Lit_A).PutAll_Map__V(jrt.As[jrt.Map](args[0])); return nil; case 24: return this.(*A_arbace_g2a_lit_Lit_A).Remove_O__O(args[0]); case 25: return this.(*A_arbace_g2a_lit_Lit_A).Seq__ISeq(); case 26: return this.(*A_arbace_g2a_lit_Lit_A).Size__I(); case 27: return this.(*A_arbace_g2a_lit_Lit_A).ValAt_O__O(args[0]); case 28: return this.(*A_arbace_g2a_lit_Lit_A).ValAt_O_O__O(args[0], args[1]); case 29: return this.(*A_arbace_g2a_lit_Lit_A).Values__Collection(); case 30: return this.(*A_arbace_g2a_lit_Lit_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 31: return this.(*A_arbace_g2a_lit_Lit_A).Without_O__IPersistentMap(args[0])}; return nil }

func A_arbace_g2a_lit_Lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_Lit_A_New_O_O_O_O_I_I(args[0], args[1], args[2], args[3], args[4].(int32), args[5].(int32)); case 1: return A_arbace_g2a_lit_Lit_A_New_O_O(args[0], args[1]); case 2: return A_arbace_g2a_lit_Lit_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_lit_Lit_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_g2a_lit_Lit_A).F_text; case 1: return o.(*A_arbace_g2a_lit_Lit_A).F_value; case 2: return o.(*A_arbace_g2a_lit_Lit_A).F___meta; case 3: return o.(*A_arbace_g2a_lit_Lit_A).F___extmap}; return nil }

var A_arbace_g2a_lit_Lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M4161 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.Associative;\nM1 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nM1 clear ()V\nM1 cons (Ljava.lang.Object;)Larbace.lang.IPersistentCollection;\nM1 containsKey (Ljava.lang.Object;)Z\nM1 containsValue (Ljava.lang.Object;)Z\nM1 count ()I\nM9 create (Larbace.lang.IPersistentMap;)Larbace.g2a.lit.Lit;\nM1 empty ()Larbace.lang.IPersistentCollection;\nM1 entryAt (Ljava.lang.Object;)Larbace.lang.IMapEntry;\nM1 entrySet ()Ljava.util.Set;\nM1 equals (Ljava.lang.Object;)Z\nM1 equiv (Ljava.lang.Object;)Z\nM1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 getLookupThunk (Larbace.lang.Keyword;)Larbace.lang.ILookupThunk;\nM1 hashCode ()I\nM1 hasheq ()I\nM1 isEmpty ()Z\nM1 iterator ()Ljava.util.Iterator;\nM1 keySet ()Ljava.util.Set;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 put (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 putAll (Ljava.util.Map;)V\nM1 remove (Ljava.lang.Object;)Ljava.lang.Object;\nM1 seq ()Larbace.lang.ISeq;\nM1 size ()I\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 values ()Ljava.util.Collection;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 without (Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;II)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 text Ljava.lang.Object;\nG17 value Ljava.lang.Object;\nG17 __meta Ljava.lang.Object;\nG17 __extmap Ljava.lang.Object;", Invoke: A_arbace_g2a_lit_Lit_A_invoke, New: A_arbace_g2a_lit_Lit_A_new, Get: A_arbace_g2a_lit_Lit_A_get}

var A_arbace_g2a_lit_Lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit.Lit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IRecord_class, lang.IHashEq_class, lang.IObj_class, lang.ILookup_class, lang.IKeywordLookup_class, lang.IPersistentMap_class, jrt.Map_class, jrt.Serializable_class}, Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_Lit_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_Lit_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_Lit_A_InstanceOf; i.Init = A_arbace_g2a_lit_Lit_A_Init; i.Table = A_arbace_g2a_lit_Lit_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_Lit_A_class, reflect.TypeFor[A_arbace_g2a_lit_Lit_A]()) }

func A_arbace_g2a_lit_Lit_reify__1426000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_Lit_reify__1426000017_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_g2a_lit_Lit_reify__1426000017_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_g2a_lit_Lit_reify__1426000017_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_g2a_lit_Lit_reify__1426000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_Lit_reify__1426000017_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_g2a_lit_Lit_reify__1426000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_g2a_lit_Lit_reify__1426000017_A_invoke, New: A_arbace_g2a_lit_Lit_reify__1426000017_A_new}

var A_arbace_g2a_lit_Lit_reify__1426000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit.Lit$reify__1426000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_g2a_lit_Lit_A_class, Simple: "reify__1426000017", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_Lit_reify__1426000017_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_Lit_reify__1426000017_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_Lit_reify__1426000017_A_InstanceOf; i.Table = A_arbace_g2a_lit_Lit_reify__1426000017_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_Lit_reify__1426000017_A_class, reflect.TypeFor[A_arbace_g2a_lit_Lit_reify__1426000017_A]()) }

func A_arbace_g2a_lit_Lit_reify__1426000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_lit_Lit_reify__1426000019_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_g2a_lit_Lit_reify__1426000019_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_g2a_lit_Lit_reify__1426000019_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_g2a_lit_Lit_reify__1426000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit_Lit_reify__1426000019_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_g2a_lit_Lit_reify__1426000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_g2a_lit_Lit_reify__1426000019_A_invoke, New: A_arbace_g2a_lit_Lit_reify__1426000019_A_new}

var A_arbace_g2a_lit_Lit_reify__1426000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit.Lit$reify__1426000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_g2a_lit_Lit_A_class, Simple: "reify__1426000019", Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit_Lit_reify__1426000019_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit_Lit_reify__1426000019_A_class.Info(); i.IsInstance = A_arbace_g2a_lit_Lit_reify__1426000019_A_InstanceOf; i.Table = A_arbace_g2a_lit_Lit_reify__1426000019_A_members; jrt.RegisterGoType(A_arbace_g2a_lit_Lit_reify__1426000019_A_class, reflect.TypeFor[A_arbace_g2a_lit_Lit_reify__1426000019_A]()) }

func A_arbace_g2a_lit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_lit__init_A_Load__O(); case 1: return A_arbace_g2a_lit__init_A_Unit0__O(); case 2: return A_arbace_g2a_lit__init_A_Unit1__O(); case 3: return A_arbace_g2a_lit__init_A_Unit10__O(); case 4: return A_arbace_g2a_lit__init_A_Unit11__O(); case 5: return A_arbace_g2a_lit__init_A_Unit12__O(); case 6: return A_arbace_g2a_lit__init_A_Unit13__O(); case 7: return A_arbace_g2a_lit__init_A_Unit14__O(); case 8: return A_arbace_g2a_lit__init_A_Unit15__O(); case 9: return A_arbace_g2a_lit__init_A_Unit16__O(); case 10: return A_arbace_g2a_lit__init_A_Unit17__O(); case 11: return A_arbace_g2a_lit__init_A_Unit18__O(); case 12: return A_arbace_g2a_lit__init_A_Unit19__O(); case 13: return A_arbace_g2a_lit__init_A_Unit2__O(); case 14: return A_arbace_g2a_lit__init_A_Unit20__O(); case 15: return A_arbace_g2a_lit__init_A_Unit21__O(); case 16: return A_arbace_g2a_lit__init_A_Unit22__O(); case 17: return A_arbace_g2a_lit__init_A_Unit23__O(); case 18: return A_arbace_g2a_lit__init_A_Unit24__O(); case 19: return A_arbace_g2a_lit__init_A_Unit25__O(); case 20: return A_arbace_g2a_lit__init_A_Unit26__O(); case 21: return A_arbace_g2a_lit__init_A_Unit27__O(); case 22: return A_arbace_g2a_lit__init_A_Unit28__O(); case 23: return A_arbace_g2a_lit__init_A_Unit29__O(); case 24: return A_arbace_g2a_lit__init_A_Unit3__O(); case 25: return A_arbace_g2a_lit__init_A_Unit30__O(); case 26: return A_arbace_g2a_lit__init_A_Unit31__O(); case 27: return A_arbace_g2a_lit__init_A_Unit32__O(); case 28: return A_arbace_g2a_lit__init_A_Unit33__O(); case 29: return A_arbace_g2a_lit__init_A_Unit34__O(); case 30: return A_arbace_g2a_lit__init_A_Unit35__O(); case 31: return A_arbace_g2a_lit__init_A_Unit36__O(); case 32: return A_arbace_g2a_lit__init_A_Unit37__O(); case 33: return A_arbace_g2a_lit__init_A_Unit38__O(); case 34: return A_arbace_g2a_lit__init_A_Unit4__O(); case 35: return A_arbace_g2a_lit__init_A_Unit5__O(); case 36: return A_arbace_g2a_lit__init_A_Unit6__O(); case 37: return A_arbace_g2a_lit__init_A_Unit7__O(); case 38: return A_arbace_g2a_lit__init_A_Unit8__O(); case 39: return A_arbace_g2a_lit__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_lit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_lit__init_A_New()}; return nil }

var A_arbace_g2a_lit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_lit__init_A_invoke, New: A_arbace_g2a_lit__init_A_new}

var A_arbace_g2a_lit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.lit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_lit.A_arbace_g2a_lit__init_A", Source: "lit.ae"})

func init() { i := A_arbace_g2a_lit__init_A_class.Info(); i.IsInstance = A_arbace_g2a_lit__init_A_InstanceOf; i.Init = A_arbace_g2a_lit__init_A_Init; i.Table = A_arbace_g2a_lit__init_A_members; jrt.RegisterGoType(A_arbace_g2a_lit__init_A_class, reflect.TypeFor[A_arbace_g2a_lit__init_A]()) }
