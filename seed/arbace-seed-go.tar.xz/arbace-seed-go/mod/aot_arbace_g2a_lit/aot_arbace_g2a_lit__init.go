//line aot_arbace_g2a_lit__init.ae:1
package aot_arbace_g2a_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_lit__init_A_Unit0__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_lit__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_lit__init_A_const_1) }
//line :1:1
func A_arbace_g2a_lit__init_A_Unit1__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_lit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_lit__init_A_Unit2__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_Init(); tmp2 = A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_lit__init_A_Unit3__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_lit__init_A_const_1)).Equals_O__Z(A_arbace_g2a_lit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_Init(); tmp2 = A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_lit__init_A_Load__O() any { A_arbace_g2a_lit__init_A_Init(); A_arbace_g2a_lit__init_A_Unit0__O(); A_arbace_g2a_lit__init_A_Unit1__O(); A_arbace_g2a_lit__init_A_Unit2__O(); A_arbace_g2a_lit__init_A_Unit3__O(); A_arbace_g2a_lit__init_A_Unit4__O(); A_arbace_g2a_lit__init_A_Unit5__O(); A_arbace_g2a_lit__init_A_Unit6__O(); A_arbace_g2a_lit__init_A_Unit7__O(); A_arbace_g2a_lit__init_A_Unit8__O(); A_arbace_g2a_lit__init_A_Unit9__O(); A_arbace_g2a_lit__init_A_Unit10__O(); A_arbace_g2a_lit__init_A_Unit11__O(); A_arbace_g2a_lit__init_A_Unit12__O(); A_arbace_g2a_lit__init_A_Unit13__O(); A_arbace_g2a_lit__init_A_Unit14__O(); A_arbace_g2a_lit__init_A_Unit15__O(); A_arbace_g2a_lit__init_A_Unit16__O(); A_arbace_g2a_lit__init_A_Unit17__O(); A_arbace_g2a_lit__init_A_Unit18__O(); A_arbace_g2a_lit__init_A_Unit19__O(); A_arbace_g2a_lit__init_A_Unit20__O(); A_arbace_g2a_lit__init_A_Unit21__O(); A_arbace_g2a_lit__init_A_Unit22__O(); A_arbace_g2a_lit__init_A_Unit23__O(); A_arbace_g2a_lit__init_A_Unit24__O(); A_arbace_g2a_lit__init_A_Unit25__O(); A_arbace_g2a_lit__init_A_Unit26__O(); A_arbace_g2a_lit__init_A_Unit27__O(); A_arbace_g2a_lit__init_A_Unit28__O(); A_arbace_g2a_lit__init_A_Unit29__O(); A_arbace_g2a_lit__init_A_Unit30__O(); A_arbace_g2a_lit__init_A_Unit31__O(); A_arbace_g2a_lit__init_A_Unit32__O(); A_arbace_g2a_lit__init_A_Unit33__O(); A_arbace_g2a_lit__init_A_Unit34__O(); A_arbace_g2a_lit__init_A_Unit35__O(); A_arbace_g2a_lit__init_A_Unit36__O(); A_arbace_g2a_lit__init_A_Unit37__O(); A_arbace_g2a_lit__init_A_Unit38__O(); return nil }







func A_arbace_g2a_lit__init_A_Unit4__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_5; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_6)); var tmp2 *lang.Var = A_arbace_g2a_lit__init_A_const_7; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_8)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_199)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_5; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_9)); var tmp5 *lang.Var = A_arbace_g2a_lit__init_A_const_5; var tmp6 any = A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_New(); var tmp7 *jrt.Class; A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_Init(); tmp7 = A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_fn_class; jrt.NN(tmp5).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_g2a_lit__init_A_const_7; jrt.NN(tmp8).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_10)); var tmp9 *lang.Var = A_arbace_g2a_lit__init_A_const_7; var tmp10 any = A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_New(); var tmp11 *jrt.Class; A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_Init(); tmp11 = A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_fn_class; jrt.NN(tmp9).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_g2a_lit__init_A_const_4.Ref() }

func A_arbace_g2a_lit__init_A_Unit5__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_11; var tmp2 any = A_arbace_g2a_lit_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_lit_A_Init(); tmp3 = A_arbace_g2a_lit_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_12)); return A_arbace_g2a_lit__init_A_const_11.Ref() }

func A_arbace_g2a_lit__init_A_Unit6__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_13; var tmp2 any = A_arbace_g2a_lit_lit_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_lit_QMARK__A_Init(); tmp3 = A_arbace_g2a_lit_lit_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_14)); return A_arbace_g2a_lit__init_A_const_13.Ref() }



func A_arbace_g2a_lit__init_A_Unit7__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); jrt.NN(A_arbace_g2a_lit__init_A_const_15).BindRoot_O__V(A_arbace_g2a_lit__init_A_const_16); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_15; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_17)); return A_arbace_g2a_lit__init_A_const_15.Ref() }



func A_arbace_g2a_lit__init_A_Unit8__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_18; var tmp2 any = A_arbace_g2a_lit_printable_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_printable_QMARK__A_Init(); tmp3 = A_arbace_g2a_lit_printable_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_19)); return A_arbace_g2a_lit__init_A_const_18.Ref() }













func A_arbace_g2a_lit__init_A_Unit9__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_20; var tmp2 any = A_arbace_g2a_lit_string_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_string_text_A_Init(); tmp3 = A_arbace_g2a_lit_string_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_21)); return A_arbace_g2a_lit__init_A_const_20.Ref() }























func A_arbace_g2a_lit__init_A_Unit10__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_22; var tmp2 any = A_arbace_g2a_lit_char_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_char_text_A_Init(); tmp3 = A_arbace_g2a_lit_char_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_23)); return A_arbace_g2a_lit__init_A_const_22.Ref() }










func A_arbace_g2a_lit__init_A_Unit11__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_24; var tmp2 any = A_arbace_g2a_lit_int_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_int_lit_A_Init(); tmp3 = A_arbace_g2a_lit_int_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_25)); return A_arbace_g2a_lit__init_A_const_24.Ref() }















func A_arbace_g2a_lit__init_A_Unit12__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_26; var tmp2 any = A_arbace_g2a_lit_integer_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_integer_text_A_Init(); tmp3 = A_arbace_g2a_lit_integer_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_27)); return A_arbace_g2a_lit__init_A_const_26.Ref() }





func A_arbace_g2a_lit__init_A_Unit13__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_28; var tmp2 any = A_arbace_g2a_lit_integer_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_integer_lit_A_Init(); tmp3 = A_arbace_g2a_lit_integer_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_29)); return A_arbace_g2a_lit__init_A_const_28.Ref() }





func A_arbace_g2a_lit__init_A_Unit14__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_30; var tmp2 any = A_arbace_g2a_lit_rational_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_rational_A_Init(); tmp3 = A_arbace_g2a_lit_rational_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_31)); return A_arbace_g2a_lit__init_A_const_30.Ref() }




func A_arbace_g2a_lit__init_A_Unit15__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_32; var tmp2 any = A_arbace_g2a_lit_pow2_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_pow2_A_Init(); tmp3 = A_arbace_g2a_lit_pow2_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_33)); return A_arbace_g2a_lit__init_A_const_32.Ref() }

func A_arbace_g2a_lit__init_A_Unit16__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_34; var tmp2 any = A_arbace_g2a_lit_pow5_exponent_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_pow5_exponent_A_Init(); tmp3 = A_arbace_g2a_lit_pow5_exponent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_35)); return A_arbace_g2a_lit__init_A_const_34.Ref() }







func A_arbace_g2a_lit__init_A_Unit17__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_36; var tmp2 any = A_arbace_g2a_lit_num_den_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_num_den_A_Init(); tmp3 = A_arbace_g2a_lit_num_den_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_37)); return A_arbace_g2a_lit__init_A_const_36.Ref() }




func A_arbace_g2a_lit__init_A_Unit18__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); jrt.NN(A_arbace_g2a_lit__init_A_const_38).BindRoot_O__V(A_arbace_g2a_lit__init_A_const_39); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_38; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_40)); return A_arbace_g2a_lit__init_A_const_38.Ref() }




func A_arbace_g2a_lit__init_A_Unit19__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_41; var tmp2 any = A_arbace_g2a_lit_terminating_decimal_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_terminating_decimal_A_Init(); tmp3 = A_arbace_g2a_lit_terminating_decimal_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_42)); return A_arbace_g2a_lit__init_A_const_41.Ref() }











func A_arbace_g2a_lit__init_A_Unit20__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_43; var tmp2 any = A_arbace_g2a_lit_double_exact_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_double_exact_text_A_Init(); tmp3 = A_arbace_g2a_lit_double_exact_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_44)); return A_arbace_g2a_lit__init_A_const_43.Ref() }












func A_arbace_g2a_lit__init_A_Unit21__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_45; var tmp2 any = A_arbace_g2a_lit_decimal_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_decimal_text_A_Init(); tmp3 = A_arbace_g2a_lit_decimal_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_46)); return A_arbace_g2a_lit__init_A_const_45.Ref() }





func A_arbace_g2a_lit__init_A_Unit22__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_47; var tmp2 any = A_arbace_g2a_lit_float_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_float_lit_A_Init(); tmp3 = A_arbace_g2a_lit_float_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_48)); return A_arbace_g2a_lit__init_A_const_47.Ref() }


















func A_arbace_g2a_lit__init_A_Unit23__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(177, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_49; var tmp2 any = A_arbace_g2a_lit_double_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_double_lit_A_Init(); tmp3 = A_arbace_g2a_lit_double_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_50)); return A_arbace_g2a_lit__init_A_const_49.Ref() }








func A_arbace_g2a_lit__init_A_Unit24__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(186, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_51; var tmp2 any = A_arbace_g2a_lit_hex_float_value_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_hex_float_value_A_Init(); tmp3 = A_arbace_g2a_lit_hex_float_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_52)); return A_arbace_g2a_lit__init_A_const_51.Ref() }
















func A_arbace_g2a_lit__init_A_Unit25__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(203, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_53; var tmp2 any = A_arbace_g2a_lit_float_value_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_float_value_A_Init(); tmp3 = A_arbace_g2a_lit_float_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_54)); return A_arbace_g2a_lit__init_A_const_53.Ref() }








func A_arbace_g2a_lit__init_A_Unit26__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(212, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_55; var tmp2 any = A_arbace_g2a_lit_float_text_lit_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_float_text_lit_A_Init(); tmp3 = A_arbace_g2a_lit_float_text_lit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_56)); return A_arbace_g2a_lit__init_A_const_55.Ref() }






func A_arbace_g2a_lit__init_A_Unit27__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_57; var tmp2 any = A_arbace_g2a_lit_imag_inner_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_imag_inner_A_Init(); tmp3 = A_arbace_g2a_lit_imag_inner_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_58)); return A_arbace_g2a_lit__init_A_const_57.Ref() }















func A_arbace_g2a_lit__init_A_Unit28__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(235, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_59; var tmp2 any = A_arbace_g2a_lit_hexv_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_hexv_A_Init(); tmp3 = A_arbace_g2a_lit_hexv_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_60)); return A_arbace_g2a_lit__init_A_const_59.Ref() }

func A_arbace_g2a_lit__init_A_Unit29__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(237, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_61; var tmp2 any = A_arbace_g2a_lit_unescape_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_unescape_A_Init(); tmp3 = A_arbace_g2a_lit_unescape_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_62)); return A_arbace_g2a_lit__init_A_const_61.Ref() }

































func A_arbace_g2a_lit__init_A_Unit30__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(271, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_63; var tmp2 any = A_arbace_g2a_lit_string_bytes_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_string_bytes_A_Init(); tmp3 = A_arbace_g2a_lit_string_bytes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_64)); return A_arbace_g2a_lit__init_A_const_63.Ref() }






func A_arbace_g2a_lit__init_A_Unit31__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_65; var tmp2 any = A_arbace_g2a_lit_rune_value_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_rune_value_A_Init(); tmp3 = A_arbace_g2a_lit_rune_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_65; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_66)); return A_arbace_g2a_lit__init_A_const_65.Ref() }













func A_arbace_g2a_lit__init_A_Unit32__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_67; var tmp2 any = A_arbace_g2a_lit_decode_rune_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_decode_rune_A_Init(); tmp3 = A_arbace_g2a_lit_decode_rune_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_67; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_68)); return A_arbace_g2a_lit__init_A_const_67.Ref() }




























func A_arbace_g2a_lit__init_A_Unit33__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(321, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_69; var tmp2 any = A_arbace_g2a_lit_utf8_parts_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_utf8_parts_A_Init(); tmp3 = A_arbace_g2a_lit_utf8_parts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_70)); return A_arbace_g2a_lit__init_A_const_69.Ref() }














func A_arbace_g2a_lit__init_A_Unit34__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(336, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_71; var tmp2 any = A_arbace_g2a_lit_rune_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_rune_form_A_Init(); tmp3 = A_arbace_g2a_lit_rune_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_71; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_72)); return A_arbace_g2a_lit__init_A_const_71.Ref() }








func A_arbace_g2a_lit__init_A_Unit35__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(345, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_73; var tmp2 any = A_arbace_g2a_lit_bytes_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_bytes_form_A_Init(); tmp3 = A_arbace_g2a_lit_bytes_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_73; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_74)); return A_arbace_g2a_lit__init_A_const_73.Ref() }











func A_arbace_g2a_lit__init_A_Unit36__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(357, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_75; var tmp2 any = A_arbace_g2a_lit_val_rational_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_val_rational_A_Init(); tmp3 = A_arbace_g2a_lit_val_rational_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_75; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_76)); return A_arbace_g2a_lit__init_A_const_75.Ref() }












func A_arbace_g2a_lit__init_A_Unit37__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(370, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_77; var tmp2 any = A_arbace_g2a_lit_untyped_float_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_untyped_float_form_A_Init(); tmp3 = A_arbace_g2a_lit_untyped_float_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_77; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_78)); return A_arbace_g2a_lit__init_A_const_77.Ref() }








func A_arbace_g2a_lit__init_A_Unit38__O() any { A_arbace_g2a_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_g2a_lit__init_A_const_79; var tmp2 any = A_arbace_g2a_lit_const_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_lit_const_form_A_Init(); tmp3 = A_arbace_g2a_lit_const_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_lit__init_A_const_79; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_lit__init_A_const_80)); return A_arbace_g2a_lit__init_A_const_79.Ref() }



type A_arbace_g2a_lit__init_A struct{ jrt.Object }

var A_arbace_g2a_lit__init_A_const_0 *lang.Var

var A_arbace_g2a_lit__init_A_const_1 any

var A_arbace_g2a_lit__init_A_const_2 any

var A_arbace_g2a_lit__init_A_const_3 any

var A_arbace_g2a_lit__init_A_const_4 *jrt.Class

var A_arbace_g2a_lit__init_A_const_5 *lang.Var

var A_arbace_g2a_lit__init_A_const_6 any

var A_arbace_g2a_lit__init_A_const_7 *lang.Var

var A_arbace_g2a_lit__init_A_const_8 any

var A_arbace_g2a_lit__init_A_const_9 any

var A_arbace_g2a_lit__init_A_const_10 any

var A_arbace_g2a_lit__init_A_const_11 *lang.Var

var A_arbace_g2a_lit__init_A_const_12 any

var A_arbace_g2a_lit__init_A_const_13 *lang.Var

var A_arbace_g2a_lit__init_A_const_14 any

var A_arbace_g2a_lit__init_A_const_15 *lang.Var

var A_arbace_g2a_lit__init_A_const_16 any

var A_arbace_g2a_lit__init_A_const_17 any

var A_arbace_g2a_lit__init_A_const_18 *lang.Var

var A_arbace_g2a_lit__init_A_const_19 any

var A_arbace_g2a_lit__init_A_const_20 *lang.Var

var A_arbace_g2a_lit__init_A_const_21 any

var A_arbace_g2a_lit__init_A_const_22 *lang.Var

var A_arbace_g2a_lit__init_A_const_23 any

var A_arbace_g2a_lit__init_A_const_24 *lang.Var

var A_arbace_g2a_lit__init_A_const_25 any

var A_arbace_g2a_lit__init_A_const_26 *lang.Var

var A_arbace_g2a_lit__init_A_const_27 any

var A_arbace_g2a_lit__init_A_const_28 *lang.Var

var A_arbace_g2a_lit__init_A_const_29 any

var A_arbace_g2a_lit__init_A_const_30 *lang.Var

var A_arbace_g2a_lit__init_A_const_31 any

var A_arbace_g2a_lit__init_A_const_32 *lang.Var

var A_arbace_g2a_lit__init_A_const_33 any

var A_arbace_g2a_lit__init_A_const_34 *lang.Var

var A_arbace_g2a_lit__init_A_const_35 any

var A_arbace_g2a_lit__init_A_const_36 *lang.Var

var A_arbace_g2a_lit__init_A_const_37 any

var A_arbace_g2a_lit__init_A_const_38 *lang.Var

var A_arbace_g2a_lit__init_A_const_39 any

var A_arbace_g2a_lit__init_A_const_40 any

var A_arbace_g2a_lit__init_A_const_41 *lang.Var

var A_arbace_g2a_lit__init_A_const_42 any

var A_arbace_g2a_lit__init_A_const_43 *lang.Var

var A_arbace_g2a_lit__init_A_const_44 any

var A_arbace_g2a_lit__init_A_const_45 *lang.Var

var A_arbace_g2a_lit__init_A_const_46 any

var A_arbace_g2a_lit__init_A_const_47 *lang.Var

var A_arbace_g2a_lit__init_A_const_48 any

var A_arbace_g2a_lit__init_A_const_49 *lang.Var

var A_arbace_g2a_lit__init_A_const_50 any

var A_arbace_g2a_lit__init_A_const_51 *lang.Var

var A_arbace_g2a_lit__init_A_const_52 any

var A_arbace_g2a_lit__init_A_const_53 *lang.Var

var A_arbace_g2a_lit__init_A_const_54 any

var A_arbace_g2a_lit__init_A_const_55 *lang.Var

var A_arbace_g2a_lit__init_A_const_56 any

var A_arbace_g2a_lit__init_A_const_57 *lang.Var

var A_arbace_g2a_lit__init_A_const_58 any

var A_arbace_g2a_lit__init_A_const_59 *lang.Var

var A_arbace_g2a_lit__init_A_const_60 any

var A_arbace_g2a_lit__init_A_const_61 *lang.Var

var A_arbace_g2a_lit__init_A_const_62 any

var A_arbace_g2a_lit__init_A_const_63 *lang.Var

var A_arbace_g2a_lit__init_A_const_64 any

var A_arbace_g2a_lit__init_A_const_65 *lang.Var

var A_arbace_g2a_lit__init_A_const_66 any

var A_arbace_g2a_lit__init_A_const_67 *lang.Var

var A_arbace_g2a_lit__init_A_const_68 any

var A_arbace_g2a_lit__init_A_const_69 *lang.Var

var A_arbace_g2a_lit__init_A_const_70 any

var A_arbace_g2a_lit__init_A_const_71 *lang.Var

var A_arbace_g2a_lit__init_A_const_72 any

var A_arbace_g2a_lit__init_A_const_73 *lang.Var

var A_arbace_g2a_lit__init_A_const_74 any

var A_arbace_g2a_lit__init_A_const_75 *lang.Var

var A_arbace_g2a_lit__init_A_const_76 any

var A_arbace_g2a_lit__init_A_const_77 *lang.Var

var A_arbace_g2a_lit__init_A_const_78 any

var A_arbace_g2a_lit__init_A_const_79 *lang.Var

var A_arbace_g2a_lit__init_A_const_80 any

var A_arbace_g2a_lit__init_A_init jrt.ClassInit

func A_arbace_g2a_lit__init_A_Init() { if !A_arbace_g2a_lit__init_A_init.Done() { A_arbace_g2a_lit__init_A_init.Run(A_arbace_g2a_lit__init_A_clinit) } }

func A_arbace_g2a_lit__init_A_clinit() { A_arbace_g2a_lit__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_200); A_arbace_g2a_lit__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_g2a_lit__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_g2a_lit__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_lit__init_A_const_4 = lang.RT_ClassForNameNonLoading_String__Class(Lit_199); A_arbace_g2a_lit__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_9, Lit_14); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_201).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_lit__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_9, Lit_206); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_201).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_lit__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_186).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_208, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_209).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_210, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_g2a_lit__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_186).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_9, Lit_211); A_arbace_g2a_lit__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_212).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_g2a_lit__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(10).Ref(), Lit_213, jrt.Character_ValueOf_C__Character(32).Ref(), Lit_214, jrt.Character_ValueOf_C__Character(9).Ref(), Lit_215, jrt.Character_ValueOf_C__Character(8).Ref(), Lit_216, jrt.Character_ValueOf_C__Character(12).Ref(), Lit_217, jrt.Character_ValueOf_C__Character(13).Ref(), Lit_218)); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_lit__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); A_arbace_g2a_lit__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_220).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_221, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_9, Lit_74); A_arbace_g2a_lit__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_222)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_225, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_68); A_arbace_g2a_lit__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_220).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_226, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); A_arbace_g2a_lit__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_227, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_9, Lit_35); A_arbace_g2a_lit__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_9, Lit_90); A_arbace_g2a_lit__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_9, Lit_54); A_arbace_g2a_lit__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_229)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_230).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_231)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_230).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_232, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_9, Lit_55); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_lit__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_233).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_129).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_lit__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_230).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_235, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_9, Lit_47); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_g2a_lit__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(117).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); A_arbace_g2a_lit__init_A_const_39 = jrt.Long_ValueOf_J__Long(80).Ref(); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_g2a_lit__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_237)); A_arbace_g2a_lit__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_48); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_g2a_lit__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_229)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_230).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_231)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_230).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_238, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(127).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_45); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_g2a_lit__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_239, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_9, Lit_46); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_g2a_lit__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_240)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_241).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_242, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(152).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_9, Lit_51); A_arbace_g2a_lit__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_197).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_243, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_9, Lit_101); A_arbace_g2a_lit__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_244, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(177).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_9, Lit_56); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_g2a_lit__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_245)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_246, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(186).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_57); A_arbace_g2a_lit__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_247, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(203).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_9, Lit_60); A_arbace_g2a_lit__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_248, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(212).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_9, Lit_249); A_arbace_g2a_lit__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_250, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(219).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_9, Lit_64); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_g2a_lit__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_222)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(235).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_9, Lit_65); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_g2a_lit__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_251)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_252, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(237).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_9, Lit_253); A_arbace_g2a_lit__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_254, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(271).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_9, Lit_255); A_arbace_g2a_lit__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_256, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(278).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_9, Lit_66); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_g2a_lit__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_257)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_258).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_233).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_259, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(292).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_9, Lit_70); A_arbace_g2a_lit__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_257)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_260, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(321).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_9, Lit_102); A_arbace_g2a_lit__init_A_const_72 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_220).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_261, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(336).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_73 = lang.RT_Var_String_String__Var(Lit_9, Lit_103); A_arbace_g2a_lit__init_A_const_74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_257)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_262, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(345).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_75 = lang.RT_Var_String_String__Var(Lit_9, Lit_91); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_219).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_g2a_lit__init_A_const_76 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_263, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_9, Lit_99); A_arbace_g2a_lit__init_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_264, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(370).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)); A_arbace_g2a_lit__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_9, Lit_265); A_arbace_g2a_lit__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_202).Ref(), jrt.Integer_ValueOf_I__Integer(379).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_203).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), Lit_205)) }

func A_arbace_g2a_lit__init_A_New() *A_arbace_g2a_lit__init_A { A_arbace_g2a_lit__init_A_Init(); t := &A_arbace_g2a_lit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_lit__init_A) Ctor() {}

func (t *A_arbace_g2a_lit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit__init_A_class }

func (t *A_arbace_g2a_lit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit__init_A); return ok }

func A_arbace_g2a_lit__init_A_Cast(x any) *A_arbace_g2a_lit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit__init_A_class)) }; return v }
