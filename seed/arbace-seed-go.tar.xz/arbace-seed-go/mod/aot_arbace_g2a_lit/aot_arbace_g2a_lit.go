//line aot_arbace_g2a_lit.ae:1
package aot_arbace_g2a_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_New() *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A { A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_Init(); t := &A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_3; tmp8.Invoke_O__O(tmp9); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_50)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_129)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_130)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp13 != nil { panic(tmp13) }; return tmp3 }
//line :1:1
func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_New() *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A { A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_Init(); t := &A_arbace_g2a_lit_eval1426000008_fn__1426000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_New() *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A { A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_Init(); t := &A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) Ctor() {}
//line :13:1
func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) Invoke_O_O_O__O(self, text__1, value__2 any) any { return A_arbace_g2a_lit_Lit_A_New_O_O(text__1, value__2) }
//line :13:1
func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_New() *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A { A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_Init(); t := &A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) Ctor() {}
//line :13:1
func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_9; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O__O(tmp4.Ref(), m__231000174__auto____1) }; return A_arbace_g2a_lit_Lit_A_Create_IPersistentMap__A_arbace_g2a_lit_Lit_A(lang.IPersistentMap_Cast(tmp1)).Ref() }

func A_arbace_g2a_lit_lit_A_New() *A_arbace_g2a_lit_lit_A { A_arbace_g2a_lit_lit_A_Init(); t := &A_arbace_g2a_lit_lit_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_g2a_lit_lit_A) Ctor() {}
//line :15:1
func (t *A_arbace_g2a_lit_lit_A) Invoke_O_O_O__O(self, text__0, value__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(text__0, value__1) }

func A_arbace_g2a_lit_lit_QMARK__A_New() *A_arbace_g2a_lit_lit_QMARK__A { A_arbace_g2a_lit_lit_QMARK__A_Init(); t := &A_arbace_g2a_lit_lit_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_g2a_lit_lit_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_g2a_lit_lit_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(A_arbace_g2a_lit_Lit_A_InstanceOf(x__0)).Ref() }







func A_arbace_g2a_lit_printable_QMARK__A_New() *A_arbace_g2a_lit_printable_QMARK__A { A_arbace_g2a_lit_printable_QMARK__A_Init(); t := &A_arbace_g2a_lit_printable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_g2a_lit_printable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_g2a_lit_printable_QMARK__A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J(cp__0); var t__3 int32 = jrt.Character_GetType_I__I(lang.RT_IntCast_J__I(cp__2)); var tmp1 *lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____4 bool = jrt.Character_IsISOControl_I__Z(lang.RT_IntCast_J__I(cp__2)); if or__1927000174__auto____4 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.Character_IsWhitespace_I__Z(lang.RT_IntCast_J__I(cp__2)); if or__1927000174__auto____5 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.Character_IsSpaceChar_I__Z(lang.RT_IntCast_J__I(cp__2)); if or__1927000174__auto____6 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 any; var tmp4 *lang.Var

		A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_14; var tmp7 any = tmp6; var tmp8 any = jrt.Long_ValueOf_J__Long(cp__2).Ref(); var tmp9 any; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_15; or__1927000174__auto____7 = tmp5.Invoke_O_O_O__O(tmp7, tmp8, tmp9)
//line :30:1
		if jrt.A2g_Truth(or__1927000174__auto____7) { tmp3 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var tmp10 *lang.Var


			A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_12; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_16; var tmp13 any = tmp12; var tmp14 any = jrt.Long_ValueOf_J__Long(cp__2).Ref(); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_17; or__1927000174__auto____8 = tmp11.Invoke_O_O_O__O(tmp13, tmp14, tmp15)
//line :30:1
			if jrt.A2g_Truth(or__1927000174__auto____8) { tmp3 = or__1927000174__auto____8 } else {



				var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_13; tmp3 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(0)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(19)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(13)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(14)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(18)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_B__I(16)).Ref())), jrt.Integer_ValueOf_I__Integer(t__3).Ref()) } } } } }; return /*line :30:1*/ tmp2.Invoke_O__O(tmp3) }








func A_arbace_g2a_lit_string_text_A_New() *A_arbace_g2a_lit_string_text_A { A_arbace_g2a_lit_string_text_A_Init(); t := &A_arbace_g2a_lit_string_text_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_lit_string_text_A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_lit_string_text_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_170); var n__3 int32 = jrt.NN(jrt.String_Cast(s__0)).Length__I(); var i__4 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z(i__4, int64(n__3)) { var cp__5 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I(i__4)); var w__6 int32 = jrt.Character_CharCount_I__I(cp__5); var G__1426000031__7_ int32 = lang.RT_IntCast_I__I(cp__5)


	L2: switch { default: switch G__1426000031__7_ { case 8:





		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_171)
//line :48:1
		break L2; case 9:



		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_172)
//line :48:1
		break L2; case 10:


		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_173)
//line :48:1
		break L2; case 12:






		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_174)
//line :48:1
		break L2; case 13:




		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_175)
//line :48:1
		break L2; case 34:
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_176)
//line :48:1
		break L2; case 92:

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_177)
//line :48:1
		break L2; default:
	}






		var tmp1 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_J_J__Z(int64(cp__5), 32)
		if or__1927000174__auto____8 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_19; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(cp__5).Ref()) }
//line :56:1
		if jrt.A2g_Truth(tmp1) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).AppendCodePoint_I__StringBuilder(cp__5) } else {
//line :56:1
				if lang.Numbers_Lt_J_J__Z(int64(cp__5), 65536) {

					var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_20; jrt.NN(tmp3).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(Lit_113, jrt.Integer_ValueOf_I__Integer(cp__5).Ref()))) } else {
//line :56:1
						var tmp5 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_21; if tmp5 != nil { var seq_1426000032__8 any; var tmp6 *lang.Var


							A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_22; seq_1426000032__8 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(jrt.Character_ToChars_I__C1(cp__5).Ref())
//line :56:1
							var chunk_1426000033__9 any; var count_1426000034__10 int64 = 0; var i_1426000035__11 int64 = 0; L3: for {


								if lang.Numbers_Lt_J_J__Z(i_1426000035__11, count_1426000034__10) { var c__12 any = lang.Indexed_Cast(chunk_1426000033__9).Nth_I__O(lang.RT_IntCast_J__I(i_1426000035__11)); var tmp7 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_20; jrt.NN(tmp7).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(Lit_113, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__12)).Ref()))); seq_1426000032__8, chunk_1426000033__9, count_1426000034__10, i_1426000035__11 = seq_1426000032__8, chunk_1426000033__9, count_1426000034__10, lang.Numbers_Unchecked_inc_J__J(i_1426000035__11); continue L3 } else { var temp__1927000414__auto____12 any; var tmp9 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_22; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1426000032__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_1426000032__13 any = temp__1927000414__auto____12; var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_1426000032__13)) { var c__1927000678__auto____14 any; var tmp11 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_24; c__1927000678__auto____14 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_1426000032__13); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_26; seq_1426000032__8, chunk_1426000033__9, count_1426000034__10, i_1426000035__11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1426000032__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var c__14 any; var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_25; c__14 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_1426000032__13); var tmp14 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp15 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_20; jrt.NN(tmp14).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(Lit_113, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__14)).Ref()))); var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_27; seq_1426000032__8, chunk_1426000033__9, count_1426000034__10, i_1426000035__11 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1426000032__13), nil, 0, 0; continue L3 } } }
//line :56:1
								break L3
							}
						}
					} }}
		i__4 = lang.Numbers_Add_J_J__J(i__4, int64(w__6)); continue L1 }
//line :39:1
	break L1 }; var tmp17 /*line :61:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_18; return lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_170).Ref()) }

func A_arbace_g2a_lit_char_text_A_New() *A_arbace_g2a_lit_char_text_A { A_arbace_g2a_lit_char_text_A_Init(); t := &A_arbace_g2a_lit_char_text_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_g2a_lit_char_text_A) Ctor() {}
//line :63:1
func (t *A_arbace_g2a_lit_char_text_A) Invoke_O_O__O(self, cp__0 any) any { var ch__2 uint16 = lang.RT_CharCast_O__C(cp__0); var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(ch__2).Ref())) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_112, nil); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_28; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(ch__2).Ref()))).Ref() } else {
//line :67:1
			var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(cp__0)) {

				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character(ch__2).Ref())).Ref() } else {
//line :67:1
					var tmp5 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_21; if tmp5 != nil {


						var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_20; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(Lit_113, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(cp__0)).Ref()) } else {
//line :67:1
							return nil } } } }






func A_arbace_g2a_lit_int_lit_A_New() *A_arbace_g2a_lit_int_lit_A { A_arbace_g2a_lit_int_lit_A_Init(); t := &A_arbace_g2a_lit_int_lit_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_g2a_lit_int_lit_A) Ctor() {}
//line :74:1
func (t *A_arbace_g2a_lit_int_lit_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_29; t__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(text__0, Lit_140, Lit_141); var lower__3 any; var tmp2 /*line :74:1*/*lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_30; lower__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t__2); var vec__1426000038__4 any; var tmp3 /*line :74:1*/*lang.Var;






	A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_138)) { var tmp4 any; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_34; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_35; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_36; vec__1426000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp5, tmp7.Invoke_O_O__O(t__2, tmp8)) } else { var tmp9 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_148)) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_149, nil); var tmp11 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_35; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_36; var tmp14 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12.Invoke_O_O__O(t__2, tmp13))).Ref(); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_37; var tmp16 any = tmp15; var tmp17 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_35; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_36; vec__1426000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp14, tmp16, tmp18.Invoke_O_O__O(t__2, tmp19)) } else { var tmp20 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp20 = A_arbace_g2a_lit_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_150)) { var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_151, nil); var tmp22 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_35; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_36; var tmp25 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp23.Invoke_O_O__O(t__2, tmp24))).Ref(); var tmp26 any; A_arbace_g2a_lit_A_Init(); tmp26 = A_arbace_g2a_lit_A_const_36; var tmp27 any = tmp26; var tmp28 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_35; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_36; vec__1426000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp25, tmp27, tmp29.Invoke_O_O__O(t__2, tmp30)) } else { var tmp31 any; var and__1927000168__auto____4 any; var tmp32 *lang.Var



		A_arbace_g2a_lit_A_Init(); tmp32 = A_arbace_g2a_lit_A_const_31; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O_O__O(t__2, Lit_149); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp31 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(t__2)), 1)).Ref() } else { tmp31 = and__1927000168__auto____4 }
//line :81:1
		if jrt.A2g_Truth(tmp31) { var tmp33 any; A_arbace_g2a_lit_A_Init(); tmp33 = A_arbace_g2a_lit_A_const_37; var tmp34 any = tmp33; var tmp35 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp35 = A_arbace_g2a_lit_A_const_35; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_g2a_lit_A_Init(); tmp37 = A_arbace_g2a_lit_A_const_38; vec__1426000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp34, tmp36.Invoke_O_O__O(t__2, tmp37)) } else { var tmp38 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp38 = A_arbace_g2a_lit_A_const_21; if tmp38 != nil { var tmp39 any; A_arbace_g2a_lit_A_Init(); tmp39 = A_arbace_g2a_lit_A_const_39; vec__1426000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp39, t__2) } else { vec__1426000038__4 = nil } } } } }; var ctext__5 any = /*line :74:1*/lang.RT_Nth_O_I_O__O(vec__1426000038__4, lang.RT_IntCast_J__I(0), nil); var radix__6 any = lang.RT_Nth_O_I_O__O(vec__1426000038__4, lang.RT_IntCast_J__I(1), nil); var digits__7 any = lang.RT_Nth_O_I_O__O(vec__1426000038__4, lang.RT_IntCast_J__I(2), nil); var v__8 any; var tmp40 *lang.Var;












	A_arbace_g2a_lit_A_Init(); tmp40 = A_arbace_g2a_lit_A_const_32; v__8 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(jrt.BigInteger_New_String_I(jrt.String_Cast(digits__7), lang.RT_IntCast_O__I(radix__6))); var tmp41 /*line :88:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp41 = A_arbace_g2a_lit_A_const_33; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; var tmp44 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp44 = A_arbace_g2a_lit_A_const_40; if lang.Numbers_Lt_J_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(v__8))).BitLength__I()), 64) { tmp43 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__8)).Ref() } else { tmp43 = v__8 }; return tmp42.Invoke_O_O__O(ctext__5, tmp43) }

func A_arbace_g2a_lit_integer_text_A_New() *A_arbace_g2a_lit_integer_text_A { A_arbace_g2a_lit_integer_text_A_Init(); t := &A_arbace_g2a_lit_integer_text_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_g2a_lit_integer_text_A) Ctor() {}
//line :90:1
func (t *A_arbace_g2a_lit_integer_text_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_40; b__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0); if
	lang.Numbers_Lt_J_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_18; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__0)).Ref()) } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_154), jrt.RefArrayOf(jrt.Object_class, b__2, nil)).Ref() } }

func A_arbace_g2a_lit_integer_lit_A_New() *A_arbace_g2a_lit_integer_lit_A { A_arbace_g2a_lit_integer_lit_A_Init(); t := &A_arbace_g2a_lit_integer_lit_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_g2a_lit_integer_lit_A) Ctor() {}
//line :96:1
func (t *A_arbace_g2a_lit_integer_lit_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var tmp1 *lang.Var;
										A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_40; b__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0); var tmp2 /*line :98:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_41; var tmp5 any = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(v__0); var tmp6 any; if lang.Numbers_Lt_J_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { tmp6 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__0)).Ref() } else { var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_32; tmp6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(b__2) }; return tmp3.Invoke_O_O__O(tmp5, tmp6) }



func A_arbace_g2a_lit_rational_A_New() *A_arbace_g2a_lit_rational_A { A_arbace_g2a_lit_rational_A_Init(); t := &A_arbace_g2a_lit_rational_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_lit_rational_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_lit_rational_A) Invoke_O_O_O__O(self, num__0, den__1 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_32; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(num__0); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_32; return lang.Numbers_Divide_O_O__Number(tmp2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(den__1))
}
func A_arbace_g2a_lit_pow2_A_New() *A_arbace_g2a_lit_pow2_A { A_arbace_g2a_lit_pow2_A_Init(); t := &A_arbace_g2a_lit_pow2_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_g2a_lit_pow2_A) Ctor() {}
//line :107:1
func (t *A_arbace_g2a_lit_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.BigInteger; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 *jrt.BigInteger = tmp1; return jrt.NN(tmp2).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I(n__0)).Ref() }

func A_arbace_g2a_lit_pow5_exponent_A_New() *A_arbace_g2a_lit_pow5_exponent_A { A_arbace_g2a_lit_pow5_exponent_A_Init(); t := &A_arbace_g2a_lit_pow5_exponent_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_lit_pow5_exponent_A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_lit_pow5_exponent_A) Invoke_O_O__O(self, d__0 any) any { var guess__2 int64; var tmp1 int64 = int64(jrt.NN(jrt.BigInteger_Cast(d__0)).BitLength__I()); var tmp2 any;


	A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_36; var tmp3 float64 = lang.Numbers_Multiply_J_D__D(tmp1, jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D(tmp2))); var tmp4 any; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_42; guess__2 = lang.RT_LongCast_D__J(jrt.Math_Floor_D__D(lang.Numbers_Divide_D_D__D(tmp3, jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D(tmp4))))); var five__3 any = /*line :109:1*/jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var tmp5 *lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_43; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_New_O_O(d__0, five__3); var tmp8 *jrt.Class; A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_Init(); tmp8 = A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_fn_class; return tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(guess__2).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(guess__2)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(guess__2)).Ref())) }
//line :114:1
func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_New_O_O(p0, p1 any) *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A { A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_Init(); t := &A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) Ctor_O_O(c__d, c__five any) { t.F_d = c__d; t.F_five = c__five }
//line :114:1
func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Gte_O_J__Z(k__1, 0); if and__1927000168__auto____2 { var tmp2 any = t.F_d; var tmp3 *jrt.BigInteger = jrt.BigInteger_Cast(t.F_five); tmp1 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Pow_I__BigInteger(lang.RT_IntCast_O__I(k__1)).Ref()) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return k__1 } else { return nil } }


func A_arbace_g2a_lit_num_den_A_New() *A_arbace_g2a_lit_num_den_A { A_arbace_g2a_lit_num_den_A_Init(); t := &A_arbace_g2a_lit_num_den_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_g2a_lit_num_den_A) Ctor() {}
//line :117:1
func (t *A_arbace_g2a_lit_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_44; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(r__0)) { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_45; var tmp3 any = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(r__0); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_46; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(r__0)) } else { var tmp5 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_21; if tmp5 != nil { var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_40; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(r__0); var tmp8 *jrt.BigInteger; jrt.BigInteger_Init(); tmp8 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Ref()) } else { return nil
	}
	}
}





func A_arbace_g2a_lit_terminating_decimal_A_New() *A_arbace_g2a_lit_terminating_decimal_A { A_arbace_g2a_lit_terminating_decimal_A_Init(); t := &A_arbace_g2a_lit_terminating_decimal_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_g2a_lit_terminating_decimal_A) Ctor() {}
//line :127:1
func (t *A_arbace_g2a_lit_terminating_decimal_A) Invoke_O_O_O__O(self, num__0, den__1 any) any { var twos__3 int32 = jrt.NN(jrt.BigInteger_Cast(den__1)).GetLowestSetBit__I(); var temp__1927000414__auto____4 any; var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_47; temp__1927000414__auto____4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigInteger_Cast(den__1)).ShiftRight_I__BigInteger(twos__3).Ref()); if jrt.A2g_Truth(temp__1927000414__auto____4) { var fives__5 any = temp__1927000414__auto____4; var scale__6 any = lang.Numbers_Max_J_O__O(int64(twos__3), fives__5); var unscaled__7 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(num__0)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I(lang.Numbers_Minus_O_J__Number(scale__6, int64(twos__3))))).Multiply_BigInteger__BigInteger(jrt.NN(jrt.BigInteger_ValueOf_J__BigInteger(5)).Pow_I__BigInteger(lang.RT_IntCast_O__I(lang.Numbers_Minus_O_O__Number(scale__6, fives__5)))).Ref(); return jrt.BigDecimal_New_BigInteger_I(jrt.BigInteger_Cast(unscaled__7), lang.RT_IntCast_O__I(scale__6)) } else { return nil } }







func A_arbace_g2a_lit_double_exact_text_A_New() *A_arbace_g2a_lit_double_exact_text_A { A_arbace_g2a_lit_double_exact_text_A_Init(); t := &A_arbace_g2a_lit_double_exact_text_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_g2a_lit_double_exact_text_A) Ctor() {}
//line :139:1
func (t *A_arbace_g2a_lit_double_exact_text_A) Invoke_O_O__O(self, v__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D(v__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsInfinite_D__Z(d__2); if or__1927000174__auto____3 {




	tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsNaN_D__Z(d__2) }; if tmp1 { return nil } else { var s__3 any = jrt.Double_ToString_D__String(d__2).Ref(); var bd__4 any = jrt.BigDecimal_New_String(jrt.String_Cast(s__3)); var tmp2 bool


		if jrt.BigDecimal_InstanceOf(v__0) {
			tmp2 = lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.BigDecimal_Cast(bd__4)).CompareTo_BigDecimal__I(jrt.BigDecimal_Cast(v__0)))) } else {
				var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_48; tmp2 = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(bd__4), v__0) }
//line :147:1
		if tmp2 { return s__3 } else { return nil } } }




func A_arbace_g2a_lit_decimal_text_A_New() *A_arbace_g2a_lit_decimal_text_A { A_arbace_g2a_lit_decimal_text_A_Init(); t := &A_arbace_g2a_lit_decimal_text_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_lit_decimal_text_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_lit_decimal_text_A) Invoke_O_O__O(self, bd__0 any) any { var s__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_18; s__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_Cast(bd__0)).StripTrailingZeros__BigDecimal().Ref()); var tmp2 any; var or__1927000174__auto____3 any; var tmp3 /*line :156:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_49; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_117); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_49; tmp2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_118) }; if jrt.A2g_Truth(tmp2) { return s__2 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() } }

func A_arbace_g2a_lit_float_lit_A_New() *A_arbace_g2a_lit_float_lit_A { A_arbace_g2a_lit_float_lit_A_Init(); t := &A_arbace_g2a_lit_float_lit_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_g2a_lit_float_lit_A) Ctor() {}
//line :158:1
func (t *A_arbace_g2a_lit_float_lit_A) Invoke_O_O_O__O(self, v__0, p__1426000053__1 any) any { var map__1426000054__3 any = p__1426000053__1; var map__1426000054__4 any; if lang.ISeq_InstanceOf(map__1426000054__3) { var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1426000054__3)) { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_50; map__1426000054__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1426000054__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1426000054__3)) { var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_25; map__1426000054__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1426000054__3) } else { lang.PersistentArrayMap_Init(); map__1426000054__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1426000054__4 = map__1426000054__3 }; var prefer_ratio__5 any; var tmp5 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_51; prefer_ratio__5 = lang.RT_Get_O_O__O(map__1426000054__4, tmp5.Ref()); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 any; var tmp6 *lang.Var;







	A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_11; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(prefer_ratio__5); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_52; temp__1927000408__auto____6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(v__0) } else { temp__1927000408__auto____6 = and__1927000168__auto____6 }; if jrt.A2g_Truth(temp__1927000408__auto____6) { var s__7 any = temp__1927000408__auto____6; var tmp8 *lang.Var
		A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_33; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(s__7, jrt.Double_ValueOf_D__Double(jrt.Double_ParseDouble_String__D(jrt.String_Cast(s__7))).Ref()) } else {
			if jrt.BigDecimal_InstanceOf(v__0) { var s__7_2 any; var tmp9 *lang.Var
				A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_53; s__7_2 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(v__0); var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_33; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_135), jrt.RefArrayOf(jrt.Object_class, s__7_2, nil)).Ref(); var tmp13 *jrt.Class; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_57; var tmp14 *jrt.Class = tmp13; return tmp11.Invoke_O_O__O(tmp12, lang.Reflector_InvokeConstructor_Class_O1__O(tmp14, jrt.RefArrayOf(jrt.Object_class, s__7_2))) } else {
//line :168:1
					var vec__1426000056__7 any; var tmp15 *lang.Var

					A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_54; vec__1426000056__7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(v__0)
//line :168:1
					var num__8 any = lang.RT_Nth_O_I_O__O(vec__1426000056__7, lang.RT_IntCast_J__I(0), nil); var den__9 any = lang.RT_Nth_O_I_O__O(vec__1426000056__7, lang.RT_IntCast_J__I(1), nil); var integral__10 bool; var tmp16 *jrt.BigInteger


					jrt.BigInteger_Init(); tmp16 = jrt.BigInteger_ONE; integral__10 = lang.Util_Equiv_O_O__Z(den__9, tmp16.Ref())
//line :168:1
					var bd__11 any; var tmp17 any
					var and__1927000168__auto____11 any = prefer_ratio__5


					if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp18 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_11; tmp17 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(integral__10).Ref()) } else { tmp17 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp17) { bd__11 = nil } else { var tmp19 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_55; bd__11 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(num__8, den__9) }
					var tmp20 any; var and__1927000168__auto____12 any = bd__11; if jrt.A2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = integral__10; if or__1927000174__auto____13 { tmp20 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____13).Ref() } else { var tmp21 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_18; var tmp22 int64 = int64(lang.RT_Count_O__I(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(bd__11))); var tmp23 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp23 = A_arbace_g2a_lit_A_const_56; tmp20 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lte_J_O__Z(tmp22, jrt.NN(tmp23).GetRawRoot__O())).Ref() } } else { tmp20 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp20) { var s__12 any; var tmp24 *lang.Var
						A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_53; s__12 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(bd__11); var tmp25 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp25 = A_arbace_g2a_lit_A_const_33; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_135), jrt.RefArrayOf(jrt.Object_class, s__12, nil)).Ref(); var tmp28 *jrt.Class; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_57; var tmp29 *jrt.Class = tmp28; return tmp26.Invoke_O_O__O(tmp27, lang.Reflector_InvokeConstructor_Class_O1__O(tmp29, jrt.RefArrayOf(jrt.Object_class, s__12))) } else {
							var tmp30 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_33; return lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_136, nil), jrt.RefArrayOf(jrt.Object_class, num__8, nil, den__9)).Ref(), v__0) } } } }
//line :158:1
func (t *A_arbace_g2a_lit_float_lit_A) Invoke_O_O__O(self, v__0 any) any {





	var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_58; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O__O(v__0, tmp3.Ref())
}











func A_arbace_g2a_lit_double_lit_A_New() *A_arbace_g2a_lit_double_lit_A { A_arbace_g2a_lit_double_lit_A_Init(); t := &A_arbace_g2a_lit_double_lit_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_g2a_lit_double_lit_A) Ctor() {}
//line :177:1
func (t *A_arbace_g2a_lit_double_lit_A) Invoke_O_O__O(self, r__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D(r__0); var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.String; if jrt.Double_IsNaN_D__Z(d__2) { tmp3 = Lit_125 } else { if jrt.Double_IsInfinite_D__Z(d__2) {
		if lang.Numbers_IsPos_D__Z(d__2) { tmp3 = Lit_126 } else { tmp3 = Lit_127 } } else {
//line :181:1
			var tmp4 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_21; if tmp4 != nil {

				tmp3 = jrt.Double_ToString_D__String(d__2) } else {
//line :181:1
					tmp3 = nil } } }; return tmp2.Invoke_O_O__O(tmp3.Ref(), jrt.Double_ValueOf_D__Double(d__2).Ref()) }




func A_arbace_g2a_lit_hex_float_value_A_New() *A_arbace_g2a_lit_hex_float_value_A { A_arbace_g2a_lit_hex_float_value_A_Init(); t := &A_arbace_g2a_lit_hex_float_value_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_g2a_lit_hex_float_value_A) Ctor() {}
//line :186:1
func (t *A_arbace_g2a_lit_hex_float_value_A) Invoke_O_O__O(self, t__0 any) any { var body__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_36; body__2 = tmp2.Invoke_O_O__O(t__0, tmp3); var pi__3 any; var tmp4 /*line :186:1*/*lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_59; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_30; pi__3 = tmp5.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(body__2), Lit_143); var mant__4 any; var tmp7 /*line :186:1*/*lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_35; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_62; mant__4 = tmp8.Invoke_O_O_O__O(body__2, tmp9, pi__3); var exp__5 int64; var tmp10 /*line :186:1*/*lang.Var;





	A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_29; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_35; exp__5 = jrt.Long_ParseLong_String__J(jrt.String_Cast(tmp11.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(body__2, lang.Numbers_Inc_O__Number(pi__3)), Lit_144, Lit_141))); var dot__6 any; var tmp13 /*line :186:1*/*lang.Var;






	A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_59; dot__6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(mant__4, Lit_117); var int_part__7 any; if
	jrt.A2g_Truth(dot__6) { var tmp14 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp14 = A_arbace_g2a_lit_A_const_35; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_62; int_part__7 = tmp15.Invoke_O_O_O__O(mant__4, tmp16, dot__6) } else { int_part__7 = mant__4 }; var frac__8 any; if
	jrt.A2g_Truth(dot__6) { var tmp17 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_35; frac__8 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(mant__4, lang.Numbers_Inc_O__Number(dot__6)) } else { frac__8 = Lit_141 }; var digits__9 any = /*line :186:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, int_part__7, frac__8)).Ref(); var m__10 any; var tmp18 *lang.Var;










	A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_60; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(digits__9)) { jrt.BigInteger_Init(); m__10 = jrt.BigInteger_ZERO.Ref() } else { m__10 = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__9), lang.RT_IntCast_J__I(16)) }; var e__11 int64 = /*line :186:1*/lang.Numbers_Minus_J_J__J(exp__5, lang.Numbers_Multiply_J_J__J(4, int64(lang.RT_Count_O__I(frac__8)))); if












	lang.Numbers_IsNeg_J__Z(e__11) {
		var tmp19 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_61; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_63; return tmp20.Invoke_O_O__O(m__10, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(e__11)).Ref())) } else {
			var tmp22 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_61; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = jrt.NN(jrt.BigInteger_Cast(m__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I(e__11)).Ref(); var tmp25 *jrt.BigInteger; jrt.BigInteger_Init(); tmp25 = jrt.BigInteger_ONE; return tmp23.Invoke_O_O__O(tmp24, tmp25.Ref()) } }

func A_arbace_g2a_lit_float_value_A_New() *A_arbace_g2a_lit_float_value_A { A_arbace_g2a_lit_float_value_A_Init(); t := &A_arbace_g2a_lit_float_value_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_g2a_lit_float_value_A) Ctor() {}
//line :203:1
func (t *A_arbace_g2a_lit_float_value_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_29; t__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(text__0, Lit_140, Lit_141); var tmp2 /*line :208:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_30; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t__2), Lit_138)) {
		var tmp5 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_64; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :208:1
			return jrt.BigDecimal_New_String(jrt.String_Cast(t__2)) } }



func A_arbace_g2a_lit_float_text_lit_A_New() *A_arbace_g2a_lit_float_text_lit_A { A_arbace_g2a_lit_float_text_lit_A_Init(); t := &A_arbace_g2a_lit_float_text_lit_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_g2a_lit_float_text_lit_A) Ctor() {}
//line :212:1
func (t *A_arbace_g2a_lit_float_text_lit_A) Invoke_O_O__O(self, text__0 any) any { var hex__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_30; hex__2 = tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(text__0), Lit_138); var tmp4 /*line :217:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_58; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_65; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(text__0); var tmp8 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_51; return tmp5.Invoke_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), hex__2))) }

func A_arbace_g2a_lit_imag_inner_A_New() *A_arbace_g2a_lit_imag_inner_A { A_arbace_g2a_lit_imag_inner_A_Init(); t := &A_arbace_g2a_lit_imag_inner_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_g2a_lit_imag_inner_A) Ctor() {}
//line :219:1
func (t *A_arbace_g2a_lit_imag_inner_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_35; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_62; var tmp6 any = tmp5; t__2 = tmp2.Invoke_O_O_O__O(tmp4.Invoke_O_O_O__O(text__0, tmp6, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(text__0)))).Ref()), Lit_140, Lit_141); var lower__3 any; var tmp7 /*line :219:1*/*lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_30; lower__3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(t__2); var tmp8 /*line :225:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_66; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_69; if jrt.A2g_Truth(tmp9.Invoke_O_O__O(tmp10, t__2)) { var v__4 any; var tmp11 *lang.Var
		A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_32; v__4 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(jrt.BigInteger_New_String(jrt.String_Cast(t__2)))
		var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_33; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp14 = A_arbace_g2a_lit_A_const_41; var tmp15 any = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(v__4); var tmp16 any; var tmp17 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_40; if lang.Numbers_Lt_J_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(v__4))).BitLength__I()), 64) { tmp16 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__4)).Ref() } else { tmp16 = v__4 }; return tmp13.Invoke_O_O__O(tmp15, tmp16) } else {
//line :225:1
			var tmp18 any; var and__1927000168__auto____4 any; var tmp19 *lang.Var


			A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_66; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_70; and__1927000168__auto____4 = tmp20.Invoke_O_O__O(tmp21, lower__3); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp22 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_11; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_49; and__1927000168__auto____5 = tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_143)); if jrt.A2g_Truth(and__1927000168__auto____5) {
				var tmp25 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp25 = A_arbace_g2a_lit_A_const_11; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp27 = A_arbace_g2a_lit_A_const_49; tmp18 = tmp26.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_117)) } else {
//line :228:1
					tmp18 = and__1927000168__auto____5 } } else { tmp18 = and__1927000168__auto____4 }
//line :225:1
			if jrt.A2g_Truth(tmp18) {




				var tmp28 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_67; return lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :225:1
					var tmp29 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp29 = A_arbace_g2a_lit_A_const_21; if tmp29 != nil {





						var tmp30 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_68; return lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :225:1
							return nil } } } }









func A_arbace_g2a_lit_hexv_A_New() *A_arbace_g2a_lit_hexv_A { A_arbace_g2a_lit_hexv_A_Init(); t := &A_arbace_g2a_lit_hexv_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_g2a_lit_hexv_A) Ctor() {}
//line :235:1
func (t *A_arbace_g2a_lit_hexv_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(s__0), lang.RT_IntCast_J__I(16))).Ref() }

func A_arbace_g2a_lit_unescape_A_New() *A_arbace_g2a_lit_unescape_A { A_arbace_g2a_lit_unescape_A_Init(); t := &A_arbace_g2a_lit_unescape_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_g2a_lit_unescape_A) Ctor() {}
//line :237:1
func (t *A_arbace_g2a_lit_unescape_A) Invoke_O_O__O(self, body__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var n__3 int32 = jrt.NN(jrt.String_Cast(body__0)).Length__I(); var put_cp__4 any; var tmp1 any = A_arbace_g2a_lit_unescape_put_cp__1426000066_A_New_O(out__2); var tmp2 *jrt.Class;




	A_arbace_g2a_lit_unescape_put_cp__1426000066_A_Init(); tmp2 = A_arbace_g2a_lit_unescape_put_cp__1426000066_A_fn_class; put_cp__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var i__5 int64 = 0; L1:
//line :237:1
	for {








		if lang.Numbers_Lt_J_J__Z(i__5, int64(n__3)) { var c__6 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I(i__5)); var tmp3 *lang.Var

			A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_71; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = jrt.Character_ValueOf_C__Character(c__6).Ref(); var tmp6 any; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_75; if jrt.A2g_Truth(tmp4.Invoke_O_O__O(tmp5, tmp6)) { var cp__7 int32 = jrt.NN(jrt.String_Cast(body__0)).CodePointAt_I__I(lang.RT_IntCast_J__I(i__5))

				lang.IFn_Cast(put_cp__4).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(cp__7).Ref())
				i__5 = lang.Numbers_Add_J_J__J(i__5, int64(jrt.Character_CharCount_I__I(cp__7))); continue L1 } else {
//line :248:1
					var e__7 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(i__5)))
					var G__1426000068__8_ uint16 = e__7



				L2: switch { default: switch lang.Util_Hash_O__I(jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref()) { case 34: var tmp7 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp8 any; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_72; if lang.Util_Equiv_O_O__Z(tmp7, tmp8) {









					jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(34)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
					break L2 }; case 39: var tmp9 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp10 any; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_73; if lang.Util_Equiv_O_O__Z(tmp9, tmp10) {








						jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(39)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
						break L2 }; case 85: var tmp11 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp12 any; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_74; if lang.Util_Equiv_O_O__Z(tmp11, tmp12) {












							var tmp13 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp14 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp14 = A_arbace_g2a_lit_A_const_76; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_35; tmp13.Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 10)).Ref()))); i__5 = lang.Numbers_Add_J_J__J(i__5, 10); continue L1
//line :253:1
							break L2 }; case 92: var tmp17 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp18 any; A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_75; if lang.Util_Equiv_O_O__Z(tmp17, tmp18) {







								jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(92)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
								break L2 }; case 97: var tmp19 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp20 any; A_arbace_g2a_lit_A_Init(); tmp20 = A_arbace_g2a_lit_A_const_77; if lang.Util_Equiv_O_O__Z(tmp19, tmp20) {
									jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(7)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
									break L2 }; case 98: var tmp21 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp22 any; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_78; if lang.Util_Equiv_O_O__Z(tmp21, tmp22) {

										jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(8)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
										break L2 }; case 102: var tmp23 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp24 any; A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_79; if lang.Util_Equiv_O_O__Z(tmp23, tmp24) {


											jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(12)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
											break L2 }; case 110: var tmp25 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp26 any; A_arbace_g2a_lit_A_Init(); tmp26 = A_arbace_g2a_lit_A_const_80; if lang.Util_Equiv_O_O__Z(tmp25, tmp26) {



												jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(10)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
												break L2 }; case 114: var tmp27 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp28 any; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_81; if lang.Util_Equiv_O_O__Z(tmp27, tmp28) {




													jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(13)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
													break L2 }; case 116: var tmp29 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp30 any; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_82; if lang.Util_Equiv_O_O__Z(tmp29, tmp30) {





														jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(9)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
														break L2 }; case 117: var tmp31 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp32 any; A_arbace_g2a_lit_A_Init(); tmp32 = A_arbace_g2a_lit_A_const_83; if lang.Util_Equiv_O_O__Z(tmp31, tmp32) {











															var tmp33 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp34 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp34 = A_arbace_g2a_lit_A_const_76; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp36 = A_arbace_g2a_lit_A_const_35; tmp33.Invoke_O__O(tmp35.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 6)).Ref()))); i__5 = lang.Numbers_Add_J_J__J(i__5, 6); continue L1
//line :253:1
															break L2 }; case 118: var tmp37 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp38 any; A_arbace_g2a_lit_A_Init(); tmp38 = A_arbace_g2a_lit_A_const_84; if lang.Util_Equiv_O_O__Z(tmp37, tmp38) {






																jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(11)); i__5 = lang.Numbers_Add_J_J__J(i__5, 2); continue L1
//line :253:1
																break L2 }; case 120: var tmp39 any = jrt.Character_ValueOf_C__Character(G__1426000068__8_).Ref(); var tmp40 any; A_arbace_g2a_lit_A_Init(); tmp40 = A_arbace_g2a_lit_A_const_85; if lang.Util_Equiv_O_O__Z(tmp39, tmp40) {










																	var tmp41 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp42 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp42 = A_arbace_g2a_lit_A_const_76; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp44 = A_arbace_g2a_lit_A_const_35; jrt.NN(tmp41).Write_I__V(lang.RT_IntCast_O__I(tmp43.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 4)).Ref())))); i__5 = lang.Numbers_Add_J_J__J(i__5, 4); continue L1
//line :253:1
																	break L2 }; default:
				}












					var tmp45 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp46 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp46 = A_arbace_g2a_lit_A_const_35; jrt.NN(tmp45).Write_I__V(lang.RT_IntCast_J__I(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(i__5)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(i__5, 4)).Ref())), lang.RT_IntCast_J__I(8))))
					i__5 = lang.Numbers_Add_J_J__J(i__5, 4); continue L1} } }
//line :237:1
		break L1 }; return out__2 }




func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_New_O(p0 any) *A_arbace_g2a_lit_unescape_put_cp__1426000066_A { A_arbace_g2a_lit_unescape_put_cp__1426000066_A_Init(); t := &A_arbace_g2a_lit_unescape_put_cp__1426000066_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :242:1
func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) Invoke_O_O__O(self, cp__1 any) any { var bs__2 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1(lang.RT_IntCast_O__I(cp__1))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(t.F_out);

	jrt.NN(tmp1).Write_B1_I_I__V(jrt.A2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))); return nil }


























func A_arbace_g2a_lit_string_bytes_A_New() *A_arbace_g2a_lit_string_bytes_A { A_arbace_g2a_lit_string_bytes_A_Init(); t := &A_arbace_g2a_lit_string_bytes_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_g2a_lit_string_bytes_A) Ctor() {}
//line :271:1
func (t *A_arbace_g2a_lit_string_bytes_A) Invoke_O_O__O(self, text__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(text__0, Lit_167)) {
		var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_29; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_35; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_38; var tmp7 any = tmp6; return jrt.NN(jrt.String_Cast(tmp3.Invoke_O_O_O__O(tmp5.Invoke_O_O_O__O(text__0, tmp7, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(text__0)))).Ref()), Lit_168, Lit_141))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
			var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_86; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_35; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_38; var tmp13 any = tmp12; return jrt.NN(jrt.ByteArrayOutputStream_Cast(tmp9.Invoke_O__O(tmp11.Invoke_O_O_O__O(text__0, tmp13, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(text__0)))).Ref())))).ToByteArray__B1().Ref()
		} }
func A_arbace_g2a_lit_rune_value_A_New() *A_arbace_g2a_lit_rune_value_A { A_arbace_g2a_lit_rune_value_A_Init(); t := &A_arbace_g2a_lit_rune_value_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_g2a_lit_rune_value_A) Ctor() {}
//line :278:1
func (t *A_arbace_g2a_lit_rune_value_A) Invoke_O_O__O(self, text__0 any) any { var body__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_38; var tmp4 any = tmp3; body__2 = tmp2.Invoke_O_O_O__O(text__0, tmp4, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(text__0)))).Ref()); var tmp5 /*line :282:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_112)) { var G__1426000071__3_ uint16 = jrt.NN(jrt.String_Cast(body__2)).CharAt_I__C(lang.RT_IntCast_J__I(1))
		switch lang.Util_Hash_O__I(jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref()) { case 48: var tmp6 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp7 any; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_87; if lang.Util_Equiv_O_O__Z(tmp6, tmp7) {



			var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_35; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp9.Invoke_O_O__O(body__2, tmp10)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 49: var tmp11 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp12 any; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_88; if lang.Util_Equiv_O_O__Z(tmp11, tmp12) {



			var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_35; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp14.Invoke_O_O__O(body__2, tmp15)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 50: var tmp16 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp17 any; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_89; if lang.Util_Equiv_O_O__Z(tmp16, tmp17) {



			var tmp18 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_35; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_g2a_lit_A_Init(); tmp20 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp19.Invoke_O_O__O(body__2, tmp20)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 51: var tmp21 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp22 any; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_90; if lang.Util_Equiv_O_O__Z(tmp21, tmp22) {



			var tmp23 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp23 = A_arbace_g2a_lit_A_const_35; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_g2a_lit_A_Init(); tmp25 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp24.Invoke_O_O__O(body__2, tmp25)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 52: var tmp26 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp27 any; A_arbace_g2a_lit_A_Init(); tmp27 = A_arbace_g2a_lit_A_const_91; if lang.Util_Equiv_O_O__Z(tmp26, tmp27) {



			var tmp28 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_35; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp29.Invoke_O_O__O(body__2, tmp30)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 53: var tmp31 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp32 any; A_arbace_g2a_lit_A_Init(); tmp32 = A_arbace_g2a_lit_A_const_92; if lang.Util_Equiv_O_O__Z(tmp31, tmp32) {



			var tmp33 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp33 = A_arbace_g2a_lit_A_const_35; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_g2a_lit_A_Init(); tmp35 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp34.Invoke_O_O__O(body__2, tmp35)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 54: var tmp36 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp37 any; A_arbace_g2a_lit_A_Init(); tmp37 = A_arbace_g2a_lit_A_const_93; if lang.Util_Equiv_O_O__Z(tmp36, tmp37) {



			var tmp38 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp38 = A_arbace_g2a_lit_A_const_35; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_g2a_lit_A_Init(); tmp40 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp39.Invoke_O_O__O(body__2, tmp40)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 55: var tmp41 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp42 any; A_arbace_g2a_lit_A_Init(); tmp42 = A_arbace_g2a_lit_A_const_94; if lang.Util_Equiv_O_O__Z(tmp41, tmp42) {



			var tmp43 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp43 = A_arbace_g2a_lit_A_const_35; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 any; A_arbace_g2a_lit_A_Init(); tmp45 = A_arbace_g2a_lit_A_const_38; return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String_I__J(jrt.String_Cast(tmp44.Invoke_O_O__O(body__2, tmp45)), lang.RT_IntCast_J__I(8))).Ref() }
//line :283:1
		case 85: var tmp46 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp47 any; A_arbace_g2a_lit_A_Init(); tmp47 = A_arbace_g2a_lit_A_const_74; if lang.Util_Equiv_O_O__Z(tmp46, tmp47) {


			var tmp48 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp48 = A_arbace_g2a_lit_A_const_76; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp50 = A_arbace_g2a_lit_A_const_35; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_g2a_lit_A_Init(); tmp52 = A_arbace_g2a_lit_A_const_36; return tmp49.Invoke_O__O(tmp51.Invoke_O_O__O(body__2, tmp52)) }
//line :283:1
		case 117: var tmp53 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp54 any; A_arbace_g2a_lit_A_Init(); tmp54 = A_arbace_g2a_lit_A_const_83; if lang.Util_Equiv_O_O__Z(tmp53, tmp54) {

			var tmp55 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp55 = A_arbace_g2a_lit_A_const_76; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp57 = A_arbace_g2a_lit_A_const_35; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any; A_arbace_g2a_lit_A_Init(); tmp59 = A_arbace_g2a_lit_A_const_36; return tmp56.Invoke_O__O(tmp58.Invoke_O_O__O(body__2, tmp59)) }
//line :283:1
		case 120: var tmp60 any = jrt.Character_ValueOf_C__Character(G__1426000071__3_).Ref(); var tmp61 any; A_arbace_g2a_lit_A_Init(); tmp61 = A_arbace_g2a_lit_A_const_85; if lang.Util_Equiv_O_O__Z(tmp60, tmp61) {
			var tmp62 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp62 = A_arbace_g2a_lit_A_const_76; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp64 = A_arbace_g2a_lit_A_const_35; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 any; A_arbace_g2a_lit_A_Init(); tmp66 = A_arbace_g2a_lit_A_const_36; return tmp63.Invoke_O__O(tmp65.Invoke_O_O__O(body__2, tmp66)) }
//line :283:1
		default:}; var bs__4 any; var tmp67 *lang.Var




		A_arbace_g2a_lit_A_Init(); tmp67 = A_arbace_g2a_lit_A_const_86; bs__4 = jrt.NN(jrt.ByteArrayOutputStream_Cast(lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(body__2))).ToByteArray__B1().Ref()
		return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_B__J(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](bs__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0)))).Ref() } else {
			return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(jrt.NN(jrt.String_Cast(body__2)).CodePointAt_I__I(lang.RT_IntCast_J__I(0)))).Ref() } }

func A_arbace_g2a_lit_decode_rune_A_New() *A_arbace_g2a_lit_decode_rune_A { A_arbace_g2a_lit_decode_rune_A_Init(); t := &A_arbace_g2a_lit_decode_rune_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_g2a_lit_decode_rune_A) Ctor() {}
//line :292:1
func (t *A_arbace_g2a_lit_decode_rune_A) Invoke_O_O_O_O__O(self, bs__0, i__1, n__2 any) any { var b__4 any; var tmp1 any = A_arbace_g2a_lit_decode_rune_b__1426000073_A_New_O(bs__0); var tmp2 *jrt.Class;


	A_arbace_g2a_lit_decode_rune_b__1426000073_A_Init(); tmp2 = A_arbace_g2a_lit_decode_rune_b__1426000073_A_fn_class; b__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var cont_QMARK___5 any; var tmp3 any = /*line :292:1*/A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_New_O_O(n__2, b__4); var tmp4 *jrt.Class;



	A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_Init(); tmp4 = A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_fn_class; cont_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var b0__6 any = /*line :292:1*/lang.IFn_Cast(b__4).Invoke_O__O(i__1); if





	lang.Numbers_Lt_O_J__Z(b0__6, 128) { var tmp5 any; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_38; return lang.Tuple_Create_O_O__IPersistentVector(b0__6, tmp5) } else { if lang.Numbers_Lt_O_J__Z(b0__6, 194) { A_arbace_g2a_lit_A_Init(); return A_arbace_g2a_lit_A_const_95 } else { if lang.Numbers_Lt_O_J__Z(b0__6, 224) {


		if jrt.A2g_Truth(lang.IFn_Cast(cont_QMARK___5).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1))) { var tmp6 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(b0__6, 31), 6), lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1)), 63))).Ref(); var tmp7 any; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_36; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) } else { A_arbace_g2a_lit_A_Init(); return A_arbace_g2a_lit_A_const_96 } } else {
//line :298:1
			if lang.Numbers_Lt_O_J__Z(b0__6, 240) { var lo__7 int64; var G__1426000077__7_ int32 = lang.RT_IntCast_O__I(b0__6)





			L1: switch { default: switch G__1426000077__7_ { case 224: lo__7 = 160; break L1; default:}; lo__7 = 128}
//line :298:1
				var hi__8 int64; var G__1426000078__8_ int32 = lang.RT_IntCast_O__I(b0__6)






			L2: switch { default: switch G__1426000078__8_ { case 237: hi__8 = 159; break L2; default:}; hi__8 = 191}
				var tmp8 any; var and__1927000168__auto____9 bool = lang.Numbers_Lt_O_O__Z(lang.Numbers_Inc_O__Number(i__1), n__2); if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var tmp9 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_12; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O__O(jrt.Long_ValueOf_J__Long(lo__7).Ref(), lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1)), jrt.Long_ValueOf_J__Long(hi__8).Ref()); if jrt.A2g_Truth(and__1927000168__auto____10) { tmp8 = lang.IFn_Cast(cont_QMARK___5).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 2)) } else { tmp8 = and__1927000168__auto____10 } } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp8) { var tmp10 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(b0__6, 15), 12), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1)), 63), 6)), lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 2)), 63))).Ref(); var tmp11 any; A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_100; return lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) } else { A_arbace_g2a_lit_A_Init(); return A_arbace_g2a_lit_A_const_97 } } else {
//line :298:1
					if lang.Numbers_Lt_O_J__Z(b0__6, 245) { var lo__7_2 int64; var G__1426000079__7_ int32 = lang.RT_IntCast_O__I(b0__6)












					L3: switch { default: switch G__1426000079__7_ { case 240: lo__7_2 = 144; break L3; default:}; lo__7_2 = 128}
//line :298:1
						var hi__8_2 int64; var G__1426000080__8_ int32 = lang.RT_IntCast_O__I(b0__6)













					L4: switch { default: switch G__1426000080__8_ { case 244: hi__8_2 = 143; break L4; default:}; hi__8_2 = 191}
						var tmp12 any; var and__1927000168__auto____9_2 bool = lang.Numbers_Lt_O_O__Z(lang.Numbers_Inc_O__Number(i__1), n__2); if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_12; and__1927000168__auto____10_2 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O_O__O(jrt.Long_ValueOf_J__Long(lo__7_2).Ref(), lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1)), jrt.Long_ValueOf_J__Long(hi__8_2).Ref()); if jrt.A2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any = lang.IFn_Cast(cont_QMARK___5).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 2)); if jrt.A2g_Truth(and__1927000168__auto____11) { tmp12 = lang.IFn_Cast(cont_QMARK___5).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 3)) } else { tmp12 = and__1927000168__auto____11 } } else { tmp12 = and__1927000168__auto____10_2 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9_2).Ref() }; if jrt.A2g_Truth(tmp12) { var tmp14 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_Or_J_J__J(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(b0__6, 7), 18), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1)), 63), 12)), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 2)), 63), 6)), lang.Numbers_And_O_J__J(lang.IFn_Cast(b__4).Invoke_O__O(lang.Numbers_Add_O_J__Number(i__1, 3)), 63))).Ref(); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_101; return lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15) } else { A_arbace_g2a_lit_A_Init(); return A_arbace_g2a_lit_A_const_98 } } else {
//line :298:1
							var tmp16 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_21; if tmp16 != nil { A_arbace_g2a_lit_A_Init(); return A_arbace_g2a_lit_A_const_99 } else { return nil } } } } } } }
//line :295:1
func A_arbace_g2a_lit_decode_rune_b__1426000073_A_New_O(p0 any) *A_arbace_g2a_lit_decode_rune_b__1426000073_A { A_arbace_g2a_lit_decode_rune_b__1426000073_A_Init(); t := &A_arbace_g2a_lit_decode_rune_b__1426000073_A{}; t.Ctor_O(p0); return t }
//line :295:1
func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) Ctor_O(c__bs any) { t.F_bs = c__bs }
//line :295:1
func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(255, lang.RT_LongCast_B__J(lang.RT_Aget_B1_I__B(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(k__1)))))).Ref() }
func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_New_O_O(p0, p1 any) *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A { A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_Init(); t := &A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) Ctor_O_O(c__n, c__b any) { t.F_n = c__n; t.F_b = c__b }
//line :296:1
func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) Invoke_O_O__O(self, k__1 any) any { var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_O__Z(k__1, t.F_n); if and__1927000168__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(128, lang.Numbers_And_O_J__J(lang.IFn_Cast(t.F_b).Invoke_O__O(k__1), 192))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
























func A_arbace_g2a_lit_utf8_parts_A_New() *A_arbace_g2a_lit_utf8_parts_A { A_arbace_g2a_lit_utf8_parts_A_Init(); t := &A_arbace_g2a_lit_utf8_parts_A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_g2a_lit_utf8_parts_A) Ctor() {}
//line :321:1
func (t *A_arbace_g2a_lit_utf8_parts_A) Invoke_O_O__O(self, bs__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass())); var i__3 int64 = 0; var run__4 any = jrt.StringBuilder_New(); var parts__5 any; lang.PersistentVector_Init(); parts__5 = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_J_J__Z(i__3, int64(n__2)) {
		if lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) { var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_18; return tmp2.Invoke_O_O__O(parts__5, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(run__4)) } else { return parts__5 } } else {
//line :326:1
			var vec__1426000082__6 any; var tmp4 *lang.Var

			A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_102; vec__1426000082__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(bs__0, jrt.Long_ValueOf_J__Long(i__3).Ref(), jrt.Integer_ValueOf_I__Integer(n__2).Ref())
//line :326:1
			var r__7 any = lang.RT_Nth_O_I_O__O(vec__1426000082__6, lang.RT_IntCast_J__I(0), nil); var w__8 any = lang.RT_Nth_O_I_O__O(vec__1426000082__6, lang.RT_IntCast_J__I(1), nil)


			if lang.Numbers_IsNeg_J__Z(lang.RT_LongCast_O__J(r__7)) {
				var tmp5 int64 = lang.Numbers_Inc_J__J(i__3); var tmp6 any = jrt.StringBuilder_New(); var tmp7 any; var G__1426000085__9_ any = parts__5; var G__1426000085__10_ any
				if lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) {
					var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_6; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_18; G__1426000085__10_ = tmp9.Invoke_O_O__O(G__1426000085__9_, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(run__4)) } else {
//line :331:1
						G__1426000085__10_ = G__1426000085__9_ }; var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp11.Ref()) {

							var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_6; tmp7 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(G__1426000085__10_, jrt.Long_ValueOf_J__Long(lang.Numbers_And_J_J__J(255, lang.RT_LongCast_B__J(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(i__3)))))).Ref()) } else {
//line :331:1
								tmp7 = G__1426000085__10_ }
//line :330:1
				i__3, run__4, parts__5 = tmp5, tmp6, tmp7; continue L1 } else {



					i__3, run__4, parts__5 = lang.Numbers_Add_J_J__J(i__3, lang.RT_LongCast_O__J(w__8)), jrt.NN(jrt.StringBuilder_Cast(run__4)).AppendCodePoint_I__StringBuilder(lang.RT_IntCast_O__I(r__7)).Ref(), parts__5; continue L1 } } } }; /*line :321:1*/panic("a2g: unreachable") }














func A_arbace_g2a_lit_rune_form_A_New() *A_arbace_g2a_lit_rune_form_A { A_arbace_g2a_lit_rune_form_A_Init(); t := &A_arbace_g2a_lit_rune_form_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_g2a_lit_rune_form_A) Ctor() {}
//line :336:1
func (t *A_arbace_g2a_lit_rune_form_A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J(cp__0); var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var;




	A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_12; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_62; var tmp5 any = tmp4; var tmp6 any = jrt.Long_ValueOf_J__Long(cp__2).Ref(); var tmp7 any; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_104; and__1927000168__auto____3 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, tmp7); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_11; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_12; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_105; var tmp13 any = tmp12; var tmp14 any = jrt.Long_ValueOf_J__Long(cp__2).Ref(); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_106; tmp1 = tmp9.Invoke_O__O(tmp11.Invoke_O_O_O__O(tmp13, tmp14, tmp15)) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_33; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_107; return tmp17.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(cp__2).Ref()), jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(cp__2)).Ref()) } else {
			var tmp19 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_103; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_108; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp23 = A_arbace_g2a_lit_A_const_33; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; if lang.Numbers_IsNeg_J__Z(cp__2) { var tmp26 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp26 = A_arbace_g2a_lit_A_const_18; tmp25 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(cp__2).Ref()) } else { var tmp27 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp27 = A_arbace_g2a_lit_A_const_20; tmp25 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(Lit_164, jrt.Long_ValueOf_J__Long(cp__2).Ref()) }; return tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp25, jrt.Long_ValueOf_J__Long(cp__2).Ref())) } }

func A_arbace_g2a_lit_bytes_form_A_New() *A_arbace_g2a_lit_bytes_form_A { A_arbace_g2a_lit_bytes_form_A_Init(); t := &A_arbace_g2a_lit_bytes_form_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_g2a_lit_bytes_form_A) Ctor() {}
//line :345:1
func (t *A_arbace_g2a_lit_bytes_form_A) Invoke_O_O__O(self, bs__0 any) any { var parts__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_109; parts__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(bs__0); var tmp2 /*line :349:1*/*lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_110; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_112; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(jrt.NN(tmp4).GetRawRoot__O(), parts__2)) { var s__3 any; var tmp5 *lang.Var
		A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_111; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_18; s__3 = tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), parts__2); var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_33; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_113; return tmp9.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__3), s__3) } else {
			var tmp11 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_111; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_103; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 any; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_114; var tmp16 any = tmp15; var tmp17 any; var iter__1927001039__auto____3 any; var tmp18 any = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_New(); var tmp19 *jrt.Class
			A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_Init(); tmp19 = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); tmp17 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(parts__2)
//line :351:1
			return tmp12.Invoke_O_O_O__O(tmp14, tmp16, tmp17) } }
func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_New() *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_Init(); t := &A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) Ctor() {}
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) Invoke_O_O__O(self, s__1426000089__1 any) any { var tmp1 any = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_New_O_O(s__1426000089__1, self); var tmp2 *jrt.Class; A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_Init(); tmp2 = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :352:1
func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_New_O_O(p0, p1 any) *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_Init(); t := &A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) Ctor_O_O(c__s__1426000089, c__iter__1426000088 any) { t.F_s__1426000089 = c__s__1426000089; t.F_iter__1426000088 = c__iter__1426000088 }
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) Invoke_O__O(self any) any { { var s__1426000089__1 any; var t_ any = t.F_s__1426000089; t.F_s__1426000089 = nil; s__1426000089__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_22; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1426000089__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1426000089__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1426000089__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_24; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1426000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1426000091__6 any; var tmp4 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_115; b__1426000091__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_New_O_I_O(b__1426000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_Init(); tmp6 = A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_117; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_119; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1426000091__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1426000088); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_26; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1426000089__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_117; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_119; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1426000091__6), nil) } } else { var p__4 any; var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_25; p__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1426000089__3); var tmp17 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_118; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var tmp20 *lang.Var
														A_arbace_g2a_lit_A_Init(); tmp20 = A_arbace_g2a_lit_A_const_112; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(p__4)) { var tmp21 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_33; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp23 = A_arbace_g2a_lit_A_const_113; tmp19 = tmp22.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(p__4), p__4) } else { var tmp24 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_33; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp26 = A_arbace_g2a_lit_A_const_20; tmp19 = tmp25.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(Lit_109, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__4)).Ref()), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__4)).Ref()) }
//line :352:1
	var tmp27 any = tmp19; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__1426000088); var tmp29 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp29 = A_arbace_g2a_lit_A_const_120; return tmp18.Invoke_O_O__O(tmp27, tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(s__1426000089__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :352:1
func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_Init(); t := &A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) Ctor_O_I_O(c__b__1426000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1426000091 = c__b__1426000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) Invoke_O__O(self any) any { { var i__1426000090__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1426000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1426000090__1)); var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_116; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1426000091; var tmp5 any; var tmp6 *lang.Var
																A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_112; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p__2)) { var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_33; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_113; tmp5 = tmp8.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(p__2), p__2) } else { var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_33; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_20; tmp5 = tmp11.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(Lit_109, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__2)).Ref()), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__2)).Ref()) }
//line :352:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1426000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1426000090__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_g2a_lit_val_rational_A_New() *A_arbace_g2a_lit_val_rational_A { A_arbace_g2a_lit_val_rational_A_Init(); t := &A_arbace_g2a_lit_val_rational_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_g2a_lit_val_rational_A) Ctor() {}
//line :357:1
func (t *A_arbace_g2a_lit_val_rational_A) Invoke_O_O__O(self, v__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_121; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0)) { return v__0 } else { var tmp2 any; var and__1927000168__auto____2 any; var tmp3 *lang.Var

		A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp4 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_123; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_25; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(v__0)); if and__1927000168__auto____3 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(v__0)))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp2 = and__1927000168__auto____2 }
//line :360:1
		if jrt.A2g_Truth(tmp2) {

			var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_124; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(v__0) } else {
//line :360:1
				var tmp8 any; var and__1927000168__auto____2_2 any; var tmp9 *lang.Var


				A_arbace_g2a_lit_A_Init(); tmp9 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp10 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_123; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_25; tmp8 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp8 = and__1927000168__auto____2_2 }
//line :360:1
				if jrt.A2g_Truth(tmp8) { var vec__1426000099__2 any = v__0; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1426000099__2, lang.RT_IntCast_J__I(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O(vec__1426000099__2, lang.RT_IntCast_J__I(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O(vec__1426000099__2, lang.RT_IntCast_J__I(2), nil); var m__6 any; var tmp13 *lang.Var; _ = ___3




					A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_40; m__6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(m__4)
//line :360:1
					var e__7 int64 = lang.RT_LongCast_O__J(e__5)






					if lang.Numbers_IsNeg_J__Z(e__7) { var tmp14 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp14 = A_arbace_g2a_lit_A_const_61; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_63; return tmp15.Invoke_O_O__O(m__6, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(e__7)).Ref())) } else { var tmp17 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp17 = A_arbace_g2a_lit_A_const_61; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = jrt.NN(jrt.BigInteger_Cast(m__6)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I(e__7)).Ref(); var tmp20 *jrt.BigInteger; jrt.BigInteger_Init(); tmp20 = jrt.BigInteger_ONE; return tmp18.Invoke_O_O__O(tmp19, tmp20.Ref()) } } else {
//line :360:1
						var tmp21 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_21; if tmp21 != nil { var tmp22 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_125; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_184, nil); var tmp25 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp25 = A_arbace_g2a_lit_A_const_126; var tmp26 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var tmp27 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp27 = A_arbace_g2a_lit_A_const_127; panic(jrt.Thrown(jrt.Throwable_Cast(tmp23.Invoke_O_O__O(tmp26, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp27.Ref(), v__0)))))) } else { return nil
						}
					}
			}
	}
}




func A_arbace_g2a_lit_untyped_float_form_A_New() *A_arbace_g2a_lit_untyped_float_form_A { A_arbace_g2a_lit_untyped_float_form_A_Init(); t := &A_arbace_g2a_lit_untyped_float_form_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_g2a_lit_untyped_float_form_A) Ctor() {}
//line :370:1
func (t *A_arbace_g2a_lit_untyped_float_form_A) Invoke_O_O__O(self, v__0 any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp3 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp3 = A_arbace_g2a_lit_A_const_123; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_25; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(v__0)); if and__1927000168__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(3, int64(lang.RT_Count_O__I(v__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp6 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp6 = A_arbace_g2a_lit_A_const_103; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_128; var tmp9 any = tmp8; var tmp10 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_129; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(1))); var tmp12 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp12 = A_arbace_g2a_lit_A_const_129; return tmp7.Invoke_O_O_O__O(tmp9, tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(2)))) } else {
			var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_58; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_130; return tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(v__0))
		} }
func A_arbace_g2a_lit_const_form_A_New() *A_arbace_g2a_lit_const_form_A { A_arbace_g2a_lit_const_form_A_Init(); t := &A_arbace_g2a_lit_const_form_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_g2a_lit_const_form_A) Ctor() {}
//line :379:1
func (t *A_arbace_g2a_lit_const_form_A) Invoke_O_O_O__O(self, v__0, k__1 any) any { var k__3 any; var or__1927000174__auto____3 any = k__1; if




	jrt.A2g_Truth(or__1927000174__auto____3) { k__3 = or__1927000174__auto____3 } else {
		var tmp1 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp1 = A_arbace_g2a_lit_A_const_131; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0)) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_132.Ref() } else { var tmp2 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp2 = A_arbace_g2a_lit_A_const_112; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(v__0)) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_133.Ref() } else { var tmp3 any; var and__1927000168__auto____4 any; var tmp4 *lang.Var


			A_arbace_g2a_lit_A_Init(); tmp4 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp5 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp5 = A_arbace_g2a_lit_A_const_134; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp7 = A_arbace_g2a_lit_A_const_25; tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp3 = and__1927000168__auto____4 }
//line :385:1
			if jrt.A2g_Truth(tmp3) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_133.Ref() } else { var tmp8 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp8 = A_arbace_g2a_lit_A_const_121; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(v__0)) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_135.Ref() } else { var tmp9 any; var and__1927000168__auto____4_2 any; var tmp10 *lang.Var




				A_arbace_g2a_lit_A_Init(); tmp10 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____4_2 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____4_2) { var tmp11 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp11 = A_arbace_g2a_lit_A_const_123; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp13 = A_arbace_g2a_lit_A_const_25; tmp9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp9 = and__1927000168__auto____4_2 }
//line :385:1
				if jrt.A2g_Truth(tmp9) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_123.Ref() } else { var tmp14 any; var and__1927000168__auto____4_3 any; var tmp15 *lang.Var





					A_arbace_g2a_lit_A_Init(); tmp15 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____4_3 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____4_3) { var tmp16 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp16 = A_arbace_g2a_lit_A_const_136; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp18 = A_arbace_g2a_lit_A_const_25; tmp14 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp14 = and__1927000168__auto____4_3 }
//line :385:1
					if jrt.A2g_Truth(tmp14) { A_arbace_g2a_lit_A_Init(); k__3 = A_arbace_g2a_lit_A_const_136.Ref() } else { k__3 = nil } } } } } } }; var G__1426000104__4_ any = k__3; switch






	lang.Util_Hash_O__I(G__1426000104__4_) >> 7 & 15 { case 0: var tmp19 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp19 = A_arbace_g2a_lit_A_const_137; if any(G__1426000104__4_) == any(tmp19.Ref()) {










		var tmp20 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp20 = A_arbace_g2a_lit_A_const_138; return lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(v__0) }
//line :392:1
	case 3: var tmp21 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp21 = A_arbace_g2a_lit_A_const_132; if any(G__1426000104__4_) == any(tmp21.Ref()) {
		var tmp22 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp22 = A_arbace_g2a_lit_A_const_33; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp24 = A_arbace_g2a_lit_A_const_18; return tmp23.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(v__0), v__0) }
//line :392:1
	case 4: var tmp25 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp25 = A_arbace_g2a_lit_A_const_139; if any(G__1426000104__4_) == any(tmp25.Ref()) { var vec__1426000105__5 any; var tmp26 any; var and__1927000168__auto____5 any; var tmp27 *lang.Var












		A_arbace_g2a_lit_A_Init(); tmp27 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp28 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp28 = A_arbace_g2a_lit_A_const_136; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp30 = A_arbace_g2a_lit_A_const_25; tmp26 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp29, lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp26 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp26) { vec__1426000105__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(1)), lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(2))) } else { var tmp31 any; A_arbace_g2a_lit_A_Init(); tmp31 = A_arbace_g2a_lit_A_const_62; vec__1426000105__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, tmp31) }
//line :392:1
		var re__6 any = lang.RT_Nth_O_I_O__O(vec__1426000105__5, lang.RT_IntCast_J__I(0), nil); var im__7 any = lang.RT_Nth_O_I_O__O(vec__1426000105__5, lang.RT_IntCast_J__I(1), nil); var vec__1426000108__8 any; var tmp32 *lang.Keyword















		A_arbace_g2a_lit_A_Init(); tmp32 = A_arbace_g2a_lit_A_const_136; if lang.Util_Equiv_O_O__Z(k__3, tmp32.Ref()) { var tmp33 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp33 = A_arbace_g2a_lit_A_const_130; var tmp34 any = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(re__6); var tmp35 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp35 = A_arbace_g2a_lit_A_const_130; vec__1426000108__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp34, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(im__7)) } else { vec__1426000108__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6, im__7) }
//line :392:1
		var re__9 any = lang.RT_Nth_O_I_O__O(vec__1426000108__8, lang.RT_IntCast_J__I(0), nil); var im__10 any = lang.RT_Nth_O_I_O__O(vec__1426000108__8, lang.RT_IntCast_J__I(1), nil); var f__11 any; var tmp36 *lang.Keyword
















		A_arbace_g2a_lit_A_Init(); tmp36 = A_arbace_g2a_lit_A_const_136; if lang.Util_Equiv_O_O__Z(k__3, tmp36.Ref()) { var tmp37 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp37 = A_arbace_g2a_lit_A_const_140; f__11 = jrt.NN(tmp37).GetRawRoot__O() } else { var tmp38 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp38 = A_arbace_g2a_lit_A_const_138; f__11 = jrt.NN(tmp38).GetRawRoot__O() }
		var tmp39 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp39 = A_arbace_g2a_lit_A_const_103; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_g2a_lit_A_Init(); tmp41 = A_arbace_g2a_lit_A_const_143; var tmp42 any = tmp41; return tmp40.Invoke_O_O_O__O(tmp42, lang.IFn_Cast(f__11).Invoke_O__O(re__9), lang.IFn_Cast(f__11).Invoke_O__O(im__10)) }
//line :392:1
	case 5: var tmp43 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp43 = A_arbace_g2a_lit_A_const_141; if any(G__1426000104__4_) == any(tmp43.Ref()) {








		var tmp44 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp44 = A_arbace_g2a_lit_A_const_142; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp46 = A_arbace_g2a_lit_A_const_130; return tmp45.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(v__0)) }
//line :392:1
	case 8: var tmp47 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp47 = A_arbace_g2a_lit_A_const_136; if any(G__1426000104__4_) == any(tmp47.Ref()) { var vec__1426000111__5 any; var tmp48 any; var and__1927000168__auto____5_2 any; var tmp49 *lang.Var












		A_arbace_g2a_lit_A_Init(); tmp49 = A_arbace_g2a_lit_A_const_122; and__1927000168__auto____5_2 = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____5_2) { var tmp50 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp50 = A_arbace_g2a_lit_A_const_136; var tmp51 any = tmp50.Ref(); var tmp52 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp52 = A_arbace_g2a_lit_A_const_25; tmp48 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp51, lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp48 = and__1927000168__auto____5_2 }; if jrt.A2g_Truth(tmp48) { vec__1426000111__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(1)), lang.RT_Nth_O_I__O(v__0, lang.RT_IntCast_J__I(2))) } else { var tmp53 any; A_arbace_g2a_lit_A_Init(); tmp53 = A_arbace_g2a_lit_A_const_62; vec__1426000111__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, tmp53) }
//line :392:1
		var re__6_2 any = lang.RT_Nth_O_I_O__O(vec__1426000111__5, lang.RT_IntCast_J__I(0), nil); var im__7_2 any = lang.RT_Nth_O_I_O__O(vec__1426000111__5, lang.RT_IntCast_J__I(1), nil); var vec__1426000114__8 any; var tmp54 *lang.Keyword















		A_arbace_g2a_lit_A_Init(); tmp54 = A_arbace_g2a_lit_A_const_136; if lang.Util_Equiv_O_O__Z(k__3, tmp54.Ref()) { var tmp55 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp55 = A_arbace_g2a_lit_A_const_130; var tmp56 any = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(re__6_2); var tmp57 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp57 = A_arbace_g2a_lit_A_const_130; vec__1426000114__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp56, lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(im__7_2)) } else { vec__1426000114__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6_2, im__7_2) }
//line :392:1
		var re__9_2 any = lang.RT_Nth_O_I_O__O(vec__1426000114__8, lang.RT_IntCast_J__I(0), nil); var im__10_2 any = lang.RT_Nth_O_I_O__O(vec__1426000114__8, lang.RT_IntCast_J__I(1), nil); var f__11_2 any; var tmp58 *lang.Keyword
















		A_arbace_g2a_lit_A_Init(); tmp58 = A_arbace_g2a_lit_A_const_136; if lang.Util_Equiv_O_O__Z(k__3, tmp58.Ref()) { var tmp59 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp59 = A_arbace_g2a_lit_A_const_140; f__11_2 = jrt.NN(tmp59).GetRawRoot__O() } else { var tmp60 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp60 = A_arbace_g2a_lit_A_const_138; f__11_2 = jrt.NN(tmp60).GetRawRoot__O() }
		var tmp61 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp61 = A_arbace_g2a_lit_A_const_103; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any; A_arbace_g2a_lit_A_Init(); tmp63 = A_arbace_g2a_lit_A_const_143; var tmp64 any = tmp63; return tmp62.Invoke_O_O_O__O(tmp64, lang.IFn_Cast(f__11_2).Invoke_O__O(re__9_2), lang.IFn_Cast(f__11_2).Invoke_O__O(im__10_2)) }
//line :392:1
	case 9: var tmp65 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp65 = A_arbace_g2a_lit_A_const_123; if any(G__1426000104__4_) == any(tmp65.Ref()) {









		var tmp66 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp66 = A_arbace_g2a_lit_A_const_140; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp68 = A_arbace_g2a_lit_A_const_130; return tmp67.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(v__0)) }
//line :392:1
	case 12: var tmp69 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp69 = A_arbace_g2a_lit_A_const_135; if any(G__1426000104__4_) == any(tmp69.Ref()) { var r__5 any; var tmp70 *lang.Var




		A_arbace_g2a_lit_A_Init(); tmp70 = A_arbace_g2a_lit_A_const_130; r__5 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(v__0)
		var tmp71 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp71 = A_arbace_g2a_lit_A_const_121; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(r__5)) {
			var tmp72 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp72 = A_arbace_g2a_lit_A_const_129; return lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(r__5) } else {
//line :398:1
				var tmp73 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp73 = A_arbace_g2a_lit_A_const_125; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_115, nil); var tmp76 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp76 = A_arbace_g2a_lit_A_const_126; var tmp77 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp75, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var tmp78 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp78 = A_arbace_g2a_lit_A_const_127; panic(jrt.Thrown(jrt.Throwable_Cast(tmp74.Invoke_O_O__O(tmp77, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp78.Ref(), v__0)))))) } }
//line :392:1
	case 15: var tmp79 *lang.Keyword; A_arbace_g2a_lit_A_Init(); tmp79 = A_arbace_g2a_lit_A_const_133; if any(G__1426000104__4_) == any(tmp79.Ref()) {

		var tmp80 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp80 = A_arbace_g2a_lit_A_const_112; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(v__0)) {
			var tmp81 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp81 = A_arbace_g2a_lit_A_const_33; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp83 = A_arbace_g2a_lit_A_const_113; return tmp82.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(v__0), v__0) } else {
				var tmp84 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp84 = A_arbace_g2a_lit_A_const_144; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp86 = A_arbace_g2a_lit_A_const_145; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp88 = A_arbace_g2a_lit_A_const_146; var tmp89 any = jrt.NN(tmp88).GetRawRoot__O(); var tmp90 *lang.Var; A_arbace_g2a_lit_A_Init(); tmp90 = A_arbace_g2a_lit_A_const_124; return tmp85.Invoke_O__O(lang.Numbers_Byte_array_O__B1(tmp87.Invoke_O_O__O(tmp89, lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } }
//line :392:1
	default:}; return nil }
//line :390:1
type A_arbace_g2a_lit_A struct{ jrt.Object }

var A_arbace_g2a_lit_A_const_0 *lang.Var

var A_arbace_g2a_lit_A_const_1 *lang.Var

var A_arbace_g2a_lit_A_const_2 any

var A_arbace_g2a_lit_A_const_3 any

var A_arbace_g2a_lit_A_const_4 *lang.Var

var A_arbace_g2a_lit_A_const_5 *lang.Var

var A_arbace_g2a_lit_A_const_6 *lang.Var

var A_arbace_g2a_lit_A_const_7 any

var A_arbace_g2a_lit_A_const_8 *lang.Var

var A_arbace_g2a_lit_A_const_9 *lang.Var

var A_arbace_g2a_lit_A_const_10 *lang.Var

var A_arbace_g2a_lit_A_const_11 *lang.Var

var A_arbace_g2a_lit_A_const_12 *lang.Var

var A_arbace_g2a_lit_A_const_13 *lang.Var

var A_arbace_g2a_lit_A_const_14 any

var A_arbace_g2a_lit_A_const_15 any

var A_arbace_g2a_lit_A_const_16 any

var A_arbace_g2a_lit_A_const_17 any

var A_arbace_g2a_lit_A_const_18 *lang.Var

var A_arbace_g2a_lit_A_const_19 *lang.Var

var A_arbace_g2a_lit_A_const_20 *lang.Var

var A_arbace_g2a_lit_A_const_21 *lang.Keyword

var A_arbace_g2a_lit_A_const_22 *lang.Var

var A_arbace_g2a_lit_A_const_23 *lang.Var

var A_arbace_g2a_lit_A_const_24 *lang.Var

var A_arbace_g2a_lit_A_const_25 *lang.Var

var A_arbace_g2a_lit_A_const_26 *lang.Var

var A_arbace_g2a_lit_A_const_27 *lang.Var

var A_arbace_g2a_lit_A_const_28 *lang.Var

var A_arbace_g2a_lit_A_const_29 *lang.Var

var A_arbace_g2a_lit_A_const_30 *lang.Var

var A_arbace_g2a_lit_A_const_31 *lang.Var

var A_arbace_g2a_lit_A_const_32 *lang.Var

var A_arbace_g2a_lit_A_const_33 *lang.Var

var A_arbace_g2a_lit_A_const_34 any

var A_arbace_g2a_lit_A_const_35 *lang.Var

var A_arbace_g2a_lit_A_const_36 any

var A_arbace_g2a_lit_A_const_37 any

var A_arbace_g2a_lit_A_const_38 any

var A_arbace_g2a_lit_A_const_39 any

var A_arbace_g2a_lit_A_const_40 *lang.Var

var A_arbace_g2a_lit_A_const_41 *lang.Var

var A_arbace_g2a_lit_A_const_42 any

var A_arbace_g2a_lit_A_const_43 *lang.Var

var A_arbace_g2a_lit_A_const_44 *lang.Var

var A_arbace_g2a_lit_A_const_45 *lang.Var

var A_arbace_g2a_lit_A_const_46 *lang.Var

var A_arbace_g2a_lit_A_const_47 *lang.Var

var A_arbace_g2a_lit_A_const_48 *lang.Var

var A_arbace_g2a_lit_A_const_49 *lang.Var

var A_arbace_g2a_lit_A_const_50 *lang.Var

var A_arbace_g2a_lit_A_const_51 *lang.Keyword

var A_arbace_g2a_lit_A_const_52 *lang.Var

var A_arbace_g2a_lit_A_const_53 *lang.Var

var A_arbace_g2a_lit_A_const_54 *lang.Var

var A_arbace_g2a_lit_A_const_55 *lang.Var

var A_arbace_g2a_lit_A_const_56 *lang.Var

var A_arbace_g2a_lit_A_const_57 *jrt.Class

var A_arbace_g2a_lit_A_const_58 *lang.Var

var A_arbace_g2a_lit_A_const_59 *lang.Var

var A_arbace_g2a_lit_A_const_60 *lang.Var

var A_arbace_g2a_lit_A_const_61 *lang.Var

var A_arbace_g2a_lit_A_const_62 any

var A_arbace_g2a_lit_A_const_63 *lang.Var

var A_arbace_g2a_lit_A_const_64 *lang.Var

var A_arbace_g2a_lit_A_const_65 *lang.Var

var A_arbace_g2a_lit_A_const_66 *lang.Var

var A_arbace_g2a_lit_A_const_67 *lang.Var

var A_arbace_g2a_lit_A_const_68 *lang.Var

var A_arbace_g2a_lit_A_const_69 any

var A_arbace_g2a_lit_A_const_70 any

var A_arbace_g2a_lit_A_const_71 *lang.Var

var A_arbace_g2a_lit_A_const_72 any

var A_arbace_g2a_lit_A_const_73 any

var A_arbace_g2a_lit_A_const_74 any

var A_arbace_g2a_lit_A_const_75 any

var A_arbace_g2a_lit_A_const_76 *lang.Var

var A_arbace_g2a_lit_A_const_77 any

var A_arbace_g2a_lit_A_const_78 any

var A_arbace_g2a_lit_A_const_79 any

var A_arbace_g2a_lit_A_const_80 any

var A_arbace_g2a_lit_A_const_81 any

var A_arbace_g2a_lit_A_const_82 any

var A_arbace_g2a_lit_A_const_83 any

var A_arbace_g2a_lit_A_const_84 any

var A_arbace_g2a_lit_A_const_85 any

var A_arbace_g2a_lit_A_const_86 *lang.Var

var A_arbace_g2a_lit_A_const_87 any

var A_arbace_g2a_lit_A_const_88 any

var A_arbace_g2a_lit_A_const_89 any

var A_arbace_g2a_lit_A_const_90 any

var A_arbace_g2a_lit_A_const_91 any

var A_arbace_g2a_lit_A_const_92 any

var A_arbace_g2a_lit_A_const_93 any

var A_arbace_g2a_lit_A_const_94 any

var A_arbace_g2a_lit_A_const_95 any

var A_arbace_g2a_lit_A_const_96 any

var A_arbace_g2a_lit_A_const_97 any

var A_arbace_g2a_lit_A_const_98 any

var A_arbace_g2a_lit_A_const_99 any

var A_arbace_g2a_lit_A_const_100 any

var A_arbace_g2a_lit_A_const_101 any

var A_arbace_g2a_lit_A_const_102 *lang.Var

var A_arbace_g2a_lit_A_const_103 *lang.Var

var A_arbace_g2a_lit_A_const_104 any

var A_arbace_g2a_lit_A_const_105 any

var A_arbace_g2a_lit_A_const_106 any

var A_arbace_g2a_lit_A_const_107 *lang.Var

var A_arbace_g2a_lit_A_const_108 any

var A_arbace_g2a_lit_A_const_109 *lang.Var

var A_arbace_g2a_lit_A_const_110 *lang.Var

var A_arbace_g2a_lit_A_const_111 *lang.Var

var A_arbace_g2a_lit_A_const_112 *lang.Var

var A_arbace_g2a_lit_A_const_113 *lang.Var

var A_arbace_g2a_lit_A_const_114 any

var A_arbace_g2a_lit_A_const_115 *lang.Var

var A_arbace_g2a_lit_A_const_116 *lang.Var

var A_arbace_g2a_lit_A_const_117 *lang.Var

var A_arbace_g2a_lit_A_const_118 *lang.Var

var A_arbace_g2a_lit_A_const_119 *lang.Var

var A_arbace_g2a_lit_A_const_120 *lang.Var

var A_arbace_g2a_lit_A_const_121 *lang.Var

var A_arbace_g2a_lit_A_const_122 *lang.Var

var A_arbace_g2a_lit_A_const_123 *lang.Keyword

var A_arbace_g2a_lit_A_const_124 *lang.Var

var A_arbace_g2a_lit_A_const_125 *lang.Var

var A_arbace_g2a_lit_A_const_126 *lang.Var

var A_arbace_g2a_lit_A_const_127 *lang.Keyword

var A_arbace_g2a_lit_A_const_128 any

var A_arbace_g2a_lit_A_const_129 *lang.Var

var A_arbace_g2a_lit_A_const_130 *lang.Var

var A_arbace_g2a_lit_A_const_131 *lang.Var

var A_arbace_g2a_lit_A_const_132 *lang.Keyword

var A_arbace_g2a_lit_A_const_133 *lang.Keyword

var A_arbace_g2a_lit_A_const_134 *lang.Keyword

var A_arbace_g2a_lit_A_const_135 *lang.Keyword

var A_arbace_g2a_lit_A_const_136 *lang.Keyword

var A_arbace_g2a_lit_A_const_137 *lang.Keyword

var A_arbace_g2a_lit_A_const_138 *lang.Var

var A_arbace_g2a_lit_A_const_139 *lang.Keyword

var A_arbace_g2a_lit_A_const_140 *lang.Var

var A_arbace_g2a_lit_A_const_141 *lang.Keyword

var A_arbace_g2a_lit_A_const_142 *lang.Var

var A_arbace_g2a_lit_A_const_143 any

var A_arbace_g2a_lit_A_const_144 *lang.Var

var A_arbace_g2a_lit_A_const_145 *lang.Var

var A_arbace_g2a_lit_A_const_146 *lang.Var

var A_arbace_g2a_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_A_Init() { if !A_arbace_g2a_lit_A_init.Done() { A_arbace_g2a_lit_A_init.Run(A_arbace_g2a_lit_A_clinit) } }

func A_arbace_g2a_lit_A_clinit() { A_arbace_g2a_lit_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_lit_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_lit_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_lit_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_g2a_lit_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_g2a_lit_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_g2a_lit_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_g2a_lit_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_g2a_lit_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_g2a_lit_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_g2a_lit_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_14); A_arbace_g2a_lit_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_g2a_lit_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_g2a_lit_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_lit_A_const_14 = jrt.Long_ValueOf_J__Long(55296).Ref(); A_arbace_g2a_lit_A_const_15 = jrt.Long_ValueOf_J__Long(57343).Ref(); A_arbace_g2a_lit_A_const_16 = jrt.Long_ValueOf_J__Long(65520).Ref(); A_arbace_g2a_lit_A_const_17 = jrt.Long_ValueOf_J__Long(65535).Ref(); A_arbace_g2a_lit_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_g2a_lit_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); A_arbace_g2a_lit_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_g2a_lit_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_g2a_lit_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_g2a_lit_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_g2a_lit_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_g2a_lit_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_g2a_lit_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_g2a_lit_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_g2a_lit_A_const_28 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_g2a_lit_A_const_29 = lang.RT_Var_String_String__Var(Lit_3, Lit_28); A_arbace_g2a_lit_A_const_30 = lang.RT_Var_String_String__Var(Lit_3, Lit_29); A_arbace_g2a_lit_A_const_31 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_g2a_lit_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_g2a_lit_A_const_33 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_g2a_lit_A_const_34 = jrt.Long_ValueOf_J__Long(16).Ref(); A_arbace_g2a_lit_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_g2a_lit_A_const_36 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_g2a_lit_A_const_37 = jrt.Long_ValueOf_J__Long(8).Ref(); A_arbace_g2a_lit_A_const_38 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_g2a_lit_A_const_39 = jrt.Long_ValueOf_J__Long(10).Ref(); A_arbace_g2a_lit_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_lit_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_35); A_arbace_g2a_lit_A_const_42 = jrt.Long_ValueOf_J__Long(5).Ref(); A_arbace_g2a_lit_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_g2a_lit_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_g2a_lit_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_g2a_lit_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_g2a_lit_A_const_47 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); A_arbace_g2a_lit_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_g2a_lit_A_const_49 = lang.RT_Var_String_String__Var(Lit_3, Lit_42); A_arbace_g2a_lit_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_g2a_lit_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_g2a_lit_A_const_52 = lang.RT_Var_String_String__Var(Lit_9, Lit_45); A_arbace_g2a_lit_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_46); A_arbace_g2a_lit_A_const_54 = lang.RT_Var_String_String__Var(Lit_9, Lit_47); A_arbace_g2a_lit_A_const_55 = lang.RT_Var_String_String__Var(Lit_9, Lit_48); A_arbace_g2a_lit_A_const_56 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); A_arbace_g2a_lit_A_const_57 = lang.RT_ClassForNameNonLoading_String__Class(Lit_50); A_arbace_g2a_lit_A_const_58 = lang.RT_Var_String_String__Var(Lit_9, Lit_51); A_arbace_g2a_lit_A_const_59 = lang.RT_Var_String_String__Var(Lit_3, Lit_52); A_arbace_g2a_lit_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_g2a_lit_A_const_61 = lang.RT_Var_String_String__Var(Lit_9, Lit_54); A_arbace_g2a_lit_A_const_62 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_g2a_lit_A_const_63 = lang.RT_Var_String_String__Var(Lit_9, Lit_55); A_arbace_g2a_lit_A_const_64 = lang.RT_Var_String_String__Var(Lit_9, Lit_56); A_arbace_g2a_lit_A_const_65 = lang.RT_Var_String_String__Var(Lit_9, Lit_57); A_arbace_g2a_lit_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_g2a_lit_A_const_67 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); A_arbace_g2a_lit_A_const_68 = lang.RT_Var_String_String__Var(Lit_9, Lit_60); A_arbace_g2a_lit_A_const_69 = jrt.Pattern_Compile_String__Pattern(Lit_61).Ref(); A_arbace_g2a_lit_A_const_70 = jrt.Pattern_Compile_String__Pattern(Lit_62).Ref(); A_arbace_g2a_lit_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_g2a_lit_A_const_72 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_g2a_lit_A_const_73 = jrt.Character_ValueOf_C__Character(39).Ref(); A_arbace_g2a_lit_A_const_74 = jrt.Character_ValueOf_C__Character(85).Ref(); A_arbace_g2a_lit_A_const_75 = jrt.Character_ValueOf_C__Character(92).Ref(); A_arbace_g2a_lit_A_const_76 = lang.RT_Var_String_String__Var(Lit_9, Lit_64); A_arbace_g2a_lit_A_const_77 = jrt.Character_ValueOf_C__Character(97).Ref(); A_arbace_g2a_lit_A_const_78 = jrt.Character_ValueOf_C__Character(98).Ref(); A_arbace_g2a_lit_A_const_79 = jrt.Character_ValueOf_C__Character(102).Ref(); A_arbace_g2a_lit_A_const_80 = jrt.Character_ValueOf_C__Character(110).Ref(); A_arbace_g2a_lit_A_const_81 = jrt.Character_ValueOf_C__Character(114).Ref(); A_arbace_g2a_lit_A_const_82 = jrt.Character_ValueOf_C__Character(116).Ref(); A_arbace_g2a_lit_A_const_83 = jrt.Character_ValueOf_C__Character(117).Ref(); A_arbace_g2a_lit_A_const_84 = jrt.Character_ValueOf_C__Character(118).Ref(); A_arbace_g2a_lit_A_const_85 = jrt.Character_ValueOf_C__Character(120).Ref(); A_arbace_g2a_lit_A_const_86 = lang.RT_Var_String_String__Var(Lit_9, Lit_65); A_arbace_g2a_lit_A_const_87 = jrt.Character_ValueOf_C__Character(48).Ref(); A_arbace_g2a_lit_A_const_88 = jrt.Character_ValueOf_C__Character(49).Ref(); A_arbace_g2a_lit_A_const_89 = jrt.Character_ValueOf_C__Character(50).Ref(); A_arbace_g2a_lit_A_const_90 = jrt.Character_ValueOf_C__Character(51).Ref(); A_arbace_g2a_lit_A_const_91 = jrt.Character_ValueOf_C__Character(52).Ref(); A_arbace_g2a_lit_A_const_92 = jrt.Character_ValueOf_C__Character(53).Ref(); A_arbace_g2a_lit_A_const_93 = jrt.Character_ValueOf_C__Character(54).Ref(); A_arbace_g2a_lit_A_const_94 = jrt.Character_ValueOf_C__Character(55).Ref(); A_arbace_g2a_lit_A_const_95 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(-1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref()); A_arbace_g2a_lit_A_const_96 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(-1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref()); A_arbace_g2a_lit_A_const_97 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(-1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref()); A_arbace_g2a_lit_A_const_98 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(-1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref()); A_arbace_g2a_lit_A_const_99 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(-1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref()); A_arbace_g2a_lit_A_const_100 = jrt.Long_ValueOf_J__Long(3).Ref(); A_arbace_g2a_lit_A_const_101 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_g2a_lit_A_const_102 = lang.RT_Var_String_String__Var(Lit_9, Lit_66); A_arbace_g2a_lit_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_g2a_lit_A_const_104 = jrt.Long_ValueOf_J__Long(65535).Ref(); A_arbace_g2a_lit_A_const_105 = jrt.Long_ValueOf_J__Long(55296).Ref(); A_arbace_g2a_lit_A_const_106 = jrt.Long_ValueOf_J__Long(57343).Ref(); A_arbace_g2a_lit_A_const_107 = lang.RT_Var_String_String__Var(Lit_9, Lit_68); A_arbace_g2a_lit_A_const_108 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_g2a_lit_A_const_109 = lang.RT_Var_String_String__Var(Lit_9, Lit_70); A_arbace_g2a_lit_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_g2a_lit_A_const_111 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_g2a_lit_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_g2a_lit_A_const_113 = lang.RT_Var_String_String__Var(Lit_9, Lit_74); A_arbace_g2a_lit_A_const_114 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref(); A_arbace_g2a_lit_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_g2a_lit_A_const_116 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_g2a_lit_A_const_117 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_g2a_lit_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_g2a_lit_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_g2a_lit_A_const_120 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_g2a_lit_A_const_121 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_g2a_lit_A_const_122 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_g2a_lit_A_const_123 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_g2a_lit_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_g2a_lit_A_const_125 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_g2a_lit_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_g2a_lit_A_const_127 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_g2a_lit_A_const_128 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(); A_arbace_g2a_lit_A_const_129 = lang.RT_Var_String_String__Var(Lit_9, Lit_90); A_arbace_g2a_lit_A_const_130 = lang.RT_Var_String_String__Var(Lit_9, Lit_91); A_arbace_g2a_lit_A_const_131 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_g2a_lit_A_const_132 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_g2a_lit_A_const_133 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_g2a_lit_A_const_134 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_g2a_lit_A_const_135 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_g2a_lit_A_const_136 = lang.RT_Keyword_String_String__Keyword(nil, Lit_97); A_arbace_g2a_lit_A_const_137 = lang.RT_Keyword_String_String__Keyword(nil, Lit_98); A_arbace_g2a_lit_A_const_138 = lang.RT_Var_String_String__Var(Lit_9, Lit_99); A_arbace_g2a_lit_A_const_139 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_g2a_lit_A_const_140 = lang.RT_Var_String_String__Var(Lit_9, Lit_101); A_arbace_g2a_lit_A_const_141 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_g2a_lit_A_const_142 = lang.RT_Var_String_String__Var(Lit_9, Lit_102); A_arbace_g2a_lit_A_const_143 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref(); A_arbace_g2a_lit_A_const_144 = lang.RT_Var_String_String__Var(Lit_9, Lit_103); A_arbace_g2a_lit_A_const_145 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_g2a_lit_A_const_146 = lang.RT_Var_String_String__Var(Lit_0, Lit_105) }

func A_arbace_g2a_lit_A_New() *A_arbace_g2a_lit_A { A_arbace_g2a_lit_A_Init(); t := &A_arbace_g2a_lit_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_lit_A) Ctor() {}

func (t *A_arbace_g2a_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_A_class }

func (t *A_arbace_g2a_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_A); return ok }

func A_arbace_g2a_lit_A_Cast(x any) *A_arbace_g2a_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_A_class)) }; return v }



type A_arbace_g2a_lit_bytes_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_bytes_form_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_bytes_form_A_fn_class *jrt.Class

var A_arbace_g2a_lit_bytes_form_A_init jrt.ClassInit

func A_arbace_g2a_lit_bytes_form_A_Init() { if !A_arbace_g2a_lit_bytes_form_A_init.Done() { A_arbace_g2a_lit_bytes_form_A_init.Run(A_arbace_g2a_lit_bytes_form_A_clinit) } }

func A_arbace_g2a_lit_bytes_form_A_clinit() { A_arbace_g2a_lit_bytes_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_bytes_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_bytes_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_bytes_form_A_class }

func (t *A_arbace_g2a_lit_bytes_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_bytes_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_bytes_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_bytes_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_bytes_form_A); return ok }

func A_arbace_g2a_lit_bytes_form_A_Cast(x any) *A_arbace_g2a_lit_bytes_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_bytes_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_bytes_form_A_class)) }; return v }



type A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_fn_class *jrt.Class

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_init jrt.ClassInit

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_Init() { if !A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_init.Done() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_init.Run(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_clinit) } }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_clinit() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A); return ok }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_Cast(x any) *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_A_class)) }; return v }



type A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A struct{ jrt.Object; F_s__1426000089, F_iter__1426000088 any }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_fn_class *jrt.Class

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_init jrt.ClassInit

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_Init() { if !A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_init.Done() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_init.Run(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_clinit) } }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_clinit() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A); return ok }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_Cast(x any) *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_A_class)) }; return v }



type A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A struct{ jrt.Object; F_b__1426000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_fn_class *jrt.Class

var A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_init jrt.ClassInit

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_Init() { if !A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_init.Done() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_init.Run(A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_clinit) } }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_clinit() { A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_class }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A); return ok }

func A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_Cast(x any) *A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_bytes_form_iter__1426000088__1426000092_fn__1426000093_fn__1426000094_A_class)) }; return v }



type A_arbace_g2a_lit_char_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_char_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_char_text_A_fn_class *jrt.Class

var A_arbace_g2a_lit_char_text_A_init jrt.ClassInit

func A_arbace_g2a_lit_char_text_A_Init() { if !A_arbace_g2a_lit_char_text_A_init.Done() { A_arbace_g2a_lit_char_text_A_init.Run(A_arbace_g2a_lit_char_text_A_clinit) } }

func A_arbace_g2a_lit_char_text_A_clinit() { A_arbace_g2a_lit_char_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_char_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_char_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_char_text_A_class }

func (t *A_arbace_g2a_lit_char_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_char_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_char_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_char_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_char_text_A); return ok }

func A_arbace_g2a_lit_char_text_A_Cast(x any) *A_arbace_g2a_lit_char_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_char_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_char_text_A_class)) }; return v }



type A_arbace_g2a_lit_const_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_const_form_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_lit_const_form_A_fn_class *jrt.Class

var A_arbace_g2a_lit_const_form_A_init jrt.ClassInit

func A_arbace_g2a_lit_const_form_A_Init() { if !A_arbace_g2a_lit_const_form_A_init.Done() { A_arbace_g2a_lit_const_form_A_init.Run(A_arbace_g2a_lit_const_form_A_clinit) } }

func A_arbace_g2a_lit_const_form_A_clinit() { A_arbace_g2a_lit_const_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_const_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_const_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_const_form_A_class }

func (t *A_arbace_g2a_lit_const_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_const_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_const_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_const_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_const_form_A); return ok }

func A_arbace_g2a_lit_const_form_A_Cast(x any) *A_arbace_g2a_lit_const_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_const_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_const_form_A_class)) }; return v }



type A_arbace_g2a_lit_decimal_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_decimal_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_decimal_text_A_fn_class *jrt.Class

var A_arbace_g2a_lit_decimal_text_A_init jrt.ClassInit

func A_arbace_g2a_lit_decimal_text_A_Init() { if !A_arbace_g2a_lit_decimal_text_A_init.Done() { A_arbace_g2a_lit_decimal_text_A_init.Run(A_arbace_g2a_lit_decimal_text_A_clinit) } }

func A_arbace_g2a_lit_decimal_text_A_clinit() { A_arbace_g2a_lit_decimal_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_decimal_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_decimal_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_decimal_text_A_class }

func (t *A_arbace_g2a_lit_decimal_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_decimal_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_decimal_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_decimal_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_decimal_text_A); return ok }

func A_arbace_g2a_lit_decimal_text_A_Cast(x any) *A_arbace_g2a_lit_decimal_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_decimal_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_decimal_text_A_class)) }; return v }



type A_arbace_g2a_lit_decode_rune_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_decode_rune_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_lit_decode_rune_A_fn_class *jrt.Class

var A_arbace_g2a_lit_decode_rune_A_init jrt.ClassInit

func A_arbace_g2a_lit_decode_rune_A_Init() { if !A_arbace_g2a_lit_decode_rune_A_init.Done() { A_arbace_g2a_lit_decode_rune_A_init.Run(A_arbace_g2a_lit_decode_rune_A_clinit) } }

func A_arbace_g2a_lit_decode_rune_A_clinit() { A_arbace_g2a_lit_decode_rune_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_decode_rune_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_decode_rune_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_decode_rune_A_class }

func (t *A_arbace_g2a_lit_decode_rune_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_decode_rune_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_decode_rune_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_decode_rune_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_decode_rune_A); return ok }

func A_arbace_g2a_lit_decode_rune_A_Cast(x any) *A_arbace_g2a_lit_decode_rune_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_decode_rune_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_decode_rune_A_class)) }; return v }



type A_arbace_g2a_lit_decode_rune_b__1426000073_A struct{ jrt.Object; F_bs any }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_decode_rune_b__1426000073_A_fn_class *jrt.Class

var A_arbace_g2a_lit_decode_rune_b__1426000073_A_init jrt.ClassInit

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_Init() { if !A_arbace_g2a_lit_decode_rune_b__1426000073_A_init.Done() { A_arbace_g2a_lit_decode_rune_b__1426000073_A_init.Run(A_arbace_g2a_lit_decode_rune_b__1426000073_A_clinit) } }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_clinit() { A_arbace_g2a_lit_decode_rune_b__1426000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_decode_rune_b__1426000073_A_class }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_decode_rune_b__1426000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_decode_rune_b__1426000073_A); return ok }

func A_arbace_g2a_lit_decode_rune_b__1426000073_A_Cast(x any) *A_arbace_g2a_lit_decode_rune_b__1426000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_decode_rune_b__1426000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_decode_rune_b__1426000073_A_class)) }; return v }



type A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A struct{ jrt.Object; F_n, F_b any }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_fn_class *jrt.Class

var A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_init jrt.ClassInit

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_Init() { if !A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_init.Done() { A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_init.Run(A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_clinit) } }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_clinit() { A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_class }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A); return ok }

func A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_Cast(x any) *A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_decode_rune_cont_QMARK___1426000075_A_class)) }; return v }



type A_arbace_g2a_lit_double_exact_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_double_exact_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_double_exact_text_A_fn_class *jrt.Class

var A_arbace_g2a_lit_double_exact_text_A_init jrt.ClassInit

func A_arbace_g2a_lit_double_exact_text_A_Init() { if !A_arbace_g2a_lit_double_exact_text_A_init.Done() { A_arbace_g2a_lit_double_exact_text_A_init.Run(A_arbace_g2a_lit_double_exact_text_A_clinit) } }

func A_arbace_g2a_lit_double_exact_text_A_clinit() { A_arbace_g2a_lit_double_exact_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_double_exact_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_double_exact_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_double_exact_text_A_class }

func (t *A_arbace_g2a_lit_double_exact_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_double_exact_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_double_exact_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_double_exact_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_double_exact_text_A); return ok }

func A_arbace_g2a_lit_double_exact_text_A_Cast(x any) *A_arbace_g2a_lit_double_exact_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_double_exact_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_double_exact_text_A_class)) }; return v }



type A_arbace_g2a_lit_double_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_double_lit_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_double_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_double_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_double_lit_A_Init() { if !A_arbace_g2a_lit_double_lit_A_init.Done() { A_arbace_g2a_lit_double_lit_A_init.Run(A_arbace_g2a_lit_double_lit_A_clinit) } }

func A_arbace_g2a_lit_double_lit_A_clinit() { A_arbace_g2a_lit_double_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_double_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_double_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_double_lit_A_class }

func (t *A_arbace_g2a_lit_double_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_double_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_double_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_double_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_double_lit_A); return ok }

func A_arbace_g2a_lit_double_lit_A_Cast(x any) *A_arbace_g2a_lit_double_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_double_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_double_lit_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000004_A struct{ jrt.Object }

func A_arbace_g2a_lit_eval1426000004_A_New() *A_arbace_g2a_lit_eval1426000004_A { t := &A_arbace_g2a_lit_eval1426000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_lit_eval1426000004_A) Ctor() {}

func (t *A_arbace_g2a_lit_eval1426000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000004_A_class }

func (t *A_arbace_g2a_lit_eval1426000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000004_A); return ok }

func A_arbace_g2a_lit_eval1426000004_A_Cast(x any) *A_arbace_g2a_lit_eval1426000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000004_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_fn_class *jrt.Class

var A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_init jrt.ClassInit

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_Init() { if !A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_init.Done() { A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_init.Run(A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_clinit) } }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_clinit() { A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_class }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A); return ok }

func A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_Cast(x any) *A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000004_loading__1927001464__auto____1426000005_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000008_A struct{ jrt.Object }

func A_arbace_g2a_lit_eval1426000008_A_New() *A_arbace_g2a_lit_eval1426000008_A { t := &A_arbace_g2a_lit_eval1426000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_lit_eval1426000008_A) Ctor() {}

func (t *A_arbace_g2a_lit_eval1426000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000008_A_class }

func (t *A_arbace_g2a_lit_eval1426000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000008_A); return ok }

func A_arbace_g2a_lit_eval1426000008_A_Cast(x any) *A_arbace_g2a_lit_eval1426000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000008_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000008_fn__1426000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_fn_class *jrt.Class

var A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_init jrt.ClassInit

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_Init() { if !A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_init.Done() { A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_init.Run(A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_clinit) } }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_clinit() { A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_class }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000008_fn__1426000009_A); return ok }

func A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_Cast(x any) *A_arbace_g2a_lit_eval1426000008_fn__1426000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000008_fn__1426000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000008_fn__1426000009_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000013_A struct{ jrt.Object }

func A_arbace_g2a_lit_eval1426000013_A_New() *A_arbace_g2a_lit_eval1426000013_A { t := &A_arbace_g2a_lit_eval1426000013_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_lit_eval1426000013_A) Ctor() {}

func (t *A_arbace_g2a_lit_eval1426000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000013_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000013_A_class }

func (t *A_arbace_g2a_lit_eval1426000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000013_A); return ok }

func A_arbace_g2a_lit_eval1426000013_A_Cast(x any) *A_arbace_g2a_lit_eval1426000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000013_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_fn_class *jrt.Class

var A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_init jrt.ClassInit

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_Init() { if !A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_init.Done() { A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_init.Run(A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_clinit) } }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_clinit() { A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_class }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A); return ok }

func A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_Cast(x any) *A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000013___GT_Lit__1426000023_A_class)) }; return v }



type A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_fn_class *jrt.Class

var A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_init jrt.ClassInit

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_Init() { if !A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_init.Done() { A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_init.Run(A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_clinit) } }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_clinit() { A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_class }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A); return ok }

func A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_Cast(x any) *A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_eval1426000013_map__GT_Lit__1426000025_A_class)) }; return v }



type A_arbace_g2a_lit_float_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_float_lit_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_g2a_lit_float_lit_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_float_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_float_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_float_lit_A_Init() { if !A_arbace_g2a_lit_float_lit_A_init.Done() { A_arbace_g2a_lit_float_lit_A_init.Run(A_arbace_g2a_lit_float_lit_A_clinit) } }

func A_arbace_g2a_lit_float_lit_A_clinit() { A_arbace_g2a_lit_float_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_float_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_float_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_float_lit_A_class }

func (t *A_arbace_g2a_lit_float_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_float_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_float_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_float_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_float_lit_A); return ok }

func A_arbace_g2a_lit_float_lit_A_Cast(x any) *A_arbace_g2a_lit_float_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_float_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_float_lit_A_class)) }; return v }



type A_arbace_g2a_lit_float_text_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_float_text_lit_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_float_text_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_float_text_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_float_text_lit_A_Init() { if !A_arbace_g2a_lit_float_text_lit_A_init.Done() { A_arbace_g2a_lit_float_text_lit_A_init.Run(A_arbace_g2a_lit_float_text_lit_A_clinit) } }

func A_arbace_g2a_lit_float_text_lit_A_clinit() { A_arbace_g2a_lit_float_text_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_float_text_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_float_text_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_float_text_lit_A_class }

func (t *A_arbace_g2a_lit_float_text_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_float_text_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_float_text_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_float_text_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_float_text_lit_A); return ok }

func A_arbace_g2a_lit_float_text_lit_A_Cast(x any) *A_arbace_g2a_lit_float_text_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_float_text_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_float_text_lit_A_class)) }; return v }



type A_arbace_g2a_lit_float_value_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_float_value_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_float_value_A_fn_class *jrt.Class

var A_arbace_g2a_lit_float_value_A_init jrt.ClassInit

func A_arbace_g2a_lit_float_value_A_Init() { if !A_arbace_g2a_lit_float_value_A_init.Done() { A_arbace_g2a_lit_float_value_A_init.Run(A_arbace_g2a_lit_float_value_A_clinit) } }

func A_arbace_g2a_lit_float_value_A_clinit() { A_arbace_g2a_lit_float_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_float_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_float_value_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_float_value_A_class }

func (t *A_arbace_g2a_lit_float_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_float_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_float_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_float_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_float_value_A); return ok }

func A_arbace_g2a_lit_float_value_A_Cast(x any) *A_arbace_g2a_lit_float_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_float_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_float_value_A_class)) }; return v }



type A_arbace_g2a_lit_hex_float_value_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_hex_float_value_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_hex_float_value_A_fn_class *jrt.Class

var A_arbace_g2a_lit_hex_float_value_A_init jrt.ClassInit

func A_arbace_g2a_lit_hex_float_value_A_Init() { if !A_arbace_g2a_lit_hex_float_value_A_init.Done() { A_arbace_g2a_lit_hex_float_value_A_init.Run(A_arbace_g2a_lit_hex_float_value_A_clinit) } }

func A_arbace_g2a_lit_hex_float_value_A_clinit() { A_arbace_g2a_lit_hex_float_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_hex_float_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_hex_float_value_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_hex_float_value_A_class }

func (t *A_arbace_g2a_lit_hex_float_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_hex_float_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_hex_float_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_hex_float_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_hex_float_value_A); return ok }

func A_arbace_g2a_lit_hex_float_value_A_Cast(x any) *A_arbace_g2a_lit_hex_float_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_hex_float_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_hex_float_value_A_class)) }; return v }



type A_arbace_g2a_lit_hexv_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_hexv_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_hexv_A_fn_class *jrt.Class

var A_arbace_g2a_lit_hexv_A_init jrt.ClassInit

func A_arbace_g2a_lit_hexv_A_Init() { if !A_arbace_g2a_lit_hexv_A_init.Done() { A_arbace_g2a_lit_hexv_A_init.Run(A_arbace_g2a_lit_hexv_A_clinit) } }

func A_arbace_g2a_lit_hexv_A_clinit() { A_arbace_g2a_lit_hexv_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_hexv_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_hexv_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_hexv_A_class }

func (t *A_arbace_g2a_lit_hexv_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_hexv_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_hexv_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_hexv_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_hexv_A); return ok }

func A_arbace_g2a_lit_hexv_A_Cast(x any) *A_arbace_g2a_lit_hexv_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_hexv_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_hexv_A_class)) }; return v }



type A_arbace_g2a_lit_imag_inner_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_imag_inner_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_imag_inner_A_fn_class *jrt.Class

var A_arbace_g2a_lit_imag_inner_A_init jrt.ClassInit

func A_arbace_g2a_lit_imag_inner_A_Init() { if !A_arbace_g2a_lit_imag_inner_A_init.Done() { A_arbace_g2a_lit_imag_inner_A_init.Run(A_arbace_g2a_lit_imag_inner_A_clinit) } }

func A_arbace_g2a_lit_imag_inner_A_clinit() { A_arbace_g2a_lit_imag_inner_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_imag_inner_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_imag_inner_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_imag_inner_A_class }

func (t *A_arbace_g2a_lit_imag_inner_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_imag_inner_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_imag_inner_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_imag_inner_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_imag_inner_A); return ok }

func A_arbace_g2a_lit_imag_inner_A_Cast(x any) *A_arbace_g2a_lit_imag_inner_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_imag_inner_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_imag_inner_A_class)) }; return v }



type A_arbace_g2a_lit_int_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_int_lit_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_int_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_int_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_int_lit_A_Init() { if !A_arbace_g2a_lit_int_lit_A_init.Done() { A_arbace_g2a_lit_int_lit_A_init.Run(A_arbace_g2a_lit_int_lit_A_clinit) } }

func A_arbace_g2a_lit_int_lit_A_clinit() { A_arbace_g2a_lit_int_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_int_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_int_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_int_lit_A_class }

func (t *A_arbace_g2a_lit_int_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_int_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_int_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_int_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_int_lit_A); return ok }

func A_arbace_g2a_lit_int_lit_A_Cast(x any) *A_arbace_g2a_lit_int_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_int_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_int_lit_A_class)) }; return v }



type A_arbace_g2a_lit_integer_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_integer_lit_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_integer_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_integer_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_integer_lit_A_Init() { if !A_arbace_g2a_lit_integer_lit_A_init.Done() { A_arbace_g2a_lit_integer_lit_A_init.Run(A_arbace_g2a_lit_integer_lit_A_clinit) } }

func A_arbace_g2a_lit_integer_lit_A_clinit() { A_arbace_g2a_lit_integer_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_integer_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_integer_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_integer_lit_A_class }

func (t *A_arbace_g2a_lit_integer_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_integer_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_integer_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_integer_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_integer_lit_A); return ok }

func A_arbace_g2a_lit_integer_lit_A_Cast(x any) *A_arbace_g2a_lit_integer_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_integer_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_integer_lit_A_class)) }; return v }



type A_arbace_g2a_lit_integer_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_integer_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_integer_text_A_fn_class *jrt.Class

var A_arbace_g2a_lit_integer_text_A_init jrt.ClassInit

func A_arbace_g2a_lit_integer_text_A_Init() { if !A_arbace_g2a_lit_integer_text_A_init.Done() { A_arbace_g2a_lit_integer_text_A_init.Run(A_arbace_g2a_lit_integer_text_A_clinit) } }

func A_arbace_g2a_lit_integer_text_A_clinit() { A_arbace_g2a_lit_integer_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_153, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_integer_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_integer_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_integer_text_A_class }

func (t *A_arbace_g2a_lit_integer_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_integer_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_integer_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_integer_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_integer_text_A); return ok }

func A_arbace_g2a_lit_integer_text_A_Cast(x any) *A_arbace_g2a_lit_integer_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_integer_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_integer_text_A_class)) }; return v }



type A_arbace_g2a_lit_lit_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_lit_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_lit_lit_A_fn_class *jrt.Class

var A_arbace_g2a_lit_lit_A_init jrt.ClassInit

func A_arbace_g2a_lit_lit_A_Init() { if !A_arbace_g2a_lit_lit_A_init.Done() { A_arbace_g2a_lit_lit_A_init.Run(A_arbace_g2a_lit_lit_A_clinit) } }

func A_arbace_g2a_lit_lit_A_clinit() { A_arbace_g2a_lit_lit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_lit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_lit_A_class }

func (t *A_arbace_g2a_lit_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_lit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_lit_A); return ok }

func A_arbace_g2a_lit_lit_A_Cast(x any) *A_arbace_g2a_lit_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_lit_A_class)) }; return v }



type A_arbace_g2a_lit_lit_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_lit_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_lit_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_lit_lit_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_lit_lit_QMARK__A_Init() { if !A_arbace_g2a_lit_lit_QMARK__A_init.Done() { A_arbace_g2a_lit_lit_QMARK__A_init.Run(A_arbace_g2a_lit_lit_QMARK__A_clinit) } }

func A_arbace_g2a_lit_lit_QMARK__A_clinit() { A_arbace_g2a_lit_lit_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_lit_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_lit_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_lit_QMARK__A_class }

func (t *A_arbace_g2a_lit_lit_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_lit_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_lit_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_lit_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_lit_QMARK__A); return ok }

func A_arbace_g2a_lit_lit_QMARK__A_Cast(x any) *A_arbace_g2a_lit_lit_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_lit_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_lit_QMARK__A_class)) }; return v }



type A_arbace_g2a_lit_num_den_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_num_den_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_num_den_A_fn_class *jrt.Class

var A_arbace_g2a_lit_num_den_A_init jrt.ClassInit

func A_arbace_g2a_lit_num_den_A_Init() { if !A_arbace_g2a_lit_num_den_A_init.Done() { A_arbace_g2a_lit_num_den_A_init.Run(A_arbace_g2a_lit_num_den_A_clinit) } }

func A_arbace_g2a_lit_num_den_A_clinit() { A_arbace_g2a_lit_num_den_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_num_den_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_num_den_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_num_den_A_class }

func (t *A_arbace_g2a_lit_num_den_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_num_den_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_num_den_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_num_den_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_num_den_A); return ok }

func A_arbace_g2a_lit_num_den_A_Cast(x any) *A_arbace_g2a_lit_num_den_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_num_den_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_num_den_A_class)) }; return v }



type A_arbace_g2a_lit_pow2_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_pow2_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_pow2_A_fn_class *jrt.Class

var A_arbace_g2a_lit_pow2_A_init jrt.ClassInit

func A_arbace_g2a_lit_pow2_A_Init() { if !A_arbace_g2a_lit_pow2_A_init.Done() { A_arbace_g2a_lit_pow2_A_init.Run(A_arbace_g2a_lit_pow2_A_clinit) } }

func A_arbace_g2a_lit_pow2_A_clinit() { A_arbace_g2a_lit_pow2_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_pow2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_pow2_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_pow2_A_class }

func (t *A_arbace_g2a_lit_pow2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_pow2_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_pow2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_pow2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_pow2_A); return ok }

func A_arbace_g2a_lit_pow2_A_Cast(x any) *A_arbace_g2a_lit_pow2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_pow2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_pow2_A_class)) }; return v }



type A_arbace_g2a_lit_pow5_exponent_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_pow5_exponent_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_pow5_exponent_A_fn_class *jrt.Class

var A_arbace_g2a_lit_pow5_exponent_A_init jrt.ClassInit

func A_arbace_g2a_lit_pow5_exponent_A_Init() { if !A_arbace_g2a_lit_pow5_exponent_A_init.Done() { A_arbace_g2a_lit_pow5_exponent_A_init.Run(A_arbace_g2a_lit_pow5_exponent_A_clinit) } }

func A_arbace_g2a_lit_pow5_exponent_A_clinit() { A_arbace_g2a_lit_pow5_exponent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_pow5_exponent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_pow5_exponent_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_pow5_exponent_A_class }

func (t *A_arbace_g2a_lit_pow5_exponent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_pow5_exponent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_pow5_exponent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_pow5_exponent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_pow5_exponent_A); return ok }

func A_arbace_g2a_lit_pow5_exponent_A_Cast(x any) *A_arbace_g2a_lit_pow5_exponent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_pow5_exponent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_pow5_exponent_A_class)) }; return v }



type A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A struct{ jrt.Object; F_d, F_five any }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_fn_class *jrt.Class

var A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_init jrt.ClassInit

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_Init() { if !A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_init.Done() { A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_init.Run(A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_clinit) } }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_clinit() { A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_class }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A); return ok }

func A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_Cast(x any) *A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_pow5_exponent_fn__1426000046_A_class)) }; return v }



type A_arbace_g2a_lit_printable_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_printable_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_printable_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_lit_printable_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_lit_printable_QMARK__A_Init() { if !A_arbace_g2a_lit_printable_QMARK__A_init.Done() { A_arbace_g2a_lit_printable_QMARK__A_init.Run(A_arbace_g2a_lit_printable_QMARK__A_clinit) } }

func A_arbace_g2a_lit_printable_QMARK__A_clinit() { A_arbace_g2a_lit_printable_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_printable_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_printable_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_printable_QMARK__A_class }

func (t *A_arbace_g2a_lit_printable_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_printable_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_printable_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_printable_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_printable_QMARK__A); return ok }

func A_arbace_g2a_lit_printable_QMARK__A_Cast(x any) *A_arbace_g2a_lit_printable_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_printable_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_printable_QMARK__A_class)) }; return v }



type A_arbace_g2a_lit_rational_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_rational_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_lit_rational_A_fn_class *jrt.Class

var A_arbace_g2a_lit_rational_A_init jrt.ClassInit

func A_arbace_g2a_lit_rational_A_Init() { if !A_arbace_g2a_lit_rational_A_init.Done() { A_arbace_g2a_lit_rational_A_init.Run(A_arbace_g2a_lit_rational_A_clinit) } }

func A_arbace_g2a_lit_rational_A_clinit() { A_arbace_g2a_lit_rational_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_rational_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_rational_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_rational_A_class }

func (t *A_arbace_g2a_lit_rational_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_rational_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_rational_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_rational_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_rational_A); return ok }

func A_arbace_g2a_lit_rational_A_Cast(x any) *A_arbace_g2a_lit_rational_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_rational_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_rational_A_class)) }; return v }



type A_arbace_g2a_lit_rune_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_rune_form_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_rune_form_A_fn_class *jrt.Class

var A_arbace_g2a_lit_rune_form_A_init jrt.ClassInit

func A_arbace_g2a_lit_rune_form_A_Init() { if !A_arbace_g2a_lit_rune_form_A_init.Done() { A_arbace_g2a_lit_rune_form_A_init.Run(A_arbace_g2a_lit_rune_form_A_clinit) } }

func A_arbace_g2a_lit_rune_form_A_clinit() { A_arbace_g2a_lit_rune_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_rune_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_rune_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_rune_form_A_class }

func (t *A_arbace_g2a_lit_rune_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_rune_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_rune_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_rune_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_rune_form_A); return ok }

func A_arbace_g2a_lit_rune_form_A_Cast(x any) *A_arbace_g2a_lit_rune_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_rune_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_rune_form_A_class)) }; return v }



type A_arbace_g2a_lit_rune_value_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_rune_value_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_rune_value_A_fn_class *jrt.Class

var A_arbace_g2a_lit_rune_value_A_init jrt.ClassInit

func A_arbace_g2a_lit_rune_value_A_Init() { if !A_arbace_g2a_lit_rune_value_A_init.Done() { A_arbace_g2a_lit_rune_value_A_init.Run(A_arbace_g2a_lit_rune_value_A_clinit) } }

func A_arbace_g2a_lit_rune_value_A_clinit() { A_arbace_g2a_lit_rune_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_rune_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_rune_value_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_rune_value_A_class }

func (t *A_arbace_g2a_lit_rune_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_rune_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_rune_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_rune_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_rune_value_A); return ok }

func A_arbace_g2a_lit_rune_value_A_Cast(x any) *A_arbace_g2a_lit_rune_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_rune_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_rune_value_A_class)) }; return v }



type A_arbace_g2a_lit_string_bytes_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_string_bytes_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_string_bytes_A_fn_class *jrt.Class

var A_arbace_g2a_lit_string_bytes_A_init jrt.ClassInit

func A_arbace_g2a_lit_string_bytes_A_Init() { if !A_arbace_g2a_lit_string_bytes_A_init.Done() { A_arbace_g2a_lit_string_bytes_A_init.Run(A_arbace_g2a_lit_string_bytes_A_clinit) } }

func A_arbace_g2a_lit_string_bytes_A_clinit() { A_arbace_g2a_lit_string_bytes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_string_bytes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_string_bytes_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_string_bytes_A_class }

func (t *A_arbace_g2a_lit_string_bytes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_string_bytes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_string_bytes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_string_bytes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_string_bytes_A); return ok }

func A_arbace_g2a_lit_string_bytes_A_Cast(x any) *A_arbace_g2a_lit_string_bytes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_string_bytes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_string_bytes_A_class)) }; return v }



type A_arbace_g2a_lit_string_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_string_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_string_text_A_fn_class *jrt.Class

var A_arbace_g2a_lit_string_text_A_init jrt.ClassInit

func A_arbace_g2a_lit_string_text_A_Init() { if !A_arbace_g2a_lit_string_text_A_init.Done() { A_arbace_g2a_lit_string_text_A_init.Run(A_arbace_g2a_lit_string_text_A_clinit) } }

func A_arbace_g2a_lit_string_text_A_clinit() { A_arbace_g2a_lit_string_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_string_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_string_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_string_text_A_class }

func (t *A_arbace_g2a_lit_string_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_string_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_string_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_string_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_string_text_A); return ok }

func A_arbace_g2a_lit_string_text_A_Cast(x any) *A_arbace_g2a_lit_string_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_string_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_string_text_A_class)) }; return v }



type A_arbace_g2a_lit_terminating_decimal_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_terminating_decimal_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_lit_terminating_decimal_A_fn_class *jrt.Class

var A_arbace_g2a_lit_terminating_decimal_A_init jrt.ClassInit

func A_arbace_g2a_lit_terminating_decimal_A_Init() { if !A_arbace_g2a_lit_terminating_decimal_A_init.Done() { A_arbace_g2a_lit_terminating_decimal_A_init.Run(A_arbace_g2a_lit_terminating_decimal_A_clinit) } }

func A_arbace_g2a_lit_terminating_decimal_A_clinit() { A_arbace_g2a_lit_terminating_decimal_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_terminating_decimal_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_terminating_decimal_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_terminating_decimal_A_class }

func (t *A_arbace_g2a_lit_terminating_decimal_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_terminating_decimal_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_terminating_decimal_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_terminating_decimal_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_terminating_decimal_A); return ok }

func A_arbace_g2a_lit_terminating_decimal_A_Cast(x any) *A_arbace_g2a_lit_terminating_decimal_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_terminating_decimal_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_terminating_decimal_A_class)) }; return v }



type A_arbace_g2a_lit_unescape_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_unescape_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_unescape_A_fn_class *jrt.Class

var A_arbace_g2a_lit_unescape_A_init jrt.ClassInit

func A_arbace_g2a_lit_unescape_A_Init() { if !A_arbace_g2a_lit_unescape_A_init.Done() { A_arbace_g2a_lit_unescape_A_init.Run(A_arbace_g2a_lit_unescape_A_clinit) } }

func A_arbace_g2a_lit_unescape_A_clinit() { A_arbace_g2a_lit_unescape_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_unescape_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_unescape_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_unescape_A_class }

func (t *A_arbace_g2a_lit_unescape_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_unescape_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_unescape_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_unescape_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_unescape_A); return ok }

func A_arbace_g2a_lit_unescape_A_Cast(x any) *A_arbace_g2a_lit_unescape_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_unescape_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_unescape_A_class)) }; return v }



type A_arbace_g2a_lit_unescape_put_cp__1426000066_A struct{ jrt.Object; F_out any }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_unescape_put_cp__1426000066_A_fn_class *jrt.Class

var A_arbace_g2a_lit_unescape_put_cp__1426000066_A_init jrt.ClassInit

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_Init() { if !A_arbace_g2a_lit_unescape_put_cp__1426000066_A_init.Done() { A_arbace_g2a_lit_unescape_put_cp__1426000066_A_init.Run(A_arbace_g2a_lit_unescape_put_cp__1426000066_A_clinit) } }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_clinit() { A_arbace_g2a_lit_unescape_put_cp__1426000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_unescape_put_cp__1426000066_A_class }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_unescape_put_cp__1426000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_unescape_put_cp__1426000066_A); return ok }

func A_arbace_g2a_lit_unescape_put_cp__1426000066_A_Cast(x any) *A_arbace_g2a_lit_unescape_put_cp__1426000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_unescape_put_cp__1426000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_unescape_put_cp__1426000066_A_class)) }; return v }



type A_arbace_g2a_lit_untyped_float_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_untyped_float_form_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_untyped_float_form_A_fn_class *jrt.Class

var A_arbace_g2a_lit_untyped_float_form_A_init jrt.ClassInit

func A_arbace_g2a_lit_untyped_float_form_A_Init() { if !A_arbace_g2a_lit_untyped_float_form_A_init.Done() { A_arbace_g2a_lit_untyped_float_form_A_init.Run(A_arbace_g2a_lit_untyped_float_form_A_clinit) } }

func A_arbace_g2a_lit_untyped_float_form_A_clinit() { A_arbace_g2a_lit_untyped_float_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_untyped_float_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_untyped_float_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_untyped_float_form_A_class }

func (t *A_arbace_g2a_lit_untyped_float_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_untyped_float_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_untyped_float_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_untyped_float_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_untyped_float_form_A); return ok }

func A_arbace_g2a_lit_untyped_float_form_A_Cast(x any) *A_arbace_g2a_lit_untyped_float_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_untyped_float_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_untyped_float_form_A_class)) }; return v }



type A_arbace_g2a_lit_utf8_parts_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_utf8_parts_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_utf8_parts_A_fn_class *jrt.Class

var A_arbace_g2a_lit_utf8_parts_A_init jrt.ClassInit

func A_arbace_g2a_lit_utf8_parts_A_Init() { if !A_arbace_g2a_lit_utf8_parts_A_init.Done() { A_arbace_g2a_lit_utf8_parts_A_init.Run(A_arbace_g2a_lit_utf8_parts_A_clinit) } }

func A_arbace_g2a_lit_utf8_parts_A_clinit() { A_arbace_g2a_lit_utf8_parts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_utf8_parts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_utf8_parts_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_utf8_parts_A_class }

func (t *A_arbace_g2a_lit_utf8_parts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_utf8_parts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_utf8_parts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_utf8_parts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_utf8_parts_A); return ok }

func A_arbace_g2a_lit_utf8_parts_A_Cast(x any) *A_arbace_g2a_lit_utf8_parts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_utf8_parts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_utf8_parts_A_class)) }; return v }



type A_arbace_g2a_lit_val_rational_A struct{ jrt.Object }

func (t *A_arbace_g2a_lit_val_rational_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_lit_val_rational_A_fn_class *jrt.Class

var A_arbace_g2a_lit_val_rational_A_init jrt.ClassInit

func A_arbace_g2a_lit_val_rational_A_Init() { if !A_arbace_g2a_lit_val_rational_A_init.Done() { A_arbace_g2a_lit_val_rational_A_init.Run(A_arbace_g2a_lit_val_rational_A_clinit) } }

func A_arbace_g2a_lit_val_rational_A_clinit() { A_arbace_g2a_lit_val_rational_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_lit_val_rational_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_lit_val_rational_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_lit_val_rational_A_class }

func (t *A_arbace_g2a_lit_val_rational_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_lit_val_rational_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_lit_val_rational_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_lit_val_rational_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_lit_val_rational_A); return ok }

func A_arbace_g2a_lit_val_rational_A_Cast(x any) *A_arbace_g2a_lit_val_rational_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_lit_val_rational_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_lit_val_rational_A_class)) }; return v }
