//line j2g_classes.ae:1
package aot_arbace_c_aotlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_aotlib__main_A_class, Name: "arbace.c.aotlib$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib__main_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_bytes_hex_A_class, Name: "arbace.c.aotlib$bytes_hex", Modifiers: 25, Simple: "bytes_hex", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_bytes_hex_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_c_compile_A_class, Name: "arbace.c.aotlib$c_compile", Modifiers: 25, Simple: "c_compile", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_c_compile_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_cache_root_A_class, Name: "arbace.c.aotlib$cache_root", Modifiers: 25, Simple: "cache_root", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_cache_root_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A_class, Name: "arbace.c.aotlib$eval1211000004$loading__1927001464__auto____1211000005", Modifiers: 25, Simple: "loading__1927001464__auto____1211000005", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_eval1211000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_eval1211000008_fn__1211000009_A_class, Name: "arbace.c.aotlib$eval1211000008$fn__1211000009", Modifiers: 25, Simple: "fn__1211000009", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_eval1211000008_fn__1211000009_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_eval1211000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_dir_name_A_class, Name: "arbace.c.aotlib$lib_dir_name", Modifiers: 25, Simple: "lib_dir_name", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_dir_name_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_key_A_class, Name: "arbace.c.aotlib$lib_key", Modifiers: 25, Simple: "lib_key", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_key_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_key_STAR__A_class, Name: "arbace.c.aotlib$lib_key_STAR_", Modifiers: 25, Simple: "lib_key_STAR_", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_key_STAR__A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_class, Name: "arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029", Modifiers: 25, Simple: "iter__1211000025__1211000029", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_lib_key_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_class, Name: "arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029$fn__1211000030", Modifiers: 25, Simple: "fn__1211000030", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_class, Name: "arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029$fn__1211000030$fn__1211000031", Modifiers: 25, Simple: "fn__1211000031", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_make_unit_A_class, Name: "arbace.c.aotlib$make_unit", Modifiers: 25, Simple: "make_unit", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_make_unit_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_make_unit_fn__1211000046_A_class, Name: "arbace.c.aotlib$make_unit$fn__1211000046", Modifiers: 25, Simple: "fn__1211000046", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_make_unit_fn__1211000046_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_make_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_make_unit_fn__1211000051_A_class, Name: "arbace.c.aotlib$make_unit$fn__1211000051", Modifiers: 25, Simple: "fn__1211000051", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_make_unit_fn__1211000051_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_make_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_A_class, Name: "arbace.c.aotlib$program_pre", Modifiers: 25, Simple: "program_pre", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_class, Name: "arbace.c.aotlib$program_pre$alias_of__1211000068", Modifiers: 25, Simple: "alias_of__1211000068", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_alias_of__1211000068_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_fn__1211000066_A_class, Name: "arbace.c.aotlib$program_pre$fn__1211000066", Modifiers: 25, Simple: "fn__1211000066", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_fn__1211000066_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000070__1211000074", Modifiers: 25, Simple: "iter__1211000070__1211000074", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000070__1211000074$fn__1211000075", Modifiers: 25, Simple: "fn__1211000075", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000070__1211000074$fn__1211000075$fn__1211000076", Modifiers: 25, Simple: "fn__1211000076", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000098__1211000102", Modifiers: 25, Simple: "iter__1211000098__1211000102", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000098__1211000102$fn__1211000103", Modifiers: 25, Simple: "fn__1211000103", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000098__1211000102$fn__1211000103$fn__1211000104", Modifiers: 25, Simple: "fn__1211000104", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124", Modifiers: 25, Simple: "iter__1211000120__1211000124", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125", Modifiers: 25, Simple: "fn__1211000125", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126", Modifiers: 25, Simple: "fn__1211000126", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126$fn__1211000133", Modifiers: 25, Simple: "fn__1211000133", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126$fn__1211000135", Modifiers: 25, Simple: "fn__1211000135", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000144", Modifiers: 25, Simple: "fn__1211000144", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_class, Name: "arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000146", Modifiers: 25, Simple: "fn__1211000146", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_secs_A_class, Name: "arbace.c.aotlib$secs", Modifiers: 25, Simple: "secs", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_secs_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_sha256_hex_A_class, Name: "arbace.c.aotlib$sha256_hex", Modifiers: 25, Simple: "sha256_hex", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_sha256_hex_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_A_class, Name: "arbace.c.aotlib$translate_lib", Modifiers: 25, Simple: "translate_lib", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156", Modifiers: 25, Simple: "iter__1211000152__1211000156", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157", Modifiers: 25, Simple: "fn__1211000157", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158", Modifiers: 25, Simple: "fn__1211000158", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158$fn__1211000159", Modifiers: 25, Simple: "fn__1211000159", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158$fn__1211000159$fn__1211000160", Modifiers: 25, Simple: "fn__1211000160", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000164", Modifiers: 25, Simple: "fn__1211000164", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_class, Name: "arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000164$fn__1211000165", Modifiers: 25, Simple: "fn__1211000165", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_unit_A_class, Name: "arbace.c.aotlib$unit", Modifiers: 25, Simple: "unit", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_unit_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_unit_fn__1211000054_A_class, Name: "arbace.c.aotlib$unit$fn__1211000054", Modifiers: 25, Simple: "fn__1211000054", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_unit_fn__1211000054_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_unit_pkg_A_class, Name: "arbace.c.aotlib$unit_pkg", Modifiers: 25, Simple: "unit_pkg", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_unit_pkg_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_aotlib_write_atomic_A_class, Name: "arbace.c.aotlib$write_atomic", Modifiers: 25, Simple: "write_atomic", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_write_atomic_A", Source: "aotlib.ae", Declaring: &A_arbace_c_aotlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_aotlib_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_aotlib_A_New()}; return nil }

var A_arbace_c_aotlib_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_aotlib_A_new}

var A_arbace_c_aotlib_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.aotlib", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_A"})

func init() { i := A_arbace_c_aotlib_A_class.Info(); i.IsInstance = A_arbace_c_aotlib_A_InstanceOf; i.Init = A_arbace_c_aotlib_A_Init; i.Table = A_arbace_c_aotlib_A_members }

var A_arbace_c_aotlib__main_A_class *jrt.Class

var A_arbace_c_aotlib_bytes_hex_A_class *jrt.Class

var A_arbace_c_aotlib_c_compile_A_class *jrt.Class

var A_arbace_c_aotlib_cache_root_A_class *jrt.Class

func A_arbace_c_aotlib_eval1211000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_aotlib_eval1211000004_A_New()}; return nil }

var A_arbace_c_aotlib_eval1211000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_aotlib_eval1211000004_A_new}

var A_arbace_c_aotlib_eval1211000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.aotlib$eval1211000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_aotlib_A_class, Simple: "eval1211000004", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_eval1211000004_A"})

func init() { i := A_arbace_c_aotlib_eval1211000004_A_class.Info(); i.IsInstance = A_arbace_c_aotlib_eval1211000004_A_InstanceOf; i.Table = A_arbace_c_aotlib_eval1211000004_A_members }

var A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A_class *jrt.Class

func A_arbace_c_aotlib_eval1211000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_aotlib_eval1211000008_A_New()}; return nil }

var A_arbace_c_aotlib_eval1211000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_aotlib_eval1211000008_A_new}

var A_arbace_c_aotlib_eval1211000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.aotlib$eval1211000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_aotlib_A_class, Simple: "eval1211000008", Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib_eval1211000008_A"})

func init() { i := A_arbace_c_aotlib_eval1211000008_A_class.Info(); i.IsInstance = A_arbace_c_aotlib_eval1211000008_A_InstanceOf; i.Table = A_arbace_c_aotlib_eval1211000008_A_members }

var A_arbace_c_aotlib_eval1211000008_fn__1211000009_A_class *jrt.Class

var A_arbace_c_aotlib_lib_dir_name_A_class *jrt.Class

var A_arbace_c_aotlib_lib_key_A_class *jrt.Class

var A_arbace_c_aotlib_lib_key_STAR__A_class *jrt.Class

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_class *jrt.Class

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_class *jrt.Class

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_class *jrt.Class

var A_arbace_c_aotlib_make_unit_A_class *jrt.Class

var A_arbace_c_aotlib_make_unit_fn__1211000046_A_class *jrt.Class

var A_arbace_c_aotlib_make_unit_fn__1211000051_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_fn__1211000066_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_class *jrt.Class

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_class *jrt.Class

var A_arbace_c_aotlib_secs_A_class *jrt.Class

var A_arbace_c_aotlib_sha256_hex_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_class *jrt.Class

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_class *jrt.Class

var A_arbace_c_aotlib_unit_A_class *jrt.Class

var A_arbace_c_aotlib_unit_fn__1211000054_A_class *jrt.Class

var A_arbace_c_aotlib_unit_pkg_A_class *jrt.Class

var A_arbace_c_aotlib_write_atomic_A_class *jrt.Class

func A_arbace_c_aotlib__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_aotlib__init_A_Load__O()}; return nil }

func A_arbace_c_aotlib__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_aotlib__init_A_New()}; return nil }

var A_arbace_c_aotlib__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_aotlib__init_A_invoke, New: A_arbace_c_aotlib__init_A_new}

var A_arbace_c_aotlib__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.aotlib__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_aotlib.A_arbace_c_aotlib__init_A", Source: "aotlib.ae"})

func init() { i := A_arbace_c_aotlib__init_A_class.Info(); i.IsInstance = A_arbace_c_aotlib__init_A_InstanceOf; i.Init = A_arbace_c_aotlib__init_A_Init; i.Table = A_arbace_c_aotlib__init_A_members }
