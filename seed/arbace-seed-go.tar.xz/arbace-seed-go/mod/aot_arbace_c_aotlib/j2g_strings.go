//line j2g_strings.ae:1
package aot_arbace_c_aotlib

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.c.buildkn2,asyn5,buildyn13,arbace.c.cf2gyn4,cf2gyn12,arbace.c.runyn4,crunyn16,arbace.c.runtimeyn3,rtmyn18,arbace.repr.c.hostyn4,hostyn13,arbace.stringyn3,strkn3,dockn11,runtime-keykn8,frag-dirkn3,srckn3,pkgkn4,pathkn5,byteskn7,secondskn5,tracekn9,frag-libskn1,fkn3,fnskn5,initskn5,itemskn7,importskn5,bindskn5,fmapskn5,smapskn5,unitskn9,functionskn7,refusedkn5,fragskn2,okkn6,statuskn7,messagekn4,textkn5,indexv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c.aotlibm2,R14,s1072,cf2g's prebuilt libraries (doc/rust/RUST-EVAL-SURVEY.md, \"As built: RES34 (write-ahead)\"; RES34 (a)): a library's units (musl's,\n  a lowered Rust std's or C++ runtime's: any library arbace.c.runtime/prebuilt makes) each translated once by cf2g into a Go\n  package of its own (arbace.c.cf2g/translate-unit: the unit's fragment, its functions' and statics' numbers left to relocation\n  tables), cached on disk by a key (the fragments' key, cf2g's and repr/go's printer's sources as loaded) under\n  .tmp/ci-aot-lib/LIB-KEY/PKG/ (CI_AOT_LIB), so that a program's AOT build translates only its own code: its link (arbace.c.build's\n  *link-trace*) says which code commands are a library unit's items, the program's package calls the unit packages' functions\n  for them (SetCompiled) and fills each unit's relocation tables from the link's numbers (Bind). The Go of a unit is compiled by\n  Go once per key too (Go's build cache: the same file at the same import path).\n\n  The program's module links the cache's root as its directory cilib (import paths arbace/cilib/LIB-KEY/PKG).v11,arbace.core3,strv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core6,formatv11,arbace.core10,chunk-restv11,arbace.core4,nextv16,arbace.c.runtime12,source-bytesv15,arbace.c.aotlib10,sha256-hexv15,arbace.c.aotlib11,aot-versionR15,v13,arbace.string4,joinv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.c.aotlib9,bytes-hexv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core4,restv15,arbace.c.aotlib11,aot-sourcesv15,arbace.c.aotlib8,lib-keysR16,v15,arbace.c.aotlib8,lib-key*v13,arbace.string7,replacep14,-[0-9a-f]{64}$p13,[^A-Za-z0-9_]v11,arbace.core4,subsv15,arbace.c.aotlib7,lib-keyl0,l16,l8,p12,[^A-Za-z0-9]v11,arbace.core4,spitv15,arbace.c.aotlib12,lib-dir-namev15,arbace.c.aotlib8,unit-pkgv15,arbace.c.aotlib10,cache-rootv11,arbace.core11,read-stringv11,arbace.core5,slurpv16,arbace.c.runtime12,lib-fragmentv13,arbace.c.cf2g14,translate-unitv13,arbace.c.cf2g7,go-textv11,arbace.core5,assocR17,R18,R19,R20,R21,v15,arbace.c.aotlib12,write-atomicv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v15,arbace.c.aotlib5,unitsv15,arbace.c.aotlib9,make-unitv11,arbace.core8,to-arrayR22,R23,v11,arbace.core8,distinctv11,arbace.core4,keepv11,arbace.core4,intov15,arbace.c.aotlib4,unitR24,R25,R26,v11,arbace.core6,symbolR27,R28,v11,arbace.core3,vecR29,v11,arbace.core4,mapvl-1,R30,R31,R32,v11,arbace.core4,atomm8,R32,l0,R33,l0,R34,l0,R20,l0,v11,arbace.core5,doallv11,arbace.core11,future-callv11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core3,incR33,v11,arbace.core1,+R34,R35,v11,arbace.core5,rangev16,arbace.c.runtime7,libraryv12,arbace.c.run9,read-unitV1,s10,-std=gnu17v15,arbace.c.aotlib4,secsv11,arbace.core4,not=R36,R37,v11,arbace.core7,printlnv11,arbace.core4,nameR38,v16,arbace.c.runtime11,link-tracedv15,arbace.c.aotlib11,program-prev13,arbace.c.cf2g9,translatev14,arbace.c.build12,read-programR39,v18,arbace.repr.c.host9,load-hostv15,arbace.c.aotlib13,translate-libv11,arbace.core4,keysR40,v11,arbace.core4,someS1,s7,--wholev11,arbace.core6,removeS1,s7,--wholev11,arbace.core9,partitionl2,v11,arbace.core15,shutdown-agentsv15,arbace.c.aotlib9,c-compile")

var Lit_1 *jrt.String = jrt.Intern("user.dir")

var Lit_2 *jrt.String = jrt.Intern("translate-musl")

var Lit_3 *jrt.String = jrt.Intern("test/c/host")

var Lit_4 *jrt.String = jrt.Intern("2")

var Lit_5 *jrt.String = jrt.Intern("c-compile")

var Lit_6 *jrt.String = jrt.Intern("arbace.c.aotlib: c-compile, translate-musl")

var Lit_7 *jrt.String = jrt.Intern("SHA-256")

var Lit_8 *jrt.String = jrt.Intern("%02x")

var Lit_9 *jrt.String = jrt.Intern("arbace/progs/")

var Lit_10 *jrt.String = jrt.Intern("/progs/")

var Lit_11 *jrt.String = jrt.Intern("/prog.go")

var Lit_12 *jrt.String = jrt.Intern("ok")

var Lit_13 *jrt.String = jrt.Intern("CI_AOT_LIB")

var Lit_14 *jrt.String = jrt.Intern("/.tmp/ci-aot-lib")

var Lit_15 *jrt.String = jrt.Intern("java.io.File")

var Lit_16 *jrt.String = jrt.Intern("java.util.concurrent.ConcurrentHashMap")

var Lit_17 *jrt.String = jrt.Intern("")

var Lit_18 *jrt.String = jrt.Intern("_")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029$fn__1211000030")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_key_STAR_$iter__1211000025__1211000029$fn__1211000030$fn__1211000031")

var Lit_22 *jrt.String = jrt.Intern(" ")

var Lit_23 *jrt.String = jrt.Intern("\n")

var Lit_24 *jrt.String = jrt.Intern("/")

var Lit_25 *jrt.String = jrt.Intern("manifest.edn")

var Lit_26 *jrt.String = jrt.Intern("arbace.c.aotlib$make_unit$fn__1211000046")

var Lit_27 *jrt.String = jrt.Intern("arbace/cilib/")

var Lit_28 *jrt.String = jrt.Intern("unit.go")

var Lit_29 *jrt.String = jrt.Intern("arbace.c.aotlib$make_unit$fn__1211000051")

var Lit_30 *jrt.String = jrt.Intern("CI_AOT_LIB_OFF")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$fn__1211000066")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$alias_of__1211000068")

var Lit_33 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000070__1211000074")

var Lit_34 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000098__1211000102")

var Lit_35 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124")

var Lit_36 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000070__1211000074$fn__1211000075")

var Lit_37 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000070__1211000074$fn__1211000075$fn__1211000076")

var Lit_38 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000098__1211000102$fn__1211000103")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000098__1211000102$fn__1211000103$fn__1211000104")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000144")

var Lit_43 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000146")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126$fn__1211000133")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre$iter__1211000120__1211000124$fn__1211000125$fn__1211000126$fn__1211000135")

var Lit_46 *jrt.String = jrt.Intern("%.1f")

var Lit_47 *jrt.String = jrt.Intern("UTF-8")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156")

var Lit_49 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157")

var Lit_50 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000164")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158$fn__1211000159")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000158$fn__1211000159$fn__1211000160")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib$iter__1211000152__1211000156$fn__1211000157$fn__1211000164$fn__1211000165")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.aotlib$unit$fn__1211000054")

var Lit_56 *jrt.String = jrt.Intern("u")

var Lit_57 *jrt.String = jrt.Intern(".tmp")

var Lit_58 *jrt.String = jrt.Intern("-")

var Lit_59 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn16,java.lang.Stringyn5,bytesyn3,libyn4,Filekn4,keysyn5,traceyn9,frag-libsyn4,srcsyn7,threadsyn2,t0yn1,hyn6,whole?yn4,verbyn1,&yn4,argsv11,arbace.core5,in-nsMyn15,arbace.c.aotlibm2,R0,s1072,cf2g's prebuilt libraries (doc/rust/RUST-EVAL-SURVEY.md, \"As built: RES34 (write-ahead)\"; RES34 (a)): a library's units (musl's,\n  a lowered Rust std's or C++ runtime's: any library arbace.c.runtime/prebuilt makes) each translated once by cf2g into a Go\n  package of its own (arbace.c.cf2g/translate-unit: the unit's fragment, its functions' and statics' numbers left to relocation\n  tables), cached on disk by a key (the fragments' key, cf2g's and repr/go's printer's sources as loaded) under\n  .tmp/ci-aot-lib/LIB-KEY/PKG/ (CI_AOT_LIB), so that a program's AOT build translates only its own code: its link (arbace.c.build's\n  *link-trace*) says which code commands are a library unit's items, the program's package calls the unit packages' functions\n  for them (SetCompiled) and fills each unit's relocation tables from the link's numbers (Bind). The Go of a unit is compiled by\n  Go once per key too (Go's build cache: the same file at the same import path).\n\n  The program's module links the cache's root as its directory cilib (import paths arbace/cilib/LIB-KEY/PKG).m2,R0,s1072,cf2g's prebuilt libraries (doc/rust/RUST-EVAL-SURVEY.md, \"As built: RES34 (write-ahead)\"; RES34 (a)): a library's units (musl's,\n  a lowered Rust std's or C++ runtime's: any library arbace.c.runtime/prebuilt makes) each translated once by cf2g into a Go\n  package of its own (arbace.c.cf2g/translate-unit: the unit's fragment, its functions' and statics' numbers left to relocation\n  tables), cached on disk by a key (the fragments' key, cf2g's and repr/go's printer's sources as loaded) under\n  .tmp/ci-aot-lib/LIB-KEY/PKG/ (CI_AOT_LIB), so that a program's AOT build translates only its own code: its link (arbace.c.build's\n  *link-trace*) says which code commands are a library unit's items, the program's package calls the unit packages' functions\n  for them (SetCompiled) and fills each unit's relocation tables from the link's numbers (Bind). The Go of a unit is compiled by\n  Go once per key too (Go's build cache: the same file at the same import path).\n\n  The program's module links the cache's root as its directory cilib (import paths arbace/cilib/LIB-KEY/PKG).R1,v11,arbace.core20,*warn-on-reflection*v15,arbace.c.aotlib11,aot-versionl1,m8,R2,i23,R3,i1,R4,s18,arbace/c/aotlib.aeR0,s33,The units' Go format: in the key.v15,arbace.c.aotlib11,aot-sourcesV7,s16,arbace/c/cf2g.aes18,arbace/c/aotlib.aes23,arbace/repr/go/print.aes28,arbace/repr/go/print_code.aes28,arbace/repr/go/print_emit.aes28,arbace/repr/go/print_text.aes24,arbace/repr/go/layout.aem8,R2,i27,R3,i1,R4,s18,arbace/c/aotlib.aeR0,s105,The sources a unit's Go is made by, beyond the fragments' (whose key covers the checker and the builder).v15,arbace.c.aotlib10,sha256-hexm10,R5,TR6,L1,MV1,Myn1,sm2,R7,R8,m2,R7,R9,R2,i32,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib9,bytes-hexm10,R5,TR6,L1,MV1,Myn1,bm2,R7,R10,m2,R7,R9,R2,i38,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib10,cache-rootm8,R6,L1,MV1,Myn4,rootm2,R7,R8,m2,R7,R9,R2,i44,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib8,lib-key*m10,R5,TR6,L1,MV2,Myn4,rootm2,R7,R8,R11,m2,R7,R9,R2,i46,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib8,lib-keysm8,R5,TR2,i53,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib7,lib-keym10,R6,L1,MV2,Myn4,rootm2,R7,R8,R11,m2,R7,R9,R0,s186,A prebuilt library's Go key: the units' Go format, its fragments' key (arbace.c.runtime's: the library's sources, ci's\n  checker and builder) and aot-sources as this process loaded them.R2,i55,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib12,lib-dir-namem10,R6,L1,MV2,Myn4,rootm2,R7,R8,R11,m2,R7,R9,R0,s140,The library's directory under the cache (and arbace/cilib/): its fragments' directory's name before the key, the Go key's\n  first 16 digits.R2,i62,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib8,unit-pkgm10,R6,L1,MV1,Myn3,srcm2,R7,R8,m2,R7,R9,R0,s99,A unit's Go package name: u, a digest of its name, its name's last characters made an identifier's.R2,i70,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib5,unitsm8,R5,TR2,i78,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib12,write-atomicm10,R5,TR6,L1,V2,Myn1,fm2,R7,R12,Myn1,sm2,R7,R8,R2,i80,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib9,make-unitm12,R5,TR6,L1,V3,Myn4,rootm2,R7,R8,R11,Myn3,srcm2,R7,R8,R0,s137,The unit's Go package in the cache, translated when missing: its manifest {:pkg :path :fns :inits :refused :functions :bytes\n  :seconds}.R2,i86,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib4,unitm10,R6,L1,V3,Myn4,rootm2,R7,R8,R11,Myn3,srcm2,R7,R8,R0,s68,A library unit's manifest, made once per process (a delay per unit).R2,i106,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib11,program-prem10,R6,L1,V2,Myn4,rootm2,R7,R8,m2,R13,V2,R14,R15,R0,s350,translate's `pre` of a traced link ({:text :trace :frag-libs}: arbace.c.runtime/link-traced's, arbace.rust.run's): each code\n  command or init that is a library unit's translated item, the unit packages the program imports and their relocation tables\n  (an unresolved placeholder -1). CI_AOT_LIB_OFF=1: none (the whole program translated, as before).R2,i113,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib13,translate-libm10,R6,L1,V4,Myn4,rootm2,R7,R8,R11,R16,R17,R0,s128,Every unit of a prebuilt library translated (the cache filled ahead), in `threads` threads: {:units :functions :refused :bytes}.R2,i139,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib4,secsm10,R5,TR6,L1,V1,R18,R2,i159,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib9,c-compilem10,R6,L1,V5,R19,Myn3,outm2,R7,R8,Myn4,filem2,R7,R8,Myn3,pkgm2,R7,R8,R20,R0,s229,One C file read, checked, linked with musl (traced) and translated into OUT/progs/PKG/prog.go: with the prebuilt units (the\n  default) or whole (whole?). A line: PKG STATUS read-seconds link-seconds translate-seconds bytes units.R2,i161,R3,i1,R4,s18,arbace/c/aotlib.aev15,arbace.c.aotlib5,-mainm10,R6,L1,V3,R21,R22,R23,R0,s145,c-compile OUT PKG FILE [--whole] ...: C files (PKG FILE pairs) translated as c-compile does; translate-musl THREADS: every musl\n  unit's Go made.R2,i183,R3,i1,R4,s18,arbace/c/aotlib.ae")

var Lit_60 *jrt.String = jrt.Intern("arbace.c.aotlib$eval1211000004$loading__1927001464__auto____1211000005")

var Lit_61 *jrt.String = jrt.Intern("arbace.c.aotlib$eval1211000008$fn__1211000009")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.aotlib$sha256_hex")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.aotlib$bytes_hex")

var Lit_64 *jrt.String = jrt.Intern("arbace.c.aotlib$cache_root")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_key_STAR_")

var Lit_66 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_key")

var Lit_67 *jrt.String = jrt.Intern("arbace.c.aotlib$lib_dir_name")

var Lit_68 *jrt.String = jrt.Intern("arbace.c.aotlib$unit_pkg")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.aotlib$write_atomic")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.aotlib$make_unit")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.aotlib$unit")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.aotlib$program_pre")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.aotlib$translate_lib")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.aotlib$secs")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.aotlib$c_compile")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.aotlib$_main")
