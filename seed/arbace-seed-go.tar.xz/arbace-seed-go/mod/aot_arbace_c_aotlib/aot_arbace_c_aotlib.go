//line aot_arbace_c_aotlib.ae:1
package aot_arbace_c_aotlib

import (
	"arbace/aot_arbace_c_build"
	"arbace/aot_arbace_c_cf2g"
	"arbace/aot_arbace_c_run"
	"arbace/aot_arbace_c_runtime"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A_New() *A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_aotlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_aotlib_A_const_1); lang.IFn_Cast(A_arbace_c_aotlib_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_c_aotlib_A_const_3, A_arbace_c_aotlib_A_const_4, A_arbace_c_aotlib_A_const_5, A_arbace_c_aotlib_A_const_6, A_arbace_c_aotlib_A_const_7, A_arbace_c_aotlib_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_aotlib_eval1211000008_fn__1211000009_A_New() *A_arbace_c_aotlib_eval1211000008_fn__1211000009_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_eval1211000008_fn__1211000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_aotlib_eval1211000008_fn__1211000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_aotlib_eval1211000008_fn__1211000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_c_aotlib_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_aotlib_A_const_12.GetRawRoot__O(), A_arbace_c_aotlib_A_const_13) }






























func A_arbace_c_aotlib_sha256_hex_A_New() *A_arbace_c_aotlib_sha256_hex_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_sha256_hex_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_c_aotlib_sha256_hex_A) Ctor() {}
//line :32:1
func (t *A_arbace_c_aotlib_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_7).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_String__B1(Lit_47)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_1211000014__4 any; var root_28 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_30 lang.IFn; if


	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = d__2; if linked_29 == nil { seq_1211000014__4 = ifn_30.Invoke_O__O(arg_31) } else { seq_1211000014__4 = linked_29.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_28, arg_31) }; var chunk_1211000015__5 any; var count_1211000016__6 int64 = 0; var i_1211000017__7 int64 = 0; L1:
//line :32:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1211000017__7, count_1211000016__6) { var x__8 any = lang.Indexed_Cast(chunk_1211000015__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1211000017__7)); jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_aotlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__8))).Ref()))); seq_1211000014__4, chunk_1211000015__5, count_1211000016__6, i_1211000017__7 = seq_1211000014__4, chunk_1211000015__5, count_1211000016__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1211000017__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_32 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = seq_1211000014__4; if linked_33 == nil { temp__1927000414__auto____8 = ifn_34.Invoke_O__O(arg_35) } else { temp__1927000414__auto____8 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1211000014__9 any = temp__1927000414__auto____8; var tmp1 any; var root_36 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = seq_1211000014__9; if linked_37 == nil { tmp1 = ifn_38.Invoke_O__O(arg_39) } else { tmp1 = linked_37.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_36, arg_39) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_40 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_1211000014__9; if linked_41 == nil { c__1927000678__auto____10 = ifn_42.Invoke_O__O(arg_43) } else { c__1927000678__auto____10 = linked_41.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_40, arg_43) }; var tmp2 any; var root_53 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = seq_1211000014__9; if linked_54 == nil { tmp2 = ifn_55.Invoke_O__O(arg_56) } else { tmp2 = linked_54.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_53, arg_56) }; seq_1211000014__4, chunk_1211000015__5, count_1211000016__6, i_1211000017__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__10 any; var root_44 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = seq_1211000014__9; if linked_45 == nil { x__10 = ifn_46.Invoke_O__O(arg_47) } else { x__10 = linked_45.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_44, arg_47) }; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_aotlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__10))).Ref()))); var tmp3 any; var root_62 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = seq_1211000014__9; if linked_63 == nil { tmp3 = ifn_64.Invoke_O__O(arg_65) } else { tmp3 = linked_63.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_62, arg_65) }; seq_1211000014__4, chunk_1211000015__5, count_1211000016__6, i_1211000017__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :32:1
		break L1 }; var root_24 any =



	A_arbace_c_aotlib_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = sb__3; if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_24, arg_27) } }

func A_arbace_c_aotlib_bytes_hex_A_New() *A_arbace_c_aotlib_bytes_hex_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_bytes_hex_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_c_aotlib_bytes_hex_A) Ctor() {}
//line :38:1
func (t *A_arbace_c_aotlib_bytes_hex_A) Invoke_O_O__O(self, b__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_7).Digest_B1__B1(jrt.ByteArray_Cast(b__0)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_1211000019__4 any; var root_70 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_72 lang.IFn; if


	linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = d__2; if linked_71 == nil { seq_1211000019__4 = ifn_72.Invoke_O__O(arg_73) } else { seq_1211000019__4 = linked_71.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_70, arg_73) }; var chunk_1211000020__5 any; var count_1211000021__6 int64 = 0; var i_1211000022__7 int64 = 0; L1:
//line :38:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1211000022__7, count_1211000021__6) { var x__8 any = lang.Indexed_Cast(chunk_1211000020__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1211000022__7)); jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_aotlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__8))).Ref()))); seq_1211000019__4, chunk_1211000020__5, count_1211000021__6, i_1211000022__7 = seq_1211000019__4, chunk_1211000020__5, count_1211000021__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1211000022__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_74 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = seq_1211000019__4; if linked_75 == nil { temp__1927000414__auto____8 = ifn_76.Invoke_O__O(arg_77) } else { temp__1927000414__auto____8 = linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1211000019__9 any = temp__1927000414__auto____8; var tmp1 any; var root_78 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = seq_1211000019__9; if linked_79 == nil { tmp1 = ifn_80.Invoke_O__O(arg_81) } else { tmp1 = linked_79.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_82 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1211000019__9; if linked_83 == nil { c__1927000678__auto____10 = ifn_84.Invoke_O__O(arg_85) } else { c__1927000678__auto____10 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_82, arg_85) }; var tmp2 any; var root_95 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = seq_1211000019__9; if linked_96 == nil { tmp2 = ifn_97.Invoke_O__O(arg_98) } else { tmp2 = linked_96.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_95, arg_98) }; seq_1211000019__4, chunk_1211000020__5, count_1211000021__6, i_1211000022__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__10 any; var root_86 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1211000019__9; if linked_87 == nil { x__10 = ifn_88.Invoke_O__O(arg_89) } else { x__10 = linked_87.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_86, arg_89) }; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_aotlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__10))).Ref()))); var tmp3 any; var root_104 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = seq_1211000019__9; if linked_105 == nil { tmp3 = ifn_106.Invoke_O__O(arg_107) } else { tmp3 = linked_105.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_104, arg_107) }; seq_1211000019__4, chunk_1211000020__5, count_1211000021__6, i_1211000022__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :38:1
		break L1 }; var root_66 any =



	A_arbace_c_aotlib_A_const_14.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = sb__3; if linked_67 == nil { return ifn_68.Invoke_O__O(arg_69) } else { return linked_67.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_66, arg_69) } }

func A_arbace_c_aotlib_cache_root_A_New() *A_arbace_c_aotlib_cache_root_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_cache_root_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_c_aotlib_cache_root_A) Ctor() {}
//line :44:1
func (t *A_arbace_c_aotlib_cache_root_A) Invoke_O_O__O(self, root__0 any) any { var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_13).Ref(); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref() } }

func A_arbace_c_aotlib_lib_key_STAR__A_New() *A_arbace_c_aotlib_lib_key_STAR__A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_key_STAR__A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_c_aotlib_lib_key_STAR__A) Ctor() {}
//line :46:1
func (t *A_arbace_c_aotlib_lib_key_STAR__A) Invoke_O_O_O__O(self, root__0, lib__1 any) any { var sb__3 any; var root_108 any = A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_110 lang.IFn; if

	linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = A_arbace_c_aotlib_A_const_22; if linked_109 == nil { sb__3 = ifn_110.Invoke_O__O(arg_111) } else { sb__3 = linked_109.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_108, arg_111) }; var root_112 any =
	A_arbace_c_aotlib_A_const_23.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_c_aotlib_sha256_hex_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any; var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,7,s11:ci-aot-lib ns1:\ns10:fragments ns1:\nn", []*jrt.Class{jrt.String_class}); var tmp2 any = A_arbace_c_aotlib_A_const_24.GetRawRoot__O(); var tmp3 any = A_arbace_c_aotlib_A_const_25.Invoke_O__O(lib__1); var tmp4 any; var root_116 any = A_arbace_c_aotlib_A_const_26.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_118 lang.IFn; if

	linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var iter__1927001039__auto____11 any; var fnbody__189 any = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_New_O_O(root__0, sb__3); var tmp5 *jrt.Class; var fncls__188 *jrt.Class = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__189); A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_fn_class = fncls__188d; tmp5 = fncls__188d } else { tmp5 = fncls__188 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__189, tmp5, nil); arg_119 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_c_aotlib_A_const_34.GetRawRoot__O()); if linked_117 == nil { tmp4 = ifn_118.Invoke_O__O(arg_119) } else { tmp4 = linked_117.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_116, arg_119) }; arg_115 = /*line :49:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, nil, tmp3, nil, tmp4)).Ref(); if linked_113 == nil { return ifn_114.Invoke_O__O(arg_115) } else { return linked_113.(*A_arbace_c_aotlib_sha256_hex_A).Invoke_O_O__O(root_112, arg_115) } }

func A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_New_O_O(p0, p1 any) *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A) Ctor_O_O(c__root, c__sb any) { t.F_root = c__root; t.F_sb = c__sb }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A) Invoke_O_O__O(self, s__1211000026__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__187 any = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_New_O_O_O_O(t.F_root, t.F_sb, s__1211000026__1, self); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__187); A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__187, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :51:1
func A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A) Ctor_O_O_O_O(c__root, c__sb, c__s__1211000026, c__iter__1211000025 any) { t.F_root = c__root; t.F_sb = c__sb; t.F_s__1211000026 = c__s__1211000026; t.F_iter__1211000025 = c__iter__1211000025 }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A) Invoke_O__O(self any) any { { var s__1211000026__1 any; var t_ any = t.F_s__1211000026; t.F_s__1211000026 = nil; s__1211000026__1 = t_; for { var temp__1927000414__auto____2 any; var root_120 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1211000026__1; if linked_121 == nil { temp__1927000414__auto____2 = ifn_122.Invoke_O__O(arg_123) } else { temp__1927000414__auto____2 = linked_121.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1211000026__3 any = temp__1927000414__auto____2; var tmp1 any; var root_124 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__1211000026__3; if linked_125 == nil { tmp1 = ifn_126.Invoke_O__O(arg_127) } else { tmp1 = linked_125.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_124, arg_127) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_128 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__1211000026__3; if linked_129 == nil { c__1927001037__auto____4 = ifn_130.Invoke_O__O(arg_131) } else { c__1927001037__auto____4 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_128, arg_131) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1211000028__6 any; var root_132 any = A_arbace_c_aotlib_A_const_27.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_133 == nil { b__1211000028__6 = ifn_134.Invoke_O__O(arg_135) } else { b__1211000028__6 = linked_133.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_132, arg_135) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_New_O_O_O_I_O(t.F_root, b__1211000028__6, t.F_sb, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__146); A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_147 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_152 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = b__1211000028__6; if linked_153 == nil { arg_150 = ifn_154.Invoke_O__O(arg_155) } else { arg_150 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_152, arg_155) }; var arg_151 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1211000025); var tmp5 any; var root_156 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__1211000026__3; if linked_157 == nil { tmp5 = ifn_158.Invoke_O__O(arg_159) } else { tmp5 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_156, arg_159) }; arg_151 = tmp4.Invoke_O__O(tmp5); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } } else { var root_160 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_165 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__1211000028__6; if linked_166 == nil { arg_163 = ifn_167.Invoke_O__O(arg_168) } else { arg_163 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_164 any; if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } } else { var f__4 any; var root_169 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1211000026__3; if linked_170 == nil { f__4 = ifn_171.Invoke_O__O(arg_172) } else { f__4 = linked_170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_169, arg_172) }; var vec__1211000036__5 any = lang.IFn_Cast(t.F_sb).Invoke_O_O__O(t.F_root, f__4); var how__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000036__5, lang.RT_IntCast_J__I_NoInit(0), nil); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000036__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_173 any = A_arbace_c_aotlib_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_22, nil, Lit_23); var tmp7 any; var root_178 any = A_arbace_c_aotlib_A_const_29.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_c_aotlib_bytes_hex_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = b__7; if linked_179 == nil { tmp7 = ifn_180.Invoke_O__O(arg_181) } else { tmp7 = linked_179.(*A_arbace_c_aotlib_bytes_hex_A).Invoke_O_O__O(root_178, arg_181) }; arg_176 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, f__4, nil, how__6, nil, tmp7, nil)).Ref(); var arg_177 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1211000025); var tmp9 any; var root_182 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__1211000026__3; if linked_183 == nil { tmp9 = ifn_184.Invoke_O__O(arg_185) } else { tmp9 = linked_183.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_182, arg_185) }; arg_177 = tmp8.Invoke_O__O(tmp9); if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :51:1
func A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A) Ctor_O_O_O_I_O(c__root, c__b__1211000028, c__sb any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_b__1211000028 = c__b__1211000028; t.F_sb = c__sb; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A) Invoke_O__O(self any) any { { var i__1211000027__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1211000027__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1211000027__1)); var vec__1211000032__3 any = lang.IFn_Cast(t.F_sb).Invoke_O_O__O(t.F_root, f__2); var how__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000032__3, lang.RT_IntCast_J__I_NoInit(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000032__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_136 any = A_arbace_c_aotlib_A_const_28.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__1211000028; var arg_140 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_22, nil, Lit_23); var tmp3 any; var root_141 any = A_arbace_c_aotlib_A_const_29.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_c_aotlib_bytes_hex_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = b__5; if linked_142 == nil { tmp3 = ifn_143.Invoke_O__O(arg_144) } else { tmp3 = linked_142.(*A_arbace_c_aotlib_bytes_hex_A).Invoke_O_O__O(root_141, arg_144) }; arg_140 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, f__2, nil, how__4, nil, tmp3, nil)).Ref(); if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__1211000027__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000027__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c_aotlib_lib_key_A_New() *A_arbace_c_aotlib_lib_key_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_key_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_c_aotlib_lib_key_A) Ctor() {}
//line :55:1
func (t *A_arbace_c_aotlib_lib_key_A) Invoke_O_O_O__O(self, root__0, lib__1 any) any { var or__1927000174__auto____3 any = jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_35.GetRawRoot__O()).Get_O__O(A_arbace_c_aotlib_A_const_36.Invoke_O__O(lib__1)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var k__4 any; var root_190 any = A_arbace_c_aotlib_A_const_37.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_c_aotlib_lib_key_STAR__A_fn_class); var ifn_192 lang.IFn
		if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = root__0; var arg_194 any = lib__1; if linked_191 == nil { k__4 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { k__4 = linked_191.(*A_arbace_c_aotlib_lib_key_STAR__A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_35.GetRawRoot__O()).Put_O_O__O(A_arbace_c_aotlib_A_const_36.Invoke_O__O(lib__1), k__4)
//line :59:1
		return k__4 } }


func A_arbace_c_aotlib_lib_dir_name_A_New() *A_arbace_c_aotlib_lib_dir_name_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_lib_dir_name_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_c_aotlib_lib_dir_name_A) Ctor() {}
//line :62:1
func (t *A_arbace_c_aotlib_lib_dir_name_A) Invoke_O_O_O__O(self, root__0, lib__1 any) any { var fd__3 any = jrt.File_New_String(jrt.String_Cast(A_arbace_c_aotlib_A_const_36.Invoke_O__O(lib__1))).GetName__String().Ref(); var nm__4 any; var root_195 any = A_arbace_c_aotlib_A_const_38.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_197 lang.IFn; if




	linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = fd__3; var arg_199 any = A_arbace_c_aotlib_A_const_39; var arg_200 any = Lit_17; if linked_196 == nil { nm__4 = ifn_197.Invoke_O_O_O__O(arg_198, arg_199, arg_200) } else { nm__4 = linked_196.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_195, arg_198, arg_199, arg_200) }; var tmp1 /*line :68:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18, nil); var tmp2 any; var root_201 any = A_arbace_c_aotlib_A_const_38.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = nm__4; var arg_205 any = A_arbace_c_aotlib_A_const_40; var arg_206 any = Lit_18; if linked_202 == nil { tmp2 = ifn_203.Invoke_O_O_O__O(arg_204, arg_205, arg_206) } else { tmp2 = linked_202.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_201, arg_204, arg_205, arg_206) }; var tmp3 any = tmp2; var tmp4 any; var root_207 any = A_arbace_c_aotlib_A_const_41.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var root_213 any = A_arbace_c_aotlib_A_const_42.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, A_arbace_c_aotlib_lib_key_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = root__0; var arg_217 any = lib__1; if linked_214 == nil { arg_210 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { arg_210 = linked_214.(*A_arbace_c_aotlib_lib_key_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; var arg_211 any = A_arbace_c_aotlib_A_const_43; var arg_212 any = A_arbace_c_aotlib_A_const_44; if linked_208 == nil { tmp4 = ifn_209.Invoke_O_O_O__O(arg_210, arg_211, arg_212) } else { tmp4 = linked_208.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_207, arg_210, arg_211, arg_212) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref() }

func A_arbace_c_aotlib_unit_pkg_A_New() *A_arbace_c_aotlib_unit_pkg_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_unit_pkg_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_c_aotlib_unit_pkg_A) Ctor() {}
//line :70:1
func (t *A_arbace_c_aotlib_unit_pkg_A) Invoke_O_O__O(self, src__0 any) any { var h__2 any; var root_218 any = A_arbace_c_aotlib_A_const_41.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_220 lang.IFn; if


	linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var root_224 any = A_arbace_c_aotlib_A_const_23.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_c_aotlib_sha256_hex_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = src__0; if linked_225 == nil { arg_221 = ifn_226.Invoke_O__O(arg_227) } else { arg_221 = linked_225.(*A_arbace_c_aotlib_sha256_hex_A).Invoke_O_O__O(root_224, arg_227) }; var arg_222 any = A_arbace_c_aotlib_A_const_43; var arg_223 any = A_arbace_c_aotlib_A_const_45; if linked_219 == nil { h__2 = ifn_220.Invoke_O_O_O__O(arg_221, arg_222, arg_223) } else { h__2 = linked_219.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_218, arg_221, arg_222, arg_223) }; var t__3 any; var root_228 any = /*line :70:1*/A_arbace_c_aotlib_A_const_38.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_230 lang.IFn; if



	linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = src__0; var arg_232 any = A_arbace_c_aotlib_A_const_46; var arg_233 any = Lit_18; if linked_229 == nil { t__3 = ifn_230.Invoke_O_O_O__O(arg_231, arg_232, arg_233) } else { t__3 = linked_229.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_228, arg_231, arg_232, arg_233) }; var t__4 any; if
	lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t__3)), 40) { var root_234 any = A_arbace_c_aotlib_A_const_41.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = t__3; var arg_238 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t__3)), 40)).Ref(); if linked_235 == nil { t__4 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { t__4 = linked_235.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) } } else { t__4 = t__3 }; return /*line :76:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__2, nil, t__4)).Ref() }



func A_arbace_c_aotlib_write_atomic_A_New() *A_arbace_c_aotlib_write_atomic_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_write_atomic_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_c_aotlib_write_atomic_A) Ctor() {}
//line :80:1
func (t *A_arbace_c_aotlib_write_atomic_A) Invoke_O_O_O__O(self, f__0, s__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__0).GetParentFile__File().Mkdirs__Z())
//line :80:1
	var tmp__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, jrt.File_Cast(f__0).GetPath__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.Thread_CurrentThread__Thread().GetId__J()).Ref())))


	lang.IFn_Cast(A_arbace_c_aotlib_A_const_47.GetRawRoot__O()).Invoke_O_O__O(tmp__3, s__1)
	if jrt.File_Cast(tmp__3).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(tmp__3).Delete__Z()).Ref()
	} }
func A_arbace_c_aotlib_make_unit_A_New() *A_arbace_c_aotlib_make_unit_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_make_unit_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_c_aotlib_make_unit_A) Ctor() {}
//line :86:1
func (t *A_arbace_c_aotlib_make_unit_A) Invoke_O_O_O_O__O(self, root__0, lib__1, src__2 any) any { var ld__4 any; var root_244 any = A_arbace_c_aotlib_A_const_48.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_c_aotlib_lib_dir_name_A_fn_class); var ifn_246 lang.IFn; if



	linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = root__0; var arg_248 any = lib__1; if linked_245 == nil { ld__4 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { ld__4 = linked_245.(*A_arbace_c_aotlib_lib_dir_name_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; var pkg__5 any; var root_249 any = /*line :86:1*/A_arbace_c_aotlib_A_const_49.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_c_aotlib_unit_pkg_A_fn_class); var ifn_251 lang.IFn; if




	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = src__2; if linked_250 == nil { pkg__5 = ifn_251.Invoke_O__O(arg_252) } else { pkg__5 = linked_250.(*A_arbace_c_aotlib_unit_pkg_A).Invoke_O_O__O(root_249, arg_252) }; var dir__6 any; var tmp1 /*line :86:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil, Lit_24, nil); var tmp2 any; var root_253 any = A_arbace_c_aotlib_A_const_50.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_c_aotlib_cache_root_A_fn_class); var ifn_255 lang.IFn; if





	linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = root__0; if linked_254 == nil { tmp2 = ifn_255.Invoke_O__O(arg_256) } else { tmp2 = linked_254.(*A_arbace_c_aotlib_cache_root_A).Invoke_O_O__O(root_253, arg_256) }; dir__6 = /*line :86:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, ld__4, nil, pkg__5))); var mf__7 any = jrt.File_New_File_String(jrt.File_Cast(dir__6), Lit_25); var or__1927000174__auto____8 any; if







	jrt.File_Cast(mf__7).Exists__Z() { var tmp3 *lang.Compiler_AOTFn; var fnbody__266 any = A_arbace_c_aotlib_make_unit_fn__1211000046_A_New_O(mf__7); var tmp4 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_c_aotlib_make_unit_fn__1211000046_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__266); A_arbace_c_aotlib_make_unit_fn__1211000046_A_fn_class = fncls__265d; tmp4 = fncls__265d } else { tmp4 = fncls__265 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__266, tmp4, nil); or__1927000174__auto____8 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O() } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else { var t0__9 int64 = jrt.System_NanoTime__J(); var frag__10 any; var root_267 any = A_arbace_c_aotlib_A_const_53.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_A_fn_class); var ifn_269 lang.IFn

		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = lib__1; var arg_271 any = src__2; if linked_268 == nil { frag__10 = ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { frag__10 = linked_268.(*aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_A).Invoke_O_O_O__O(root_267, arg_270, arg_271) }
//line :94:1
		var path__11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, ld__4, nil, pkg__5)).Ref(); var vec__1211000048__12 any; var root_272 any = A_arbace_c_aotlib_A_const_54.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_c_cf2g.A_arbace_c_cf2g_translate_unit_A_fn_class); var ifn_274 lang.IFn



		if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = frag__10; var arg_276 any = pkg__5; var arg_277 any = path__11; if linked_273 == nil { vec__1211000048__12 = ifn_274.Invoke_O_O_O__O(arg_275, arg_276, arg_277) } else { vec__1211000048__12 = linked_273.(*aot_arbace_c_cf2g.A_arbace_c_cf2g_translate_unit_A).Invoke_O_O_O_O__O(root_272, arg_275, arg_276, arg_277) }
//line :94:1
		var forms__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000048__12, lang.RT_IntCast_J__I_NoInit(0), nil); var info__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000048__12, lang.RT_IntCast_J__I_NoInit(1), nil); var text__15 any; var root_278 any = A_arbace_c_aotlib_A_const_55.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_c_cf2g.A_arbace_c_cf2g_go_text_A_fn_class); var ifn_280 lang.IFn




		if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = forms__13; if linked_279 == nil { text__15 = ifn_280.Invoke_O__O(arg_281) } else { text__15 = linked_279.(*aot_arbace_c_cf2g.A_arbace_c_cf2g_go_text_A).Invoke_O_O__O(root_278, arg_281) }
//line :94:1
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_56.GetRawRoot__O()); var tmp6 any = A_arbace_c_aotlib_A_const_57; var tmp7 any = A_arbace_c_aotlib_A_const_58; var tmp8 any = A_arbace_c_aotlib_A_const_59; var tmp9 any = A_arbace_c_aotlib_A_const_60; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(text__15)).Ref(); var tmp11 any = A_arbace_c_aotlib_A_const_61; var m__16 any = tmp5.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(info__14, tmp6, src__2, tmp7, pkg__5, tmp8, path__11, tmp9, tmp10, tmp11, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__9), 1.0e7)), 100.0)).Ref()); var root_296 any = A_arbace_c_aotlib_A_const_62.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_c_aotlib_write_atomic_A_fn_class); var ifn_298 lang.IFn







		if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = jrt.File_New_File_String(jrt.File_Cast(dir__6), Lit_28); var arg_300 any = text__15; if linked_297 == nil { ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { linked_297.(*A_arbace_c_aotlib_write_atomic_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) }
		var root_301 any = A_arbace_c_aotlib_A_const_62.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, A_arbace_c_aotlib_write_atomic_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = mf__7; var arg_305 any; var root_315 any = A_arbace_c_aotlib_A_const_65.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = lang.IFn_Cast(A_arbace_c_aotlib_A_const_66.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c_aotlib_A_const_67, nil, A_arbace_c_aotlib_A_const_68, nil); if linked_316 == nil { ifn_317.Invoke_O__O(arg_318) } else { linked_316.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_315, arg_318) }; var tmp12 *lang.Compiler_AOTFn; var fnbody__314 any = A_arbace_c_aotlib_make_unit_fn__1211000051_A_New_O(m__16); var tmp13 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_c_aotlib_make_unit_fn__1211000051_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__314); A_arbace_c_aotlib_make_unit_fn__1211000051_A_fn_class = fncls__313d; tmp13 = fncls__313d } else { tmp13 = fncls__313 }; tmp12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__314, tmp13, nil); arg_305 = Up_Compiler_AOTFn_IFn(tmp12).Invoke__O(); if linked_302 == nil { ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { linked_302.(*A_arbace_c_aotlib_write_atomic_A).Invoke_O_O_O__O(root_301, arg_304, arg_305) }
//line :94:1
		return m__16 } }
//line :94:1
func A_arbace_c_aotlib_make_unit_fn__1211000046_A_New_O(p0 any) *A_arbace_c_aotlib_make_unit_fn__1211000046_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_make_unit_fn__1211000046_A{}; t.Ctor_O(p0); return t }
//line :94:1
func (t *A_arbace_c_aotlib_make_unit_fn__1211000046_A) Ctor_O(c__mf any) { t.F_mf = c__mf }
//line :94:1
func (t *A_arbace_c_aotlib_make_unit_fn__1211000046_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_257 any = A_arbace_c_aotlib_A_const_51.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_52.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_mf; t.F_mf = nil; tmp3 = t_; arg_260 = tmp2.Invoke_O__O(tmp3); if linked_258 == nil { tmp1 = ifn_259.Invoke_O__O(arg_260) } else { tmp1 = linked_258.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_257, arg_260) } }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }








func A_arbace_c_aotlib_make_unit_fn__1211000051_A_New_O(p0 any) *A_arbace_c_aotlib_make_unit_fn__1211000051_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_make_unit_fn__1211000051_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_c_aotlib_make_unit_fn__1211000051_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :103:1
func (t *A_arbace_c_aotlib_make_unit_fn__1211000051_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_63.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_m; t.F_m = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_310 any = A_arbace_c_aotlib_A_const_64.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; if linked_311 == nil { ifn_312.Invoke__O() } else { linked_311.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_310) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_c_aotlib_unit_A_New() *A_arbace_c_aotlib_unit_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_unit_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_c_aotlib_unit_A) Ctor() {}
//line :106:1
func (t *A_arbace_c_aotlib_unit_A) Invoke_O_O_O_O__O(self, root__0, lib__1, src__2 any) any { var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c_aotlib_A_const_36.Invoke_O__O(lib__1), src__2); var d__5 any; var or__1927000174__auto____5 any = jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_69.GetRawRoot__O()).Get_O__O(k__4); if



	jrt.J2g_Truth(or__1927000174__auto____5) { d__5 = or__1927000174__auto____5 } else { var d__6 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__333 any = A_arbace_c_aotlib_unit_fn__1211000054_A_New_O_O_O(root__0, src__2, lib__1); var tmp2 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_c_aotlib_unit_fn__1211000054_A_fn_class; if fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__333); A_arbace_c_aotlib_unit_fn__1211000054_A_fn_class = fncls__332d; tmp2 = fncls__332d } else { tmp2 = fncls__332 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__333, tmp2, nil); d__6 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)); var or__1927000174__auto____7 any = jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_69.GetRawRoot__O()).PutIfAbsent_O_O__O(k__4, d__6); if jrt.J2g_Truth(or__1927000174__auto____7) { d__5 = or__1927000174__auto____7 } else { d__5 = d__6 } }; var root_334 any = /*line :109:1*/A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = d__5; if linked_335 == nil { return ifn_336.Invoke_O__O(arg_337) } else { return linked_335.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_334, arg_337) } }
func A_arbace_c_aotlib_unit_fn__1211000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_aotlib_unit_fn__1211000054_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_unit_fn__1211000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :110:1
func (t *A_arbace_c_aotlib_unit_fn__1211000054_A) Ctor_O_O_O(c__root, c__src, c__lib any) { t.F_root = c__root; t.F_src = c__src; t.F_lib = c__lib }
//line :110:1
func (t *A_arbace_c_aotlib_unit_fn__1211000054_A) Invoke_O__O(self any) any { var root_326 any = A_arbace_c_aotlib_A_const_70.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_c_aotlib_make_unit_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var t_ any = t.F_root; t.F_root = nil; arg_329 = t_; var arg_330 any; var t__2 any = t.F_lib; t.F_lib = nil; arg_330 = t__2; var arg_331 any; var t__3 any = t.F_src; t.F_src = nil; arg_331 = t__3; if linked_327 == nil { return ifn_328.Invoke_O_O_O__O(arg_329, arg_330, arg_331) } else { return linked_327.(*A_arbace_c_aotlib_make_unit_A).Invoke_O_O_O_O__O(root_326, arg_329, arg_330, arg_331) } }


func A_arbace_c_aotlib_program_pre_A_New() *A_arbace_c_aotlib_program_pre_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_c_aotlib_program_pre_A) Ctor() {}
//line :113:1
func (t *A_arbace_c_aotlib_program_pre_A) Invoke_O_O_O__O(self, root__0, p__1211000059__1 any) any { var map__1211000060__3 any = p__1211000059__1; var map__1211000060__4 any; if lang.ISeq_InstanceOf(map__1211000060__3) { var tmp1 any; var root_338 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = map__1211000060__3; if linked_339 == nil { tmp1 = ifn_340.Invoke_O__O(arg_341) } else { tmp1 = linked_339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_342 any = A_arbace_c_aotlib_A_const_71.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = map__1211000060__3; if linked_343 == nil { tmp2 = ifn_344.Invoke_O__O(arg_345) } else { tmp2 = linked_343.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_342, arg_345) }; map__1211000060__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_346 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = map__1211000060__3; if linked_347 == nil { tmp3 = ifn_348.Invoke_O__O(arg_349) } else { tmp3 = linked_347.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(tmp3) { var root_350 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = map__1211000060__3; if linked_351 == nil { map__1211000060__4 = ifn_352.Invoke_O__O(arg_353) } else { map__1211000060__4 = linked_351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_350, arg_353) } } else { map__1211000060__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1211000060__4 = map__1211000060__3 }; var trace__5 any = lang.RT_Get_O_O__O_NoInit(map__1211000060__4, A_arbace_c_aotlib_A_const_72); var frag_libs__6 any = lang.RT_Get_O_O__O_NoInit(map__1211000060__4, A_arbace_c_aotlib_A_const_73); var tmp4 any; var or__1927000174__auto____7 any = jrt.System_Getenv_String__String(Lit_30).Ref(); if




	jrt.J2g_Truth(or__1927000174__auto____7) { tmp4 = or__1927000174__auto____7 } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(trace__5, nil)).Ref() }; if jrt.J2g_Truth(tmp4) { return nil } else { var ___7 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__410 any = A_arbace_c_aotlib_program_pre_fn__1211000066_A_New_O_O(root__0, frag_libs__6); var tmp6 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_c_aotlib_program_pre_fn__1211000066_A_fn_class; _ = ___7


		if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__410); A_arbace_c_aotlib_program_pre_fn__1211000066_A_fn_class = fncls__409d; tmp6 = fncls__409d } else { tmp6 = fncls__409 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__410, tmp6, nil); ___7 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :118:1
		var used__8 any = jrt.TreeMap_New(); var alias_of__9 any; var fnbody__416 any = A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_New_O(used__8); var tmp7 *jrt.Class
		var fncls__415 /*line :118:1*/*jrt.Class = A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_fn_class





		if fncls__415 == nil { var fncls__415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__416); A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_fn_class = fncls__415d; tmp7 = fncls__415d } else { tmp7 = fncls__415 }; alias_of__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__416, tmp7, nil)
//line :118:1
		var items__10 any; var root_417 any = A_arbace_c_aotlib_A_const_76.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_419 lang.IFn







		if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_421 any; var iter__1927001039__auto____10 any; var fnbody__513 any = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_New_O_O_O(root__0, frag_libs__6, alias_of__9); var tmp8 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__513); A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_fn_class = fncls__512d; tmp8 = fncls__512d } else { tmp8 = fncls__512 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__513, tmp8, nil); arg_421 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_c_aotlib_A_const_82.Invoke_O__O(trace__5)); if linked_418 == nil { items__10 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { items__10 = linked_418.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_417, arg_420, arg_421) }
//line :118:1
		var tmp9 any = A_arbace_c_aotlib_A_const_82; var tmp10 any = A_arbace_c_aotlib_A_const_83; var tmp11 any; var root_514 any = A_arbace_c_aotlib_A_const_84.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_516 lang.IFn















		if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var iter__1927001039__auto____11 any; var fnbody__579 any = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_New(); var tmp12 *jrt.Class; var fncls__578 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_fn_class; if fncls__578 == nil { var fncls__578d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_fn_class = fncls__578d; tmp12 = fncls__578d } else { tmp12 = fncls__578 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__579, tmp12, nil); arg_517 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(used__8); if linked_515 == nil { tmp11 = ifn_516.Invoke_O__O(arg_517) } else { tmp11 = linked_515.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_514, arg_517) }
//line :118:1
		var tmp13 any = tmp11; var tmp14 any = A_arbace_c_aotlib_A_const_85; var tmp15 any; var root_580 any = A_arbace_c_aotlib_A_const_84.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_582 lang.IFn
















		if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any; var iter__1927001039__auto____11_2 any; var fnbody__673 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_New_O(trace__5); var tmp16 *jrt.Class; var fncls__672 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_fn_class; if fncls__672 == nil { var fncls__672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__673); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_fn_class = fncls__672d; tmp16 = fncls__672d } else { tmp16 = fncls__672 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__673, tmp16, nil); arg_583 = lang.IFn_Cast(iter__1927001039__auto____11_2).Invoke_O__O(used__8); if linked_581 == nil { tmp15 = ifn_582.Invoke_O__O(arg_583) } else { tmp15 = linked_581.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_580, arg_583) }
//line :118:1
		var tmp17 any = tmp15; var tmp18 any = A_arbace_c_aotlib_A_const_90; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, items__10, tmp10, tmp13, tmp14, tmp17, tmp18, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(used__8)).Ref())) } }


func A_arbace_c_aotlib_program_pre_fn__1211000066_A_New_O_O(p0, p1 any) *A_arbace_c_aotlib_program_pre_fn__1211000066_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_fn__1211000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_c_aotlib_program_pre_fn__1211000066_A) Ctor_O_O(c__root, c__frag_libs any) { t.F_root = c__root; t.F_frag_libs = c__frag_libs }
//line :121:1
func (t *A_arbace_c_aotlib_program_pre_fn__1211000066_A) Invoke_O__O(self any) any { { var seq_1211000062__1 any; var root_354 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var root_358 any = A_arbace_c_aotlib_A_const_74.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any; var root_362 any = A_arbace_c_aotlib_A_const_75.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var arg_366 any; var t_ any = t.F_frag_libs; t.F_frag_libs = nil; arg_366 = t_; if linked_363 == nil { arg_361 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { arg_361 = linked_363.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }; if linked_359 == nil { arg_357 = ifn_360.Invoke_O__O(arg_361) } else { arg_357 = linked_359.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_358, arg_361) }; if linked_355 == nil { seq_1211000062__1 = ifn_356.Invoke_O__O(arg_357) } else { seq_1211000062__1 = linked_355.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_354, arg_357) }; var chunk_1211000063__2 any; var count_1211000064__3 int64 = 0; var i_1211000065__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1211000065__4, count_1211000064__3) { var lib__5 any = lang.Indexed_Cast(chunk_1211000063__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1211000065__4)); var d__6 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil); var tmp2 any; var root_383 any = A_arbace_c_aotlib_A_const_50.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_c_aotlib_cache_root_A_fn_class); var ifn_385 lang.IFn
											if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = t.F_root; if linked_384 == nil { tmp2 = ifn_385.Invoke_O__O(arg_386) } else { tmp2 = linked_384.(*A_arbace_c_aotlib_cache_root_A).Invoke_O_O__O(root_383, arg_386) }
//line :121:1
	var tmp3 any = tmp2; var tmp4 any; var root_387 any = A_arbace_c_aotlib_A_const_48.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, A_arbace_c_aotlib_lib_dir_name_A_fn_class); var ifn_389 lang.IFn
	if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = t.F_root; var arg_391 any = lib__5; if linked_388 == nil { tmp4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { tmp4 = linked_388.(*A_arbace_c_aotlib_lib_dir_name_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }
//line :121:1
	d__6 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)))
	if jrt.File_Cast(d__6).IsDirectory__Z() { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(d__6).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J())) }
//line :121:1
	seq_1211000062__1, chunk_1211000063__2, count_1211000064__3, i_1211000065__4 = seq_1211000062__1, chunk_1211000063__2, count_1211000064__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1211000065__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_367 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = seq_1211000062__1; if linked_368 == nil { temp__1927000414__auto____5 = ifn_369.Invoke_O__O(arg_370) } else { temp__1927000414__auto____5 = linked_368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1211000062__6 any = temp__1927000414__auto____5; var tmp5 any; var root_371 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = seq_1211000062__6; if linked_372 == nil { tmp5 = ifn_373.Invoke_O__O(arg_374) } else { tmp5 = linked_372.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____7 any; var root_375 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = seq_1211000062__6; if linked_376 == nil { c__1927000678__auto____7 = ifn_377.Invoke_O__O(arg_378) } else { c__1927000678__auto____7 = linked_376.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_375, arg_378) }; var tmp6 any; var root_392 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = seq_1211000062__6; if linked_393 == nil { tmp6 = ifn_394.Invoke_O__O(arg_395) } else { tmp6 = linked_393.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_392, arg_395) }; seq_1211000062__1, chunk_1211000063__2, count_1211000064__3, i_1211000065__4 = tmp6, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var lib__7 any; var root_379 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = seq_1211000062__6; if linked_380 == nil { lib__7 = ifn_381.Invoke_O__O(arg_382) } else { lib__7 = linked_380.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_379, arg_382) }; var d__8 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil); var tmp8 any; var root_396 any = A_arbace_c_aotlib_A_const_50.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, A_arbace_c_aotlib_cache_root_A_fn_class); var ifn_398 lang.IFn
		if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = t.F_root; if linked_397 == nil { tmp8 = ifn_398.Invoke_O__O(arg_399) } else { tmp8 = linked_397.(*A_arbace_c_aotlib_cache_root_A).Invoke_O_O__O(root_396, arg_399) }
//line :121:1
		var tmp9 any = tmp8; var tmp10 any; var root_400 any = A_arbace_c_aotlib_A_const_48.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_c_aotlib_lib_dir_name_A_fn_class); var ifn_402 lang.IFn
		if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = t.F_root; var arg_404 any = lib__7; if linked_401 == nil { tmp10 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { tmp10 = linked_401.(*A_arbace_c_aotlib_lib_dir_name_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }
//line :121:1
		d__8 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)))
		if jrt.File_Cast(d__8).IsDirectory__Z() { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(d__8).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J())) }
//line :121:1
		var tmp11 any; var root_405 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = seq_1211000062__6; if linked_406 == nil { tmp11 = ifn_407.Invoke_O__O(arg_408) } else { tmp11 = linked_406.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_405, arg_408) }; seq_1211000062__1, chunk_1211000063__2, count_1211000064__3, i_1211000065__4 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_New_O(p0 any) *A_arbace_c_aotlib_program_pre_alias_of__1211000068_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_alias_of__1211000068_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_c_aotlib_program_pre_alias_of__1211000068_A) Ctor_O(c__used any) { t.F_used = c__used }
//line :124:1
func (t *A_arbace_c_aotlib_program_pre_alias_of__1211000068_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var or__1927000174__auto____3 any; var root_411 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = jrt.TreeMap_Cast(t.F_used).Get_O__O(i__1); if linked_412 == nil { or__1927000174__auto____3 = ifn_413.Invoke_O__O(arg_414) } else { or__1927000174__auto____3 = linked_412.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var a__4 any = A_arbace_c_aotlib_A_const_58.Invoke_O__O(m__2); var tmp1 jrt.TreeMap_I = jrt.TreeMap_Cast(t.F_used)
														tmp1.Put_O_O__O(i__1, lang.Tuple_Create_O_O__IPersistentVector(a__4, m__2))
//line :124:1
	return a__4 } }

func A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A) Ctor_O_O_O(c__root, c__frag_libs, c__alias_of any) { t.F_root = c__root; t.F_frag_libs = c__frag_libs; t.F_alias_of = c__alias_of }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A) Invoke_O_O__O(self, s__1211000071__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__511 any = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_New_O_O_O_O_O(t.F_root, s__1211000071__1, self, t.F_frag_libs, t.F_alias_of); var tmp2 *jrt.Class; var fncls__510 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_fn_class; if fncls__510 == nil { var fncls__510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__511); A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_fn_class = fncls__510d; tmp2 = fncls__510d } else { tmp2 = fncls__510 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__511, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :126:1
func A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A) Ctor_O_O_O_O_O(c__root, c__s__1211000071, c__iter__1211000070, c__frag_libs, c__alias_of any) { t.F_root = c__root; t.F_s__1211000071 = c__s__1211000071; t.F_iter__1211000070 = c__iter__1211000070; t.F_frag_libs = c__frag_libs; t.F_alias_of = c__alias_of }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A) Invoke_O__O(self any) any { { var s__1211000071__1 any; var t_ any = t.F_s__1211000071; t.F_s__1211000071 = nil; s__1211000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_422 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = s__1211000071__1; if linked_423 == nil { temp__1927000414__auto____2 = ifn_424.Invoke_O__O(arg_425) } else { temp__1927000414__auto____2 = linked_423.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1211000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_426 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = s__1211000071__3; if linked_427 == nil { tmp1 = ifn_428.Invoke_O__O(arg_429) } else { tmp1 = linked_427.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_426, arg_429) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_430 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = s__1211000071__3; if linked_431 == nil { c__1927001037__auto____4 = ifn_432.Invoke_O__O(arg_433) } else { c__1927001037__auto____4 = linked_431.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_430, arg_433) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1211000073__6 any; var root_434 any = A_arbace_c_aotlib_A_const_27.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_435 == nil { b__1211000073__6 = ifn_436.Invoke_O__O(arg_437) } else { b__1211000073__6 = linked_435.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_434, arg_437) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__455 any = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_New_O_O_O_I_O_O(t.F_root, t.F_frag_libs, b__1211000073__6, size__1927001038__auto____5, t.F_alias_of, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__454 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_fn_class; if fncls__454 == nil { var fncls__454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__455); A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_fn_class = fncls__454d; tmp3 = fncls__454d } else { tmp3 = fncls__454 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__455, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_456 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_461 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = b__1211000073__6; if linked_462 == nil { arg_459 = ifn_463.Invoke_O__O(arg_464) } else { arg_459 = linked_462.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_461, arg_464) }; var arg_460 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1211000070); var tmp5 any; var root_465 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = s__1211000071__3; if linked_466 == nil { tmp5 = ifn_467.Invoke_O__O(arg_468) } else { tmp5 = linked_466.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_465, arg_468) }; arg_460 = tmp4.Invoke_O__O(tmp5); if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } } else { var root_469 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var root_474 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = b__1211000073__6; if linked_475 == nil { arg_472 = ifn_476.Invoke_O__O(arg_477) } else { arg_472 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_474, arg_477) }; var arg_473 any; if linked_470 == nil { return ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { return linked_470.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } } else { var vec__1211000087__4 any; var root_478 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = s__1211000071__3; if linked_479 == nil { vec__1211000087__4 = ifn_480.Invoke_O__O(arg_481) } else { vec__1211000087__4 = linked_479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_478, arg_481) }; var line__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000087__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000090__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000087__4, lang.RT_IntCast_J__I_NoInit(1), nil); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000090__6, lang.RT_IntCast_J__I_NoInit(0), nil); var kind__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000090__6, lang.RT_IntCast_J__I_NoInit(1), nil); var j__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000090__6, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1211000093__10 any = lang.RT_Get_O_O__O_NoInit(t.F_frag_libs, i__7); var lib__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000093__10, lang.RT_IntCast_J__I_NoInit(0), nil); var src__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000093__10, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(lib__11) { var m__13 any; var root_482 any = A_arbace_c_aotlib_A_const_77.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_c_aotlib_unit_A_fn_class); var ifn_484 lang.IFn


	if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = t.F_root; var arg_486 any = lib__11; var arg_487 any = src__12; if linked_483 == nil { m__13 = ifn_484.Invoke_O_O_O__O(arg_485, arg_486, arg_487) } else { m__13 = linked_483.(*A_arbace_c_aotlib_unit_A).Invoke_O_O_O_O__O(root_482, arg_485, arg_486, arg_487) }
//line :126:1
	var g__14 any; var tmp6 any



	if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_c_aotlib_A_const_78) { tmp6 = A_arbace_c_aotlib_A_const_79.Invoke_O__O(m__13) } else { tmp6 = A_arbace_c_aotlib_A_const_80.Invoke_O__O(m__13) }; g__14 = lang.RT_Get_O_O__O_NoInit(tmp6, j__9)
//line :126:1
	if jrt.J2g_Truth(g__14) { var root_488 any = A_arbace_c_aotlib_A_const_32.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any; var tmp7 any; var root_493 any = A_arbace_c_aotlib_A_const_81.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_495 lang.IFn





		if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = lang.IFn_Cast(t.F_alias_of).Invoke_O_O__O(i__7, m__13); var arg_497 any = g__14; if linked_494 == nil { tmp7 = ifn_495.Invoke_O_O__O(arg_496, arg_497) } else { tmp7 = linked_494.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_493, arg_496, arg_497) }
//line :126:1
		arg_491 = lang.Tuple_Create_O_O__IPersistentVector(line__5, tmp7); var arg_492 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1211000070); var tmp9 any; var root_498 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1211000071__3; if linked_499 == nil { tmp9 = ifn_500.Invoke_O__O(arg_501) } else { tmp9 = linked_499.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_498, arg_501) }; arg_492 = tmp8.Invoke_O__O(tmp9); if linked_489 == nil { return ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { return linked_489.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) } } else { var tmp10 any; var root_502 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = s__1211000071__3; if linked_503 == nil { tmp10 = ifn_504.Invoke_O__O(arg_505) } else { tmp10 = linked_503.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_502, arg_505) }; s__1211000071__1 = tmp10; continue L1 } } else { var tmp11 any; var root_506 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = s__1211000071__3; if linked_507 == nil { tmp11 = ifn_508.Invoke_O__O(arg_509) } else { tmp11 = linked_507.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_506, arg_509) }; s__1211000071__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :126:1
func A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A) Ctor_O_O_O_I_O_O(c__root, c__frag_libs, c__b__1211000073 any, c__size__1927001038__auto__ int32, c__alias_of, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_frag_libs = c__frag_libs; t.F_b__1211000073 = c__b__1211000073; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_alias_of = c__alias_of; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :126:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A) Invoke_O__O(self any) any { { var i__1211000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1211000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1211000077__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1211000072__1)); var line__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000077__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000080__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000077__2, lang.RT_IntCast_J__I_NoInit(1), nil); var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var kind__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000080__4, lang.RT_IntCast_J__I_NoInit(1), nil); var j__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000080__4, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1211000083__8 any = lang.RT_Get_O_O__O_NoInit(t.F_frag_libs, i__5); var lib__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000083__8, lang.RT_IntCast_J__I_NoInit(0), nil); var src__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000083__8, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(lib__9) { var m__11 any; var root_438 any = A_arbace_c_aotlib_A_const_77.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_c_aotlib_unit_A_fn_class); var ifn_440 lang.IFn


	if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = t.F_root; var arg_442 any = lib__9; var arg_443 any = src__10; if linked_439 == nil { m__11 = ifn_440.Invoke_O_O_O__O(arg_441, arg_442, arg_443) } else { m__11 = linked_439.(*A_arbace_c_aotlib_unit_A).Invoke_O_O_O_O__O(root_438, arg_441, arg_442, arg_443) }
//line :126:1
	var g__12 any; var tmp2 any



	if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_c_aotlib_A_const_78) { tmp2 = A_arbace_c_aotlib_A_const_79.Invoke_O__O(m__11) } else { tmp2 = A_arbace_c_aotlib_A_const_80.Invoke_O__O(m__11) }; g__12 = lang.RT_Get_O_O__O_NoInit(tmp2, j__7)
//line :126:1
	if jrt.J2g_Truth(g__12) { var root_444 any = A_arbace_c_aotlib_A_const_28.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = t.F_b__1211000073; var arg_448 any; var tmp3 any; var root_449 any = A_arbace_c_aotlib_A_const_81.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_451 lang.IFn





		if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = lang.IFn_Cast(t.F_alias_of).Invoke_O_O__O(i__5, m__11); var arg_453 any = g__12; if linked_450 == nil { tmp3 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { tmp3 = linked_450.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) }
//line :126:1
		arg_448 = lang.Tuple_Create_O_O__IPersistentVector(line__3, tmp3); if linked_445 == nil { ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { linked_445.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }; i__1211000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000072__1); continue L1 } else { i__1211000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000072__1); continue L1 } } else { i__1211000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_New() *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A) Ctor() {}
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A) Invoke_O_O__O(self, s__1211000099__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__577 any = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_New_O_O(s__1211000099__1, self); var tmp2 *jrt.Class; var fncls__576 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_fn_class; if fncls__576 == nil { var fncls__576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__577); A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_fn_class = fncls__576d; tmp2 = fncls__576d } else { tmp2 = fncls__576 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__577, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :134:1
func A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_New_O_O(p0, p1 any) *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A) Ctor_O_O(c__s__1211000099, c__iter__1211000098 any) { t.F_s__1211000099 = c__s__1211000099; t.F_iter__1211000098 = c__iter__1211000098 }
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A) Invoke_O__O(self any) any { { var s__1211000099__1 any; var t_ any = t.F_s__1211000099; t.F_s__1211000099 = nil; s__1211000099__1 = t_; for { var temp__1927000414__auto____2 any; var root_518 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = s__1211000099__1; if linked_519 == nil { temp__1927000414__auto____2 = ifn_520.Invoke_O__O(arg_521) } else { temp__1927000414__auto____2 = linked_519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_518, arg_521) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1211000099__3 any = temp__1927000414__auto____2; var tmp1 any; var root_522 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = s__1211000099__3; if linked_523 == nil { tmp1 = ifn_524.Invoke_O__O(arg_525) } else { tmp1 = linked_523.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_522, arg_525) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_526 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = s__1211000099__3; if linked_527 == nil { c__1927001037__auto____4 = ifn_528.Invoke_O__O(arg_529) } else { c__1927001037__auto____4 = linked_527.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_526, arg_529) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1211000101__6 any; var root_530 any = A_arbace_c_aotlib_A_const_27.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_531 == nil { b__1211000101__6 = ifn_532.Invoke_O__O(arg_533) } else { b__1211000101__6 = linked_531.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_530, arg_533) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__540 any = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1211000101__6); var tmp3 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__540); A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_fn_class = fncls__539d; tmp3 = fncls__539d } else { tmp3 = fncls__539 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__540, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_541 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any; var root_546 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = b__1211000101__6; if linked_547 == nil { arg_544 = ifn_548.Invoke_O__O(arg_549) } else { arg_544 = linked_547.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_546, arg_549) }; var arg_545 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1211000098); var tmp5 any; var root_550 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__1211000099__3; if linked_551 == nil { tmp5 = ifn_552.Invoke_O__O(arg_553) } else { tmp5 = linked_551.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_550, arg_553) }; arg_545 = tmp4.Invoke_O__O(tmp5); if linked_542 == nil { return ifn_543.Invoke_O_O__O(arg_544, arg_545) } else { return linked_542.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_541, arg_544, arg_545) } } else { var root_554 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var root_559 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = b__1211000101__6; if linked_560 == nil { arg_557 = ifn_561.Invoke_O__O(arg_562) } else { arg_557 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_559, arg_562) }; var arg_558 any; if linked_555 == nil { return ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { return linked_555.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) } } } else { var vec__1211000112__4 any; var root_563 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__1211000099__3; if linked_564 == nil { vec__1211000112__4 = ifn_565.Invoke_O__O(arg_566) } else { vec__1211000112__4 = linked_564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_563, arg_566) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000115__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var a__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000115__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000115__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_567 any = A_arbace_c_aotlib_A_const_32.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_569 lang.IFn; _ = ___5; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = lang.Tuple_Create_O_O__IPersistentVector(a__7, A_arbace_c_aotlib_A_const_59.Invoke_O__O(m__8)); var arg_571 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1211000098); var tmp7 any; var root_572 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__1211000099__3; if linked_573 == nil { tmp7 = ifn_574.Invoke_O__O(arg_575) } else { tmp7 = linked_573.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_572, arg_575) }; arg_571 = tmp6.Invoke_O__O(tmp7); if linked_568 == nil { return ifn_569.Invoke_O_O__O(arg_570, arg_571) } else { return linked_568.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_567, arg_570, arg_571) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :134:1
func A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1211000101 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1211000101 = c__b__1211000101 }
//line :134:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A) Invoke_O__O(self any) any { { var i__1211000100__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1211000100__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1211000105__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1211000100__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000105__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000108__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000105__2, lang.RT_IntCast_J__I_NoInit(1), nil); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000108__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000108__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_534 any = A_arbace_c_aotlib_A_const_28.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_536 lang.IFn; _ = ___3; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = t.F_b__1211000101; var arg_538 any = lang.Tuple_Create_O_O__IPersistentVector(a__5, A_arbace_c_aotlib_A_const_59.Invoke_O__O(m__6)); if linked_535 == nil { ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { linked_535.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }; i__1211000100__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000100__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_New_O(p0 any) *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A) Ctor_O(c__trace any) { t.F_trace = c__trace }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A) Invoke_O_O__O(self, s__1211000121__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__671 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_New_O_O_O(t.F_trace, s__1211000121__1, self); var tmp2 *jrt.Class; var fncls__670 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_fn_class; if fncls__670 == nil { var fncls__670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__671); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_fn_class = fncls__670d; tmp2 = fncls__670d } else { tmp2 = fncls__670 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__671, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :135:1
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A) Ctor_O_O_O(c__trace, c__s__1211000121, c__iter__1211000120 any) { t.F_trace = c__trace; t.F_s__1211000121 = c__s__1211000121; t.F_iter__1211000120 = c__iter__1211000120 }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A) Invoke_O__O(self any) any { { var s__1211000121__1 any; var t_ any = t.F_s__1211000121; t.F_s__1211000121 = nil; s__1211000121__1 = t_; for { var temp__1927000414__auto____2 any; var root_584 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__1211000121__1; if linked_585 == nil { temp__1927000414__auto____2 = ifn_586.Invoke_O__O(arg_587) } else { temp__1927000414__auto____2 = linked_585.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_584, arg_587) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1211000121__3 any = temp__1927000414__auto____2; var tmp1 any; var root_588 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = s__1211000121__3; if linked_589 == nil { tmp1 = ifn_590.Invoke_O__O(arg_591) } else { tmp1 = linked_589.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_588, arg_591) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_592 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = s__1211000121__3; if linked_593 == nil { c__1927001037__auto____4 = ifn_594.Invoke_O__O(arg_595) } else { c__1927001037__auto____4 = linked_593.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_592, arg_595) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1211000123__6 any; var root_596 any = A_arbace_c_aotlib_A_const_27.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_597 == nil { b__1211000123__6 = ifn_598.Invoke_O__O(arg_599) } else { b__1211000123__6 = linked_597.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_596, arg_599) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__620 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_New_O_I_O_O(t.F_trace, size__1927001038__auto____5, c__1927001037__auto____4, b__1211000123__6); var tmp3 *jrt.Class; var fncls__619 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_fn_class; if fncls__619 == nil { var fncls__619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__620); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_fn_class = fncls__619d; tmp3 = fncls__619d } else { tmp3 = fncls__619 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__620, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_621 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_626 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = b__1211000123__6; if linked_627 == nil { arg_624 = ifn_628.Invoke_O__O(arg_629) } else { arg_624 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_626, arg_629) }; var arg_625 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1211000120); var tmp5 any; var root_630 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = s__1211000121__3; if linked_631 == nil { tmp5 = ifn_632.Invoke_O__O(arg_633) } else { tmp5 = linked_631.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_630, arg_633) }; arg_625 = tmp4.Invoke_O__O(tmp5); if linked_622 == nil { return ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { return linked_622.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) } } else { var root_634 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any; var root_639 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = b__1211000123__6; if linked_640 == nil { arg_637 = ifn_641.Invoke_O__O(arg_642) } else { arg_637 = linked_640.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_639, arg_642) }; var arg_638 any; if linked_635 == nil { return ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { return linked_635.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) } } } else { var vec__1211000138__4 any; var root_643 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__1211000121__3; if linked_644 == nil { vec__1211000138__4 = ifn_645.Invoke_O__O(arg_646) } else { vec__1211000138__4 = linked_644.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_643, arg_646) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000138__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000141__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000138__4, lang.RT_IntCast_J__I_NoInit(1), nil); var a__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000141__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000141__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_647 any = A_arbace_c_aotlib_A_const_32.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_649 lang.IFn; _ = ___8; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any; var tmp6 any; var root_652 any = A_arbace_c_aotlib_A_const_86.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_654 lang.IFn
														if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var fnbody__658 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_New(); var tmp7 *jrt.Class; var fncls__657 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_fn_class; if fncls__657 == nil { var fncls__657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_fn_class = fncls__657d; tmp7 = fncls__657d } else { tmp7 = fncls__657 }; arg_655 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__658, tmp7, nil); var arg_656 any = lang.IFn_Cast(A_arbace_c_aotlib_A_const_88.Invoke_O__O(t.F_trace)).Invoke_O__O(i__5); if linked_653 == nil { tmp6 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { tmp6 = linked_653.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }
//line :135:1
	var tmp8 any = tmp6; var tmp9 any; var root_659 any = A_arbace_c_aotlib_A_const_86.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_661 lang.IFn
	if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any; var fnbody__665 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_New(); var tmp10 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_fn_class = fncls__664d; tmp10 = fncls__664d } else { tmp10 = fncls__664 }; arg_662 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__665, tmp10, nil); var arg_663 any = lang.IFn_Cast(A_arbace_c_aotlib_A_const_89.Invoke_O__O(t.F_trace)).Invoke_O__O(i__5); if linked_660 == nil { tmp9 = ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { tmp9 = linked_660.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }
//line :135:1
	arg_650 = lang.Tuple_Create_O_O_O__IPersistentVector(a__7, tmp8, tmp9); var arg_651 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1211000120); var tmp12 any; var root_666 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = s__1211000121__3; if linked_667 == nil { tmp12 = ifn_668.Invoke_O__O(arg_669) } else { tmp12 = linked_667.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_666, arg_669) }; arg_651 = tmp11.Invoke_O__O(tmp12); if linked_648 == nil { return ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { return linked_648.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A) Ctor_O_I_O_O(c__trace any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1211000123 any) { t.F_trace = c__trace; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1211000123 = c__b__1211000123 }
//line :135:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A) Invoke_O__O(self any) any { { var i__1211000122__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1211000122__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1211000127__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1211000122__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000127__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1211000130__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000127__2, lang.RT_IntCast_J__I_NoInit(1), nil); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000130__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000130__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_600 any = A_arbace_c_aotlib_A_const_28.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_602 lang.IFn; _ = ___6; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = t.F_b__1211000123; var arg_604 any; var tmp2 any; var root_605 any = A_arbace_c_aotlib_A_const_86.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_607 lang.IFn
																if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var fnbody__611 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_New(); var tmp3 *jrt.Class; var fncls__610 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_fn_class; if fncls__610 == nil { var fncls__610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_fn_class = fncls__610d; tmp3 = fncls__610d } else { tmp3 = fncls__610 }; arg_608 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__611, tmp3, nil); var arg_609 any = lang.IFn_Cast(A_arbace_c_aotlib_A_const_88.Invoke_O__O(t.F_trace)).Invoke_O__O(i__3); if linked_606 == nil { tmp2 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { tmp2 = linked_606.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }
//line :135:1
	var tmp4 any = tmp2; var tmp5 any; var root_612 any = A_arbace_c_aotlib_A_const_86.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_614 lang.IFn
	if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var fnbody__618 any = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_New(); var tmp6 *jrt.Class; var fncls__617 *jrt.Class = A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_fn_class; if fncls__617 == nil { var fncls__617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_fn_class = fncls__617d; tmp6 = fncls__617d } else { tmp6 = fncls__617 }; arg_615 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__618, tmp6, nil); var arg_616 any = lang.IFn_Cast(A_arbace_c_aotlib_A_const_89.Invoke_O__O(t.F_trace)).Invoke_O__O(i__3); if linked_613 == nil { tmp5 = ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { tmp5 = linked_613.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) }
//line :135:1
	arg_604 = lang.Tuple_Create_O_O_O__IPersistentVector(a__5, tmp4, tmp5); if linked_601 == nil { ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { linked_601.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; i__1211000122__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000122__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_New() *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A) Ctor() {}
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A) Invoke_O_O__O(self, p1__1211000057_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(p1__1211000057_SHARP___1, nil) { return A_arbace_c_aotlib_A_const_87 } else { return p1__1211000057_SHARP___1 } }
//line :136:1
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_New() *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A) Ctor() {}
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A) Invoke_O_O__O(self, p1__1211000058_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(p1__1211000058_SHARP___1, nil) { return A_arbace_c_aotlib_A_const_87 } else { return p1__1211000058_SHARP___1 } }
//line :136:1
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_New() *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A) Ctor() {}
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A) Invoke_O_O__O(self, p1__1211000057_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(p1__1211000057_SHARP___1, nil) { return A_arbace_c_aotlib_A_const_87 } else { return p1__1211000057_SHARP___1 } }
//line :136:1
func A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_New() *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A) Ctor() {}
//line :136:1
func (t *A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A) Invoke_O_O__O(self, p1__1211000058_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(p1__1211000058_SHARP___1, nil) { return A_arbace_c_aotlib_A_const_87 } else { return p1__1211000058_SHARP___1 } }


func A_arbace_c_aotlib_translate_lib_A_New() *A_arbace_c_aotlib_translate_lib_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_c_aotlib_translate_lib_A) Ctor() {}
//line :139:1
func (t *A_arbace_c_aotlib_translate_lib_A) Invoke_O_O_O_O_O__O(self, root__0, lib__1, srcs__2, threads__3 any) any { var q__5 any; var tmp1 any; var root_674 any = A_arbace_c_aotlib_A_const_84.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_676 lang.IFn; if


	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = srcs__2; if linked_675 == nil { tmp1 = ifn_676.Invoke_O__O(arg_677) } else { tmp1 = linked_675.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_674, arg_677) }; q__5 = /*line :139:1*/jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(tmp1)); var acc__6 any; var root_678 any = A_arbace_c_aotlib_A_const_91.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_680 lang.IFn; if



	linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = A_arbace_c_aotlib_A_const_92; if linked_679 == nil { acc__6 = ifn_680.Invoke_O__O(arg_681) } else { acc__6 = linked_679.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_678, arg_681) }; var ws__7 any; var root_682 any = /*line :139:1*/A_arbace_c_aotlib_A_const_93.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_684 lang.IFn; if




	linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any; var iter__1927001039__auto____7 any; var fnbody__839 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_New_O_O_O_O(root__0, lib__1, q__5, acc__6); var tmp2 *jrt.Class; var fncls__838 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_fn_class; if fncls__838 == nil { var fncls__838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__839); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_fn_class = fncls__838d; tmp2 = fncls__838d } else { tmp2 = fncls__838 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__839, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_840 any = A_arbace_c_aotlib_A_const_102.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = threads__3; if linked_841 == nil { tmp4 = ifn_842.Invoke_O__O(arg_843) } else { tmp4 = linked_841.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_840, arg_843) }; arg_685 = tmp3.Invoke_O__O(tmp4); if linked_683 == nil { ws__7 = ifn_684.Invoke_O__O(arg_685) } else { ws__7 = linked_683.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_682, arg_685) }; var seq_1211000170__8 any; var root_848 any = /*line :139:1*/A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_850 lang.IFn; if













	linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = ws__7; if linked_849 == nil { seq_1211000170__8 = ifn_850.Invoke_O__O(arg_851) } else { seq_1211000170__8 = linked_849.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_848, arg_851) }; var chunk_1211000171__9 any; var count_1211000172__10 int64 = 0; var i_1211000173__11 int64 = 0; L1:
//line :139:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_1211000173__11, count_1211000172__10) { var w__12 any = lang.Indexed_Cast(chunk_1211000171__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1211000173__11)); var root_868 any = A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = w__12; if linked_869 == nil { ifn_870.Invoke_O__O(arg_871) } else { linked_869.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_868, arg_871) }; seq_1211000170__8, chunk_1211000171__9, count_1211000172__10, i_1211000173__11 = seq_1211000170__8, chunk_1211000171__9, count_1211000172__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1211000173__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_852 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = seq_1211000170__8; if linked_853 == nil { temp__1927000414__auto____12 = ifn_854.Invoke_O__O(arg_855) } else { temp__1927000414__auto____12 = linked_853.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1211000170__13 any = temp__1927000414__auto____12; var tmp5 any; var root_856 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = seq_1211000170__13; if linked_857 == nil { tmp5 = ifn_858.Invoke_O__O(arg_859) } else { tmp5 = linked_857.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_856, arg_859) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_860 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = seq_1211000170__13; if linked_861 == nil { c__1927000678__auto____14 = ifn_862.Invoke_O__O(arg_863) } else { c__1927000678__auto____14 = linked_861.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_860, arg_863) }; var tmp6 any; var root_872 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = seq_1211000170__13; if linked_873 == nil { tmp6 = ifn_874.Invoke_O__O(arg_875) } else { tmp6 = linked_873.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_872, arg_875) }; seq_1211000170__8, chunk_1211000171__9, count_1211000172__10, i_1211000173__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_864 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = seq_1211000170__13; if linked_865 == nil { w__14 = ifn_866.Invoke_O__O(arg_867) } else { w__14 = linked_865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_864, arg_867) }; var root_876 any = A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = w__14; if linked_877 == nil { ifn_878.Invoke_O__O(arg_879) } else { linked_877.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_876, arg_879) }; var tmp7 any; var root_880 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = seq_1211000170__13; if linked_881 == nil { tmp7 = ifn_882.Invoke_O__O(arg_883) } else { tmp7 = linked_881.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_880, arg_883) }; seq_1211000170__8, chunk_1211000171__9, count_1211000172__10, i_1211000173__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :139:1
		break L1 }; var root_844 any =


	A_arbace_c_aotlib_A_const_10.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = acc__6; if linked_845 == nil { return ifn_846.Invoke_O__O(arg_847) } else { return linked_845.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_844, arg_847) } }

func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A) Ctor_O_O_O_O(c__root, c__lib, c__q, c__acc any) { t.F_root = c__root; t.F_lib = c__lib; t.F_q = c__q; t.F_acc = c__acc }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A) Invoke_O_O__O(self, s__1211000153__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__837 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_New_O_O_O_O_O_O(t.F_root, t.F_lib, t.F_q, s__1211000153__1, self, t.F_acc); var tmp2 *jrt.Class; var fncls__836 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_fn_class; if fncls__836 == nil { var fncls__836d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__837); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_fn_class = fncls__836d; tmp2 = fncls__836d } else { tmp2 = fncls__836 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__837, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :144:1
func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A) Ctor_O_O_O_O_O_O(c__root, c__lib, c__q, c__s__1211000153, c__iter__1211000152, c__acc any) { t.F_root = c__root; t.F_lib = c__lib; t.F_q = c__q; t.F_s__1211000153 = c__s__1211000153; t.F_iter__1211000152 = c__iter__1211000152; t.F_acc = c__acc }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A) Invoke_O__O(self any) any { { var s__1211000153__1 any; var t_ any = t.F_s__1211000153; t.F_s__1211000153 = nil; s__1211000153__1 = t_; for { var temp__1927000414__auto____2 any; var root_686 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = s__1211000153__1; if linked_687 == nil { temp__1927000414__auto____2 = ifn_688.Invoke_O__O(arg_689) } else { temp__1927000414__auto____2 = linked_687.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1211000153__3 any = temp__1927000414__auto____2; var tmp1 any; var root_690 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__1211000153__3; if linked_691 == nil { tmp1 = ifn_692.Invoke_O__O(arg_693) } else { tmp1 = linked_691.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_694 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__1211000153__3; if linked_695 == nil { c__1927001037__auto____4 = ifn_696.Invoke_O__O(arg_697) } else { c__1927001037__auto____4 = linked_695.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_694, arg_697) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1211000155__6 any; var root_698 any = A_arbace_c_aotlib_A_const_27.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_699 == nil { b__1211000155__6 = ifn_700.Invoke_O__O(arg_701) } else { b__1211000155__6 = linked_699.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_698, arg_701) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__754 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_New_O_O_O_O_I_O_O(t.F_root, t.F_lib, t.F_q, t.F_acc, size__1927001038__auto____5, c__1927001037__auto____4, b__1211000155__6); var tmp3 *jrt.Class; var fncls__753 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_fn_class; if fncls__753 == nil { var fncls__753d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__754); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_fn_class = fncls__753d; tmp3 = fncls__753d } else { tmp3 = fncls__753 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__754, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_755 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any; var root_760 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = b__1211000155__6; if linked_761 == nil { arg_758 = ifn_762.Invoke_O__O(arg_763) } else { arg_758 = linked_761.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_760, arg_763) }; var arg_759 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1211000152); var tmp5 any; var root_764 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__1211000153__3; if linked_765 == nil { tmp5 = ifn_766.Invoke_O__O(arg_767) } else { tmp5 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_764, arg_767) }; arg_759 = tmp4.Invoke_O__O(tmp5); if linked_756 == nil { return ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { return linked_756.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) } } else { var root_768 any = A_arbace_c_aotlib_A_const_30.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any; var root_773 any = A_arbace_c_aotlib_A_const_31.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = b__1211000155__6; if linked_774 == nil { arg_771 = ifn_775.Invoke_O__O(arg_776) } else { arg_771 = linked_774.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_773, arg_776) }; var arg_772 any; if linked_769 == nil { return ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { return linked_769.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } } else { var ___4 any; var root_777 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_779 lang.IFn; _ = ___4; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__1211000153__3; if linked_778 == nil { ___4 = ifn_779.Invoke_O__O(arg_780) } else { ___4 = linked_778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_777, arg_780) }; var root_781 any = A_arbace_c_aotlib_A_const_32.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_786 any = A_arbace_c_aotlib_A_const_94.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_788 lang.IFn
															if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var fnbody__831 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_New_O_O_O_O(t.F_root, t.F_lib, t.F_q, t.F_acc); var tmp6 *jrt.Class; var fncls__830 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_fn_class; if fncls__830 == nil { var fncls__830d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__831); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_fn_class = fncls__830d; tmp6 = fncls__830d } else { tmp6 = fncls__830 }; arg_789 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__831, tmp6, nil); if linked_787 == nil { arg_784 = ifn_788.Invoke_O__O(arg_789) } else { arg_784 = linked_787.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_786, arg_789) }
//line :144:1
	var arg_785 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1211000152); var tmp8 any; var root_832 any = A_arbace_c_aotlib_A_const_33.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = s__1211000153__3; if linked_833 == nil { tmp8 = ifn_834.Invoke_O__O(arg_835) } else { tmp8 = linked_833.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_832, arg_835) }; arg_785 = tmp7.Invoke_O__O(tmp8); if linked_782 == nil { return ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { return linked_782.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_781, arg_784, arg_785) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A) Ctor_O_O_O_O_I_O_O(c__root, c__lib, c__q, c__acc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1211000155 any) { t.F_root = c__root; t.F_lib = c__lib; t.F_q = c__q; t.F_acc = c__acc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1211000155 = c__b__1211000155 }
//line :144:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A) Invoke_O__O(self any) any { { var i__1211000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1211000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1211000154__1)); var root_702 any = A_arbace_c_aotlib_A_const_28.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_704 lang.IFn; _ = ___2; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = t.F_b__1211000155; var arg_706 any; var root_707 any = A_arbace_c_aotlib_A_const_94.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_709 lang.IFn
																	if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var fnbody__752 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_New_O_O_O_O(t.F_root, t.F_lib, t.F_q, t.F_acc); var tmp2 *jrt.Class; var fncls__751 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_fn_class; if fncls__751 == nil { var fncls__751d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__752); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_fn_class = fncls__751d; tmp2 = fncls__751d } else { tmp2 = fncls__751 }; arg_710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__752, tmp2, nil); if linked_708 == nil { arg_706 = ifn_709.Invoke_O__O(arg_710) } else { arg_706 = linked_708.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_707, arg_710) }
//line :144:1
	if linked_703 == nil { ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { linked_703.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; i__1211000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1211000154__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :145:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A) Ctor_O_O_O_O(c__root, c__lib, c__q, c__acc any) { t.F_root = c__root; t.F_lib = c__lib; t.F_q = c__q; t.F_acc = c__acc }
//line :145:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var m__3 any; var root_711 any = A_arbace_c_aotlib_A_const_77.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_c_aotlib_unit_A_fn_class); var ifn_713 lang.IFn
		if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = t.F_root; var arg_715 any = t.F_lib; var arg_716 any = s__2; if linked_712 == nil { m__3 = ifn_713.Invoke_O_O_O__O(arg_714, arg_715, arg_716) } else { m__3 = linked_712.(*A_arbace_c_aotlib_unit_A).Invoke_O_O_O_O__O(root_711, arg_714, arg_715, arg_716) }
		var root_717 any = A_arbace_c_aotlib_A_const_95.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = t.F_acc; var arg_721 any; var fnbody__750 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_New_O(m__3); var tmp1 *jrt.Class; var fncls__749 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_fn_class; if fncls__749 == nil { var fncls__749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__750); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_fn_class = fncls__749d; tmp1 = fncls__749d } else { tmp1 = fncls__749 }; arg_721 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__750, tmp1, nil); if linked_718 == nil { ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { linked_718.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_717, arg_720, arg_721)
		}
		jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_101.Invoke_O__O(t.F_lib)).Remove_O__O(s__2)
		continue L2 } else {
//line :147:1
			return nil } } }; /*line :145:1*/panic("j2g: unreachable") }
//line :145:1
func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :145:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A) Ctor_O_O_O_O(c__root, c__lib, c__q, c__acc any) { t.F_root = c__root; t.F_lib = c__lib; t.F_q = c__q; t.F_acc = c__acc }
//line :145:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var m__3 any; var root_790 any = A_arbace_c_aotlib_A_const_77.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, A_arbace_c_aotlib_unit_A_fn_class); var ifn_792 lang.IFn
		if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = t.F_root; var arg_794 any = t.F_lib; var arg_795 any = s__2; if linked_791 == nil { m__3 = ifn_792.Invoke_O_O_O__O(arg_793, arg_794, arg_795) } else { m__3 = linked_791.(*A_arbace_c_aotlib_unit_A).Invoke_O_O_O_O__O(root_790, arg_793, arg_794, arg_795) }
		var root_796 any = A_arbace_c_aotlib_A_const_95.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = t.F_acc; var arg_800 any; var fnbody__829 any = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_New_O(m__3); var tmp1 *jrt.Class; var fncls__828 *jrt.Class = A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_fn_class; if fncls__828 == nil { var fncls__828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__829); A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_fn_class = fncls__828d; tmp1 = fncls__828d } else { tmp1 = fncls__828 }; arg_800 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__829, tmp1, nil); if linked_797 == nil { ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { linked_797.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_796, arg_799, arg_800)
		}
		jrt.ConcurrentHashMap_Cast(A_arbace_c_aotlib_A_const_101.Invoke_O__O(t.F_lib)).Remove_O__O(s__2)
		continue L2 } else {
//line :147:1
			return nil } } }; /*line :145:1*/panic("j2g: unreachable") }



func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_New_O(p0 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A{}; t.Ctor_O(p0); return t }
//line :149:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :149:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A) Invoke_O_O__O(self, p1__1211000151_SHARP___1 any) any {
	var root_722 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var root_729 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any; var root_736 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_738 lang.IFn
//line :149:1
	if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var root_743 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = p1__1211000151_SHARP___1; var arg_747 any = A_arbace_c_aotlib_A_const_90; var arg_748 any = A_arbace_c_aotlib_A_const_97.GetRawRoot__O(); if linked_744 == nil { arg_739 = ifn_745.Invoke_O_O_O__O(arg_746, arg_747, arg_748) } else { arg_739 = linked_744.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_743, arg_746, arg_747, arg_748) }; var arg_740 any = A_arbace_c_aotlib_A_const_98; var arg_741 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_742 any = A_arbace_c_aotlib_A_const_98.Invoke_O__O(t.F_m); if linked_737 == nil { arg_732 = ifn_738.Invoke_O_O_O_O__O(arg_739, arg_740, arg_741, arg_742) } else { arg_732 = linked_737.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_736, arg_739, arg_740, arg_741, arg_742) }
	var arg_733 any = A_arbace_c_aotlib_A_const_100; var arg_734 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_735 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_c_aotlib_A_const_100.Invoke_O__O(t.F_m))).Ref(); if linked_730 == nil { arg_725 = ifn_731.Invoke_O_O_O_O__O(arg_732, arg_733, arg_734, arg_735) } else { arg_725 = linked_730.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_729, arg_732, arg_733, arg_734, arg_735) }; var arg_726 any = A_arbace_c_aotlib_A_const_60; var arg_727 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_728 any = A_arbace_c_aotlib_A_const_60.Invoke_O__O(t.F_m); if linked_723 == nil { return ifn_724.Invoke_O_O_O_O__O(arg_725, arg_726, arg_727, arg_728) } else { return linked_723.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_722, arg_725, arg_726, arg_727, arg_728) } }
//line :149:1
func A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_New_O(p0 any) *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A{}; t.Ctor_O(p0); return t }
//line :149:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :149:1
func (t *A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A) Invoke_O_O__O(self, p1__1211000151_SHARP___1 any) any {
	var root_801 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any; var root_808 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any; var root_815 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_817 lang.IFn
//line :149:1
	if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var root_822 any = A_arbace_c_aotlib_A_const_96.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = p1__1211000151_SHARP___1; var arg_826 any = A_arbace_c_aotlib_A_const_90; var arg_827 any = A_arbace_c_aotlib_A_const_97.GetRawRoot__O(); if linked_823 == nil { arg_818 = ifn_824.Invoke_O_O_O__O(arg_825, arg_826, arg_827) } else { arg_818 = linked_823.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_822, arg_825, arg_826, arg_827) }; var arg_819 any = A_arbace_c_aotlib_A_const_98; var arg_820 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_821 any = A_arbace_c_aotlib_A_const_98.Invoke_O__O(t.F_m); if linked_816 == nil { arg_811 = ifn_817.Invoke_O_O_O_O__O(arg_818, arg_819, arg_820, arg_821) } else { arg_811 = linked_816.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_815, arg_818, arg_819, arg_820, arg_821) }
	var arg_812 any = A_arbace_c_aotlib_A_const_100; var arg_813 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_814 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_c_aotlib_A_const_100.Invoke_O__O(t.F_m))).Ref(); if linked_809 == nil { arg_804 = ifn_810.Invoke_O_O_O_O__O(arg_811, arg_812, arg_813, arg_814) } else { arg_804 = linked_809.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_808, arg_811, arg_812, arg_813, arg_814) }; var arg_805 any = A_arbace_c_aotlib_A_const_60; var arg_806 any = A_arbace_c_aotlib_A_const_99.GetRawRoot__O(); var arg_807 any = A_arbace_c_aotlib_A_const_60.Invoke_O__O(t.F_m); if linked_802 == nil { return ifn_803.Invoke_O_O_O_O__O(arg_804, arg_805, arg_806, arg_807) } else { return linked_802.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_801, arg_804, arg_805, arg_806, arg_807)
	}
}






func A_arbace_c_aotlib_secs_A_New() *A_arbace_c_aotlib_secs_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_secs_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_c_aotlib_secs_A) Ctor() {}
//line :159:1
func (t *A_arbace_c_aotlib_secs_A) Invoke_O_O__O(self, t0__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_19.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_889 int64 = jrt.System_NanoTime__J(); var na_890 any = t0__0; if jrt.Long_InstanceOf(na_890) { var n0_891 int64 = na_889; var n1_892 int64 = jrt.NN(jrt.Long_Cast(na_890)).LongValue__J(); var nr_893 int64 = n0_891 - n1_892; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_892 == -9223372036854775808); if tmp4 { tmp4 = (n0_891^n1_892)&(n0_891^nr_893) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_893)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_889, na_890) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_889, na_890) }; return tmp1.Invoke_O_O__O(Lit_46, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e9)).Ref()) }

func A_arbace_c_aotlib_c_compile_A_New() *A_arbace_c_aotlib_c_compile_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_c_compile_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_c_aotlib_c_compile_A) Ctor() {}
//line :161:1
func (t *A_arbace_c_aotlib_c_compile_A) Invoke_O_O_O_O_O_O__O(self, h__0, out__1, file__2, pkg__3, whole_QMARK___4 any) any { var root__6 any = jrt.System_GetProperty_String__String(Lit_1).Ref(); var lib__7 any; var root_894 any = A_arbace_c_aotlib_A_const_103.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_c_runtime.A_arbace_c_runtime_library_A_fn_class); var ifn_896 lang.IFn; if




	linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = h__0; var arg_898 any = root__6; if linked_895 == nil { lib__7 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { lib__7 = linked_895.(*aot_arbace_c_runtime.A_arbace_c_runtime_library_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }; var t0__8 int64 = /*line :161:1*/jrt.System_NanoTime__J(); var u__9 any; var root_899 any = A_arbace_c_aotlib_A_const_104.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_c_run.A_arbace_c_run_read_unit_A_fn_class); var ifn_901 lang.IFn; if






	linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = h__0; var arg_903 any = A_arbace_c_aotlib_A_const_105; var arg_904 any = jrt.File_New_String(jrt.String_Cast(file__2)).GetParent__String().Ref(); var arg_905 any = jrt.File_New_String(jrt.String_Cast(file__2)).GetName__String().Ref(); if linked_900 == nil { u__9 = ifn_901.Invoke_O_O_O_O__O(arg_902, arg_903, arg_904, arg_905) } else { u__9 = linked_900.(*aot_arbace_c_run.A_arbace_c_run_read_unit_A).Invoke_O_O_O_O_O__O(root_899, arg_902, arg_903, arg_904, arg_905) }; var rs__10 any; var root_906 any = /*line :161:1*/A_arbace_c_aotlib_A_const_106.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, A_arbace_c_aotlib_secs_A_fn_class); var ifn_908 lang.IFn; if







	linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = jrt.Long_ValueOf_J__Long_NoInit(t0__8).Ref(); if linked_907 == nil { rs__10 = ifn_908.Invoke_O__O(arg_909) } else { rs__10 = linked_907.(*A_arbace_c_aotlib_secs_A).Invoke_O_O__O(root_906, arg_909) }; var tmp1 any; var root_910 any =
	A_arbace_c_aotlib_A_const_107.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = A_arbace_c_aotlib_A_const_108; var arg_914 any = A_arbace_c_aotlib_A_const_109.Invoke_O__O(u__9); if linked_911 == nil { tmp1 = ifn_912.Invoke_O_O__O(arg_913, arg_914) } else { tmp1 = linked_911.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_910, arg_913, arg_914) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_110.GetRawRoot__O()); var tmp3 any; var root_921 any = A_arbace_c_aotlib_A_const_111.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = A_arbace_c_aotlib_A_const_109.Invoke_O__O(u__9); if linked_922 == nil { tmp3 = ifn_923.Invoke_O__O(arg_924) } else { tmp3 = linked_922.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_921, arg_924) }; return tmp2.Invoke_O_O_O__O(pkg__3, tmp3, A_arbace_c_aotlib_A_const_112.Invoke_O__O(u__9)) } else {
//line :170:1
			var t1__11 int64 = jrt.System_NanoTime__J(); var lt__12 any; var root_925 any = A_arbace_c_aotlib_A_const_113.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_c_runtime.A_arbace_c_runtime_link_traced_A_fn_class); var ifn_927 lang.IFn


			if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = lib__7; var arg_929 any = lang.Tuple_Create_O__IPersistentVector(u__9); if linked_926 == nil { lt__12 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { lt__12 = linked_926.(*aot_arbace_c_runtime.A_arbace_c_runtime_link_traced_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }
//line :170:1
			var ls__13 any; var root_930 any = A_arbace_c_aotlib_A_const_106.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_c_aotlib_secs_A_fn_class); var ifn_932 lang.IFn



			if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = jrt.Long_ValueOf_J__Long_NoInit(t1__11).Ref(); if linked_931 == nil { ls__13 = ifn_932.Invoke_O__O(arg_933) } else { ls__13 = linked_931.(*A_arbace_c_aotlib_secs_A).Invoke_O_O__O(root_930, arg_933) }
//line :170:1
			var t2__14 int64 = jrt.System_NanoTime__J(); var pre__15 any





			if jrt.J2g_Truth(whole_QMARK___4) { pre__15 = nil } else { var root_934 any = A_arbace_c_aotlib_A_const_114.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_c_aotlib_program_pre_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = root__6; var arg_938 any = lt__12; if linked_935 == nil { pre__15 = ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { pre__15 = linked_935.(*A_arbace_c_aotlib_program_pre_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) } }
//line :170:1
			var vec__1211000176__16 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_115.GetRawRoot__O()); var tmp5 any; var root_946 any = A_arbace_c_aotlib_A_const_116.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_c_build.A_arbace_c_build_read_program_A_fn_class); var ifn_948 lang.IFn






			if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = A_arbace_c_aotlib_A_const_117.Invoke_O__O(lt__12); if linked_947 == nil { tmp5 = ifn_948.Invoke_O__O(arg_949) } else { tmp5 = linked_947.(*aot_arbace_c_build.A_arbace_c_build_read_program_A).Invoke_O_O__O(root_946, arg_949) }; vec__1211000176__16 = tmp4.Invoke_O_O_O_O__O(tmp5, pkg__3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__3)).Ref(), pre__15)
//line :170:1
			var forms__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000176__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any; var root_950 any = A_arbace_c_aotlib_A_const_55.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_c_cf2g.A_arbace_c_cf2g_go_text_A_fn_class); var ifn_952 lang.IFn







			if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = forms__17; if linked_951 == nil { text__18 = ifn_952.Invoke_O__O(arg_953) } else { text__18 = linked_951.(*aot_arbace_c_cf2g.A_arbace_c_cf2g_go_text_A).Invoke_O_O__O(root_950, arg_953) }
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__1, nil, pkg__3))).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_c_aotlib_A_const_47.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, out__1, nil, pkg__3, nil)).Ref(), text__18)
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_110.GetRawRoot__O()); var tmp7 any; var root_964 any = A_arbace_c_aotlib_A_const_106.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_c_aotlib_secs_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = jrt.Long_ValueOf_J__Long_NoInit(t2__14).Ref(); if linked_965 == nil { tmp7 = ifn_966.Invoke_O__O(arg_967) } else { tmp7 = linked_965.(*A_arbace_c_aotlib_secs_A).Invoke_O_O__O(root_964, arg_967) }; var tmp8 any = tmp7; var tmp9 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(text__18)).Ref(); var tmp10 any; var or__1927000174__auto____19 any = A_arbace_c_aotlib_A_const_90.Invoke_O__O(pre__15); if jrt.J2g_Truth(or__1927000174__auto____19) { tmp10 = or__1927000174__auto____19 } else { tmp10 = A_arbace_c_aotlib_A_const_43 }; return tmp6.Invoke_O_O_O_O_O_O_O__O(pkg__3, Lit_12, rs__10, ls__13, tmp8, tmp9, tmp10) } }

func A_arbace_c_aotlib__main_A_New() *A_arbace_c_aotlib__main_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib__main_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_c_aotlib__main_A) Ctor() {}
//line :183:1
func (t *A_arbace_c_aotlib__main_A) DoInvoke_O_O_O__O(self, verb__0, args__1 any) any { var root__3 any = jrt.System_GetProperty_String__String(Lit_1).Ref(); var G__1211000180__4_ any = verb__0; L1:




switch { default: switch lang.Util_Hash_O__I_NoInit(G__1211000180__4_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1211000180__4_, Lit_2) { var h__5 any; var root_974 any = A_arbace_c_aotlib_A_const_118.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A_fn_class); var ifn_976 lang.IFn




	if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = Lit_3; if linked_975 == nil { h__5 = ifn_976.Invoke_O__O(arg_977) } else { h__5 = linked_975.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A).Invoke_O_O__O(root_974, arg_977) }
//line :188:1
	var lib__6 any; var root_978 any = A_arbace_c_aotlib_A_const_103.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_c_runtime.A_arbace_c_runtime_library_A_fn_class); var ifn_980 lang.IFn





	if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = h__5; var arg_982 any = root__3; if linked_979 == nil { lib__6 = ifn_980.Invoke_O_O__O(arg_981, arg_982) } else { lib__6 = linked_979.(*aot_arbace_c_runtime.A_arbace_c_runtime_library_A).Invoke_O_O_O__O(root_978, arg_981, arg_982) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_aotlib_A_const_110.GetRawRoot__O()); var tmp2 any; var root_987 any = A_arbace_c_aotlib_A_const_119.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, A_arbace_c_aotlib_translate_lib_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = root__3; var arg_991 any = lib__6; var arg_992 any; var root_994 any = A_arbace_c_aotlib_A_const_120.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_c_aotlib_A_const_121.Invoke_O__O(lib__6); if linked_995 == nil { arg_992 = ifn_996.Invoke_O__O(arg_997) } else { arg_992 = linked_995.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_994, arg_997) }; var arg_993 any; var tmp3 any; var or__1927000174__auto____7 any; var root_998 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = args__1; if linked_999 == nil { or__1927000174__auto____7 = ifn_1000.Invoke_O__O(arg_1001) } else { or__1927000174__auto____7 = linked_999.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_998, arg_1001) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp3 = or__1927000174__auto____7 } else { tmp3 = Lit_4 }; arg_993 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp3))).Ref(); if linked_988 == nil { tmp2 = ifn_989.Invoke_O_O_O_O__O(arg_990, arg_991, arg_992, arg_993) } else { tmp2 = linked_988.(*A_arbace_c_aotlib_translate_lib_A).Invoke_O_O_O_O_O__O(root_987, arg_990, arg_991, arg_992, arg_993) }; tmp1.Invoke_O__O(tmp2)
//line :188:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1211000180__4_, Lit_5) { var h__5_2 any; var root_1002 any = A_arbace_c_aotlib_A_const_118.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A_fn_class); var ifn_1004 lang.IFn
		if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = Lit_3; if linked_1003 == nil { h__5_2 = ifn_1004.Invoke_O__O(arg_1005) } else { h__5_2 = linked_1003.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A).Invoke_O_O__O(root_1002, arg_1005) }
//line :188:1
		var whole_QMARK___6 any; var root_1006 any = A_arbace_c_aotlib_A_const_122.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1008 lang.IFn

		if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = A_arbace_c_aotlib_A_const_123; var arg_1010 any = args__1; if linked_1007 == nil { whole_QMARK___6 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { whole_QMARK___6 = linked_1007.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }
//line :188:1
		var vec__1211000181__7 any; var root_1011 any = A_arbace_c_aotlib_A_const_124.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1013 lang.IFn


		if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = A_arbace_c_aotlib_A_const_125; var arg_1015 any = args__1; if linked_1012 == nil { vec__1211000181__7 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { vec__1211000181__7 = linked_1012.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) }
//line :188:1
		var seq__1211000182__8 any; var root_1016 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1018 lang.IFn
		if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = vec__1211000181__7; if linked_1017 == nil { seq__1211000182__8 = ifn_1018.Invoke_O__O(arg_1019) } else { seq__1211000182__8 = linked_1017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1016, arg_1019) }
//line :188:1
		var first__1211000183__9 any; var root_1020 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1022 lang.IFn
		if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = seq__1211000182__8; if linked_1021 == nil { first__1211000183__9 = ifn_1022.Invoke_O__O(arg_1023) } else { first__1211000183__9 = linked_1021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1020, arg_1023) }
//line :188:1
		var seq__1211000182__10 any; var root_1024 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1026 lang.IFn
		if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = seq__1211000182__8; if linked_1025 == nil { seq__1211000182__10 = ifn_1026.Invoke_O__O(arg_1027) } else { seq__1211000182__10 = linked_1025.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1024, arg_1027) }
//line :188:1
		var out__11 any = first__1211000183__9; var pairs__12 any = seq__1211000182__10; var seq_1211000184__13 any; var root_1028 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1030 lang.IFn



		if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var root_1032 any = A_arbace_c_aotlib_A_const_126.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = A_arbace_c_aotlib_A_const_127; var arg_1036 any = pairs__12; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { arg_1031 = linked_1033.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }; if linked_1029 == nil { seq_1211000184__13 = ifn_1030.Invoke_O__O(arg_1031) } else { seq_1211000184__13 = linked_1029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :188:1
		var chunk_1211000185__14 any; var count_1211000186__15 int64 = 0; var i_1211000187__16 int64 = 0; L2: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(i_1211000187__16, count_1211000186__15) { var vec__1211000188__17 any = lang.Indexed_Cast(chunk_1211000185__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1211000187__16)); var pkg__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000188__17, lang.RT_IntCast_J__I_NoInit(0), nil); var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000188__17, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1056 any = A_arbace_c_aotlib_A_const_129.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, A_arbace_c_aotlib_c_compile_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = h__5_2; var arg_1060 any = out__11; var arg_1061 any = f__19; var arg_1062 any = pkg__18; var arg_1063 any = whole_QMARK___6; if linked_1057 == nil { ifn_1058.Invoke_O_O_O_O_O__O(arg_1059, arg_1060, arg_1061, arg_1062, arg_1063) } else { linked_1057.(*A_arbace_c_aotlib_c_compile_A).Invoke_O_O_O_O_O_O__O(root_1056, arg_1059, arg_1060, arg_1061, arg_1062, arg_1063) }; seq_1211000184__13, chunk_1211000185__14, count_1211000186__15, i_1211000187__16 = seq_1211000184__13, chunk_1211000185__14, count_1211000186__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1211000187__16); continue L2 } else { var temp__1927000414__auto____17 any; var root_1037 any = A_arbace_c_aotlib_A_const_15.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = seq_1211000184__13; if linked_1038 == nil { temp__1927000414__auto____17 = ifn_1039.Invoke_O__O(arg_1040) } else { temp__1927000414__auto____17 = linked_1038.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1037, arg_1040) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_1211000184__18 any = temp__1927000414__auto____17; var tmp4 any; var root_1041 any = A_arbace_c_aotlib_A_const_16.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = seq_1211000184__18; if linked_1042 == nil { tmp4 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp4 = linked_1042.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1041, arg_1044) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____19 any; var root_1045 any = A_arbace_c_aotlib_A_const_17.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = seq_1211000184__18; if linked_1046 == nil { c__1927000678__auto____19 = ifn_1047.Invoke_O__O(arg_1048) } else { c__1927000678__auto____19 = linked_1046.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1045, arg_1048) }; var tmp5 any; var root_1064 any = A_arbace_c_aotlib_A_const_20.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = seq_1211000184__18; if linked_1065 == nil { tmp5 = ifn_1066.Invoke_O__O(arg_1067) } else { tmp5 = linked_1065.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1064, arg_1067) }; seq_1211000184__13, chunk_1211000185__14, count_1211000186__15, i_1211000187__16 = tmp5, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1211000191__19 any; var root_1049 any = A_arbace_c_aotlib_A_const_18.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = seq_1211000184__18; if linked_1050 == nil { vec__1211000191__19 = ifn_1051.Invoke_O__O(arg_1052) } else { vec__1211000191__19 = linked_1050.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1049, arg_1052) }; var pkg__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000191__19, lang.RT_IntCast_J__I_NoInit(0), nil); var f__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1211000191__19, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1068 any = A_arbace_c_aotlib_A_const_129.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_c_aotlib_c_compile_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = h__5_2; var arg_1072 any = out__11; var arg_1073 any = f__21; var arg_1074 any = pkg__20; var arg_1075 any = whole_QMARK___6; if linked_1069 == nil { ifn_1070.Invoke_O_O_O_O_O__O(arg_1071, arg_1072, arg_1073, arg_1074, arg_1075) } else { linked_1069.(*A_arbace_c_aotlib_c_compile_A).Invoke_O_O_O_O_O_O__O(root_1068, arg_1071, arg_1072, arg_1073, arg_1074, arg_1075) }; var tmp6 any; var root_1076 any = A_arbace_c_aotlib_A_const_21.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = seq_1211000184__18; if linked_1077 == nil { tmp6 = ifn_1078.Invoke_O__O(arg_1079) } else { tmp6 = linked_1077.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1076, arg_1079) }; seq_1211000184__13, chunk_1211000185__14, count_1211000186__15, i_1211000187__16 = tmp6, nil, 0, 0; continue L2 } } }
//line :188:1
			break L2 }; break L1 }; default:
}






	lang.IFn_Cast(A_arbace_c_aotlib_A_const_110.GetRawRoot__O()).Invoke_O__O(Lit_6); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))}; var root_1053 any =
	A_arbace_c_aotlib_A_const_128.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; if linked_1054 == nil { ifn_1055.Invoke__O() } else { linked_1054.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_1053) };
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }





























































































type A_arbace_c_aotlib_A struct{ jrt.Object }

var A_arbace_c_aotlib_A_const_pool *jrt.RefArray

var A_arbace_c_aotlib_A_const_0 *lang.Var

var A_arbace_c_aotlib_A_const_1 any

var A_arbace_c_aotlib_A_const_2 *lang.Var

var A_arbace_c_aotlib_A_const_3 any

var A_arbace_c_aotlib_A_const_4 any

var A_arbace_c_aotlib_A_const_5 any

var A_arbace_c_aotlib_A_const_6 any

var A_arbace_c_aotlib_A_const_7 any

var A_arbace_c_aotlib_A_const_8 any

var A_arbace_c_aotlib_A_const_9 *lang.Var

var A_arbace_c_aotlib_A_const_10 *lang.Var

var A_arbace_c_aotlib_A_const_11 *lang.Var

var A_arbace_c_aotlib_A_const_12 *lang.Var

var A_arbace_c_aotlib_A_const_13 any

var A_arbace_c_aotlib_A_const_14 *lang.Var

var A_arbace_c_aotlib_A_const_15 *lang.Var

var A_arbace_c_aotlib_A_const_16 *lang.Var

var A_arbace_c_aotlib_A_const_17 *lang.Var

var A_arbace_c_aotlib_A_const_18 *lang.Var

var A_arbace_c_aotlib_A_const_19 *lang.Var

var A_arbace_c_aotlib_A_const_20 *lang.Var

var A_arbace_c_aotlib_A_const_21 *lang.Var

var A_arbace_c_aotlib_A_const_22 *lang.Var

var A_arbace_c_aotlib_A_const_23 *lang.Var

var A_arbace_c_aotlib_A_const_24 *lang.Var

var A_arbace_c_aotlib_A_const_25 *lang.Keyword

var A_arbace_c_aotlib_A_const_26 *lang.Var

var A_arbace_c_aotlib_A_const_27 *lang.Var

var A_arbace_c_aotlib_A_const_28 *lang.Var

var A_arbace_c_aotlib_A_const_29 *lang.Var

var A_arbace_c_aotlib_A_const_30 *lang.Var

var A_arbace_c_aotlib_A_const_31 *lang.Var

var A_arbace_c_aotlib_A_const_32 *lang.Var

var A_arbace_c_aotlib_A_const_33 *lang.Var

var A_arbace_c_aotlib_A_const_34 *lang.Var

var A_arbace_c_aotlib_A_const_35 *lang.Var

var A_arbace_c_aotlib_A_const_36 *lang.Keyword

var A_arbace_c_aotlib_A_const_37 *lang.Var

var A_arbace_c_aotlib_A_const_38 *lang.Var

var A_arbace_c_aotlib_A_const_39 any

var A_arbace_c_aotlib_A_const_40 any

var A_arbace_c_aotlib_A_const_41 *lang.Var

var A_arbace_c_aotlib_A_const_42 *lang.Var

var A_arbace_c_aotlib_A_const_43 any

var A_arbace_c_aotlib_A_const_44 any

var A_arbace_c_aotlib_A_const_45 any

var A_arbace_c_aotlib_A_const_46 any

var A_arbace_c_aotlib_A_const_47 *lang.Var

var A_arbace_c_aotlib_A_const_48 *lang.Var

var A_arbace_c_aotlib_A_const_49 *lang.Var

var A_arbace_c_aotlib_A_const_50 *lang.Var

var A_arbace_c_aotlib_A_const_51 *lang.Var

var A_arbace_c_aotlib_A_const_52 *lang.Var

var A_arbace_c_aotlib_A_const_53 *lang.Var

var A_arbace_c_aotlib_A_const_54 *lang.Var

var A_arbace_c_aotlib_A_const_55 *lang.Var

var A_arbace_c_aotlib_A_const_56 *lang.Var

var A_arbace_c_aotlib_A_const_57 *lang.Keyword

var A_arbace_c_aotlib_A_const_58 *lang.Keyword

var A_arbace_c_aotlib_A_const_59 *lang.Keyword

var A_arbace_c_aotlib_A_const_60 *lang.Keyword

var A_arbace_c_aotlib_A_const_61 *lang.Keyword

var A_arbace_c_aotlib_A_const_62 *lang.Var

var A_arbace_c_aotlib_A_const_63 *lang.Var

var A_arbace_c_aotlib_A_const_64 *lang.Var

var A_arbace_c_aotlib_A_const_65 *lang.Var

var A_arbace_c_aotlib_A_const_66 *lang.Var

var A_arbace_c_aotlib_A_const_67 *lang.Var

var A_arbace_c_aotlib_A_const_68 *lang.Var

var A_arbace_c_aotlib_A_const_69 *lang.Var

var A_arbace_c_aotlib_A_const_70 *lang.Var

var A_arbace_c_aotlib_A_const_71 *lang.Var

var A_arbace_c_aotlib_A_const_72 *lang.Keyword

var A_arbace_c_aotlib_A_const_73 *lang.Keyword

var A_arbace_c_aotlib_A_const_74 *lang.Var

var A_arbace_c_aotlib_A_const_75 *lang.Var

var A_arbace_c_aotlib_A_const_76 *lang.Var

var A_arbace_c_aotlib_A_const_77 *lang.Var

var A_arbace_c_aotlib_A_const_78 *lang.Keyword

var A_arbace_c_aotlib_A_const_79 *lang.Keyword

var A_arbace_c_aotlib_A_const_80 *lang.Keyword

var A_arbace_c_aotlib_A_const_81 *lang.Var

var A_arbace_c_aotlib_A_const_82 *lang.Keyword

var A_arbace_c_aotlib_A_const_83 *lang.Keyword

var A_arbace_c_aotlib_A_const_84 *lang.Var

var A_arbace_c_aotlib_A_const_85 *lang.Keyword

var A_arbace_c_aotlib_A_const_86 *lang.Var

var A_arbace_c_aotlib_A_const_87 any

var A_arbace_c_aotlib_A_const_88 *lang.Keyword

var A_arbace_c_aotlib_A_const_89 *lang.Keyword

var A_arbace_c_aotlib_A_const_90 *lang.Keyword

var A_arbace_c_aotlib_A_const_91 *lang.Var

var A_arbace_c_aotlib_A_const_92 any

var A_arbace_c_aotlib_A_const_93 *lang.Var

var A_arbace_c_aotlib_A_const_94 *lang.Var

var A_arbace_c_aotlib_A_const_95 *lang.Var

var A_arbace_c_aotlib_A_const_96 *lang.Var

var A_arbace_c_aotlib_A_const_97 *lang.Var

var A_arbace_c_aotlib_A_const_98 *lang.Keyword

var A_arbace_c_aotlib_A_const_99 *lang.Var

var A_arbace_c_aotlib_A_const_100 *lang.Keyword

var A_arbace_c_aotlib_A_const_101 *lang.Keyword

var A_arbace_c_aotlib_A_const_102 *lang.Var

var A_arbace_c_aotlib_A_const_103 *lang.Var

var A_arbace_c_aotlib_A_const_104 *lang.Var

var A_arbace_c_aotlib_A_const_105 any

var A_arbace_c_aotlib_A_const_106 *lang.Var

var A_arbace_c_aotlib_A_const_107 *lang.Var

var A_arbace_c_aotlib_A_const_108 *lang.Keyword

var A_arbace_c_aotlib_A_const_109 *lang.Keyword

var A_arbace_c_aotlib_A_const_110 *lang.Var

var A_arbace_c_aotlib_A_const_111 *lang.Var

var A_arbace_c_aotlib_A_const_112 *lang.Keyword

var A_arbace_c_aotlib_A_const_113 *lang.Var

var A_arbace_c_aotlib_A_const_114 *lang.Var

var A_arbace_c_aotlib_A_const_115 *lang.Var

var A_arbace_c_aotlib_A_const_116 *lang.Var

var A_arbace_c_aotlib_A_const_117 *lang.Keyword

var A_arbace_c_aotlib_A_const_118 *lang.Var

var A_arbace_c_aotlib_A_const_119 *lang.Var

var A_arbace_c_aotlib_A_const_120 *lang.Var

var A_arbace_c_aotlib_A_const_121 *lang.Keyword

var A_arbace_c_aotlib_A_const_122 *lang.Var

var A_arbace_c_aotlib_A_const_123 any

var A_arbace_c_aotlib_A_const_124 *lang.Var

var A_arbace_c_aotlib_A_const_125 any

var A_arbace_c_aotlib_A_const_126 *lang.Var

var A_arbace_c_aotlib_A_const_127 any

var A_arbace_c_aotlib_A_const_128 *lang.Var

var A_arbace_c_aotlib_A_const_129 *lang.Var

var A_arbace_c_aotlib_A_init jrt.ClassInit

func A_arbace_c_aotlib_A_Init() { if !A_arbace_c_aotlib_A_init.Done() { A_arbace_c_aotlib_A_init.Run(A_arbace_c_aotlib_A_clinit) } }

func A_arbace_c_aotlib_A_clinit() { A_arbace_c_aotlib_A_clinit_p0(); A_arbace_c_aotlib_A_clinit_p1(); A_arbace_c_aotlib_A_clinit_p2(); A_arbace_c_aotlib_A_clinit_p3(); A_arbace_c_aotlib_A_clinit_p4(); A_arbace_c_aotlib_A_clinit_p5(); A_arbace_c_aotlib_A_clinit_p6(); A_arbace_c_aotlib_A_clinit_p7(); A_arbace_c_aotlib_A_clinit_p8(); A_arbace_c_aotlib_A_clinit_p9(); A_arbace_c_aotlib_A_clinit_p10() }

func A_arbace_c_aotlib_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_aotlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 171); A_arbace_c_aotlib_A_const_0 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[41]); A_arbace_c_aotlib_A_const_1 = A_arbace_c_aotlib_A_const_pool.A[42]; A_arbace_c_aotlib_A_const_2 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[43]); A_arbace_c_aotlib_A_const_3 = A_arbace_c_aotlib_A_const_pool.A[44]; A_arbace_c_aotlib_A_const_4 = A_arbace_c_aotlib_A_const_pool.A[45]; A_arbace_c_aotlib_A_const_5 = A_arbace_c_aotlib_A_const_pool.A[46]; A_arbace_c_aotlib_A_const_6 = A_arbace_c_aotlib_A_const_pool.A[47]; A_arbace_c_aotlib_A_const_7 = A_arbace_c_aotlib_A_const_pool.A[48]; A_arbace_c_aotlib_A_const_8 = A_arbace_c_aotlib_A_const_pool.A[49]; A_arbace_c_aotlib_A_const_9 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[50]); A_arbace_c_aotlib_A_const_10 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[51]); A_arbace_c_aotlib_A_const_11 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[52]); A_arbace_c_aotlib_A_const_12 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[53]) }

func A_arbace_c_aotlib_A_clinit_p1() { A_arbace_c_aotlib_A_const_13 = A_arbace_c_aotlib_A_const_pool.A[54]; A_arbace_c_aotlib_A_const_14 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[55]); A_arbace_c_aotlib_A_const_15 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[56]); A_arbace_c_aotlib_A_const_16 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[57]); A_arbace_c_aotlib_A_const_17 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[58]); A_arbace_c_aotlib_A_const_18 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[59]); A_arbace_c_aotlib_A_const_19 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[60]); A_arbace_c_aotlib_A_const_20 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[61]); A_arbace_c_aotlib_A_const_21 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[62]); A_arbace_c_aotlib_A_const_22 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[63]); A_arbace_c_aotlib_A_const_23 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[64]); A_arbace_c_aotlib_A_const_24 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[65]) }

func A_arbace_c_aotlib_A_clinit_p2() { A_arbace_c_aotlib_A_const_25 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[66]); A_arbace_c_aotlib_A_const_26 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[67]); A_arbace_c_aotlib_A_const_27 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[68]); A_arbace_c_aotlib_A_const_28 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[69]); A_arbace_c_aotlib_A_const_29 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[70]); A_arbace_c_aotlib_A_const_30 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[71]); A_arbace_c_aotlib_A_const_31 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[72]); A_arbace_c_aotlib_A_const_32 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[73]); A_arbace_c_aotlib_A_const_33 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[74]); A_arbace_c_aotlib_A_const_34 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[75]); A_arbace_c_aotlib_A_const_35 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[76]); A_arbace_c_aotlib_A_const_36 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[77]) }

func A_arbace_c_aotlib_A_clinit_p3() { A_arbace_c_aotlib_A_const_37 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[78]); A_arbace_c_aotlib_A_const_38 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[79]); A_arbace_c_aotlib_A_const_39 = A_arbace_c_aotlib_A_const_pool.A[80]; A_arbace_c_aotlib_A_const_40 = A_arbace_c_aotlib_A_const_pool.A[81]; A_arbace_c_aotlib_A_const_41 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[82]); A_arbace_c_aotlib_A_const_42 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[83]); A_arbace_c_aotlib_A_const_43 = A_arbace_c_aotlib_A_const_pool.A[84]; A_arbace_c_aotlib_A_const_44 = A_arbace_c_aotlib_A_const_pool.A[85]; A_arbace_c_aotlib_A_const_45 = A_arbace_c_aotlib_A_const_pool.A[86]; A_arbace_c_aotlib_A_const_46 = A_arbace_c_aotlib_A_const_pool.A[87]; A_arbace_c_aotlib_A_const_47 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[88]); A_arbace_c_aotlib_A_const_48 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[89]); A_arbace_c_aotlib_A_const_49 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[90]) }

func A_arbace_c_aotlib_A_clinit_p4() { A_arbace_c_aotlib_A_const_50 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[91]); A_arbace_c_aotlib_A_const_51 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[92]); A_arbace_c_aotlib_A_const_52 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[93]); A_arbace_c_aotlib_A_const_53 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[94]); A_arbace_c_aotlib_A_const_54 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[95]); A_arbace_c_aotlib_A_const_55 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[96]); A_arbace_c_aotlib_A_const_56 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[97]); A_arbace_c_aotlib_A_const_57 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[98]); A_arbace_c_aotlib_A_const_58 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[99]); A_arbace_c_aotlib_A_const_59 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[100]); A_arbace_c_aotlib_A_const_60 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[101]); A_arbace_c_aotlib_A_const_61 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[102]) }

func A_arbace_c_aotlib_A_clinit_p5() { A_arbace_c_aotlib_A_const_62 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[103]); A_arbace_c_aotlib_A_const_63 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[104]); A_arbace_c_aotlib_A_const_64 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[105]); A_arbace_c_aotlib_A_const_65 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[106]); A_arbace_c_aotlib_A_const_66 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[107]); A_arbace_c_aotlib_A_const_67 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[108]); A_arbace_c_aotlib_A_const_68 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[109]); A_arbace_c_aotlib_A_const_69 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[110]); A_arbace_c_aotlib_A_const_70 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[111]); A_arbace_c_aotlib_A_const_71 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[112]); A_arbace_c_aotlib_A_const_72 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[113]); A_arbace_c_aotlib_A_const_73 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[114]) }

func A_arbace_c_aotlib_A_clinit_p6() { A_arbace_c_aotlib_A_const_74 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[115]); A_arbace_c_aotlib_A_const_75 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[116]); A_arbace_c_aotlib_A_const_76 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[117]); A_arbace_c_aotlib_A_const_77 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[118]); A_arbace_c_aotlib_A_const_78 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[119]); A_arbace_c_aotlib_A_const_79 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[120]); A_arbace_c_aotlib_A_const_80 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[121]); A_arbace_c_aotlib_A_const_81 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[122]); A_arbace_c_aotlib_A_const_82 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[123]); A_arbace_c_aotlib_A_const_83 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[124]); A_arbace_c_aotlib_A_const_84 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[125]); A_arbace_c_aotlib_A_const_85 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[126]) }

func A_arbace_c_aotlib_A_clinit_p7() { A_arbace_c_aotlib_A_const_86 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[127]); A_arbace_c_aotlib_A_const_87 = A_arbace_c_aotlib_A_const_pool.A[128]; A_arbace_c_aotlib_A_const_88 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[129]); A_arbace_c_aotlib_A_const_89 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[130]); A_arbace_c_aotlib_A_const_90 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[131]); A_arbace_c_aotlib_A_const_91 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[132]); A_arbace_c_aotlib_A_const_92 = A_arbace_c_aotlib_A_const_pool.A[133]; A_arbace_c_aotlib_A_const_93 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[134]); A_arbace_c_aotlib_A_const_94 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[135]); A_arbace_c_aotlib_A_const_95 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[136]); A_arbace_c_aotlib_A_const_96 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[137]); A_arbace_c_aotlib_A_const_97 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[138]) }

func A_arbace_c_aotlib_A_clinit_p8() { A_arbace_c_aotlib_A_const_98 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[139]); A_arbace_c_aotlib_A_const_99 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[140]); A_arbace_c_aotlib_A_const_100 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[141]); A_arbace_c_aotlib_A_const_101 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[142]); A_arbace_c_aotlib_A_const_102 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[143]); A_arbace_c_aotlib_A_const_103 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[144]); A_arbace_c_aotlib_A_const_104 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[145]); A_arbace_c_aotlib_A_const_105 = A_arbace_c_aotlib_A_const_pool.A[146]; A_arbace_c_aotlib_A_const_106 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[147]); A_arbace_c_aotlib_A_const_107 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[148]); A_arbace_c_aotlib_A_const_108 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[149]); A_arbace_c_aotlib_A_const_109 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[150]) }

func A_arbace_c_aotlib_A_clinit_p9() { A_arbace_c_aotlib_A_const_110 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[151]); A_arbace_c_aotlib_A_const_111 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[152]); A_arbace_c_aotlib_A_const_112 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[153]); A_arbace_c_aotlib_A_const_113 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[154]); A_arbace_c_aotlib_A_const_114 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[155]); A_arbace_c_aotlib_A_const_115 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[156]); A_arbace_c_aotlib_A_const_116 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[157]); A_arbace_c_aotlib_A_const_117 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[158]); A_arbace_c_aotlib_A_const_118 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[159]); A_arbace_c_aotlib_A_const_119 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[160]); A_arbace_c_aotlib_A_const_120 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[161]); A_arbace_c_aotlib_A_const_121 = lang.Keyword_Cast(A_arbace_c_aotlib_A_const_pool.A[162]) }

func A_arbace_c_aotlib_A_clinit_p10() { A_arbace_c_aotlib_A_const_122 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[163]); A_arbace_c_aotlib_A_const_123 = A_arbace_c_aotlib_A_const_pool.A[164]; A_arbace_c_aotlib_A_const_124 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[165]); A_arbace_c_aotlib_A_const_125 = A_arbace_c_aotlib_A_const_pool.A[166]; A_arbace_c_aotlib_A_const_126 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[167]); A_arbace_c_aotlib_A_const_127 = A_arbace_c_aotlib_A_const_pool.A[168]; A_arbace_c_aotlib_A_const_128 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[169]); A_arbace_c_aotlib_A_const_129 = lang.Var_Cast(A_arbace_c_aotlib_A_const_pool.A[170]) }

func A_arbace_c_aotlib_A_New() *A_arbace_c_aotlib_A { A_arbace_c_aotlib_A_Init(); t := &A_arbace_c_aotlib_A{}; t.Ctor(); return t }

func (t *A_arbace_c_aotlib_A) Ctor() {}

func (t *A_arbace_c_aotlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_aotlib_A) GetClass__Class() *jrt.Class { return A_arbace_c_aotlib_A_class }

func (t *A_arbace_c_aotlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_aotlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_aotlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_aotlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_aotlib_A); return ok }

func A_arbace_c_aotlib_A_Cast(x any) *A_arbace_c_aotlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_aotlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_aotlib_A_class)) }; return v }



type A_arbace_c_aotlib__main_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib__main_A_fn_class *jrt.Class



type A_arbace_c_aotlib_bytes_hex_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_bytes_hex_A_fn_class *jrt.Class



type A_arbace_c_aotlib_c_compile_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_c_compile_A_fn_class *jrt.Class



type A_arbace_c_aotlib_cache_root_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_cache_root_A_fn_class *jrt.Class



type A_arbace_c_aotlib_eval1211000004_A struct{ jrt.Object }

func A_arbace_c_aotlib_eval1211000004_A_New() *A_arbace_c_aotlib_eval1211000004_A { t := &A_arbace_c_aotlib_eval1211000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_aotlib_eval1211000004_A) Ctor() {}

func (t *A_arbace_c_aotlib_eval1211000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_aotlib_eval1211000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_aotlib_eval1211000004_A_class }

func (t *A_arbace_c_aotlib_eval1211000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_aotlib_eval1211000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_aotlib_eval1211000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_aotlib_eval1211000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_aotlib_eval1211000004_A); return ok }

func A_arbace_c_aotlib_eval1211000004_A_Cast(x any) *A_arbace_c_aotlib_eval1211000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_aotlib_eval1211000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_aotlib_eval1211000004_A_class)) }; return v }



type A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_eval1211000004_loading__1927001464__auto____1211000005_A_fn_class *jrt.Class



type A_arbace_c_aotlib_eval1211000008_A struct{ jrt.Object }

func A_arbace_c_aotlib_eval1211000008_A_New() *A_arbace_c_aotlib_eval1211000008_A { t := &A_arbace_c_aotlib_eval1211000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_aotlib_eval1211000008_A) Ctor() {}

func (t *A_arbace_c_aotlib_eval1211000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_aotlib_eval1211000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_aotlib_eval1211000008_A_class }

func (t *A_arbace_c_aotlib_eval1211000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_aotlib_eval1211000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_aotlib_eval1211000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_aotlib_eval1211000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_aotlib_eval1211000008_A); return ok }

func A_arbace_c_aotlib_eval1211000008_A_Cast(x any) *A_arbace_c_aotlib_eval1211000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_aotlib_eval1211000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_aotlib_eval1211000008_A_class)) }; return v }



type A_arbace_c_aotlib_eval1211000008_fn__1211000009_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_eval1211000008_fn__1211000009_A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_dir_name_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_lib_dir_name_A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_key_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_lib_key_A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_key_STAR__A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_lib_key_STAR__A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A struct{ j2g_header uint64; F_root, F_sb any }

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A struct{ j2g_header uint64; F_root, F_sb, F_s__1211000026, F_iter__1211000025 any }

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_A_fn_class *jrt.Class



type A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A struct{ j2g_header uint64; F_root, F_b__1211000028, F_sb any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_aotlib_lib_key_STAR__iter__1211000025__1211000029_fn__1211000030_fn__1211000031_A_fn_class *jrt.Class



type A_arbace_c_aotlib_make_unit_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_make_unit_A_fn_class *jrt.Class



type A_arbace_c_aotlib_make_unit_fn__1211000046_A struct{ j2g_header uint64; F_mf any }

var A_arbace_c_aotlib_make_unit_fn__1211000046_A_fn_class *jrt.Class



type A_arbace_c_aotlib_make_unit_fn__1211000051_A struct{ j2g_header uint64; F_m any }

var A_arbace_c_aotlib_make_unit_fn__1211000051_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_alias_of__1211000068_A struct{ j2g_header uint64; F_used any }

var A_arbace_c_aotlib_program_pre_alias_of__1211000068_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_fn__1211000066_A struct{ j2g_header uint64; F_root, F_frag_libs any }

var A_arbace_c_aotlib_program_pre_fn__1211000066_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A struct{ j2g_header uint64; F_root, F_frag_libs, F_alias_of any }

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A struct{ j2g_header uint64; F_root, F_s__1211000071, F_iter__1211000070, F_frag_libs, F_alias_of any }

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A struct{ j2g_header uint64; F_root, F_frag_libs, F_b__1211000073 any; F_size__1927001038__auto__ int32; F_alias_of, F_c__1927001037__auto__ any }

var A_arbace_c_aotlib_program_pre_iter__1211000070__1211000074_fn__1211000075_fn__1211000076_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A struct{ j2g_header uint64; F_s__1211000099, F_iter__1211000098 any }

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1211000101 any }

var A_arbace_c_aotlib_program_pre_iter__1211000098__1211000102_fn__1211000103_fn__1211000104_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A struct{ j2g_header uint64; F_trace any }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A struct{ j2g_header uint64; F_trace, F_s__1211000121, F_iter__1211000120 any }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A struct{ j2g_header uint64; F_trace any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1211000123 any }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000133_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000126_fn__1211000135_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000144_A_fn_class *jrt.Class



type A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_program_pre_iter__1211000120__1211000124_fn__1211000125_fn__1211000146_A_fn_class *jrt.Class



type A_arbace_c_aotlib_secs_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_secs_A_fn_class *jrt.Class



type A_arbace_c_aotlib_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_sha256_hex_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_translate_lib_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A struct{ j2g_header uint64; F_root, F_lib, F_q, F_acc any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A struct{ j2g_header uint64; F_root, F_lib, F_q, F_s__1211000153, F_iter__1211000152, F_acc any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A struct{ j2g_header uint64; F_root, F_lib, F_q, F_acc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1211000155 any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A struct{ j2g_header uint64; F_root, F_lib, F_q, F_acc any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A struct{ j2g_header uint64; F_m any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000158_fn__1211000159_fn__1211000160_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A struct{ j2g_header uint64; F_root, F_lib, F_q, F_acc any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_A_fn_class *jrt.Class



type A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A struct{ j2g_header uint64; F_m any }

var A_arbace_c_aotlib_translate_lib_iter__1211000152__1211000156_fn__1211000157_fn__1211000164_fn__1211000165_A_fn_class *jrt.Class



type A_arbace_c_aotlib_unit_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_unit_A_fn_class *jrt.Class



type A_arbace_c_aotlib_unit_fn__1211000054_A struct{ j2g_header uint64; F_root, F_src, F_lib any }

var A_arbace_c_aotlib_unit_fn__1211000054_A_fn_class *jrt.Class



type A_arbace_c_aotlib_unit_pkg_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_unit_pkg_A_fn_class *jrt.Class



type A_arbace_c_aotlib_write_atomic_A struct{ j2g_header uint64 }

var A_arbace_c_aotlib_write_atomic_A_fn_class *jrt.Class
