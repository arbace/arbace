//line a2g_classes.ae:1
package aot_arbace_a2g_model

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_model_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_A_New()}; return nil }

var A_arbace_a2g_model_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_A_new}

var A_arbace_a2g_model_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_A"})

func init() { i := A_arbace_a2g_model_A_class.Info(); i.IsInstance = A_arbace_a2g_model_A_InstanceOf; i.Init = A_arbace_a2g_model_A_Init; i.Table = A_arbace_a2g_model_A_members; jrt.RegisterGoType(A_arbace_a2g_model_A_class, reflect.TypeFor[A_arbace_a2g_model_A]()) }

func A_arbace_a2g_model_T_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_T_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_T_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_T_A_New()}; return nil }

func A_arbace_a2g_model_T_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_T_A_fn_class)}; return nil }

var A_arbace_a2g_model_T_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_T_A_invoke, New: A_arbace_a2g_model_T_A_new, Get: A_arbace_a2g_model_T_A_get}

var A_arbace_a2g_model_T_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$T", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "T", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_T_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_T_A_class.Info(); i.IsInstance = A_arbace_a2g_model_T_A_InstanceOf; i.Init = A_arbace_a2g_model_T_A_Init; i.Table = A_arbace_a2g_model_T_A_members; jrt.RegisterGoType(A_arbace_a2g_model_T_A_class, reflect.TypeFor[A_arbace_a2g_model_T_A]()) }

func A_arbace_a2g_model_a2g_method_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_a2g_method_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_a2g_method_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_a2g_method_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_a2g_method_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_a2g_method_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_a2g_method_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_a2g_method_QMARK__A_invoke, New: A_arbace_a2g_model_a2g_method_QMARK__A_new, Get: A_arbace_a2g_model_a2g_method_QMARK__A_get}

var A_arbace_a2g_model_a2g_method_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$a2g_method_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "a2g_method_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_a2g_method_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_a2g_method_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_a2g_method_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_a2g_method_QMARK__A_Init; i.Table = A_arbace_a2g_model_a2g_method_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_a2g_method_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_a2g_method_QMARK__A]()) }

func A_arbace_a2g_model_a2g_static_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_a2g_static_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_a2g_static_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_a2g_static_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_a2g_static_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_a2g_static_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_a2g_static_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_a2g_static_QMARK__A_invoke, New: A_arbace_a2g_model_a2g_static_QMARK__A_new, Get: A_arbace_a2g_model_a2g_static_QMARK__A_get}

var A_arbace_a2g_model_a2g_static_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$a2g_static_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "a2g_static_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_a2g_static_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_a2g_static_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_a2g_static_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_a2g_static_QMARK__A_Init; i.Table = A_arbace_a2g_model_a2g_static_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_a2g_static_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_a2g_static_QMARK__A]()) }

func A_arbace_a2g_model_abstract_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_abstract_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_abstract_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_abstract_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_abstract_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_abstract_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_abstract_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_abstract_QMARK__A_invoke, New: A_arbace_a2g_model_abstract_QMARK__A_new, Get: A_arbace_a2g_model_abstract_QMARK__A_get}

var A_arbace_a2g_model_abstract_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$abstract_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "abstract_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_abstract_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_abstract_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_abstract_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_abstract_QMARK__A_Init; i.Table = A_arbace_a2g_model_abstract_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_abstract_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_abstract_QMARK__A]()) }

func A_arbace_a2g_model_abstract_m_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_abstract_m_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_abstract_m_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_abstract_m_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_abstract_m_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_abstract_m_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_abstract_m_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_abstract_m_QMARK__A_invoke, New: A_arbace_a2g_model_abstract_m_QMARK__A_new, Get: A_arbace_a2g_model_abstract_m_QMARK__A_get}

var A_arbace_a2g_model_abstract_m_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$abstract_m_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "abstract_m_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_abstract_m_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_abstract_m_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_abstract_m_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_abstract_m_QMARK__A_Init; i.Table = A_arbace_a2g_model_abstract_m_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_abstract_m_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_abstract_m_QMARK__A]()) }

func A_arbace_a2g_model_all_supertypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_all_supertypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_all_supertypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_all_supertypes_A_New()}; return nil }

func A_arbace_a2g_model_all_supertypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_all_supertypes_A_fn_class)}; return nil }

var A_arbace_a2g_model_all_supertypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_all_supertypes_A_invoke, New: A_arbace_a2g_model_all_supertypes_A_new, Get: A_arbace_a2g_model_all_supertypes_A_get}

var A_arbace_a2g_model_all_supertypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$all_supertypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "all_supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_all_supertypes_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_all_supertypes_A_class.Info(); i.IsInstance = A_arbace_a2g_model_all_supertypes_A_InstanceOf; i.Init = A_arbace_a2g_model_all_supertypes_A_Init; i.Table = A_arbace_a2g_model_all_supertypes_A_members; jrt.RegisterGoType(A_arbace_a2g_model_all_supertypes_A_class, reflect.TypeFor[A_arbace_a2g_model_all_supertypes_A]()) }

func A_arbace_a2g_model_benign_init_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_benign_init_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_benign_init_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_benign_init_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_benign_init_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_benign_init_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_benign_init_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_benign_init_QMARK__A_invoke, New: A_arbace_a2g_model_benign_init_QMARK__A_new, Get: A_arbace_a2g_model_benign_init_QMARK__A_get}

var A_arbace_a2g_model_benign_init_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$benign_init_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "benign_init_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_benign_init_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_benign_init_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_benign_init_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_benign_init_QMARK__A_Init; i.Table = A_arbace_a2g_model_benign_init_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_benign_init_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_benign_init_QMARK__A]()) }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_fn_class)}; return nil }

var A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_invoke, New: A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_new, Get: A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_get}

var A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$benign_init_QMARK_$fn__1008000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_benign_init_QMARK__A_class, Simple: "fn__1008000165", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_class.Info(); i.IsInstance = A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_InstanceOf; i.Init = A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_Init; i.Table = A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_members; jrt.RegisterGoType(A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_class, reflect.TypeFor[A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A]()) }

func A_arbace_a2g_model_class_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_class_sym_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_a2g_model_class_sym_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_model_class_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_class_sym_A_New()}; return nil }

func A_arbace_a2g_model_class_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_class_sym_A_fn_class)}; return nil }

var A_arbace_a2g_model_class_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_class_sym_A_invoke, New: A_arbace_a2g_model_class_sym_A_new, Get: A_arbace_a2g_model_class_sym_A_get}

var A_arbace_a2g_model_class_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$class_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "class_sym", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_class_sym_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_class_sym_A_class.Info(); i.IsInstance = A_arbace_a2g_model_class_sym_A_InstanceOf; i.Init = A_arbace_a2g_model_class_sym_A_Init; i.Table = A_arbace_a2g_model_class_sym_A_members; jrt.RegisterGoType(A_arbace_a2g_model_class_sym_A_class, reflect.TypeFor[A_arbace_a2g_model_class_sym_A]()) }

func A_arbace_a2g_model_declared_vmethods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_declared_vmethods_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_declared_vmethods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_declared_vmethods_A_New()}; return nil }

func A_arbace_a2g_model_declared_vmethods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_declared_vmethods_A_fn_class)}; return nil }

var A_arbace_a2g_model_declared_vmethods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_declared_vmethods_A_invoke, New: A_arbace_a2g_model_declared_vmethods_A_new, Get: A_arbace_a2g_model_declared_vmethods_A_get}

var A_arbace_a2g_model_declared_vmethods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$declared_vmethods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "declared_vmethods", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_declared_vmethods_A_class.Info(); i.IsInstance = A_arbace_a2g_model_declared_vmethods_A_InstanceOf; i.Init = A_arbace_a2g_model_declared_vmethods_A_Init; i.Table = A_arbace_a2g_model_declared_vmethods_A_members; jrt.RegisterGoType(A_arbace_a2g_model_declared_vmethods_A_class, reflect.TypeFor[A_arbace_a2g_model_declared_vmethods_A]()) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_fn_class)}; return nil }

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_invoke, New: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_new, Get: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_get}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_declared_vmethods_A_class, Simple: "iter__1008000087__1008000091", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class.Info(); i.IsInstance = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_InstanceOf; i.Init = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_Init; i.Table = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_members; jrt.RegisterGoType(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class, reflect.TypeFor[A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A]()) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_fn_class)}; return nil }

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_invoke, New: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_new, Get: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_get}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class, Simple: "fn__1008000092", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class.Info(); i.IsInstance = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_InstanceOf; i.Init = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_Init; i.Table = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_members; jrt.RegisterGoType(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class, reflect.TypeFor[A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A]()) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_fn_class)}; return nil }

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_invoke, New: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_new, Get: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_get}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092$fn__1008000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class, Simple: "fn__1008000093", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class.Info(); i.IsInstance = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_InstanceOf; i.Init = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_Init; i.Table = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_members; jrt.RegisterGoType(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class, reflect.TypeFor[A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A]()) }

func A_arbace_a2g_model_desc_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_desc_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_desc_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_desc_classes_A_New()}; return nil }

func A_arbace_a2g_model_desc_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_desc_classes_A_fn_class)}; return nil }

var A_arbace_a2g_model_desc_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_desc_classes_A_invoke, New: A_arbace_a2g_model_desc_classes_A_new, Get: A_arbace_a2g_model_desc_classes_A_get}

var A_arbace_a2g_model_desc_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$desc_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "desc_classes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_desc_classes_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_desc_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_model_desc_classes_A_InstanceOf; i.Init = A_arbace_a2g_model_desc_classes_A_Init; i.Table = A_arbace_a2g_model_desc_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_model_desc_classes_A_class, reflect.TypeFor[A_arbace_a2g_model_desc_classes_A]()) }

func A_arbace_a2g_model_desc_in_world_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_desc_in_world_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_desc_in_world_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_desc_in_world_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_desc_in_world_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_desc_in_world_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_desc_in_world_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_desc_in_world_QMARK__A_invoke, New: A_arbace_a2g_model_desc_in_world_QMARK__A_new, Get: A_arbace_a2g_model_desc_in_world_QMARK__A_get}

var A_arbace_a2g_model_desc_in_world_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$desc_in_world_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "desc_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_desc_in_world_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_desc_in_world_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_desc_in_world_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_desc_in_world_QMARK__A_Init; i.Table = A_arbace_a2g_model_desc_in_world_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_desc_in_world_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_desc_in_world_QMARK__A]()) }

func A_arbace_a2g_model_erased_desc_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_erased_desc_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_erased_desc_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_erased_desc_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_erased_desc_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_erased_desc_QMARK__A_invoke, New: A_arbace_a2g_model_erased_desc_QMARK__A_new, Get: A_arbace_a2g_model_erased_desc_QMARK__A_get}

var A_arbace_a2g_model_erased_desc_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$erased_desc_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "erased_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_erased_desc_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_erased_desc_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_erased_desc_QMARK__A_Init; i.Table = A_arbace_a2g_model_erased_desc_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_erased_desc_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_erased_desc_QMARK__A]()) }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_fn_class)}; return nil }

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_invoke, New: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_new, Get: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_get}

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$erased_desc_QMARK_$fn__1008000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_erased_desc_QMARK__A_class, Simple: "fn__1008000045", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class.Info(); i.IsInstance = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_InstanceOf; i.Init = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_Init; i.Table = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_members; jrt.RegisterGoType(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class, reflect.TypeFor[A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A]()) }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_fn_class)}; return nil }

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_invoke, New: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_new, Get: A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_get}

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$erased_desc_QMARK_$fn__1008000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_erased_desc_QMARK__A_class, Simple: "fn__1008000047", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class.Info(); i.IsInstance = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_InstanceOf; i.Init = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_Init; i.Table = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_members; jrt.RegisterGoType(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class, reflect.TypeFor[A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A]()) }

func A_arbace_a2g_model_eval1008000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000004_A_New()}; return nil }

var A_arbace_a2g_model_eval1008000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_eval1008000004_A_new}

var A_arbace_a2g_model_eval1008000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_model_A_class, Simple: "eval1008000004", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000004_A"})

func init() { i := A_arbace_a2g_model_eval1008000004_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000004_A_InstanceOf; i.Table = A_arbace_a2g_model_eval1008000004_A_members; jrt.RegisterGoType(A_arbace_a2g_model_eval1008000004_A_class, reflect.TypeFor[A_arbace_a2g_model_eval1008000004_A]()) }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_New()}; return nil }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_fn_class)}; return nil }

var A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_invoke, New: A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_new, Get: A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_get}

var A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000004$loading__1927001464__auto____1008000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_eval1008000004_A_class, Simple: "loading__1927001464__auto____1008000005", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_InstanceOf; i.Init = A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_Init; i.Table = A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_members; jrt.RegisterGoType(A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class, reflect.TypeFor[A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A]()) }

func A_arbace_a2g_model_eval1008000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000008_A_New()}; return nil }

var A_arbace_a2g_model_eval1008000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_eval1008000008_A_new}

var A_arbace_a2g_model_eval1008000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_model_A_class, Simple: "eval1008000008", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000008_A"})

func init() { i := A_arbace_a2g_model_eval1008000008_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000008_A_InstanceOf; i.Table = A_arbace_a2g_model_eval1008000008_A_members; jrt.RegisterGoType(A_arbace_a2g_model_eval1008000008_A_class, reflect.TypeFor[A_arbace_a2g_model_eval1008000008_A]()) }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_eval1008000008_fn__1008000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000008_fn__1008000009_A_New()}; return nil }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_eval1008000008_fn__1008000009_A_fn_class)}; return nil }

var A_arbace_a2g_model_eval1008000008_fn__1008000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_eval1008000008_fn__1008000009_A_invoke, New: A_arbace_a2g_model_eval1008000008_fn__1008000009_A_new, Get: A_arbace_a2g_model_eval1008000008_fn__1008000009_A_get}

var A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000008$fn__1008000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_eval1008000008_A_class, Simple: "fn__1008000009", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000008_fn__1008000009_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000008_fn__1008000009_A_InstanceOf; i.Init = A_arbace_a2g_model_eval1008000008_fn__1008000009_A_Init; i.Table = A_arbace_a2g_model_eval1008000008_fn__1008000009_A_members; jrt.RegisterGoType(A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class, reflect.TypeFor[A_arbace_a2g_model_eval1008000008_fn__1008000009_A]()) }

func A_arbace_a2g_model_fields_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_fields_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_fields_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_fields_of_A_New()}; return nil }

func A_arbace_a2g_model_fields_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_fields_of_A_fn_class)}; return nil }

var A_arbace_a2g_model_fields_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_fields_of_A_invoke, New: A_arbace_a2g_model_fields_of_A_new, Get: A_arbace_a2g_model_fields_of_A_get}

var A_arbace_a2g_model_fields_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$fields_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "fields_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_fields_of_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_fields_of_A_class.Info(); i.IsInstance = A_arbace_a2g_model_fields_of_A_InstanceOf; i.Init = A_arbace_a2g_model_fields_of_A_Init; i.Table = A_arbace_a2g_model_fields_of_A_members; jrt.RegisterGoType(A_arbace_a2g_model_fields_of_A_class, reflect.TypeFor[A_arbace_a2g_model_fields_of_A]()) }

func A_arbace_a2g_model_final_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_final_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_final_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_final_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_final_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_final_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_final_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_final_QMARK__A_invoke, New: A_arbace_a2g_model_final_QMARK__A_new, Get: A_arbace_a2g_model_final_QMARK__A_get}

var A_arbace_a2g_model_final_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$final_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "final_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_final_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_final_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_final_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_final_QMARK__A_Init; i.Table = A_arbace_a2g_model_final_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_final_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_final_QMARK__A]()) }

func A_arbace_a2g_model_find_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_find_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_model_find_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_find_method_A_New()}; return nil }

func A_arbace_a2g_model_find_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_find_method_A_fn_class)}; return nil }

var A_arbace_a2g_model_find_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_find_method_A_invoke, New: A_arbace_a2g_model_find_method_A_new, Get: A_arbace_a2g_model_find_method_A_get}

var A_arbace_a2g_model_find_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$find_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "find_method", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_find_method_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_find_method_A_class.Info(); i.IsInstance = A_arbace_a2g_model_find_method_A_InstanceOf; i.Init = A_arbace_a2g_model_find_method_A_Init; i.Table = A_arbace_a2g_model_find_method_A_members; jrt.RegisterGoType(A_arbace_a2g_model_find_method_A_class, reflect.TypeFor[A_arbace_a2g_model_find_method_A]()) }

func A_arbace_a2g_model_find_method_fn__1008000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_find_method_fn__1008000077_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_find_method_fn__1008000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_find_method_fn__1008000077_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_find_method_fn__1008000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_find_method_fn__1008000077_A_fn_class)}; return nil }

var A_arbace_a2g_model_find_method_fn__1008000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_find_method_fn__1008000077_A_invoke, New: A_arbace_a2g_model_find_method_fn__1008000077_A_new, Get: A_arbace_a2g_model_find_method_fn__1008000077_A_get}

var A_arbace_a2g_model_find_method_fn__1008000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$find_method$fn__1008000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_find_method_A_class, Simple: "fn__1008000077", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_find_method_fn__1008000077_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_find_method_fn__1008000077_A_class.Info(); i.IsInstance = A_arbace_a2g_model_find_method_fn__1008000077_A_InstanceOf; i.Init = A_arbace_a2g_model_find_method_fn__1008000077_A_Init; i.Table = A_arbace_a2g_model_find_method_fn__1008000077_A_members; jrt.RegisterGoType(A_arbace_a2g_model_find_method_fn__1008000077_A_class, reflect.TypeFor[A_arbace_a2g_model_find_method_fn__1008000077_A]()) }

func A_arbace_a2g_model_go_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_go_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_go_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_go_name_A_New()}; return nil }

func A_arbace_a2g_model_go_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_go_name_A_fn_class)}; return nil }

var A_arbace_a2g_model_go_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_go_name_A_invoke, New: A_arbace_a2g_model_go_name_A_new, Get: A_arbace_a2g_model_go_name_A_get}

var A_arbace_a2g_model_go_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$go_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "go_name", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_go_name_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_go_name_A_class.Info(); i.IsInstance = A_arbace_a2g_model_go_name_A_InstanceOf; i.Init = A_arbace_a2g_model_go_name_A_Init; i.Table = A_arbace_a2g_model_go_name_A_members; jrt.RegisterGoType(A_arbace_a2g_model_go_name_A_class, reflect.TypeFor[A_arbace_a2g_model_go_name_A]()) }

func A_arbace_a2g_model_go_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_go_type_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_go_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_go_type_A_New()}; return nil }

func A_arbace_a2g_model_go_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_go_type_A_fn_class)}; return nil }

var A_arbace_a2g_model_go_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_go_type_A_invoke, New: A_arbace_a2g_model_go_type_A_new, Get: A_arbace_a2g_model_go_type_A_get}

var A_arbace_a2g_model_go_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$go_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "go_type", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_go_type_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_go_type_A_class.Info(); i.IsInstance = A_arbace_a2g_model_go_type_A_InstanceOf; i.Init = A_arbace_a2g_model_go_type_A_Init; i.Table = A_arbace_a2g_model_go_type_A_members; jrt.RegisterGoType(A_arbace_a2g_model_go_type_A_class, reflect.TypeFor[A_arbace_a2g_model_go_type_A]()) }

func A_arbace_a2g_model_hand_written_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_hand_written_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_hand_written_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_hand_written_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_hand_written_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_hand_written_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_hand_written_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_hand_written_QMARK__A_invoke, New: A_arbace_a2g_model_hand_written_QMARK__A_new, Get: A_arbace_a2g_model_hand_written_QMARK__A_get}

var A_arbace_a2g_model_hand_written_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$hand_written_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "hand_written_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_hand_written_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_hand_written_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_hand_written_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_hand_written_QMARK__A_Init; i.Table = A_arbace_a2g_model_hand_written_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_hand_written_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_hand_written_QMARK__A]()) }

func A_arbace_a2g_model_has_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_has_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_has_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_has_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_has_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_has_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_has_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_has_QMARK__A_invoke, New: A_arbace_a2g_model_has_QMARK__A_new, Get: A_arbace_a2g_model_has_QMARK__A_get}

var A_arbace_a2g_model_has_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$has_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "has_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_has_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_has_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_has_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_has_QMARK__A_Init; i.Table = A_arbace_a2g_model_has_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_has_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_has_QMARK__A]()) }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_hw_method_exists_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_hw_method_exists_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_hw_method_exists_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_hw_method_exists_QMARK__A_invoke, New: A_arbace_a2g_model_hw_method_exists_QMARK__A_new, Get: A_arbace_a2g_model_hw_method_exists_QMARK__A_get}

var A_arbace_a2g_model_hw_method_exists_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$hw_method_exists_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "hw_method_exists_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_hw_method_exists_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_hw_method_exists_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_hw_method_exists_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_hw_method_exists_QMARK__A_Init; i.Table = A_arbace_a2g_model_hw_method_exists_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_hw_method_exists_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_hw_method_exists_QMARK__A]()) }

func A_arbace_a2g_model_iface_desc_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_iface_desc_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_iface_desc_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_iface_desc_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_iface_desc_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_iface_desc_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_iface_desc_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_iface_desc_QMARK__A_invoke, New: A_arbace_a2g_model_iface_desc_QMARK__A_new, Get: A_arbace_a2g_model_iface_desc_QMARK__A_get}

var A_arbace_a2g_model_iface_desc_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$iface_desc_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "iface_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_iface_desc_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_iface_desc_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_iface_desc_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_iface_desc_QMARK__A_Init; i.Table = A_arbace_a2g_model_iface_desc_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_iface_desc_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_iface_desc_QMARK__A]()) }

func A_arbace_a2g_model_impl_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_impl_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_A_New()}; return nil }

func A_arbace_a2g_model_impl_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_A_invoke, New: A_arbace_a2g_model_impl_of_A_new, Get: A_arbace_a2g_model_impl_of_A_get}

var A_arbace_a2g_model_impl_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "impl_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_A_Init; i.Table = A_arbace_a2g_model_impl_of_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_A]()) }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_fn__1008000112_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_fn__1008000112_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_fn__1008000112_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_fn__1008000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_fn__1008000112_A_invoke, New: A_arbace_a2g_model_impl_of_fn__1008000112_A_new, Get: A_arbace_a2g_model_impl_of_fn__1008000112_A_get}

var A_arbace_a2g_model_impl_of_fn__1008000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$fn__1008000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_impl_of_A_class, Simple: "fn__1008000112", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000112_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_fn__1008000112_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_fn__1008000112_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_fn__1008000112_A_Init; i.Table = A_arbace_a2g_model_impl_of_fn__1008000112_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_fn__1008000112_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_fn__1008000112_A]()) }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_fn__1008000124_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_fn__1008000124_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_fn__1008000124_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_fn__1008000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_fn__1008000124_A_invoke, New: A_arbace_a2g_model_impl_of_fn__1008000124_A_new, Get: A_arbace_a2g_model_impl_of_fn__1008000124_A_get}

var A_arbace_a2g_model_impl_of_fn__1008000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$fn__1008000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_impl_of_A_class, Simple: "fn__1008000124", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000124_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_fn__1008000124_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_fn__1008000124_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_fn__1008000124_A_Init; i.Table = A_arbace_a2g_model_impl_of_fn__1008000124_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_fn__1008000124_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_fn__1008000124_A]()) }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_invoke, New: A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_new, Get: A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_get}

var A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$fn__1008000124$fn__1008000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_impl_of_fn__1008000124_A_class, Simple: "fn__1008000125", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_Init; i.Table = A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A]()) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_invoke, New: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_new, Get: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_get}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_impl_of_A_class, Simple: "iter__1008000114__1008000118", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_Init; i.Table = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A]()) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_invoke, New: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_new, Get: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_get}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class, Simple: "fn__1008000119", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_Init; i.Table = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A]()) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_fn_class)}; return nil }

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_invoke, New: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_new, Get: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_get}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119$fn__1008000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class, Simple: "fn__1008000120", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class.Info(); i.IsInstance = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_InstanceOf; i.Init = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_Init; i.Table = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_members; jrt.RegisterGoType(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class, reflect.TypeFor[A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A]()) }

func A_arbace_a2g_model_in_world_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_in_world_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_in_world_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_in_world_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_in_world_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_in_world_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_in_world_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_in_world_QMARK__A_invoke, New: A_arbace_a2g_model_in_world_QMARK__A_new, Get: A_arbace_a2g_model_in_world_QMARK__A_get}

var A_arbace_a2g_model_in_world_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$in_world_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_in_world_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_in_world_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_in_world_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_in_world_QMARK__A_Init; i.Table = A_arbace_a2g_model_in_world_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_in_world_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_in_world_QMARK__A]()) }

func A_arbace_a2g_model_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_info_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_info_A_New()}; return nil }

func A_arbace_a2g_model_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_info_A_fn_class)}; return nil }

var A_arbace_a2g_model_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_info_A_invoke, New: A_arbace_a2g_model_info_A_new, Get: A_arbace_a2g_model_info_A_get}

var A_arbace_a2g_model_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "info", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_info_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_info_A_class.Info(); i.IsInstance = A_arbace_a2g_model_info_A_InstanceOf; i.Init = A_arbace_a2g_model_info_A_Init; i.Table = A_arbace_a2g_model_info_A_members; jrt.RegisterGoType(A_arbace_a2g_model_info_A_class, reflect.TypeFor[A_arbace_a2g_model_info_A]()) }

func A_arbace_a2g_model_interface_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_interface_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_interface_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_interface_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_interface_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_interface_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_interface_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_interface_QMARK__A_invoke, New: A_arbace_a2g_model_interface_QMARK__A_new, Get: A_arbace_a2g_model_interface_QMARK__A_get}

var A_arbace_a2g_model_interface_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$interface_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_interface_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_interface_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_interface_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_interface_QMARK__A_Init; i.Table = A_arbace_a2g_model_interface_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_interface_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_interface_QMARK__A]()) }

func A_arbace_a2g_model_jobs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_jobs_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_jobs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_jobs_A_New()}; return nil }

func A_arbace_a2g_model_jobs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_jobs_A_fn_class)}; return nil }

var A_arbace_a2g_model_jobs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_jobs_A_invoke, New: A_arbace_a2g_model_jobs_A_new, Get: A_arbace_a2g_model_jobs_A_get}

var A_arbace_a2g_model_jobs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$jobs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "jobs", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jobs_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_jobs_A_class.Info(); i.IsInstance = A_arbace_a2g_model_jobs_A_InstanceOf; i.Init = A_arbace_a2g_model_jobs_A_Init; i.Table = A_arbace_a2g_model_jobs_A_members; jrt.RegisterGoType(A_arbace_a2g_model_jobs_A_class, reflect.TypeFor[A_arbace_a2g_model_jobs_A]()) }

func A_arbace_a2g_model_jrt_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_jrt_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_jrt_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_jrt_class_A_New()}; return nil }

func A_arbace_a2g_model_jrt_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_jrt_class_A_fn_class)}; return nil }

var A_arbace_a2g_model_jrt_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_jrt_class_A_invoke, New: A_arbace_a2g_model_jrt_class_A_new, Get: A_arbace_a2g_model_jrt_class_A_get}

var A_arbace_a2g_model_jrt_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$jrt_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "jrt_class", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jrt_class_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_jrt_class_A_class.Info(); i.IsInstance = A_arbace_a2g_model_jrt_class_A_InstanceOf; i.Init = A_arbace_a2g_model_jrt_class_A_Init; i.Table = A_arbace_a2g_model_jrt_class_A_members; jrt.RegisterGoType(A_arbace_a2g_model_jrt_class_A_class, reflect.TypeFor[A_arbace_a2g_model_jrt_class_A]()) }

func A_arbace_a2g_model_jrt_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_jrt_sym_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_jrt_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_jrt_sym_A_New()}; return nil }

func A_arbace_a2g_model_jrt_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_jrt_sym_A_fn_class)}; return nil }

var A_arbace_a2g_model_jrt_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_jrt_sym_A_invoke, New: A_arbace_a2g_model_jrt_sym_A_new, Get: A_arbace_a2g_model_jrt_sym_A_get}

var A_arbace_a2g_model_jrt_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$jrt_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "jrt_sym", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jrt_sym_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_jrt_sym_A_class.Info(); i.IsInstance = A_arbace_a2g_model_jrt_sym_A_InstanceOf; i.Init = A_arbace_a2g_model_jrt_sym_A_Init; i.Table = A_arbace_a2g_model_jrt_sym_A_members; jrt.RegisterGoType(A_arbace_a2g_model_jrt_sym_A_class, reflect.TypeFor[A_arbace_a2g_model_jrt_sym_A]()) }

func A_arbace_a2g_model_leaf_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_leaf_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_leaf_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_leaf_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_leaf_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_leaf_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_leaf_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_leaf_QMARK__A_invoke, New: A_arbace_a2g_model_leaf_QMARK__A_new, Get: A_arbace_a2g_model_leaf_QMARK__A_get}

var A_arbace_a2g_model_leaf_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$leaf_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "leaf_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_leaf_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_leaf_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_leaf_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_leaf_QMARK__A_Init; i.Table = A_arbace_a2g_model_leaf_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_leaf_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_leaf_QMARK__A]()) }

func A_arbace_a2g_model_make_subclass_index_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_make_subclass_index_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_make_subclass_index_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_make_subclass_index_A_New()}; return nil }

func A_arbace_a2g_model_make_subclass_index_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_make_subclass_index_A_fn_class)}; return nil }

var A_arbace_a2g_model_make_subclass_index_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_make_subclass_index_A_invoke, New: A_arbace_a2g_model_make_subclass_index_A_new, Get: A_arbace_a2g_model_make_subclass_index_A_get}

var A_arbace_a2g_model_make_subclass_index_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$make_subclass_index", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "make_subclass_index", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_make_subclass_index_A_class.Info(); i.IsInstance = A_arbace_a2g_model_make_subclass_index_A_InstanceOf; i.Init = A_arbace_a2g_model_make_subclass_index_A_Init; i.Table = A_arbace_a2g_model_make_subclass_index_A_members; jrt.RegisterGoType(A_arbace_a2g_model_make_subclass_index_A_class, reflect.TypeFor[A_arbace_a2g_model_make_subclass_index_A]()) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_fn_class)}; return nil }

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_invoke, New: A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_new, Get: A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_get}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$make_subclass_index$fn__1008000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_make_subclass_index_A_class, Simple: "fn__1008000057", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class.Info(); i.IsInstance = A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_InstanceOf; i.Init = A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_Init; i.Table = A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_members; jrt.RegisterGoType(A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class, reflect.TypeFor[A_arbace_a2g_model_make_subclass_index_fn__1008000057_A]()) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_fn_class)}; return nil }

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_invoke, New: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_new, Get: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_get}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class, Simple: "fn__1008000058", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class.Info(); i.IsInstance = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_InstanceOf; i.Init = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_Init; i.Table = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_members; jrt.RegisterGoType(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class, reflect.TypeFor[A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A]()) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_New()}; return nil }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_fn_class)}; return nil }

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_invoke, New: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_new, Get: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_get}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058$fn__1008000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class, Simple: "fn__1008000059", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class.Info(); i.IsInstance = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_InstanceOf; i.Init = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_Init; i.Table = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_members; jrt.RegisterGoType(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class, reflect.TypeFor[A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A]()) }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_mdesc_in_world_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_mdesc_in_world_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_mdesc_in_world_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_mdesc_in_world_QMARK__A_invoke, New: A_arbace_a2g_model_mdesc_in_world_QMARK__A_new, Get: A_arbace_a2g_model_mdesc_in_world_QMARK__A_get}

var A_arbace_a2g_model_mdesc_in_world_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$mdesc_in_world_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "mdesc_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_mdesc_in_world_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_mdesc_in_world_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_mdesc_in_world_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_mdesc_in_world_QMARK__A_Init; i.Table = A_arbace_a2g_model_mdesc_in_world_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_mdesc_in_world_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_mdesc_in_world_QMARK__A]()) }

func A_arbace_a2g_model_member_in_world_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_member_in_world_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_member_in_world_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_member_in_world_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_member_in_world_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_member_in_world_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_member_in_world_QMARK__A_invoke, New: A_arbace_a2g_model_member_in_world_QMARK__A_new, Get: A_arbace_a2g_model_member_in_world_QMARK__A_get}

var A_arbace_a2g_model_member_in_world_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$member_in_world_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "member_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_member_in_world_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_member_in_world_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_member_in_world_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_member_in_world_QMARK__A_Init; i.Table = A_arbace_a2g_model_member_in_world_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_member_in_world_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_member_in_world_QMARK__A]()) }

func A_arbace_a2g_model_method_desc_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_method_desc_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_method_desc_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_method_desc_classes_A_New()}; return nil }

func A_arbace_a2g_model_method_desc_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_method_desc_classes_A_fn_class)}; return nil }

var A_arbace_a2g_model_method_desc_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_method_desc_classes_A_invoke, New: A_arbace_a2g_model_method_desc_classes_A_new, Get: A_arbace_a2g_model_method_desc_classes_A_get}

var A_arbace_a2g_model_method_desc_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$method_desc_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "method_desc_classes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_method_desc_classes_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_method_desc_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_model_method_desc_classes_A_InstanceOf; i.Init = A_arbace_a2g_model_method_desc_classes_A_Init; i.Table = A_arbace_a2g_model_method_desc_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_model_method_desc_classes_A_class, reflect.TypeFor[A_arbace_a2g_model_method_desc_classes_A]()) }

func A_arbace_a2g_model_methods_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_methods_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_methods_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_methods_of_A_New()}; return nil }

func A_arbace_a2g_model_methods_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_methods_of_A_fn_class)}; return nil }

var A_arbace_a2g_model_methods_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_methods_of_A_invoke, New: A_arbace_a2g_model_methods_of_A_new, Get: A_arbace_a2g_model_methods_of_A_get}

var A_arbace_a2g_model_methods_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$methods_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "methods_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_methods_of_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_methods_of_A_class.Info(); i.IsInstance = A_arbace_a2g_model_methods_of_A_InstanceOf; i.Init = A_arbace_a2g_model_methods_of_A_Init; i.Table = A_arbace_a2g_model_methods_of_A_members; jrt.RegisterGoType(A_arbace_a2g_model_methods_of_A_class, reflect.TypeFor[A_arbace_a2g_model_methods_of_A]()) }

func A_arbace_a2g_model_par_mapv_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_par_mapv_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_model_par_mapv_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_par_mapv_A_New()}; return nil }

func A_arbace_a2g_model_par_mapv_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_par_mapv_A_fn_class)}; return nil }

var A_arbace_a2g_model_par_mapv_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_par_mapv_A_invoke, New: A_arbace_a2g_model_par_mapv_A_new, Get: A_arbace_a2g_model_par_mapv_A_get}

var A_arbace_a2g_model_par_mapv_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$par_mapv", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "par_mapv", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_par_mapv_A_class.Info(); i.IsInstance = A_arbace_a2g_model_par_mapv_A_InstanceOf; i.Init = A_arbace_a2g_model_par_mapv_A_Init; i.Table = A_arbace_a2g_model_par_mapv_A_members; jrt.RegisterGoType(A_arbace_a2g_model_par_mapv_A_class, reflect.TypeFor[A_arbace_a2g_model_par_mapv_A]()) }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_par_mapv_fn__1008000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_par_mapv_fn__1008000019_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_par_mapv_fn__1008000019_A_fn_class)}; return nil }

var A_arbace_a2g_model_par_mapv_fn__1008000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_par_mapv_fn__1008000019_A_invoke, New: A_arbace_a2g_model_par_mapv_fn__1008000019_A_new, Get: A_arbace_a2g_model_par_mapv_fn__1008000019_A_get}

var A_arbace_a2g_model_par_mapv_fn__1008000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$par_mapv$fn__1008000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_par_mapv_A_class, Simple: "fn__1008000019", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_fn__1008000019_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_par_mapv_fn__1008000019_A_class.Info(); i.IsInstance = A_arbace_a2g_model_par_mapv_fn__1008000019_A_InstanceOf; i.Init = A_arbace_a2g_model_par_mapv_fn__1008000019_A_Init; i.Table = A_arbace_a2g_model_par_mapv_fn__1008000019_A_members; jrt.RegisterGoType(A_arbace_a2g_model_par_mapv_fn__1008000019_A_class, reflect.TypeFor[A_arbace_a2g_model_par_mapv_fn__1008000019_A]()) }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_New_O(args[0])}; return nil }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_fn_class)}; return nil }

var A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_invoke, New: A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_new, Get: A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_get}

var A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$par_mapv$fn__1008000019$fn__1008000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_par_mapv_fn__1008000019_A_class, Simple: "fn__1008000020", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class.Info(); i.IsInstance = A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_InstanceOf; i.Init = A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_Init; i.Table = A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_members; jrt.RegisterGoType(A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class, reflect.TypeFor[A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A]()) }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_par_mapv_work__1008000017_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_par_mapv_work__1008000017_A_New_I_O_O_O_O_O(args[0].(int32), args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_par_mapv_work__1008000017_A_fn_class)}; return nil }

var A_arbace_a2g_model_par_mapv_work__1008000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_par_mapv_work__1008000017_A_invoke, New: A_arbace_a2g_model_par_mapv_work__1008000017_A_new, Get: A_arbace_a2g_model_par_mapv_work__1008000017_A_get}

var A_arbace_a2g_model_par_mapv_work__1008000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$par_mapv$work__1008000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_model_par_mapv_A_class, Simple: "work__1008000017", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_work__1008000017_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_par_mapv_work__1008000017_A_class.Info(); i.IsInstance = A_arbace_a2g_model_par_mapv_work__1008000017_A_InstanceOf; i.Init = A_arbace_a2g_model_par_mapv_work__1008000017_A_Init; i.Table = A_arbace_a2g_model_par_mapv_work__1008000017_A_members; jrt.RegisterGoType(A_arbace_a2g_model_par_mapv_work__1008000017_A_class, reflect.TypeFor[A_arbace_a2g_model_par_mapv_work__1008000017_A]()) }

func A_arbace_a2g_model_pkg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pkg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pkg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pkg_A_New()}; return nil }

func A_arbace_a2g_model_pkg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pkg_A_fn_class)}; return nil }

var A_arbace_a2g_model_pkg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pkg_A_invoke, New: A_arbace_a2g_model_pkg_A_new, Get: A_arbace_a2g_model_pkg_A_get}

var A_arbace_a2g_model_pkg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pkg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "pkg", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pkg_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pkg_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pkg_A_InstanceOf; i.Init = A_arbace_a2g_model_pkg_A_Init; i.Table = A_arbace_a2g_model_pkg_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pkg_A_class, reflect.TypeFor[A_arbace_a2g_model_pkg_A]()) }

func A_arbace_a2g_model_pointer_desc_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pointer_desc_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pointer_desc_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_pointer_desc_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pointer_desc_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_pointer_desc_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pointer_desc_QMARK__A_invoke, New: A_arbace_a2g_model_pointer_desc_QMARK__A_new, Get: A_arbace_a2g_model_pointer_desc_QMARK__A_get}

var A_arbace_a2g_model_pointer_desc_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pointer_desc_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "pointer_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pointer_desc_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pointer_desc_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_pointer_desc_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_pointer_desc_QMARK__A_Init; i.Table = A_arbace_a2g_model_pointer_desc_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_pointer_desc_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_pointer_desc_QMARK__A]()) }

func A_arbace_a2g_model_private_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_private_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_private_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_private_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_private_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_private_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_private_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_private_QMARK__A_invoke, New: A_arbace_a2g_model_private_QMARK__A_new, Get: A_arbace_a2g_model_private_QMARK__A_get}

var A_arbace_a2g_model_private_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$private_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "private_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_private_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_private_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_private_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_private_QMARK__A_Init; i.Table = A_arbace_a2g_model_private_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_private_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_private_QMARK__A]()) }

func A_arbace_a2g_model_pure_ctor_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_ctor_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_ctor_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_ctor_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_ctor_QMARK__A_invoke, New: A_arbace_a2g_model_pure_ctor_QMARK__A_new, Get: A_arbace_a2g_model_pure_ctor_QMARK__A_get}

var A_arbace_a2g_model_pure_ctor_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_ctor_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "pure_ctor_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_ctor_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_ctor_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_pure_ctor_QMARK__A_Init; i.Table = A_arbace_a2g_model_pure_ctor_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_ctor_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_pure_ctor_QMARK__A]()) }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_invoke, New: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_new, Get: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_get}

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_ctor_QMARK_$fn__1008000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_ctor_QMARK__A_class, Simple: "fn__1008000133", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_Init; i.Table = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A]()) }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_invoke, New: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_new, Get: A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_get}

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_ctor_QMARK_$fn__1008000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_ctor_QMARK__A_class, Simple: "fn__1008000135", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_Init; i.Table = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__A_new, Get: A_arbace_a2g_model_pure_node_QMARK__A_get}

var A_arbace_a2g_model_pure_node_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "pure_node_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000145", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000148", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000153", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_New()}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000155", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000157", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000159", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A]()) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_fn_class)}; return nil }

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_invoke, New: A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_new, Get: A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_get}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_pure_node_QMARK__A_class, Simple: "fn__1008000161", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_class.Info(); i.IsInstance = A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_InstanceOf; i.Init = A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_Init; i.Table = A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_members; jrt.RegisterGoType(A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_class, reflect.TypeFor[A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A]()) }

func A_arbace_a2g_model_qualify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_qualify_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_model_qualify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_qualify_A_New()}; return nil }

func A_arbace_a2g_model_qualify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_qualify_A_fn_class)}; return nil }

var A_arbace_a2g_model_qualify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_qualify_A_invoke, New: A_arbace_a2g_model_qualify_A_new, Get: A_arbace_a2g_model_qualify_A_get}

var A_arbace_a2g_model_qualify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$qualify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "qualify", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_qualify_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_qualify_A_class.Info(); i.IsInstance = A_arbace_a2g_model_qualify_A_InstanceOf; i.Init = A_arbace_a2g_model_qualify_A_Init; i.Table = A_arbace_a2g_model_qualify_A_members; jrt.RegisterGoType(A_arbace_a2g_model_qualify_A_class, reflect.TypeFor[A_arbace_a2g_model_qualify_A]()) }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_reflectable_interface_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_reflectable_interface_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_reflectable_interface_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_reflectable_interface_QMARK__A_invoke, New: A_arbace_a2g_model_reflectable_interface_QMARK__A_new, Get: A_arbace_a2g_model_reflectable_interface_QMARK__A_get}

var A_arbace_a2g_model_reflectable_interface_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$reflectable_interface_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "reflectable_interface_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflectable_interface_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_reflectable_interface_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_reflectable_interface_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_reflectable_interface_QMARK__A_Init; i.Table = A_arbace_a2g_model_reflectable_interface_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_reflectable_interface_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_reflectable_interface_QMARK__A]()) }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_New()}; return nil }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_fn_class)}; return nil }

var A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_invoke, New: A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_new, Get: A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_get}

var A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$reflectable_interface_QMARK_$fn__1008000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_reflectable_interface_QMARK__A_class, Simple: "fn__1008000033", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class.Info(); i.IsInstance = A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_InstanceOf; i.Init = A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_Init; i.Table = A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_members; jrt.RegisterGoType(A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class, reflect.TypeFor[A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A]()) }

func A_arbace_a2g_model_reflected_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_reflected_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_reflected_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_reflected_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_reflected_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_reflected_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_reflected_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_reflected_QMARK__A_invoke, New: A_arbace_a2g_model_reflected_QMARK__A_new, Get: A_arbace_a2g_model_reflected_QMARK__A_get}

var A_arbace_a2g_model_reflected_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$reflected_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "reflected_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflected_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_reflected_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_reflected_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_reflected_QMARK__A_Init; i.Table = A_arbace_a2g_model_reflected_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_reflected_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_reflected_QMARK__A]()) }

func A_arbace_a2g_model_static_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_static_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_static_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_static_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_static_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_static_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_static_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_static_QMARK__A_invoke, New: A_arbace_a2g_model_static_QMARK__A_new, Get: A_arbace_a2g_model_static_QMARK__A_get}

var A_arbace_a2g_model_static_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$static_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "static_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_static_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_static_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_static_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_static_QMARK__A_Init; i.Table = A_arbace_a2g_model_static_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_static_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_static_QMARK__A]()) }

func A_arbace_a2g_model_subclasses_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_subclasses_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_subclasses_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_subclasses_A_New()}; return nil }

func A_arbace_a2g_model_subclasses_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_subclasses_A_fn_class)}; return nil }

var A_arbace_a2g_model_subclasses_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_subclasses_A_invoke, New: A_arbace_a2g_model_subclasses_A_new, Get: A_arbace_a2g_model_subclasses_A_get}

var A_arbace_a2g_model_subclasses_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$subclasses", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "subclasses", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_subclasses_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_subclasses_A_class.Info(); i.IsInstance = A_arbace_a2g_model_subclasses_A_InstanceOf; i.Init = A_arbace_a2g_model_subclasses_A_Init; i.Table = A_arbace_a2g_model_subclasses_A_members; jrt.RegisterGoType(A_arbace_a2g_model_subclasses_A_class, reflect.TypeFor[A_arbace_a2g_model_subclasses_A]()) }

func A_arbace_a2g_model_superclass_chain_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_superclass_chain_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_superclass_chain_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_superclass_chain_A_New()}; return nil }

func A_arbace_a2g_model_superclass_chain_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_superclass_chain_A_fn_class)}; return nil }

var A_arbace_a2g_model_superclass_chain_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_superclass_chain_A_invoke, New: A_arbace_a2g_model_superclass_chain_A_new, Get: A_arbace_a2g_model_superclass_chain_A_get}

var A_arbace_a2g_model_superclass_chain_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$superclass_chain", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "superclass_chain", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_superclass_chain_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_superclass_chain_A_class.Info(); i.IsInstance = A_arbace_a2g_model_superclass_chain_A_InstanceOf; i.Init = A_arbace_a2g_model_superclass_chain_A_Init; i.Table = A_arbace_a2g_model_superclass_chain_A_members; jrt.RegisterGoType(A_arbace_a2g_model_superclass_chain_A_class, reflect.TypeFor[A_arbace_a2g_model_superclass_chain_A]()) }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_superclass_chain_fn__1008000104_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_superclass_chain_fn__1008000104_A_New()}; return nil }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_superclass_chain_fn__1008000104_A_fn_class)}; return nil }

var A_arbace_a2g_model_superclass_chain_fn__1008000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_superclass_chain_fn__1008000104_A_invoke, New: A_arbace_a2g_model_superclass_chain_fn__1008000104_A_new, Get: A_arbace_a2g_model_superclass_chain_fn__1008000104_A_get}

var A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$superclass_chain$fn__1008000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_superclass_chain_A_class, Simple: "fn__1008000104", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_superclass_chain_fn__1008000104_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class.Info(); i.IsInstance = A_arbace_a2g_model_superclass_chain_fn__1008000104_A_InstanceOf; i.Init = A_arbace_a2g_model_superclass_chain_fn__1008000104_A_Init; i.Table = A_arbace_a2g_model_superclass_chain_fn__1008000104_A_members; jrt.RegisterGoType(A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class, reflect.TypeFor[A_arbace_a2g_model_superclass_chain_fn__1008000104_A]()) }

func A_arbace_a2g_model_supertypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_supertypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_supertypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_supertypes_A_New()}; return nil }

func A_arbace_a2g_model_supertypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_supertypes_A_fn_class)}; return nil }

var A_arbace_a2g_model_supertypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_supertypes_A_invoke, New: A_arbace_a2g_model_supertypes_A_new, Get: A_arbace_a2g_model_supertypes_A_get}

var A_arbace_a2g_model_supertypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$supertypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_supertypes_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_supertypes_A_class.Info(); i.IsInstance = A_arbace_a2g_model_supertypes_A_InstanceOf; i.Init = A_arbace_a2g_model_supertypes_A_Init; i.Table = A_arbace_a2g_model_supertypes_A_members; jrt.RegisterGoType(A_arbace_a2g_model_supertypes_A_class, reflect.TypeFor[A_arbace_a2g_model_supertypes_A]()) }

func A_arbace_a2g_model_top_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_top_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_top_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_top_class_A_New()}; return nil }

func A_arbace_a2g_model_top_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_top_class_A_fn_class)}; return nil }

var A_arbace_a2g_model_top_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_top_class_A_invoke, New: A_arbace_a2g_model_top_class_A_new, Get: A_arbace_a2g_model_top_class_A_get}

var A_arbace_a2g_model_top_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$top_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "top_class", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_top_class_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_top_class_A_class.Info(); i.IsInstance = A_arbace_a2g_model_top_class_A_InstanceOf; i.Init = A_arbace_a2g_model_top_class_A_Init; i.Table = A_arbace_a2g_model_top_class_A_members; jrt.RegisterGoType(A_arbace_a2g_model_top_class_A_class, reflect.TypeFor[A_arbace_a2g_model_top_class_A]()) }

func A_arbace_a2g_model_translatable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_translatable_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_translatable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_translatable_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_translatable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_translatable_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_translatable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_translatable_QMARK__A_invoke, New: A_arbace_a2g_model_translatable_QMARK__A_new, Get: A_arbace_a2g_model_translatable_QMARK__A_get}

var A_arbace_a2g_model_translatable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$translatable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "translatable_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_translatable_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_translatable_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_translatable_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_translatable_QMARK__A_Init; i.Table = A_arbace_a2g_model_translatable_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_translatable_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_translatable_QMARK__A]()) }

func A_arbace_a2g_model_translated_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_translated_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_translated_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_translated_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_translated_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_translated_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_translated_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_translated_QMARK__A_invoke, New: A_arbace_a2g_model_translated_QMARK__A_new, Get: A_arbace_a2g_model_translated_QMARK__A_get}

var A_arbace_a2g_model_translated_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$translated_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "translated_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_translated_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_translated_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_translated_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_translated_QMARK__A_Init; i.Table = A_arbace_a2g_model_translated_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_translated_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_translated_QMARK__A]()) }

func A_arbace_a2g_model_trivial_init_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_trivial_init_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_trivial_init_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_trivial_init_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_trivial_init_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_trivial_init_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_trivial_init_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_trivial_init_QMARK__A_invoke, New: A_arbace_a2g_model_trivial_init_QMARK__A_new, Get: A_arbace_a2g_model_trivial_init_QMARK__A_get}

var A_arbace_a2g_model_trivial_init_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$trivial_init_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "trivial_init_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_trivial_init_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_trivial_init_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_trivial_init_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_trivial_init_QMARK__A_Init; i.Table = A_arbace_a2g_model_trivial_init_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_trivial_init_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_trivial_init_QMARK__A]()) }

func A_arbace_a2g_model_virtual_member_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_virtual_member_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_virtual_member_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_virtual_member_QMARK__A_New()}; return nil }

func A_arbace_a2g_model_virtual_member_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_virtual_member_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_model_virtual_member_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_virtual_member_QMARK__A_invoke, New: A_arbace_a2g_model_virtual_member_QMARK__A_new, Get: A_arbace_a2g_model_virtual_member_QMARK__A_get}

var A_arbace_a2g_model_virtual_member_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$virtual_member_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "virtual_member_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_virtual_member_QMARK__A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_virtual_member_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_model_virtual_member_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_model_virtual_member_QMARK__A_Init; i.Table = A_arbace_a2g_model_virtual_member_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_model_virtual_member_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_model_virtual_member_QMARK__A]()) }

func A_arbace_a2g_model_vmethods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_vmethods_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_vmethods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_vmethods_A_New()}; return nil }

func A_arbace_a2g_model_vmethods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_vmethods_A_fn_class)}; return nil }

var A_arbace_a2g_model_vmethods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_vmethods_A_invoke, New: A_arbace_a2g_model_vmethods_A_new, Get: A_arbace_a2g_model_vmethods_A_get}

var A_arbace_a2g_model_vmethods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$vmethods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "vmethods", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_vmethods_A_class.Info(); i.IsInstance = A_arbace_a2g_model_vmethods_A_InstanceOf; i.Init = A_arbace_a2g_model_vmethods_A_Init; i.Table = A_arbace_a2g_model_vmethods_A_members; jrt.RegisterGoType(A_arbace_a2g_model_vmethods_A_class, reflect.TypeFor[A_arbace_a2g_model_vmethods_A]()) }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_vmethods_fn__1008000098_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_vmethods_fn__1008000098_A_New()}; return nil }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_vmethods_fn__1008000098_A_fn_class)}; return nil }

var A_arbace_a2g_model_vmethods_fn__1008000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_vmethods_fn__1008000098_A_invoke, New: A_arbace_a2g_model_vmethods_fn__1008000098_A_new, Get: A_arbace_a2g_model_vmethods_fn__1008000098_A_get}

var A_arbace_a2g_model_vmethods_fn__1008000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$vmethods$fn__1008000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_vmethods_A_class, Simple: "fn__1008000098", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_fn__1008000098_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_vmethods_fn__1008000098_A_class.Info(); i.IsInstance = A_arbace_a2g_model_vmethods_fn__1008000098_A_InstanceOf; i.Init = A_arbace_a2g_model_vmethods_fn__1008000098_A_Init; i.Table = A_arbace_a2g_model_vmethods_fn__1008000098_A_members; jrt.RegisterGoType(A_arbace_a2g_model_vmethods_fn__1008000098_A_class, reflect.TypeFor[A_arbace_a2g_model_vmethods_fn__1008000098_A]()) }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_New()}; return nil }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_fn_class)}; return nil }

var A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_invoke, New: A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_new, Get: A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_get}

var A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$vmethods$fn__1008000098$fn__1008000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_model_vmethods_fn__1008000098_A_class, Simple: "fn__1008000099", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class.Info(); i.IsInstance = A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_InstanceOf; i.Init = A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_Init; i.Table = A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_members; jrt.RegisterGoType(A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class, reflect.TypeFor[A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A]()) }

func A_arbace_a2g_model_world_supertypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_model_world_supertypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_model_world_supertypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_world_supertypes_A_New()}; return nil }

func A_arbace_a2g_model_world_supertypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_model_world_supertypes_A_fn_class)}; return nil }

var A_arbace_a2g_model_world_supertypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_model_world_supertypes_A_invoke, New: A_arbace_a2g_model_world_supertypes_A_new, Get: A_arbace_a2g_model_world_supertypes_A_get}

var A_arbace_a2g_model_world_supertypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$world_supertypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_model_A_class, Simple: "world_supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_world_supertypes_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model_world_supertypes_A_class.Info(); i.IsInstance = A_arbace_a2g_model_world_supertypes_A_InstanceOf; i.Init = A_arbace_a2g_model_world_supertypes_A_Init; i.Table = A_arbace_a2g_model_world_supertypes_A_members; jrt.RegisterGoType(A_arbace_a2g_model_world_supertypes_A_class, reflect.TypeFor[A_arbace_a2g_model_world_supertypes_A]()) }

func A_arbace_a2g_model__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_model__init_A_Load__O(); case 1: return A_arbace_a2g_model__init_A_Unit0__O(); case 2: return A_arbace_a2g_model__init_A_Unit1__O(); case 3: return A_arbace_a2g_model__init_A_Unit10__O(); case 4: return A_arbace_a2g_model__init_A_Unit11__O(); case 5: return A_arbace_a2g_model__init_A_Unit12__O(); case 6: return A_arbace_a2g_model__init_A_Unit13__O(); case 7: return A_arbace_a2g_model__init_A_Unit14__O(); case 8: return A_arbace_a2g_model__init_A_Unit15__O(); case 9: return A_arbace_a2g_model__init_A_Unit16__O(); case 10: return A_arbace_a2g_model__init_A_Unit17__O(); case 11: return A_arbace_a2g_model__init_A_Unit18__O(); case 12: return A_arbace_a2g_model__init_A_Unit19__O(); case 13: return A_arbace_a2g_model__init_A_Unit2__O(); case 14: return A_arbace_a2g_model__init_A_Unit20__O(); case 15: return A_arbace_a2g_model__init_A_Unit21__O(); case 16: return A_arbace_a2g_model__init_A_Unit22__O(); case 17: return A_arbace_a2g_model__init_A_Unit23__O(); case 18: return A_arbace_a2g_model__init_A_Unit24__O(); case 19: return A_arbace_a2g_model__init_A_Unit25__O(); case 20: return A_arbace_a2g_model__init_A_Unit26__O(); case 21: return A_arbace_a2g_model__init_A_Unit27__O(); case 22: return A_arbace_a2g_model__init_A_Unit28__O(); case 23: return A_arbace_a2g_model__init_A_Unit29__O(); case 24: return A_arbace_a2g_model__init_A_Unit3__O(); case 25: return A_arbace_a2g_model__init_A_Unit30__O(); case 26: return A_arbace_a2g_model__init_A_Unit31__O(); case 27: return A_arbace_a2g_model__init_A_Unit32__O(); case 28: return A_arbace_a2g_model__init_A_Unit33__O(); case 29: return A_arbace_a2g_model__init_A_Unit34__O(); case 30: return A_arbace_a2g_model__init_A_Unit35__O(); case 31: return A_arbace_a2g_model__init_A_Unit36__O(); case 32: return A_arbace_a2g_model__init_A_Unit37__O(); case 33: return A_arbace_a2g_model__init_A_Unit38__O(); case 34: return A_arbace_a2g_model__init_A_Unit39__O(); case 35: return A_arbace_a2g_model__init_A_Unit4__O(); case 36: return A_arbace_a2g_model__init_A_Unit40__O(); case 37: return A_arbace_a2g_model__init_A_Unit41__O(); case 38: return A_arbace_a2g_model__init_A_Unit42__O(); case 39: return A_arbace_a2g_model__init_A_Unit43__O(); case 40: return A_arbace_a2g_model__init_A_Unit44__O(); case 41: return A_arbace_a2g_model__init_A_Unit45__O(); case 42: return A_arbace_a2g_model__init_A_Unit46__O(); case 43: return A_arbace_a2g_model__init_A_Unit47__O(); case 44: return A_arbace_a2g_model__init_A_Unit48__O(); case 45: return A_arbace_a2g_model__init_A_Unit49__O(); case 46: return A_arbace_a2g_model__init_A_Unit5__O(); case 47: return A_arbace_a2g_model__init_A_Unit50__O(); case 48: return A_arbace_a2g_model__init_A_Unit51__O(); case 49: return A_arbace_a2g_model__init_A_Unit52__O(); case 50: return A_arbace_a2g_model__init_A_Unit53__O(); case 51: return A_arbace_a2g_model__init_A_Unit54__O(); case 52: return A_arbace_a2g_model__init_A_Unit55__O(); case 53: return A_arbace_a2g_model__init_A_Unit56__O(); case 54: return A_arbace_a2g_model__init_A_Unit57__O(); case 55: return A_arbace_a2g_model__init_A_Unit58__O(); case 56: return A_arbace_a2g_model__init_A_Unit59__O(); case 57: return A_arbace_a2g_model__init_A_Unit6__O(); case 58: return A_arbace_a2g_model__init_A_Unit60__O(); case 59: return A_arbace_a2g_model__init_A_Unit61__O(); case 60: return A_arbace_a2g_model__init_A_Unit62__O(); case 61: return A_arbace_a2g_model__init_A_Unit63__O(); case 62: return A_arbace_a2g_model__init_A_Unit64__O(); case 63: return A_arbace_a2g_model__init_A_Unit65__O(); case 64: return A_arbace_a2g_model__init_A_Unit66__O(); case 65: return A_arbace_a2g_model__init_A_Unit7__O(); case 66: return A_arbace_a2g_model__init_A_Unit8__O(); case 67: return A_arbace_a2g_model__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_model__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model__init_A_New()}; return nil }

var A_arbace_a2g_model__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_model__init_A_invoke, New: A_arbace_a2g_model__init_A_new}

var A_arbace_a2g_model__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model__init_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model__init_A_class.Info(); i.IsInstance = A_arbace_a2g_model__init_A_InstanceOf; i.Init = A_arbace_a2g_model__init_A_Init; i.Table = A_arbace_a2g_model__init_A_members; jrt.RegisterGoType(A_arbace_a2g_model__init_A_class, reflect.TypeFor[A_arbace_a2g_model__init_A]()) }
