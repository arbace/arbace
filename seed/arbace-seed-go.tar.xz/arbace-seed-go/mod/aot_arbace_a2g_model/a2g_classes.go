//line a2g_classes.ae:1
package aot_arbace_a2g_model

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_a2g_model_T_A_class, Name: "arbace.a2g.model$T", Modifiers: 25, Simple: "T", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_T_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_a2g_method_QMARK__A_class, Name: "arbace.a2g.model$a2g_method_QMARK_", Modifiers: 25, Simple: "a2g_method_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_a2g_method_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_a2g_static_QMARK__A_class, Name: "arbace.a2g.model$a2g_static_QMARK_", Modifiers: 25, Simple: "a2g_static_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_a2g_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_abstract_QMARK__A_class, Name: "arbace.a2g.model$abstract_QMARK_", Modifiers: 25, Simple: "abstract_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_abstract_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_abstract_m_QMARK__A_class, Name: "arbace.a2g.model$abstract_m_QMARK_", Modifiers: 25, Simple: "abstract_m_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_abstract_m_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_all_supertypes_A_class, Name: "arbace.a2g.model$all_supertypes", Modifiers: 25, Simple: "all_supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_all_supertypes_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_benign_init_QMARK__A_class, Name: "arbace.a2g.model$benign_init_QMARK_", Modifiers: 25, Simple: "benign_init_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_benign_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_benign_init_QMARK__fn__1008000168_A_class, Name: "arbace.a2g.model$benign_init_QMARK_$fn__1008000168", Modifiers: 25, Simple: "fn__1008000168", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_benign_init_QMARK__fn__1008000168_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_benign_init_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_class_sym_A_class, Name: "arbace.a2g.model$class_sym", Modifiers: 25, Simple: "class_sym", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_class_sym_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_code_class_QMARK__A_class, Name: "arbace.a2g.model$code_class_QMARK_", Modifiers: 25, Simple: "code_class_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_code_class_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_code_iface_QMARK__A_class, Name: "arbace.a2g.model$code_iface_QMARK_", Modifiers: 25, Simple: "code_iface_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_code_iface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_declared_vmethods_A_class, Name: "arbace.a2g.model$declared_vmethods", Modifiers: 25, Simple: "declared_vmethods", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class, Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091", Modifiers: 25, Simple: "iter__1008000087__1008000091", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_declared_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class, Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092", Modifiers: 25, Simple: "fn__1008000092", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class, Name: "arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092$fn__1008000093", Modifiers: 25, Simple: "fn__1008000093", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_desc_classes_A_class, Name: "arbace.a2g.model$desc_classes", Modifiers: 25, Simple: "desc_classes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_desc_in_world_QMARK__A_class, Name: "arbace.a2g.model$desc_in_world_QMARK_", Modifiers: 25, Simple: "desc_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_desc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_erased_desc_QMARK__A_class, Name: "arbace.a2g.model$erased_desc_QMARK_", Modifiers: 25, Simple: "erased_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class, Name: "arbace.a2g.model$erased_desc_QMARK_$fn__1008000045", Modifiers: 25, Simple: "fn__1008000045", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class, Name: "arbace.a2g.model$erased_desc_QMARK_$fn__1008000047", Modifiers: 25, Simple: "fn__1008000047", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_erased_desc_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class, Name: "arbace.a2g.model$eval1008000004$loading__1927001464__auto____1008000005", Modifiers: 25, Simple: "loading__1927001464__auto____1008000005", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_eval1008000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class, Name: "arbace.a2g.model$eval1008000008$fn__1008000009", Modifiers: 25, Simple: "fn__1008000009", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000008_fn__1008000009_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_eval1008000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_fields_of_A_class, Name: "arbace.a2g.model$fields_of", Modifiers: 25, Simple: "fields_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_fields_of_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_final_QMARK__A_class, Name: "arbace.a2g.model$final_QMARK_", Modifiers: 25, Simple: "final_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_final_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_find_method_A_class, Name: "arbace.a2g.model$find_method", Modifiers: 25, Simple: "find_method", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_find_method_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_find_method_fn__1008000077_A_class, Name: "arbace.a2g.model$find_method$fn__1008000077", Modifiers: 25, Simple: "fn__1008000077", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_find_method_fn__1008000077_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_find_method_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_go_name_A_class, Name: "arbace.a2g.model$go_name", Modifiers: 25, Simple: "go_name", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_go_name_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_go_type_A_class, Name: "arbace.a2g.model$go_type", Modifiers: 25, Simple: "go_type", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_go_type_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_hand_written_QMARK__A_class, Name: "arbace.a2g.model$hand_written_QMARK_", Modifiers: 25, Simple: "hand_written_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_hand_written_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_has_QMARK__A_class, Name: "arbace.a2g.model$has_QMARK_", Modifiers: 25, Simple: "has_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_has_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_hw_method_exists_QMARK__A_class, Name: "arbace.a2g.model$hw_method_exists_QMARK_", Modifiers: 25, Simple: "hw_method_exists_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_hw_method_exists_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_iface_desc_QMARK__A_class, Name: "arbace.a2g.model$iface_desc_QMARK_", Modifiers: 25, Simple: "iface_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_iface_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_A_class, Name: "arbace.a2g.model$impl_of", Modifiers: 25, Simple: "impl_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_fn__1008000112_A_class, Name: "arbace.a2g.model$impl_of$fn__1008000112", Modifiers: 25, Simple: "fn__1008000112", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000112_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_fn__1008000124_A_class, Name: "arbace.a2g.model$impl_of$fn__1008000124", Modifiers: 25, Simple: "fn__1008000124", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000124_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class, Name: "arbace.a2g.model$impl_of$fn__1008000124$fn__1008000125", Modifiers: 25, Simple: "fn__1008000125", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_fn__1008000124_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class, Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118", Modifiers: 25, Simple: "iter__1008000114__1008000118", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class, Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119", Modifiers: 25, Simple: "fn__1008000119", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class, Name: "arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119$fn__1008000120", Modifiers: 25, Simple: "fn__1008000120", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_in_world_QMARK__A_class, Name: "arbace.a2g.model$in_world_QMARK_", Modifiers: 25, Simple: "in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_info_A_class, Name: "arbace.a2g.model$info", Modifiers: 25, Simple: "info", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_info_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_interface_QMARK__A_class, Name: "arbace.a2g.model$interface_QMARK_", Modifiers: 25, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_jobs_A_class, Name: "arbace.a2g.model$jobs", Modifiers: 25, Simple: "jobs", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jobs_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_jrt_class_A_class, Name: "arbace.a2g.model$jrt_class", Modifiers: 25, Simple: "jrt_class", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jrt_class_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_jrt_sym_A_class, Name: "arbace.a2g.model$jrt_sym", Modifiers: 25, Simple: "jrt_sym", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_jrt_sym_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_leaf_QMARK__A_class, Name: "arbace.a2g.model$leaf_QMARK_", Modifiers: 25, Simple: "leaf_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_leaf_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_make_subclass_index_A_class, Name: "arbace.a2g.model$make_subclass_index", Modifiers: 25, Simple: "make_subclass_index", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class, Name: "arbace.a2g.model$make_subclass_index$fn__1008000057", Modifiers: 25, Simple: "fn__1008000057", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_make_subclass_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class, Name: "arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058", Modifiers: 25, Simple: "fn__1008000058", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class, Name: "arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058$fn__1008000059", Modifiers: 25, Simple: "fn__1008000059", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_mdesc_in_world_QMARK__A_class, Name: "arbace.a2g.model$mdesc_in_world_QMARK_", Modifiers: 25, Simple: "mdesc_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_mdesc_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_member_in_world_QMARK__A_class, Name: "arbace.a2g.model$member_in_world_QMARK_", Modifiers: 25, Simple: "member_in_world_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_member_in_world_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_method_desc_classes_A_class, Name: "arbace.a2g.model$method_desc_classes", Modifiers: 25, Simple: "method_desc_classes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_method_desc_classes_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_methods_of_A_class, Name: "arbace.a2g.model$methods_of", Modifiers: 25, Simple: "methods_of", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_methods_of_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_nest_top_A_class, Name: "arbace.a2g.model$nest_top", Modifiers: 25, Simple: "nest_top", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_nest_top_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_par_mapv_A_class, Name: "arbace.a2g.model$par_mapv", Modifiers: 25, Simple: "par_mapv", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_par_mapv_fn__1008000019_A_class, Name: "arbace.a2g.model$par_mapv$fn__1008000019", Modifiers: 25, Simple: "fn__1008000019", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_fn__1008000019_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class, Name: "arbace.a2g.model$par_mapv$fn__1008000019$fn__1008000020", Modifiers: 25, Simple: "fn__1008000020", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_par_mapv_fn__1008000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_par_mapv_work__1008000017_A_class, Name: "arbace.a2g.model$par_mapv$work__1008000017", Modifiers: 25, Simple: "work__1008000017", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_par_mapv_work__1008000017_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_par_mapv_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pkg_A_class, Name: "arbace.a2g.model$pkg", Modifiers: 25, Simple: "pkg", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pkg_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pointer_desc_QMARK__A_class, Name: "arbace.a2g.model$pointer_desc_QMARK_", Modifiers: 25, Simple: "pointer_desc_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pointer_desc_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_private_QMARK__A_class, Name: "arbace.a2g.model$private_QMARK_", Modifiers: 25, Simple: "private_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_private_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_ctor_QMARK__A_class, Name: "arbace.a2g.model$pure_ctor_QMARK_", Modifiers: 25, Simple: "pure_ctor_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000136_A_class, Name: "arbace.a2g.model$pure_ctor_QMARK_$fn__1008000136", Modifiers: 25, Simple: "fn__1008000136", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000136_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000138_A_class, Name: "arbace.a2g.model$pure_ctor_QMARK_$fn__1008000138", Modifiers: 25, Simple: "fn__1008000138", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000138_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_ctor_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__A_class, Name: "arbace.a2g.model$pure_node_QMARK_", Modifiers: 25, Simple: "pure_node_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000148", Modifiers: 25, Simple: "fn__1008000148", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000151_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000151", Modifiers: 25, Simple: "fn__1008000151", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000151_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000156_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000156", Modifiers: 25, Simple: "fn__1008000156", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000156_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000158_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000158", Modifiers: 25, Simple: "fn__1008000158", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000158_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000160_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000160", Modifiers: 25, Simple: "fn__1008000160", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000160_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000162_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000162", Modifiers: 25, Simple: "fn__1008000162", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000162_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_pure_node_QMARK__fn__1008000164_A_class, Name: "arbace.a2g.model$pure_node_QMARK_$fn__1008000164", Modifiers: 25, Simple: "fn__1008000164", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_pure_node_QMARK__fn__1008000164_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_pure_node_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_qualify_A_class, Name: "arbace.a2g.model$qualify", Modifiers: 25, Simple: "qualify", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_qualify_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_reflectable_interface_QMARK__A_class, Name: "arbace.a2g.model$reflectable_interface_QMARK_", Modifiers: 25, Simple: "reflectable_interface_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflectable_interface_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class, Name: "arbace.a2g.model$reflectable_interface_QMARK_$fn__1008000033", Modifiers: 25, Simple: "fn__1008000033", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_reflectable_interface_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_reflected_QMARK__A_class, Name: "arbace.a2g.model$reflected_QMARK_", Modifiers: 25, Simple: "reflected_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_reflected_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_static_QMARK__A_class, Name: "arbace.a2g.model$static_QMARK_", Modifiers: 25, Simple: "static_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_static_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_subclasses_A_class, Name: "arbace.a2g.model$subclasses", Modifiers: 25, Simple: "subclasses", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_subclasses_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_superclass_chain_A_class, Name: "arbace.a2g.model$superclass_chain", Modifiers: 25, Simple: "superclass_chain", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_superclass_chain_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class, Name: "arbace.a2g.model$superclass_chain$fn__1008000104", Modifiers: 25, Simple: "fn__1008000104", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_superclass_chain_fn__1008000104_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_superclass_chain_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_supertypes_A_class, Name: "arbace.a2g.model$supertypes", Modifiers: 25, Simple: "supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_supertypes_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_top_class_A_class, Name: "arbace.a2g.model$top_class", Modifiers: 25, Simple: "top_class", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_top_class_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_translatable_QMARK__A_class, Name: "arbace.a2g.model$translatable_QMARK_", Modifiers: 25, Simple: "translatable_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_translatable_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_translated_QMARK__A_class, Name: "arbace.a2g.model$translated_QMARK_", Modifiers: 25, Simple: "translated_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_translated_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_trivial_init_QMARK__A_class, Name: "arbace.a2g.model$trivial_init_QMARK_", Modifiers: 25, Simple: "trivial_init_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_trivial_init_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_virtual_member_QMARK__A_class, Name: "arbace.a2g.model$virtual_member_QMARK_", Modifiers: 25, Simple: "virtual_member_QMARK_", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_virtual_member_QMARK__A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_vmethods_A_class, Name: "arbace.a2g.model$vmethods", Modifiers: 25, Simple: "vmethods", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_vmethods_fn__1008000098_A_class, Name: "arbace.a2g.model$vmethods$fn__1008000098", Modifiers: 25, Simple: "fn__1008000098", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_fn__1008000098_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_vmethods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class, Name: "arbace.a2g.model$vmethods$fn__1008000098$fn__1008000099", Modifiers: 25, Simple: "fn__1008000099", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_vmethods_fn__1008000098_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_model_world_supertypes_A_class, Name: "arbace.a2g.model$world_supertypes", Modifiers: 25, Simple: "world_supertypes", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_world_supertypes_A", Source: "model.ae", Declaring: &A_arbace_a2g_model_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_a2g_model_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_A_New()}; return nil }

var A_arbace_a2g_model_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_A_new}

var A_arbace_a2g_model_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_A"})

func init() { i := A_arbace_a2g_model_A_class.Info(); i.IsInstance = A_arbace_a2g_model_A_InstanceOf; i.Init = A_arbace_a2g_model_A_Init; i.Table = A_arbace_a2g_model_A_members }

var A_arbace_a2g_model_T_A_class *jrt.Class

var A_arbace_a2g_model_a2g_method_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_a2g_static_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_abstract_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_abstract_m_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_all_supertypes_A_class *jrt.Class

var A_arbace_a2g_model_benign_init_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_benign_init_QMARK__fn__1008000168_A_class *jrt.Class

var A_arbace_a2g_model_class_sym_A_class *jrt.Class

var A_arbace_a2g_model_code_class_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_code_iface_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_A_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class *jrt.Class

var A_arbace_a2g_model_desc_classes_A_class *jrt.Class

var A_arbace_a2g_model_desc_in_world_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class *jrt.Class

func A_arbace_a2g_model_eval1008000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000004_A_New()}; return nil }

var A_arbace_a2g_model_eval1008000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_eval1008000004_A_new}

var A_arbace_a2g_model_eval1008000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_model_A_class, Simple: "eval1008000004", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000004_A"})

func init() { i := A_arbace_a2g_model_eval1008000004_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000004_A_InstanceOf; i.Table = A_arbace_a2g_model_eval1008000004_A_members }

var A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class *jrt.Class

func A_arbace_a2g_model_eval1008000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model_eval1008000008_A_New()}; return nil }

var A_arbace_a2g_model_eval1008000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_model_eval1008000008_A_new}

var A_arbace_a2g_model_eval1008000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model$eval1008000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_model_A_class, Simple: "eval1008000008", Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model_eval1008000008_A"})

func init() { i := A_arbace_a2g_model_eval1008000008_A_class.Info(); i.IsInstance = A_arbace_a2g_model_eval1008000008_A_InstanceOf; i.Table = A_arbace_a2g_model_eval1008000008_A_members }

var A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class *jrt.Class

var A_arbace_a2g_model_fields_of_A_class *jrt.Class

var A_arbace_a2g_model_final_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_find_method_A_class *jrt.Class

var A_arbace_a2g_model_find_method_fn__1008000077_A_class *jrt.Class

var A_arbace_a2g_model_go_name_A_class *jrt.Class

var A_arbace_a2g_model_go_type_A_class *jrt.Class

var A_arbace_a2g_model_hand_written_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_has_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_hw_method_exists_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_iface_desc_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_impl_of_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000112_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000124_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class *jrt.Class

var A_arbace_a2g_model_in_world_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_info_A_class *jrt.Class

var A_arbace_a2g_model_interface_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_jobs_A_class *jrt.Class

var A_arbace_a2g_model_jrt_class_A_class *jrt.Class

var A_arbace_a2g_model_jrt_sym_A_class *jrt.Class

var A_arbace_a2g_model_leaf_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_A_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class *jrt.Class

var A_arbace_a2g_model_mdesc_in_world_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_member_in_world_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_method_desc_classes_A_class *jrt.Class

var A_arbace_a2g_model_methods_of_A_class *jrt.Class

var A_arbace_a2g_model_nest_top_A_class *jrt.Class

var A_arbace_a2g_model_par_mapv_A_class *jrt.Class

var A_arbace_a2g_model_par_mapv_fn__1008000019_A_class *jrt.Class

var A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class *jrt.Class

var A_arbace_a2g_model_par_mapv_work__1008000017_A_class *jrt.Class

var A_arbace_a2g_model_pkg_A_class *jrt.Class

var A_arbace_a2g_model_pointer_desc_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_private_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000136_A_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000138_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000151_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000156_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000158_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000160_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000162_A_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000164_A_class *jrt.Class

var A_arbace_a2g_model_qualify_A_class *jrt.Class

var A_arbace_a2g_model_reflectable_interface_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class *jrt.Class

var A_arbace_a2g_model_reflected_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_static_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_subclasses_A_class *jrt.Class

var A_arbace_a2g_model_superclass_chain_A_class *jrt.Class

var A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class *jrt.Class

var A_arbace_a2g_model_supertypes_A_class *jrt.Class

var A_arbace_a2g_model_top_class_A_class *jrt.Class

var A_arbace_a2g_model_translatable_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_translated_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_trivial_init_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_virtual_member_QMARK__A_class *jrt.Class

var A_arbace_a2g_model_vmethods_A_class *jrt.Class

var A_arbace_a2g_model_vmethods_fn__1008000098_A_class *jrt.Class

var A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class *jrt.Class

var A_arbace_a2g_model_world_supertypes_A_class *jrt.Class

func A_arbace_a2g_model__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_model__init_A_Load__O()}; return nil }

func A_arbace_a2g_model__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_model__init_A_New()}; return nil }

var A_arbace_a2g_model__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_model__init_A_invoke, New: A_arbace_a2g_model__init_A_new}

var A_arbace_a2g_model__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.model__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_model.A_arbace_a2g_model__init_A", Source: "model.ae"})

func init() { i := A_arbace_a2g_model__init_A_class.Info(); i.IsInstance = A_arbace_a2g_model__init_A_InstanceOf; i.Init = A_arbace_a2g_model__init_A_Init; i.Table = A_arbace_a2g_model__init_A_members }
