//line a2g_strings.ae:1
package aot_arbace_a2g_model

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_13 *jrt.String = jrt.Intern("nm")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_15 *jrt.String = jrt.Intern("jrt")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_17 *jrt.String = jrt.Intern("Opcodes")

var Lit_18 *jrt.String = jrt.Intern("commute")

var Lit_19 *jrt.String = jrt.Intern("deref")

var Lit_20 *jrt.String = jrt.Intern("conj")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_22 *jrt.String = jrt.Intern("doc")

var Lit_23 *jrt.String = jrt.Intern("The closed world of one a2g run (A2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).")

var Lit_24 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_25 *jrt.String = jrt.Intern("seq")

var Lit_26 *jrt.String = jrt.Intern("default-jobs")

var Lit_27 *jrt.String = jrt.Intern("vec")

var Lit_28 *jrt.String = jrt.Intern("mapv")

var Lit_29 *jrt.String = jrt.Intern("atom")

var Lit_30 *jrt.String = jrt.Intern("swap!")

var Lit_31 *jrt.String = jrt.Intern("inc")

var Lit_32 *jrt.String = jrt.Intern("doall")

var Lit_33 *jrt.String = jrt.Intern("range")

var Lit_34 *jrt.String = jrt.Intern("repeatedly")

var Lit_35 *jrt.String = jrt.Intern("future-call")

var Lit_36 *jrt.String = jrt.Intern("run!")

var Lit_37 *jrt.String = jrt.Intern("not")

var Lit_38 *jrt.String = jrt.Intern("T")

var Lit_39 *jrt.String = jrt.Intern("*w*")

var Lit_40 *jrt.String = jrt.Intern("contains?")

var Lit_41 *jrt.String = jrt.Intern("translated?")

var Lit_42 *jrt.String = jrt.Intern("jrt-classes")

var Lit_43 *jrt.String = jrt.Intern("jrt-class")

var Lit_44 *jrt.String = jrt.Intern("decl")

var Lit_45 *jrt.String = jrt.Intern("starts-with?")

var Lit_46 *jrt.String = jrt.Intern("some?")

var Lit_47 *jrt.String = jrt.Intern("interface?")

var Lit_48 *jrt.String = jrt.Intern("empty?")

var Lit_49 *jrt.String = jrt.Intern("every?")

var Lit_50 *jrt.String = jrt.Intern("includes?")

var Lit_51 *jrt.String = jrt.Intern("info")

var Lit_52 *jrt.String = jrt.Intern("has?")

var Lit_53 *jrt.String = jrt.Intern("flags")

var Lit_54 *jrt.String = jrt.Intern("methods")

var Lit_55 *jrt.String = jrt.Intern("in-world?")

var Lit_56 *jrt.String = jrt.Intern("reflectable-interface?")

var Lit_57 *jrt.String = jrt.Intern("interfaces")

var Lit_58 *jrt.String = jrt.Intern("keyword?")

var Lit_59 *jrt.String = jrt.Intern("array?")

var Lit_60 *jrt.String = jrt.Intern("desc-classes")

var Lit_61 *jrt.String = jrt.Intern("class-desc?")

var Lit_62 *jrt.String = jrt.Intern("else")

var Lit_63 *jrt.String = jrt.Intern("subs")

var Lit_64 *jrt.String = jrt.Intern("array-dims")

var Lit_65 *jrt.String = jrt.Intern("desc->internal")

var Lit_66 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_67 *jrt.String = jrt.Intern("mapcat")

var Lit_68 *jrt.String = jrt.Intern("cons")

var Lit_69 *jrt.String = jrt.Intern("string?")

var Lit_70 *jrt.String = jrt.Intern("elem-type")

var Lit_71 *jrt.String = jrt.Intern("some")

var Lit_72 *jrt.String = jrt.Intern("erased")

var Lit_73 *jrt.String = jrt.Intern("method-desc-classes")

var Lit_74 *jrt.String = jrt.Intern("go")

var Lit_75 *jrt.String = jrt.Intern("go-class-name")

var Lit_76 *jrt.String = jrt.Intern("pkg-of")

var Lit_77 *jrt.String = jrt.Intern("subclass-index")

var Lit_78 *jrt.String = jrt.Intern("reset!")

var Lit_79 *jrt.String = jrt.Intern("reduce")

var Lit_80 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_81 *jrt.String = jrt.Intern("super")

var Lit_82 *jrt.String = jrt.Intern("update")

var Lit_83 *jrt.String = jrt.Intern("fnil")

var Lit_84 *jrt.String = jrt.Intern("concat")

var Lit_85 *jrt.String = jrt.Intern("keys")

var Lit_86 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_87 *jrt.String = jrt.Intern("hash-map")

var Lit_88 *jrt.String = jrt.Intern("hand-written?")

var Lit_89 *jrt.String = jrt.Intern("types")

var Lit_90 *jrt.String = jrt.Intern("go-name")

var Lit_91 *jrt.String = jrt.Intern("abstract?")

var Lit_92 *jrt.String = jrt.Intern("subclasses")

var Lit_93 *jrt.String = jrt.Intern("proxy-super?")

var Lit_94 *jrt.String = jrt.Intern("final?")

var Lit_95 *jrt.String = jrt.Intern("symbol")

var Lit_96 *jrt.String = jrt.Intern("pkg-name")

var Lit_97 *jrt.String = jrt.Intern("qualify")

var Lit_98 *jrt.String = jrt.Intern("pkg")

var Lit_99 *jrt.String = jrt.Intern("class-sym")

var Lit_100 *jrt.String = jrt.Intern("null")

var Lit_101 *jrt.String = jrt.Intern("any")

var Lit_102 *jrt.String = jrt.Intern("prim-go")

var Lit_103 *jrt.String = jrt.Intern("prim?")

var Lit_104 *jrt.String = jrt.Intern("list")

var Lit_105 *jrt.String = jrt.Intern("leaf?")

var Lit_106 *jrt.String = jrt.Intern("ex-info")

var Lit_107 *jrt.String = jrt.Intern("*")

var Lit_108 *jrt.String = jrt.Intern("jrt-sym")

var Lit_109 *jrt.String = jrt.Intern("prim-array-go")

var Lit_110 *jrt.String = jrt.Intern("pr-str")

var Lit_111 *jrt.String = jrt.Intern("desc")

var Lit_112 *jrt.String = jrt.Intern("not=")

var Lit_113 *jrt.String = jrt.Intern("ref?")

var Lit_114 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_115 *jrt.String = jrt.Intern("fields")

var Lit_116 *jrt.String = jrt.Intern("name")

var Lit_117 *jrt.String = jrt.Intern("methods-of")

var Lit_118 *jrt.String = jrt.Intern("static?")

var Lit_119 *jrt.String = jrt.Intern("private?")

var Lit_120 *jrt.String = jrt.Intern("remove")

var Lit_121 *jrt.String = jrt.Intern("nil?")

var Lit_122 *jrt.String = jrt.Intern("filter")

var Lit_123 *jrt.String = jrt.Intern("supertypes")

var Lit_124 *jrt.String = jrt.Intern("all-supertypes")

var Lit_125 *jrt.String = jrt.Intern("method-base")

var Lit_126 *jrt.String = jrt.Intern("struct-methods")

var Lit_127 *jrt.String = jrt.Intern("a2g-method?")

var Lit_128 *jrt.String = jrt.Intern("object-keys")

var Lit_129 *jrt.String = jrt.Intern("iface-methods")

var Lit_130 *jrt.String = jrt.Intern("funcs")

var Lit_131 *jrt.String = jrt.Intern("impl-name")

var Lit_132 *jrt.String = jrt.Intern("Chars__IntStream")

var Lit_133 *jrt.String = jrt.Intern("CodePoints__IntStream")

var Lit_134 *jrt.String = jrt.Intern("mdesc-in-world?")

var Lit_135 *jrt.String = jrt.Intern("hw-method-exists?")

var Lit_136 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_137 *jrt.String = jrt.Intern("chunk-first")

var Lit_138 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_139 *jrt.String = jrt.Intern("virtual-member?")

var Lit_140 *jrt.String = jrt.Intern("member-in-world?")

var Lit_141 *jrt.String = jrt.Intern("chunk-append")

var Lit_142 *jrt.String = jrt.Intern("assoc")

var Lit_143 *jrt.String = jrt.Intern("owner")

var Lit_144 *jrt.String = jrt.Intern("chunk-cons")

var Lit_145 *jrt.String = jrt.Intern("first")

var Lit_146 *jrt.String = jrt.Intern("chunk")

var Lit_147 *jrt.String = jrt.Intern("chunk-rest")

var Lit_148 *jrt.String = jrt.Intern("rest")

var Lit_149 *jrt.String = jrt.Intern("vmethods-cache")

var Lit_150 *jrt.String = jrt.Intern("declared-vmethods")

var Lit_151 *jrt.String = jrt.Intern("array-map")

var Lit_152 *jrt.String = jrt.Intern("take-while")

var Lit_153 *jrt.String = jrt.Intern("iterate")

var Lit_154 *jrt.String = jrt.Intern("find-method")

var Lit_155 *jrt.String = jrt.Intern("abstract-m?")

var Lit_156 *jrt.String = jrt.Intern("kind")

var Lit_157 *jrt.String = jrt.Intern("default")

var Lit_158 *jrt.String = jrt.Intern("method")

var Lit_159 *jrt.String = jrt.Intern("object")

var Lit_160 *jrt.String = jrt.Intern("jrt-impl")

var Lit_161 *jrt.String = jrt.Intern("promoted")

var Lit_162 *jrt.String = jrt.Intern("class")

var Lit_163 *jrt.String = jrt.Intern("superclass-chain")

var Lit_164 *jrt.String = jrt.Intern("subclass?")

var Lit_165 *jrt.String = jrt.Intern("trivial-cache")

var Lit_166 *jrt.String = jrt.Intern("trivial-init?")

var Lit_167 *jrt.String = jrt.Intern("state")

var Lit_168 *jrt.String = jrt.Intern("clinit")

var Lit_169 *jrt.String = jrt.Intern("clj-consts")

var Lit_170 *jrt.String = jrt.Intern("uses-assert")

var Lit_171 *jrt.String = jrt.Intern("interface-assert")

var Lit_172 *jrt.String = jrt.Intern("bodies")

var Lit_173 *jrt.String = jrt.Intern("top-class")

var Lit_174 *jrt.String = jrt.Intern("call")

var Lit_175 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_176 *jrt.String = jrt.Intern("java/lang/Enum")

var Lit_177 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_178 *jrt.String = jrt.Intern("pure-ctor?")

var Lit_179 *jrt.String = jrt.Intern("body")

var Lit_180 *jrt.String = jrt.Intern("pure-node?")

var Lit_181 *jrt.String = jrt.Intern("prologue")

var Lit_182 *jrt.String = jrt.Intern("nested-call")

var Lit_183 *jrt.String = jrt.Intern("args")

var Lit_184 *jrt.String = jrt.Intern("ctor")

var Lit_185 *jrt.String = jrt.Intern("init")

var Lit_186 *jrt.String = jrt.Intern("op")

var Lit_187 *jrt.String = jrt.Intern("convert")

var Lit_188 *jrt.String = jrt.Intern("set-field")

var Lit_189 *jrt.String = jrt.Intern("this-path")

var Lit_190 *jrt.String = jrt.Intern("target")

var Lit_191 *jrt.String = jrt.Intern("invoke")

var Lit_192 *jrt.String = jrt.Intern("static")

var Lit_193 *jrt.String = jrt.Intern("set-static")

var Lit_194 *jrt.String = jrt.Intern("declarer")

var Lit_195 *jrt.String = jrt.Intern("field")

var Lit_196 *jrt.String = jrt.Intern("from")

var Lit_197 *jrt.String = jrt.Intern("to")

var Lit_198 *jrt.String = jrt.Intern("expr")

var Lit_199 *jrt.String = jrt.Intern("path")

var Lit_200 *jrt.String = jrt.Intern("val")

var Lit_201 *jrt.String = jrt.Intern("let")

var Lit_202 *jrt.String = jrt.Intern("get-static")

var Lit_203 *jrt.String = jrt.Intern("bindings")

var Lit_204 *jrt.String = jrt.Intern("do")

var Lit_205 *jrt.String = jrt.Intern("const")

var Lit_206 *jrt.String = jrt.Intern("statements")

var Lit_207 *jrt.String = jrt.Intern("ret")

var Lit_208 *jrt.String = jrt.Intern("local")

var Lit_209 *jrt.String = jrt.Intern("new-array")

var Lit_210 *jrt.String = jrt.Intern("new")

var Lit_211 *jrt.String = jrt.Intern("outer")

var Lit_212 *jrt.String = jrt.Intern("number?")

var Lit_213 *jrt.String = jrt.Intern("dims")

var Lit_214 *jrt.String = jrt.Intern("arith")

var Lit_215 *jrt.String = jrt.Intern("class-lit")

var Lit_216 *jrt.String = jrt.Intern("rem")

var Lit_217 *jrt.String = jrt.Intern("div")

var Lit_218 *jrt.String = jrt.Intern("o")

var Lit_219 *jrt.String = jrt.Intern("exact")

var Lit_220 *jrt.String = jrt.Intern("family")

var Lit_221 *jrt.String = jrt.Intern("array-init")

var Lit_222 *jrt.String = jrt.Intern("elems")

var Lit_223 *jrt.String = jrt.Intern("benign-init?")

var Lit_224 *jrt.String = jrt.Intern("benign")

var Lit_225 *jrt.String = jrt.Intern("arbace.a2g.model$T")

var Lit_226 *jrt.String = jrt.Intern("arbace.a2g.model$a2g_method_QMARK_")

var Lit_227 *jrt.String = jrt.Intern("java/lang/String")

var Lit_228 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_229 *jrt.String = jrt.Intern("java/util/stream/IntStream")

var Lit_230 *jrt.String = jrt.Intern("arbace.a2g.model$a2g_static_QMARK_")

var Lit_231 *jrt.String = jrt.Intern("java/lang/System")

var Lit_232 *jrt.String = jrt.Intern("GetProperties__Properties")

var Lit_233 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_234 *jrt.String = jrt.Intern("arbace.a2g.model$abstract_QMARK_")

var Lit_235 *jrt.String = jrt.Intern("arbace.a2g.model$abstract_m_QMARK_")

var Lit_236 *jrt.String = jrt.Intern("arbace.a2g.model$all_supertypes")

var Lit_237 *jrt.String = jrt.Intern("arbace.a2g.model$benign_init_QMARK_")

var Lit_238 *jrt.String = jrt.Intern("arbace.a2g.model$benign_init_QMARK_$fn__1008000165")

var Lit_239 *jrt.String = jrt.Intern("arbace.a2g.model$class_sym")

var Lit_240 *jrt.String = jrt.Intern("")

var Lit_241 *jrt.String = jrt.Intern("arbace.a2g.model$declared_vmethods")

var Lit_242 *jrt.String = jrt.Intern("arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091")

var Lit_243 *jrt.String = jrt.Intern("arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092")

var Lit_244 *jrt.String = jrt.Intern("arbace.a2g.model$declared_vmethods$iter__1008000087__1008000091$fn__1008000092$fn__1008000093")

var Lit_245 *jrt.String = jrt.Intern("arbace.a2g.model$desc_classes")

var Lit_246 *jrt.String = jrt.Intern("arbace.a2g.model$desc_in_world_QMARK_")

var Lit_247 *jrt.String = jrt.Intern("arbace.a2g.model$erased_desc_QMARK_")

var Lit_248 *jrt.String = jrt.Intern("arbace.a2g.model$erased_desc_QMARK_$fn__1008000045")

var Lit_249 *jrt.String = jrt.Intern("arbace.a2g.model$erased_desc_QMARK_$fn__1008000047")

var Lit_250 *jrt.String = jrt.Intern("arbace.a2g.model$eval1008000004$loading__1927001464__auto____1008000005")

var Lit_251 *jrt.String = jrt.Intern("arbace.a2g.model$eval1008000008$fn__1008000009")

var Lit_252 *jrt.String = jrt.Intern("arbace.a2g.model$fields_of")

var Lit_253 *jrt.String = jrt.Intern("arbace.a2g.model$final_QMARK_")

var Lit_254 *jrt.String = jrt.Intern("arbace.a2g.model$find_method")

var Lit_255 *jrt.String = jrt.Intern("arbace.a2g.model$find_method$fn__1008000077")

var Lit_256 *jrt.String = jrt.Intern("arbace.a2g.model$go_name")

var Lit_257 *jrt.String = jrt.Intern("arbace.a2g.model$go_type")

var Lit_258 *jrt.String = jrt.Intern("V")

var Lit_259 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_260 *jrt.String = jrt.Intern("RefArray")

var Lit_261 *jrt.String = jrt.Intern("_I")

var Lit_262 *jrt.String = jrt.Intern("a2g: no Go type for ")

var Lit_263 *jrt.String = jrt.Intern("arbace.a2g.model$hand_written_QMARK_")

var Lit_264 *jrt.String = jrt.Intern("arbace.a2g.model$has_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.a2g.model$hw_method_exists_QMARK_")

var Lit_266 *jrt.String = jrt.Intern("_")

var Lit_267 *jrt.String = jrt.Intern("arbace.a2g.model$iface_desc_QMARK_")

var Lit_268 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of")

var Lit_269 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$fn__1008000112")

var Lit_270 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$fn__1008000124")

var Lit_271 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$fn__1008000124$fn__1008000125")

var Lit_272 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$iter__1008000114__1008000118")

var Lit_273 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119")

var Lit_274 *jrt.String = jrt.Intern("arbace.a2g.model$impl_of$iter__1008000114__1008000118$fn__1008000119$fn__1008000120")

var Lit_275 *jrt.String = jrt.Intern("arbace.a2g.model$in_world_QMARK_")

var Lit_276 *jrt.String = jrt.Intern("arbace.a2g.model$info")

var Lit_277 *jrt.String = jrt.Intern("arbace.a2g.model$interface_QMARK_")

var Lit_278 *jrt.String = jrt.Intern("arbace.a2g.model$jobs")

var Lit_279 *jrt.String = jrt.Intern("A2G_JOBS")

var Lit_280 *jrt.String = jrt.Intern("arbace.a2g.model$jrt_class")

var Lit_281 *jrt.String = jrt.Intern("arbace.a2g.model$jrt_sym")

var Lit_282 *jrt.String = jrt.Intern("arbace.a2g.model$leaf_QMARK_")

var Lit_283 *jrt.String = jrt.Intern("arbace.a2g.model$make_subclass_index")

var Lit_284 *jrt.String = jrt.Intern("arbace.a2g.model$make_subclass_index$fn__1008000057")

var Lit_285 *jrt.String = jrt.Intern("arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058")

var Lit_286 *jrt.String = jrt.Intern("arbace.a2g.model$make_subclass_index$fn__1008000057$fn__1008000058$fn__1008000059")

var Lit_287 *jrt.String = jrt.Intern("arbace.a2g.model$mdesc_in_world_QMARK_")

var Lit_288 *jrt.String = jrt.Intern("arbace.a2g.model$member_in_world_QMARK_")

var Lit_289 *jrt.String = jrt.Intern("arbace.a2g.model$method_desc_classes")

var Lit_290 *jrt.String = jrt.Intern("arbace.a2g.model$methods_of")

var Lit_291 *jrt.String = jrt.Intern("arbace.a2g.model$par_mapv")

var Lit_292 *jrt.String = jrt.Intern("arbace.a2g.model$par_mapv$fn__1008000019")

var Lit_293 *jrt.String = jrt.Intern("arbace.a2g.model$par_mapv$fn__1008000019$fn__1008000020")

var Lit_294 *jrt.String = jrt.Intern("arbace.a2g.model$par_mapv$work__1008000017")

var Lit_295 *jrt.String = jrt.Intern("arbace.a2g.model$pkg")

var Lit_296 *jrt.String = jrt.Intern("arbace.a2g.model$pointer_desc_QMARK_")

var Lit_297 *jrt.String = jrt.Intern("arbace.a2g.model$private_QMARK_")

var Lit_298 *jrt.String = jrt.Intern("arbace.a2g.model$pure_ctor_QMARK_")

var Lit_299 *jrt.String = jrt.Intern("<init>")

var Lit_300 *jrt.String = jrt.Intern("arbace.a2g.model$pure_ctor_QMARK_$fn__1008000133")

var Lit_301 *jrt.String = jrt.Intern("arbace.a2g.model$pure_ctor_QMARK_$fn__1008000135")

var Lit_302 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_")

var Lit_303 *jrt.String = jrt.Intern("java/lang/Class")

var Lit_304 *jrt.String = jrt.Intern("getPrimitiveClass")

var Lit_305 *jrt.String = jrt.Intern("$values")

var Lit_306 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000145")

var Lit_307 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000148")

var Lit_308 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000153")

var Lit_309 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000155")

var Lit_310 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000157")

var Lit_311 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000159")

var Lit_312 *jrt.String = jrt.Intern("arbace.a2g.model$pure_node_QMARK_$fn__1008000161")

var Lit_313 *jrt.String = jrt.Intern("arbace.a2g.model$qualify")

var Lit_314 *jrt.String = jrt.Intern("arbace.a2g.model$reflectable_interface_QMARK_")

var Lit_315 *jrt.String = jrt.Intern("java/")

var Lit_316 *jrt.String = jrt.Intern("javax/")

var Lit_317 *jrt.String = jrt.Intern("jdk/")

var Lit_318 *jrt.String = jrt.Intern("sun/")

var Lit_319 *jrt.String = jrt.Intern("com/sun/")

var Lit_320 *jrt.String = jrt.Intern("$$")

var Lit_321 *jrt.String = jrt.Intern("arbace.a2g.model$reflectable_interface_QMARK_$fn__1008000033")

var Lit_322 *jrt.String = jrt.Intern("arbace.a2g.model$reflected_QMARK_")

var Lit_323 *jrt.String = jrt.Intern("arbace.a2g.model$static_QMARK_")

var Lit_324 *jrt.String = jrt.Intern("arbace.a2g.model$subclasses")

var Lit_325 *jrt.String = jrt.Intern("arbace.a2g.model$superclass_chain")

var Lit_326 *jrt.String = jrt.Intern("arbace.a2g.model$superclass_chain$fn__1008000104")

var Lit_327 *jrt.String = jrt.Intern("arbace.a2g.model$supertypes")

var Lit_328 *jrt.String = jrt.Intern("arbace.a2g.model$top_class")

var Lit_329 *jrt.String = jrt.Intern("$")

var Lit_330 *jrt.String = jrt.Intern("arbace.a2g.model$translatable_QMARK_")

var Lit_331 *jrt.String = jrt.Intern("arbace.a2g.model$translated_QMARK_")

var Lit_332 *jrt.String = jrt.Intern("arbace.a2g.model$trivial_init_QMARK_")

var Lit_333 *jrt.String = jrt.Intern("arbace.a2g.model$virtual_member_QMARK_")

var Lit_334 *jrt.String = jrt.Intern("<clinit>")

var Lit_335 *jrt.String = jrt.Intern("arbace.a2g.model$vmethods")

var Lit_336 *jrt.String = jrt.Intern("arbace.a2g.model$vmethods$fn__1008000098")

var Lit_337 *jrt.String = jrt.Intern("arbace.a2g.model$vmethods$fn__1008000098$fn__1008000099")

var Lit_338 *jrt.String = jrt.Intern("arbace.a2g.model$world_supertypes")

var Lit_339 *jrt.String = jrt.Intern("in-ns")

var Lit_340 *jrt.String = jrt.Intern("dynamic")

var Lit_341 *jrt.String = jrt.Intern("line")

var Lit_342 *jrt.String = jrt.Intern("column")

var Lit_343 *jrt.String = jrt.Intern("file")

var Lit_344 *jrt.String = jrt.Intern("arbace/a2g/model.ae")

var Lit_345 *jrt.String = jrt.Intern("The world: {:jrt scan :T atom-or-set :jrt-classes {internal {:go :var :standin :file}}}.")

var Lit_346 *jrt.String = jrt.Intern("At most this many threads by default: on Go, 16 take 10 GB at most for the program, 64 take\n  12 GB (GOMEMLIMIT 12GiB) for 5% less time (doc/STANDALONE-NOTES.md, S4, amendment SA51).")

var Lit_347 *jrt.String = jrt.Intern("jobs")

var Lit_348 *jrt.String = jrt.Intern("arglists")

var Lit_349 *jrt.String = jrt.Intern("How many threads translate and write: A2G_JOBS, else the number of processors, at most\n  default-jobs.")

var Lit_350 *jrt.String = jrt.Intern("par-mapv")

var Lit_351 *jrt.String = jrt.Intern("n")

var Lit_352 *jrt.String = jrt.Intern("f")

var Lit_353 *jrt.String = jrt.Intern("xs")

var Lit_354 *jrt.String = jrt.Intern("&")

var Lit_355 *jrt.String = jrt.Intern("order")

var Lit_356 *jrt.String = jrt.Intern("(mapv f xs), f applied on up to n threads, each taking the next element (in xs' order, or\n  in the order of the indices `order`: the longest first); the results in xs' order. f's\n  dynamic bindings are the caller's (future's conveyance).")

var Lit_357 *jrt.String = jrt.Intern("a2g-static?")

var Lit_358 *jrt.String = jrt.Intern("cls")

var Lit_359 *jrt.String = jrt.Intern("base")

var Lit_360 *jrt.String = jrt.Intern("A static method of jrt's hand-written class cls (Go base name base) that a2g writes itself,\n  in the program's support code, because its type is a translated class jrt cannot name:\n  System.getProperties(), a Properties (out.ae; JRT-NOTES.md, \"Text and locales\":\n  StaticProperty reads it).")

var Lit_361 *jrt.String = jrt.Intern("jrt's hand-written (or stand-in) class n, when jrt defines it: {:go :var :standin :file}.")

var Lit_362 *jrt.String = jrt.Intern("Is n a class jrt provides and a2g does not translate in this world?")

var Lit_363 *jrt.String = jrt.Intern("translatable?")

var Lit_364 *jrt.String = jrt.Intern("Is n in the class environment as class forms (a2g can translate it)?")

var Lit_365 *jrt.String = jrt.Intern("Is n a JDK interface a2g knows only by reflection (no class forms: outside the converted\n  closure), which it may declare: its methods, no code (A2G-NOTES.md, \"Reflected\n  interfaces\")?")

var Lit_366 *jrt.String = jrt.Intern("reflected?")

var Lit_367 *jrt.String = jrt.Intern("Is n a translated class declared from reflection (no class forms)?")

var Lit_368 *jrt.String = jrt.Intern("d")

var Lit_369 *jrt.String = jrt.Intern("The classes a descriptor mentions (array element classes included).")

var Lit_370 *jrt.String = jrt.Intern("erased-desc?")

var Lit_371 *jrt.String = jrt.Intern("Is d a class outside the world in a package a variant erases (a2g/erase), or an array of\n  one? Values of such types exist only to feed what the Go build cuts (the bytecode back end):\n  an operation producing one is the zero value (proposed amendment B2).")

var Lit_372 *jrt.String = jrt.Intern("desc-in-world?")

var Lit_373 *jrt.String = jrt.Intern("The Go type name of class n: jrt's own name for a class jrt provides and a2g does not\n  translate (a jrt class may register a JDK name under another Go name: ReentrantLock's\n  condition is AbstractQueuedSynchronizer$ConditionObject), else the name derived from n.")

var Lit_374 *jrt.String = jrt.Intern("Direct subclasses of class n in the world (memoized per world).")

var Lit_375 *jrt.String = jrt.Intern("make-subclass-index")

var Lit_376 *jrt.String = jrt.Intern("w")

var Lit_377 *jrt.String = jrt.Intern("proxy-supers")

var Lit_378 *jrt.String = jrt.Intern("The classes besides Object that a proxy may extend in the Go build (§5.12, arbace.a2g.dyn):\n  each gets a Go type DynSub_C, a subclass of C in the world, so a translated class of the list\n  is not a leaf (§5.3).")

var Lit_379 *jrt.String = jrt.Intern("set")

var Lit_380 *jrt.String = jrt.Intern("private")

var Lit_381 *jrt.String = jrt.Intern("Is class n a leaf (§5.3): its values are *C pointers. Interfaces are not; jrt's classes are\n  leaves when jrt gives them no class interface C_I; a translated class of proxy-supers is not\n  (its DynSub_C extends it).")

var Lit_382 *jrt.String = jrt.Intern("of")

var Lit_383 *jrt.String = jrt.Intern("ident")

var Lit_384 *jrt.String = jrt.Intern("A Go identifier of package `of` (:jrt or :lang) as referred to from package `from`.")

var Lit_385 *jrt.String = jrt.Intern("suffix")

var Lit_386 *jrt.String = jrt.Intern("The Go identifier `suffix` of class n (\"\" for the type itself), as referred to from `from`.")

var Lit_387 *jrt.String = jrt.Intern("Z")

var Lit_388 *jrt.String = jrt.Intern("bool")

var Lit_389 *jrt.String = jrt.Intern("B")

var Lit_390 *jrt.String = jrt.Intern("int8")

var Lit_391 *jrt.String = jrt.Intern("C")

var Lit_392 *jrt.String = jrt.Intern("uint16")

var Lit_393 *jrt.String = jrt.Intern("S")

var Lit_394 *jrt.String = jrt.Intern("int16")

var Lit_395 *jrt.String = jrt.Intern("I")

var Lit_396 *jrt.String = jrt.Intern("int32")

var Lit_397 *jrt.String = jrt.Intern("J")

var Lit_398 *jrt.String = jrt.Intern("int64")

var Lit_399 *jrt.String = jrt.Intern("F")

var Lit_400 *jrt.String = jrt.Intern("float32")

var Lit_401 *jrt.String = jrt.Intern("D")

var Lit_402 *jrt.String = jrt.Intern("float64")

var Lit_403 *jrt.String = jrt.Intern("go-type")

var Lit_404 *jrt.String = jrt.Intern("The Go type form of descriptor d in package `from` (§5.1).")

var Lit_405 *jrt.String = jrt.Intern("Is the Go type of d a pointer (leaf class, String, array)?")

var Lit_406 *jrt.String = jrt.Intern("iface-desc?")

var Lit_407 *jrt.String = jrt.Intern("Is the Go type of d an interface (any, C_I, J)?")

var Lit_408 *jrt.String = jrt.Intern("m")

var Lit_409 *jrt.String = jrt.Intern("fields-of")

var Lit_410 *jrt.String = jrt.Intern("A method that takes part in dispatch: an instance method, not private, not a constructor.")

var Lit_411 *jrt.String = jrt.Intern("getClass")

var Lit_412 *jrt.String = jrt.Intern("()Ljava/lang/Class;")

var Lit_413 *jrt.String = jrt.Intern("toString")

var Lit_414 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_415 *jrt.String = jrt.Intern("clone")

var Lit_416 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_417 *jrt.String = jrt.Intern("equals")

var Lit_418 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_419 *jrt.String = jrt.Intern("hashCode")

var Lit_420 *jrt.String = jrt.Intern("()I")

var Lit_421 *jrt.String = jrt.Intern("Object's methods every class has through jrt.Object_I (§5.8).")

var Lit_422 *jrt.String = jrt.Intern("world-supertypes")

var Lit_423 *jrt.String = jrt.Intern("n's supertypes that exist in the world (interfaces that do not are left out, §4.1).")

var Lit_424 *jrt.String = jrt.Intern("n and its supertypes that exist in the world, superclass chain first then interfaces\n  (Java's supertypes: an interface in the world counts also when it is reached only through\n  one that is not).")

var Lit_425 *jrt.String = jrt.Intern("declared")

var Lit_426 *jrt.String = jrt.Intern("Does jrt's hand-written class or interface n have method m (name desc) in Go?")

var Lit_427 *jrt.String = jrt.Intern("An instance method of jrt's hand-written class n (Go base name base) that the program's\n  support code has, though jrt does not: String's chars() and codePoints(), the default methods\n  of CharSequence (translated), which a2g forwards to on the classes jrt writes that implement\n  it (JRT-NOTES.md, \"Text and locales\": CompactNumberFormat and java.time's text call them on\n  a String).")

var Lit_428 *jrt.String = jrt.Intern("Does method m of class n exist in Go: its descriptor's classes exist, and for a jrt class\n  jrt has it.")

var Lit_429 *jrt.String = jrt.Intern("The virtual methods n declares that exist in Go, by [name desc].")

var Lit_430 *jrt.String = jrt.Intern("vmethods")

var Lit_431 *jrt.String = jrt.Intern("Every virtual method of n (declared and inherited, abstract or not), in the world, Object's\n  excluded: an ordered map [name desc] -> method (the most specific declaration: classes first).")

var Lit_432 *jrt.String = jrt.Intern("impl-of")

var Lit_433 *jrt.String = jrt.Intern("k")

var Lit_434 *jrt.String = jrt.Intern("The implementation of virtual method k = [name desc] for class n: {:kind :class :owner c\n  :method m} for a method with a body in n or a superclass (a jrt class's: :jrt-impl when jrt\n  has Impl_, :promoted when the method itself is on its struct), {:kind :default :owner j\n  :method m} for an interface's default method, or nil (abstract).")

var Lit_435 *jrt.String = jrt.Intern("Does class n have trivial initialization (§6.2): no static initializer code, no\n  non-constant static field initializer, a superclass with trivial initialization? jrt's\n  classes count as trivial (jrt initializes them itself).")

var Lit_436 *jrt.String = jrt.Intern("tag")

var Lit_437 *jrt.String = jrt.Intern("String")

var Lit_438 *jrt.String = jrt.Intern("c")

var Lit_439 *jrt.String = jrt.Intern("seen")

var Lit_440 *jrt.String = jrt.Intern("Is constructor m of class c (in the file of class n) free of effects beyond its object's\n  fields: field stores of pure values on this, a super or this constructor call that is pure\n  too (Object's at the end)?")

var Lit_441 *jrt.String = jrt.Intern("node")

var Lit_442 *jrt.String = jrt.Intern("Can node, run inside the static initializer of class n, neither be observed outside n's\n  statics and new objects nor throw (bar running out of memory)?")

var Lit_443 *jrt.String = jrt.Intern("Is class n's initialization unobservable but through n's own static fields: trivial, or a\n  static initializer that only stores pure values (constants, arrays, n's own objects built by\n  pure constructors) into n's statics, over a superclass whose initialization is benign too?\n  Then a static method of n that reads no static field of n needs no initialization guard\n  (A2G-NOTES, phase 2D).")
