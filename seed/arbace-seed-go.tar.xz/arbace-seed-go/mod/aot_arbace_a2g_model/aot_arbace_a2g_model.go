//line aot_arbace_a2g_model.ae:1
package aot_arbace_a2g_model

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_New() *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A { A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_Init(); t := &A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_7; var tmp18 any = tmp17; var tmp19 any; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_8; var tmp20 any = tmp19; var tmp21 any; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_9; tmp3 = tmp8.Invoke_O_O_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp21) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp22 != nil { panic(tmp22) }; return tmp3 }
//line :1:1
func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_New() *A_arbace_a2g_model_eval1008000008_fn__1008000009_A { A_arbace_a2g_model_eval1008000008_fn__1008000009_A_Init(); t := &A_arbace_a2g_model_eval1008000008_fn__1008000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_14; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_12; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_13; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }























func A_arbace_a2g_model_jobs_A_New() *A_arbace_a2g_model_jobs_A { A_arbace_a2g_model_jobs_A_Init(); t := &A_arbace_a2g_model_jobs_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_model_jobs_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_279).Ref(); var tmp1 any; var tmp2 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(e__1)) {
		tmp1 = jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(e__1))).Ref() } else {
			var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_16; tmp1 = lang.Numbers_Min_O_J__O(jrt.NN(tmp3).GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :30:1*/ lang.Numbers_Max_J_O__O(1, tmp1) }



func A_arbace_a2g_model_par_mapv_A_New() *A_arbace_a2g_model_par_mapv_A { A_arbace_a2g_model_par_mapv_A_Init(); t := &A_arbace_a2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_model_par_mapv_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1008000013__3 any) any { var vec__1008000014__5 any = p__1008000013__3; var order__6 any = lang.RT_Nth_O_I_O__O(vec__1008000014__5, lang.RT_IntCast_J__I(0), nil); var xs__7 any; var tmp1 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_17; xs__7 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(xs__2); var cnt__8 int32 = /*line :34:1*/lang.RT_Count_O__I(xs__7); var n__9 any = lang.Numbers_Min_O_J__O(n__0, int64(cnt__8)); var order__10 any; if







	jrt.A2g_Truth(order__6) { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_17; order__10 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(order__6) } else { var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_17; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_23; order__10 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(cnt__8).Ref())) }; if
	lang.Numbers_Lte_O_J__Z(n__9, 1) {
		var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_18; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(f__1, xs__7) } else {
//line :43:1
			var res__11 any = lang.RT_Object_array_O__O1(jrt.Integer_ValueOf_I__Integer(cnt__8).Ref()).Ref(); var next_i__12 any; var tmp7 *lang.Var


			A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_19; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_24; next_i__12 = tmp8.Invoke_O__O(tmp9)
//line :43:1
			var work__13 any; var tmp10 any = A_arbace_a2g_model_par_mapv_work__1008000017_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__12, xs__7, res__11); var tmp11 *jrt.Class



			A_arbace_a2g_model_par_mapv_work__1008000017_A_Init(); tmp11 = A_arbace_a2g_model_par_mapv_work__1008000017_A_fn_class; work__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :43:1
			var ws__14 any; var tmp12 *lang.Var









			A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = A_arbace_a2g_model_par_mapv_fn__1008000019_A_New_O(work__13); var tmp17 *jrt.Class; A_arbace_a2g_model_par_mapv_fn__1008000019_A_Init(); tmp17 = A_arbace_a2g_model_par_mapv_fn__1008000019_A_fn_class; ws__14 = tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(n__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil)))
			var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_27; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_11; tmp19.Invoke_O_O__O(jrt.NN(tmp20).GetRawRoot__O(), ws__14)
			var tmp21 *lang.Var; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_17; return lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(res__11) } }
//line :47:1
func A_arbace_a2g_model_par_mapv_work__1008000017_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_a2g_model_par_mapv_work__1008000017_A { A_arbace_a2g_model_par_mapv_work__1008000017_A_Init(); t := &A_arbace_a2g_model_par_mapv_work__1008000017_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :47:1
func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :47:1
func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var tmp1 *lang.Var
											A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_next_i; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_21; k__1 = tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp4).GetRawRoot__O())
											if lang.Numbers_Lt_O_J__Z(k__1, int64(t.F_cnt)) { var tmp5 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O(tmp5, lang.RT_IntCast_O__I(k__1)); var tmp6 *jrt.RefArray = jrt.A2g_CastArray[*jrt.RefArray](t.F_res, jrt.Object_class.ArrayClass()); var tmp7 lang.IFn = lang.IFn_Cast(t.F_f); var tmp8 any = t.F_xs

		lang.RT_Aset_O1_I_O__O(tmp6, lang.RT_IntCast_O__I(i__2), tmp7.Invoke_O__O(lang.RT_Nth_O_I__O(tmp8, lang.RT_IntCast_O__I(i__2))))
		continue L2 } else {
//line :49:1
			return nil } } }; /*line :47:1*/panic("a2g: unreachable") }





func A_arbace_a2g_model_par_mapv_fn__1008000019_A_New_O(p0 any) *A_arbace_a2g_model_par_mapv_fn__1008000019_A { A_arbace_a2g_model_par_mapv_fn__1008000019_A_Init(); t := &A_arbace_a2g_model_par_mapv_fn__1008000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :53:1
func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_26; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_New_O(t.F_work); var tmp4 *jrt.Class; A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_Init(); tmp4 = A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_fn_class; return tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :53:1
func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_New_O(p0 any) *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A { A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_Init(); t := &A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :53:1
func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_a2g_model_has_QMARK__A_New() *A_arbace_a2g_model_has_QMARK__A { A_arbace_a2g_model_has_QMARK__A_Init(); t := &A_arbace_a2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_a2g_model_has_QMARK__A) Ctor() {}
//line :59:1
func (t *A_arbace_a2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any = flags__0; if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_29 }; return tmp2.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(tmp3, f__1))).Ref()) }

func A_arbace_a2g_model_T_A_New() *A_arbace_a2g_model_T_A { A_arbace_a2g_model_T_A_Init(); t := &A_arbace_a2g_model_T_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_a2g_model_T_A) Ctor() {}
//line :61:1
func (t *A_arbace_a2g_model_T_A) Invoke_O__O(self any) any { var x__1 any; var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_30; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; x__1 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()); if lang.IDeref_InstanceOf(x__1) { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_11; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__1) } else { return x__1 } }

func A_arbace_a2g_model_translated_QMARK__A_New() *A_arbace_a2g_model_translated_QMARK__A { A_arbace_a2g_model_translated_QMARK__A_Init(); t := &A_arbace_a2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_a2g_model_translated_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_a2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_32; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_33; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O(), n__0) }

func A_arbace_a2g_model_a2g_static_QMARK__A_New() *A_arbace_a2g_model_a2g_static_QMARK__A { A_arbace_a2g_model_a2g_static_QMARK__A_Init(); t := &A_arbace_a2g_model_a2g_static_QMARK__A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_model_a2g_static_QMARK__A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_model_a2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(cls__0, Lit_231); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(base__1, Lit_232); if and__1927000168__auto____4 {
		var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_34; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_233) } else {
//line :71:1
			return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }


func A_arbace_a2g_model_jrt_class_A_New() *A_arbace_a2g_model_jrt_class_A { A_arbace_a2g_model_jrt_class_A_Init(); t := &A_arbace_a2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_a2g_model_jrt_class_A) Ctor() {}
//line :74:1
func (t *A_arbace_a2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_35; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; return lang.RT_Get_O_O__O(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()), n__0)
}
func A_arbace_a2g_model_hand_written_QMARK__A_New() *A_arbace_a2g_model_hand_written_QMARK__A { A_arbace_a2g_model_hand_written_QMARK__A_Init(); t := &A_arbace_a2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_a2g_model_hand_written_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_a2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;


	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_36; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_28; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_34; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(n__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_model_in_world_QMARK__A_New() *A_arbace_a2g_model_in_world_QMARK__A { A_arbace_a2g_model_in_world_QMARK__A_Init(); t := &A_arbace_a2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_a2g_model_in_world_QMARK__A) Ctor() {}
//line :84:1
func (t *A_arbace_a2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z(n__0, Lit_177); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_34; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_36; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(n__0))).Ref() } } }

func A_arbace_a2g_model_translatable_QMARK__A_New() *A_arbace_a2g_model_translatable_QMARK__A { A_arbace_a2g_model_translatable_QMARK__A_Init(); t := &A_arbace_a2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_a2g_model_translatable_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_a2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_37; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0))).Ref()
}
func A_arbace_a2g_model_reflectable_interface_QMARK__A_New() *A_arbace_a2g_model_reflectable_interface_QMARK__A { A_arbace_a2g_model_reflectable_interface_QMARK__A_Init(); t := &A_arbace_a2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_37; and__1927000168__auto____2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_38; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_315); if jrt.A2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_38; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_316); if jrt.A2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_38; or__1927000174__auto____5 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_317); if jrt.A2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_38; or__1927000174__auto____6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_318); if jrt.A2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_38; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_319) } } } }
//line :97:1
		if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp9 *lang.Var


			A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_28; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_43; and__1927000168__auto____4 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_320))
//line :97:1
			if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp12 *lang.Var



				A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_39; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_44; and__1927000168__auto____5 = tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(n__0))
//line :97:1
				if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp15 *lang.Var




					A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_40; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(n__0)
//line :97:1
					if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp16 *lang.Var






						A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_28; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_45; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_46; var tmp21 *lang.Keyword = tmp20; var tmp22 *lang.Var; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_44; var tmp23 any = jrt.NN(tmp21).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(n__0)); var tmp24 any; A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_47; and__1927000168__auto____7 = tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(tmp23, tmp24))
//line :97:1
						if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp25 *lang.Var









							A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_41; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_48; var tmp28 *lang.Keyword = tmp27; var tmp29 *lang.Var; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_44; and__1927000168__auto____8 = tmp26.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(n__0)))
//line :97:1
							if jrt.A2g_Truth(and__1927000168__auto____8) {










								var tmp30 *lang.Var; A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_42; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_New(); var tmp33 *jrt.Class; A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_Init(); tmp33 = A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_fn_class; var tmp34 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var tmp35 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_51; var tmp36 *lang.Keyword = tmp35; var tmp37 *lang.Var; A_arbace_a2g_model_A_Init(); tmp37 = A_arbace_a2g_model_A_const_44; return tmp31.Invoke_O_O__O(tmp34, jrt.NN(tmp36).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(n__0))) } else {
//line :97:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_New() *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A { A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_Init(); t := &A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) Ctor() {}
//line :108:1
func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) Invoke_O_O__O(self, p1__1008000032_SHARP___1 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_49; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1008000032_SHARP___1); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_50; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__1008000032_SHARP___1) } }

func A_arbace_a2g_model_reflected_QMARK__A_New() *A_arbace_a2g_model_reflected_QMARK__A { A_arbace_a2g_model_reflected_QMARK__A_Init(); t := &A_arbace_a2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_model_reflected_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;


	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_34; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_28; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_37; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(n__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_model_info_A_New() *A_arbace_a2g_model_info_A { A_arbace_a2g_model_info_A_Init(); t := &A_arbace_a2g_model_info_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_a2g_model_info_A) Ctor() {}
//line :115:1
func (t *A_arbace_a2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_44; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0) }
func A_arbace_a2g_model_interface_QMARK__A_New() *A_arbace_a2g_model_interface_QMARK__A { A_arbace_a2g_model_interface_QMARK__A_Init(); t := &A_arbace_a2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_a2g_model_interface_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_a2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_40; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_a2g_model_desc_classes_A_New() *A_arbace_a2g_model_desc_classes_A { A_arbace_a2g_model_desc_classes_A_Init(); t := &A_arbace_a2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_a2g_model_desc_classes_A) Ctor() {}
//line :118:1
func (t *A_arbace_a2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z(d__0, nil) { return nil } else { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_52; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { return nil } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_53; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__0)) {

		var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_57; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_58; return tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(d__0, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(d__0))) } else {
//line :121:1
			var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_59; return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(d__0)) } else { var tmp10 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_56; if tmp10 != nil { return nil } else { return nil
			}
			}
		}
	}
	} }
func A_arbace_a2g_model_method_desc_classes_A_New() *A_arbace_a2g_model_method_desc_classes_A { A_arbace_a2g_model_method_desc_classes_A_Init(); t := &A_arbace_a2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_a2g_model_method_desc_classes_A) Ctor() {}
//line :127:1
func (t *A_arbace_a2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1008000040__2 any; var tmp1 *lang.Var;
											A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_60; vec__1008000040__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(desc__0); var ps__3 any = /*line :127:1*/lang.RT_Nth_O_I_O__O(vec__1008000040__2, lang.RT_IntCast_J__I(0), nil); var r__4 any = lang.RT_Nth_O_I_O__O(vec__1008000040__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var;

	A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_61; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_54; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_62; return tmp3.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(r__4, ps__3)) }

func A_arbace_a2g_model_erased_desc_QMARK__A_New() *A_arbace_a2g_model_erased_desc_QMARK__A { A_arbace_a2g_model_erased_desc_QMARK__A_Init(); t := &A_arbace_a2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__A) Ctor() {}
//line :131:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_63; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp2 any = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_New_O(d__0); var tmp3 *jrt.Class
		A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_Init(); tmp3 = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_fn_class; e__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :136:1
		var and__1927000168__auto____4 any; var tmp4 *lang.Var

		A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_55; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(e__3); if jrt.A2g_Truth(and__1927000168__auto____4) { var n__5 any; var tmp5 *lang.Var
			A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_59; n__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(e__3)
//line :138:1
			var and__1927000168__auto____6 any; var tmp6 *lang.Var

			A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_28; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_49; and__1927000168__auto____6 = tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__5)); if jrt.A2g_Truth(and__1927000168__auto____6) {
				var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_65; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_New_O(n__5); var tmp12 *jrt.Class; A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_Init(); tmp12 = A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_66; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_31; return tmp10.Invoke_O_O__O(tmp13, jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O())) } else {
//line :140:1
					return and__1927000168__auto____6 } } else {
//line :138:1
						return and__1927000168__auto____4 } } else {
//line :136:1
							return and__1927000168__auto____2 } }
func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_New_O(p0 any) *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_Init(); t := &A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :137:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_53; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__1)) { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_64; d__1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__1); continue L1 } else { return d__1 } } }; panic("a2g: unreachable") }



func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_New_O(p0 any) *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_Init(); t := &A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :141:1
func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) Invoke_O_O__O(self, p1__1008000044_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_38; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_n, p1__1008000044_SHARP___1) }

func A_arbace_a2g_model_desc_in_world_QMARK__A_New() *A_arbace_a2g_model_desc_in_world_QMARK__A { A_arbace_a2g_model_desc_in_world_QMARK__A_Init(); t := &A_arbace_a2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :143:1
func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_42; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_49; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_54; return tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(d__0)) }
func A_arbace_a2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_a2g_model_mdesc_in_world_QMARK__A { A_arbace_a2g_model_mdesc_in_world_QMARK__A_Init(); t := &A_arbace_a2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :144:1
func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_42; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_49; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_67; return tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(desc__0)) }




func A_arbace_a2g_model_go_name_A_New() *A_arbace_a2g_model_go_name_A { A_arbace_a2g_model_go_name_A_Init(); t := &A_arbace_a2g_model_go_name_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_a2g_model_go_name_A) Ctor() {}
//line :149:1
func (t *A_arbace_a2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_31; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var temp__1927000414__auto____2 any; var tmp2 *lang.Keyword
		A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_35; var tmp3 *lang.Keyword = tmp2; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_31; temp__1927000414__auto____2 = lang.RT_Get_O_O__O(jrt.NN(tmp3).Invoke_O__O(jrt.NN(tmp4).Get__O()), n__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp5 *lang.Var
			A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_34; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(n__0)) { or__1927000174__auto____2 = nil } else { var tmp6 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_68; or__1927000174__auto____2 = jrt.NN(tmp6).Invoke_O__O(jc__3) } } else {
//line :155:1
				or__1927000174__auto____2 = nil } } else {
//line :154:1
					or__1927000174__auto____2 = nil }; if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_69; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__0) } }
func A_arbace_a2g_model_pkg_A_New() *A_arbace_a2g_model_pkg_A { A_arbace_a2g_model_pkg_A_Init(); t := &A_arbace_a2g_model_pkg_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_a2g_model_pkg_A) Ctor() {}
//line :158:1
func (t *A_arbace_a2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_70; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_a2g_model_abstract_QMARK__A_New() *A_arbace_a2g_model_abstract_QMARK__A { A_arbace_a2g_model_abstract_QMARK__A_Init(); t := &A_arbace_a2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_a2g_model_abstract_QMARK__A) Ctor() {}
//line :160:1
func (t *A_arbace_a2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_46; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_71; var tmp6 any = jrt.NN(tmp4).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(n__0)); var tmp7 any; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_72; return tmp2.Invoke_O_O__O(tmp6, tmp7) }
func A_arbace_a2g_model_final_QMARK__A_New() *A_arbace_a2g_model_final_QMARK__A { A_arbace_a2g_model_final_QMARK__A_Init(); t := &A_arbace_a2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_a2g_model_final_QMARK__A) Ctor() {}
//line :161:1
func (t *A_arbace_a2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_46; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_71; var tmp6 any = jrt.NN(tmp4).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(n__0)); var tmp7 any; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_73; return tmp2.Invoke_O_O__O(tmp6, tmp7) }

func A_arbace_a2g_model_subclasses_A_New() *A_arbace_a2g_model_subclasses_A { A_arbace_a2g_model_subclasses_A_Init(); t := &A_arbace_a2g_model_subclasses_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_model_subclasses_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_74; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; return lang.RT_Get_O_O__O(lang.IFn_Cast(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())).Invoke__O(), n__0)
}
func A_arbace_a2g_model_make_subclass_index_A_New() *A_arbace_a2g_model_make_subclass_index_A { A_arbace_a2g_model_make_subclass_index_A_Init(); t := &A_arbace_a2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_a2g_model_make_subclass_index_A) Ctor() {}
//line :168:1
func (t *A_arbace_a2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var tmp1 *lang.Var;
											A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_19; cache__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(nil); var tmp2 any =
											A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_New_O_O(cache__2, w__0); var tmp3 *jrt.Class; A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_Init(); tmp3 = A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil) }
//line :170:1
func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A { A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_Init(); t := &A_arbace_a2g_model_make_subclass_index_fn__1008000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :170:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :170:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 *lang.Var;
												A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_11; or__1927000174__auto____1 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_cache); if jrt.A2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_75; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_cache; var tmp5 any; var tmp6 *lang.Var
													A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_83; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_84; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_31; tmp7.Invoke_O__O(tmp9.Invoke_O_O__O(tmp10.Ref(), t.F_w)); var tmp11 any = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_New_O(t.F_w); var tmp12 *jrt.Class; A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_Init(); tmp12 = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_fn_class; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :172:1
		return tmp3.Invoke_O_O__O(tmp4, tmp5) } }
func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_New_O(p0 any) *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_Init(); t := &A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A{}; t.Ctor_O(p0); return t }
//line :173:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :173:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_76; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_New(); var tmp5 *jrt.Class; A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_Init(); tmp5 = A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_fn_class; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_81; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_33; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_82; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_35; var tmp16 *lang.Keyword = tmp15; var tmp17 any; var t_ any = t.F_w


		t.F_w = nil; tmp17 = t_
//line :174:1
		tmp1 = tmp3.Invoke_O_O_O__O(tmp6, tmp8, tmp10.Invoke_O_O__O(tmp12, tmp14.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(tmp17)))) }
//line :173:1
	return nil }(); var tmp19 *lang.Var; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_77; lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O(); if tmp18 != nil { panic(tmp18) }; return tmp1 }
func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_New() *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_Init(); t := &A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) Ctor() {}
//line :174:1
func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword;
																		A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_78; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_71; s__3 = jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__2)); if
																		jrt.A2g_Truth(s__3) { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_79; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_80; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_12; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp10 = lang.PersistentHashSet_EMPTY; return tmp5.Invoke_O_O_O_O__O(m__1, s__3, tmp7.Invoke_O_O__O(tmp9, tmp10.Ref()), c__2) } else { return m__1 } }















func A_arbace_a2g_model_leaf_QMARK__A_New() *A_arbace_a2g_model_leaf_QMARK__A { A_arbace_a2g_model_leaf_QMARK__A_Init(); t := &A_arbace_a2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_a2g_model_leaf_QMARK__A) Ctor() {}
//line :192:1
func (t *A_arbace_a2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z(n__0, Lit_177) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_86; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(n__0)) {


		var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_28; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_87; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_88; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_31; var tmp12 any = jrt.NN(tmp8).Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Get__O())); var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_261); var tmp14 *lang.Var; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_89; return tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp13, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(n__0), nil)).Ref())) } else {
//line :197:1
			var tmp15 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_56; if tmp15 != nil { var and__1927000168__auto____2 any; var tmp16 *lang.Var



				A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_28; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_90; and__1927000168__auto____2 = tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp19 *lang.Var; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_41; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_91; and__1927000168__auto____3 = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(and__1927000168__auto____3) {
					var tmp22 *lang.Var; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_28; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; var and__1927000168__auto____4 any; var tmp25 *lang.Var; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_92; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp26 *lang.Var; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_28; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_93; tmp24 = tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp24 = and__1927000168__auto____4 }; return tmp23.Invoke_O__O(tmp24) } else {
//line :201:1
						return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :197:1
							return nil
						}
		}
	}
	}
}




func A_arbace_a2g_model_qualify_A_New() *A_arbace_a2g_model_qualify_A { A_arbace_a2g_model_qualify_A_Init(); t := &A_arbace_a2g_model_qualify_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_a2g_model_qualify_A) Ctor() {}
//line :207:1
func (t *A_arbace_a2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z(from__0, nil) }; if tmp1 { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_94; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(ident__2) } else { var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_94; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_95; return tmp4.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(of__1), ident__2)
	} }
func A_arbace_a2g_model_class_sym_A_New() *A_arbace_a2g_model_class_sym_A { A_arbace_a2g_model_class_sym_A_Init(); t := &A_arbace_a2g_model_class_sym_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_a2g_model_class_sym_A) Ctor() {}
//line :212:1
func (t *A_arbace_a2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_97; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__1); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_89; return tmp2.Invoke_O_O_O__O(from__0, tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(n__1), suffix__2)).Ref()) }
//line :212:1
func (t *A_arbace_a2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_98; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(from__0, n__1, Lit_240)
}

func A_arbace_a2g_model_jrt_sym_A_New() *A_arbace_a2g_model_jrt_sym_A { A_arbace_a2g_model_jrt_sym_A_Init(); t := &A_arbace_a2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_a2g_model_jrt_sym_A) Ctor() {}
//line :217:1
func (t *A_arbace_a2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_88; return tmp2.Invoke_O_O_O__O(from__0, tmp3.Ref(), ident__1) }






func A_arbace_a2g_model_go_type_A_New() *A_arbace_a2g_model_go_type_A { A_arbace_a2g_model_go_type_A_Init(); t := &A_arbace_a2g_model_go_type_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_a2g_model_go_type_A) Ctor() {}
//line :224:1
func (t *A_arbace_a2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_99; if lang.Util_Equiv_O_O__Z(d__1, tmp1.Ref()) { A_arbace_a2g_model_A_Init(); return A_arbace_a2g_model_A_const_100 } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_101; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :227:1
			if lang.Util_Equiv_O_O__Z(d__1, Lit_258) { return nil } else { if lang.Util_Equiv_O_O__Z(d__1, Lit_259) { A_arbace_a2g_model_A_Init(); return A_arbace_a2g_model_A_const_102 } else { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_53; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(d__1)) { var e__3 any; var tmp5 *lang.Var




				A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_64; e__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(d__1)
				var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(e__3)) {
					var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_104; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_108; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_109; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_110; return tmp8.Invoke_O_O__O(tmp10, tmp12.Invoke_O_O__O(from__0, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(e__3))) } else {
						var tmp14 *lang.Var; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_104; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_111; var tmp17 any = tmp16; var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_109; return tmp15.Invoke_O_O__O(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(from__0, Lit_260)) } } else {
//line :227:1
							var tmp19 *lang.Var; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__1)) { var n__3 any; var tmp20 *lang.Var









								A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_59; n__3 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(d__1)
								var tmp21 *lang.Var; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_28; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_49; if jrt.A2g_Truth(tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(n__3))) { A_arbace_a2g_model_A_Init(); return A_arbace_a2g_model_A_const_105 } else { var tmp24 *lang.Var; A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(n__3)) {

									var tmp25 *lang.Var; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_98; return lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(from__0, n__3) } else {
//line :238:1
										var tmp26 *lang.Var; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_106; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(n__3)) {


											var tmp27 *lang.Var; A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_104; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_112; var tmp30 any = tmp29; var tmp31 *lang.Var; A_arbace_a2g_model_A_Init(); tmp31 = A_arbace_a2g_model_A_const_98; return tmp28.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O__O(from__0, n__3)) } else {
//line :238:1
												var tmp32 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp32 = A_arbace_a2g_model_A_const_56; if tmp32 != nil {



													var tmp33 *lang.Var; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_98; return lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O_O_O__O(from__0, n__3, Lit_261) } else {
//line :238:1
														return nil } } } } } else {
//line :227:1
															var tmp34 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp34 = A_arbace_a2g_model_A_const_56; if tmp34 != nil { var tmp35 *lang.Var; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_107; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_262, nil); var tmp38 *lang.Var; A_arbace_a2g_model_A_Init(); tmp38 = A_arbace_a2g_model_A_const_113; var tmp39 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var tmp40 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp40 = A_arbace_a2g_model_A_const_114; panic(jrt.Thrown(jrt.Throwable_Cast(tmp36.Invoke_O_O__O(tmp39, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40.Ref(), d__1)))))) } else { return nil
															}
														}
						}
			}
			}
		}
	}
}









func A_arbace_a2g_model_pointer_desc_QMARK__A_New() *A_arbace_a2g_model_pointer_desc_QMARK__A { A_arbace_a2g_model_pointer_desc_QMARK__A_Init(); t := &A_arbace_a2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :245:1
func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_53; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__0)) { var n__2 any; var tmp3 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_59; n__2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(d__0)
//line :248:1
		var and__1927000168__auto____3 any; var tmp4 *lang.Var

		A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_49; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(n__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_28; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_85; and__1927000168__auto____4 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_115; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(n__2, Lit_177); if jrt.A2g_Truth(and__1927000168__auto____5) {
			var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_106; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(n__2) } else {
//line :250:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :248:1
					var tmp10 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_56; if tmp10 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
	}
}

func A_arbace_a2g_model_iface_desc_QMARK__A_New() *A_arbace_a2g_model_iface_desc_QMARK__A { A_arbace_a2g_model_iface_desc_QMARK__A_Init(); t := &A_arbace_a2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_a2g_model_iface_desc_QMARK__A) Ctor() {}
//line :254:1
func (t *A_arbace_a2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;


	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_116; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_115; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_99; and__1927000168__auto____3 = tmp3.Invoke_O_O__O(d__0, tmp4.Ref()); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_28; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_117; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(d__0)) } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_a2g_model_static_QMARK__A_New() *A_arbace_a2g_model_static_QMARK__A { A_arbace_a2g_model_static_QMARK__A_Init(); t := &A_arbace_a2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_a2g_model_static_QMARK__A) Ctor() {}
//line :262:1
func (t *A_arbace_a2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_46; var tmp4 any = jrt.NN(tmp3).Invoke_O__O(m__0); var tmp5 any; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_118; return tmp2.Invoke_O_O__O(tmp4, tmp5) }
func A_arbace_a2g_model_private_QMARK__A_New() *A_arbace_a2g_model_private_QMARK__A { A_arbace_a2g_model_private_QMARK__A_Init(); t := &A_arbace_a2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_a2g_model_private_QMARK__A) Ctor() {}
//line :263:1
func (t *A_arbace_a2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_46; var tmp4 any = jrt.NN(tmp3).Invoke_O__O(m__0); var tmp5 any; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_119; return tmp2.Invoke_O_O__O(tmp4, tmp5) }
func A_arbace_a2g_model_abstract_m_QMARK__A_New() *A_arbace_a2g_model_abstract_m_QMARK__A { A_arbace_a2g_model_abstract_m_QMARK__A_Init(); t := &A_arbace_a2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_a2g_model_abstract_m_QMARK__A) Ctor() {}
//line :264:1
func (t *A_arbace_a2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_46; var tmp4 any = jrt.NN(tmp3).Invoke_O__O(m__0); var tmp5 any; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_72; return tmp2.Invoke_O_O__O(tmp4, tmp5) }

func A_arbace_a2g_model_methods_of_A_New() *A_arbace_a2g_model_methods_of_A { A_arbace_a2g_model_methods_of_A_Init(); t := &A_arbace_a2g_model_methods_of_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_a2g_model_methods_of_A) Ctor() {}
//line :266:1
func (t *A_arbace_a2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_48; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_71; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__0)) }
func A_arbace_a2g_model_fields_of_A_New() *A_arbace_a2g_model_fields_of_A { A_arbace_a2g_model_fields_of_A_Init(); t := &A_arbace_a2g_model_fields_of_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_a2g_model_fields_of_A) Ctor() {}
//line :267:1
func (t *A_arbace_a2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_120; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_71; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_a2g_model_find_method_A_New() *A_arbace_a2g_model_find_method_A { A_arbace_a2g_model_find_method_A_Init(); t := &A_arbace_a2g_model_find_method_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_a2g_model_find_method_A) Ctor() {}
//line :269:1
func (t *A_arbace_a2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_model_find_method_fn__1008000077_A_New_O_O(name__1, desc__2); var tmp4 *jrt.Class; A_arbace_a2g_model_find_method_fn__1008000077_A_Init(); tmp4 = A_arbace_a2g_model_find_method_fn__1008000077_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_122; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :270:1
func A_arbace_a2g_model_find_method_fn__1008000077_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_find_method_fn__1008000077_A { A_arbace_a2g_model_find_method_fn__1008000077_A_Init(); t := &A_arbace_a2g_model_find_method_fn__1008000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :270:1
func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) Invoke_O_O__O(self, p1__1008000076_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 any = t.F_name; var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_121; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__1008000076_SHARP___1)); if and__1927000168__auto____2 { var tmp4 any = t.F_desc; var tmp5 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_114; tmp1 = lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(p1__1008000076_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1008000076_SHARP___1 } else { return nil } }

func A_arbace_a2g_model_virtual_member_QMARK__A_New() *A_arbace_a2g_model_virtual_member_QMARK__A { A_arbace_a2g_model_virtual_member_QMARK__A_Init(); t := &A_arbace_a2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_a2g_model_virtual_member_QMARK__A) Ctor() {}
//line :272:1
func (t *A_arbace_a2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;


	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_123; and__1927000168__auto____2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(m__0)); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_28; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_124; and__1927000168__auto____3 = tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(m__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_115; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_121; and__1927000168__auto____4 = tmp8.Invoke_O_O__O(Lit_299, jrt.NN(tmp9).Invoke_O__O(m__0)); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_115; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_121; return tmp11.Invoke_O_O__O(Lit_334, jrt.NN(tmp12).Invoke_O__O(m__0)) } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_a2g_model_supertypes_A_New() *A_arbace_a2g_model_supertypes_A { A_arbace_a2g_model_supertypes_A_Init(); t := &A_arbace_a2g_model_supertypes_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_a2g_model_supertypes_A) Ctor() {}
//line :282:1
func (t *A_arbace_a2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var tmp1 *lang.Var;
										A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_71; i__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_125; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_126; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_62; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_78; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(i__2); var tmp10 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_51; return tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(i__2))) }

func A_arbace_a2g_model_world_supertypes_A_New() *A_arbace_a2g_model_world_supertypes_A { A_arbace_a2g_model_world_supertypes_A_Init(); t := &A_arbace_a2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_a2g_model_world_supertypes_A) Ctor() {}
//line :285:1
func (t *A_arbace_a2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_127; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_49; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_128; return tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(n__0))
}
func A_arbace_a2g_model_all_supertypes_A_New() *A_arbace_a2g_model_all_supertypes_A { A_arbace_a2g_model_all_supertypes_A_Init(); t := &A_arbace_a2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_a2g_model_all_supertypes_A) Ctor() {}
//line :290:1
func (t *A_arbace_a2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_127; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_49; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_129; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__0)))
}


func A_arbace_a2g_model_hw_method_exists_QMARK__A_New() *A_arbace_a2g_model_hw_method_exists_QMARK__A { A_arbace_a2g_model_hw_method_exists_QMARK__A_Init(); t := &A_arbace_a2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :299:1
func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var scan__3 any; var tmp1 *lang.Keyword;


	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_88; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; scan__3 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()); var g__4 any; var tmp4 /*line :299:1*/*lang.Var;



	A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_89; g__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(n__0); var base__5 any; var tmp5 /*line :299:1*/*lang.Var;




	A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_130; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_121; var tmp8 any = jrt.NN(tmp7).Invoke_O__O(m__1); var tmp9 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_114; base__5 = tmp6.Invoke_O_O__O(tmp8, jrt.NN(tmp9).Invoke_O__O(m__1)); if
	lang.Util_Equiv_O_O__Z(n__0, Lit_177) {
		var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_32; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_133; var tmp13 any = jrt.NN(tmp12).GetRawRoot__O(); var tmp14 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_121; var tmp15 any = jrt.NN(tmp14).Invoke_O__O(m__1); var tmp16 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_114; return tmp11.Invoke_O_O__O(tmp13, lang.Tuple_Create_O_O__IPersistentVector(tmp15, jrt.NN(tmp16).Invoke_O__O(m__1))) } else {
//line :305:1
			var tmp17 *lang.Var; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(n__0)) { var or__1927000174__auto____6 any; var tmp18 *lang.Var

				A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_32; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_134; or__1927000174__auto____6 = tmp19.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O_O__O(scan__3, g__4), base__5); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var tmp21 *lang.Var; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_32; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_135; return tmp22.Invoke_O_O__O(jrt.NN(tmp23).Invoke_O__O(scan__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_266, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref()) } } else {
//line :305:1
						var tmp24 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_56; if tmp24 != nil { var ms__6 any; var tmp25 *lang.Var




							A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_131; ms__6 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(scan__3, g__4)
//line :305:1
							var or__1927000174__auto____7 any; var tmp26 *lang.Var





							A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_32; or__1927000174__auto____7 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(ms__6, base__5); if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var tmp27 *lang.Var; A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_32; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_136; or__1927000174__auto____8 = tmp28.Invoke_O_O__O(ms__6, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(base__5)); if jrt.A2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var tmp30 *lang.Var; A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_132; return lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(n__0, base__5) } } } else {
//line :305:1
									return nil } } } }








func A_arbace_a2g_model_a2g_method_QMARK__A_New() *A_arbace_a2g_model_a2g_method_QMARK__A { A_arbace_a2g_model_a2g_method_QMARK__A_Init(); t := &A_arbace_a2g_model_a2g_method_QMARK__A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_a2g_model_a2g_method_QMARK__A) Ctor() {}
//line :314:1
func (t *A_arbace_a2g_model_a2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(n__0, Lit_227); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any; var tmp1 any; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_137; and__1927000168__auto____4 = lang.IFn_Cast(tmp1).Invoke_O__O(base__1); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp2 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_34; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(Lit_228)
//line :321:1
		if jrt.A2g_Truth(and__1927000168__auto____5) {
			var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_34; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(Lit_229) } else {
//line :321:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }


func A_arbace_a2g_model_member_in_world_QMARK__A_New() *A_arbace_a2g_model_member_in_world_QMARK__A { A_arbace_a2g_model_member_in_world_QMARK__A_Init(); t := &A_arbace_a2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_a2g_model_member_in_world_QMARK__A) Ctor() {}
//line :324:1
func (t *A_arbace_a2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var tmp1 *lang.Var;



	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_138; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_114; and__1927000168__auto____3 = tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(m__1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var tmp4 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_28; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_86; or__1927000174__auto____4 = tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_139; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(n__0, m__1) } } else {
//line :328:1
			return and__1927000168__auto____3 } }


func A_arbace_a2g_model_declared_vmethods_A_New() *A_arbace_a2g_model_declared_vmethods_A { A_arbace_a2g_model_declared_vmethods_A_Init(); t := &A_arbace_a2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_a2g_model_declared_vmethods_A) Ctor() {}
//line :331:1
func (t *A_arbace_a2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_New_O(n__0); var tmp2 *jrt.Class;


	A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_Init(); tmp2 = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_122; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :334:1
func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_New_O(p0 any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_Init(); t := &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A{}; t.Ctor_O(p0); return t }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) Invoke_O_O__O(self, s__1008000088__1 any) any { var tmp1 any = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_New_O_O_O(t.F_n, s__1008000088__1, self); var tmp2 *jrt.Class; A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_Init(); tmp2 = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :334:1
func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_Init(); t := &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) Ctor_O_O_O(c__n, c__s__1008000088, c__iter__1008000087 any) { t.F_n = c__n; t.F_s__1008000088 = c__s__1008000088; t.F_iter__1008000087 = c__iter__1008000087 }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) Invoke_O__O(self any) any { { var s__1008000088__1 any; var t_ any = t.F_s__1008000088; t.F_s__1008000088 = nil; s__1008000088__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1008000088__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1008000088__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_140; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1008000088__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_141; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1008000088__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1008000090__6 any; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_142; b__1008000090__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_New_O_O_I_O(t.F_n, b__1008000090__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_Init(); tmp6 = A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_148; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_150; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1008000090__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1008000087); var tmp12 *lang.Var; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_151; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1008000088__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_148; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_150; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1008000090__6), nil) } } else { var m__4 any; var tmp16 *lang.Var; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_149; m__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1008000088__3); var tmp17 *lang.Var; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_143; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(m__4)) { var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_144; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(t.F_n, m__4)) { var tmp19 *lang.Var; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_146; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_147; var tmp24 any = tmp22.Invoke_O_O_O__O(m__4, tmp23.Ref(), t.F_n); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1008000087); var tmp26 *lang.Var; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_152; return tmp20.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1008000088__3))) } else { var tmp27 *lang.Var; A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_152; s__1008000088__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1008000088__3); continue L1 } } else { var tmp28 *lang.Var; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_152; s__1008000088__1 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__1008000088__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :334:1
func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_Init(); t := &A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) Ctor_O_O_I_O(c__n, c__b__1008000090 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1008000090 = c__b__1008000090; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) Invoke_O__O(self any) any { { var i__1008000089__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1008000089__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1008000089__1)); var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_143; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(m__2)) { var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_144; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t.F_n, m__2)) { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_145; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_b__1008000090; var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_146; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_147; tmp5.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O_O__O(m__2, tmp9.Ref(), t.F_n)); i__1008000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000089__1); continue L1 } else { i__1008000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000089__1); continue L1 } } else { i__1008000089__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000089__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_model_vmethods_A_New() *A_arbace_a2g_model_vmethods_A { A_arbace_a2g_model_vmethods_A_Init(); t := &A_arbace_a2g_model_vmethods_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_a2g_model_vmethods_A) Ctor() {}
//line :339:1
func (t *A_arbace_a2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var cache__2 any; var tmp1 *lang.Keyword;



	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_153; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; cache__2 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()); var or__1927000174__auto____3 any; var tmp4 /*line :339:1*/*lang.Var;




	A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_11; or__1927000174__auto____3 = lang.RT_Get_O_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(cache__2), n__0); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var tmp5 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_76; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_a2g_model_vmethods_fn__1008000098_A_New(); var tmp8 *jrt.Class; A_arbace_a2g_model_vmethods_fn__1008000098_A_Init(); tmp8 = A_arbace_a2g_model_vmethods_fn__1008000098_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_155; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O(); var tmp12 *lang.Var; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_156; r__4 = tmp6.Invoke_O_O_O__O(tmp9, tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__0))







		var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_20; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_146; tmp14.Invoke_O_O_O_O__O(cache__2, jrt.NN(tmp15).GetRawRoot__O(), n__0, r__4)
//line :344:1
		return r__4 } }
func A_arbace_a2g_model_vmethods_fn__1008000098_A_New() *A_arbace_a2g_model_vmethods_fn__1008000098_A { A_arbace_a2g_model_vmethods_fn__1008000098_A_Init(); t := &A_arbace_a2g_model_vmethods_fn__1008000098_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) Ctor() {}
//line :345:1
func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z(c__2, Lit_177) { return acc__1 } else {

		var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_Init(); tmp4 = A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_154; return tmp2.Invoke_O_O_O__O(tmp5, acc__1, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(c__2)) } }
//line :348:1
func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_New() *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A { A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_Init(); t := &A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) Ctor() {}
//line :348:1
func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any; var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_121; var tmp2 any = jrt.NN(tmp1).Invoke_O__O(m__2); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_114; k__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, jrt.NN(tmp3).Invoke_O__O(m__2)); var tmp4 any; var or__1927000174__auto____4 any; var tmp5 /*line :350:1*/*lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_32; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(acc__1, k__3); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else { var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_32; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_133; tmp4 = tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), k__3) }; if jrt.A2g_Truth(tmp4) { return acc__1 } else { var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_146; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O__O(acc__1, k__3, m__2) } }





func A_arbace_a2g_model_superclass_chain_A_New() *A_arbace_a2g_model_superclass_chain_A { A_arbace_a2g_model_superclass_chain_A_Init(); t := &A_arbace_a2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_a2g_model_superclass_chain_A) Ctor() {}
//line :356:1
func (t *A_arbace_a2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_157; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_39; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_158; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_a2g_model_superclass_chain_fn__1008000104_A_New(); var tmp8 *jrt.Class; A_arbace_a2g_model_superclass_chain_fn__1008000104_A_Init(); tmp8 = A_arbace_a2g_model_superclass_chain_fn__1008000104_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), n__0)) }
//line :357:1
func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_New() *A_arbace_a2g_model_superclass_chain_fn__1008000104_A { A_arbace_a2g_model_superclass_chain_fn__1008000104_A_Init(); t := &A_arbace_a2g_model_superclass_chain_fn__1008000104_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) Ctor() {}
//line :357:1
func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) Invoke_O_O__O(self, p1__1008000103_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_78; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_71; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__1008000103_SHARP___1)) }

func A_arbace_a2g_model_impl_of_A_New() *A_arbace_a2g_model_impl_of_A { A_arbace_a2g_model_impl_of_A_Init(); t := &A_arbace_a2g_model_impl_of_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_a2g_model_impl_of_A) Ctor() {}
//line :359:1
func (t *A_arbace_a2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1008000108__1 any) any { var vec__1008000109__3 any = p__1008000108__1; var name__4 any = lang.RT_Nth_O_I_O__O(vec__1008000109__3, lang.RT_IntCast_J__I(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__1008000109__3, lang.RT_IntCast_J__I(1), nil); var k__6 any = vec__1008000109__3; var or__1927000174__auto____7 any; var tmp1 *lang.Var; _ = k__6;





	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_model_impl_of_fn__1008000112_A_New_O_O_O(name__4, desc__5, n__0); var tmp4 *jrt.Class; A_arbace_a2g_model_impl_of_fn__1008000112_A_Init(); tmp4 = A_arbace_a2g_model_impl_of_fn__1008000112_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_168; or__1927000174__auto____7 = tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_New_O_O(name__4, desc__5); var tmp8 *jrt.Class














		A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_Init(); tmp8 = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_fn_class; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_156; cands__8 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(n__0))
//line :365:1
		var cands__9 any; var tmp11 *lang.Var





















		A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_125; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_a2g_model_impl_of_fn__1008000124_A_New_O(cands__8); var tmp14 *jrt.Class; A_arbace_a2g_model_impl_of_fn__1008000124_A_Init(); tmp14 = A_arbace_a2g_model_impl_of_fn__1008000124_A_fn_class; cands__9 = tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), cands__8)
		var tmp15 *lang.Var; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_149; return lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(cands__9) } }
//line :365:1
func A_arbace_a2g_model_impl_of_fn__1008000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_model_impl_of_fn__1008000112_A { A_arbace_a2g_model_impl_of_fn__1008000112_A_Init(); t := &A_arbace_a2g_model_impl_of_fn__1008000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :365:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var tmp1 *lang.Var;
											A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_85; and__1927000168__auto____2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__1)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_159; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(c__1, t.F_name, t.F_desc) } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.A2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp5 any; var and__1927000168__auto____4 any; var tmp6 *lang.Var
												A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_28; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_123; and__1927000168__auto____4 = tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_28; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_160; and__1927000168__auto____5 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var tmp12 *lang.Var
													A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_28; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_124; or__1927000174__auto____6 = tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__1, t.F_n)).Ref() } } else {
//line :367:1
				tmp5 = and__1927000168__auto____5 } } else { tmp5 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp5) {

					if lang.Util_Equiv_O_O__Z(c__1, Lit_177) { var tmp15 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_161; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_164; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_147; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_163; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, tmp20, c__1, tmp21.Ref(), m__3)) } else { var tmp22 *lang.Var; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_86; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(c__1)) { var base__4 any; var tmp23 *lang.Var


						A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_130; base__4 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc)
//line :369:1
						var ms__5 any; var tmp24 *lang.Var



						A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_131; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_88; var tmp27 *lang.Keyword = tmp26; var tmp28 *lang.Var; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_31; var tmp29 any = jrt.NN(tmp27).Invoke_O__O(jrt.NN(tmp28).Get__O()); var tmp30 *lang.Var; A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_89; ms__5 = tmp25.Invoke_O_O__O(tmp29, lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(c__1))
						var tmp31 *lang.Var; A_arbace_a2g_model_A_Init(); tmp31 = A_arbace_a2g_model_A_const_32; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_136; if jrt.A2g_Truth(tmp32.Invoke_O_O__O(ms__5, lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(base__4))) { var tmp34 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp34 = A_arbace_a2g_model_A_const_161; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp36 = A_arbace_a2g_model_A_const_165; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp38 = A_arbace_a2g_model_A_const_147; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp40 = A_arbace_a2g_model_A_const_163; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp37, tmp39, c__1, tmp40.Ref(), m__3)) } else { var tmp41 *lang.Var; A_arbace_a2g_model_A_Init(); tmp41 = A_arbace_a2g_model_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O_O__O(ms__5, base__4)) { var tmp42 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp42 = A_arbace_a2g_model_A_const_161; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp44 = A_arbace_a2g_model_A_const_166; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp46 = A_arbace_a2g_model_A_const_147; var tmp47 any = tmp46.Ref(); var tmp48 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp48 = A_arbace_a2g_model_A_const_163; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, tmp47, c__1, tmp48.Ref(), m__3)) } else { var tmp49 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp49 = A_arbace_a2g_model_A_const_56; if tmp49 != nil { return nil } else { return nil } } } } else {
//line :369:1
							var tmp50 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp50 = A_arbace_a2g_model_A_const_56; if tmp50 != nil { var tmp51 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp51 = A_arbace_a2g_model_A_const_161; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp53 = A_arbace_a2g_model_A_const_167; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp55 = A_arbace_a2g_model_A_const_147; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp57 = A_arbace_a2g_model_A_const_163; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, tmp56, c__1, tmp57.Ref(), m__3)) } else { return nil } } } } else {
//line :367:1
								return nil } } else {
//line :366:1
									return nil } }













func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_Init(); t := &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) Invoke_O_O__O(self, s__1008000115__1 any) any { var tmp1 any = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1008000115__1); var tmp2 *jrt.Class; A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_Init(); tmp2 = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :380:1
func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_Init(); t := &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) Ctor_O_O_O_O(c__iter__1008000114, c__name, c__desc, c__s__1008000115 any) { t.F_iter__1008000114 = c__iter__1008000114; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1008000115 = c__s__1008000115 }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) Invoke_O__O(self any) any { { var s__1008000115__1 any; var t_ any = t.F_s__1008000115; t.F_s__1008000115 = nil; s__1008000115__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1008000115__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1008000115__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_140; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1008000115__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_141; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1008000115__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1008000117__6 any; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_142; b__1008000117__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_New_O_O_O_I_O(t.F_name, b__1008000117__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_Init(); tmp6 = A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_148; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_150; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1008000117__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1008000114); var tmp12 *lang.Var; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_151; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1008000115__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_148; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_150; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1008000117__6), nil) } } else { var c__4 any; var tmp16 *lang.Var; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_149; c__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1008000115__3); var tmp17 *lang.Var; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(c__4)) { var m__5 any; var tmp18 *lang.Var

	A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_159; m__5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O_O__O(c__4, t.F_name, t.F_desc)
//line :380:1
	var tmp19 any
	var and__1927000168__auto____6 any = m__5

	if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp20 *lang.Var; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_28; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_160; and__1927000168__auto____7 = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(m__5)); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp23 *lang.Var; A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_28; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_123; and__1927000168__auto____8 = tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(m__5)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp26 *lang.Var; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_28; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_124; tmp19 = tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(m__5)) } else { tmp19 = and__1927000168__auto____8 } } else { tmp19 = and__1927000168__auto____7 } } else { tmp19 = and__1927000168__auto____6 }
//line :380:1
	if jrt.A2g_Truth(tmp19) { var tmp29 any; var or__1927000174__auto____6 any; var tmp30 *lang.Var



		A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_28; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_model_A_Init(); tmp32 = A_arbace_a2g_model_A_const_86; or__1927000174__auto____6 = tmp31.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(c__4)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp29 = or__1927000174__auto____6 } else {
			var tmp33 *lang.Var; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_32; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_135; var tmp36 *lang.Keyword = tmp35; var tmp37 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp37 = A_arbace_a2g_model_A_const_88; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Var; A_arbace_a2g_model_A_Init(); tmp39 = A_arbace_a2g_model_A_const_31; var tmp40 any = jrt.NN(tmp36).Invoke_O__O(jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Get__O())); var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_266, nil); var tmp42 *lang.Var; A_arbace_a2g_model_A_Init(); tmp42 = A_arbace_a2g_model_A_const_89; var tmp43 any = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(c__4); var tmp44 *lang.Var; A_arbace_a2g_model_A_Init(); tmp44 = A_arbace_a2g_model_A_const_130; tmp29 = tmp34.Invoke_O_O__O(tmp40, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp41, jrt.RefArrayOf(jrt.Object_class, tmp43, nil, lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc))).Ref()) }
//line :380:1
		if jrt.A2g_Truth(tmp29) { var tmp45 *lang.Var; A_arbace_a2g_model_A_Init(); tmp45 = A_arbace_a2g_model_A_const_62; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp47 = A_arbace_a2g_model_A_const_161; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp49 = A_arbace_a2g_model_A_const_162; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp51 = A_arbace_a2g_model_A_const_147; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp53 = A_arbace_a2g_model_A_const_163; var tmp54 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp50, tmp52, c__4, tmp53.Ref(), m__5)); var tmp55 lang.IFn = lang.IFn_Cast(t.F_iter__1008000114); var tmp56 *lang.Var; A_arbace_a2g_model_A_Init(); tmp56 = A_arbace_a2g_model_A_const_152; return tmp46.Invoke_O_O__O(tmp54, tmp55.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(s__1008000115__3))) } else { var tmp57 *lang.Var; A_arbace_a2g_model_A_Init(); tmp57 = A_arbace_a2g_model_A_const_152; s__1008000115__1 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(s__1008000115__3); continue L1 } } else { var tmp58 *lang.Var; A_arbace_a2g_model_A_Init(); tmp58 = A_arbace_a2g_model_A_const_152; s__1008000115__1 = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(s__1008000115__3); continue L1 } } else { var tmp59 *lang.Var; A_arbace_a2g_model_A_Init(); tmp59 = A_arbace_a2g_model_A_const_152; s__1008000115__1 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(s__1008000115__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :380:1
func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_Init(); t := &A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) Ctor_O_O_O_I_O(c__name, c__b__1008000117, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1008000117 = c__b__1008000117; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :380:1
func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) Invoke_O__O(self any) any { { var i__1008000116__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1008000116__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1008000116__1)); var tmp2 *lang.Var; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(c__2)) { var m__3 any; var tmp3 *lang.Var

	A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_159; m__3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(c__2, t.F_name, t.F_desc)
//line :380:1
	var tmp4 any
	var and__1927000168__auto____4 any = m__3

	if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp5 *lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_28; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_160; and__1927000168__auto____5 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_28; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_123; and__1927000168__auto____6 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(m__3)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_28; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_124; tmp4 = tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(m__3)) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = and__1927000168__auto____5 } } else { tmp4 = and__1927000168__auto____4 }
//line :380:1
	if jrt.A2g_Truth(tmp4) { var tmp14 any; var or__1927000174__auto____4 any; var tmp15 *lang.Var



		A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_28; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_86; or__1927000174__auto____4 = tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(c__2)); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp14 = or__1927000174__auto____4 } else {
			var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_32; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_135; var tmp21 *lang.Keyword = tmp20; var tmp22 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_88; var tmp23 *lang.Keyword = tmp22; var tmp24 *lang.Var; A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_31; var tmp25 any = jrt.NN(tmp21).Invoke_O__O(jrt.NN(tmp23).Invoke_O__O(jrt.NN(tmp24).Get__O())); var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_266, nil); var tmp27 *lang.Var; A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_89; var tmp28 any = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(c__2); var tmp29 *lang.Var; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_130; tmp14 = tmp19.Invoke_O_O__O(tmp25, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp26, jrt.RefArrayOf(jrt.Object_class, tmp28, nil, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O__O(t.F_name, t.F_desc))).Ref()) }
//line :380:1
		if jrt.A2g_Truth(tmp14) { var tmp30 *lang.Var; A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_145; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = t.F_b__1008000117; var tmp33 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_161; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_162; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp37 = A_arbace_a2g_model_A_const_147; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp39 = A_arbace_a2g_model_A_const_163; tmp31.Invoke_O_O__O(tmp32, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, tmp38, c__2, tmp39.Ref(), m__3))); i__1008000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000116__1); continue L1 } else { i__1008000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000116__1); continue L1 } } else { i__1008000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000116__1); continue L1 } } else { i__1008000116__1 = lang.Numbers_Unchecked_inc_J__J(i__1008000116__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_a2g_model_impl_of_fn__1008000124_A_New_O(p0 any) *A_arbace_a2g_model_impl_of_fn__1008000124_A { A_arbace_a2g_model_impl_of_fn__1008000124_A_Init(); t := &A_arbace_a2g_model_impl_of_fn__1008000124_A{}; t.Ctor_O(p0); return t }
//line :387:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :387:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_New_O(x__1); var tmp4 *jrt.Class; A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_Init(); tmp4 = A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_cands) }
//line :387:1
func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_New_O(p0 any) *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A { A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_Init(); t := &A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A{}; t.Ctor_O(p0); return t }
//line :387:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :387:1
func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) Invoke_O_O__O(self, p1__1008000107_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_115; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_147; var tmp4 any = jrt.NN(tmp3).Invoke_O__O(p1__1008000107_SHARP___1); var tmp5 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_147; and__1927000168__auto____2 = tmp2.Invoke_O_O__O(tmp4, jrt.NN(tmp5).Invoke_O__O(t.F_x)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_169; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_147; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(p1__1008000107_SHARP___1); var tmp10 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_147; return tmp7.Invoke_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(t.F_x)) } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_model_trivial_init_QMARK__A_New() *A_arbace_a2g_model_trivial_init_QMARK__A { A_arbace_a2g_model_trivial_init_QMARK__A_Init(); t := &A_arbace_a2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_a2g_model_trivial_init_QMARK__A) Ctor() {}
//line :390:1
func (t *A_arbace_a2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cache__2 any; var tmp1 *lang.Keyword;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_170; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; cache__2 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()); var tmp4 /*line :396:1*/*lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_32; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_11; if jrt.A2g_Truth(tmp5.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(cache__2), n__0)) {
		var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_11; return lang.RT_Get_O_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(cache__2), n__0) } else {
//line :396:1
			var r__3 any; var tmp8 *lang.Var

			A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_28; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_34; if jrt.A2g_Truth(tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(n__0))) { jrt.Boolean_Init(); r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp11 *lang.Var; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_37; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(n__0), nil) { jrt.Boolean_Init(); r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp12 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_56; if tmp12 != nil { var d__3 any; var tmp13 *lang.Var


				A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_37; d__3 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(n__0)
//line :398:1
				var st__4 any; var tmp14 *lang.Var


				A_arbace_a2g_model_A_Init(); tmp14 = A_arbace_a2g_model_A_const_11; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_172; st__4 = tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(d__3))
//line :398:1
				var and__1927000168__auto____5 any; var tmp17 *lang.Var




				A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_41; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_173; and__1927000168__auto____5 = tmp18.Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(st__4)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp20 *lang.Var
					A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_41; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_174; and__1927000168__auto____6 = tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(st__4))
//line :403:1
					if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp23 *lang.Var

						A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_28; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_175; and__1927000168__auto____7 = tmp24.Invoke_O__O(jrt.NN(tmp25).Invoke_O__O(st__4))
//line :403:1
						if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp26 *lang.Var


							A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_28; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_176; and__1927000168__auto____8 = tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(st__4))
//line :403:1
							if jrt.A2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 bool; var tmp29 *lang.Keyword



								A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_78; or__1927000174__auto____9 = lang.Util_Identical_O_O__Z(jrt.NN(tmp29).Invoke_O__O(d__3), nil); if or__1927000174__auto____9 { r__3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9).Ref() } else { var tmp30 *lang.Var; A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_171; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp32 = A_arbace_a2g_model_A_const_78; r__3 = tmp31.Invoke_O__O(jrt.NN(tmp32).Invoke_O__O(d__3)) } } else {
//line :403:1
									r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :398:1
										r__3 = nil
									}
			}
			}






			var tmp33 *lang.Var; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_20; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_146; tmp34.Invoke_O_O_O_O__O(cache__2, jrt.NN(tmp35).GetRawRoot__O(), n__0, r__3)
//line :396:1
			return r__3 } }



















func A_arbace_a2g_model_top_class_A_New() *A_arbace_a2g_model_top_class_A { A_arbace_a2g_model_top_class_A_Init(); t := &A_arbace_a2g_model_top_class_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_a2g_model_top_class_A) Ctor() {}
//line :416:1
func (t *A_arbace_a2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_329); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_57; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_29; var tmp4 any = tmp3; return tmp2.Invoke_O_O_O__O(n__0, tmp4, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_a2g_model_pure_ctor_QMARK__A_New() *A_arbace_a2g_model_pure_ctor_QMARK__A { A_arbace_a2g_model_pure_ctor_QMARK__A_Init(); t := &A_arbace_a2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :418:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var tmp1 *lang.Var;




	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_37; d__5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__1); var ab__6 any; if
	jrt.A2g_Truth(d__5) { var tmp2 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_177; var tmp3 *lang.Keyword = tmp2; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_11; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_172; var tmp7 any = jrt.NN(tmp3).Invoke_O__O(tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(d__5))); var tmp8 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_114; ab__6 = lang.RT_Get_O_O__O(tmp7, lang.Tuple_Create_O_O__IPersistentVector(Lit_299, jrt.NN(tmp8).Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_34; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(c__1); if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp10 *lang.Var
		A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_178; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(c__1); var tmp12 *lang.Var; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_178; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__0))
//line :425:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var tmp13 *lang.Var

			A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_32; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_114; and__1927000168__auto____11 = tmp14.Invoke_O__O(tmp16.Invoke_O_O__O(seen__3, lang.Tuple_Create_O_O__IPersistentVector(c__1, jrt.NN(tmp17).Invoke_O__O(m__2))))
//line :425:1
			if jrt.A2g_Truth(and__1927000168__auto____11) { var seen__12 any; var tmp18 *lang.Var


				A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_12; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_114; seen__12 = tmp19.Invoke_O_O__O(seen__3, lang.Tuple_Create_O_O__IPersistentVector(c__1, jrt.NN(tmp20).Invoke_O__O(m__2)))
//line :425:1
				var call__13 any; var tmp21 *lang.Keyword



				A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_179; call__13 = jrt.NN(tmp21).Invoke_O__O(ab__6)
//line :425:1
				var sup__14 any; var tmp22 *lang.Keyword




				A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_78; sup__14 = jrt.NN(tmp22).Invoke_O__O(d__5)
//line :425:1
				var and__1927000168__auto____15 any; var tmp23 *lang.Var





				A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_41; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_184; and__1927000168__auto____15 = tmp24.Invoke_O__O(jrt.NN(tmp25).Invoke_O__O(ab__6)); if jrt.A2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var tmp26 *lang.Var
					A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_28; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_185; and__1927000168__auto____16 = tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(ab__6))
//line :431:1
					if jrt.A2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var tmp29 *lang.Var
							A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_42; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_New_O_O(n__0, seen__12); var tmp32 *jrt.Class; A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_Init(); tmp32 = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_fn_class; var tmp33 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp34 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp34 = A_arbace_a2g_model_A_const_186; and__1927000168__auto____18 = tmp30.Invoke_O_O__O(tmp33, jrt.NN(tmp34).Invoke_O__O(call__13)); if jrt.A2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool; var tmp35 *lang.Keyword
								A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_167; or__1927000174__auto____19 = lang.Util_Identical_O_O__Z(jrt.NN(tmp35).Invoke_O__O(call__13), nil); if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____19).Ref() } else { var or__1927000174__auto____20 any; var tmp36 any; A_arbace_a2g_model_A_Init(); tmp36 = A_arbace_a2g_model_A_const_180; var tmp37 lang.IFn = lang.IFn_Cast(tmp36); var tmp38 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp38 = A_arbace_a2g_model_A_const_167; or__1927000174__auto____20 = tmp37.Invoke_O__O(jrt.NN(tmp38).Invoke_O__O(call__13)); if jrt.A2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var tmp39 *lang.Var; A_arbace_a2g_model_A_Init(); tmp39 = A_arbace_a2g_model_A_const_181; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp41 = A_arbace_a2g_model_A_const_167; var tmp42 any = jrt.NN(tmp41).Invoke_O__O(call__13); var tmp43 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp43 = A_arbace_a2g_model_A_const_187; and__1927000168__auto____17 = tmp40.Invoke_O_O_O_O__O(n__0, tmp42, jrt.NN(tmp43).Invoke_O__O(call__13), seen__12) } } } else {
//line :434:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :431:1
						if jrt.A2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var tmp44 *lang.Var





							A_arbace_a2g_model_A_Init(); tmp44 = A_arbace_a2g_model_A_const_39; or__1927000174__auto____18 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(call__13); if jrt.A2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(sup__14, Lit_177)).Ref() } }
//line :431:1
							if jrt.A2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var tmp45 *lang.Var






								A_arbace_a2g_model_A_Init(); tmp45 = A_arbace_a2g_model_A_const_42; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_New_O_O(n__0, seen__12); var tmp48 *jrt.Class; A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_Init(); tmp48 = A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_fn_class; var tmp49 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil); var tmp50 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp50 = A_arbace_a2g_model_A_const_188; var tmp51 *lang.Keyword = tmp50; var tmp52 *lang.Var; A_arbace_a2g_model_A_Init(); tmp52 = A_arbace_a2g_model_A_const_11; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp54 = A_arbace_a2g_model_A_const_172; and__1927000168__auto____19 = tmp46.Invoke_O_O__O(tmp49, jrt.NN(tmp51).Invoke_O__O(tmp53.Invoke_O__O(jrt.NN(tmp54).Invoke_O__O(d__5))))
//line :431:1
								if jrt.A2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool; var tmp55 *lang.Keyword







									A_arbace_a2g_model_A_Init(); tmp55 = A_arbace_a2g_model_A_const_182; or__1927000174__auto____20_2 = lang.Util_Identical_O_O__Z(jrt.NN(tmp55).Invoke_O__O(ab__6), nil); if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____20_2).Ref() } else { var tmp56 *lang.Var; A_arbace_a2g_model_A_Init(); tmp56 = A_arbace_a2g_model_A_const_183; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp58 = A_arbace_a2g_model_A_const_182; return tmp57.Invoke_O_O_O__O(n__0, jrt.NN(tmp58).Invoke_O__O(ab__6), seen__12) } } else {
//line :431:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :425:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_Init(); t := &A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A{}; t.Ctor_O_O(p0, p1); return t }
//line :434:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :434:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) Invoke_O_O__O(self, p1__1008000131_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000131_SHARP___1, t.F_seen) }



func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_Init(); t := &A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A{}; t.Ctor_O_O(p0, p1); return t }
//line :438:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :438:1
func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) Invoke_O_O__O(self, p1__1008000132_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000132_SHARP___1, t.F_seen) }


func A_arbace_a2g_model_pure_node_QMARK__A_New() *A_arbace_a2g_model_pure_node_QMARK__A { A_arbace_a2g_model_pure_node_QMARK__A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :441:1
func (t *A_arbace_a2g_model_pure_node_QMARK__A) Ctor() {}
//line :441:1
func (t *A_arbace_a2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1008000144__4_ any; var tmp1 *lang.Keyword;



	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_189; G__1008000144__4_ = jrt.NN(tmp1).Invoke_O__O(node__1); switch lang.Util_Hash_O__I(G__1008000144__4_) >> 3 & 63 { case 1: var tmp2 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp2 = A_arbace_a2g_model_A_const_190; if any(G__1008000144__4_) == any(tmp2.Ref()) { var and__1927000168__auto____5 any; var tmp3 *lang.Var


















		A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_103; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_199; and__1927000168__auto____5 = tmp4.Invoke_O__O(jrt.NN(tmp5).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp6 *lang.Var; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_103; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_200; and__1927000168__auto____6 = tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp9 *lang.Var; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_183; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_201; return tmp10.Invoke_O_O_O__O(n__0, jrt.NN(tmp11).Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :445:1
	case 11: var tmp12 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_191; if any(G__1008000144__4_) == any(tmp12.Ref()) { var and__1927000168__auto____5_2 bool; var tmp13 *lang.Keyword







		A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_192; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_189; var tmp16 *lang.Keyword = tmp15; var tmp17 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp17 = A_arbace_a2g_model_A_const_193; and__1927000168__auto____5_2 = lang.Util_Equiv_O_O__Z(tmp14, jrt.NN(tmp16).Invoke_O__O(jrt.NN(tmp17).Invoke_O__O(node__1))); if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var tmp18 *lang.Var; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_41; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp20 = A_arbace_a2g_model_A_const_202; var tmp21 *lang.Keyword = tmp20; var tmp22 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_193; and__1927000168__auto____6_2 = tmp19.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(node__1))); if jrt.A2g_Truth(and__1927000168__auto____6_2) { var tmp23 *lang.Var; A_arbace_a2g_model_A_Init(); tmp23 = A_arbace_a2g_model_A_const_183; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_203; return tmp24.Invoke_O_O_O__O(n__0, jrt.NN(tmp25).Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() } }
//line :445:1
	case 13: var tmp26 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_194; if any(G__1008000144__4_) == any(tmp26.Ref()) { var and__1927000168__auto____5_3 bool; var tmp27 *lang.Keyword













		A_arbace_a2g_model_A_Init(); tmp27 = A_arbace_a2g_model_A_const_195; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_161; and__1927000168__auto____5_3 = lang.Util_Equiv_O_O__Z(tmp28, jrt.NN(tmp29).Invoke_O__O(node__1)); if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool; var tmp30 *lang.Keyword
			A_arbace_a2g_model_A_Init(); tmp30 = A_arbace_a2g_model_A_const_147; and__1927000168__auto____6_4 = lang.Util_Equiv_O_O__Z(Lit_303, jrt.NN(tmp30).Invoke_O__O(node__1)); if and__1927000168__auto____6_4 { var tmp31 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp31 = A_arbace_a2g_model_A_const_121; or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z(Lit_304, jrt.NN(tmp31).Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool; var tmp32 *lang.Keyword

				A_arbace_a2g_model_A_Init(); tmp32 = A_arbace_a2g_model_A_const_147; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z(n__0, jrt.NN(tmp32).Invoke_O__O(node__1)); if and__1927000168__auto____7 { var tmp33 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp33 = A_arbace_a2g_model_A_const_121; and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z(Lit_305, jrt.NN(tmp33).Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :459:1
			if and__1927000168__auto____6_3 {



				var tmp34 *lang.Var; A_arbace_a2g_model_A_Init(); tmp34 = A_arbace_a2g_model_A_const_42; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_New_O_O(n__0, seen__2); var tmp37 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_Init(); tmp37 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_fn_class; var tmp38 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); var tmp39 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp39 = A_arbace_a2g_model_A_const_186; return tmp35.Invoke_O_O__O(tmp38, jrt.NN(tmp39).Invoke_O__O(node__1)) } else {
//line :459:1
					return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_3).Ref() } }
//line :445:1
	case 14: var tmp40 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp40 = A_arbace_a2g_model_A_const_196; if any(G__1008000144__4_) == any(tmp40.Ref()) { var and__1927000168__auto____5_4 bool; var tmp41 any; var or__1927000174__auto____5 any; var tmp42 *lang.Keyword






		A_arbace_a2g_model_A_Init(); tmp42 = A_arbace_a2g_model_A_const_197; var tmp43 *lang.Keyword = tmp42; var tmp44 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp44 = A_arbace_a2g_model_A_const_198; or__1927000174__auto____5 = jrt.NN(tmp43).Invoke_O__O(jrt.NN(tmp44).Invoke_O__O(node__1)); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp41 = or__1927000174__auto____5 } else { var tmp45 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp45 = A_arbace_a2g_model_A_const_147; var tmp46 *lang.Keyword = tmp45; var tmp47 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp47 = A_arbace_a2g_model_A_const_198; tmp41 = jrt.NN(tmp46).Invoke_O__O(jrt.NN(tmp47).Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z(n__0, tmp41); if and__1927000168__auto____5_4 { var tmp48 *lang.Var; A_arbace_a2g_model_A_Init(); tmp48 = A_arbace_a2g_model_A_const_183; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp50 = A_arbace_a2g_model_A_const_203; return tmp49.Invoke_O_O_O__O(n__0, jrt.NN(tmp50).Invoke_O__O(node__1), seen__2) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_4).Ref() } }
//line :445:1
	case 15: var tmp51 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp51 = A_arbace_a2g_model_A_const_192; if any(G__1008000144__4_) == any(tmp51.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 19: var tmp52 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp52 = A_arbace_a2g_model_A_const_204; if any(G__1008000144__4_) == any(tmp52.Ref()) { var and__1927000168__auto____5_5 any; var tmp53 *lang.Var


		A_arbace_a2g_model_A_Init(); tmp53 = A_arbace_a2g_model_A_const_42; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_New_O_O(n__0, seen__2); var tmp56 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_Init(); tmp56 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_fn_class; var tmp57 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil); var tmp58 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp58 = A_arbace_a2g_model_A_const_206; and__1927000168__auto____5_5 = tmp54.Invoke_O_O__O(tmp57, jrt.NN(tmp58).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____5_5) { var tmp59 *lang.Var; A_arbace_a2g_model_A_Init(); tmp59 = A_arbace_a2g_model_A_const_183; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp61 = A_arbace_a2g_model_A_const_182; return tmp60.Invoke_O_O_O__O(n__0, jrt.NN(tmp61).Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____5_5 } }
//line :445:1
	case 21: var tmp62 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp62 = A_arbace_a2g_model_A_const_205; if any(G__1008000144__4_) == any(tmp62.Ref()) {





		var tmp63 any; var or__1927000174__auto____5_2 any; var tmp64 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp64 = A_arbace_a2g_model_A_const_197; var tmp65 *lang.Keyword = tmp64; var tmp66 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp66 = A_arbace_a2g_model_A_const_198; or__1927000174__auto____5_2 = jrt.NN(tmp65).Invoke_O__O(jrt.NN(tmp66).Invoke_O__O(node__1)); if jrt.A2g_Truth(or__1927000174__auto____5_2) { tmp63 = or__1927000174__auto____5_2 } else { var tmp67 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp67 = A_arbace_a2g_model_A_const_147; var tmp68 *lang.Keyword = tmp67; var tmp69 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp69 = A_arbace_a2g_model_A_const_198; tmp63 = jrt.NN(tmp68).Invoke_O__O(jrt.NN(tmp69).Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(n__0, tmp63)).Ref() }
//line :445:1
	case 25: var tmp70 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp70 = A_arbace_a2g_model_A_const_207; if any(G__1008000144__4_) == any(tmp70.Ref()) { var and__1927000168__auto____5_6 any; var tmp71 *lang.Var

		A_arbace_a2g_model_A_Init(); tmp71 = A_arbace_a2g_model_A_const_42; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_New_O_O(n__0, seen__2); var tmp74 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_Init(); tmp74 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_fn_class; var tmp75 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp73, tmp74, nil); var tmp76 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp76 = A_arbace_a2g_model_A_const_209; and__1927000168__auto____5_6 = tmp72.Invoke_O_O__O(tmp75, jrt.NN(tmp76).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____5_6) { var tmp77 *lang.Var; A_arbace_a2g_model_A_Init(); tmp77 = A_arbace_a2g_model_A_const_183; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp79 = A_arbace_a2g_model_A_const_210; return tmp78.Invoke_O_O_O__O(n__0, jrt.NN(tmp79).Invoke_O__O(node__1), seen__2) } else { return and__1927000168__auto____5_6 } }
//line :445:1
	case 29: var tmp80 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp80 = A_arbace_a2g_model_A_const_208; if any(G__1008000144__4_) == any(tmp80.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 30: var tmp81 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp81 = A_arbace_a2g_model_A_const_211; if any(G__1008000144__4_) == any(tmp81.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 34: var tmp82 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp82 = A_arbace_a2g_model_A_const_212; if any(G__1008000144__4_) == any(tmp82.Ref()) {




		var tmp83 *lang.Var; A_arbace_a2g_model_A_Init(); tmp83 = A_arbace_a2g_model_A_const_42; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_New(); var tmp86 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_Init(); tmp86 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_fn_class; var tmp87 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil); var tmp88 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp88 = A_arbace_a2g_model_A_const_216; return tmp84.Invoke_O_O__O(tmp87, jrt.NN(tmp88).Invoke_O__O(node__1)) }
//line :445:1
	case 39: var tmp89 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp89 = A_arbace_a2g_model_A_const_213; if any(G__1008000144__4_) == any(tmp89.Ref()) { var and__1927000168__auto____5_7 any; var tmp90 *lang.Var








		A_arbace_a2g_model_A_Init(); tmp90 = A_arbace_a2g_model_A_const_42; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_New_O_O(n__0, seen__2); var tmp93 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_Init(); tmp93 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_fn_class; var tmp94 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp92, tmp93, nil); var tmp95 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp95 = A_arbace_a2g_model_A_const_186; and__1927000168__auto____5_7 = tmp91.Invoke_O_O__O(tmp94, jrt.NN(tmp95).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool; var tmp96 *lang.Keyword
			A_arbace_a2g_model_A_Init(); tmp96 = A_arbace_a2g_model_A_const_214; and__1927000168__auto____6_5 = lang.Util_Identical_O_O__Z(jrt.NN(tmp96).Invoke_O__O(node__1), nil)
//line :454:1
			if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool; var tmp97 *lang.Keyword

				A_arbace_a2g_model_A_Init(); tmp97 = A_arbace_a2g_model_A_const_167; or__1927000174__auto____7 = lang.Util_Equiv_O_O__Z(Lit_177, jrt.NN(tmp97).Invoke_O__O(node__1)); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool; var tmp98 *lang.Keyword
					A_arbace_a2g_model_A_Init(); tmp98 = A_arbace_a2g_model_A_const_167; or__1927000174__auto____8 = lang.Util_Equiv_O_O__Z(jrt.NN(tmp98).Invoke_O__O(node__1), n__0); if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var tmp99 *lang.Var; A_arbace_a2g_model_A_Init(); tmp99 = A_arbace_a2g_model_A_const_171; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp101 = A_arbace_a2g_model_A_const_167; and__1927000168__auto____8 = tmp100.Invoke_O__O(jrt.NN(tmp101).Invoke_O__O(node__1)) }; if jrt.A2g_Truth(and__1927000168__auto____8) {
						var tmp102 *lang.Var; A_arbace_a2g_model_A_Init(); tmp102 = A_arbace_a2g_model_A_const_181; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp104 = A_arbace_a2g_model_A_const_167; var tmp105 any = jrt.NN(tmp104).Invoke_O__O(node__1); var tmp106 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp106 = A_arbace_a2g_model_A_const_187; return tmp103.Invoke_O_O_O_O__O(n__0, tmp105, jrt.NN(tmp106).Invoke_O__O(node__1), seen__2) } else {
//line :457:1
							return and__1927000168__auto____8 } } } else {
//line :454:1
								return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :445:1
	case 43: var tmp107 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp107 = A_arbace_a2g_model_A_const_217; if any(G__1008000144__4_) == any(tmp107.Ref()) { var and__1927000168__auto____5_8 any; var tmp108 *lang.Var



















		A_arbace_a2g_model_A_Init(); tmp108 = A_arbace_a2g_model_A_const_28; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 any; A_arbace_a2g_model_A_Init(); tmp110 = A_arbace_a2g_model_A_const_219; var tmp111 lang.IFn = lang.IFn_Cast(tmp110); var tmp112 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp112 = A_arbace_a2g_model_A_const_220; and__1927000168__auto____5_8 = tmp109.Invoke_O__O(tmp111.Invoke_O__O(jrt.NN(tmp112).Invoke_O__O(node__1))); if jrt.A2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var tmp113 *lang.Var; A_arbace_a2g_model_A_Init(); tmp113 = A_arbace_a2g_model_A_const_115; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp115 = A_arbace_a2g_model_A_const_221; var tmp116 any = tmp115.Ref(); var tmp117 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp117 = A_arbace_a2g_model_A_const_222; and__1927000168__auto____6_6 = tmp114.Invoke_O_O__O(tmp116, jrt.NN(tmp117).Invoke_O__O(node__1)); if jrt.A2g_Truth(and__1927000168__auto____6_6) { var tmp118 *lang.Var; A_arbace_a2g_model_A_Init(); tmp118 = A_arbace_a2g_model_A_const_42; var tmp119 lang.IFn = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()); var tmp120 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_New_O_O(n__0, seen__2); var tmp121 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_Init(); tmp121 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_fn_class; var tmp122 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp120, tmp121, nil); var tmp123 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp123 = A_arbace_a2g_model_A_const_186; return tmp119.Invoke_O_O__O(tmp122, jrt.NN(tmp123).Invoke_O__O(node__1)) } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :445:1
	case 44: var tmp124 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp124 = A_arbace_a2g_model_A_const_218; if any(G__1008000144__4_) == any(tmp124.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 46: var tmp125 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp125 = A_arbace_a2g_model_A_const_223; if any(G__1008000144__4_) == any(tmp125.Ref()) {



		var tmp126 *lang.Var; A_arbace_a2g_model_A_Init(); tmp126 = A_arbace_a2g_model_A_const_42; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 any = A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_New_O_O(n__0, seen__2); var tmp129 *jrt.Class; A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_Init(); tmp129 = A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_fn_class; var tmp130 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp128, tmp129, nil); var tmp131 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp131 = A_arbace_a2g_model_A_const_224; return tmp127.Invoke_O_O__O(tmp130, jrt.NN(tmp131).Invoke_O__O(node__1)) }
//line :445:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A{}; t.Ctor_O_O(p0, p1); return t }
//line :447:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :447:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) Invoke_O_O__O(self, p1__1008000138_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000138_SHARP___1, t.F_seen) }
func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :448:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :448:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) Invoke_O_O__O(self, p__1008000147__1 any) any { var vec__1008000149__2 any = p__1008000147__1; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1008000149__2, lang.RT_IntCast_J__I(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O(vec__1008000149__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___3; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, init__4, t.F_seen) }
func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A{}; t.Ctor_O_O(p0, p1); return t }
//line :449:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :449:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) Invoke_O_O__O(self, p1__1008000139_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000139_SHARP___1, t.F_seen) }
func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_New() *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A{}; t.Ctor(); return t }
//line :450:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) Ctor() {}
//line :450:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) Invoke_O_O__O(self, p1__1008000140_SHARP___1 any) any { var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_208; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_189; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__1008000140_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var tmp4 *lang.Var; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_215; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp6 = A_arbace_a2g_model_A_const_203; and__1927000168__auto____3 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p1__1008000140_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_203; return tmp8.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(lang.RT_LongCast_O__J(jrt.NN(tmp9).Invoke_O__O(p1__1008000140_SHARP___1)))).Ref()) } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }



func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A{}; t.Ctor_O_O(p0, p1); return t }
//line :454:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :454:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) Invoke_O_O__O(self, p1__1008000141_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000141_SHARP___1, t.F_seen) }








func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :463:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :463:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) Invoke_O_O__O(self, p1__1008000142_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000142_SHARP___1, t.F_seen) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_New_O_O(p0, p1 any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A { A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_Init(); t := &A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A{}; t.Ctor_O_O(p0, p1); return t }
//line :465:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :465:1
func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) Invoke_O_O__O(self, p1__1008000143_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, p1__1008000143_SHARP___1, t.F_seen) }


func A_arbace_a2g_model_benign_init_QMARK__A_New() *A_arbace_a2g_model_benign_init_QMARK__A { A_arbace_a2g_model_benign_init_QMARK__A_Init(); t := &A_arbace_a2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_a2g_model_benign_init_QMARK__A) Ctor() {}
//line :468:1
func (t *A_arbace_a2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cache__2 any; var tmp1 *lang.Keyword;






	A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_170; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_model_A_Init(); tmp3 = A_arbace_a2g_model_A_const_31; cache__2 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()); var k__3 any; var tmp4 /*line :468:1*/*lang.Keyword; A_arbace_a2g_model_A_Init(); tmp4 = A_arbace_a2g_model_A_const_226; k__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp4.Ref(), n__0); var tmp5 /*line :477:1*/*lang.Var; A_arbace_a2g_model_A_Init(); tmp5 = A_arbace_a2g_model_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_model_A_Init(); tmp7 = A_arbace_a2g_model_A_const_11; if jrt.A2g_Truth(tmp6.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(cache__2), k__3)) {
		var tmp8 *lang.Var; A_arbace_a2g_model_A_Init(); tmp8 = A_arbace_a2g_model_A_const_11; return lang.RT_Get_O_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(cache__2), k__3) } else {
//line :477:1
			var r__4 any; var tmp9 *lang.Var

			A_arbace_a2g_model_A_Init(); tmp9 = A_arbace_a2g_model_A_const_171; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp10 *lang.Var; A_arbace_a2g_model_A_Init(); tmp10 = A_arbace_a2g_model_A_const_37; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(n__0), nil) { jrt.Boolean_Init(); r__4 = jrt.Boolean_FALSE.Ref() } else { var tmp11 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp11 = A_arbace_a2g_model_A_const_56; if tmp11 != nil { var d__4 any; var tmp12 *lang.Var


				A_arbace_a2g_model_A_Init(); tmp12 = A_arbace_a2g_model_A_const_37; d__4 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__0)
//line :479:1
				var st__5 any; var tmp13 *lang.Var


				A_arbace_a2g_model_A_Init(); tmp13 = A_arbace_a2g_model_A_const_11; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp15 = A_arbace_a2g_model_A_const_172; st__5 = tmp14.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(d__4))
//line :479:1
				var and__1927000168__auto____6 any; var tmp16 *lang.Var




				A_arbace_a2g_model_A_Init(); tmp16 = A_arbace_a2g_model_A_const_41; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp18 = A_arbace_a2g_model_A_const_174; and__1927000168__auto____6 = tmp17.Invoke_O__O(jrt.NN(tmp18).Invoke_O__O(st__5)); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp19 *lang.Var
					A_arbace_a2g_model_A_Init(); tmp19 = A_arbace_a2g_model_A_const_28; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp21 = A_arbace_a2g_model_A_const_175; and__1927000168__auto____7 = tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(st__5))
//line :484:1
					if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp22 *lang.Var

						A_arbace_a2g_model_A_Init(); tmp22 = A_arbace_a2g_model_A_const_28; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp24 = A_arbace_a2g_model_A_const_176; and__1927000168__auto____8 = tmp23.Invoke_O__O(jrt.NN(tmp24).Invoke_O__O(st__5))
//line :484:1
						if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool; var tmp25 *lang.Keyword


							A_arbace_a2g_model_A_Init(); tmp25 = A_arbace_a2g_model_A_const_78; or__1927000174__auto____9 = lang.Util_Identical_O_O__Z(jrt.NN(tmp25).Invoke_O__O(d__4), nil); if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9).Ref() } else { var tmp26 *lang.Var; A_arbace_a2g_model_A_Init(); tmp26 = A_arbace_a2g_model_A_const_225; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp28 = A_arbace_a2g_model_A_const_78; and__1927000168__auto____9 = tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(d__4)) }
//line :484:1
							if jrt.A2g_Truth(and__1927000168__auto____9) {



								var tmp29 *lang.Var; A_arbace_a2g_model_A_Init(); tmp29 = A_arbace_a2g_model_A_const_42; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_New_O(n__0); var tmp32 *jrt.Class; A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_Init(); tmp32 = A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_fn_class; var tmp33 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp34 *lang.Keyword; A_arbace_a2g_model_A_Init(); tmp34 = A_arbace_a2g_model_A_const_173; r__4 = tmp30.Invoke_O_O__O(tmp33, jrt.NN(tmp34).Invoke_O__O(st__5)) } else {
//line :484:1
									r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :479:1
										r__4 = nil
									}
			}
			}






			var tmp35 *lang.Var; A_arbace_a2g_model_A_Init(); tmp35 = A_arbace_a2g_model_A_const_20; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_model_A_Init(); tmp37 = A_arbace_a2g_model_A_const_146; tmp36.Invoke_O_O_O_O__O(cache__2, jrt.NN(tmp37).GetRawRoot__O(), k__3, r__4)
//line :477:1
			return r__4 } }










func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_New_O(p0 any) *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A { A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_Init(); t := &A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A{}; t.Ctor_O(p0); return t }
//line :488:1
func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :488:1
func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) Invoke_O_O__O(self, p1__1008000164_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_model_A_Init(); tmp1 = A_arbace_a2g_model_A_const_183; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_n; var tmp4 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp4 = lang.PersistentHashSet_EMPTY; return tmp2.Invoke_O_O_O__O(tmp3, p1__1008000164_SHARP___1, tmp4.Ref()) }


































































type A_arbace_a2g_model_A struct{ jrt.Object }

var A_arbace_a2g_model_A_const_0 *lang.Var

var A_arbace_a2g_model_A_const_1 *lang.Var

var A_arbace_a2g_model_A_const_2 any

var A_arbace_a2g_model_A_const_3 any

var A_arbace_a2g_model_A_const_4 any

var A_arbace_a2g_model_A_const_5 any

var A_arbace_a2g_model_A_const_6 any

var A_arbace_a2g_model_A_const_7 any

var A_arbace_a2g_model_A_const_8 any

var A_arbace_a2g_model_A_const_9 any

var A_arbace_a2g_model_A_const_10 *lang.Var

var A_arbace_a2g_model_A_const_11 *lang.Var

var A_arbace_a2g_model_A_const_12 *lang.Var

var A_arbace_a2g_model_A_const_13 any

var A_arbace_a2g_model_A_const_14 *lang.Var

var A_arbace_a2g_model_A_const_15 *lang.Var

var A_arbace_a2g_model_A_const_16 *lang.Var

var A_arbace_a2g_model_A_const_17 *lang.Var

var A_arbace_a2g_model_A_const_18 *lang.Var

var A_arbace_a2g_model_A_const_19 *lang.Var

var A_arbace_a2g_model_A_const_20 *lang.Var

var A_arbace_a2g_model_A_const_21 *lang.Var

var A_arbace_a2g_model_A_const_22 *lang.Var

var A_arbace_a2g_model_A_const_23 *lang.Var

var A_arbace_a2g_model_A_const_24 any

var A_arbace_a2g_model_A_const_25 *lang.Var

var A_arbace_a2g_model_A_const_26 *lang.Var

var A_arbace_a2g_model_A_const_27 *lang.Var

var A_arbace_a2g_model_A_const_28 *lang.Var

var A_arbace_a2g_model_A_const_29 any

var A_arbace_a2g_model_A_const_30 *lang.Keyword

var A_arbace_a2g_model_A_const_31 *lang.Var

var A_arbace_a2g_model_A_const_32 *lang.Var

var A_arbace_a2g_model_A_const_33 *lang.Var

var A_arbace_a2g_model_A_const_34 *lang.Var

var A_arbace_a2g_model_A_const_35 *lang.Keyword

var A_arbace_a2g_model_A_const_36 *lang.Var

var A_arbace_a2g_model_A_const_37 *lang.Var

var A_arbace_a2g_model_A_const_38 *lang.Var

var A_arbace_a2g_model_A_const_39 *lang.Var

var A_arbace_a2g_model_A_const_40 *lang.Var

var A_arbace_a2g_model_A_const_41 *lang.Var

var A_arbace_a2g_model_A_const_42 *lang.Var

var A_arbace_a2g_model_A_const_43 *lang.Var

var A_arbace_a2g_model_A_const_44 *lang.Var

var A_arbace_a2g_model_A_const_45 *lang.Var

var A_arbace_a2g_model_A_const_46 *lang.Keyword

var A_arbace_a2g_model_A_const_47 any

var A_arbace_a2g_model_A_const_48 *lang.Keyword

var A_arbace_a2g_model_A_const_49 *lang.Var

var A_arbace_a2g_model_A_const_50 *lang.Var

var A_arbace_a2g_model_A_const_51 *lang.Keyword

var A_arbace_a2g_model_A_const_52 *lang.Var

var A_arbace_a2g_model_A_const_53 *lang.Var

var A_arbace_a2g_model_A_const_54 *lang.Var

var A_arbace_a2g_model_A_const_55 *lang.Var

var A_arbace_a2g_model_A_const_56 *lang.Keyword

var A_arbace_a2g_model_A_const_57 *lang.Var

var A_arbace_a2g_model_A_const_58 *lang.Var

var A_arbace_a2g_model_A_const_59 *lang.Var

var A_arbace_a2g_model_A_const_60 *lang.Var

var A_arbace_a2g_model_A_const_61 *lang.Var

var A_arbace_a2g_model_A_const_62 *lang.Var

var A_arbace_a2g_model_A_const_63 *lang.Var

var A_arbace_a2g_model_A_const_64 *lang.Var

var A_arbace_a2g_model_A_const_65 *lang.Var

var A_arbace_a2g_model_A_const_66 *lang.Keyword

var A_arbace_a2g_model_A_const_67 *lang.Var

var A_arbace_a2g_model_A_const_68 *lang.Keyword

var A_arbace_a2g_model_A_const_69 *lang.Var

var A_arbace_a2g_model_A_const_70 *lang.Var

var A_arbace_a2g_model_A_const_71 *lang.Var

var A_arbace_a2g_model_A_const_72 any

var A_arbace_a2g_model_A_const_73 any

var A_arbace_a2g_model_A_const_74 *lang.Keyword

var A_arbace_a2g_model_A_const_75 *lang.Var

var A_arbace_a2g_model_A_const_76 *lang.Var

var A_arbace_a2g_model_A_const_77 *lang.Var

var A_arbace_a2g_model_A_const_78 *lang.Keyword

var A_arbace_a2g_model_A_const_79 *lang.Var

var A_arbace_a2g_model_A_const_80 *lang.Var

var A_arbace_a2g_model_A_const_81 *lang.Var

var A_arbace_a2g_model_A_const_82 *lang.Var

var A_arbace_a2g_model_A_const_83 *lang.Var

var A_arbace_a2g_model_A_const_84 *lang.Var

var A_arbace_a2g_model_A_const_85 *lang.Var

var A_arbace_a2g_model_A_const_86 *lang.Var

var A_arbace_a2g_model_A_const_87 *lang.Keyword

var A_arbace_a2g_model_A_const_88 *lang.Keyword

var A_arbace_a2g_model_A_const_89 *lang.Var

var A_arbace_a2g_model_A_const_90 *lang.Var

var A_arbace_a2g_model_A_const_91 *lang.Var

var A_arbace_a2g_model_A_const_92 *lang.Var

var A_arbace_a2g_model_A_const_93 *lang.Var

var A_arbace_a2g_model_A_const_94 *lang.Var

var A_arbace_a2g_model_A_const_95 *lang.Var

var A_arbace_a2g_model_A_const_96 *lang.Var

var A_arbace_a2g_model_A_const_97 *lang.Var

var A_arbace_a2g_model_A_const_98 *lang.Var

var A_arbace_a2g_model_A_const_99 *lang.Keyword

var A_arbace_a2g_model_A_const_100 any

var A_arbace_a2g_model_A_const_101 *lang.Var

var A_arbace_a2g_model_A_const_102 any

var A_arbace_a2g_model_A_const_103 *lang.Var

var A_arbace_a2g_model_A_const_104 *lang.Var

var A_arbace_a2g_model_A_const_105 any

var A_arbace_a2g_model_A_const_106 *lang.Var

var A_arbace_a2g_model_A_const_107 *lang.Var

var A_arbace_a2g_model_A_const_108 any

var A_arbace_a2g_model_A_const_109 *lang.Var

var A_arbace_a2g_model_A_const_110 *lang.Var

var A_arbace_a2g_model_A_const_111 any

var A_arbace_a2g_model_A_const_112 any

var A_arbace_a2g_model_A_const_113 *lang.Var

var A_arbace_a2g_model_A_const_114 *lang.Keyword

var A_arbace_a2g_model_A_const_115 *lang.Var

var A_arbace_a2g_model_A_const_116 *lang.Var

var A_arbace_a2g_model_A_const_117 *lang.Var

var A_arbace_a2g_model_A_const_118 any

var A_arbace_a2g_model_A_const_119 any

var A_arbace_a2g_model_A_const_120 *lang.Keyword

var A_arbace_a2g_model_A_const_121 *lang.Keyword

var A_arbace_a2g_model_A_const_122 *lang.Var

var A_arbace_a2g_model_A_const_123 *lang.Var

var A_arbace_a2g_model_A_const_124 *lang.Var

var A_arbace_a2g_model_A_const_125 *lang.Var

var A_arbace_a2g_model_A_const_126 *lang.Var

var A_arbace_a2g_model_A_const_127 *lang.Var

var A_arbace_a2g_model_A_const_128 *lang.Var

var A_arbace_a2g_model_A_const_129 *lang.Var

var A_arbace_a2g_model_A_const_130 *lang.Var

var A_arbace_a2g_model_A_const_131 *lang.Var

var A_arbace_a2g_model_A_const_132 *lang.Var

var A_arbace_a2g_model_A_const_133 *lang.Var

var A_arbace_a2g_model_A_const_134 *lang.Var

var A_arbace_a2g_model_A_const_135 *lang.Keyword

var A_arbace_a2g_model_A_const_136 *lang.Var

var A_arbace_a2g_model_A_const_137 any

var A_arbace_a2g_model_A_const_138 *lang.Var

var A_arbace_a2g_model_A_const_139 *lang.Var

var A_arbace_a2g_model_A_const_140 *lang.Var

var A_arbace_a2g_model_A_const_141 *lang.Var

var A_arbace_a2g_model_A_const_142 *lang.Var

var A_arbace_a2g_model_A_const_143 *lang.Var

var A_arbace_a2g_model_A_const_144 *lang.Var

var A_arbace_a2g_model_A_const_145 *lang.Var

var A_arbace_a2g_model_A_const_146 *lang.Var

var A_arbace_a2g_model_A_const_147 *lang.Keyword

var A_arbace_a2g_model_A_const_148 *lang.Var

var A_arbace_a2g_model_A_const_149 *lang.Var

var A_arbace_a2g_model_A_const_150 *lang.Var

var A_arbace_a2g_model_A_const_151 *lang.Var

var A_arbace_a2g_model_A_const_152 *lang.Var

var A_arbace_a2g_model_A_const_153 *lang.Keyword

var A_arbace_a2g_model_A_const_154 *lang.Var

var A_arbace_a2g_model_A_const_155 *lang.Var

var A_arbace_a2g_model_A_const_156 *lang.Var

var A_arbace_a2g_model_A_const_157 *lang.Var

var A_arbace_a2g_model_A_const_158 *lang.Var

var A_arbace_a2g_model_A_const_159 *lang.Var

var A_arbace_a2g_model_A_const_160 *lang.Var

var A_arbace_a2g_model_A_const_161 *lang.Keyword

var A_arbace_a2g_model_A_const_162 *lang.Keyword

var A_arbace_a2g_model_A_const_163 *lang.Keyword

var A_arbace_a2g_model_A_const_164 *lang.Keyword

var A_arbace_a2g_model_A_const_165 *lang.Keyword

var A_arbace_a2g_model_A_const_166 *lang.Keyword

var A_arbace_a2g_model_A_const_167 *lang.Keyword

var A_arbace_a2g_model_A_const_168 *lang.Var

var A_arbace_a2g_model_A_const_169 *lang.Var

var A_arbace_a2g_model_A_const_170 *lang.Keyword

var A_arbace_a2g_model_A_const_171 *lang.Var

var A_arbace_a2g_model_A_const_172 *lang.Keyword

var A_arbace_a2g_model_A_const_173 *lang.Keyword

var A_arbace_a2g_model_A_const_174 *lang.Keyword

var A_arbace_a2g_model_A_const_175 *lang.Keyword

var A_arbace_a2g_model_A_const_176 *lang.Keyword

var A_arbace_a2g_model_A_const_177 *lang.Keyword

var A_arbace_a2g_model_A_const_178 *lang.Var

var A_arbace_a2g_model_A_const_179 *lang.Keyword

var A_arbace_a2g_model_A_const_180 any

var A_arbace_a2g_model_A_const_181 *lang.Var

var A_arbace_a2g_model_A_const_182 *lang.Keyword

var A_arbace_a2g_model_A_const_183 *lang.Var

var A_arbace_a2g_model_A_const_184 *lang.Keyword

var A_arbace_a2g_model_A_const_185 *lang.Keyword

var A_arbace_a2g_model_A_const_186 *lang.Keyword

var A_arbace_a2g_model_A_const_187 *lang.Keyword

var A_arbace_a2g_model_A_const_188 *lang.Keyword

var A_arbace_a2g_model_A_const_189 *lang.Keyword

var A_arbace_a2g_model_A_const_190 *lang.Keyword

var A_arbace_a2g_model_A_const_191 *lang.Keyword

var A_arbace_a2g_model_A_const_192 *lang.Keyword

var A_arbace_a2g_model_A_const_193 *lang.Keyword

var A_arbace_a2g_model_A_const_194 *lang.Keyword

var A_arbace_a2g_model_A_const_195 *lang.Keyword

var A_arbace_a2g_model_A_const_196 *lang.Keyword

var A_arbace_a2g_model_A_const_197 *lang.Keyword

var A_arbace_a2g_model_A_const_198 *lang.Keyword

var A_arbace_a2g_model_A_const_199 *lang.Keyword

var A_arbace_a2g_model_A_const_200 *lang.Keyword

var A_arbace_a2g_model_A_const_201 *lang.Keyword

var A_arbace_a2g_model_A_const_202 *lang.Keyword

var A_arbace_a2g_model_A_const_203 *lang.Keyword

var A_arbace_a2g_model_A_const_204 *lang.Keyword

var A_arbace_a2g_model_A_const_205 *lang.Keyword

var A_arbace_a2g_model_A_const_206 *lang.Keyword

var A_arbace_a2g_model_A_const_207 *lang.Keyword

var A_arbace_a2g_model_A_const_208 *lang.Keyword

var A_arbace_a2g_model_A_const_209 *lang.Keyword

var A_arbace_a2g_model_A_const_210 *lang.Keyword

var A_arbace_a2g_model_A_const_211 *lang.Keyword

var A_arbace_a2g_model_A_const_212 *lang.Keyword

var A_arbace_a2g_model_A_const_213 *lang.Keyword

var A_arbace_a2g_model_A_const_214 *lang.Keyword

var A_arbace_a2g_model_A_const_215 *lang.Var

var A_arbace_a2g_model_A_const_216 *lang.Keyword

var A_arbace_a2g_model_A_const_217 *lang.Keyword

var A_arbace_a2g_model_A_const_218 *lang.Keyword

var A_arbace_a2g_model_A_const_219 any

var A_arbace_a2g_model_A_const_220 *lang.Keyword

var A_arbace_a2g_model_A_const_221 *lang.Keyword

var A_arbace_a2g_model_A_const_222 *lang.Keyword

var A_arbace_a2g_model_A_const_223 *lang.Keyword

var A_arbace_a2g_model_A_const_224 *lang.Keyword

var A_arbace_a2g_model_A_const_225 *lang.Var

var A_arbace_a2g_model_A_const_226 *lang.Keyword

var A_arbace_a2g_model_A_init jrt.ClassInit

func A_arbace_a2g_model_A_Init() { if !A_arbace_a2g_model_A_init.Done() { A_arbace_a2g_model_A_init.Run(A_arbace_a2g_model_A_clinit) } }

func A_arbace_a2g_model_A_clinit() { A_arbace_a2g_model_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_model_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_model_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_model_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_model_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_model_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_model_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_model_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_a2g_model_A_const_8 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref()); A_arbace_a2g_model_A_const_9 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref()); A_arbace_a2g_model_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_model_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_a2g_model_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_model_A_const_13 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_21)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), Lit_23))); A_arbace_a2g_model_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_model_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_a2g_model_A_const_16 = lang.RT_Var_String_String__Var(Lit_21, Lit_26); A_arbace_a2g_model_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_a2g_model_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_model_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_model_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_model_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_model_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_model_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_model_A_const_24 = jrt.Long_ValueOf_J__Long(-1).Ref(); A_arbace_a2g_model_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_model_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_model_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_model_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_model_A_const_29 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_model_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_a2g_model_A_const_31 = lang.RT_Var_String_String__Var(Lit_21, Lit_39); A_arbace_a2g_model_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_model_A_const_33 = lang.RT_Var_String_String__Var(Lit_21, Lit_38); A_arbace_a2g_model_A_const_34 = lang.RT_Var_String_String__Var(Lit_21, Lit_41); A_arbace_a2g_model_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_a2g_model_A_const_36 = lang.RT_Var_String_String__Var(Lit_21, Lit_43); A_arbace_a2g_model_A_const_37 = lang.RT_Var_String_String__Var(Lit_10, Lit_44); A_arbace_a2g_model_A_const_38 = lang.RT_Var_String_String__Var(Lit_3, Lit_45); A_arbace_a2g_model_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_a2g_model_A_const_40 = lang.RT_Var_String_String__Var(Lit_8, Lit_47); A_arbace_a2g_model_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_a2g_model_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_a2g_model_A_const_43 = lang.RT_Var_String_String__Var(Lit_3, Lit_50); A_arbace_a2g_model_A_const_44 = lang.RT_Var_String_String__Var(Lit_8, Lit_51); A_arbace_a2g_model_A_const_45 = lang.RT_Var_String_String__Var(Lit_21, Lit_52); A_arbace_a2g_model_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_a2g_model_A_const_47 = jrt.Long_ValueOf_J__Long(8192).Ref(); A_arbace_a2g_model_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_a2g_model_A_const_49 = lang.RT_Var_String_String__Var(Lit_21, Lit_55); A_arbace_a2g_model_A_const_50 = lang.RT_Var_String_String__Var(Lit_21, Lit_56); A_arbace_a2g_model_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_a2g_model_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_model_A_const_53 = lang.RT_Var_String_String__Var(Lit_6, Lit_59); A_arbace_a2g_model_A_const_54 = lang.RT_Var_String_String__Var(Lit_21, Lit_60); A_arbace_a2g_model_A_const_55 = lang.RT_Var_String_String__Var(Lit_6, Lit_61); A_arbace_a2g_model_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_62); A_arbace_a2g_model_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_a2g_model_A_const_58 = lang.RT_Var_String_String__Var(Lit_6, Lit_64); A_arbace_a2g_model_A_const_59 = lang.RT_Var_String_String__Var(Lit_6, Lit_65); A_arbace_a2g_model_A_const_60 = lang.RT_Var_String_String__Var(Lit_6, Lit_66); A_arbace_a2g_model_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_a2g_model_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_a2g_model_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_a2g_model_A_const_64 = lang.RT_Var_String_String__Var(Lit_6, Lit_70); A_arbace_a2g_model_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_a2g_model_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_a2g_model_A_const_67 = lang.RT_Var_String_String__Var(Lit_21, Lit_73); A_arbace_a2g_model_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_a2g_model_A_const_69 = lang.RT_Var_String_String__Var(Lit_12, Lit_75); A_arbace_a2g_model_A_const_70 = lang.RT_Var_String_String__Var(Lit_12, Lit_76); A_arbace_a2g_model_A_const_71 = lang.RT_Var_String_String__Var(Lit_21, Lit_51); A_arbace_a2g_model_A_const_72 = jrt.Integer_ValueOf_I__Integer(1024).Ref(); A_arbace_a2g_model_A_const_73 = jrt.Integer_ValueOf_I__Integer(16).Ref(); A_arbace_a2g_model_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_a2g_model_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_a2g_model_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_a2g_model_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_a2g_model_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_81); A_arbace_a2g_model_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_a2g_model_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_a2g_model_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_a2g_model_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_a2g_model_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_a2g_model_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_model_A_const_85 = lang.RT_Var_String_String__Var(Lit_21, Lit_47); A_arbace_a2g_model_A_const_86 = lang.RT_Var_String_String__Var(Lit_21, Lit_88); A_arbace_a2g_model_A_const_87 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_a2g_model_A_const_88 = lang.RT_Keyword_String_String__Keyword(nil, Lit_15); A_arbace_a2g_model_A_const_89 = lang.RT_Var_String_String__Var(Lit_21, Lit_90); A_arbace_a2g_model_A_const_90 = lang.RT_Var_String_String__Var(Lit_21, Lit_91); A_arbace_a2g_model_A_const_91 = lang.RT_Var_String_String__Var(Lit_21, Lit_92); A_arbace_a2g_model_A_const_92 = lang.RT_Var_String_String__Var(Lit_21, Lit_93); A_arbace_a2g_model_A_const_93 = lang.RT_Var_String_String__Var(Lit_21, Lit_94); A_arbace_a2g_model_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_a2g_model_A_const_95 = lang.RT_Var_String_String__Var(Lit_12, Lit_96); A_arbace_a2g_model_A_const_96 = lang.RT_Var_String_String__Var(Lit_21, Lit_97); A_arbace_a2g_model_A_const_97 = lang.RT_Var_String_String__Var(Lit_21, Lit_98); A_arbace_a2g_model_A_const_98 = lang.RT_Var_String_String__Var(Lit_21, Lit_99); A_arbace_a2g_model_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_a2g_model_A_const_100 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_a2g_model_A_const_101 = lang.RT_Var_String_String__Var(Lit_21, Lit_102); A_arbace_a2g_model_A_const_102 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_a2g_model_A_const_103 = lang.RT_Var_String_String__Var(Lit_6, Lit_103); A_arbace_a2g_model_A_const_104 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_a2g_model_A_const_105 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_a2g_model_A_const_106 = lang.RT_Var_String_String__Var(Lit_21, Lit_105); A_arbace_a2g_model_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_a2g_model_A_const_108 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(); A_arbace_a2g_model_A_const_109 = lang.RT_Var_String_String__Var(Lit_21, Lit_108); A_arbace_a2g_model_A_const_110 = lang.RT_Var_String_String__Var(Lit_21, Lit_109); A_arbace_a2g_model_A_const_111 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(); A_arbace_a2g_model_A_const_112 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(); A_arbace_a2g_model_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_a2g_model_A_const_114 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_a2g_model_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_a2g_model_A_const_116 = lang.RT_Var_String_String__Var(Lit_6, Lit_113); A_arbace_a2g_model_A_const_117 = lang.RT_Var_String_String__Var(Lit_21, Lit_114); A_arbace_a2g_model_A_const_118 = jrt.Integer_ValueOf_I__Integer(8).Ref(); A_arbace_a2g_model_A_const_119 = jrt.Integer_ValueOf_I__Integer(2).Ref(); A_arbace_a2g_model_A_const_120 = lang.RT_Keyword_String_String__Keyword(nil, Lit_115); A_arbace_a2g_model_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_116); A_arbace_a2g_model_A_const_122 = lang.RT_Var_String_String__Var(Lit_21, Lit_117); A_arbace_a2g_model_A_const_123 = lang.RT_Var_String_String__Var(Lit_21, Lit_118); A_arbace_a2g_model_A_const_124 = lang.RT_Var_String_String__Var(Lit_21, Lit_119); A_arbace_a2g_model_A_const_125 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_a2g_model_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_a2g_model_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_a2g_model_A_const_128 = lang.RT_Var_String_String__Var(Lit_21, Lit_123); A_arbace_a2g_model_A_const_129 = lang.RT_Var_String_String__Var(Lit_8, Lit_124); A_arbace_a2g_model_A_const_130 = lang.RT_Var_String_String__Var(Lit_12, Lit_125); A_arbace_a2g_model_A_const_131 = lang.RT_Var_String_String__Var(Lit_14, Lit_126); A_arbace_a2g_model_A_const_132 = lang.RT_Var_String_String__Var(Lit_21, Lit_127); A_arbace_a2g_model_A_const_133 = lang.RT_Var_String_String__Var(Lit_21, Lit_128); A_arbace_a2g_model_A_const_134 = lang.RT_Var_String_String__Var(Lit_14, Lit_129); A_arbace_a2g_model_A_const_135 = lang.RT_Keyword_String_String__Keyword(nil, Lit_130); A_arbace_a2g_model_A_const_136 = lang.RT_Var_String_String__Var(Lit_12, Lit_131); A_arbace_a2g_model_A_const_137 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_132, Lit_133)).Ref(); A_arbace_a2g_model_A_const_138 = lang.RT_Var_String_String__Var(Lit_21, Lit_134); A_arbace_a2g_model_A_const_139 = lang.RT_Var_String_String__Var(Lit_21, Lit_135); A_arbace_a2g_model_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_a2g_model_A_const_141 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_a2g_model_A_const_142 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_a2g_model_A_const_143 = lang.RT_Var_String_String__Var(Lit_21, Lit_139); A_arbace_a2g_model_A_const_144 = lang.RT_Var_String_String__Var(Lit_21, Lit_140); A_arbace_a2g_model_A_const_145 = lang.RT_Var_String_String__Var(Lit_0, Lit_141); A_arbace_a2g_model_A_const_146 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_a2g_model_A_const_147 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); A_arbace_a2g_model_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_144); A_arbace_a2g_model_A_const_149 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_a2g_model_A_const_150 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_a2g_model_A_const_151 = lang.RT_Var_String_String__Var(Lit_0, Lit_147); A_arbace_a2g_model_A_const_152 = lang.RT_Var_String_String__Var(Lit_0, Lit_148); A_arbace_a2g_model_A_const_153 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_a2g_model_A_const_154 = lang.RT_Var_String_String__Var(Lit_21, Lit_150); A_arbace_a2g_model_A_const_155 = lang.RT_Var_String_String__Var(Lit_0, Lit_151); A_arbace_a2g_model_A_const_156 = lang.RT_Var_String_String__Var(Lit_21, Lit_124); A_arbace_a2g_model_A_const_157 = lang.RT_Var_String_String__Var(Lit_0, Lit_152); A_arbace_a2g_model_A_const_158 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_a2g_model_A_const_159 = lang.RT_Var_String_String__Var(Lit_21, Lit_154); A_arbace_a2g_model_A_const_160 = lang.RT_Var_String_String__Var(Lit_21, Lit_155); A_arbace_a2g_model_A_const_161 = lang.RT_Keyword_String_String__Keyword(nil, Lit_156); A_arbace_a2g_model_A_const_162 = lang.RT_Keyword_String_String__Keyword(nil, Lit_157); A_arbace_a2g_model_A_const_163 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_a2g_model_A_const_164 = lang.RT_Keyword_String_String__Keyword(nil, Lit_159); A_arbace_a2g_model_A_const_165 = lang.RT_Keyword_String_String__Keyword(nil, Lit_160); A_arbace_a2g_model_A_const_166 = lang.RT_Keyword_String_String__Keyword(nil, Lit_161); A_arbace_a2g_model_A_const_167 = lang.RT_Keyword_String_String__Keyword(nil, Lit_162); A_arbace_a2g_model_A_const_168 = lang.RT_Var_String_String__Var(Lit_21, Lit_163); A_arbace_a2g_model_A_const_169 = lang.RT_Var_String_String__Var(Lit_8, Lit_164); A_arbace_a2g_model_A_const_170 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_a2g_model_A_const_171 = lang.RT_Var_String_String__Var(Lit_21, Lit_166); A_arbace_a2g_model_A_const_172 = lang.RT_Keyword_String_String__Keyword(nil, Lit_167); A_arbace_a2g_model_A_const_173 = lang.RT_Keyword_String_String__Keyword(nil, Lit_168); A_arbace_a2g_model_A_const_174 = lang.RT_Keyword_String_String__Keyword(nil, Lit_169); A_arbace_a2g_model_A_const_175 = lang.RT_Keyword_String_String__Keyword(nil, Lit_170); A_arbace_a2g_model_A_const_176 = lang.RT_Keyword_String_String__Keyword(nil, Lit_171); A_arbace_a2g_model_A_const_177 = lang.RT_Keyword_String_String__Keyword(nil, Lit_172); A_arbace_a2g_model_A_const_178 = lang.RT_Var_String_String__Var(Lit_21, Lit_173); A_arbace_a2g_model_A_const_179 = lang.RT_Keyword_String_String__Keyword(nil, Lit_174); A_arbace_a2g_model_A_const_180 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_175, Lit_176, Lit_177)).Ref(); A_arbace_a2g_model_A_const_181 = lang.RT_Var_String_String__Var(Lit_21, Lit_178); A_arbace_a2g_model_A_const_182 = lang.RT_Keyword_String_String__Keyword(nil, Lit_179); A_arbace_a2g_model_A_const_183 = lang.RT_Var_String_String__Var(Lit_21, Lit_180); A_arbace_a2g_model_A_const_184 = lang.RT_Keyword_String_String__Keyword(nil, Lit_181); A_arbace_a2g_model_A_const_185 = lang.RT_Keyword_String_String__Keyword(nil, Lit_182); A_arbace_a2g_model_A_const_186 = lang.RT_Keyword_String_String__Keyword(nil, Lit_183); A_arbace_a2g_model_A_const_187 = lang.RT_Keyword_String_String__Keyword(nil, Lit_184); A_arbace_a2g_model_A_const_188 = lang.RT_Keyword_String_String__Keyword(nil, Lit_185); A_arbace_a2g_model_A_const_189 = lang.RT_Keyword_String_String__Keyword(nil, Lit_186); A_arbace_a2g_model_A_const_190 = lang.RT_Keyword_String_String__Keyword(nil, Lit_187); A_arbace_a2g_model_A_const_191 = lang.RT_Keyword_String_String__Keyword(nil, Lit_188); A_arbace_a2g_model_A_const_192 = lang.RT_Keyword_String_String__Keyword(nil, Lit_189); A_arbace_a2g_model_A_const_193 = lang.RT_Keyword_String_String__Keyword(nil, Lit_190); A_arbace_a2g_model_A_const_194 = lang.RT_Keyword_String_String__Keyword(nil, Lit_191); A_arbace_a2g_model_A_const_195 = lang.RT_Keyword_String_String__Keyword(nil, Lit_192); A_arbace_a2g_model_A_const_196 = lang.RT_Keyword_String_String__Keyword(nil, Lit_193); A_arbace_a2g_model_A_const_197 = lang.RT_Keyword_String_String__Keyword(nil, Lit_194); A_arbace_a2g_model_A_const_198 = lang.RT_Keyword_String_String__Keyword(nil, Lit_195); A_arbace_a2g_model_A_const_199 = lang.RT_Keyword_String_String__Keyword(nil, Lit_196); A_arbace_a2g_model_A_const_200 = lang.RT_Keyword_String_String__Keyword(nil, Lit_197); A_arbace_a2g_model_A_const_201 = lang.RT_Keyword_String_String__Keyword(nil, Lit_198); A_arbace_a2g_model_A_const_202 = lang.RT_Keyword_String_String__Keyword(nil, Lit_199); A_arbace_a2g_model_A_const_203 = lang.RT_Keyword_String_String__Keyword(nil, Lit_200); A_arbace_a2g_model_A_const_204 = lang.RT_Keyword_String_String__Keyword(nil, Lit_201); A_arbace_a2g_model_A_const_205 = lang.RT_Keyword_String_String__Keyword(nil, Lit_202); A_arbace_a2g_model_A_const_206 = lang.RT_Keyword_String_String__Keyword(nil, Lit_203); A_arbace_a2g_model_A_const_207 = lang.RT_Keyword_String_String__Keyword(nil, Lit_204); A_arbace_a2g_model_A_const_208 = lang.RT_Keyword_String_String__Keyword(nil, Lit_205); A_arbace_a2g_model_A_const_209 = lang.RT_Keyword_String_String__Keyword(nil, Lit_206); A_arbace_a2g_model_A_const_210 = lang.RT_Keyword_String_String__Keyword(nil, Lit_207); A_arbace_a2g_model_A_const_211 = lang.RT_Keyword_String_String__Keyword(nil, Lit_208); A_arbace_a2g_model_A_const_212 = lang.RT_Keyword_String_String__Keyword(nil, Lit_209); A_arbace_a2g_model_A_const_213 = lang.RT_Keyword_String_String__Keyword(nil, Lit_210); A_arbace_a2g_model_A_const_214 = lang.RT_Keyword_String_String__Keyword(nil, Lit_211); A_arbace_a2g_model_A_const_215 = lang.RT_Var_String_String__Var(Lit_0, Lit_212); A_arbace_a2g_model_A_const_216 = lang.RT_Keyword_String_String__Keyword(nil, Lit_213); A_arbace_a2g_model_A_const_217 = lang.RT_Keyword_String_String__Keyword(nil, Lit_214); A_arbace_a2g_model_A_const_218 = lang.RT_Keyword_String_String__Keyword(nil, Lit_215); A_arbace_a2g_model_A_const_219 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_216).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_217).Ref())).Ref(); A_arbace_a2g_model_A_const_220 = lang.RT_Keyword_String_String__Keyword(nil, Lit_218); A_arbace_a2g_model_A_const_221 = lang.RT_Keyword_String_String__Keyword(nil, Lit_219); A_arbace_a2g_model_A_const_222 = lang.RT_Keyword_String_String__Keyword(nil, Lit_220); A_arbace_a2g_model_A_const_223 = lang.RT_Keyword_String_String__Keyword(nil, Lit_221); A_arbace_a2g_model_A_const_224 = lang.RT_Keyword_String_String__Keyword(nil, Lit_222); A_arbace_a2g_model_A_const_225 = lang.RT_Var_String_String__Var(Lit_21, Lit_223); A_arbace_a2g_model_A_const_226 = lang.RT_Keyword_String_String__Keyword(nil, Lit_224) }

func A_arbace_a2g_model_A_New() *A_arbace_a2g_model_A { A_arbace_a2g_model_A_Init(); t := &A_arbace_a2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_model_A) Ctor() {}

func (t *A_arbace_a2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_A_class }

func (t *A_arbace_a2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_A); return ok }

func A_arbace_a2g_model_A_Cast(x any) *A_arbace_a2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_A_class)) }; return v }



type A_arbace_a2g_model_T_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_T_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_T_A_fn_class *jrt.Class

var A_arbace_a2g_model_T_A_init jrt.ClassInit

func A_arbace_a2g_model_T_A_Init() { if !A_arbace_a2g_model_T_A_init.Done() { A_arbace_a2g_model_T_A_init.Run(A_arbace_a2g_model_T_A_clinit) } }

func A_arbace_a2g_model_T_A_clinit() { A_arbace_a2g_model_T_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_T_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_T_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_T_A_class }

func (t *A_arbace_a2g_model_T_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_T_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_T_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_T_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_T_A); return ok }

func A_arbace_a2g_model_T_A_Cast(x any) *A_arbace_a2g_model_T_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_T_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_T_A_class)) }; return v }



type A_arbace_a2g_model_a2g_method_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_a2g_method_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_a2g_method_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_a2g_method_QMARK__A_Init() { if !A_arbace_a2g_model_a2g_method_QMARK__A_init.Done() { A_arbace_a2g_model_a2g_method_QMARK__A_init.Run(A_arbace_a2g_model_a2g_method_QMARK__A_clinit) } }

func A_arbace_a2g_model_a2g_method_QMARK__A_clinit() { A_arbace_a2g_model_a2g_method_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_226, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_a2g_method_QMARK__A_class }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_a2g_method_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_a2g_method_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_a2g_method_QMARK__A); return ok }

func A_arbace_a2g_model_a2g_method_QMARK__A_Cast(x any) *A_arbace_a2g_model_a2g_method_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_a2g_method_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_a2g_method_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_a2g_static_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_a2g_static_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_a2g_static_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_a2g_static_QMARK__A_Init() { if !A_arbace_a2g_model_a2g_static_QMARK__A_init.Done() { A_arbace_a2g_model_a2g_static_QMARK__A_init.Run(A_arbace_a2g_model_a2g_static_QMARK__A_clinit) } }

func A_arbace_a2g_model_a2g_static_QMARK__A_clinit() { A_arbace_a2g_model_a2g_static_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_230, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_a2g_static_QMARK__A_class }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_a2g_static_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_a2g_static_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_a2g_static_QMARK__A); return ok }

func A_arbace_a2g_model_a2g_static_QMARK__A_Cast(x any) *A_arbace_a2g_model_a2g_static_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_a2g_static_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_a2g_static_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_abstract_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_abstract_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_abstract_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_abstract_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_abstract_QMARK__A_Init() { if !A_arbace_a2g_model_abstract_QMARK__A_init.Done() { A_arbace_a2g_model_abstract_QMARK__A_init.Run(A_arbace_a2g_model_abstract_QMARK__A_clinit) } }

func A_arbace_a2g_model_abstract_QMARK__A_clinit() { A_arbace_a2g_model_abstract_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_abstract_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_abstract_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_abstract_QMARK__A_class }

func (t *A_arbace_a2g_model_abstract_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_abstract_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_abstract_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_abstract_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_abstract_QMARK__A); return ok }

func A_arbace_a2g_model_abstract_QMARK__A_Cast(x any) *A_arbace_a2g_model_abstract_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_abstract_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_abstract_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_abstract_m_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_abstract_m_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_abstract_m_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_abstract_m_QMARK__A_Init() { if !A_arbace_a2g_model_abstract_m_QMARK__A_init.Done() { A_arbace_a2g_model_abstract_m_QMARK__A_init.Run(A_arbace_a2g_model_abstract_m_QMARK__A_clinit) } }

func A_arbace_a2g_model_abstract_m_QMARK__A_clinit() { A_arbace_a2g_model_abstract_m_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_abstract_m_QMARK__A_class }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_abstract_m_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_abstract_m_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_abstract_m_QMARK__A); return ok }

func A_arbace_a2g_model_abstract_m_QMARK__A_Cast(x any) *A_arbace_a2g_model_abstract_m_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_abstract_m_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_abstract_m_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_all_supertypes_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_all_supertypes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_all_supertypes_A_fn_class *jrt.Class

var A_arbace_a2g_model_all_supertypes_A_init jrt.ClassInit

func A_arbace_a2g_model_all_supertypes_A_Init() { if !A_arbace_a2g_model_all_supertypes_A_init.Done() { A_arbace_a2g_model_all_supertypes_A_init.Run(A_arbace_a2g_model_all_supertypes_A_clinit) } }

func A_arbace_a2g_model_all_supertypes_A_clinit() { A_arbace_a2g_model_all_supertypes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_all_supertypes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_all_supertypes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_all_supertypes_A_class }

func (t *A_arbace_a2g_model_all_supertypes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_all_supertypes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_all_supertypes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_all_supertypes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_all_supertypes_A); return ok }

func A_arbace_a2g_model_all_supertypes_A_Cast(x any) *A_arbace_a2g_model_all_supertypes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_all_supertypes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_all_supertypes_A_class)) }; return v }



type A_arbace_a2g_model_benign_init_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_benign_init_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_benign_init_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_benign_init_QMARK__A_Init() { if !A_arbace_a2g_model_benign_init_QMARK__A_init.Done() { A_arbace_a2g_model_benign_init_QMARK__A_init.Run(A_arbace_a2g_model_benign_init_QMARK__A_clinit) } }

func A_arbace_a2g_model_benign_init_QMARK__A_clinit() { A_arbace_a2g_model_benign_init_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_benign_init_QMARK__A_class }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_benign_init_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_benign_init_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_benign_init_QMARK__A); return ok }

func A_arbace_a2g_model_benign_init_QMARK__A_Cast(x any) *A_arbace_a2g_model_benign_init_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_benign_init_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_benign_init_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_fn_class *jrt.Class

var A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_init jrt.ClassInit

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_Init() { if !A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_init.Done() { A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_init.Run(A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_clinit) } }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_clinit() { A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_class }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A); return ok }

func A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_Cast(x any) *A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_benign_init_QMARK__fn__1008000165_A_class)) }; return v }



type A_arbace_a2g_model_class_sym_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_class_sym_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_a2g_model_class_sym_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_class_sym_A_fn_class *jrt.Class

var A_arbace_a2g_model_class_sym_A_init jrt.ClassInit

func A_arbace_a2g_model_class_sym_A_Init() { if !A_arbace_a2g_model_class_sym_A_init.Done() { A_arbace_a2g_model_class_sym_A_init.Run(A_arbace_a2g_model_class_sym_A_clinit) } }

func A_arbace_a2g_model_class_sym_A_clinit() { A_arbace_a2g_model_class_sym_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_class_sym_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_class_sym_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_class_sym_A_class }

func (t *A_arbace_a2g_model_class_sym_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_class_sym_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_class_sym_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_class_sym_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_class_sym_A); return ok }

func A_arbace_a2g_model_class_sym_A_Cast(x any) *A_arbace_a2g_model_class_sym_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_class_sym_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_class_sym_A_class)) }; return v }



type A_arbace_a2g_model_declared_vmethods_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_declared_vmethods_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_declared_vmethods_A_fn_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_A_init jrt.ClassInit

func A_arbace_a2g_model_declared_vmethods_A_Init() { if !A_arbace_a2g_model_declared_vmethods_A_init.Done() { A_arbace_a2g_model_declared_vmethods_A_init.Run(A_arbace_a2g_model_declared_vmethods_A_clinit) } }

func A_arbace_a2g_model_declared_vmethods_A_clinit() { A_arbace_a2g_model_declared_vmethods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_declared_vmethods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_declared_vmethods_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_declared_vmethods_A_class }

func (t *A_arbace_a2g_model_declared_vmethods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_declared_vmethods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_declared_vmethods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_declared_vmethods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_declared_vmethods_A); return ok }

func A_arbace_a2g_model_declared_vmethods_A_Cast(x any) *A_arbace_a2g_model_declared_vmethods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_declared_vmethods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_declared_vmethods_A_class)) }; return v }



type A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_fn_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_init jrt.ClassInit

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_Init() { if !A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_init.Done() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_init.Run(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_clinit) } }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_clinit() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A); return ok }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_Cast(x any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_A_class)) }; return v }



type A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A struct{ jrt.Object; F_n, F_s__1008000088, F_iter__1008000087 any }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_fn_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_init jrt.ClassInit

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_Init() { if !A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_init.Done() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_init.Run(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_clinit) } }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_clinit() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A); return ok }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_Cast(x any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_A_class)) }; return v }



type A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A struct{ jrt.Object; F_n, F_b__1008000090 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_fn_class *jrt.Class

var A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_init jrt.ClassInit

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_Init() { if !A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_init.Done() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_init.Run(A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_clinit) } }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_clinit() { A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A); return ok }

func A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_Cast(x any) *A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_declared_vmethods_iter__1008000087__1008000091_fn__1008000092_fn__1008000093_A_class)) }; return v }



type A_arbace_a2g_model_desc_classes_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_desc_classes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_desc_classes_A_fn_class *jrt.Class

var A_arbace_a2g_model_desc_classes_A_init jrt.ClassInit

func A_arbace_a2g_model_desc_classes_A_Init() { if !A_arbace_a2g_model_desc_classes_A_init.Done() { A_arbace_a2g_model_desc_classes_A_init.Run(A_arbace_a2g_model_desc_classes_A_clinit) } }

func A_arbace_a2g_model_desc_classes_A_clinit() { A_arbace_a2g_model_desc_classes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_desc_classes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_desc_classes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_desc_classes_A_class }

func (t *A_arbace_a2g_model_desc_classes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_desc_classes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_desc_classes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_desc_classes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_desc_classes_A); return ok }

func A_arbace_a2g_model_desc_classes_A_Cast(x any) *A_arbace_a2g_model_desc_classes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_desc_classes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_desc_classes_A_class)) }; return v }



type A_arbace_a2g_model_desc_in_world_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_desc_in_world_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_desc_in_world_QMARK__A_Init() { if !A_arbace_a2g_model_desc_in_world_QMARK__A_init.Done() { A_arbace_a2g_model_desc_in_world_QMARK__A_init.Run(A_arbace_a2g_model_desc_in_world_QMARK__A_clinit) } }

func A_arbace_a2g_model_desc_in_world_QMARK__A_clinit() { A_arbace_a2g_model_desc_in_world_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_desc_in_world_QMARK__A_class }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_desc_in_world_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_desc_in_world_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_desc_in_world_QMARK__A); return ok }

func A_arbace_a2g_model_desc_in_world_QMARK__A_Cast(x any) *A_arbace_a2g_model_desc_in_world_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_desc_in_world_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_desc_in_world_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_erased_desc_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_erased_desc_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_erased_desc_QMARK__A_Init() { if !A_arbace_a2g_model_erased_desc_QMARK__A_init.Done() { A_arbace_a2g_model_erased_desc_QMARK__A_init.Run(A_arbace_a2g_model_erased_desc_QMARK__A_clinit) } }

func A_arbace_a2g_model_erased_desc_QMARK__A_clinit() { A_arbace_a2g_model_erased_desc_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_247, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_erased_desc_QMARK__A_class }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_erased_desc_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__A); return ok }

func A_arbace_a2g_model_erased_desc_QMARK__A_Cast(x any) *A_arbace_a2g_model_erased_desc_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_erased_desc_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A struct{ jrt.Object; F_d any }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_fn_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_init jrt.ClassInit

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_Init() { if !A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_init.Done() { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_init.Run(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_clinit) } }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_clinit() { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A); return ok }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_Cast(x any) *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_erased_desc_QMARK__fn__1008000045_A_class)) }; return v }



type A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_fn_class *jrt.Class

var A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_init jrt.ClassInit

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_Init() { if !A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_init.Done() { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_init.Run(A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_clinit) } }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_clinit() { A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A); return ok }

func A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_Cast(x any) *A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_erased_desc_QMARK__fn__1008000047_A_class)) }; return v }



type A_arbace_a2g_model_eval1008000004_A struct{ jrt.Object }

func A_arbace_a2g_model_eval1008000004_A_New() *A_arbace_a2g_model_eval1008000004_A { t := &A_arbace_a2g_model_eval1008000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_model_eval1008000004_A) Ctor() {}

func (t *A_arbace_a2g_model_eval1008000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_eval1008000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_eval1008000004_A_class }

func (t *A_arbace_a2g_model_eval1008000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_eval1008000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_eval1008000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_eval1008000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_eval1008000004_A); return ok }

func A_arbace_a2g_model_eval1008000004_A_Cast(x any) *A_arbace_a2g_model_eval1008000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_eval1008000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_eval1008000004_A_class)) }; return v }



type A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_fn_class *jrt.Class

var A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_init jrt.ClassInit

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_Init() { if !A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_init.Done() { A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_init.Run(A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_clinit) } }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_clinit() { A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A); return ok }

func A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_Cast(x any) *A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_eval1008000004_loading__1927001464__auto____1008000005_A_class)) }; return v }



type A_arbace_a2g_model_eval1008000008_A struct{ jrt.Object }

func A_arbace_a2g_model_eval1008000008_A_New() *A_arbace_a2g_model_eval1008000008_A { t := &A_arbace_a2g_model_eval1008000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_model_eval1008000008_A) Ctor() {}

func (t *A_arbace_a2g_model_eval1008000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_eval1008000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_eval1008000008_A_class }

func (t *A_arbace_a2g_model_eval1008000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_eval1008000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_eval1008000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_eval1008000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_eval1008000008_A); return ok }

func A_arbace_a2g_model_eval1008000008_A_Cast(x any) *A_arbace_a2g_model_eval1008000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_eval1008000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_eval1008000008_A_class)) }; return v }



type A_arbace_a2g_model_eval1008000008_fn__1008000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_eval1008000008_fn__1008000009_A_fn_class *jrt.Class

var A_arbace_a2g_model_eval1008000008_fn__1008000009_A_init jrt.ClassInit

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_Init() { if !A_arbace_a2g_model_eval1008000008_fn__1008000009_A_init.Done() { A_arbace_a2g_model_eval1008000008_fn__1008000009_A_init.Run(A_arbace_a2g_model_eval1008000008_fn__1008000009_A_clinit) } }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_clinit() { A_arbace_a2g_model_eval1008000008_fn__1008000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_eval1008000008_fn__1008000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_eval1008000008_fn__1008000009_A); return ok }

func A_arbace_a2g_model_eval1008000008_fn__1008000009_A_Cast(x any) *A_arbace_a2g_model_eval1008000008_fn__1008000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_eval1008000008_fn__1008000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_eval1008000008_fn__1008000009_A_class)) }; return v }



type A_arbace_a2g_model_fields_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_fields_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_fields_of_A_fn_class *jrt.Class

var A_arbace_a2g_model_fields_of_A_init jrt.ClassInit

func A_arbace_a2g_model_fields_of_A_Init() { if !A_arbace_a2g_model_fields_of_A_init.Done() { A_arbace_a2g_model_fields_of_A_init.Run(A_arbace_a2g_model_fields_of_A_clinit) } }

func A_arbace_a2g_model_fields_of_A_clinit() { A_arbace_a2g_model_fields_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_fields_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_fields_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_fields_of_A_class }

func (t *A_arbace_a2g_model_fields_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_fields_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_fields_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_fields_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_fields_of_A); return ok }

func A_arbace_a2g_model_fields_of_A_Cast(x any) *A_arbace_a2g_model_fields_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_fields_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_fields_of_A_class)) }; return v }



type A_arbace_a2g_model_final_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_final_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_final_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_final_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_final_QMARK__A_Init() { if !A_arbace_a2g_model_final_QMARK__A_init.Done() { A_arbace_a2g_model_final_QMARK__A_init.Run(A_arbace_a2g_model_final_QMARK__A_clinit) } }

func A_arbace_a2g_model_final_QMARK__A_clinit() { A_arbace_a2g_model_final_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_253, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_final_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_final_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_final_QMARK__A_class }

func (t *A_arbace_a2g_model_final_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_final_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_final_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_final_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_final_QMARK__A); return ok }

func A_arbace_a2g_model_final_QMARK__A_Cast(x any) *A_arbace_a2g_model_final_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_final_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_final_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_find_method_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_find_method_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_model_find_method_A_fn_class *jrt.Class

var A_arbace_a2g_model_find_method_A_init jrt.ClassInit

func A_arbace_a2g_model_find_method_A_Init() { if !A_arbace_a2g_model_find_method_A_init.Done() { A_arbace_a2g_model_find_method_A_init.Run(A_arbace_a2g_model_find_method_A_clinit) } }

func A_arbace_a2g_model_find_method_A_clinit() { A_arbace_a2g_model_find_method_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_find_method_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_find_method_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_find_method_A_class }

func (t *A_arbace_a2g_model_find_method_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_find_method_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_find_method_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_find_method_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_find_method_A); return ok }

func A_arbace_a2g_model_find_method_A_Cast(x any) *A_arbace_a2g_model_find_method_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_find_method_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_find_method_A_class)) }; return v }



type A_arbace_a2g_model_find_method_fn__1008000077_A struct{ jrt.Object; F_name, F_desc any }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_find_method_fn__1008000077_A_fn_class *jrt.Class

var A_arbace_a2g_model_find_method_fn__1008000077_A_init jrt.ClassInit

func A_arbace_a2g_model_find_method_fn__1008000077_A_Init() { if !A_arbace_a2g_model_find_method_fn__1008000077_A_init.Done() { A_arbace_a2g_model_find_method_fn__1008000077_A_init.Run(A_arbace_a2g_model_find_method_fn__1008000077_A_clinit) } }

func A_arbace_a2g_model_find_method_fn__1008000077_A_clinit() { A_arbace_a2g_model_find_method_fn__1008000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_find_method_fn__1008000077_A_class }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_find_method_fn__1008000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_find_method_fn__1008000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_find_method_fn__1008000077_A); return ok }

func A_arbace_a2g_model_find_method_fn__1008000077_A_Cast(x any) *A_arbace_a2g_model_find_method_fn__1008000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_find_method_fn__1008000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_find_method_fn__1008000077_A_class)) }; return v }



type A_arbace_a2g_model_go_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_go_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_go_name_A_fn_class *jrt.Class

var A_arbace_a2g_model_go_name_A_init jrt.ClassInit

func A_arbace_a2g_model_go_name_A_Init() { if !A_arbace_a2g_model_go_name_A_init.Done() { A_arbace_a2g_model_go_name_A_init.Run(A_arbace_a2g_model_go_name_A_clinit) } }

func A_arbace_a2g_model_go_name_A_clinit() { A_arbace_a2g_model_go_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_256, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_go_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_go_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_go_name_A_class }

func (t *A_arbace_a2g_model_go_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_go_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_go_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_go_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_go_name_A); return ok }

func A_arbace_a2g_model_go_name_A_Cast(x any) *A_arbace_a2g_model_go_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_go_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_go_name_A_class)) }; return v }



type A_arbace_a2g_model_go_type_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_go_type_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_go_type_A_fn_class *jrt.Class

var A_arbace_a2g_model_go_type_A_init jrt.ClassInit

func A_arbace_a2g_model_go_type_A_Init() { if !A_arbace_a2g_model_go_type_A_init.Done() { A_arbace_a2g_model_go_type_A_init.Run(A_arbace_a2g_model_go_type_A_clinit) } }

func A_arbace_a2g_model_go_type_A_clinit() { A_arbace_a2g_model_go_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_go_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_go_type_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_go_type_A_class }

func (t *A_arbace_a2g_model_go_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_go_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_go_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_go_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_go_type_A); return ok }

func A_arbace_a2g_model_go_type_A_Cast(x any) *A_arbace_a2g_model_go_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_go_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_go_type_A_class)) }; return v }



type A_arbace_a2g_model_hand_written_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_hand_written_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_hand_written_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_hand_written_QMARK__A_Init() { if !A_arbace_a2g_model_hand_written_QMARK__A_init.Done() { A_arbace_a2g_model_hand_written_QMARK__A_init.Run(A_arbace_a2g_model_hand_written_QMARK__A_clinit) } }

func A_arbace_a2g_model_hand_written_QMARK__A_clinit() { A_arbace_a2g_model_hand_written_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_263, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_hand_written_QMARK__A_class }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_hand_written_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_hand_written_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_hand_written_QMARK__A); return ok }

func A_arbace_a2g_model_hand_written_QMARK__A_Cast(x any) *A_arbace_a2g_model_hand_written_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_hand_written_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_hand_written_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_has_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_has_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_has_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_has_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_has_QMARK__A_Init() { if !A_arbace_a2g_model_has_QMARK__A_init.Done() { A_arbace_a2g_model_has_QMARK__A_init.Run(A_arbace_a2g_model_has_QMARK__A_clinit) } }

func A_arbace_a2g_model_has_QMARK__A_clinit() { A_arbace_a2g_model_has_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_264, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_has_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_has_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_has_QMARK__A_class }

func (t *A_arbace_a2g_model_has_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_has_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_has_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_has_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_has_QMARK__A); return ok }

func A_arbace_a2g_model_has_QMARK__A_Cast(x any) *A_arbace_a2g_model_has_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_has_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_has_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_hw_method_exists_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_hw_method_exists_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_hw_method_exists_QMARK__A_Init() { if !A_arbace_a2g_model_hw_method_exists_QMARK__A_init.Done() { A_arbace_a2g_model_hw_method_exists_QMARK__A_init.Run(A_arbace_a2g_model_hw_method_exists_QMARK__A_clinit) } }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_clinit() { A_arbace_a2g_model_hw_method_exists_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_265, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_hw_method_exists_QMARK__A_class }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_hw_method_exists_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_hw_method_exists_QMARK__A); return ok }

func A_arbace_a2g_model_hw_method_exists_QMARK__A_Cast(x any) *A_arbace_a2g_model_hw_method_exists_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_hw_method_exists_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_hw_method_exists_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_iface_desc_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_iface_desc_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_iface_desc_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_iface_desc_QMARK__A_Init() { if !A_arbace_a2g_model_iface_desc_QMARK__A_init.Done() { A_arbace_a2g_model_iface_desc_QMARK__A_init.Run(A_arbace_a2g_model_iface_desc_QMARK__A_clinit) } }

func A_arbace_a2g_model_iface_desc_QMARK__A_clinit() { A_arbace_a2g_model_iface_desc_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_267, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_iface_desc_QMARK__A_class }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_iface_desc_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_iface_desc_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_iface_desc_QMARK__A); return ok }

func A_arbace_a2g_model_iface_desc_QMARK__A_Cast(x any) *A_arbace_a2g_model_iface_desc_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_iface_desc_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_iface_desc_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_impl_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_impl_of_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_impl_of_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_A_Init() { if !A_arbace_a2g_model_impl_of_A_init.Done() { A_arbace_a2g_model_impl_of_A_init.Run(A_arbace_a2g_model_impl_of_A_clinit) } }

func A_arbace_a2g_model_impl_of_A_clinit() { A_arbace_a2g_model_impl_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_268, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_A_class }

func (t *A_arbace_a2g_model_impl_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_A); return ok }

func A_arbace_a2g_model_impl_of_A_Cast(x any) *A_arbace_a2g_model_impl_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_fn__1008000112_A struct{ jrt.Object; F_name, F_desc, F_n any }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_impl_of_fn__1008000112_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000112_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_fn__1008000112_A_Init() { if !A_arbace_a2g_model_impl_of_fn__1008000112_A_init.Done() { A_arbace_a2g_model_impl_of_fn__1008000112_A_init.Run(A_arbace_a2g_model_impl_of_fn__1008000112_A_clinit) } }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_clinit() { A_arbace_a2g_model_impl_of_fn__1008000112_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_269, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_fn__1008000112_A_class }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000112_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000112_A); return ok }

func A_arbace_a2g_model_impl_of_fn__1008000112_A_Cast(x any) *A_arbace_a2g_model_impl_of_fn__1008000112_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000112_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_fn__1008000112_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_fn__1008000124_A struct{ jrt.Object; F_cands any }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_impl_of_fn__1008000124_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000124_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_fn__1008000124_A_Init() { if !A_arbace_a2g_model_impl_of_fn__1008000124_A_init.Done() { A_arbace_a2g_model_impl_of_fn__1008000124_A_init.Run(A_arbace_a2g_model_impl_of_fn__1008000124_A_clinit) } }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_clinit() { A_arbace_a2g_model_impl_of_fn__1008000124_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_270, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_fn__1008000124_A_class }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000124_A); return ok }

func A_arbace_a2g_model_impl_of_fn__1008000124_A_Cast(x any) *A_arbace_a2g_model_impl_of_fn__1008000124_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000124_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_fn__1008000124_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A struct{ jrt.Object; F_x any }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_Init() { if !A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_init.Done() { A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_init.Run(A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_clinit) } }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_clinit() { A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_271, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A); return ok }

func A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_Cast(x any) *A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_fn__1008000124_fn__1008000125_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A struct{ jrt.Object; F_name, F_desc any }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_Init() { if !A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_init.Done() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_init.Run(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_clinit) } }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_clinit() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A); return ok }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_Cast(x any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A struct{ jrt.Object; F_iter__1008000114, F_name, F_desc, F_s__1008000115 any }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_Init() { if !A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_init.Done() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_init.Run(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_clinit) } }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_clinit() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A); return ok }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_Cast(x any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_A_class)) }; return v }



type A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A struct{ jrt.Object; F_name, F_b__1008000117, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_fn_class *jrt.Class

var A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_init jrt.ClassInit

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_Init() { if !A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_init.Done() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_init.Run(A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_clinit) } }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_clinit() { A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_274, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A); return ok }

func A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_Cast(x any) *A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_impl_of_iter__1008000114__1008000118_fn__1008000119_fn__1008000120_A_class)) }; return v }



type A_arbace_a2g_model_in_world_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_in_world_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_in_world_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_in_world_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_in_world_QMARK__A_Init() { if !A_arbace_a2g_model_in_world_QMARK__A_init.Done() { A_arbace_a2g_model_in_world_QMARK__A_init.Run(A_arbace_a2g_model_in_world_QMARK__A_clinit) } }

func A_arbace_a2g_model_in_world_QMARK__A_clinit() { A_arbace_a2g_model_in_world_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_in_world_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_in_world_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_in_world_QMARK__A_class }

func (t *A_arbace_a2g_model_in_world_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_in_world_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_in_world_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_in_world_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_in_world_QMARK__A); return ok }

func A_arbace_a2g_model_in_world_QMARK__A_Cast(x any) *A_arbace_a2g_model_in_world_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_in_world_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_in_world_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_info_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_info_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_info_A_fn_class *jrt.Class

var A_arbace_a2g_model_info_A_init jrt.ClassInit

func A_arbace_a2g_model_info_A_Init() { if !A_arbace_a2g_model_info_A_init.Done() { A_arbace_a2g_model_info_A_init.Run(A_arbace_a2g_model_info_A_clinit) } }

func A_arbace_a2g_model_info_A_clinit() { A_arbace_a2g_model_info_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_276, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_info_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_info_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_info_A_class }

func (t *A_arbace_a2g_model_info_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_info_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_info_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_info_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_info_A); return ok }

func A_arbace_a2g_model_info_A_Cast(x any) *A_arbace_a2g_model_info_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_info_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_info_A_class)) }; return v }



type A_arbace_a2g_model_interface_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_interface_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_interface_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_interface_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_interface_QMARK__A_Init() { if !A_arbace_a2g_model_interface_QMARK__A_init.Done() { A_arbace_a2g_model_interface_QMARK__A_init.Run(A_arbace_a2g_model_interface_QMARK__A_clinit) } }

func A_arbace_a2g_model_interface_QMARK__A_clinit() { A_arbace_a2g_model_interface_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_interface_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_interface_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_interface_QMARK__A_class }

func (t *A_arbace_a2g_model_interface_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_interface_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_interface_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_interface_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_interface_QMARK__A); return ok }

func A_arbace_a2g_model_interface_QMARK__A_Cast(x any) *A_arbace_a2g_model_interface_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_interface_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_interface_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_jobs_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_jobs_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_jobs_A_fn_class *jrt.Class

var A_arbace_a2g_model_jobs_A_init jrt.ClassInit

func A_arbace_a2g_model_jobs_A_Init() { if !A_arbace_a2g_model_jobs_A_init.Done() { A_arbace_a2g_model_jobs_A_init.Run(A_arbace_a2g_model_jobs_A_clinit) } }

func A_arbace_a2g_model_jobs_A_clinit() { A_arbace_a2g_model_jobs_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_jobs_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_jobs_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_jobs_A_class }

func (t *A_arbace_a2g_model_jobs_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_jobs_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_jobs_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_jobs_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_jobs_A); return ok }

func A_arbace_a2g_model_jobs_A_Cast(x any) *A_arbace_a2g_model_jobs_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_jobs_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_jobs_A_class)) }; return v }



type A_arbace_a2g_model_jrt_class_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_jrt_class_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_jrt_class_A_fn_class *jrt.Class

var A_arbace_a2g_model_jrt_class_A_init jrt.ClassInit

func A_arbace_a2g_model_jrt_class_A_Init() { if !A_arbace_a2g_model_jrt_class_A_init.Done() { A_arbace_a2g_model_jrt_class_A_init.Run(A_arbace_a2g_model_jrt_class_A_clinit) } }

func A_arbace_a2g_model_jrt_class_A_clinit() { A_arbace_a2g_model_jrt_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_jrt_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_jrt_class_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_jrt_class_A_class }

func (t *A_arbace_a2g_model_jrt_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_jrt_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_jrt_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_jrt_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_jrt_class_A); return ok }

func A_arbace_a2g_model_jrt_class_A_Cast(x any) *A_arbace_a2g_model_jrt_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_jrt_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_jrt_class_A_class)) }; return v }



type A_arbace_a2g_model_jrt_sym_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_jrt_sym_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_jrt_sym_A_fn_class *jrt.Class

var A_arbace_a2g_model_jrt_sym_A_init jrt.ClassInit

func A_arbace_a2g_model_jrt_sym_A_Init() { if !A_arbace_a2g_model_jrt_sym_A_init.Done() { A_arbace_a2g_model_jrt_sym_A_init.Run(A_arbace_a2g_model_jrt_sym_A_clinit) } }

func A_arbace_a2g_model_jrt_sym_A_clinit() { A_arbace_a2g_model_jrt_sym_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_281, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_jrt_sym_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_jrt_sym_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_jrt_sym_A_class }

func (t *A_arbace_a2g_model_jrt_sym_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_jrt_sym_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_jrt_sym_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_jrt_sym_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_jrt_sym_A); return ok }

func A_arbace_a2g_model_jrt_sym_A_Cast(x any) *A_arbace_a2g_model_jrt_sym_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_jrt_sym_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_jrt_sym_A_class)) }; return v }



type A_arbace_a2g_model_leaf_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_leaf_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_leaf_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_leaf_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_leaf_QMARK__A_Init() { if !A_arbace_a2g_model_leaf_QMARK__A_init.Done() { A_arbace_a2g_model_leaf_QMARK__A_init.Run(A_arbace_a2g_model_leaf_QMARK__A_clinit) } }

func A_arbace_a2g_model_leaf_QMARK__A_clinit() { A_arbace_a2g_model_leaf_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_leaf_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_leaf_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_leaf_QMARK__A_class }

func (t *A_arbace_a2g_model_leaf_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_leaf_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_leaf_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_leaf_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_leaf_QMARK__A); return ok }

func A_arbace_a2g_model_leaf_QMARK__A_Cast(x any) *A_arbace_a2g_model_leaf_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_leaf_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_leaf_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_make_subclass_index_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_make_subclass_index_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_make_subclass_index_A_fn_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_A_init jrt.ClassInit

func A_arbace_a2g_model_make_subclass_index_A_Init() { if !A_arbace_a2g_model_make_subclass_index_A_init.Done() { A_arbace_a2g_model_make_subclass_index_A_init.Run(A_arbace_a2g_model_make_subclass_index_A_clinit) } }

func A_arbace_a2g_model_make_subclass_index_A_clinit() { A_arbace_a2g_model_make_subclass_index_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_make_subclass_index_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_make_subclass_index_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_make_subclass_index_A_class }

func (t *A_arbace_a2g_model_make_subclass_index_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_make_subclass_index_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_make_subclass_index_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_make_subclass_index_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_make_subclass_index_A); return ok }

func A_arbace_a2g_model_make_subclass_index_A_Cast(x any) *A_arbace_a2g_model_make_subclass_index_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_make_subclass_index_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_make_subclass_index_A_class)) }; return v }



type A_arbace_a2g_model_make_subclass_index_fn__1008000057_A struct{ jrt.Object; F_cache, F_w any }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_fn_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_init jrt.ClassInit

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_Init() { if !A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_init.Done() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_init.Run(A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_clinit) } }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_clinit() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_284, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_A); return ok }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_Cast(x any) *A_arbace_a2g_model_make_subclass_index_fn__1008000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_make_subclass_index_fn__1008000057_A_class)) }; return v }



type A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A struct{ jrt.Object; F_w any }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_fn_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_init jrt.ClassInit

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_Init() { if !A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_init.Done() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_init.Run(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_clinit) } }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_clinit() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_285, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A); return ok }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_Cast(x any) *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_A_class)) }; return v }



type A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_fn_class *jrt.Class

var A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_init jrt.ClassInit

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_Init() { if !A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_init.Done() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_init.Run(A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_clinit) } }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_clinit() { A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_286, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A); return ok }

func A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_Cast(x any) *A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_make_subclass_index_fn__1008000057_fn__1008000058_fn__1008000059_A_class)) }; return v }



type A_arbace_a2g_model_mdesc_in_world_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_mdesc_in_world_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_Init() { if !A_arbace_a2g_model_mdesc_in_world_QMARK__A_init.Done() { A_arbace_a2g_model_mdesc_in_world_QMARK__A_init.Run(A_arbace_a2g_model_mdesc_in_world_QMARK__A_clinit) } }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_clinit() { A_arbace_a2g_model_mdesc_in_world_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_287, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_mdesc_in_world_QMARK__A_class }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_mdesc_in_world_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_mdesc_in_world_QMARK__A); return ok }

func A_arbace_a2g_model_mdesc_in_world_QMARK__A_Cast(x any) *A_arbace_a2g_model_mdesc_in_world_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_mdesc_in_world_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_mdesc_in_world_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_member_in_world_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_member_in_world_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_member_in_world_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_member_in_world_QMARK__A_Init() { if !A_arbace_a2g_model_member_in_world_QMARK__A_init.Done() { A_arbace_a2g_model_member_in_world_QMARK__A_init.Run(A_arbace_a2g_model_member_in_world_QMARK__A_clinit) } }

func A_arbace_a2g_model_member_in_world_QMARK__A_clinit() { A_arbace_a2g_model_member_in_world_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_member_in_world_QMARK__A_class }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_member_in_world_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_member_in_world_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_member_in_world_QMARK__A); return ok }

func A_arbace_a2g_model_member_in_world_QMARK__A_Cast(x any) *A_arbace_a2g_model_member_in_world_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_member_in_world_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_member_in_world_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_method_desc_classes_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_method_desc_classes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_method_desc_classes_A_fn_class *jrt.Class

var A_arbace_a2g_model_method_desc_classes_A_init jrt.ClassInit

func A_arbace_a2g_model_method_desc_classes_A_Init() { if !A_arbace_a2g_model_method_desc_classes_A_init.Done() { A_arbace_a2g_model_method_desc_classes_A_init.Run(A_arbace_a2g_model_method_desc_classes_A_clinit) } }

func A_arbace_a2g_model_method_desc_classes_A_clinit() { A_arbace_a2g_model_method_desc_classes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_289, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_method_desc_classes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_method_desc_classes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_method_desc_classes_A_class }

func (t *A_arbace_a2g_model_method_desc_classes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_method_desc_classes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_method_desc_classes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_method_desc_classes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_method_desc_classes_A); return ok }

func A_arbace_a2g_model_method_desc_classes_A_Cast(x any) *A_arbace_a2g_model_method_desc_classes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_method_desc_classes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_method_desc_classes_A_class)) }; return v }



type A_arbace_a2g_model_methods_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_methods_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_methods_of_A_fn_class *jrt.Class

var A_arbace_a2g_model_methods_of_A_init jrt.ClassInit

func A_arbace_a2g_model_methods_of_A_Init() { if !A_arbace_a2g_model_methods_of_A_init.Done() { A_arbace_a2g_model_methods_of_A_init.Run(A_arbace_a2g_model_methods_of_A_clinit) } }

func A_arbace_a2g_model_methods_of_A_clinit() { A_arbace_a2g_model_methods_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_290, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_methods_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_methods_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_methods_of_A_class }

func (t *A_arbace_a2g_model_methods_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_methods_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_methods_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_methods_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_methods_of_A); return ok }

func A_arbace_a2g_model_methods_of_A_Cast(x any) *A_arbace_a2g_model_methods_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_methods_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_methods_of_A_class)) }; return v }



type A_arbace_a2g_model_par_mapv_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_par_mapv_A) Is_Compiler_AOTR3() {}

var A_arbace_a2g_model_par_mapv_A_fn_class *jrt.Class

var A_arbace_a2g_model_par_mapv_A_init jrt.ClassInit

func A_arbace_a2g_model_par_mapv_A_Init() { if !A_arbace_a2g_model_par_mapv_A_init.Done() { A_arbace_a2g_model_par_mapv_A_init.Run(A_arbace_a2g_model_par_mapv_A_clinit) } }

func A_arbace_a2g_model_par_mapv_A_clinit() { A_arbace_a2g_model_par_mapv_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_291, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_a2g_model_par_mapv_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_par_mapv_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_par_mapv_A_class }

func (t *A_arbace_a2g_model_par_mapv_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_par_mapv_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_par_mapv_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_par_mapv_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_par_mapv_A); return ok }

func A_arbace_a2g_model_par_mapv_A_Cast(x any) *A_arbace_a2g_model_par_mapv_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_par_mapv_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_par_mapv_A_class)) }; return v }



type A_arbace_a2g_model_par_mapv_fn__1008000019_A struct{ jrt.Object; F_work any }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_par_mapv_fn__1008000019_A_fn_class *jrt.Class

var A_arbace_a2g_model_par_mapv_fn__1008000019_A_init jrt.ClassInit

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_Init() { if !A_arbace_a2g_model_par_mapv_fn__1008000019_A_init.Done() { A_arbace_a2g_model_par_mapv_fn__1008000019_A_init.Run(A_arbace_a2g_model_par_mapv_fn__1008000019_A_clinit) } }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_clinit() { A_arbace_a2g_model_par_mapv_fn__1008000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_292, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_par_mapv_fn__1008000019_A_class }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_par_mapv_fn__1008000019_A); return ok }

func A_arbace_a2g_model_par_mapv_fn__1008000019_A_Cast(x any) *A_arbace_a2g_model_par_mapv_fn__1008000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_par_mapv_fn__1008000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_par_mapv_fn__1008000019_A_class)) }; return v }



type A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A struct{ jrt.Object; F_work any }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_fn_class *jrt.Class

var A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_init jrt.ClassInit

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_Init() { if !A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_init.Done() { A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_init.Run(A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_clinit) } }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_clinit() { A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A); return ok }

func A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_Cast(x any) *A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_par_mapv_fn__1008000019_fn__1008000020_A_class)) }; return v }



type A_arbace_a2g_model_par_mapv_work__1008000017_A struct{ jrt.Object; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_model_par_mapv_work__1008000017_A_fn_class *jrt.Class

var A_arbace_a2g_model_par_mapv_work__1008000017_A_init jrt.ClassInit

func A_arbace_a2g_model_par_mapv_work__1008000017_A_Init() { if !A_arbace_a2g_model_par_mapv_work__1008000017_A_init.Done() { A_arbace_a2g_model_par_mapv_work__1008000017_A_init.Run(A_arbace_a2g_model_par_mapv_work__1008000017_A_clinit) } }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_clinit() { A_arbace_a2g_model_par_mapv_work__1008000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_294, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_par_mapv_work__1008000017_A_class }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_par_mapv_work__1008000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_par_mapv_work__1008000017_A); return ok }

func A_arbace_a2g_model_par_mapv_work__1008000017_A_Cast(x any) *A_arbace_a2g_model_par_mapv_work__1008000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_par_mapv_work__1008000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_par_mapv_work__1008000017_A_class)) }; return v }



type A_arbace_a2g_model_pkg_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_pkg_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pkg_A_fn_class *jrt.Class

var A_arbace_a2g_model_pkg_A_init jrt.ClassInit

func A_arbace_a2g_model_pkg_A_Init() { if !A_arbace_a2g_model_pkg_A_init.Done() { A_arbace_a2g_model_pkg_A_init.Run(A_arbace_a2g_model_pkg_A_clinit) } }

func A_arbace_a2g_model_pkg_A_clinit() { A_arbace_a2g_model_pkg_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_295, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pkg_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pkg_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pkg_A_class }

func (t *A_arbace_a2g_model_pkg_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pkg_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pkg_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pkg_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pkg_A); return ok }

func A_arbace_a2g_model_pkg_A_Cast(x any) *A_arbace_a2g_model_pkg_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pkg_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pkg_A_class)) }; return v }



type A_arbace_a2g_model_pointer_desc_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_pointer_desc_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_pointer_desc_QMARK__A_Init() { if !A_arbace_a2g_model_pointer_desc_QMARK__A_init.Done() { A_arbace_a2g_model_pointer_desc_QMARK__A_init.Run(A_arbace_a2g_model_pointer_desc_QMARK__A_clinit) } }

func A_arbace_a2g_model_pointer_desc_QMARK__A_clinit() { A_arbace_a2g_model_pointer_desc_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_296, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pointer_desc_QMARK__A_class }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pointer_desc_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pointer_desc_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pointer_desc_QMARK__A); return ok }

func A_arbace_a2g_model_pointer_desc_QMARK__A_Cast(x any) *A_arbace_a2g_model_pointer_desc_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pointer_desc_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pointer_desc_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_private_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_private_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_private_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_private_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_private_QMARK__A_Init() { if !A_arbace_a2g_model_private_QMARK__A_init.Done() { A_arbace_a2g_model_private_QMARK__A_init.Run(A_arbace_a2g_model_private_QMARK__A_clinit) } }

func A_arbace_a2g_model_private_QMARK__A_clinit() { A_arbace_a2g_model_private_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_297, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_private_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_private_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_private_QMARK__A_class }

func (t *A_arbace_a2g_model_private_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_private_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_private_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_private_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_private_QMARK__A); return ok }

func A_arbace_a2g_model_private_QMARK__A_Cast(x any) *A_arbace_a2g_model_private_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_private_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_private_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_pure_ctor_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) Is_Compiler_AOTF4() {}

var A_arbace_a2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_pure_ctor_QMARK__A_Init() { if !A_arbace_a2g_model_pure_ctor_QMARK__A_init.Done() { A_arbace_a2g_model_pure_ctor_QMARK__A_init.Run(A_arbace_a2g_model_pure_ctor_QMARK__A_clinit) } }

func A_arbace_a2g_model_pure_ctor_QMARK__A_clinit() { A_arbace_a2g_model_pure_ctor_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_298, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_ctor_QMARK__A_class }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_ctor_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__A); return ok }

func A_arbace_a2g_model_pure_ctor_QMARK__A_Cast(x any) *A_arbace_a2g_model_pure_ctor_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_ctor_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_Init() { if !A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_init.Done() { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_init.Run(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_clinit) } }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_clinit() { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_300, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_class }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A); return ok }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_Cast(x any) *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000133_A_class)) }; return v }



type A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_Init() { if !A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_init.Done() { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_init.Run(A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_clinit) } }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_clinit() { A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_301, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_class }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A); return ok }

func A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_Cast(x any) *A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_ctor_QMARK__fn__1008000135_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_model_pure_node_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__A_init.Run(A_arbace_a2g_model_pure_node_QMARK__A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__A_clinit() { A_arbace_a2g_model_pure_node_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_302, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_306, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000145_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_307, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000148_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_308, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000153_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_309, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000155_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_310, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000157_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_311, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000159_A_class)) }; return v }



type A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A struct{ jrt.Object; F_n, F_seen any }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_fn_class *jrt.Class

var A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_init jrt.ClassInit

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_Init() { if !A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_init.Done() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_init.Run(A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_clinit) } }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_clinit() { A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_312, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_class }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A); return ok }

func A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_Cast(x any) *A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_pure_node_QMARK__fn__1008000161_A_class)) }; return v }



type A_arbace_a2g_model_qualify_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_qualify_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_model_qualify_A_fn_class *jrt.Class

var A_arbace_a2g_model_qualify_A_init jrt.ClassInit

func A_arbace_a2g_model_qualify_A_Init() { if !A_arbace_a2g_model_qualify_A_init.Done() { A_arbace_a2g_model_qualify_A_init.Run(A_arbace_a2g_model_qualify_A_clinit) } }

func A_arbace_a2g_model_qualify_A_clinit() { A_arbace_a2g_model_qualify_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_313, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_qualify_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_qualify_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_qualify_A_class }

func (t *A_arbace_a2g_model_qualify_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_qualify_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_qualify_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_qualify_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_qualify_A); return ok }

func A_arbace_a2g_model_qualify_A_Cast(x any) *A_arbace_a2g_model_qualify_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_qualify_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_qualify_A_class)) }; return v }



type A_arbace_a2g_model_reflectable_interface_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_reflectable_interface_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_reflectable_interface_QMARK__A_Init() { if !A_arbace_a2g_model_reflectable_interface_QMARK__A_init.Done() { A_arbace_a2g_model_reflectable_interface_QMARK__A_init.Run(A_arbace_a2g_model_reflectable_interface_QMARK__A_clinit) } }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_clinit() { A_arbace_a2g_model_reflectable_interface_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_314, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_reflectable_interface_QMARK__A_class }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_reflectable_interface_QMARK__A); return ok }

func A_arbace_a2g_model_reflectable_interface_QMARK__A_Cast(x any) *A_arbace_a2g_model_reflectable_interface_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_reflectable_interface_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_reflectable_interface_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_fn_class *jrt.Class

var A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_init jrt.ClassInit

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_Init() { if !A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_init.Done() { A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_init.Run(A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_clinit) } }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_clinit() { A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_321, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A); return ok }

func A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_Cast(x any) *A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_reflectable_interface_QMARK__fn__1008000033_A_class)) }; return v }



type A_arbace_a2g_model_reflected_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_reflected_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_reflected_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_reflected_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_reflected_QMARK__A_Init() { if !A_arbace_a2g_model_reflected_QMARK__A_init.Done() { A_arbace_a2g_model_reflected_QMARK__A_init.Run(A_arbace_a2g_model_reflected_QMARK__A_clinit) } }

func A_arbace_a2g_model_reflected_QMARK__A_clinit() { A_arbace_a2g_model_reflected_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_322, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_reflected_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_reflected_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_reflected_QMARK__A_class }

func (t *A_arbace_a2g_model_reflected_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_reflected_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_reflected_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_reflected_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_reflected_QMARK__A); return ok }

func A_arbace_a2g_model_reflected_QMARK__A_Cast(x any) *A_arbace_a2g_model_reflected_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_reflected_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_reflected_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_static_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_static_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_static_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_static_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_static_QMARK__A_Init() { if !A_arbace_a2g_model_static_QMARK__A_init.Done() { A_arbace_a2g_model_static_QMARK__A_init.Run(A_arbace_a2g_model_static_QMARK__A_clinit) } }

func A_arbace_a2g_model_static_QMARK__A_clinit() { A_arbace_a2g_model_static_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_323, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_static_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_static_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_static_QMARK__A_class }

func (t *A_arbace_a2g_model_static_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_static_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_static_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_static_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_static_QMARK__A); return ok }

func A_arbace_a2g_model_static_QMARK__A_Cast(x any) *A_arbace_a2g_model_static_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_static_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_static_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_subclasses_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_subclasses_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_subclasses_A_fn_class *jrt.Class

var A_arbace_a2g_model_subclasses_A_init jrt.ClassInit

func A_arbace_a2g_model_subclasses_A_Init() { if !A_arbace_a2g_model_subclasses_A_init.Done() { A_arbace_a2g_model_subclasses_A_init.Run(A_arbace_a2g_model_subclasses_A_clinit) } }

func A_arbace_a2g_model_subclasses_A_clinit() { A_arbace_a2g_model_subclasses_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_324, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_subclasses_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_subclasses_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_subclasses_A_class }

func (t *A_arbace_a2g_model_subclasses_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_subclasses_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_subclasses_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_subclasses_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_subclasses_A); return ok }

func A_arbace_a2g_model_subclasses_A_Cast(x any) *A_arbace_a2g_model_subclasses_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_subclasses_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_subclasses_A_class)) }; return v }



type A_arbace_a2g_model_superclass_chain_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_superclass_chain_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_superclass_chain_A_fn_class *jrt.Class

var A_arbace_a2g_model_superclass_chain_A_init jrt.ClassInit

func A_arbace_a2g_model_superclass_chain_A_Init() { if !A_arbace_a2g_model_superclass_chain_A_init.Done() { A_arbace_a2g_model_superclass_chain_A_init.Run(A_arbace_a2g_model_superclass_chain_A_clinit) } }

func A_arbace_a2g_model_superclass_chain_A_clinit() { A_arbace_a2g_model_superclass_chain_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_325, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_superclass_chain_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_superclass_chain_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_superclass_chain_A_class }

func (t *A_arbace_a2g_model_superclass_chain_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_superclass_chain_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_superclass_chain_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_superclass_chain_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_superclass_chain_A); return ok }

func A_arbace_a2g_model_superclass_chain_A_Cast(x any) *A_arbace_a2g_model_superclass_chain_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_superclass_chain_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_superclass_chain_A_class)) }; return v }



type A_arbace_a2g_model_superclass_chain_fn__1008000104_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_superclass_chain_fn__1008000104_A_fn_class *jrt.Class

var A_arbace_a2g_model_superclass_chain_fn__1008000104_A_init jrt.ClassInit

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_Init() { if !A_arbace_a2g_model_superclass_chain_fn__1008000104_A_init.Done() { A_arbace_a2g_model_superclass_chain_fn__1008000104_A_init.Run(A_arbace_a2g_model_superclass_chain_fn__1008000104_A_clinit) } }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_clinit() { A_arbace_a2g_model_superclass_chain_fn__1008000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_326, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_superclass_chain_fn__1008000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_superclass_chain_fn__1008000104_A); return ok }

func A_arbace_a2g_model_superclass_chain_fn__1008000104_A_Cast(x any) *A_arbace_a2g_model_superclass_chain_fn__1008000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_superclass_chain_fn__1008000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_superclass_chain_fn__1008000104_A_class)) }; return v }



type A_arbace_a2g_model_supertypes_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_supertypes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_supertypes_A_fn_class *jrt.Class

var A_arbace_a2g_model_supertypes_A_init jrt.ClassInit

func A_arbace_a2g_model_supertypes_A_Init() { if !A_arbace_a2g_model_supertypes_A_init.Done() { A_arbace_a2g_model_supertypes_A_init.Run(A_arbace_a2g_model_supertypes_A_clinit) } }

func A_arbace_a2g_model_supertypes_A_clinit() { A_arbace_a2g_model_supertypes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_327, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_supertypes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_supertypes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_supertypes_A_class }

func (t *A_arbace_a2g_model_supertypes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_supertypes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_supertypes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_supertypes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_supertypes_A); return ok }

func A_arbace_a2g_model_supertypes_A_Cast(x any) *A_arbace_a2g_model_supertypes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_supertypes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_supertypes_A_class)) }; return v }



type A_arbace_a2g_model_top_class_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_top_class_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_top_class_A_fn_class *jrt.Class

var A_arbace_a2g_model_top_class_A_init jrt.ClassInit

func A_arbace_a2g_model_top_class_A_Init() { if !A_arbace_a2g_model_top_class_A_init.Done() { A_arbace_a2g_model_top_class_A_init.Run(A_arbace_a2g_model_top_class_A_clinit) } }

func A_arbace_a2g_model_top_class_A_clinit() { A_arbace_a2g_model_top_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_328, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_top_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_top_class_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_top_class_A_class }

func (t *A_arbace_a2g_model_top_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_top_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_top_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_top_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_top_class_A); return ok }

func A_arbace_a2g_model_top_class_A_Cast(x any) *A_arbace_a2g_model_top_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_top_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_top_class_A_class)) }; return v }



type A_arbace_a2g_model_translatable_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_translatable_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_translatable_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_translatable_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_translatable_QMARK__A_Init() { if !A_arbace_a2g_model_translatable_QMARK__A_init.Done() { A_arbace_a2g_model_translatable_QMARK__A_init.Run(A_arbace_a2g_model_translatable_QMARK__A_clinit) } }

func A_arbace_a2g_model_translatable_QMARK__A_clinit() { A_arbace_a2g_model_translatable_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_330, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_translatable_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_translatable_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_translatable_QMARK__A_class }

func (t *A_arbace_a2g_model_translatable_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_translatable_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_translatable_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_translatable_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_translatable_QMARK__A); return ok }

func A_arbace_a2g_model_translatable_QMARK__A_Cast(x any) *A_arbace_a2g_model_translatable_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_translatable_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_translatable_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_translated_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_translated_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_translated_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_translated_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_translated_QMARK__A_Init() { if !A_arbace_a2g_model_translated_QMARK__A_init.Done() { A_arbace_a2g_model_translated_QMARK__A_init.Run(A_arbace_a2g_model_translated_QMARK__A_clinit) } }

func A_arbace_a2g_model_translated_QMARK__A_clinit() { A_arbace_a2g_model_translated_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_331, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_translated_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_translated_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_translated_QMARK__A_class }

func (t *A_arbace_a2g_model_translated_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_translated_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_translated_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_translated_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_translated_QMARK__A); return ok }

func A_arbace_a2g_model_translated_QMARK__A_Cast(x any) *A_arbace_a2g_model_translated_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_translated_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_translated_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_trivial_init_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_trivial_init_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_trivial_init_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_trivial_init_QMARK__A_Init() { if !A_arbace_a2g_model_trivial_init_QMARK__A_init.Done() { A_arbace_a2g_model_trivial_init_QMARK__A_init.Run(A_arbace_a2g_model_trivial_init_QMARK__A_clinit) } }

func A_arbace_a2g_model_trivial_init_QMARK__A_clinit() { A_arbace_a2g_model_trivial_init_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_332, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_trivial_init_QMARK__A_class }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_trivial_init_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_trivial_init_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_trivial_init_QMARK__A); return ok }

func A_arbace_a2g_model_trivial_init_QMARK__A_Cast(x any) *A_arbace_a2g_model_trivial_init_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_trivial_init_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_trivial_init_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_virtual_member_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_virtual_member_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_model_virtual_member_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_model_virtual_member_QMARK__A_Init() { if !A_arbace_a2g_model_virtual_member_QMARK__A_init.Done() { A_arbace_a2g_model_virtual_member_QMARK__A_init.Run(A_arbace_a2g_model_virtual_member_QMARK__A_clinit) } }

func A_arbace_a2g_model_virtual_member_QMARK__A_clinit() { A_arbace_a2g_model_virtual_member_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_333, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_virtual_member_QMARK__A_class }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_virtual_member_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_virtual_member_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_virtual_member_QMARK__A); return ok }

func A_arbace_a2g_model_virtual_member_QMARK__A_Cast(x any) *A_arbace_a2g_model_virtual_member_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_virtual_member_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_virtual_member_QMARK__A_class)) }; return v }



type A_arbace_a2g_model_vmethods_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_vmethods_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_vmethods_A_fn_class *jrt.Class

var A_arbace_a2g_model_vmethods_A_init jrt.ClassInit

func A_arbace_a2g_model_vmethods_A_Init() { if !A_arbace_a2g_model_vmethods_A_init.Done() { A_arbace_a2g_model_vmethods_A_init.Run(A_arbace_a2g_model_vmethods_A_clinit) } }

func A_arbace_a2g_model_vmethods_A_clinit() { A_arbace_a2g_model_vmethods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_335, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_vmethods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_vmethods_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_vmethods_A_class }

func (t *A_arbace_a2g_model_vmethods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_vmethods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_vmethods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_vmethods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_vmethods_A); return ok }

func A_arbace_a2g_model_vmethods_A_Cast(x any) *A_arbace_a2g_model_vmethods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_vmethods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_vmethods_A_class)) }; return v }



type A_arbace_a2g_model_vmethods_fn__1008000098_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_vmethods_fn__1008000098_A_fn_class *jrt.Class

var A_arbace_a2g_model_vmethods_fn__1008000098_A_init jrt.ClassInit

func A_arbace_a2g_model_vmethods_fn__1008000098_A_Init() { if !A_arbace_a2g_model_vmethods_fn__1008000098_A_init.Done() { A_arbace_a2g_model_vmethods_fn__1008000098_A_init.Run(A_arbace_a2g_model_vmethods_fn__1008000098_A_clinit) } }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_clinit() { A_arbace_a2g_model_vmethods_fn__1008000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_336, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_vmethods_fn__1008000098_A_class }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_vmethods_fn__1008000098_A); return ok }

func A_arbace_a2g_model_vmethods_fn__1008000098_A_Cast(x any) *A_arbace_a2g_model_vmethods_fn__1008000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_vmethods_fn__1008000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_vmethods_fn__1008000098_A_class)) }; return v }



type A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_fn_class *jrt.Class

var A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_init jrt.ClassInit

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_Init() { if !A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_init.Done() { A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_init.Run(A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_clinit) } }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_clinit() { A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_337, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A); return ok }

func A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_Cast(x any) *A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_vmethods_fn__1008000098_fn__1008000099_A_class)) }; return v }



type A_arbace_a2g_model_world_supertypes_A struct{ jrt.Object }

func (t *A_arbace_a2g_model_world_supertypes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_model_world_supertypes_A_fn_class *jrt.Class

var A_arbace_a2g_model_world_supertypes_A_init jrt.ClassInit

func A_arbace_a2g_model_world_supertypes_A_Init() { if !A_arbace_a2g_model_world_supertypes_A_init.Done() { A_arbace_a2g_model_world_supertypes_A_init.Run(A_arbace_a2g_model_world_supertypes_A_clinit) } }

func A_arbace_a2g_model_world_supertypes_A_clinit() { A_arbace_a2g_model_world_supertypes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_338, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_model_world_supertypes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_model_world_supertypes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_model_world_supertypes_A_class }

func (t *A_arbace_a2g_model_world_supertypes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_model_world_supertypes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_model_world_supertypes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_model_world_supertypes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_model_world_supertypes_A); return ok }

func A_arbace_a2g_model_world_supertypes_A_Cast(x any) *A_arbace_a2g_model_world_supertypes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_model_world_supertypes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_model_world_supertypes_A_class)) }; return v }
